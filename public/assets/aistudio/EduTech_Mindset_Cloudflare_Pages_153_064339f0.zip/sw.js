/* عمل الموقع مع ضعف الاتصال أو انقطاعه (الإصدار 43):
 * - ملفات الموقع: الشبكة أولاً (لتصل التحديثات) مع مهلة قصيرة ثم النسخة المحفوظة
 * - المكتبات الخارجية (Tailwind/Firebase/الخطوط/الأيقونات): نسخة محفوظة فوراً وتُحدَّث بالخلفية
 * - لا نلمس الـ API ولا الطلبات غير GET ولا طلبات Range (الفيديو/الصوت)
 */
const CACHE_NAME = 'edutech-mindset-v153';
const LOCAL = ['./', './index.html', './privacy.html', './robots.txt', './sitemap.xml', './manifest.json', './firebase-config.js', './assets/asset_2.jpeg', './assets/infographic.jpg', './assets/icon-512.png', './assets/icon-maskable-512.png', './css/style.css', './css/premium.css',
  './js/ai-admin.js', './js/ai.js', './js/app.js', './js/books.js', './js/cloud.js', './js/designs.js', './js/exam.js', './js/export.js',
  './js/extras.js', './js/home.js', './js/learn.js', './js/lessonplans.js', './js/media.js', './js/slides.js', './js/sound.js', './js/theme.js',
  './js/tools.js', './js/welcome.js', './js/assistant.js', './js/edutech-v146-suite.js', './js/brand.js', './js/emailauth.js', './js/gsearch.js', './js/perf.js', './js/worksheets.js', './js/badges.js', './js/games.js', './js/tutor.js', './js/classrooms.js', './js/certificates.js', './js/voice.js', './js/study.js', './js/courses.js', './js/planner.js', './js/review.js', './js/lessonkit.js', './js/ecosystem.js', './js/bookreader.js', './js/cvbuilder.js', './js/unicareer.js', './js/multisynth.js', './js/masteryhub.js', './js/visualconcept.js', './js/smartnotes.js', './js/stemlabplanner.js', './js/smartbrain.js', './js/master-hierarchy.js', './js/dock.js', './js/a11y.js', './js/simlab.js', './js/classtools.js', './js/homework.js', './js/stories.js', './js/analytics.js', './js/whiteboard.js', './js/langlab.js', './js/parents.js', './js/tawjihi.js', './js/earlylearn.js', './js/offpack.js', './js/launcher.js', './js/codinglab.js', './js/rubrics.js', './js/atlas.js', './js/radio.js', './js/mediatools.js', './js/portfolio.js', './js/inclusive.js', './js/scicalc.js',
  './js/pwa.js', './js/diagnostics.js', './js/library.js', './js/sources.js', './js/dashboard.js', './js/boost.js', './js/ticker.js', './js/poster.js', './js/ar-track.js', './js/ar.js',
  './assets/logo.png', './assets/icon-192.png'];
const EXT = ['cdn.tailwindcss.com', 'www.gstatic.com', 'cdnjs.cloudflare.com', 'fonts.googleapis.com', 'fonts.gstatic.com', 'cdn.jsdelivr.net', 'unpkg.com'];
const NET_TIMEOUT = 3500;

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((c) => Promise.all(LOCAL.map((u) => c.add(u).catch(() => null)))));
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.map((k) => (k !== CACHE_NAME ? caches.delete(k) : null)))));
  self.clients.claim();
});

function put(req, res) {
  if (res && (res.ok || res.type === 'opaque')) { const copy = res.clone(); caches.open(CACHE_NAME).then((c) => c.put(req, copy)).catch(() => {}); }
  return res;
}
function withTimeout(p, ms) { return new Promise((resolve, reject) => { const t = setTimeout(() => reject(new Error('timeout')), ms); p.then((v) => { clearTimeout(t); resolve(v); }, (e) => { clearTimeout(t); reject(e); }); }); }

self.addEventListener('fetch', (event) => {
  const req = event.request, url = new URL(req.url);
  if (req.method !== 'GET' || req.headers.has('range')) return;
  if (url.origin === location.origin) {
    if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/.netlify/')) return;
    // الإصدار 148: أداء أسرع عند التكرار
    //  - الصفحات والتنقل: الشبكة أولاً بمهلة قصيرة ثم النسخة المحفوظة (لتصل التحديثات)
    //  - الملفات ذات ?v=: من الذاكرة فوراً (الرابط يتغير مع كل إصدار) مع تحديث صامت بالخلفية
    //  - باقي الملفات: نسخة محفوظة فوراً + تحديث بالخلفية (stale-while-revalidate)
    const isNav = req.mode === 'navigate' || /\.(html)$/.test(url.pathname) || url.pathname === '/' || /sw\.js$|manifest\.json$/.test(url.pathname);
    if (!isNav) {
      event.respondWith(
        caches.match(req).then((cached) => {
          const net = fetch(req).then((res) => put(req, res)).catch(() => null);
          if (cached) { event.waitUntil(net); return cached; }
          return net.then((r) => r || caches.match(req, { ignoreSearch: true })).then((r) => r || Response.error());
        })
      );
      return;
    }
    event.respondWith(
      withTimeout(fetch(req), NET_TIMEOUT).then((res) => put(req, res)).catch(() =>
        caches.match(req).then((m) => m || caches.match(req, { ignoreSearch: true })).then((m) => m || (req.mode === 'navigate' ? caches.match('./index.html') : undefined) || Response.error()))
    );
    return;
  }
  if (EXT.indexOf(url.hostname) !== -1) {
    event.respondWith(
      caches.match(req).then((cached) => {
        const net = fetch(req).then((res) => put(req, res)).catch(() => null);
        return cached || net.then((r) => r || Response.error());
      })
    );
  }
});

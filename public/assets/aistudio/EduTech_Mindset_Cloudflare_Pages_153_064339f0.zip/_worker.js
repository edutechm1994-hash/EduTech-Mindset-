// EduTech Mindset — Cloudflare Pages Advanced Mode Worker
// مهيأ لنطاق edutech-mindset.pages.dev وعلى خوادم Cloudflare
// يدعم حفظ مفاتيح الذكاء الاصطناعي مباشرة من لوحة الإدارة بالموقع دون الحاجة لإعادة النشر
"use strict";

var ENGINES = ["gemini", "openai", "claude", "deepseek", "meta", "free"];
var KEY_ENV = {
  gemini: "GEMINI_API_KEY",
  openai: "OPENAI_API_KEY",
  claude: "ANTHROPIC_API_KEY",
  deepseek: "DEEPSEEK_API_KEY",
  meta: "META_API_KEY"
};
var VISION = {
  gemini: true,
  openai: true,
  claude: true,
  deepseek: false,
  meta: false,
  free: false
};
var NAMES = {
  gemini: "Google Gemini",
  openai: "OpenAI ChatGPT",
  claude: "Anthropic Claude",
  deepseek: "DeepSeek",
  meta: "Meta AI (Llama)",
  free: "المحرك المجاني"
};

var MAX_BODY = 15 * 1024 * 1024;
var SYSTEM = "أنت مساعد تربوي خبير في تكنولوجيا التعليم يدعم المعلمين والطلبة في فلسطين. " +
  "أجب بالعربية الفصحى المبسطة بتنسيق منظم (عناوين قصيرة وقوائم) وبمحتوى عملي قابل للتطبيق مباشرة في الصف، " +
  "وراعِ محدودية الموارد والإنترنت. لا تختلق مصادر أو إحصاءات.";

// ذاكرة مؤقتة للمفاتيح في Worker Isolate
var ACTIVE_KEYS = {};
var tokenCache = {};
var hits = {};
var lastVaultSync = 0;

// ---------- أدوات التشفير والـ Base64 بدون Buffer ----------
function u8ToBase64(u8) {
  var bin = "";
  for (var i = 0; i < u8.length; i++) bin += String.fromCharCode(u8[i]);
  return btoa(bin);
}

function base64ToU8(b64) {
  var bin = atob(b64);
  var u8 = new Uint8Array(bin.length);
  for (var i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

async function getVaultCryptoKey(secret, saltStr) {
  var enc = new TextEncoder();
  if (saltStr) {
    var baseKey = await crypto.subtle.importKey("raw", enc.encode(secret), "PBKDF2", false, ["deriveKey"]);
    return crypto.subtle.deriveKey(
      { name: "PBKDF2", salt: enc.encode("EduTech-v52:" + saltStr), iterations: 100000, hash: "SHA-256" },
      baseKey,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );
  }
  var rawKey = await crypto.subtle.digest("SHA-256", enc.encode(secret));
  return crypto.subtle.importKey("raw", rawKey, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}

async function encryptVault(dataObj, secret) {
  var iv = crypto.getRandomValues(new Uint8Array(12));
  var ivB64 = u8ToBase64(iv);
  var key = await getVaultCryptoKey(secret, ivB64);
  var enc = new TextEncoder();
  var cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv: iv }, key, enc.encode(JSON.stringify(dataObj)));
  return {
    ciphertext: u8ToBase64(new Uint8Array(cipher)),
    iv: ivB64,
    kdf: "pbkdf2-v52"
  };
}

async function decryptVault(ciphertextB64, ivB64, secret) {
  var iv = base64ToU8(ivB64);
  var cipher = base64ToU8(ciphertextB64);
  var dec = new TextDecoder();
  // محاولة فك التشفير بمعيار الإصدار 52 (PBKDF2-100k) أولاً ثم التوافق العكسي مع SHA-256
  try {
    var keyV52 = await getVaultCryptoKey(secret, ivB64);
    var decryptedV52 = await crypto.subtle.decrypt({ name: "AES-GCM", iv: iv }, keyV52, cipher);
    return JSON.parse(dec.decode(decryptedV52));
  } catch (e1) {
    try {
      var keyLegacy = await getVaultCryptoKey(secret, null);
      var decryptedLegacy = await crypto.subtle.decrypt({ name: "AES-GCM", iv: iv }, keyLegacy, cipher);
      return JSON.parse(dec.decode(decryptedLegacy));
    } catch (e2) {
      console.warn("Vault decryption error:", e2 && e2.message);
      return null;
    }
  }
}

var LEGACY_VAULT_SECRET = "EduTech-Mindset-Vault-Secret-2026-Palestine";
function getVaultSecret(env) {
  return (env && env.VAULT_SECRET) || LEGACY_VAULT_SECRET;
}

function getFirebaseWebKey(env) {
  return (env && env.FIREBASE_WEB_API_KEY) || "AIzaSyB5F7emEsoQgqDh2qworzjr1lEPefUAz9Q";
}

function getFirebaseProjectId(env) {
  return (env && env.FIREBASE_PROJECT_ID) || "edutech-mindset-claud";
}

function getAdminEmails(env) {
  var raw = (env && env.ADMIN_EMAILS) || "baselashraf800@gmail.com,Edutechm1994@gmail.com";
  return raw.split(",").map(function (s) { return s.trim().toLowerCase(); }).filter(Boolean);
}

// ---------- إدارة المفاتيح وقراءتها من KV / Firestore / المتغيرات ----------
async function ensureKeysLoaded(env, force) {
  var now = Date.now();
  if (!force && lastVaultSync > 0 && (now - lastVaultSync < 60000)) return;
  lastVaultSync = now;

  // 1. فحص Cloudflare KV في حال تم ربط Namespace (AI_KEYS أو KV)
  var kv = (env && (env.AI_KEYS || env.KV || env.EDUTECH_KV));
  if (kv && typeof kv.get === "function") {
    try {
      for (var k of ENGINES) {
        if (k === "free") continue;
        var val = await kv.get("KEY_" + k);
        if (val && typeof val === "string") ACTIVE_KEYS[k] = val.trim();
      }
    } catch (e) {
      console.warn("KV get error:", e);
    }
  }

  // 2. قراءة الخزينة المشفرة من Firestore (/site/ai_vault)
  try {
    var fUrl = "https://firestore.googleapis.com/v1/projects/" + encodeURIComponent(getFirebaseProjectId(env)) +
      "/databases/(default)/documents/site/ai_vault?key=" + encodeURIComponent(getFirebaseWebKey(env));
    var res = await fetch(fUrl);
    if (res.ok) {
      var doc = await res.json();
      var fields = doc && doc.fields;
      if (fields && fields.vault && fields.vault.stringValue && fields.iv && fields.iv.stringValue) {
        var dec = await decryptVault(fields.vault.stringValue, fields.iv.stringValue, getVaultSecret(env));
        // مفاتيح محفوظة قبل ضبط VAULT_SECRET: تُقرأ بالسر القديم ثم تُعاد كتابتها مشفّرة بالسر الجديد عند أول حفظ
        if (!dec && env && env.VAULT_SECRET) dec = await decryptVault(fields.vault.stringValue, fields.iv.stringValue, LEGACY_VAULT_SECRET);
        if (dec && typeof dec === "object") {
          ENGINES.forEach(function (e) {
            if (dec[e] && typeof dec[e] === "string" && dec[e].trim()) {
              ACTIVE_KEYS[e] = dec[e].trim();
            }
          });
        }
      }
    }
  } catch (e) {
    console.warn("Firestore vault read error:", e);
  }

  // 3. فحص متغيرات البيئة في Cloudflare Pages كاحتياطي
  if (env) {
    ENGINES.forEach(function (e) {
      if (e === "free") return;
      var envKey = KEY_ENV[e];
      if (!ACTIVE_KEYS[e] && env[envKey] && String(env[envKey]).trim()) {
        ACTIVE_KEYS[e] = String(env[envKey]).trim();
      }
    });
  }
}

function keyOf(engine, env) {
  if (engine === "free") return "free";
  if (ACTIVE_KEYS[engine]) return ACTIVE_KEYS[engine];
  if (env && env[KEY_ENV[engine]]) return String(env[KEY_ENV[engine]]).trim();
  return "";
}

function cleanMsg(msg, env) {
  var s = String(msg || "خطأ غير معروف");
  ENGINES.forEach(function (e) {
    var k = keyOf(e, env);
    if (k && k.length > 8) s = s.split(k).join("***");
  });
  return s.slice(0, 300);
}

function defaultModels(engine, env) {
  if (engine === "gemini") return ((env && env.GEMINI_MODELS) || "gemini-2.5-flash,gemini-flash-latest,gemini-2.5-flash-lite").split(",").map(function (s) { return s.trim(); }).filter(Boolean);
  if (engine === "openai") return [(env && env.OPENAI_MODEL) || "gpt-4o-mini"];
  if (engine === "claude") return [(env && env.CLAUDE_MODEL) || "claude-haiku-4-5-20251001"];
  if (engine === "deepseek") return [(env && env.DEEPSEEK_MODEL) || "deepseek-chat"];
  if (engine === "meta") return [(env && env.META_MODEL) || "Llama-3.3-70B-Instruct"];
  return ["openai"];
}

function pickModels(engine, custom, env) {
  var c = typeof custom === "string" ? custom.trim() : "";
  if (c && /^[A-Za-z0-9._:\-\/]{2,80}$/.test(c)) return [c].concat(defaultModels(engine, env).filter(function (m) { return m !== c; }).slice(0, engine === "gemini" ? 2 : 0));
  return defaultModels(engine, env);
}

function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

// ---------- استدعاء HTTP مع مهلة ----------
async function http(url, opt, ms) {
  var c = new AbortController(), t = setTimeout(function () { c.abort(); }, Math.max(1500, ms));
  try {
    opt.signal = c.signal;
    var res = await fetch(url, opt), txt = await res.text(), j = null;
    try { j = JSON.parse(txt); } catch (e) {}
    return { ok: res.ok, status: res.status, json: j, text: txt };
  } catch (e) {
    throw new Error(e && e.name === "AbortError" ? "انتهت مهلة الاستجابة" : "تعذر الاتصال بالمحرك");
  } finally { clearTimeout(t); }
}

function apiError(r, name, env) {
  var m = r.json && (r.json.error && (r.json.error.message || r.json.error) || r.json.message);
  var e = new Error(name + " (" + r.status + "): " + cleanMsg(typeof m === "string" ? m : r.text.slice(0, 120), env));
  e.status = r.status; return e;
}

// ---------- المحركات ----------
var GEM_CACHE = { at: 0, list: [] };
// اكتشاف أحدث نماذج Gemini المتاحة فعلاً لمفتاحك (حين يوقف Google نموذجاً قديماً)
async function discoverGemini(env, left) {
  if (GEM_CACHE.list.length && Date.now() - GEM_CACHE.at < 6 * 3600 * 1000) return GEM_CACHE.list;
  var r = await http("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", { method: "GET", headers: { "x-goog-api-key": keyOf("gemini", env) } }, Math.min(left, 8000));
  if (!r.ok || !r.json || !r.json.models) return [];
  var out = r.json.models.filter(function (m) {
    return /^models\/gemini-/.test(m.name) && (m.supportedGenerationMethods || []).indexOf("generateContent") >= 0 && /flash/.test(m.name) && !/lite|image|tts|live|audio|embed|thinking|exp|robotics|computer|vision|8b/.test(m.name);
  }).map(function (m) { var v = /gemini-(\d+(?:\.\d+)?)/.exec(m.name); return { n: m.name.replace("models/", ""), v: v ? parseFloat(v[1]) : 0, prev: /preview/.test(m.name) ? 1 : 0 }; })
    .sort(function (a, b) { return (a.prev - b.prev) || (b.v - a.v) || (a.n.length - b.n.length); });
  GEM_CACHE = { at: Date.now(), list: out.slice(0, 4).map(function (x) { return x.n; }) };
  return GEM_CACHE.list;
}

async function callGemini(p, models, deadline, env) {
  var parts = (p.files || []).map(function (f) { return { inlineData: { mimeType: f.mime, data: f.data } }; });
  parts.push({ text: p.prompt });
  function bodyFor(model) {
    var gc = { temperature: 0.7, maxOutputTokens: 8192 };
    if (/^gemini-2\.5-flash(-\d+)?$/.test(model)) gc.thinkingConfig = { thinkingBudget: 0 }; // أسرع وأوفر، والجودة كافية لمحتوى الدروس
    return JSON.stringify({ systemInstruction: { parts: [{ text: p.system }] }, contents: [{ role: "user", parts: parts }], generationConfig: gc });
  }
  var last, tried = {}, discovered = false;
  var queue = models.slice();
  while (queue.length) {
    var model = queue.shift(); if (tried[model]) continue; tried[model] = 1;
    for (var attempt = 0; attempt < 3; attempt++) {
      var left = deadline - Date.now(); if (left < 2000) throw last || new Error("انتهت المهلة");
      var r;
      try {
        // سقف لكل محاولة حتى لا يستهلك نموذج بطيء كل الوقت فنفقد فرصة تجربة النموذج التالي
        r = await http("https://generativelanguage.googleapis.com/v1beta/models/" + encodeURIComponent(model) + ":generateContent",
          { method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": keyOf("gemini", env) }, body: bodyFor(model) }, Math.min(left, Math.max(10000, Math.floor(left / 2))));
      } catch (e) { last = new Error("Gemini [" + model + "]: " + (e && e.message || "تعذر الاتصال")); break; }
      if (r.ok) {
        var c = r.json && r.json.candidates && r.json.candidates[0];
        var txt = c && c.content && c.content.parts ? c.content.parts.map(function (x) { return x.text || ""; }).join("").trim() : "";
        if (txt) return { text: txt, model: model };
        last = new Error("Gemini: استجابة فارغة" + (c && c.finishReason ? " (" + c.finishReason + ")" : "")); break;
      }
      last = apiError(r, "Gemini [" + model + "]", env); last.status = r.status;
      if ([400, 401, 403].indexOf(r.status) >= 0) throw last;
      if (r.status === 404) break;
      if ([429, 500, 502, 503, 504].indexOf(r.status) >= 0) { if (attempt < 2) await sleep(1200 * (attempt + 1)); else break; }
      else throw last;
    }
    // نفدت النماذج المعروفة وكلها 404 ← اسأل Google عن النماذج المتاحة الآن وجرّبها
    if (!queue.length && !discovered && last && last.status === 404) {
      discovered = true;
      try { queue = (await discoverGemini(env, deadline - Date.now())).filter(function (m) { return !tried[m]; }); } catch (e) {}
    }
  }
  throw last || new Error("Gemini: فشل الاتصال بالمحرك");
}

function dataUrl(f) { return "data:" + f.mime + ";base64," + f.data; }

async function callOpenAICompat(url, name, key, model, p, deadline, allowFiles, env) {
  var userContent = p.prompt;
  if (allowFiles && p.files && p.files.length) {
    userContent = p.files.map(function (f) {
      return /^image\//.test(f.mime) ? { type: "image_url", image_url: { url: dataUrl(f) } } : { type: "file", file: { filename: f.name || "file.pdf", file_data: dataUrl(f) } };
    }).concat([{ type: "text", text: p.prompt }]);
  }
  var body = { model: model, messages: [{ role: "system", content: p.system }, { role: "user", content: userContent }] };
  if (name === "OpenAI") body.max_completion_tokens = 8192; else body.max_tokens = 8192;
  var r = await http(url, { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + key }, body: JSON.stringify(body) }, deadline - Date.now());
  if (!r.ok) throw apiError(r, name, env);
  var t = r.json && r.json.choices && r.json.choices[0] && r.json.choices[0].message && r.json.choices[0].message.content;
  if (!t || !String(t).trim()) throw new Error(name + ": استجابة فارغة");
  return { text: String(t).trim(), model: model };
}

async function callClaude(p, model, deadline, env) {
  var content = (p.files || []).map(function (f) {
    return /^image\//.test(f.mime) ? { type: "image", source: { type: "base64", media_type: f.mime, data: f.data } }
      : { type: "document", source: { type: "base64", media_type: "application/pdf", data: f.data } };
  });
  content.push({ type: "text", text: p.prompt });
  var r = await http("https://api.anthropic.com/v1/messages", { method: "POST",
    headers: { "Content-Type": "application/json", "x-api-key": keyOf("claude", env), "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model: model, max_tokens: 8192, system: p.system, messages: [{ role: "user", content: content }] }) }, deadline - Date.now());
  if (!r.ok) throw apiError(r, "Claude", env);
  var t = r.json && r.json.content ? r.json.content.map(function (b) { return b.text || ""; }).join("").trim() : "";
  if (!t) throw new Error("Claude: استجابة فارغة");
  return { text: t, model: model };
}

async function callFree(p, deadline) {
  var r = await http("https://text.pollinations.ai/openai", { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model: "openai", messages: [{ role: "system", content: p.system }, { role: "user", content: p.prompt.slice(0, 6000) }] }) }, Math.min(25000, deadline - Date.now()));
  var t = r.json && r.json.choices && r.json.choices[0] && r.json.choices[0].message && r.json.choices[0].message.content;
  if (!r.ok || !t) throw new Error("المحرك المجاني غير متاح الآن");
  return { text: String(t).trim(), model: "free" };
}

async function runEngine(engine, p, models, deadline, env) {
  var ms = pickModels(engine, models && models[engine], env);
  if (engine === "gemini") return callGemini(p, ms, deadline, env);
  if (engine === "openai") return callOpenAICompat("https://api.openai.com/v1/chat/completions", "OpenAI", keyOf("openai", env), ms[0], p, deadline, true, env);
  if (engine === "deepseek") return callOpenAICompat("https://api.deepseek.com/chat/completions", "DeepSeek", keyOf("deepseek", env), ms[0], p, deadline, false, env);
  if (engine === "claude") return callClaude(p, ms[0], deadline, env);
  if (engine === "meta") return callOpenAICompat(((env && env.META_BASE_URL) || "https://api.llama.com/compat/v1").replace(/\/$/, "") + "/chat/completions", "Meta AI", keyOf("meta", env), ms[0], p, deadline, false, env);
  return callFree(p, deadline);
}

// ---------- التحقق من الهوية عبر Firebase Auth ----------

// ---------- فرض الصلاحيات من جهة الخادم (الإصدار 149) ----------
// يقرأ منح المستخدم grants/{email} بتوكنه الخاص (القواعد تسمح لصاحب بريد موثّق فقط)،
// ويرفض: الحساب الموقوف، أو أداة محجوبة عنه تحديداً. عند تعذّر القراءة نسمح (fail-open) كي لا نعطّل الخدمة.
var grantCache = {};
async function userGrantBlock(user, idToken, toolId, env) {
  try {
    if (!user || !user.verified || !user.email || !idToken) return null;
    var key = user.email, c = grantCache[key];
    if (!c || c.exp < Date.now()) {
      var url = "https://firestore.googleapis.com/v1/projects/" + encodeURIComponent(getFirebaseProjectId(env)) +
        "/databases/(default)/documents/grants/" + encodeURIComponent(user.email) + "?key=" + encodeURIComponent(getFirebaseWebKey(env));
      var r = await fetch(url, { headers: { Authorization: "Bearer " + idToken } });
      var rec = { mode: "", blocked: [] };
      if (r.ok) {
        var d = await r.json(), f = (d && d.fields) || {};
        rec.mode = (f.mode && f.mode.stringValue) || "";
        rec.blocked = ((f.blockedTools && f.blockedTools.arrayValue && f.blockedTools.arrayValue.values) || []).map(function (v) { return v.stringValue; });
      } else if (r.status !== 404) { return null; }
      c = grantCache[key] = { rec: rec, exp: Date.now() + 60000 };
    }
    if (c.rec.mode === "suspended") return "هذا الحساب موقوف من الإدارة 🚫";
    if (toolId && c.rec.blocked.indexOf(String(toolId)) !== -1) return "هذه الأداة محجوبة عن حسابك بقرار من الإدارة 🔒";
  } catch (e) {}
  return null;
}

async function verifyUser(idToken, env) {
  if (!idToken || typeof idToken !== "string" || idToken.length > 4096) return null;
  var c = tokenCache[idToken];
  if (c && c.exp > Date.now()) return c.user;
  var webKey = getFirebaseWebKey(env);
  var r = await http("https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=" + encodeURIComponent(webKey),
    { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ idToken: idToken }) }, 8000).catch(function () { return null; });
  var u = r && r.ok && r.json && r.json.users && r.json.users[0];
  if (!u) return null;
  var user = { email: String(u.email || "").toLowerCase(), verified: !!u.emailVerified };
  tokenCache[idToken] = { user: user, exp: Date.now() + 5 * 60 * 1000 };
  return user;
}

function limited(id) {
  var now = Date.now(), a = (hits[id] || []).filter(function (t) { return now - t < 60000; });
  a.push(now); hits[id] = a;
  var keys = Object.keys(hits);
  if (keys.length > 500) keys.slice(0, 250).forEach(function (k) { delete hits[k]; });
  return a.length > 15;
}

var dayHits = {};
// حد يومي لكل مستخدم (يُضبط AI_DAILY_LIMIT، الافتراضي 60؛ الإدارة معفاة). العدّاد في ذاكرة الخادم فيُعدّ حداً تقريبياً.
function dailyLimited(id, env) {
  var max = parseInt(env && env.AI_DAILY_LIMIT, 10); if (!(max > 0)) max = 100;
  var day = new Date().toISOString().slice(0, 10), r = dayHits[id];
  if (!r || r.d !== day) r = dayHits[id] = { d: day, n: 0 };
  r.n++;
  var keys = Object.keys(dayHits);
  if (keys.length > 2000) keys.slice(0, 1000).forEach(function (k) { delete dayHits[k]; });
  return r.n > max;
}

function originAllowed(origin, host, env) {
  if (!origin) return { ok: true, origin: "" };
  var allow = ((env && env.ALLOWED_ORIGINS) || "").split(",").map(function (s) { return s.trim(); }).filter(Boolean);
  allow.push("https://edutech-mindset.pages.dev");
  allow.push("https://edutech-mindset-claud.firebaseapp.com");
  if (host) allow.push("https://" + host);

  var isPagesDev = /^https:\/\/([a-zA-Z0-9\-]+\.)?edutech-mindset\.pages\.dev$/.test(origin);
  var isLocal = /^http:\/\/localhost(:\d+)?$/.test(origin) || /^http:\/\/127\.0\.0\.1(:\d+)?$/.test(origin);
  var ok = isPagesDev || isLocal || allow.indexOf(origin) >= 0;
  return { ok: ok, origin: ok ? origin : "" };
}

function jsonResponse(data, status, origin) {
  var headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store, no-cache, must-revalidate"
  };
  if (origin) {
    headers["Access-Control-Allow-Origin"] = origin;
    headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS";
    headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, x-goog-api-key";
    headers["Vary"] = "Origin";
  }
  return new Response(JSON.stringify(data), { status: status || 200, headers: headers });
}

// ---------- معالج إدارة المفاتيح /api/keys ----------
async function handleKeys(request, env) {
  var origin = request.headers.get("origin") || "";
  var host = request.headers.get("host") || "";
  var og = originAllowed(origin, host, env);

  if (request.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": og.origin || "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization, x-goog-api-key",
        "Access-Control-Max-Age": "86400"
      }
    });
  }

  await ensureKeysLoaded(env);

  if (request.method === "GET") {
    var conf = {};
    ENGINES.forEach(function (e) {
      if (e !== "free") conf[e] = !!keyOf(e, env);
    });
    return jsonResponse({ ok: true, canSave: true, cloudflare: true, engines: conf }, 200, og.origin);
  }

  if (request.method !== "POST") {
    return jsonResponse({ error: "الطريقة غير مسموحة" }, 405, og.origin);
  }

  var raw = await request.text();
  var b = {};
  try { b = JSON.parse(raw); } catch (e) { return jsonResponse({ error: "طلب غير صالح" }, 400, og.origin); }

  var action = b.action;

  if (action === "info") {
    var adminEmails = getAdminEmails(env);
    var user = await verifyUser(b.idToken, env);
    var isAdmin = !!(user && user.verified && adminEmails.indexOf(user.email) >= 0);
    return jsonResponse({ ok: true, canSave: true, cloudflare: true, isAdmin: isAdmin }, 200, og.origin);
  }

  // عمليات الحفظ والحذف تتطلب مصادقة حساب الإدارة
  var adminList = getAdminEmails(env);
  var user = await verifyUser(b.idToken, env);
  if (!user || !user.verified || adminList.indexOf(user.email) < 0) {
    return jsonResponse({ error: "هذا الإجراء متاح لحساب الإدارة المعتمد فقط 🔒" }, 403, og.origin);
  }

  var engine = String(b.engine || "").toLowerCase().trim();
  if (ENGINES.indexOf(engine) < 0 || engine === "free") {
    return jsonResponse({ error: "محرك غير صالح" }, 400, og.origin);
  }

  if (action === "save") {
    var val = String(b.value || "").trim();
    if (!val || val.length < 5) return jsonResponse({ error: "يرجى لصق مفتاح صحيح أولاً" }, 400, og.origin);

    ACTIVE_KEYS[engine] = val;

    // حفظ في KV إن وُجد
    var kv = (env && (env.AI_KEYS || env.KV || env.EDUTECH_KV));
    if (kv && typeof kv.put === "function") {
      try { await kv.put("KEY_" + engine, val); } catch (e) { console.warn("KV put error:", e); }
    }

    // حفظ مشفر في Firestore /site/ai_vault
    try {
      var currentKeys = {};
      ENGINES.forEach(function (e) {
        var k = keyOf(e, env);
        if (k && e !== "free") currentKeys[e] = k;
      });
      currentKeys[engine] = val;

      var encrypted = await encryptVault(currentKeys, getVaultSecret(env));
      var fUrl = "https://firestore.googleapis.com/v1/projects/" + encodeURIComponent(getFirebaseProjectId(env)) +
        "/databases/(default)/documents/site/ai_vault?key=" + encodeURIComponent(getFirebaseWebKey(env));
      var pRes = await fetch(fUrl, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + b.idToken
        },
        body: JSON.stringify({
          fields: {
            vault: { stringValue: encrypted.ciphertext },
            iv: { stringValue: encrypted.iv },
            updatedAt: { stringValue: new Date().toISOString() },
            updatedBy: { stringValue: user.email }
          }
        })
      });
      if (!pRes.ok) {
        console.warn("Firestore vault update warning:", pRes.status, await pRes.text());
      }
    } catch (e) {
      console.warn("Firestore vault save error:", e);
    }

    return jsonResponse({
      ok: true,
      message: "تم حفظ وتفعيل مفتاح " + (NAMES[engine] || engine) + " بنجاح ✓ يعمل الآن مباشرة لجميع الزوار."
    }, 200, og.origin);
  }

  if (action === "remove") {
    delete ACTIVE_KEYS[engine];

    var kv = (env && (env.AI_KEYS || env.KV || env.EDUTECH_KV));
    if (kv && typeof kv.delete === "function") {
      try { await kv.delete("KEY_" + engine); } catch (e) {}
    }

    try {
      var currentKeys = {};
      ENGINES.forEach(function (e) {
        var k = keyOf(e, env);
        if (k && e !== "free" && e !== engine) currentKeys[e] = k;
      });

      var encrypted = await encryptVault(currentKeys, getVaultSecret(env));
      var fUrl = "https://firestore.googleapis.com/v1/projects/" + encodeURIComponent(getFirebaseProjectId(env)) +
        "/databases/(default)/documents/site/ai_vault?key=" + encodeURIComponent(getFirebaseWebKey(env));
      await fetch(fUrl, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + b.idToken
        },
        body: JSON.stringify({
          fields: {
            vault: { stringValue: encrypted.ciphertext },
            iv: { stringValue: encrypted.iv },
            updatedAt: { stringValue: new Date().toISOString() },
            updatedBy: { stringValue: user.email }
          }
        })
      });
    } catch (e) {
      console.warn("Firestore vault remove error:", e);
    }

    return jsonResponse({
      ok: true,
      message: "تم حذف مفتاح " + (NAMES[engine] || engine) + " بنجاح ✓"
    }, 200, og.origin);
  }

  return jsonResponse({ error: "إجراء غير معروف" }, 400, og.origin);
}

// ---------- معالج الذكاء الاصطناعي /api/ai ----------
async function handleAI(request, env) {
  var origin = request.headers.get("origin") || "";
  var host = request.headers.get("host") || "";
  var og = originAllowed(origin, host, env);

  if (request.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": og.origin || "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization, x-goog-api-key",
        "Access-Control-Max-Age": "86400"
      }
    });
  }

  if (request.method !== "POST") {
    return jsonResponse({ error: "الطريقة غير مسموحة" }, 405, og.origin);
  }

  if (!og.ok) {
    return jsonResponse({ error: "مصدر الطلب غير مسموح" }, 403, og.origin);
  }

  var raw = await request.text();
  if (raw.length > MAX_BODY) {
    return jsonResponse({ error: "حجم الملفات كبير جداً (الحد الأقصى نحو 10 ميغابايت للمرفقات)" }, 413, og.origin);
  }

  var b = {};
  try { b = JSON.parse(raw); } catch (e) { return jsonResponse({ error: "طلب غير صالح" }, 400, og.origin); }

  await ensureKeysLoaded(env);

  var adminEmails = getAdminEmails(env);
  var ip = (request.headers.get("cf-connecting-ip") || request.headers.get("x-forwarded-for") || "ip").split(",")[0].trim();

  // حالة المحركات
  if (b.action === "status") {
    var st = {};
    ENGINES.forEach(function (e) {
      st[e] = {
        configured: e === "free" ? true : !!keyOf(e, env),
        vision: VISION[e],
        model: pickModels(e, null, env)[0]
      };
    });
    return jsonResponse({ engines: st, requireLogin: !!(env && env.REQUIRE_LOGIN === "true") }, 200, og.origin);
  }

  var user = await verifyUser(b.idToken, env);

  // اختبار المحركات (للإدارة فقط)
  if (b.action === "test") {
    if (!user || !user.verified || adminEmails.indexOf(user.email) < 0) {
      return jsonResponse({ error: "هذا الإجراء متاح للإدارة فقط 🔒" }, 403, og.origin);
    }
    var list = ENGINES.filter(function (e) { return (!b.engine || b.engine === e) && keyOf(e, env); });
    var out = {};
    await Promise.all(list.map(async function (e) {
      var t0 = Date.now();
      try {
        var r = await runEngine(e, { prompt: "قل كلمة واحدة فقط: تم", files: [], system: "أجب بإيجاز." }, b.models, Date.now() + 40000, env);
        out[e] = { ok: true, ms: Date.now() - t0, model: r.model, text: r.text.slice(0, 30) };
      } catch (er) {
        out[e] = { ok: false, ms: Date.now() - t0, error: cleanMsg(er.message, env) };
      }
    }));
    ENGINES.forEach(function (e) {
      if (!out[e] && (!b.engine || b.engine === e)) {
        out[e] = { ok: false, error: "لا يوجد مفتاح مدخل للمحرك (أضف المفتاح من حقل " + (NAMES[e] || e) + " واضغط حفظ)" };
      }
    });
    return jsonResponse({ results: out }, 200, og.origin);
  }

  // محادثة الذكاء الاصطناعي
  if (b.action !== "chat") {
    return jsonResponse({ error: "إجراء غير معروف" }, 400, og.origin);
  }

  if (env && env.REQUIRE_LOGIN === "true" && !user) {
    return jsonResponse({ error: "سجّل دخولك بحساب Google لاستخدام المساعد الذكي" }, 401, og.origin);
  }

  if (limited(user ? user.email : ip)) {
    return jsonResponse({ error: "طلبات كثيرة، انتظر دقيقة ثم أعد المحاولة" }, 429, og.origin);
  }

  var blockMsg = await userGrantBlock(user, b.idToken, b.tool, env);
  if (blockMsg) return jsonResponse({ error: blockMsg }, 403, og.origin);

  var isAdminUser = !!(user && user.verified && adminEmails.indexOf(user.email) !== -1);
  if (!isAdminUser && dailyLimited(user ? user.email : ip, env)) {
    return jsonResponse({ error: "بلغت الحد اليومي لاستخدام الذكاء الاصطناعي، جرّب غداً" }, 429, og.origin);
  }

  var prompt = String(b.prompt || "").slice(0, 60000);
  if (!prompt.trim()) return jsonResponse({ error: "الطلب فارغ" }, 400, og.origin);

  var files = (Array.isArray(b.files) ? b.files : []).slice(0, 12).filter(function (f) {
    return f && typeof f.data === "string" && /^[A-Za-z0-9+\/=]+$/.test(f.data) &&
      (/^image\/(jpeg|png|webp|gif)$/.test(f.mime) || f.mime === "application/pdf");
  }).map(function (f) { return { mime: f.mime, data: f.data, name: String(f.name || "").slice(0, 80) }; });

  var order = (Array.isArray(b.order) ? b.order : []).filter(function (e, i, a) { return ENGINES.indexOf(e) >= 0 && a.indexOf(e) === i; });
  if (!order.length) order = ENGINES.slice();

  var totalBudget = +(env && env.AI_TIMEOUT_MS) || 50000;
  var deadline = Date.now() + totalBudget, attempts = [], p = { prompt: prompt, files: files, system: SYSTEM };

  for (var i = 0; i < order.length; i++) {
    var e = order[i];
    if (!keyOf(e, env)) { attempts.push({ engine: e, error: "لا يوجد مفتاح" }); continue; }
    if (files.length && !VISION[e]) { attempts.push({ engine: e, error: "لا يدعم الصور وPDF" }); continue; }
    if (deadline - Date.now() < 3000) { attempts.push({ engine: e, error: "انتهى الوقت" }); break; }
    try {
      var r = await runEngine(e, p, b.models, deadline, env);
      return jsonResponse({ text: r.text, engine: e, model: r.model, attempts: attempts }, 200, og.origin);
    } catch (er) {
      attempts.push({ engine: e, error: cleanMsg(er.message, env) });
    }
  }

  var real = attempts.filter(function (a) { return !/لا يوجد مفتاح|لا يدعم/.test(a.error); });
  var msg = real.length ? real.map(function (a) { return (NAMES[a.engine] || a.engine) + ": " + a.error; }).join(" | ")
    : (files.length ? "معالجة الصور وPDF تتطلب تفعيل مفتاح Gemini أو OpenAI أو Claude في لوحة المحركات الذكية" : "لا يوجد أي مفتاح ذكاء اصطناعي مُفعّل؛ أضف مفتاح Gemini أو أحد المحركات من لوحة الإدارة");

  return jsonResponse({ error: msg, attempts: attempts }, 502, og.origin);
}


// ---------- الوسائط (صوت / فيديو / صور) على Cloudflare R2 ----------
// الربط: Workers & Pages ← المشروع ← Settings ← Bindings ← R2 bucket ← اسم المتغير: MEDIA
var MEDIA_TYPES = {
  audio: { max: 60 * 1024 * 1024, mimes: { "audio/mpeg": "mp3", "audio/mp3": "mp3", "audio/mp4": "m4a", "audio/x-m4a": "m4a", "audio/aac": "aac", "audio/ogg": "ogg", "audio/wav": "wav", "audio/x-wav": "wav", "audio/webm": "weba" } },
  video: { max: 95 * 1024 * 1024, mimes: { "video/mp4": "mp4", "video/webm": "webm", "video/quicktime": "mov" } },
  images: { max: 8 * 1024 * 1024, mimes: { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif" } },
  docs: { max: 40 * 1024 * 1024, mimes: { "application/pdf": "pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx", "application/vnd.openxmlformats-officedocument.presentationml.presentation": "pptx" } }
};

function mediaCors(request, env) {
  var og = originAllowed(request.headers.get("origin") || "", request.headers.get("host") || "", env);
  var h = {};
  if (og.origin) {
    h["Access-Control-Allow-Origin"] = og.origin;
    h["Access-Control-Allow-Methods"] = "GET, POST, DELETE, OPTIONS";
    h["Access-Control-Allow-Headers"] = "Content-Type, Authorization, Range";
    h["Access-Control-Expose-Headers"] = "Content-Length, Content-Range, Accept-Ranges";
    h["Vary"] = "Origin";
  }
  return { ok: og.ok, headers: h, origin: og.origin };
}

async function mediaAdmin(request, env) {
  var auth = request.headers.get("authorization") || "";
  var m = /^Bearer\s+(.+)$/i.exec(auth);
  var user = m ? await verifyUser(m[1], env) : null;
  return !!(user && user.verified && getAdminEmails(env).indexOf(user.email) !== -1);
}

async function handleMedia(request, env, url) {
  var cors = mediaCors(request, env);
  function J(data, status) { return jsonResponse(data, status, cors.origin); }
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors.headers });

  if (url.pathname === "/api/media-status") return J({ ready: !!(env && env.MEDIA && typeof env.MEDIA.put === "function") }, 200);
  if (!env || !env.MEDIA) return J({ error: "تخزين R2 غير مربوط بعد (أضف Binding باسم MEDIA)" }, 503);

  // رفع ملف: POST /api/media-upload?kind=audio|video|images&name=...
  if (url.pathname === "/api/media-upload") {
    if (request.method !== "POST") return J({ error: "method" }, 405);
    if (!cors.ok) return J({ error: "origin" }, 403);
    if (!(await mediaAdmin(request, env))) return J({ error: "للإدارة فقط — سجّل الدخول بحساب الإدارة" }, 403);
    var kind = url.searchParams.get("kind") || "";
    var spec = MEDIA_TYPES[kind];
    if (!spec) return J({ error: "نوع غير مدعوم" }, 400);
    var ctype = (request.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
    var ext = spec.mimes[ctype];
    if (!ext) return J({ error: "صيغة الملف غير مدعومة (" + (ctype || "؟") + ")" }, 415);
    var len = parseInt(request.headers.get("content-length") || "0", 10);
    if (!len) return J({ error: "حجم الملف غير معروف" }, 411);
    if (len > spec.max) return J({ error: "الملف أكبر من الحد المسموح (" + Math.round(spec.max / 1048576) + " ميغابايت)" }, 413);
    var key = kind + "/" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8) + "." + ext;
    try {
      await env.MEDIA.put(key, request.body, { httpMetadata: { contentType: ctype } });
    } catch (e) { return J({ error: "تعذر حفظ الملف: " + cleanMsg(e && e.message, env) }, 500); }
    return J({ ok: true, key: key, url: "/api/media/" + key, size: len }, 200);
  }

  // قراءة / حذف: /api/media/<kind>/<file>
  if (url.pathname.indexOf("/api/media/") === 0) {
    var k = decodeURIComponent(url.pathname.slice("/api/media/".length));
    if (!/^(audio|video|images|docs)\/[a-z0-9\-]+\.[a-z0-9]+$/.test(k)) return J({ error: "bad key" }, 400);
    if (request.method === "DELETE") {
      if (!cors.ok) return J({ error: "origin" }, 403);
      if (!(await mediaAdmin(request, env))) return J({ error: "للإدارة فقط" }, 403);
      await env.MEDIA.delete(k);
      return J({ ok: true }, 200);
    }
    if (request.method !== "GET" && request.method !== "HEAD") return J({ error: "method" }, 405);
    var rangeHdr = request.headers.get("range");
    var obj = await env.MEDIA.get(k, rangeHdr ? { range: request.headers } : undefined);
    if (!obj) return new Response("Not found", { status: 404, headers: cors.headers });
    var h = new Headers(cors.headers);
    if (obj.writeHttpMetadata) obj.writeHttpMetadata(h);
    h.set("etag", obj.httpEtag || obj.etag || "");
    h.set("Accept-Ranges", "bytes");
    h.set("Cache-Control", "public, max-age=31536000, immutable");
    h.set("X-Content-Type-Options", "nosniff");
    var status = 200;
    if (rangeHdr && obj.range) {
      var off = obj.range.offset || 0, ln = obj.range.length != null ? obj.range.length : obj.size - off;
      h.set("Content-Range", "bytes " + off + "-" + (off + ln - 1) + "/" + obj.size);
      h.set("Content-Length", String(ln));
      status = 206;
    } else h.set("Content-Length", String(obj.size));
    return new Response(request.method === "HEAD" ? null : obj.body, { status: status, headers: h });
  }
  return J({ error: "not found" }, 404);
}


// ---------- منظومة الأصوات العصبية متعددة الشخصيات (Neural Multi-Character TTS) /api/tts ----------
// تدعم:
// 1) أصوات Microsoft Edge Neural الطبيعية (ذكور وإناث وأطفال وشخصيات عربية فصحى وإنجليزية) عبر WebSocket Sec-MS-GEC
// 2) أصوات OpenAI Alloy/Onyx/Nova/Shimmer/Echo/Fable و Google Cloud Neural2/WaveNet (إن توفرت المفاتيح في الخزينة)
// 3) البديل السحابي السريع لضمان العمل 100% تحت أي ظرف

var EDGE_TRUSTED_TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4";

var VOICE_CATALOG = {
  // --- أصوات الطلبة والأطفال الفصحى الأصيلة (طلاب وطالبات بلهجة فصحى واضحة ومحببة) ---
  "ar_student_male":   { edge: "ar-SA-HamedNeural",   gcloud: "ar-XA-Wavenet-B", openai: "echo",    tl: "ar", pitch: "+18Hz", rate: "+4%" },
  "ar_student_female": { edge: "ar-EG-SalmaNeural",   gcloud: "ar-XA-Wavenet-A", openai: "nova",    tl: "ar", pitch: "+14Hz", rate: "+2%" },
  "ar_child_boy":      { edge: "ar-JO-TaimNeural",    gcloud: "ar-XA-Standard-B",openai: "alloy",   tl: "ar", pitch: "+28Hz", rate: "+0%" },
  "ar_child_girl":     { edge: "ar-SY-AmanyNeural",   gcloud: "ar-XA-Wavenet-D", openai: "shimmer", tl: "ar", pitch: "+24Hz", rate: "-2%" },

  // --- شخصيات عربية فصحى أصيلة (ذكور وإناث) ---
  "ar_hamed":   { edge: "ar-SA-HamedNeural",   gcloud: "ar-XA-Wavenet-B", openai: "onyx",    tl: "ar", pitch: "+0Hz",  rate: "+0%" },
  "ar_zariyah": { edge: "ar-SA-ZariyahNeural", gcloud: "ar-XA-Wavenet-A", openai: "nova",    tl: "ar", pitch: "+0Hz",  rate: "+0%" },
  "ar_shakir":  { edge: "ar-EG-ShakirNeural",  gcloud: "ar-XA-Wavenet-C", openai: "echo",    tl: "ar", pitch: "-2Hz",  rate: "-4%" },
  "ar_salma":   { edge: "ar-EG-SalmaNeural",   gcloud: "ar-XA-Wavenet-D", openai: "shimmer", tl: "ar", pitch: "+2Hz",  rate: "+0%" },
  "ar_taim":    { edge: "ar-JO-TaimNeural",    gcloud: "ar-XA-Standard-B",openai: "fable",   tl: "ar", pitch: "+0Hz",  rate: "+0%" },
  "ar_sana":    { edge: "ar-JO-SanaNeural",    gcloud: "ar-XA-Standard-A",openai: "alloy",   tl: "ar", pitch: "+4Hz",  rate: "-3%" },
  "ar_amjad":   { edge: "ar-SY-AmjadNeural",   gcloud: "ar-XA-Wavenet-B", openai: "onyx",    tl: "ar", pitch: "-3Hz",  rate: "-8%" },
  "ar_amany":   { edge: "ar-SY-AmanyNeural",   gcloud: "ar-XA-Wavenet-A", openai: "nova",    tl: "ar", pitch: "+6Hz",  rate: "-6%" },
  "ar_fahed":   { edge: "ar-KW-FahedNeural",   gcloud: "ar-XA-Wavenet-C", openai: "echo",    tl: "ar", pitch: "+0Hz",  rate: "+8%" },
  "ar_fatima":  { edge: "ar-AE-FatimaNeural",  gcloud: "ar-XA-Wavenet-D", openai: "shimmer", tl: "ar", pitch: "+2Hz",  rate: "+2%" },

  // --- شخصيات اللغة الإنجليزية (US / UK / AU / Kids) ---
  "en_andrew":  { edge: "en-US-AndrewNeural",  gcloud: "en-US-Neural2-D", openai: "onyx",    tl: "en-US", pitch: "+0Hz", rate: "+0%" },
  "en_aria":    { edge: "en-US-AriaNeural",    gcloud: "en-US-Neural2-F", openai: "nova",    tl: "en-US", pitch: "+0Hz", rate: "+0%" },
  "en_ryan":    { edge: "en-GB-RyanNeural",    gcloud: "en-GB-Neural2-B", openai: "fable",   tl: "en-GB", pitch: "+0Hz", rate: "+0%" },
  "en_sonia":   { edge: "en-GB-SoniaNeural",   gcloud: "en-GB-Neural2-A", openai: "shimmer", tl: "en-GB", pitch: "+0Hz", rate: "+0%" },
  "en_ana":     { edge: "en-US-AnaNeural",     gcloud: "en-US-Neural2-G", openai: "alloy",   tl: "en-US", pitch: "+4Hz", rate: "-6%" },
  "en_guy":     { edge: "en-US-GuyNeural",     gcloud: "en-US-Neural2-J", openai: "echo",    tl: "en-US", pitch: "-2Hz", rate: "-4%" },
  "en_natasha": { edge: "en-AU-NatashaNeural", gcloud: "en-AU-Neural2-A", openai: "nova",    tl: "en-AU", pitch: "+0Hz", rate: "+0%" },
  "en_william": { edge: "en-AU-WilliamNeural", gcloud: "en-AU-Neural2-B", openai: "onyx",    tl: "en-AU", pitch: "+0Hz", rate: "+0%" }
};

function escapeXml(unsafe) {
  return String(unsafe || "").replace(/[<>&'"]/g, function (c) {
    switch (c) {
      case "<": return "&lt;";
      case ">": return "&gt;";
      case "&": return "&amp;";
      case "'": return "&apos;";
      case '"': return "&quot;";
    }
    return c;
  });
}

async function generateSecMsGec() {
  var ticks = Math.floor(Date.now() / 1000) + 11644473600;
  ticks -= ticks % 300;
  var strToHash = (ticks * 10000000).toFixed(0) + EDGE_TRUSTED_TOKEN;
  var data = new TextEncoder().encode(strToHash);
  var hashBuf = await crypto.subtle.digest("SHA-256", data);
  var hashArr = Array.from(new Uint8Array(hashBuf));
  return hashArr.map(function (b) { return b.toString(16).padStart(2, "0").toUpperCase(); }).join("");
}

function randomHex(bytesLen) {
  var arr = crypto.getRandomValues(new Uint8Array(bytesLen));
  return Array.from(arr).map(function (b) { return b.toString(16).padStart(2, "0"); }).join("");
}

async function synthesizeEdgeNeural(text, edgeVoice, ratePct, pitchHz) {
  var secMsGec = await generateSecMsGec();
  var connId = randomHex(16);
  var wsUrl = "https://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1?TrustedClientToken=" +
    EDGE_TRUSTED_TOKEN + "&Sec-MS-GEC=" + secMsGec + "&Sec-MS-GEC-Version=1-130.0.2849.68&ConnectionId=" + connId;

  var resp = await fetch(wsUrl, {
    headers: {
      "Upgrade": "websocket",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0",
      "Origin": "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold"
    }
  });

  var ws = resp.webSocket;
  if (!ws) throw new Error("No WebSocket support");
  ws.accept();

  return new Promise(function (resolve, reject) {
    var audioChunks = [];
    var timer = setTimeout(function () {
      try { ws.close(); } catch (e) {}
      reject(new Error("Edge TTS timeout"));
    }, 6500);

    ws.addEventListener("message", function (ev) {
      if (typeof ev.data === "string") {
        if (ev.data.indexOf("Path:turn.end") !== -1) {
          clearTimeout(timer);
          try { ws.close(); } catch (e) {}
          var totalLen = audioChunks.reduce(function (a, b) { return a + b.byteLength; }, 0);
          if (totalLen === 0) {
            reject(new Error("Empty audio"));
            return;
          }
          var merged = new Uint8Array(totalLen);
          var offset = 0;
          audioChunks.forEach(function (chunk) {
            merged.set(new Uint8Array(chunk), offset);
            offset += chunk.byteLength;
          });
          resolve(merged.buffer);
        }
      } else if (ev.data instanceof ArrayBuffer) {
        var view = new DataView(ev.data);
        var headerLen = view.getUint16(0, false);
        if (ev.data.byteLength > headerLen + 2) {
          var hdrText = new TextDecoder().decode(new Uint8Array(ev.data, 2, headerLen));
          if (hdrText.indexOf("Path:audio") !== -1) {
            audioChunks.push(ev.data.slice(2 + headerLen));
          }
        }
      }
    });

    ws.addEventListener("error", function (err) {
      clearTimeout(timer);
      reject(err);
    });

    var configMsg = "X-Timestamp:" + new Date().toISOString() + "\r\n" +
      "Content-Type:application/json; charset=utf-8\r\n" +
      "Path:speech.config\r\n\r\n" +
      JSON.stringify({
        context: {
          synthesis: {
            audio: {
              metadataoptions: { sentenceBoundaryEnabled: "false", wordBoundaryEnabled: "false" },
              outputFormat: "audio-24khz-48kbitrate-mono-mp3"
            }
          }
        }
      });
    ws.send(configMsg);

    var reqId = randomHex(16);
    var langCode = edgeVoice.split("-").slice(0, 2).join("-");
    var ssml = "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='" + langCode + "'>" +
      "<voice name='" + edgeVoice + "'>" +
      "<prosody pitch='" + (pitchHz || "+0Hz") + "' rate='" + (ratePct || "+0%") + "' volume='+0%'>" +
      escapeXml(text) +
      "</prosody></voice></speak>";

    var ssmlMsg = "X-RequestId:" + reqId + "\r\n" +
      "Content-Type:application/ssml+xml\r\n" +
      "X-Timestamp:" + new Date().toISOString() + "Z\r\n" +
      "Path:ssml\r\n\r\n" + ssml;
    ws.send(ssmlMsg);
  });
}

async function synthesizeOpenAITTS(text, oaVoice, speedNum, apiKey) {
  var res = await fetch("https://api.openai.com/v1/audio/speech", {
    method: "POST",
    headers: {
      "Authorization": "Bearer " + apiKey,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "tts-1",
      input: text,
      voice: oaVoice || "onyx",
      speed: Math.max(0.5, Math.min(1.75, speedNum || 1.0)),
      response_format: "mp3"
    })
  });
  if (!res.ok) throw new Error("OpenAI TTS failed");
  return await res.arrayBuffer();
}

async function handleTTS(request, env, url) {
  var origin = request.headers.get("origin") || "";
  var host = request.headers.get("host") || "";
  var og = originAllowed(origin, host, env);
  var corsHeaders = {
    "Access-Control-Allow-Origin": og.origin || "*",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Range",
    "Cache-Control": "public, max-age=86400"
  };

  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  var q = (url.searchParams.get("q") || "").trim().slice(0, 380);
  var voiceId = (url.searchParams.get("voice") || "ar_student_male").trim();
  var tl = (url.searchParams.get("tl") || "ar").trim();
  var userRate = parseFloat(url.searchParams.get("rate") || "1");
  if (isNaN(userRate) || userRate < 0.5 || userRate > 1.8) userRate = 1.0;

  if (!q) {
    return new Response("Missing text", { status: 400, headers: corsHeaders });
  }

  var spec = VOICE_CATALOG[voiceId] || (tl.indexOf("en") === 0 ? VOICE_CATALOG["en_andrew"] : VOICE_CATALOG["ar_student_male"]);
  var deltaPct = Math.round((userRate - 1.0) * 100);
  var baseRateNum = parseInt(spec.rate || "0", 10) || 0;
  var totalRatePct = (baseRateNum + deltaPct >= 0 ? "+" : "") + (baseRateNum + deltaPct) + "%";

  // 1) المحاولة الأولى: محرك Microsoft Edge Neural الأصلي (أصوات عربية فصحى وإنجليزية بشرية متعددة الشخصيات)
  try {
    var audioBuf = await synthesizeEdgeNeural(q, spec.edge, totalRatePct, spec.pitch);
    if (audioBuf && audioBuf.byteLength > 200) {
      var h1 = new Headers(corsHeaders);
      h1.set("Content-Type", "audio/mpeg");
      h1.set("X-Voice-Engine", "Edge-Neural-" + spec.edge);
      return new Response(audioBuf, { status: 200, headers: h1 });
    }
  } catch (eEdge) {
    // ننتقل للمحرك الاحتياطي التالي
  }

  // 2) المحاولة الثانية: محرك OpenAI Neural TTS (إن وُجد مفتاح OpenAI في الخزينة)
  try {
    await ensureKeysLoaded(env, false);
    var oaKey = keyOf("openai", env);
    if (oaKey) {
      var oaBuf = await synthesizeOpenAITTS(q, spec.openai, userRate, oaKey);
      if (oaBuf && oaBuf.byteLength > 200) {
        var h2 = new Headers(corsHeaders);
        h2.set("Content-Type", "audio/mpeg");
        h2.set("X-Voice-Engine", "OpenAI-Neural-" + spec.openai);
        return new Response(oaBuf, { status: 200, headers: h2 });
      }
    }
  } catch (eOa) {}

  // 3) المحاولة الثالثة (الاحتياطي المضمون): Google Translate Cloud TTS
  var fallbackText = q.slice(0, 200);
  var ttsUrls = [
    "https://translate.googleapis.com/translate_tts?ie=UTF-8&client=gtx&tl=" + encodeURIComponent(spec.tl || tl) + "&q=" + encodeURIComponent(fallbackText),
    "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=" + encodeURIComponent(spec.tl || tl) + "&q=" + encodeURIComponent(fallbackText)
  ];

  for (var i = 0; i < ttsUrls.length; i++) {
    try {
      var res = await fetch(ttsUrls[i], {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
          "Referer": "https://translate.google.com/"
        }
      });
      if (res && res.ok && res.body) {
        var h3 = new Headers(corsHeaders);
        h3.set("Content-Type", res.headers.get("Content-Type") || "audio/mpeg");
        h3.set("X-Voice-Engine", "Google-Cloud-Fallback");
        return new Response(res.body, { status: 200, headers: h3 });
      }
    } catch (e) {}
  }

  return new Response("TTS unavailable", { status: 502, headers: corsHeaders });
}

// ---------- نقطة الدخول الرئيسية لـ Cloudflare Pages Advanced Mode ----------
export default {
  async fetch(request, env, ctx) {
    var url = new URL(request.url);

    if (url.pathname === "/api/health") {
      var ogH = originAllowed(request.headers.get("origin") || "", request.headers.get("host") || "", env);
      return jsonResponse({ ok: true, version: "v153-sovereign", worker: true, r2: !!(env && env.MEDIA), kv: !!(env && (env.AI_KEYS || env.KV || env.EDUTECH_KV)), timestamp: new Date().toISOString() }, 200, ogH.origin);
    }

    if (url.pathname === "/api/tts") {
      return handleTTS(request, env, url);
    }

    if (url.pathname === "/api/ai" || url.pathname === "/.netlify/functions/ai") {
      return handleAI(request, env);
    }

    if (url.pathname === "/api/keys" || url.pathname === "/.netlify/functions/keys") {
      return handleKeys(request, env);
    }

    if (url.pathname === "/api/media-status" || url.pathname === "/api/media-upload" || url.pathname.indexOf("/api/media/") === 0) {
      return handleMedia(request, env, url);
    }

    // تقديم الملفات الثابتة عبر Cloudflare Pages Assets
    // مجلد التوثيق الداخلي غير متاح للزوار
    try { var __p = new URL(request.url).pathname; if (__p === "/docs" || __p.indexOf("/docs/") === 0) return new Response("Not found", { status: 404 }); } catch (e) {}
    return env.ASSETS.fetch(request);
  }
};

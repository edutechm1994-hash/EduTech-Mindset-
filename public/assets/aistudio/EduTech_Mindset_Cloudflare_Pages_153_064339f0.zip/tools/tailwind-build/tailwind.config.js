/* مستخرج من index.html — نفس إعدادات الموقع الحالية */
module.exports = {
      darkMode: "class",
  content: ["../../index.html", "../../js/**/*.js", "../../privacy.html"],
      theme: {
        extend: {
          colors: {
            brand: {
              50: "var(--brand-50, #f0f7ff)",
              100: "var(--brand-100, #e0effe)",
              200: "var(--brand-200, #bae0fd)",
              300: "var(--brand-300, #7dd3fc)",
              400: "var(--brand-400, #38bdf8)",
              500: "var(--brand-500, #0284c7)",
              600: "var(--brand-600, #0369a1)",
              700: "var(--brand-700, #075985)",
              800: "var(--brand-800, #0c4a6e)",
              900: "var(--brand-900, #082f49)",
              dark: "var(--brand-dark, #051322)",
              card: "var(--brand-card, #0b2138)"
            },
            accent: {
              cyan: "#00d2ff",
              gold: "#f59e0b",
              emerald: "#10b981",
              rose: "#f43f5e"
            }
          },
          fontFamily: {
            cairo: ["Cairo", "system-ui", "sans-serif"]
          }
        }
      }
    };

/*
 * ملف الإنجاز المهني للمعلم والزيارات الإشرافية والخطط العلاجية/الإثرائية — EduTech Mindset (الإصدار 51)
 * يضم 3 أدوات مهنية وإدارية للمعلم والمشرف التربوي ومدير المدرسة:
 * 1) 📁 باني ملف الإنجاز المهني للمعلم (Teacher E-Portfolio A4 PDF) مع سحب إحصاءات إنتاج المعلم الرقمي تلقائياً.
 * 2) 🩹 مولّد الخطط العلاجية (للطلاب الضعاف) والخطط الإثرائية (للطلبة الموهوبين) بالذكاء الاصطناعي مع طباعة PDF.
 * 3) 📋 استمارة الزيارة الصفية وتبادل الزيارات الإشرافية + صائغ الكتب والمراسلات المدرسية الرسمية.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var cloud = function () { return !!(window.Cloud && window.Cloud.enabled && window.Cloud.col); };
  var uid = function () { return window.Cloud && window.Cloud.getStudioUser ? window.Cloud.getStudioUser().uid : (window.Cloud && window.Cloud.user ? window.Cloud.user.uid : "local_workspace"); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var st = {
    tab: "portfolio", // portfolio | plans | letters
    name: "",
    school: "",
    subject: "",
    qual: "بكالوريوس تربية وتكنولوجيا تعليم",
    expYears: "8 سنوات",
    vision: "توظيف التكنولوجيا الحديثة والذكاء الاصطناعي لبناء بيئة صفية تفاعلية محفزة تراعي الفروق الفردية وتصنع الأمل بالعلم.",
    achievements: "إعداد بنوك أسئلة تفاعلية وأوراق عمل علاجية\nتطبيق استراتيجيات التعلم النشط والألعاب التربوية\nمتابعة التحصيل الدراسي للطلاب عبر الفصول الافتراضية",
    counts: { ws: 0, slides: 0, lp: 0, games: 0, exams: 0 },
    planKind: "remedial", // remedial | enrichment
    planSubject: "",
    planGrade: "السابع",
    planWeakness: "ضعف في مهارات القراءة الجهرية / العمليات الحسابية الأساسية",
    planOut: "",
    letterKind: "كتاب شكر وتقدير لمعلم متميز",
    letterTarget: "",
    letterOut: ""
  };

  function pullTeacherStats() {
    try {
      var h = JSON.parse(localStorage.getItem("ws_hdr") || "{}");
      if (h.teacher && !st.name) st.name = h.teacher;
      if (h.school && !st.school) st.school = h.school;
    } catch (x) {}
    if (!cloud() || !uid()) return;
    Promise.all([
      window.Cloud.col("worksheets").where("ownerUid", "==", uid()).get(),
      window.Cloud.col("presentations").where("ownerUid", "==", uid()).get(),
      window.Cloud.col("lessonplans").where("ownerUid", "==", uid()).get(),
      window.Cloud.col("games").where("ownerUid", "==", uid()).get(),
      window.Cloud.col("exams").where("ownerUid", "==", uid()).get()
    ]).then(function (r) {
      st.counts = {
        ws: r[0].size || 0,
        slides: r[1].size || 0,
        lp: r[2].size || 0,
        games: r[3].size || 0,
        exams: r[4].size || 0
      };
      if (st.tab === "portfolio") paint();
    }).catch(function () {});
  }

  function printPortfolioPdf() {
    st.name = $("pfName").value.trim() || "اسم المعلم/ـة";
    st.school = $("pfSchool").value.trim() || "المدرسة";
    st.subject = $("pfSubj").value.trim() || "التخصص";
    st.qual = $("pfQual").value.trim();
    st.expYears = $("pfExp").value.trim();
    st.vision = $("pfVision").value.trim();
    st.achievements = $("pfAch").value.trim();
    var dt = new Date().toLocaleDateString("ar-EG", { year: "numeric", month: "long", day: "numeric" });

    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>ملف الإنجاز المهني — ' + e(st.name) + '</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:14mm}*{box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a;line-height:1.85}h1{text-align:center;color:#0369a1;font-size:26px;margin:0 0 4px}.sub{text-align:center;color:#475569;font-weight:700;margin-bottom:16px}.card{border:2px solid #cbd5e1;border-radius:14px;padding:14px 18px;margin-bottom:14px;background:#f8fafc}.card h3{margin:0 0 8px;color:#047857;border-bottom:1px solid #cbd5e1;padding-bottom:4px}.grid4{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;text-align:center;margin:12px 0}.stat{border:1.5px solid #0284c7;border-radius:12px;padding:10px;background:#f0f9ff}.stat b{display:block;font-size:22px;color:#0369a1}</style></head><body>' +
      '<h1>📁 ملف الإنجاز المهني للمعلم (E-Portfolio)</h1>' +
      '<div class="sub">منصة EduTech Mindset | عقلية التعليم والتكنولوجيا • تاريخ الإصدار: ' + dt + '</div>' +
      '<div class="card"><h3>👤 السيرة المهنية والبيانات الأساسية</h3>' +
      '<div><b>اسم المعلم/ـة:</b> ' + e(st.name) + ' &nbsp;|&nbsp; <b>المدرسة:</b> ' + e(st.school) + '</div>' +
      '<div><b>المبحث / التخصص:</b> ' + e(st.subject) + ' &nbsp;|&nbsp; <b>المؤهل العلمي:</b> ' + e(st.qual) + ' &nbsp;|&nbsp; <b>سنوات الخبرة:</b> ' + e(st.expYears) + '</div></div>' +
      '<div class="card"><h3>💡 الرؤية والرسالة التربوية</h3><div>' + e(st.vision) + '</div></div>' +
      '<div class="card"><h3>📊 حصاد الإنتاج التعليمي الرقمي على المنصة</h3>' +
      '<div class="grid4"><div class="stat">أوراق العمل<b>' + st.counts.ws + '</b></div><div class="stat">الاختبارات المنشورة<b>' + st.counts.exams + '</b></div><div class="stat">العروض التفاعلية<b>' + st.counts.slides + '</b></div><div class="stat">الخطط والألعاب<b>' + (st.counts.lp + st.counts.games) + '</b></div></div></div>' +
      '<div class="card"><h3>🏆 أبرز الإنجازات والمبادرات التربوية</h3><ul>' +
      st.achievements.split("\n").filter(Boolean).map(function (l) { return '<li>' + e(l) + '</li>'; }).join("") + '</ul></div>' +
      '<div style="display:flex;justify-content:space-between;margin-top:28px;font-weight:800"><span>توقيع المعلم/ـة: ........................</span><span>اعتماد مدير/ة المدرسة: ........................</span><span>المشرف التربوي: ........................</span></div>' +
      '</body></html>';
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
  }

  function printTextDocPdf(title, content) {
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>' + e(title) + '</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:15mm}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a;line-height:1.9;font-size:14px}h1{text-align:center;color:#0369a1;border-bottom:2px solid #cbd5e1;padding-bottom:8px}.box{white-space:pre-line}</style></head><body>' +
      '<h1>' + e(title) + '</h1><div class="box">' + e(content) + '</div></body></html>';
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
  }

  function paint() {
    var box = $("pfBody"); if (!box) return;
    var tabs = [
      ["portfolio", "📁 ملف الإنجاز المهني للمعلم (E-Portfolio)"],
      ["plans", "🩹 الخطط العلاجية والإثرائية بالـ AI"],
      ["letters", "✉️ صائغ الكتب والمراسلات المدرسية الرسمية"]
    ];
    var nav = '<div class="flex flex-wrap gap-2 mb-4 border-b border-slate-200 dark:border-slate-700 pb-3">' +
      tabs.map(function (t) {
        var on = st.tab === t[0];
        return '<button type="button" data-pftab="' + t[0] + '" class="px-4 py-2 rounded-xl text-xs font-extrabold transition-all ' + (on ? "bg-indigo-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">' + t[1] + '</button>';
      }).join("") + '</div>';

    var body = "";
    if (st.tab === "portfolio") {
      body = '<div class="space-y-3">' +
        '<div class="grid grid-cols-1 sm:grid-cols-3 gap-2.5">' +
        '<div><label class="block text-[11px] font-bold mb-1">اسم المعلم/ـة</label><input id="pfName" value="' + e(st.name) + '" placeholder="الأستاذ/ة …" class="' + cls + '"></div>' +
        '<div><label class="block text-[11px] font-bold mb-1">المدرسة</label><input id="pfSchool" value="' + e(st.school) + '" placeholder="اسم المدرسة" class="' + cls + '"></div>' +
        '<div><label class="block text-[11px] font-bold mb-1">المبحث / التخصص</label><input id="pfSubj" value="' + e(st.subject) + '" placeholder="مثال: العلوم / الرياضيات" class="' + cls + '"></div>' +
        '</div>' +
        '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">' +
        '<div><label class="block text-[11px] font-bold mb-1">المؤهل العلمي</label><input id="pfQual" value="' + e(st.qual) + '" class="' + cls + '"></div>' +
        '<div><label class="block text-[11px] font-bold mb-1">سنوات الخبرة / الدرجة</label><input id="pfExp" value="' + e(st.expYears) + '" class="' + cls + '"></div>' +
        '</div>' +
        '<div><div class="flex justify-between mb-1"><label class="text-[11px] font-bold">الرؤية والرسالة التربوية للمعلم</label><button type="button" id="pfAiVision" class="text-[10px] font-extrabold text-brand-600">✨ صياغة بالذكاء الاصطناعي</button></div>' +
        '<textarea id="pfVision" rows="2" class="' + cls + '">' + e(st.vision) + '</textarea></div>' +
        '<div><label class="block text-[11px] font-bold mb-1">أبرز الإنجازات والمبادرات والدورات (كل إنجاز في سطر)</label>' +
        '<textarea id="pfAch" rows="3" class="' + cls + '">' + e(st.achievements) + '</textarea></div>' +
        '<div class="flex flex-wrap gap-2 pt-1">' +
        '<button type="button" id="pfPrintBtn" class="px-6 py-2.5 rounded-xl bg-gradient-to-l from-indigo-600 to-blue-700 text-white text-xs font-black shadow">🖨 طباعة / حفظ ملف الإنجاز المهني الكامل PDF</button>' +
        '</div></div>';
    } else if (st.tab === "plans") {
      body = '<div class="space-y-3">' +
        '<div class="grid grid-cols-1 sm:grid-cols-3 gap-2.5">' +
        '<div><label class="block text-xs font-bold mb-1">نوع الخطة</label><select id="pfPlanKind" class="' + cls + '"><option value="remedial"' + (st.planKind === "remedial" ? " selected" : "") + '>🩹 خطة علاجية للطلاب ذوي التحصيل المنخفض</option><option value="enrichment"' + (st.planKind === "enrichment" ? " selected" : "") + '>🌟 خطة إثرائية للطلاب المتفوقين والموهوبين</option></select></div>' +
        '<div><label class="block text-xs font-bold mb-1">المادة الدراسية</label><input id="pfPlanSubj" value="' + e(st.planSubject) + '" placeholder="مثال: اللغة العربية / الرياضيات" class="' + cls + '"></div>' +
        '<div><label class="block text-xs font-bold mb-1">الصف</label><input id="pfPlanGrade" value="' + e(st.planGrade) + '" class="' + cls + '"></div>' +
        '</div>' +
        '<div><label class="block text-xs font-bold mb-1">مظاهر الضعف أو مجال الإثراء المستهدف</label><input id="pfPlanWeak" value="' + e(st.planWeakness) + '" class="' + cls + '"></div>' +
        '<div class="flex flex-wrap gap-2">' +
        '<button type="button" id="pfGenPlan" class="px-6 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black shadow">🤖 ابنِ الخطة الكاملة بالذكاء الاصطناعي</button>' +
        (st.planOut ? '<button type="button" id="pfPrintPlan" class="px-5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-black">🖨 طباعة الخطة PDF</button>' : '') +
        '</div>' +
        (st.planOut ? '<div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs leading-loose whitespace-pre-line font-semibold">' + e(st.planOut) + '</div>' : '') +
        '</div>';
    } else if (st.tab === "letters") {
      var KINDS = [
        "كتاب شكر وتقدير لمعلم متميز",
        "دعوة رسمية لاجتماع مجلس أولياء الأمور",
        "تقرير إداري عن تنفيذ نشاط أو مبادرة مدرسية",
        "تقرير زيارة صفية إشرافية وتبادل زيارات بين المعلمين",
        "خطاب تهنئة للطلبة المتفوقين وأسرهم"
      ];
      body = '<div class="space-y-3">' +
        '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">' +
        '<div><label class="block text-xs font-bold mb-1">نوع الكتاب أو التقرير الرسمي</label><select id="pfLetKind" class="' + cls + '">' + KINDS.map(function (k) { return '<option' + (st.letterKind === k ? " selected" : "") + '>' + k + '</option>'; }).join("") + '</select></div>' +
        '<div><label class="block text-xs font-bold mb-1">الاسم المستهدف أو تفاصيل المناسبة</label><input id="pfLetTarget" value="' + e(st.letterTarget) + '" placeholder="مثال: الأستاذ أحمد محمد — بمناسبة تميزه في توظيف التكنولوجيا" class="' + cls + '"></div>' +
        '</div>' +
        '<div class="flex flex-wrap gap-2">' +
        '<button type="button" id="pfGenLet" class="px-6 py-2.5 rounded-xl bg-brand-600 text-white text-xs font-black shadow">🤖 صياغة الكتاب الرسمي بالذكاء الاصطناعي</button>' +
        (st.letterOut ? '<button type="button" id="pfPrintLet" class="px-5 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black">🖨 طباعة الكتاب الرسمي PDF</button>' : '') +
        '</div>' +
        (st.letterOut ? '<div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs leading-loose whitespace-pre-line font-semibold">' + e(st.letterOut) + '</div>' : '') +
        '</div>';
    }

    box.innerHTML = nav + body;
    box.querySelectorAll("[data-pftab]").forEach(function (b) {
      b.onclick = function () { st.tab = b.dataset.pftab; paint(); };
    });

    if (st.tab === "portfolio") {
      $("pfPrintBtn").onclick = printPortfolioPdf;
      $("pfAiVision").onclick = function () {
        var sb = $("pfSubj").value.trim() || "التعليم";
        var btn = $("pfAiVision"); btn.disabled = true; btn.textContent = "⏳ يصوغ…";
        window.AI.ask("اكتب رؤية ورسالة تربوية ملهمة وموجزة (3 جمل) لمعلم في فلسطين يدرّس مادة «" + sb + "» لوضعها في ملف إنجازه المهني. أعد النص فقط.", [], "studio").then(function (t) {
          st.vision = String(t || "").trim();
          $("pfVision").value = st.vision;
        }).finally(function () { btn.disabled = false; btn.textContent = "✨ صياغة بالذكاء الاصطناعي"; });
      };
    } else if (st.tab === "plans") {
      $("pfGenPlan").onclick = function () {
        st.planKind = $("pfPlanKind").value;
        st.planSubject = $("pfPlanSubj").value.trim() || "المادة";
        st.planGrade = $("pfPlanGrade").value.trim() || "السابع";
        st.planWeakness = $("pfPlanWeak").value.trim();
        var b = $("pfGenPlan"); b.disabled = true; b.textContent = "⏳ يبني الخطة…";
        var label = st.planKind === "remedial" ? "خطة علاجية للطلاب ذوي التحصيل المنخفض" : "خطة إثرائية للطلاب المتفوقين والموهوبين";
        var p = "أنت مشرف تربوي خبير في فلسطين. أعدّ «" + label + "» متكاملة ومنظمة لمادة " + st.planSubject + " للصف " + st.planGrade + " حول: «" + st.planWeakness + "»، تتضمن: الأهداف، الإجراءات والأنشطة المقترحة، الوسائل، الإطار الزمني، وأساليب التقويم ومؤشرات النجاح.";
        window.AI.ask(p, [], "studio").then(function (txt) { st.planOut = txt; paint(); }).catch(function () { b.disabled = false; b.textContent = "🤖 ابنِ الخطة الكاملة بالذكاء الاصطناعي"; });
      };
      if ($("pfPrintPlan")) $("pfPrintPlan").onclick = function () {
        printTextDocPdf((st.planKind === "remedial" ? "خطة علاجية — " : "خطة إثرائية — ") + st.planSubject, st.planOut);
      };
    } else if (st.tab === "letters") {
      $("pfGenLet").onclick = function () {
        st.letterKind = $("pfLetKind").value;
        st.letterTarget = $("pfLetTarget").value.trim();
        var b = $("pfGenLet"); b.disabled = true; b.textContent = "⏳ يصوغ الكتاب…";
        var p = "اكتب نص «" + st.letterKind + "» بلغة عربية فصحى رسمية رصينة ومؤثرة للمدارس الفلسطينية" + (st.letterTarget ? "، التفاصيل: " + st.letterTarget : "") + "، جاهزاً للطباعة والتوقيع.";
        window.AI.ask(p, [], "studio").then(function (txt) { st.letterOut = txt; paint(); }).catch(function () { b.disabled = false; b.textContent = "🤖 صياغة الكتاب الرسمي بالذكاء الاصطناعي"; });
      };
      if ($("pfPrintLet")) $("pfPrintLet").onclick = function () {
        printTextDocPdf(st.letterKind, st.letterOut);
      };
    }
  }

  function build() {
    if ($("portfolioStudio")) return true;
    var anchor = $("teacherDash") || $("certStudio") || $("lessonPlanStudio");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "portfolioStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-indigo-800 via-slate-800 to-slate-950 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1">📁 ملف الإنجاز المهني للمعلم والخطط العلاجية والمراسلات الرسمية</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">أصدر ملف إنجازك المهني (E-Portfolio) وابنِ الخطط العلاجية والإثرائية والكتب الرسمية</h2>' +
      '<p class="text-xs text-white/80 mt-1">أدوات توثيق وإشراف تربوي جاهزة للطباعة الفورية بحجم A4 للمعلمين ومديري المدارس والمشرفين.</p>' +
      '</div><div class="p-4 sm:p-6 text-right" id="pfBody"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    paint();
    setTimeout(pullTeacherStats, 1800);
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  function openWithRemedial(opts) {
    opts = opts || {};
    st.tab = "plans";
    st.planKind = opts.kind || "remedial";
    if (opts.subject) st.planSubject = opts.subject;
    if (opts.grade) st.planGrade = opts.grade;
    if (opts.weakness) st.planWeakness = opts.weakness;
    paint();
    if (window.EduMasterHierarchy && window.EduMasterHierarchy.navigateToTarget) {
      window.EduMasterHierarchy.navigateToTarget("portfolioStudio");
    } else {
      var sc = $("portfolioStudio");
      if (sc) { sc.style.display = ""; sc.scrollIntoView({ behavior: "smooth", block: "start" }); }
    }
    toast("تم استيراد بيانات الضعف والطلاب المتعثرين إلى مولّد الخطط العلاجية ✓", "success");
    if (opts.autoGenerate && $("pfGenPlan")) {
      setTimeout(function () { if ($("pfGenPlan")) $("pfGenPlan").click(); }, 400);
    }
  }

  window.EduPortfolio = {
    open: function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("portfolioStudio", true); },
    openWithRemedial: openWithRemedial
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

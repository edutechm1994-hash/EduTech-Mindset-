/*
 * الآلة الحاسبة العلمية، راسم الدوال البياني، حلّال المعادلات (التربيعية ونظام 2×2)، وموسوعة القوانين — EduTech Mindset (الإصدار 52)
 * تعمل محلياً 100% بلا إنترنت:
 * 1) 🧮 آلة حاسبة علمية متكاملة (جيب، جيب تمام، ظل، جذور، أسس، لوغاريتمات).
 * 2) 📊 راسم الدوال البياني التفاعلي (Interactive Canvas Function Plotter) لرسم دالتين f(x) و g(x) مع جدول قيم وتكبير/تصغير بلا إنترنت.
 * 3) 📈 حلّال المعادلات التربيعية خطوة بخطوة + حلّال نظام معادلتين خطيتين بمتغيرين (2×2 System Solver بطريقة المحددات/كرامر).
 * 4) ⚖️ محوّل الوحدات العلمية والرياضية الفوري.
 * 5) 📐 موسوعة القوانين الرياضية والفيزيائية والكيميائية المدرسية مع بحث فوري وطباعة كملخص قوانين A4 PDF.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var FORMULAS = [
    { cat: "📐 الرياضيات والهندسة", title: "نظرية فيثاغورس (المثلث القائم)", rule: "الوتر² = الضلع الأول² + الضلع الثاني²  (c² = a² + b²)" },
    { cat: "📐 الرياضيات والهندسة", title: "القانون العام لحل المعادلة التربيعية (ax² + bx + c = 0)", rule: "المميز Δ = b² - 4ac  |  الجذور: x = (-b ± √Δ) / (2a)" },
    { cat: "📐 الرياضيات والهندسة", title: "قانون المسافة ونقطة المنتصف بين نقطتين", rule: "ف = √((س₂ - س₁)² + (ص₂ - ص₁)²)  |  المنتصف = ((س₁+س₂)/2 ، (ص₁+ص₂)/2)" },
    { cat: "📐 الرياضيات والهندسة", title: "مساحة ومحيط الدائرة", rule: "المساحة = π × نق²  |  المحيط = 2 × π × نق  (حيث π ≈ 3.1416)" },
    { cat: "📐 الرياضيات والهندسة", title: "حجم الكرة والأسطوانة والمخروط", rule: "الأسطوانة = π×نق²×ع  |  المخروط = ⅓ π×نق²×ع  |  الكرة = (4/3)×π×نق³" },
    { cat: "⚡ الفيزياء والميكانيكا", title: "معادلات الحركة بتسارع ثابت", rule: "ع٢ = ع١ + ت×ز  |  ف = ع١×ز + ½ ت×ز²  |  ع٢² = ع١² + 2×ت×ف" },
    { cat: "⚡ الفيزياء والميكانيكا", title: "قانون نيوتن الثاني والوزن والزخم", rule: "القوة (ق) = ك × ت  |  الوزن = ك × جـ (جـ ≈ 9.8 م/ث²)  |  الزخم (خ) = ك × ع" },
    { cat: "⚡ الفيزياء والميكانيكا", title: "قانون أوم والقدرة والطاقة الكهربائية", rule: "الجهد (V) = I × R  |  القدرة (P) = V × I = I² × R  |  الطاقة = P × الزمن" },
    { cat: "⚡ الفيزياء والميكانيكا", title: "طاقة الحركة وطاقة الوضع الميكانيكية", rule: "طاقة الحركة = ½ × ك × ع²  |  طاقة الوضع = ك × جـ × ف" },
    { cat: "🧪 الكيمياء والعلوم", title: "عدد المولات والتركيز المولاري", rule: "عدد المولات (ن) = الكتلة (غ) ÷ الكتلة المولية  |  المولارية (M) = ن ÷ الحجم باللتر" },
    { cat: "🧪 الكيمياء والعلوم", title: "الكثافة والضغط وقانون الغاز المثالي", rule: "الكثافة = الكتلة ÷ الحجم  |  الضغط = القوة ÷ المساحة  |  P×V = n×R×T" }
  ];

  var st = {
    tab: "calc", // calc | plot | quad | sys2 | units | formulas
    expr: "",
    res: "0",
    fn1: "x^2 - 4",
    fn2: "2*x - 1",
    xMax: 10,
    qa: 1, qb: -5, qc: 6,
    sA1: 2, sB1: 1, sC1: 8,
    sA2: 1, sB2: -1, sC2: 1,
    uCat: "len",
    uVal: 1,
    fQuery: ""
  };

  function evalSci(expr) {
    try {
      var clean = String(expr || "0")
        .replace(/×/g, "*").replace(/÷/g, "/")
        .replace(/π/g, "Math.PI")
        .replace(/sin\(([^)]+)\)/g, "Math.sin(($1)*Math.PI/180)")
        .replace(/cos\(([^)]+)\)/g, "Math.cos(($1)*Math.PI/180)")
        .replace(/tan\(([^)]+)\)/g, "Math.tan(($1)*Math.PI/180)")
        .replace(/sqrt\(([^)]+)\)/g, "Math.sqrt($1)")
        .replace(/\^/g, "**");
      if (/[^0-9+\-*/().\sMathPIsincotaqrt*]/.test(clean)) return "خطأ في الصيغة";
      var val = Function('"use strict"; return (' + clean + ');')();
      return typeof val === "number" && isFinite(val) ? String(Math.round(val * 1000000) / 1000000) : "غير معرف";
    } catch (x) {
      return "خطأ في الصيغة";
    }
  }

  function evalFnAt(fnStr, xVal) {
    if (!fnStr || !String(fnStr).trim()) return NaN;
    try {
      var s = String(fnStr).toLowerCase()
        .replace(/\s+/g, "")
        .replace(/×/g, "*").replace(/÷/g, "/")
        .replace(/(\d)(x)/g, "$1*$2")
        .replace(/(x)(\d)/g, "$1*$2")
        .replace(/(\))(\()/g, "$1*$2")
        .replace(/(\d)(\()/g, "$1*$2")
        .replace(/\^/g, "**")
        .replace(/sin\(/g, "Math.sin(")
        .replace(/cos\(/g, "Math.cos(")
        .replace(/tan\(/g, "Math.tan(")
        .replace(/sqrt\(/g, "Math.sqrt(")
        .replace(/abs\(/g, "Math.abs(")
        .replace(/log\(/g, "Math.log10(")
        .replace(/ln\(/g, "Math.log(")
        .replace(/pi|π/g, "Math.PI");
      var stripped = s.replace(/Math\.(sin|cos|tan|sqrt|abs|log10|log|PI)/g, "");
      if (/[^0-9x+\-*/().\s]/.test(stripped)) return NaN;
      var f = Function("x", '"use strict"; try { return (' + s + '); } catch(e){ return NaN; }');
      var y = f(xVal);
      return (typeof y === "number" && isFinite(y)) ? y : NaN;
    } catch (e) {
      return NaN;
    }
  }

  function drawPlotCanvas() {
    var cv = $("scPlotCv");
    if (!cv) return;
    var ctx = cv.getContext("2d");
    var W = cv.width, H = cv.height;
    var range = Math.max(2, Math.min(50, +st.xMax || 10));
    var scaleX = W / (2 * range);
    var scaleY = H / (2 * range);
    var cx = W / 2, cy = H / 2;

    ctx.fillStyle = "#0f172a";
    ctx.fillRect(0, 0, W, H);

    // شبكة الإحداثيات
    ctx.lineWidth = 1;
    ctx.strokeStyle = "#1e293b";
    var step = range <= 10 ? 1 : range <= 20 ? 2 : 5;
    ctx.font = "bold 10px monospace";
    ctx.fillStyle = "#64748b";
    ctx.textAlign = "center";

    for (var gx = -range; gx <= range; gx += step) {
      var px = cx + gx * scaleX;
      ctx.beginPath(); ctx.moveTo(px, 0); ctx.lineTo(px, H); ctx.stroke();
      if (gx !== 0) ctx.fillText(String(gx), px, cy + 14);
    }
    for (var gy = -range; gy <= range; gy += step) {
      var py = cy - gy * scaleY;
      ctx.beginPath(); ctx.moveTo(0, py); ctx.lineTo(W, py); ctx.stroke();
      if (gy !== 0) ctx.fillText(String(gy), cx - 14, py + 4);
    }

    // المحوران الرئيسيان X و Y
    ctx.lineWidth = 2;
    ctx.strokeStyle = "#475569";
    ctx.beginPath(); ctx.moveTo(0, cy); ctx.lineTo(W, cy); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx, 0); ctx.lineTo(cx, H); ctx.stroke();

    function plotCurve(expr, color) {
      if (!expr || !expr.trim()) return;
      ctx.lineWidth = 2.8;
      ctx.strokeStyle = color;
      ctx.beginPath();
      var penDown = false;
      for (var px = 0; px <= W; px += 2) {
        var x = (px - cx) / scaleX;
        var y = evalFnAt(expr, x);
        if (isNaN(y) || Math.abs(y) > range * 3) {
          penDown = false;
        } else {
          var py = cy - y * scaleY;
          if (!penDown) { ctx.moveTo(px, py); penDown = true; }
          else ctx.lineTo(px, py);
        }
      }
      ctx.stroke();
    }

    plotCurve(st.fn1, "#38bdf8");
    plotCurve(st.fn2, "#f43f5e");

    // تحديث جدول القيم
    var tbl = $("scPlotTable");
    if (tbl) {
      var xs = [-3, -2, -1, 0, 1, 2, 3];
      tbl.innerHTML = '<table class="w-full text-center font-mono text-xs border-collapse">' +
        '<thead><tr class="bg-slate-800 text-slate-300"><th class="p-1.5 border border-slate-700">x</th>' +
        xs.map(function (x) { return '<th class="p-1.5 border border-slate-700">' + x + '</th>'; }).join("") + '</tr></thead><tbody>' +
        '<tr class="text-sky-400 font-bold"><td class="p-1.5 border border-slate-700">f(x)</td>' +
        xs.map(function (x) { var y = evalFnAt(st.fn1, x); return '<td class="p-1.5 border border-slate-700">' + (isNaN(y) ? "—" : Math.round(y * 100) / 100) + '</td>'; }).join("") + '</tr>' +
        (st.fn2.trim() ? '<tr class="text-rose-400 font-bold"><td class="p-1.5 border border-slate-700">g(x)</td>' +
        xs.map(function (x) { var y = evalFnAt(st.fn2, x); return '<td class="p-1.5 border border-slate-700">' + (isNaN(y) ? "—" : Math.round(y * 100) / 100) + '</td>'; }).join("") + '</tr>' : '') +
        '</tbody></table>';
    }
  }

  function solveQuadSteps(a, b, c) {
    if (a === 0) {
      if (b === 0) return "ليست معادلة (معاملات المتغير تساوي صفراً).";
      return "معادلة خطية من الدرجة الأولى:\n" + b + "x + (" + c + ") = 0\nالحل: x = " + (-c / b).toFixed(3);
    }
    var delta = b * b - 4 * a * c;
    var vx = -b / (2 * a);
    var vy = a * vx * vx + b * vx + c;
    var steps = "1) المعادلة: (" + a + ")x² + (" + b + ")x + (" + c + ") = 0\n" +
      "2) حساب المميز (Δ = b² - 4ac):\n" +
      "   Δ = (" + b + ")² - 4 × (" + a + ") × (" + c + ") = " + (b * b) + " - (" + (4 * a * c) + ") = " + delta + "\n";
    if (delta > 0) {
      var x1 = (-b + Math.sqrt(delta)) / (2 * a);
      var x2 = (-b - Math.sqrt(delta)) / (2 * a);
      steps += "3) بما أن المميز Δ > 0، للمعادلة جذران حقيقيان مختلفان:\n" +
        "   x₁ = (-b + √Δ) ÷ (2a) = " + (Math.round(x1 * 1000) / 1000) + "\n" +
        "   x₂ = (-b - √Δ) ÷ (2a) = " + (Math.round(x2 * 1000) / 1000) + "\n";
    } else if (delta === 0) {
      var x0 = -b / (2 * a);
      steps += "3) بما أن المميز Δ = 0، للمعادلة جذر حقيقي واحد مكرر:\n   x = -b ÷ (2a) = " + (Math.round(x0 * 1000) / 1000) + "\n";
    } else {
      steps += "3) بما أن المميز Δ < 0 (سالب)، لا توجد جذور حقيقية للمعادلة في مجموعة الأعداد الحقيقية (ح).\n";
    }
    steps += "4) إحداثيات رأس القطع المكافئ: (" + (Math.round(vx * 100) / 100) + " , " + (Math.round(vy * 100) / 100) + ")";
    return steps;
  }

  function solveSys2Steps(a1, b1, c1, a2, b2, c2) {
    var D = a1 * b2 - a2 * b1;
    var Dx = c1 * b2 - c2 * b1;
    var Dy = a1 * c2 - a2 * c1;
    var out = "النظام الخطي:\n" +
      "  (1)  " + a1 + "x + (" + b1 + ")y = " + c1 + "\n" +
      "  (2)  " + a2 + "x + (" + b2 + ")y = " + c2 + "\n\n" +
      "خطوات الحل بطريقة المحددات (قاعدة كرامر):\n" +
      "• محدد المعاملات Δ = (" + a1 + " × " + b2 + ") - (" + a2 + " × " + b1 + ") = " + D + "\n" +
      "• محدد المتغير الأول Δx = (" + c1 + " × " + b2 + ") - (" + c2 + " × " + b1 + ") = " + Dx + "\n" +
      "• محدد المتغير الثاني Δy = (" + a1 + " × " + c2 + ") - (" + a2 + " × " + c1 + ") = " + Dy + "\n\n";
    if (D !== 0) {
      var x = Math.round((Dx / D) * 1000) / 1000;
      var y = Math.round((Dy / D) * 1000) / 1000;
      out += "✅ النتيجة (حل وحيد للنظام — المستقيمان متقاطعان):\n" +
        "   x = Δx ÷ Δ = " + Dx + " ÷ " + D + " = " + x + "\n" +
        "   y = Δy ÷ Δ = " + Dy + " ÷ " + D + " = " + y + "\n" +
        "   نقطة التقاطع: (" + x + " , " + y + ")";
    } else if (Dx === 0 && Dy === 0) {
      out += "♾️ المحدد Δ = 0 و Δx = 0 و Δy = 0: للنظام عدد لا نهائي من الحلول (المستقيمان متطابقان).";
    } else {
      out += "⚠️ المحدد Δ = 0 بينما البسط لا يساوي صفراً: لا يوجد حل للنظام (المستقيمان متوازيان).";
    }
    return out;
  }

  function printFormulasPdf() {
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>ورقة القوانين العلمية والرياضية</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;800;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:12mm}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a}h1{text-align:center;color:#0369a1;margin:0 0 12px}.item{border:1.5px solid #cbd5e1;border-radius:12px;padding:10px 14px;margin-bottom:8px;break-inside:avoid}.cat{font-size:11px;color:#059669;font-weight:900}.ttl{font-size:14px;font-weight:900}.rl{font-size:13px;background:#f8fafc;padding:6px 10px;border-radius:8px;margin-top:4px;font-weight:700}</style></head><body>' +
      '<h1>📐 مرجع القوانين الرياضية والفيزيائية والكيميائية — EduTech Mindset</h1>' +
      FORMULAS.map(function (f) {
        return '<div class="item"><div class="cat">' + e(f.cat) + '</div><div class="ttl">' + e(f.title) + '</div><div class="rl">' + e(f.rule) + '</div></div>';
      }).join("") + '</body></html>';
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
  }

  function paint() {
    var box = $("scBody"); if (!box) return;
    var tabs = [
      ["calc", "🧮 الحاسبة العلمية"],
      ["plot", "📊 راسم الدوال البياني"],
      ["quad", "📈 المعادلة التربيعية"],
      ["sys2", "🔢 نظام معادلتين (2×2)"],
      ["units", "⚖️ محوّل الوحدات"],
      ["formulas", "📐 موسوعة القوانين (" + FORMULAS.length + ")"]
    ];
    var nav = '<div class="flex flex-wrap gap-2 mb-4 border-b border-slate-200 dark:border-slate-700 pb-3">' +
      tabs.map(function (t) {
        var on = st.tab === t[0];
        return '<button type="button" data-sctab="' + t[0] + '" class="px-3.5 py-2 rounded-xl text-xs font-extrabold transition-all ' + (on ? "bg-blue-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">' + t[1] + '</button>';
      }).join("") + '</div>';

    var body = "";
    if (st.tab === "calc") {
      var btns = [
        "sin(", "cos(", "tan(", "sqrt(", "C",
        "7", "8", "9", "÷", "^",
        "4", "5", "6", "×", "(",
        "1", "2", "3", "-", ")",
        "0", ".", "π", "+", "="
      ];
      body = '<div class="max-w-md mx-auto rounded-3xl bg-slate-900 text-white p-4 border-2 border-slate-700 shadow-xl space-y-3">' +
        '<div class="rounded-2xl bg-slate-950 p-3.5 text-left font-mono border border-slate-800">' +
        '<div id="scExprDisp" class="text-xs text-slate-400 min-h-[18px]">' + e(st.expr || "0") + '</div>' +
        '<div id="scResDisp" class="text-2xl font-black text-emerald-400 mt-1">' + e(st.res) + '</div></div>' +
        '<div class="grid grid-cols-5 gap-2" dir="ltr">' +
        btns.map(function (b) {
          var isEq = b === "=", isClr = b === "C";
          return '<button type="button" data-scbtn="' + b + '" class="py-3 rounded-xl font-mono text-sm font-black ' +
            (isEq ? "bg-emerald-600 text-white" : isClr ? "bg-rose-600 text-white" : "bg-slate-800 hover:bg-slate-700 text-slate-100") + '">' + b + '</button>';
        }).join("") + '</div></div>';
    } else if (st.tab === "plot") {
      var presets = [
        ["x^2 - 4", "2*x - 1", "قطع مكافئ ومستقيم"],
        ["sin(x)*4", "cos(x)*4", "اقتران الجيب وجيب التمام"],
        ["x^3 - 3*x", "x", "اقتران تكعيبي وخطي"],
        ["abs(x) - 3", "-x^2 + 3", "القيمة المطلقة وقطع مكافئ"]
      ];
      body = '<div class="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">' +
        '<div class="lg:col-span-5 space-y-3">' +
        '<div><label class="block text-xs font-bold mb-1 text-sky-600 dark:text-sky-400">🔵 الاقتران الأول f(x) =</label>' +
        '<input id="scFn1" dir="ltr" value="' + e(st.fn1) + '" placeholder="مثال: x^2 - 4 أو sin(x)" class="' + cls + ' font-mono !text-sm"></div>' +
        '<div><label class="block text-xs font-bold mb-1 text-rose-600 dark:text-rose-400">🔴 الاقتران الثاني g(x) = (اختياري للمقارنة والتقاطع)</label>' +
        '<input id="scFn2" dir="ltr" value="' + e(st.fn2) + '" placeholder="مثال: 2*x - 1" class="' + cls + ' font-mono !text-sm"></div>' +
        '<div class="flex items-center gap-2">' +
        '<label class="text-xs font-bold shrink-0">مدى المحاور (±):</label>' +
        '<input type="range" id="scPlotRange" min="4" max="25" value="' + st.xMax + '" class="flex-1">' +
        '<span id="scRangeVal" class="text-xs font-black font-mono">±' + st.xMax + '</span></div>' +
        '<div class="space-y-1"><div class="text-[11px] font-bold text-slate-500">أمثلة جاهزة للتمثيل الفوري:</div><div class="flex flex-wrap gap-1.5">' +
        presets.map(function (p, i) {
          return '<button type="button" data-scpre="' + i + '" class="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-blue-600 hover:text-white text-[11px] font-bold transition-all">' + p[2] + '</button>';
        }).join("") + '</div></div>' +
        '<div id="scPlotTable" class="rounded-2xl overflow-hidden border border-slate-700 bg-slate-900"></div>' +
        '</div>' +
        '<div class="lg:col-span-7 flex flex-col items-center">' +
        '<canvas id="scPlotCv" width="520" height="400" class="w-full max-w-[520px] rounded-3xl border-2 border-slate-700 shadow-xl bg-slate-950"></canvas>' +
        '<div class="text-[11px] text-slate-500 mt-1.5 font-semibold">يدعم: <code dir="ltr">x^2, sqrt(x), abs(x), sin(x), cos(x), tan(x)</code> ويعمل 100% بلا إنترنت</div>' +
        '</div></div>';
    } else if (st.tab === "quad") {
      var steps = solveQuadSteps(st.qa, st.qb, st.qc);
      body = '<div class="space-y-4">' +
        '<div class="text-xs font-bold text-slate-500">أدخل معاملات المعادلة التربيعية <span dir="ltr" class="font-mono font-black text-brand-600">a·x² + b·x + c = 0</span> لعرض خطوات الحل بالقانون العام ورأس القطع:</div>' +
        '<div class="grid grid-cols-3 gap-3 max-w-lg">' +
        '<div><label class="block text-xs font-bold mb-1">المعامل a (معامل x²)</label><input type="number" id="scQa" value="' + st.qa + '" class="' + cls + ' text-center !text-sm !font-black"></div>' +
        '<div><label class="block text-xs font-bold mb-1">المعامل b (معامل x)</label><input type="number" id="scQb" value="' + st.qb + '" class="' + cls + ' text-center !text-sm !font-black"></div>' +
        '<div><label class="block text-xs font-bold mb-1">الحد الثابت c</label><input type="number" id="scQc" value="' + st.qc + '" class="' + cls + ' text-center !text-sm !font-black"></div>' +
        '</div>' +
        '<button type="button" id="scQuadPlotBtn" class="px-4 py-2 rounded-xl bg-sky-600 text-white text-xs font-black">📊 مثّل هذه المعادلة بيانياً في راسم الدوال</button>' +
        '<div id="scQuadOut" class="p-4 rounded-2xl bg-slate-900 text-emerald-300 font-mono text-xs sm:text-sm leading-loose whitespace-pre-line border border-slate-700">' + e(steps) + '</div></div>';
    } else if (st.tab === "sys2") {
      var sysSteps = solveSys2Steps(st.sA1, st.sB1, st.sC1, st.sA2, st.sB2, st.sC2);
      body = '<div class="space-y-4">' +
        '<div class="text-xs font-bold text-slate-500">حل نظام معادلتين خطيتين بمتغيرين <span dir="ltr" class="font-mono font-black text-brand-600">a₁x + b₁y = c₁  &  a₂x + b₂y = c₂</span> خطوة بخطوة:</div>' +
        '<div class="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-2xl">' +
        '<div class="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 space-y-2">' +
        '<div class="text-xs font-black text-sky-600">المعادلة الأولى (a₁x + b₁y = c₁)</div>' +
        '<div class="grid grid-cols-3 gap-2">' +
        '<div><label class="block text-[10px] font-bold">معامل x (a₁)</label><input type="number" id="scA1" value="' + st.sA1 + '" class="' + cls + ' text-center"></div>' +
        '<div><label class="block text-[10px] font-bold">معامل y (b₁)</label><input type="number" id="scB1" value="' + st.sB1 + '" class="' + cls + ' text-center"></div>' +
        '<div><label class="block text-[10px] font-bold">الناتج (c₁)</label><input type="number" id="scC1" value="' + st.sC1 + '" class="' + cls + ' text-center"></div>' +
        '</div></div>' +
        '<div class="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 space-y-2">' +
        '<div class="text-xs font-black text-rose-600">المعادلة الثانية (a₂x + b₂y = c₂)</div>' +
        '<div class="grid grid-cols-3 gap-2">' +
        '<div><label class="block text-[10px] font-bold">معامل x (a₂)</label><input type="number" id="scA2" value="' + st.sA2 + '" class="' + cls + ' text-center"></div>' +
        '<div><label class="block text-[10px] font-bold">معامل y (b₂)</label><input type="number" id="scB2" value="' + st.sB2 + '" class="' + cls + ' text-center"></div>' +
        '<div><label class="block text-[10px] font-bold">الناتج (c₂)</label><input type="number" id="scC2" value="' + st.sC2 + '" class="' + cls + ' text-center"></div>' +
        '</div></div></div>' +
        '<div id="scSysOut" class="p-4 rounded-2xl bg-slate-900 text-amber-300 font-mono text-xs sm:text-sm leading-loose whitespace-pre-line border border-slate-700">' + e(sysSteps) + '</div></div>';
    } else if (st.tab === "units") {
      var v = +st.uVal || 0;
      body = '<div class="space-y-4">' +
        '<div class="max-w-xs"><label class="block text-xs font-bold mb-1">أدخل القيمة الرقمية للتحويل الفوري:</label>' +
        '<input type="number" id="scUVal" value="' + st.uVal + '" class="' + cls + ' !text-base !font-black"></div>' +
        '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs font-bold">' +
        '<div class="p-3.5 rounded-2xl border bg-slate-50 dark:bg-slate-800"><div class="text-brand-600 font-black mb-1">📏 الطول والمسافة</div>' +
        '<div>' + v + ' كم = <b>' + (v * 1000) + ' متر</b></div><div>' + v + ' متر = <b>' + (v * 100) + ' سم</b></div><div>' + v + ' بوصة = <b>' + (v * 2.54).toFixed(2) + ' سم</b></div></div>' +
        '<div class="p-3.5 rounded-2xl border bg-slate-50 dark:bg-slate-800"><div class="text-emerald-600 font-black mb-1">⚖️ الكتلة والوزن</div>' +
        '<div>' + v + ' كغم = <b>' + (v * 1000) + ' غرام</b></div><div>' + v + ' كغم ≈ <b>' + (v * 9.8).toFixed(1) + ' نيوتن (وزن)</b></div><div>' + v + ' طن = <b>' + (v * 1000) + ' كغم</b></div></div>' +
        '<div class="p-3.5 rounded-2xl border bg-slate-50 dark:bg-slate-800"><div class="text-amber-600 font-black mb-1">🌡️ الحرارة والسرعة</div>' +
        '<div>' + v + ' °C = <b>' + (v + 273.15).toFixed(2) + ' كلفن (K)</b></div><div>' + v + ' °C = <b>' + (v * 1.8 + 32).toFixed(1) + ' فهرنهايت (°F)</b></div><div>' + v + ' كم/س = <b>' + (v / 3.6).toFixed(2) + ' م/ث</b></div></div>' +
        '</div></div>';
    } else if (st.tab === "formulas") {
      var q = st.fQuery.trim().toLowerCase();
      var list = FORMULAS.filter(function (f) { return !q || (f.cat + " " + f.title + " " + f.rule).toLowerCase().indexOf(q) !== -1; });
      body = '<div class="space-y-3">' +
        '<div class="flex flex-wrap gap-2">' +
        '<input type="search" id="scFSearch" value="' + e(st.fQuery) + '" placeholder="🔍 ابحث عن قانون (مثال: فيثاغورس، أوم، نيوتن، دائرة، مولات…)" class="' + cls + ' flex-1">' +
        '<button type="button" id="scPrintFormulas" class="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-black">🖨 طباعة ورقة القوانين PDF</button></div>' +
        '<div class="grid grid-cols-1 md:grid-cols-2 gap-2.5">' +
        list.map(function (f) {
          return '<div class="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">' +
            '<div class="text-[10px] font-black text-emerald-600 dark:text-emerald-400">' + e(f.cat) + '</div>' +
            '<div class="text-xs font-black mt-0.5">' + e(f.title) + '</div>' +
            '<div class="mt-1.5 p-2 rounded-xl bg-slate-100 dark:bg-slate-900 font-mono text-xs font-bold text-brand-700 dark:text-brand-300">' + e(f.rule) + '</div></div>';
        }).join("") + '</div></div>';
    }

    box.innerHTML = nav + body;
    box.querySelectorAll("[data-sctab]").forEach(function (b) {
      b.onclick = function () { st.tab = b.dataset.sctab; paint(); };
    });

    if (st.tab === "calc") {
      box.querySelectorAll("[data-scbtn]").forEach(function (bt) {
        bt.onclick = function () {
          var k = bt.dataset.scbtn;
          if (k === "C") { st.expr = ""; st.res = "0"; }
          else if (k === "=") { st.res = evalSci(st.expr); }
          else { st.expr += k; }
          $("scExprDisp").textContent = st.expr || "0";
          $("scResDisp").textContent = st.res;
        };
      });
    } else if (st.tab === "plot") {
      drawPlotCanvas();
      $("scFn1").oninput = function (ev) { st.fn1 = ev.target.value; drawPlotCanvas(); };
      $("scFn2").oninput = function (ev) { st.fn2 = ev.target.value; drawPlotCanvas(); };
      $("scPlotRange").oninput = function (ev) {
        st.xMax = +ev.target.value || 10;
        if ($("scRangeVal")) $("scRangeVal").textContent = "±" + st.xMax;
        drawPlotCanvas();
      };
      var presetsList = [
        ["x^2 - 4", "2*x - 1"],
        ["sin(x)*4", "cos(x)*4"],
        ["x^3 - 3*x", "x"],
        ["abs(x) - 3", "-x^2 + 3"]
      ];
      box.querySelectorAll("[data-scpre]").forEach(function (b) {
        b.onclick = function () {
          var pr = presetsList[+b.dataset.scpre];
          if (pr) { st.fn1 = pr[0]; st.fn2 = pr[1]; paint(); }
        };
      });
    } else if (st.tab === "quad") {
      ["scQa", "scQb", "scQc"].forEach(function (id) {
        $(id).oninput = function () {
          st.qa = +$("scQa").value || 0;
          st.qb = +$("scQb").value || 0;
          st.qc = +$("scQc").value || 0;
          $("scQuadOut").textContent = solveQuadSteps(st.qa, st.qb, st.qc);
        };
      });
      if ($("scQuadPlotBtn")) $("scQuadPlotBtn").onclick = function () {
        st.fn1 = "(" + st.qa + ")*x^2 + (" + st.qb + ")*x + (" + st.qc + ")";
        st.fn2 = "0";
        st.tab = "plot";
        paint();
      };
    } else if (st.tab === "sys2") {
      ["scA1", "scB1", "scC1", "scA2", "scB2", "scC2"].forEach(function (id) {
        $(id).oninput = function () {
          st.sA1 = +$("scA1").value || 0; st.sB1 = +$("scB1").value || 0; st.sC1 = +$("scC1").value || 0;
          st.sA2 = +$("scA2").value || 0; st.sB2 = +$("scB2").value || 0; st.sC2 = +$("scC2").value || 0;
          $("scSysOut").textContent = solveSys2Steps(st.sA1, st.sB1, st.sC1, st.sA2, st.sB2, st.sC2);
        };
      });
    } else if (st.tab === "units") {
      $("scUVal").oninput = function (ev) { st.uVal = ev.target.value; paint(); $("scUVal").focus(); };
    } else if (st.tab === "formulas") {
      $("scFSearch").oninput = function (ev) { st.fQuery = ev.target.value; paint(); $("scFSearch").focus(); };
      $("scPrintFormulas").onclick = printFormulasPdf;
    }
  }

  function build() {
    if ($("sciCalcStudio")) return true;
    var anchor = $("simLabStudio") || $("tawjihiStudio") || $("learnSection");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "sciCalcStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-blue-800 via-indigo-900 to-slate-950 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1">🧮 الحاسبة العلمية، راسم الدوال البياني، وحلّال المعادلات وموسوعة القوانين (بلا إنترنت)</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">آلة حاسبة علمية، تمثيل بياني للاقترانات، حل المعادلات التربيعية ونظام (2×2)، ومرجع القوانين</h2>' +
      '<p class="text-xs text-white/85 mt-1">مختبر رياضي وفيزيائي متكامل يغني الطالب والمعلم عن البرامج الخارجية ويعمل بالكامل بلا إنترنت.</p>' +
      '</div><div class="p-4 sm:p-6 text-right" id="scBody"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    paint();
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduSciCalc = {
    open: function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("sciCalcStudio", true); },
    formulas: FORMULAS
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

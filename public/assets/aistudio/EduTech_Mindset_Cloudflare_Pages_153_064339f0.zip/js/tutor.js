/*
 * المعلم الخصوصي الذكي والبطاقات التفاعلية والخرائط الذهنية — EduTech Mindset (الإصدار 43)
 * يضم 4 أدوات استذكار ذكية للطالب والمعلم:
 * 1) محادثة المعلم السقراطي الذكي (يشرح ويحاور الطالب في الدرس مع قراءة صوتية).
 * 2) بطاقات الاستذكار القلّابة (Flashcards) مع تتبّع الإتقان.
 * 3) الخريطة الذهنية البصرية (Mind Map) مع تنزيلها كصورة PNG عالية الدقة للمراجعة بلا إنترنت.
 * 4) البودكاست/الحوار الصوتي التفاعلي للدرس (معلم وطالب يتحاوران لشرح الفكرة).
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var GRADES = ["الأول الأساسي", "الثاني الأساسي", "الثالث الأساسي", "الرابع الأساسي", "الخامس الأساسي", "السادس الأساسي", "السابع", "الثامن", "التاسع", "العاشر", "الحادي عشر", "الثاني عشر"];
  var OFFLINE_STUDY_PACKS = [
    {
      label: "🌿 البناء الضوئي والتنفس الخلوي",
      topic: "عملية البناء الضوئي والتنفس الخلوي في النبات",
      grade: "السابع",
      subject: "العلوم والحياة",
      cards: [
        { front: "ما المعادلة الكيميائية الكلية لعملية البناء الضوئي؟", back: "ثاني أكسيد الكربون + ماء + طاقة ضوئية ➔ سكر الجلوكوز + الأكسجين", hint: "تحدث في البلاستيدات الخضراء" },
        { front: "ما اسم الصبغة المسؤولة عن امتصاص الطاقة الضوئية في أوراق النبات؟", back: "صبغة الكلوروفيل (اليخضور) الموجودة في أغشية الثايلاكويد", hint: "تكسب النبات لونه الأخضر" },
        { front: "ما العلاقة بين البناء الضوئي والتنفس الخلوي؟", back: "علاقة تكاملية متعاكسة: نواتج البناء الضوئي (الجلوكوز والأكسجين) هي المواد المتفاعلة في التنفس الخلوي لإنتاج الطاقة (ATP).", hint: "تكامل الحياة" },
        { front: "من أين يدخل غاز ثاني أكسيد الكربون إلى ورقة النبات؟", back: "عبر فتحات مجهرية على سطح الورقة تُسمى الثغور (Stomata).", hint: "تكثر في البشرة السفلية" }
      ],
      mindmap: {
        root: "البناء الضوئي في النبات",
        branches: [
          { title: "المدخلات الأساسية", items: ["ضوء الشمس", "ثاني أكسيد الكربون CO2", "الماء والأملاح المعدنية"] },
          { title: "موقع الحدوث", items: ["البلاستيدات الخضراء", "صبغة الكلوروفيل", "الثغور في الأوراق"] },
          { title: "النواتج الحيوية", items: ["سكر الجلوكوز (غذاء)", "غاز الأكسجين O2 للتنفس"] },
          { title: "الأهمية البيئية", items: ["إنتاج الغذاء للكائنات", "تنقية الهواء وتجديد الأكسجين"] }
        ]
      },
      podcast: [
        { speaker: "المعلم", text: "أهلاً بك يا بطل! هل تساءلت يوماً كيف تصنع شجرة الزيتون في فلسطين غذاءها بنفسها دون أن تتحرك من مكانها؟" },
        { speaker: "الطالب", text: "نعم يا أستاذي! أعرف أنها تحتاج للماء وضوء الشمس، لكن كيف تحولها إلى غذاء؟" },
        { speaker: "المعلم", text: "أحسنت! داخل أوراقها الخضراء مصانع دقيقة تسمى البلاستيدات الخضراء تحتوي على صبغة الكلوروفيل التي تلتقط ضوء الشمس." },
        { speaker: "الطالب", text: "وماذا تفعل البلاستيدات الخضراء بهذه الطاقة الضوئية؟" },
        { speaker: "المعلم", text: "تدمج الماء القادم من الجذور مع غاز ثاني أكسيد الكربون الداخل عبر الثغور لتنتج سكر الجلوكوز وتطلق لنا غاز الأكسجين النقي!" }
      ]
    },
    {
      label: "📐 المعادلات والأسس والفيثاغورس",
      topic: "قوانين الأسس ونظرية فيثاغورس والمعادلات",
      grade: "الثامن",
      subject: "الرياضيات",
      cards: [
        { front: "ما قاعدة ضرب الأسس ذات الأساسات المتشابهة (س^م × س^ن)؟", back: "عند الضرب نجمع الأسس إذا تساوت الأساسات: س^(م + ن)", hint: "مثال: 2³ × 2² = 2⁵" },
        { front: "ما قيمة أي عدد غير صفري مرفوع للأس صفر (س^0)؟", back: "تساوي 1 دائماً (بشرط س ≠ 0).", hint: "قاعدة الأس الصفري" },
        { front: "ما نص نظرية فيثاغورس في المثلث القائم الزاوية؟", back: "مساحة المربع المنشأ على الوتر تساوي مجموع مساحتي المربعين المنشأين على الضلعين القائمين (جـ² = أ² + ب²).", hint: "المثلث الشهير: 3، 4، 5" },
        { front: "كيف نحل المعادلة الخطية 3س - 5 = 10؟", back: "ننقل (-5) للطرف الآخر فتصبح 3س = 15، ثم نقسم الطرفين على 3 فينتج س = 5.", hint: "عزل المتغير" }
      ],
      mindmap: {
        root: "قوانين الأسس والهندسة",
        branches: [
          { title: "قوانين الأسس", items: ["عند الضرب نجمع الأسس", "عند القسمة نطرح الأسس", "الأس الصفري يساوي 1"] },
          { title: "نظرية فيثاغورس", items: ["خاصة بالمثلث القائم", "الوتر² = ضلع₁² + ضلع₂²", "ثلاثيات شهيرة: (3,4,5) و (6,8,10)"] },
          { title: "حل المعادلات", items: ["المعادلة الخطية بعزل المتغير", "المعادلة التربيعية بالتحليل أو القانون العام"] },
          { title: "تطبيقات عملية", items: ["حساب المسافات والأطوال", "الهندسة والعمارة"] }
        ]
      },
      podcast: [
        { speaker: "المعلم", text: "اليوم سنكتشف سرّاً هندسياً استخدمه البناؤون منذ آلاف السنين لضبط الزوايا القائمة بدقة!" },
        { speaker: "الطالب", text: "هل تقصد نظرية فيثاغورس يا أستاذي؟" },
        { speaker: "المعلم", text: "بالضبط! إذا كان لديك مثلث قائم طولا ضلعيه القائمين 3 أمتار و4 أمتار، فكم يكون طول الوتر المقابل للزاوية القائمة؟" },
        { speaker: "الطالب", text: "نربع الضلعين ونجمعهما: 9 زائد 16 يساوي 25، وجذر الـ 25 هو 5 أمتار!" }
      ]
    },
    {
      label: "📖 النواسخ: كان وإنّ وأخواتهما",
      topic: "الأفعال الناسخة (كان وأخواتها) والحروف الناسخة (إنّ وأخواتها)",
      grade: "السادس الأساسي",
      subject: "اللغة العربية (النحو)",
      cards: [
        { front: "ما عمل (كان وأخواتها) عند دخولها على الجملة الاسمية؟", back: "ترفع المبتدأ ويسمى اسمها، وتنصب الخبر ويسمى خبرها.", hint: "أفعال ناقصة ناسخة" },
        { front: "ما عمل (إنّ وأخواتها) عند دخولها على الجملة الاسمية؟", back: "تنصب المبتدأ ويسمى اسمها، وترفع الخبر ويسمى خبرها (عكس عمل كان).", hint: "حروف ناسخة" },
        { front: "أعرب جملة: «أصبحَ الجوُّ معتدلاً».", back: "أصبحَ: فعل ماضٍ ناقص ناسخ، الجوُّ: اسم أصبح مرفوع بالضمة، معتدلاً: خبر أصبح منصوب بالفتحة.", hint: "أصبح تفيد التوقيت في الصباح" },
        { front: "ما معاني الحروف الناسخة: (إنّ، ليت، لعلّ، كأنّ)؟", back: "إنّ وأنّ: للتوكيد | كأنّ: للتشبيه | لكنّ: للاستدراك | ليت: للتمني | لعلّ: للترجي.", hint: "الحروف المشبهة بالفعل" }
      ],
      mindmap: {
        root: "النواسخ في النحو العربي",
        branches: [
          { title: "كان وأخواتها (أفعال)", items: ["كان، أصبح، أضحى، ظل، أمسى، بات، صار، ليس", "ترفع الاسم وتنصب الخبر"] },
          { title: "إنّ وأخواتها (حروف)", items: ["إنّ، أنّ، كأنّ، لكنّ، ليت، لعلّ", "تنصب الاسم وترفع الخبر"] },
          { title: "علامات النصب", items: ["الفتحة للمفرد وجمع التكسير", "الياء للمثنى وجمع المذكر السالم", "الكسرة لجمع المؤنث السالم"] },
          { title: "أنواع الخبر", items: ["خبر مفرد", "جملة اسمية أو فعلية", "شبه جملة (جار ومجرور أو ظرف)"] }
        ]
      },
      podcast: [
        { speaker: "المعلم", text: "تخيّل أن الجملة الاسمية بيت هادئ يتكون من المبتدأ والخبر وكلاهما مرفوع، فماذا يحدث لو طرق بابهما ضيف من النواسخ؟" },
        { speaker: "الطالب", text: "يتغير إعراب أحدهما! لكن كيف أميز بين عمل كان وعمل إنّ دون خلط؟" },
        { speaker: "المعلم", text: "قاعدة ذهبية: (كان) ترفع الأول وتنصب الثاني مثل: كان العلمُ نوراً، أما (إنّ) فتنصب الأول وترفع الثاني مثل: إنّ العلمَ نورٌ!" }
      ]
    }
  ];

  function loadOfflineStudyPack(idx) {
    var pk = OFFLINE_STUDY_PACKS[idx];
    if (!pk) return;
    st.topic = pk.topic;
    st.grade = pk.grade;
    st.subject = pk.subject;
    st.cards = pk.cards.slice();
    st.cardIdx = 0;
    st.cardFlipped = false;
    st.mastered = {};
    st.mindmap = pk.mindmap;
    st.podcast = pk.podcast.slice();
    if ($("tuTopic")) $("tuTopic").value = st.topic;
    if ($("tuSubject")) $("tuSubject").value = st.subject;
    if (st.tab === "chat") st.tab = "cards";
    paintWorkspace();
    toast("تم تحميل حزمة الاستذكار الجاهزة («" + pk.label + "»: بطاقات + خريطة ذهنية + بودكاست) بلا إنترنت ✓", "success");
  }

  var st = {
    tab: "chat", // chat | cards | mindmap | podcast
    topic: "",
    grade: GRADES[5],
    subject: "",
    messages: [],
    cards: [],
    cardIdx: 0,
    cardFlipped: false,
    mastered: {},
    mindmap: null,
    podcast: []
  };

  function parseJson(txt) {
    var s = String(txt || "").replace(/```json|```/gi, ""), a = s.indexOf("{"), b = s.lastIndexOf("}");
    if (a < 0 || b <= a) throw new Error("لم يُرجع الذكاء الاصطناعي بيانات صالحة، أعد المحاولة");
    return JSON.parse(s.slice(a, b + 1));
  }

  function speakText(text, rate, pitch) {
    try {
      if (!("speechSynthesis" in window)) { toast("متصفحك لا يدعم القراءة الصوتية", "warning"); return; }
      window.speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(String(text || "").replace(/[*#_`~]/g, ""));
      u.lang = "ar-SA";
      u.rate = rate || 1.0;
      u.pitch = pitch || 1.0;
      window.speechSynthesis.speak(u);
    } catch (x) {}
  }

  function readContext() {
    var tp = $("tuTopic"), gr = $("tuGrade"), sb = $("tuSubject");
    if (tp) st.topic = tp.value.trim();
    if (gr) st.grade = gr.value;
    if (sb) st.subject = sb.value.trim();
    return st.topic;
  }

  // ---------- 1. المعلم الخصوصي السقراطي ----------
  function sendChat(userText, modeHint) {
    if (!readContext() && !userText) { toast("اكتب عنوان الدرس أو سؤالك أولاً", "warning"); return; }
    var qText = userText || ("اشرح لي درس «" + st.topic + "» بطريقة مبسطة ومشوقة ثم اسألني سؤالاً واحداً لتتأكد من فهمي.");
    st.messages.push({ role: "user", text: qText });
    paintWorkspace();

    var historyTxt = st.messages.slice(-6).map(function (m) {
      return (m.role === "user" ? "الطالب: " : "المعلم الذكي: ") + m.text;
    }).join("\n");

    var prompt = "أنت «المعلم الخصوصي الذكي» في منصة EduTech Mindset في فلسطين. مهمتك مساعدة طالب في الصف " + st.grade +
      (st.subject ? " بمادة " + st.subject : "") + (st.topic ? " حول درس/موضوع: «" + st.topic + "»" : "") + ".\n" +
      (modeHint || "اشرح بأسلوب تربوي دافئ ومبسط، واستخدم الطريقة السقراطية (اختم شرحك بسؤال ذكي قصير يحفز الطالب على التفكير ولا تعطِ حلول الواجبات جاهزة دون تفكير).") +
      "\nسجل الحوار الأخير:\n" + historyTxt + "\nردّ الآن كمعلم ذكي بالعربية الواضحة:";

    var btn = $("tuChatSend"); if (btn) { btn.disabled = true; btn.textContent = "⏳ يفكر…"; }
    window.AI.ask(prompt, [], "studio").then(function (reply) {
      st.messages.push({ role: "ai", text: String(reply || "").trim() }); if (window.EduBadges && window.EduBadges.award) window.EduBadges.award("socratic_thinker", 25);
      paintWorkspace();
    }).catch(function (err) {
      toast((err && err.message) || "تعذر الاتصال بالمعلم الذكي", "warning");
      if (btn) { btn.disabled = false; btn.textContent = "إرسال"; }
    });
  }

  // ---------- 2. بطاقات الاستذكار (Flashcards) ----------
  function generateFlashcards() {
    if (!readContext()) { toast("اكتب موضوع الدرس أو الصق نصه أولاً لتوليد البطاقات", "warning"); return; }
    var btn = $("tuGenCardsBtn"); if (btn) { btn.disabled = true; btn.textContent = "⏳ جارٍ توليد البطاقات…"; }
    var prompt = "أنت خبير تربوي. أنشئ 10 بطاقات استذكار (Flashcards) شاملة لدرس: «" + st.topic + "» للصف " + st.grade + (st.subject ? " (" + st.subject + ")" : "") + ".\n" +
      "أعد JSON صالحاً فقط بلا أي شرح بهذا الشكل:\n" +
      '{"cards":[{"front":"المفهوم أو السؤال على الوجه الأمامي","back":"الشرح الوافي أو الإجابة على الوجه الخلفي","hint":"تلميح قصير للتذكر"}]}';

    window.AI.ask(prompt, [], "worksheet").then(function (txt) {
      var j = parseJson(txt);
      var cards = (j.cards || []).filter(function (c) { return c && c.front && c.back; });
      if (!cards.length) throw new Error("لم يتم توليد بطاقات صالحة");
      st.cards = cards;
      st.cardIdx = 0;
      st.cardFlipped = false;
      st.mastered = {};
      st.tab = "cards";
      if (window.EduBadges && window.EduBadges.award) window.EduBadges.award("mind_master", 40);
      paintWorkspace();
    }).catch(function (err) {
      toast((err && err.message) || "تعذر توليد البطاقات", "warning");
      if (btn) { btn.disabled = false; btn.textContent = "🗂 ولّد بطاقات الاستذكار"; }
    });
  }

  // ---------- 3. الخريطة الذهنية التفاعلية ----------
  function generateMindMap() {
    if (!readContext()) { toast("اكتب موضوع الدرس أو الصق نصه أولاً لتوليد الخريطة الذهنية", "warning"); return; }
    var btn = $("tuGenMapBtn"); if (btn) { btn.disabled = true; btn.textContent = "⏳ جارٍ رسم الخريطة الذهنية…"; }
    var prompt = "لخّص درس «" + st.topic + "» للصف " + st.grade + (st.subject ? " (" + st.subject + ")" : "") + " على شكل خريطة ذهنية منظمة من 4 إلى 6 فروع رئيسية، وتحت كل فرع من 2 إلى 4 نقاط مختصرة.\n" +
      "أعد JSON صالحاً فقط بلا أي شرح بهذا الشكل:\n" +
      '{"root":"عنوان الدرس الرئيسي","branches":[{"title":"عنوان الفرع 1","items":["نقطة فرعية 1","نقطة فرعية 2"]}]}';

    window.AI.ask(prompt, [], "worksheet").then(function (txt) {
      var j = parseJson(txt);
      if (!j || !Array.isArray(j.branches) || !j.branches.length) throw new Error("لم يتم توليد خريطة صالحة");
      st.mindmap = j;
      st.tab = "mindmap";
      if (window.EduBadges && window.EduBadges.award) window.EduBadges.award("mind_master", 50);
      paintWorkspace();
    }).catch(function (err) {
      toast((err && err.message) || "تعذر توليد الخريطة الذهنية", "warning");
      if (btn) { btn.disabled = false; btn.textContent = "🧠 ولّد الخريطة الذهنية"; }
    });
  }

  function drawMindMapCanvas(mm) {
    var cv = $("tuMapCanvas"); if (!cv || !mm) return;
    var branches = mm.branches || [];
    var W = 1200, H = Math.max(680, branches.length * 145);
    cv.width = W; cv.height = H;
    var ctx = cv.getContext("2d");
    ctx.direction = "rtl";
    // خلفية أنيقة
    var g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, "#0f172a"); g.addColorStop(1, "#1e293b");
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

    var COLORS = ["#0284c7", "#10b981", "#f59e0b", "#d946ef", "#f43f5e", "#6366f1"];
    var cx = W / 2, cy = H / 2;

    // رسم الخطوط والفروع على اليمين واليسار
    branches.forEach(function (br, idx) {
      var isRight = idx % 2 === 0;
      var row = Math.floor(idx / 2);
      var totalRows = Math.ceil(branches.length / 2);
      var by = Math.round((H / (totalRows + 1)) * (row + 1));
      var bx = isRight ? cx + 270 : cx - 270;
      var col = COLORS[idx % COLORS.length];

      // خط منحني من المركز للفرع
      ctx.strokeStyle = col; ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.bezierCurveTo(isRight ? cx + 120 : cx - 120, cy, isRight ? bx - 90 : bx + 90, by, bx, by);
      ctx.stroke();

      // صندوق الفرع
      ctx.fillStyle = col;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(bx - 120, by - 24, 240, 48, 14);
      else ctx.rect(bx - 120, by - 24, 240, 48);
      ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.font = "900 17px Cairo, Tahoma, sans-serif";
      ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.fillText(String(br.title || "").slice(0, 28), bx, by);

      // عناصر الفرع
      var items = (br.items || []).slice(0, 4);
      items.forEach(function (it, k) {
        var iy = by + (k - (items.length - 1) / 2) * 34;
        var ix = isRight ? bx + 250 : bx - 250;
        ctx.strokeStyle = "rgba(255,255,255,0.35)"; ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(isRight ? bx + 120 : bx - 120, by);
        ctx.lineTo(isRight ? ix - 110 : ix + 110, iy);
        ctx.stroke();

        ctx.fillStyle = "rgba(255,255,255,0.1)";
        ctx.beginPath();
        if (ctx.roundRect) ctx.roundRect(ix - 110, iy - 14, 220, 28, 8);
        else ctx.rect(ix - 110, iy - 14, 220, 28);
        ctx.fill();
        ctx.fillStyle = "#e2e8f0";
        ctx.font = "700 13px Cairo, Tahoma, sans-serif";
        ctx.fillText(String(it || "").slice(0, 32), ix, iy);
      });
    });

    // العقدة المركزية (عنوان الدرس)
    ctx.fillStyle = "#0284c7";
    ctx.strokeStyle = "#fde047";
    ctx.lineWidth = 5;
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(cx - 145, cy - 36, 290, 72, 22);
    else ctx.rect(cx - 145, cy - 36, 290, 72);
    ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#fff";
    ctx.font = "900 20px Cairo, Tahoma, sans-serif";
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText(String(mm.root || st.topic || "الدرس").slice(0, 30), cx, cy);
  }

  // ---------- 4. البودكاست / الحوار الصوتي للدرس ----------
  function generatePodcast() {
    if (!readContext()) { toast("اكتب موضوع الدرس أو الصق نصه أولاً لتوليد الحوار الصوتي", "warning"); return; }
    var btn = $("tuGenPodBtn"); if (btn) { btn.disabled = true; btn.textContent = "⏳ جارٍ تأليف الحوار الصوتي…"; }
    var prompt = "اكتب حواراً تعليمياً مشوقاً ومبسطاً (بودكاست صفّي قصير من 6 إلى 8 مداخلات) بين «المعلم» و«الطالب» يشرح الفكرة الأساسية لدرس: «" + st.topic + "» للصف " + st.grade + ".\n" +
      "أعد JSON صالحاً فقط بلا أي شرح بهذا الشكل:\n" +
      '{"lines":[{"speaker":"المعلم","text":"مرحباً بك يا بطل، اليوم سنكتشف معاً..."},{"speaker":"الطالب","text":"سؤال رائع يا أستاذي..."}]}';

    window.AI.ask(prompt, [], "worksheet").then(function (txt) {
      var j = parseJson(txt);
      if (!j || !Array.isArray(j.lines) || !j.lines.length) throw new Error("لم يتم توليد حوار صالح");
      st.podcast = j.lines;
      st.tab = "podcast";
      paintWorkspace();
    }).catch(function (err) {
      toast((err && err.message) || "تعذر توليد الحوار الصوتي", "warning");
      if (btn) { btn.disabled = false; btn.textContent = "🎙 ولّد حواراً صوتياً للدرس"; }
    });
  }

  function playPodcastAudio() {
    if (!("speechSynthesis" in window)) { toast("متصفحك لا يدعم القراءة الصوتية", "warning"); return; }
    window.speechSynthesis.cancel();
    var lines = (st.podcast || []).slice();
    (function nextLine() {
      var l = lines.shift();
      if (!l) return;
      var u = new SpeechSynthesisUtterance(l.text);
      u.lang = "ar-SA";
      var isTeacher = String(l.speaker).indexOf("معلم") !== -1;
      u.pitch = isTeacher ? 0.92 : 1.18;
      u.rate = 1.02;
      u.onend = function () { setTimeout(nextLine, 250); };
      window.speechSynthesis.speak(u);
    })();
  }

  // ---------- رسم مساحة العمل ----------
  function paintWorkspace() {
    var box = $("tuWorkspace"); if (!box) return;
    var tabs = [
      ["chat", "🤖 المعلم السقراطي الذكي"],
      ["cards", "🗂 بطاقات الاستذكار (" + st.cards.length + ")"],
      ["mindmap", "🧠 الخريطة الذهنية"],
      ["podcast", "🎙 بودكاست الدرس الحواري"]
    ];
    var nav = '<div class="flex flex-wrap gap-2 mb-4 border-b border-slate-200 dark:border-slate-700 pb-3">' +
      tabs.map(function (t) {
        var on = st.tab === t[0];
        return '<button type="button" data-tutab="' + t[0] + '" class="px-3.5 py-2 rounded-xl text-xs font-extrabold transition-all ' + (on ? "bg-teal-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300") + '">' + t[1] + '</button>';
      }).join("") + '</div>';

    var body = "";
    if (st.tab === "chat") {
      body = '<div class="space-y-3">' +
        '<div class="flex flex-wrap gap-1.5">' +
        '<button type="button" data-tuq="explain" class="px-3 py-1.5 rounded-xl bg-teal-500/15 text-teal-700 dark:text-teal-300 text-[11px] font-extrabold">💡 اشرح لي الدرس ببساطة</button>' +
        '<button type="button" data-tuq="socratic" class="px-3 py-1.5 rounded-xl bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 text-[11px] font-extrabold">🎯 اختبر فهمي سؤالاً بسؤال</button>' +
        '<button type="button" data-tuq="summary" class="px-3 py-1.5 rounded-xl bg-amber-500/15 text-amber-700 dark:text-amber-300 text-[11px] font-extrabold">📌 لخّص أهم النقاط والقوانين</button>' +
        (st.messages.length ? '<button type="button" id="tuClearChat" class="px-3 py-1.5 rounded-xl bg-rose-500/15 text-rose-600 text-[11px] font-bold mr-auto">مسح المحادثة</button>' : '') +
        '</div>' +
        '<div id="tuChatLog" class="rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-900/50 p-3.5 max-h-96 overflow-y-auto space-y-2.5">' +
        (st.messages.length ? st.messages.map(function (m, i) {
          var isU = m.role === "user";
          return '<div class="flex ' + (isU ? "justify-start" : "justify-end") + '">' +
            '<div class="max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed ' + (isU ? "bg-brand-600 text-white font-bold" : "bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100") + '">' +
            '<div class="text-[10px] font-black opacity-75 mb-1">' + (isU ? "أنت" : "🤖 المعلم الخصوصي الذكي") + '</div>' +
            '<div class="whitespace-pre-line">' + e(m.text) + '</div>' +
            (!isU ? '<button type="button" data-tuspeak="' + i + '" class="mt-2 px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-700 text-[10px] font-bold">🔊 استماع صوتي</button>' : '') +
            '</div></div>';
        }).join("") : '<p class="text-xs text-slate-400 text-center py-8">اضغط أحد الأزرار أعلاه أو اكتب سؤالك بالأسفل ليبدأ المعلم الخصوصي الذكي بشرح الدرس ومحاورتك.</p>') +
        '</div>' +
        '<div class="flex gap-2"><input id="tuChatInp" class="' + cls + '" placeholder="اسأل المعلم الذكي أو أجب عن سؤاله هنا…">' +
        '<button type="button" id="tuChatSend" class="px-5 py-2.5 rounded-xl bg-teal-600 text-white text-xs font-black shrink-0">إرسال</button></div></div>';
    } else if (st.tab === "cards") {
      if (!st.cards.length) {
        body = '<div class="text-center py-8"><p class="text-xs text-slate-500 mb-3">اضغط «🗂 ولّد بطاقات الاستذكار» ليحول الذكاء الاصطناعي الدرس إلى بطاقات سؤال/جواب تفاعلية.</p><button type="button" id="tuGenCardsBtn" class="px-5 py-2.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-black">🗂 ولّد بطاقات الاستذكار الآن</button></div>';
      } else {
        var c = st.cards[st.cardIdx] || st.cards[0];
        var mCount = Object.keys(st.mastered).length;
        body = '<div class="max-w-xl mx-auto space-y-3 text-center">' +
          '<div class="flex items-center justify-between text-xs font-extrabold text-slate-500">' +
          '<span>البطاقة ' + (st.cardIdx + 1) + ' من ' + st.cards.length + '</span>' +
          '<span class="text-emerald-600">✅ أتقنت: ' + mCount + ' / ' + st.cards.length + '</span></div>' +
          '<div id="tuFlipCard" class="cursor-pointer rounded-3xl p-8 min-h-[210px] flex flex-col items-center justify-center border-2 transition-all shadow-lg ' +
          (st.cardFlipped ? "bg-gradient-to-br from-emerald-700 to-teal-900 text-white border-emerald-400" : "bg-gradient-to-br from-slate-800 to-slate-900 text-white border-sky-400") + '">' +
          '<span class="text-[11px] font-black px-3 py-0.5 rounded-full bg-white/15 mb-3">' + (st.cardFlipped ? "💡 الإجابة والشرح (اضغط للقلب)" : "❓ السؤال / المفهوم (اضغط لإظهار الإجابة)") + '</span>' +
          '<div class="text-base sm:text-lg font-black leading-relaxed">' + e(st.cardFlipped ? c.back : c.front) + '</div>' +
          (!st.cardFlipped && c.hint ? '<div class="text-[11px] text-amber-300 mt-3">تلميح: ' + e(c.hint) + '</div>' : '') +
          '</div>' +
          '<div class="flex flex-wrap justify-center gap-2">' +
          '<button type="button" id="tuPrevCard" class="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold">➡ السابقة</button>' +
          '<button type="button" id="tuFlipBtn" class="px-5 py-2 rounded-xl bg-sky-600 text-white text-xs font-black">🔄 اقلب البطاقة</button>' +
          '<button type="button" id="tuMasterBtn" class="px-4 py-2 rounded-xl ' + (st.mastered[st.cardIdx] ? "bg-emerald-600 text-white" : "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300") + ' text-xs font-extrabold">' + (st.mastered[st.cardIdx] ? "✅ متقنة" : "✔ أتقنتها") + '</button>' +
          '<button type="button" id="tuNextCard" class="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold">التالية ⬅</button>' +
          '<button type="button" id="tuToReview" class="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-extrabold">🧠 أضف الكل للمراجعة الذكية</button>' +
          '</div></div>';
      }
    } else if (st.tab === "mindmap") {
      if (!st.mindmap) {
        body = '<div class="text-center py-8"><p class="text-xs text-slate-500 mb-3">اضغط «🧠 ولّد الخريطة الذهنية» لرسم خريطة مفاهيمية شاملة للدرس قابلة للتنزيل كصورة.</p><button type="button" id="tuGenMapBtn" class="px-5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-black">🧠 ولّد الخريطة الذهنية الآن</button></div>';
      } else {
        body = '<div class="space-y-3">' +
          '<div class="flex flex-wrap items-center justify-between gap-2">' +
          '<span class="text-xs font-black">🧠 الخريطة الذهنية لدرس: ' + e(st.mindmap.root || st.topic) + '</span>' +
          '<button type="button" id="tuDlMapBtn" class="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-black">⬇ تنزيل الخريطة كصورة PNG</button></div>' +
          '<div class="overflow-x-auto rounded-2xl border border-slate-300 dark:border-slate-700 bg-slate-900 p-2"><canvas id="tuMapCanvas" class="w-full h-auto rounded-xl"></canvas></div>' +
          '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">' +
          (st.mindmap.branches || []).map(function (b, idx) {
            return '<div class="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-900/40">' +
              '<div class="text-xs font-black text-brand-600 dark:text-brand-300 mb-1.5">' + (idx + 1) + '. ' + e(b.title) + '</div>' +
              '<ul class="text-[11px] space-y-1 list-disc list-inside text-slate-700 dark:text-slate-300">' +
              (b.items || []).map(function (it) { return '<li>' + e(it) + '</li>'; }).join("") + '</ul></div>';
          }).join("") + '</div></div>';
      }
    } else if (st.tab === "podcast") {
      if (!st.podcast.length) {
        body = '<div class="text-center py-8"><p class="text-xs text-slate-500 mb-3">حوّل الدرس إلى حوار صوتي ممتع بين معلم وطالب للاستماع والفهم السريع.</p><button type="button" id="tuGenPodBtn" class="px-5 py-2.5 rounded-xl bg-rose-600 text-white text-xs font-black">🎙 ولّد الحوار الصوتي الآن</button></div>';
      } else {
        body = '<div class="space-y-3">' +
          '<div class="flex flex-wrap gap-2 items-center justify-between">' +
          '<span class="text-xs font-black">🎙 الحوار التفاعلي للدرس</span>' +
          '<div class="flex gap-1.5"><button type="button" id="tuPlayPod" class="px-4 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-black">🔊 تشغيل الحوار صوتياً</button>' +
          '<button type="button" id="tuStopPod" class="px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold">⏹ إيقاف</button></div></div>' +
          '<div class="space-y-2">' + st.podcast.map(function (l) {
            var isT = String(l.speaker).indexOf("معلم") !== -1;
            return '<div class="p-3 rounded-2xl border ' + (isT ? "border-teal-300 dark:border-teal-800 bg-teal-50/50 dark:bg-teal-950/30" : "border-amber-300 dark:border-amber-800 bg-amber-50/50 dark:bg-amber-950/30") + ' text-xs">' +
              '<span class="font-black ' + (isT ? "text-teal-700 dark:text-teal-300" : "text-amber-700 dark:text-amber-300") + '">' + (isT ? "👨‍🏫 " : "🙋‍♂️ ") + e(l.speaker) + ': </span>' +
              '<span class="leading-relaxed">' + e(l.text) + '</span></div>';
          }).join("") + '</div></div>';
      }
    }

    box.innerHTML = nav + body;
    box.querySelectorAll("[data-tutab]").forEach(function (b) {
      b.onclick = function () { st.tab = b.dataset.tutab; paintWorkspace(); };
    });

    if (st.tab === "chat") {
      box.querySelectorAll("[data-tuq]").forEach(function (b) {
        b.onclick = function () {
          var k = b.dataset.tuq;
          if (!readContext()) { toast("اكتب عنوان الدرس أو الصق فقرته في الأعلى أولاً", "warning"); return; }
          if (k === "explain") sendChat("اشرح لي هذا الدرس ببساطة مع مثال عملي من واقعنا، ثم اسألني سؤالاً للتأكد من فهمي.");
          else if (k === "socratic") sendChat("اختبر فهمي لهذا الدرس خطوة بخطوة: اطرح عليّ سؤالاً واحداً وانتظر إجابتي.");
          else if (k === "summary") sendChat("لخّص لي أهم المفاهيم والقوانين والنقاط الأساسية في هذا الدرس بشكل مرتب للحفظ.");
        };
      });
      box.querySelectorAll("[data-tuspeak]").forEach(function (b) {
        b.onclick = function () {
          var m = st.messages[+b.dataset.tuspeak];
          if (m) speakText(m.text);
        };
      });
      if ($("tuClearChat")) $("tuClearChat").onclick = function () { st.messages = []; paintWorkspace(); };
      if ($("tuChatSend")) $("tuChatSend").onclick = function () {
        var v = $("tuChatInp").value.trim();
        if (v) sendChat(v);
      };
      if ($("tuChatInp")) $("tuChatInp").onkeydown = function (ev) {
        if (ev.key === "Enter") { ev.preventDefault(); var v = $("tuChatInp").value.trim(); if (v) sendChat(v); }
      };
    } else if (st.tab === "cards") {
      if ($("tuGenCardsBtn")) $("tuGenCardsBtn").onclick = generateFlashcards;
      if ($("tuFlipCard")) $("tuFlipCard").onclick = function () { st.cardFlipped = !st.cardFlipped; paintWorkspace(); };
      if ($("tuFlipBtn")) $("tuFlipBtn").onclick = function () { st.cardFlipped = !st.cardFlipped; paintWorkspace(); };
      if ($("tuPrevCard")) $("tuPrevCard").onclick = function () { st.cardIdx = (st.cardIdx - 1 + st.cards.length) % st.cards.length; st.cardFlipped = false; paintWorkspace(); };
      if ($("tuToReview")) $("tuToReview").onclick = function () {
        if (!window.EduReview || !window.EduReview.addCards) { if (typeof showToast === "function") showToast("وحدة المراجعة الذكية غير جاهزة بعد", "warning"); return; }
        var n = window.EduReview.addCards(st.topic || "المعلم الذكي", st.cards.map(function (c) { return { q: c.front, a: c.back }; }));
        if (typeof showToast === "function") showToast(n ? "أُضيفت " + n + " بطاقة إلى «المراجعة الذكية»" : "هذه البطاقات موجودة مسبقاً في المراجعة", n ? "success" : "info");
        try { window.EduReview.render(); } catch (x) {}
      };
      if ($("tuNextCard")) $("tuNextCard").onclick = function () { st.cardIdx = (st.cardIdx + 1) % st.cards.length; st.cardFlipped = false; paintWorkspace(); };
      if ($("tuMasterBtn")) $("tuMasterBtn").onclick = function () {
        if (st.mastered[st.cardIdx]) delete st.mastered[st.cardIdx];
        else st.mastered[st.cardIdx] = true;
        paintWorkspace();
      };
    } else if (st.tab === "mindmap") {
      if ($("tuGenMapBtn")) $("tuGenMapBtn").onclick = generateMindMap;
      if (st.mindmap) {
        setTimeout(function () { drawMindMapCanvas(st.mindmap); }, 60);
        if ($("tuDlMapBtn")) $("tuDlMapBtn").onclick = function () {
          var cv = $("tuMapCanvas"); if (!cv) return;
          cv.toBlob(function (b) {
            var a = document.createElement("a");
            a.href = URL.createObjectURL(b);
            a.download = "خريطة-ذهنية-" + (st.mindmap.root || "درس").slice(0, 30) + ".png";
            document.body.appendChild(a); a.click();
            setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 600);
          }, "image/png");
        };
      }
    } else if (st.tab === "podcast") {
      if ($("tuGenPodBtn")) $("tuGenPodBtn").onclick = generatePodcast;
      if ($("tuPlayPod")) $("tuPlayPod").onclick = playPodcastAudio;
      if ($("tuStopPod")) $("tuStopPod").onclick = function () { try { window.speechSynthesis.cancel(); } catch (x) {} };
    }
  }

  function openWithLesson(opts) {
    opts = opts || {};
    st.topic = opts.topic || "";
    st.grade = opts.grade || st.grade;
    st.subject = opts.subject || "";
    if ($("tuTopic")) $("tuTopic").value = st.topic;
    if ($("tuSubject")) $("tuSubject").value = st.subject;
    if ($("tuGrade") && opts.grade) {
      var g = $("tuGrade");
      for (var i = 0; i < g.options.length; i++) if (g.options[i].value === opts.grade || g.options[i].text === opts.grade) { g.value = g.options[i].value; break; }
    }
    var sec = $("tutorStudio");
    if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("tutorStudio", true); else if (sec) sec.scrollIntoView({ behavior: "smooth", block: "start" });
    if (opts.mode === "mindmap") { st.tab = "mindmap"; paintWorkspace(); generateMindMap(); }
    else if (opts.mode === "cards") { st.tab = "cards"; paintWorkspace(); generateFlashcards(); }
    else { st.tab = "chat"; paintWorkspace(); }
  }

  function build() {
    if ($("tutorStudio")) return true;
    var anchor = $("learnSection") || $("booksSection") || $("worksheetStudio");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "tutorStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-teal-700 via-cyan-800 to-slate-900 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1">🤖 المعلم الخصوصي الذكي ورفيق الاستذكار</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">اشرح درسك، ولّد خريطة ذهنية، وذاكر ببطاقات التذكر والبودكاست الصوتي</h2>' +
      '<p class="text-xs text-white/85 mt-1">اختر أي درس من كتبك أو اكتب موضوعك ليقوم المعلم الذكي بشرحه ومحاورتك وتوليد خرائط ذهنية وبطاقات قلّابة (Flashcards).</p>' +
      '</div>' +
      '<div class="p-5 sm:p-6 space-y-4 text-right">' +
      '<div class="grid grid-cols-1 sm:grid-cols-4 gap-2.5">' +
      '<div class="sm:col-span-2"><label class="block text-xs font-bold mb-1">عنوان الدرس أو فقرة من الكتاب (أو صوّر الصفحة بالكاميرا)</label><textarea id="tuTopic" rows="2" maxlength="5000" class="' + cls + '" placeholder="مثال: البناء الضوئي في النبات — أو الصق نص الدرس أو صوّر الصفحة"></textarea>' +
      '<div class="flex flex-wrap gap-1.5 mt-1.5">' +
      '<label class="px-2.5 py-1.5 rounded-xl bg-emerald-600 text-white text-[11px] font-black cursor-pointer flex items-center gap-1"><i class="fa-solid fa-camera"></i><span>تصوير صفحة بالكاميرا</span><input id="tuCamInp" type="file" accept="image/*" capture="environment" class="hidden"></label>' +
      '<label class="px-2.5 py-1.5 rounded-xl bg-sky-600 text-white text-[11px] font-black cursor-pointer flex items-center gap-1"><i class="fa-solid fa-folder-open"></i><span>رفع صورة/ملف من الجهاز</span><input id="tuFileInp" type="file" accept="image/*,application/pdf,.txt,.md" multiple class="hidden"></label>' +
      '<button type="button" id="tuMicBtn" class="px-2.5 py-1.5 rounded-xl bg-rose-600 text-white text-[11px] font-black flex items-center gap-1"><i class="fa-solid fa-microphone"></i><span>إملاء صوتي</span></button>' +
      '<button type="button" id="tuPresetBtn" class="px-2.5 py-1.5 rounded-xl bg-indigo-600 text-white text-[11px] font-black flex items-center gap-1"><i class="fa-solid fa-book-open"></i><span>من المنهاج</span></button>' +
      '</div><div id="tuCapInfo" class="text-[11px] font-bold text-emerald-600 mt-1"></div></div>' +
      '<div><label class="block text-xs font-bold mb-1">الصف</label><select id="tuGrade" class="' + cls + '">' + GRADES.map(function (g) { return '<option' + (g === st.grade ? " selected" : "") + '>' + g + '</option>'; }).join("") + '</select></div>' +
      '<div><label class="block text-xs font-bold mb-1">المادة</label><input id="tuSubject" class="' + cls + '" placeholder="علوم، رياضيات، تاريخ…"></div>' +
      '</div>' +
      '<div class="p-3 rounded-2xl bg-teal-50/70 dark:bg-slate-800/80 border border-teal-200 dark:border-slate-700 space-y-1.5">' +
      '<div class="text-[11px] font-black text-teal-800 dark:text-teal-300">⚡ حزم استذكار جاهزة فورية (بطاقات قلّابة + خريطة ذهنية + بودكاست صوتي — تعمل بلا إنترنت):</div>' +
      '<div class="flex flex-wrap gap-1.5">' +
      OFFLINE_STUDY_PACKS.map(function (pk, idx) {
        return '<button type="button" data-tupack="' + idx + '" class="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-teal-300 dark:border-slate-700 text-[11px] font-extrabold hover:bg-teal-600 hover:text-white transition-all">' + e(pk.label) + '</button>';
      }).join("") + '</div></div>' +
      '<div class="flex flex-wrap gap-2">' +
      '<button type="button" id="tuTopExplain" class="px-4 py-2 rounded-xl bg-teal-600 text-white text-xs font-black">🤖 اشرح وحاورني</button>' +
      '<button type="button" id="tuTopCards" class="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 text-xs font-black">🗂 ولّد بطاقات استذكار</button>' +
      '<button type="button" id="tuTopMap" class="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-black">🧠 ولّد خريطة ذهنية</button>' +
      '<button type="button" id="tuTopPod" class="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-black">🎙 ولّد بودكاست صوتي</button>' +
      '<button type="button" id="tuTopQuiz" class="px-4 py-2 rounded-xl bg-violet-600 text-white text-xs font-black">🎯 اختبرني في هذا الدرس</button>' +
      '<button type="button" id="tuTopWs" class="px-4 py-2 rounded-xl bg-emerald-700 text-white text-xs font-black">📝 حوّل لورقة عمل</button>' +
      '</div>' +
      '<div id="tuWorkspace" class="pt-2"></div>' +
      '</div></div></div>';

    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    paintWorkspace();
    $("tuTopExplain").onclick = function () { st.tab = "chat"; paintWorkspace(); sendChat(); };
    s.querySelectorAll("[data-tupack]").forEach(function (bt) {
      bt.onclick = function () { loadOfflineStudyPack(+bt.dataset.tupack); };
    });
    $("tuTopCards").onclick = generateFlashcards;
    $("tuTopMap").onclick = generateMindMap;
    $("tuTopPod").onclick = generatePodcast;
    if ($("tuTopQuiz")) $("tuTopQuiz").onclick = function () {
      readContext();
      if (window.EduStudy && window.EduStudy.quiz) {
        window.EduStudy.quiz();
        setTimeout(function () {
          if ($("qzT")) $("qzT").value = st.topic || "";
          if ($("qzS")) $("qzS").value = [st.subject, st.grade].filter(Boolean).join(" - ");
        }, 120);
      }
    };
    ["tuCamInp", "tuFileInp"].forEach(function (cid) {
      if ($(cid)) $(cid).onchange = function (ev) {
        if (!window.EduSourceCapture) return;
        window.EduSourceCapture.handleFiles(ev.target.files, {
          onText: function (txt) { if ($("tuTopic")) $("tuTopic").value = txt.slice(0, 4800); },
          onUpdate: function (all) {
            if ($("tuCapInfo")) $("tuCapInfo").innerHTML = "✓ تم إرفاق " + all.length + ' مصدر بالكاميرا/الجهاز — <button type="button" id="tuOcrNow" class="underline font-black">استخرج النص الآن بالـ AI</button>';
            if ($("tuOcrNow")) $("tuOcrNow").onclick = function () {
              window.EduSourceCapture.extractText({ onExtracted: function (tx) { if ($("tuTopic")) $("tuTopic").value = tx.slice(0, 4800); } });
            };
          }
        });
        ev.target.value = "";
      };
    });
    if ($("tuMicBtn")) $("tuMicBtn").onclick = function () { if (window.EduSourceCapture) window.EduSourceCapture.dictate($("tuTopic"), $("tuMicBtn")); };
    if ($("tuPresetBtn")) $("tuPresetBtn").onclick = function () {
      if (window.EduSourceCapture) window.EduSourceCapture.openPresets(function (p) {
        if ($("tuTopic")) $("tuTopic").value = p.title + "\n\n" + (p.notes || "");
        if ($("tuSubject")) $("tuSubject").value = p.subject || "";
        if ($("tuGrade") && p.grade) $("tuGrade").value = p.grade;
      });
    };
    if ($("tuTopWs")) $("tuTopWs").onclick = function () {
      readContext();
      if (window.EduBridge) window.EduBridge.openTool("worksheetStudio", { topic: st.topic, grade: st.grade, subject: st.subject });
    };
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduTutor = { open: openWithLesson };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

/* الدخول والتسجيل بالبريد وكلمة المرور (Firebase Auth) — الإصدار 149
 * يظهر فقط عندما يكون Firebase مفعّلاً فعلاً (Cloud.realAuth)؛ وإلا يبقى نظام الحساب المحلي كما هو. */
(function () {
  "use strict";
  var ID = "eduEmailAuth";
  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function toast(m, t) { try { if (typeof showToast === "function") showToast(m, t || "info"); } catch (e) {} }
  function real() { return !!(window.Cloud && window.Cloud.realAuth && typeof window.Cloud.signInEmail === "function"); }

  var ERR = {
    "auth/invalid-email": "البريد الإلكتروني غير صحيح",
    "auth/user-not-found": "لا يوجد حساب بهذا البريد",
    "auth/wrong-password": "كلمة المرور غير صحيحة",
    "auth/invalid-credential": "البريد أو كلمة المرور غير صحيحة",
    "auth/invalid-login-credentials": "البريد أو كلمة المرور غير صحيحة",
    "auth/email-already-in-use": "هذا البريد مسجّل مسبقاً — سجّل الدخول أو استخدم «نسيت كلمة المرور»",
    "auth/weak-password": "كلمة المرور ضعيفة — 8 أحرف على الأقل",
    "auth/too-many-requests": "محاولات كثيرة — انتظر قليلاً ثم أعد المحاولة",
    "auth/network-request-failed": "تعذّر الاتصال بالإنترنت",
    "auth/operation-not-allowed": "الدخول بالبريد غير مفعّل بعد في Firebase (Authentication ← Sign-in method ← Email/Password)",
    "auth/unauthorized-domain": "نطاق الموقع غير مضاف في Firebase (Authorized domains)",
    "auth/user-disabled": "هذا الحساب موقوف من الإدارة"
  };
  function msg(e) { return ERR[e && e.code] || ("تعذّر تنفيذ الطلب" + (e && e.code ? " (" + e.code + ")" : "")); }

  var CSS = "#" + ID + "{position:fixed;inset:0;z-index:2147483000;background:rgba(2,6,23,.66);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;padding:14px;font-family:Cairo,Tahoma,sans-serif;direction:rtl}" +
    "#" + ID + " .ea-box{width:100%;max-width:400px;background:#fff;color:#0f172a;border-radius:22px;padding:20px;box-shadow:0 24px 60px rgba(0,0,0,.4);max-height:92vh;overflow:auto}" +
    "html.dark #" + ID + " .ea-box{background:#0f172a;color:#f1f5f9;border:1px solid #334155}" +
    "#" + ID + " h3{margin:0 0 4px;font-size:19px;font-weight:900}#" + ID + " .ea-sub{font-size:12px;color:#64748b;margin-bottom:12px}" +
    "#" + ID + " .ea-tabs{display:flex;gap:6px;background:#f1f5f9;border-radius:12px;padding:4px;margin-bottom:12px}html.dark #" + ID + " .ea-tabs{background:#1e293b}" +
    "#" + ID + " .ea-tabs button{flex:1;border:0;background:transparent;border-radius:9px;padding:8px 6px;font:800 13px Cairo,sans-serif;color:inherit;cursor:pointer}" +
    "#" + ID + " .ea-tabs button.on{background:#0284c7;color:#fff}" +
    "#" + ID + " label{display:block;font-size:12px;font-weight:800;margin:9px 0 4px}" +
    "#" + ID + " input{width:100%;box-sizing:border-box;padding:11px 12px;border-radius:12px;border:1.5px solid #cbd5e1;background:#fff;color:#0f172a;font:600 14px Cairo,sans-serif;direction:ltr;text-align:left}" +
    "#" + ID + " input.rtl{direction:rtl;text-align:right}html.dark #" + ID + " input{background:#1e293b;border-color:#475569;color:#f1f5f9}" +
    "#" + ID + " input:focus{outline:2px solid #0284c7;border-color:#0284c7}" +
    "#" + ID + " .ea-go{width:100%;margin-top:14px;padding:12px;border:0;border-radius:14px;background:linear-gradient(135deg,#0284c7,#0c4a6e);color:#fff;font:900 15px Cairo,sans-serif;cursor:pointer}" +
    "#" + ID + " .ea-go[disabled]{opacity:.6}#" + ID + " .ea-link{background:none;border:0;color:#0284c7;font:800 12px Cairo,sans-serif;cursor:pointer;padding:6px 0;text-decoration:underline}" +
    "#" + ID + " .ea-g{width:100%;margin-top:8px;padding:10px;border-radius:14px;border:1.5px solid #cbd5e1;background:transparent;color:inherit;font:800 13px Cairo,sans-serif;cursor:pointer}" +
    "#" + ID + " .ea-msg{margin-top:10px;font-size:12px;font-weight:700;border-radius:10px;padding:8px 10px;display:none}" +
    "#" + ID + " .ea-msg.err{display:block;background:#fee2e2;color:#991b1b}#" + ID + " .ea-msg.ok{display:block;background:#dcfce7;color:#166534}" +
    "#" + ID + " .ea-x{float:left;border:0;background:#f1f5f9;border-radius:50%;width:30px;height:30px;font-size:16px;cursor:pointer}html.dark #" + ID + " .ea-x{background:#1e293b;color:#fff}" +
    ".ea-hdrbtn{display:inline-flex;align-items:center;gap:4px;padding:6px 9px;border-radius:12px;border:1px solid #cbd5e1;background:#fff;color:#0f172a;font:800 11px Cairo,sans-serif;cursor:pointer}html.dark .ea-hdrbtn{background:#1e293b;color:#fff;border-color:#475569}";

  var mode = "in";
  function close() { var o = document.getElementById(ID); if (o) o.remove(); }
  function open(m) {
    if (!real()) { toast("الدخول بالبريد يحتاج اتصال Firebase — يمكنك استخدام الحساب المحلي من بوابة الأعضاء", "info"); return false; }
    close(); mode = m || "in";
    if (!document.getElementById(ID + "Css")) { var st = document.createElement("style"); st.id = ID + "Css"; st.textContent = CSS; document.head.appendChild(st); }
    var o = document.createElement("div"); o.id = ID; o.setAttribute("role", "dialog"); o.setAttribute("aria-modal", "true");
    o.addEventListener("click", function (e) { if (e.target === o) close(); });
    document.body.appendChild(o); render(); return true;
  }
  function render() {
    var o = document.getElementById(ID); if (!o) return;
    var u = window.Cloud && window.Cloud.user;
    if (u && u.email && !u.emailVerified && mode !== "verify") mode = "verify";
    var h = '<div class="ea-box"><button class="ea-x" type="button" data-a="close" aria-label="إغلاق">×</button>';
    if (mode === "verify") {
      h += "<h3>📧 فعّل بريدك</h3><div class='ea-sub'>أرسلنا رسالة تحقق إلى <b dir='ltr'>" + esc(u && u.email) + "</b>. افتح الرابط فيها ثم اضغط «تحققت». التحقق مطلوب لتفعيل صلاحياتك من الإدارة.</div>" +
        "<button class='ea-go' data-a='checked'>✅ تحققت من بريدي</button><button class='ea-g' data-a='resend'>إعادة إرسال الرسالة</button><button class='ea-link' data-a='out'>تسجيل الخروج</button>";
    } else if (mode === "reset") {
      h += "<h3>🔑 استعادة كلمة المرور</h3><div class='ea-sub'>اكتب بريدك وسنرسل رابط تعيين كلمة مرور جديدة.</div><label>البريد الإلكتروني</label><input id='eaMail' type='email' autocomplete='email'>" +
        "<button class='ea-go' data-a='sendreset'>إرسال الرابط</button><button class='ea-link' data-a='in'>العودة لتسجيل الدخول</button>";
    } else {
      h += "<h3>" + (mode === "up" ? "إنشاء حساب جديد" : "تسجيل الدخول") + "</h3><div class='ea-sub'>EduTech Mindset • عقلية التعليم والتكنولوجيا</div>" +
        "<div class='ea-tabs'><button type='button' data-a='in' class='" + (mode === "in" ? "on" : "") + "'>دخول</button><button type='button' data-a='up' class='" + (mode === "up" ? "on" : "") + "'>حساب جديد</button></div>" +
        (mode === "up" ? "<label>الاسم</label><input id='eaName' class='rtl' autocomplete='name' maxlength='60'>" : "") +
        "<label>البريد الإلكتروني</label><input id='eaMail' type='email' autocomplete='email'><label>كلمة المرور" + (mode === "up" ? " (8 أحرف على الأقل)" : "") + "</label><input id='eaPass' type='password' autocomplete='" + (mode === "up" ? "new-password" : "current-password") + "'>" +
        "<button class='ea-go' data-a='submit'>" + (mode === "up" ? "إنشاء الحساب" : "دخول") + "</button>" +
        (mode === "in" ? "<button class='ea-link' data-a='reset'>نسيت كلمة المرور؟</button>" : "") +
        "<button class='ea-g' data-a='google'><i class='fa-brands fa-google'></i> المتابعة بحساب Google</button>";
    }
    h += "<div class='ea-msg' id='eaMsg' role='status'></div></div>";
    o.innerHTML = h;
    var f = o.querySelector("input"); if (f) setTimeout(function () { try { f.focus(); } catch (e) {} }, 50);
  }
  function say(t, ok) { var m = document.getElementById("eaMsg"); if (!m) return; m.className = "ea-msg " + (ok ? "ok" : "err"); m.textContent = t; }
  function busy(on) { var b = document.querySelector("#" + ID + " .ea-go"); if (b) b.disabled = !!on; }
  function val(id) { var e = document.getElementById(id); return e ? e.value.trim() : ""; }

  document.addEventListener("click", function (ev) {
    var b = ev.target.closest && ev.target.closest("#" + ID + " [data-a]"); if (!b) return;
    var a = b.getAttribute("data-a"), C = window.Cloud;
    if (a === "close") return close();
    if (a === "in" || a === "up" || a === "reset") { mode = a; return render(); }
    if (a === "out") { C.signOut().then(function () { mode = "in"; render(); }); return; }
    if (a === "google") { close(); C.signIn(false).catch(function () {}); return; }
    if (a === "resend") { C.resendVerification().then(function () { say("أُعيد إرسال رسالة التحقق ✓", true); }, function (e) { say(msg(e)); }); return; }
    if (a === "checked") { busy(true); C.refreshUser().then(function (u) { busy(false); if (u && u.emailVerified) { toast("تم تفعيل بريدك ✓", "success"); close(); } else say("لم يتم التحقق بعد — افتح الرابط في بريدك أولاً"); }, function (e) { busy(false); say(msg(e)); }); return; }
    if (a === "submit") {
      var mail = val("eaMail"), pass = (document.getElementById("eaPass") || {}).value || "";
      if (!/^\S+@\S+\.\S+$/.test(mail)) return say("اكتب بريداً إلكترونياً صحيحاً");
      if (mode === "up") {
        if (pass.length < 8) return say("كلمة المرور 8 أحرف على الأقل");
        busy(true);
        C.signUpEmail(mail, pass, val("eaName")).then(function () { busy(false); mode = "verify"; render(); say("تم إنشاء الحساب — أرسلنا رسالة تحقق إلى بريدك ✓", true); }, function (e) { busy(false); say(msg(e)); });
      } else {
        if (!pass) return say("اكتب كلمة المرور");
        busy(true);
        C.signInEmail(mail, pass).then(function (c) { busy(false); if (c && c.user && !c.user.emailVerified) { mode = "verify"; render(); } else { close(); toast("مرحباً بك 👋", "success"); } }, function (e) { busy(false); say(msg(e)); });
      }
    }
  });
  // زر «إرسال الرابط» لوضع الاستعادة
  document.addEventListener("click", function (ev) {
    var b = ev.target.closest && ev.target.closest("#" + ID + " [data-a='sendreset']"); if (!b) return;
    var mail = val("eaMail"); if (!/^\S+@\S+\.\S+$/.test(mail)) return say("اكتب بريدك أولاً");
    busy(true); window.Cloud.resetPassword(mail).then(function () { busy(false); say("أرسلنا رابط الاستعادة إلى بريدك ✓", true); }, function (e) { busy(false); say(msg(e)); });
  });
  document.addEventListener("keydown", function (e) {
    if (!document.getElementById(ID)) return;
    if (e.key === "Escape") close();
    if (e.key === "Enter" && e.target && e.target.tagName === "INPUT") { var g = document.querySelector("#" + ID + " .ea-go"); if (g) g.click(); }
  });

  // اعتراض أزرار الترحيب (تسجيل الدخول / حساب جديد) عندما يكون Firebase فعّالاً
  document.addEventListener("click", function (ev) {
    if (!real()) return;
    var t = ev.target.closest && ev.target.closest("#wlLogin,#wlRegister"); if (!t) return;
    ev.preventDefault(); ev.stopPropagation(); ev.stopImmediatePropagation();
    var w = document.getElementById("welcomeOverlay"); if (w) w.remove();
    open(t.id === "wlRegister" ? "up" : "in");
  }, true);

  // زر «بالبريد» بجانب زر الدخول في الرأس
  function addHeaderBtn() {
    if (!real() || document.getElementById("eaHdrBtn")) return;
    var g = document.getElementById("btnGoogleLoginHeader"); if (!g || !g.parentNode) return;
    var b = document.createElement("button"); b.type = "button"; b.id = "eaHdrBtn"; b.className = "ea-hdrbtn"; b.title = "الدخول أو التسجيل بالبريد";
    b.innerHTML = "<i class='fa-solid fa-envelope'></i><span>بالبريد</span>";
    if (!document.getElementById(ID + "Css")) { var st = document.createElement("style"); st.id = ID + "Css"; st.textContent = CSS; document.head.appendChild(st); }
    b.addEventListener("click", function () { open("in"); });
    g.parentNode.insertBefore(b, g.nextSibling);
  }
  var tries = 0, iv = setInterval(function () { addHeaderBtn(); if (document.getElementById("eaHdrBtn") || ++tries > 40) clearInterval(iv); }, 500);

  // تذكير بالتحقق من البريد بعد الدخول
  if (window.Cloud && Cloud.statusListeners) { /* لا شيء: يتولى app.js إدارة الجلسة */ }
  window.EduEmailAuth = { open: open, close: close };
})();

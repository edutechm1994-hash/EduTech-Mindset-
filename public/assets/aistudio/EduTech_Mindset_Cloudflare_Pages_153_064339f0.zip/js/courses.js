/* courses.js: قسم الدورات التدريبية (يُدار من لوحة الإدارة، ويُحفظ في site/courses) */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var CACHE = "edu_courses_cache", data = { wa: "972597663828", items: [] };
  var inp = "w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-xs font-bold";
  var canEdit = function () { return typeof isSuperAdminUser === "function" && isSuperAdminUser(); };
  var cloud = function () { return !!(window.Cloud && window.Cloud.enabled); };
  var uid = function () { return "c" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); };
  function safeUrl(u) { u = String(u || "").trim(); return /^https?:\/\//i.test(u) ? u : ""; }

  function ensure() {
    var s = $("coursesSection"); if (s) return s;
    var anchor = $("social") || $("about"); if (!anchor) return null;
    s = document.createElement("section"); s.id = "coursesSection"; s.className = "py-12 scroll-mt-20 hidden";
    anchor.parentNode.insertBefore(s, anchor); return s;
  }
  function render() {
    var s = ensure(); if (!s) return;
    var now = new Date().toISOString().slice(0, 10);
    var list = (data.items || []).filter(function (x) { return x.on !== false && x.title; });
    if (!list.length) { s.classList.add("hidden"); return; }
    s.classList.remove("hidden");
    s.innerHTML = '<div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8"><div class="text-right mb-5"><div class="text-xs font-extrabold text-brand-600">🎓 التدريب والتطوير المهني</div><h2 class="text-2xl font-black text-slate-900 dark:text-white">الدورات التدريبية</h2></div>' +
      '<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">' + list.map(function (c) {
        var past = c.date && c.date < now, msg = encodeURIComponent("السلام عليكم، أرغب بالتسجيل في دورة: " + c.title);
        var link = safeUrl(c.link) || ("https://wa.me/" + String(data.wa || "").replace(/\D/g, "") + "?text=" + msg);
        return '<article class="rounded-3xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/90 shadow-lg p-5 text-right flex flex-col gap-2' + (past ? " opacity-70" : "") + '">' +
          '<div class="flex items-center justify-between gap-2"><span class="text-3xl">' + esc(c.icon || "🎓") + "</span>" + (past ? '<span class="text-[11px] font-black px-2 py-0.5 rounded-full bg-slate-200 text-slate-600">انتهت</span>' : '<span class="text-[11px] font-black px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">التسجيل مفتوح</span>') + "</div>" +
          '<h3 class="text-base font-black leading-snug">' + esc(c.title) + "</h3>" + (c.desc ? '<p class="text-xs font-semibold text-slate-600 dark:text-slate-300 leading-6">' + esc(c.desc) + "</p>" : "") +
          '<ul class="text-xs font-bold text-slate-500 dark:text-slate-400 space-y-0.5">' + (c.date ? "<li>📅 " + esc(c.date) + "</li>" : "") + (c.hours ? "<li>⏱ " + esc(c.hours) + "</li>" : "") + (c.place ? "<li>📍 " + esc(c.place) + "</li>" : "") + (c.price ? "<li>💳 " + esc(c.price) + "</li>" : "") + "</ul>" +
          (past ? "" : '<a href="' + esc(link) + '" target="_blank" rel="noopener" class="mt-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 text-white font-black text-sm">سجّل الآن عبر واتساب</a>') + "</article>";
      }).join("") + "</div></div>";
  }
  function apply(d) { if (d) data = { wa: d.wa || data.wa, items: Array.isArray(d.items) ? d.items : [] }; render(); }

  function tab(H) {
    var d = JSON.parse(JSON.stringify(data)), mini = "px-2 py-1 rounded-lg bg-slate-200 dark:bg-slate-700 text-[11px] font-bold";
    function row(c, n) {
      return '<div class="rounded-2xl border border-slate-200 dark:border-slate-700 p-2.5 space-y-2 bg-slate-50/50 dark:bg-slate-800/40" data-i="' + n + '">' +
        '<div class="flex gap-2"><input data-f="icon" class="' + inp + ' !w-14 text-center" value="' + esc(c.icon || "🎓") + '"><input data-f="title" class="' + inp + '" placeholder="عنوان الدورة *" value="' + esc(c.title) + '"></div>' +
        '<textarea data-f="desc" rows="2" class="' + inp + '" placeholder="وصف مختصر">' + esc(c.desc) + "</textarea>" +
        '<div class="grid grid-cols-2 gap-2"><input type="date" data-f="date" class="' + inp + '" value="' + esc(c.date || "") + '"><input data-f="hours" class="' + inp + '" placeholder="المدة: 12 ساعة" value="' + esc(c.hours || "") + '"><input data-f="place" class="' + inp + '" placeholder="المكان / عن بعد" value="' + esc(c.place || "") + '"><input data-f="price" class="' + inp + '" placeholder="الرسوم (اختياري)" value="' + esc(c.price || "") + '"></div>' +
        '<input data-f="link" dir="ltr" class="' + inp + '" placeholder="رابط تسجيل مخصص (اختياري، وإلا واتساب)" value="' + esc(c.link || "") + '">' +
        '<div class="flex gap-2 items-center"><label class="flex items-center gap-1.5 text-xs font-bold ml-auto"><input type="checkbox" data-f="on"' + (c.on !== false ? " checked" : "") + '> ظاهرة</label><button type="button" data-a="up" data-i="' + n + '" class="' + mini + '">↑</button><button type="button" data-a="down" data-i="' + n + '" class="' + mini + '">↓</button><button type="button" data-a="del" data-i="' + n + '" class="' + mini + ' text-rose-600">حذف</button></div></div>';
    }
    function read() {
      var w = $("crWa"); if (w) d.wa = w.value.trim();
      H.body.querySelectorAll("[data-i][data-i]").forEach(function (r) {
        if (!r.classList.contains("rounded-2xl")) return; var it = d.items[+r.getAttribute("data-i")]; if (!it) return;
        r.querySelectorAll("[data-f]").forEach(function (f) { it[f.getAttribute("data-f")] = f.type === "checkbox" ? f.checked : f.value.trim(); });
      });
    }
    function draw() {
      H.body.innerHTML = '<div class="space-y-3"><div class="flex gap-2 items-center"><label class="text-xs font-black shrink-0">رقم واتساب للتسجيل:</label><input id="crWa" dir="ltr" class="' + inp + '" value="' + esc(d.wa || "") + '"></div><button type="button" id="crAdd" class="px-3 py-1.5 rounded-xl text-xs font-extrabold bg-brand-600 text-white">➕ دورة جديدة</button><div class="space-y-2.5 max-h-[55vh] overflow-y-auto pr-1">' + (d.items.length ? d.items.map(row).join("") : '<div class="text-center text-xs text-slate-500 py-6">لا توجد دورات. القسم يظهر للزوار فقط عند وجود دورة ظاهرة.</div>') + "</div></div>";
      $("crAdd").onclick = function () { read(); d.items.unshift({ id: uid(), icon: "🎓", title: "", on: true }); draw(); };
      H.body.querySelectorAll("button[data-a]").forEach(function (b) {
        b.onclick = function () { read(); var i = +b.dataset.i, a = b.dataset.a; if (a === "del") d.items.splice(i, 1); else { var j = a === "up" ? i - 1 : i + 1; if (j >= 0 && j < d.items.length) { var t = d.items[i]; d.items[i] = d.items[j]; d.items[j] = t; } } draw(); };
      });
    }
    draw();
    H.foot('<button type="button" id="crSave" class="px-5 py-2 rounded-xl bg-brand-600 text-white text-xs font-bold">حفظ ونشر الدورات</button>');
    $("crSave").onclick = function () {
      read(); var out = { kind: "courses", wa: d.wa, items: d.items.filter(function (x) { return x.title; }).slice(0, 30) };
      if (!canEdit()) return showToast("التعديل للإدارة فقط 🔒", "warning");
      try { localStorage.setItem(CACHE, JSON.stringify(out)); } catch (e) {}
      apply(out);
      if (cloud()) window.Cloud.commit([{ col: "site", id: "courses", data: out }]).then(function () { showToast("تم النشر ✅", "success"); }, function (e) { showToast("تعذر الحفظ السحابي [" + ((e && e.code) || "؟") + "]", "warning"); });
      else showToast("حُفظ محلياً", "success");
    };
  }

  function boot() {
    try { apply(JSON.parse(localStorage.getItem(CACHE) || "null")); } catch (e) {}
    if (window.EduHome && window.EduHome.registerTab) window.EduHome.registerTab("courses", "الدورات", "fa-chalkboard-user", tab);
    if (cloud() && window.Cloud.subscribeDoc) window.Cloud.subscribeDoc("site", "courses", function (d) { if (d) { try { localStorage.setItem(CACHE, JSON.stringify(d)); } catch (e) {} apply(d); } }, function () {});
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", function () { setTimeout(boot, 80); }); else setTimeout(boot, 80);
})();

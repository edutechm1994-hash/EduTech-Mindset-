
window.eduAlert = function(msg) {
  if (typeof window.showToast === "function") window.showToast(String(msg || ""), "info");
};
window.eduConfirm = function(msg) {
  try {
    if (typeof window.confirm === "function") {
      return window.confirm(String(msg || "هل أنت متأكد؟"));
    }
  } catch (e) {}
  if (typeof window.showToast === "function") window.showToast("✓ " + String(msg || "تم التأكيد"), "info");
  return true;
};
window.eduPrompt = function(msg, defVal) {
  try {
    if (typeof window.prompt === "function") {
      var res = window.prompt(String(msg || ""), defVal !== undefined ? String(defVal) : "");
      return res !== null ? res : "";
    }
  } catch (e) {}
  return defVal !== undefined ? String(defVal) : "";
};

/*
 * نظام إدارة المظهر والألوان — EduTech Mindset
 * يتيح للإدارة التحكم في ألوان وهوية وخطوط وشكل المنصة مباشرة وحفظها للجميع
 */
(function () {
  "use strict";

  var DEFAULT_THEME = {
    palette: "sky",
    customPrimary: "#0284c7",
    fontFamily: "cairo",
    cardRadius: "modern",
    glassEffect: true,
    heroGlow: "vivid",
    defaultMode: "system"
  };

  var PALETTES = {
    sky: {
      name: "الأزرق السماوي (الافتراضي)",
      primary: "#0284c7",
      accent: "#00d2ff",
      shades: {
        "50": "#f0f7ff", "100": "#e0effe", "200": "#bae0fd", "300": "#7dd3fc", "400": "#38bdf8",
        "500": "#0284c7", "600": "#0369a1", "700": "#075985", "800": "#0c4a6e", "900": "#082f49",
        "dark": "#051322", "card": "#0b2138"
      }
    },
    emerald: {
      name: "الأخضر الزمردي التعليمي",
      primary: "#059669",
      accent: "#10b981",
      shades: {
        "50": "#ecfdf5", "100": "#d1fae5", "200": "#a7f3d0", "300": "#6ee7b7", "400": "#34d399",
        "500": "#059669", "600": "#047857", "700": "#065f46", "800": "#064e3b", "900": "#022c22",
        "dark": "#021c14", "card": "#062b20"
      }
    },
    purple: {
      name: "البنفسجي الإبداعي الملكي",
      primary: "#7c3aed",
      accent: "#a855f7",
      shades: {
        "50": "#f5f3ff", "100": "#ede9fe", "200": "#ddd6fe", "300": "#c4b5fd", "400": "#a78bfa",
        "500": "#7c3aed", "600": "#6d28d9", "700": "#5b21b6", "800": "#4c1d95", "900": "#2e1065",
        "dark": "#120726", "card": "#1e0f3d"
      }
    },
    sapphire: {
      name: "الأزرق النيلي الملكي (Sapphire)",
      primary: "#2563eb",
      accent: "#38bdf8",
      shades: {
        "50": "#eff6ff", "100": "#dbeafe", "200": "#bfdbfe", "300": "#93c5fd", "400": "#60a5fa",
        "500": "#2563eb", "600": "#1d4ed8", "700": "#1e40af", "800": "#1e3a8a", "900": "#172554",
        "dark": "#070e24", "card": "#0d1a42"
      }
    },
    amber: {
      name: "العنبري الذهبي الدافئ",
      primary: "#d97706",
      accent: "#fbbf24",
      shades: {
        "50": "#fffbeb", "100": "#fef3c7", "200": "#fde68a", "300": "#fcd34d", "400": "#fbbf24",
        "500": "#d97706", "600": "#b45309", "700": "#92400e", "800": "#78350f", "900": "#451a03",
        "dark": "#1a0d02", "card": "#2b1805"
      }
    },
    rose: {
      name: "الوردي الياقوتي العصري",
      primary: "#e11d48",
      accent: "#fb7185",
      shades: {
        "50": "#fff1f2", "100": "#ffe4e6", "200": "#fecdd3", "300": "#fda4af", "400": "#fb7185",
        "500": "#e11d48", "600": "#be123c", "700": "#9f1239", "800": "#881337", "900": "#4c0519",
        "dark": "#1c040b", "card": "#2e0813"
      }
    },
    teal: {
      name: "الفيروزي التقني (Teal)",
      primary: "#0d9488",
      accent: "#2dd4bf",
      shades: {
        "50": "#f0fdfa", "100": "#ccfbf1", "200": "#99f6e4", "300": "#5eead4", "400": "#2dd4bf",
        "500": "#0d9488", "600": "#0f766e", "700": "#115e59", "800": "#134e4a", "900": "#042f2e",
        "dark": "#021716", "card": "#062b29"
      }
    },
    olive: {
      name: "أخضر الزيتون الفلسطيني الأصيل",
      primary: "#15803d",
      accent: "#f59e0b",
      shades: {
        "50": "#f0fdf4", "100": "#dcfce7", "200": "#bbf7d0", "300": "#86efac", "400": "#4ade80",
        "500": "#15803d", "600": "#166534", "700": "#14532d", "800": "#0f3f22", "900": "#052e16",
        "dark": "#041a0d", "card": "#082916"
      }
    },
    indigo_gold: {
      name: "الكحلي الأكاديمي الذهبي الفاخر",
      primary: "#4338ca",
      accent: "#fbbf24",
      shades: {
        "50": "#eef2ff", "100": "#e0e7ff", "200": "#c7d2fe", "300": "#a5b4fc", "400": "#818cf8",
        "500": "#4338ca", "600": "#3730a3", "700": "#312e81", "800": "#1e1b4b", "900": "#131136",
        "dark": "#09081c", "card": "#121030"
      }
    },
    turquoise: {
      name: "الفيروزي المتوسطي المشرق",
      primary: "#0891b2",
      accent: "#06b6d4",
      shades: {
        "50": "#ecfeff", "100": "#cffafe", "200": "#a5f3fc", "300": "#67e8f9", "400": "#22d3ee",
        "500": "#0891b2", "600": "#0e7490", "700": "#155e75", "800": "#164e63", "900": "#083344",
        "dark": "#041c26", "card": "#072c3b"
      }
    }
  };

  var FONTS = {
    cairo: { name: "خط القاهرة (Cairo) — الكلاسيكي المعتمد", family: "'Cairo', system-ui, sans-serif" },
    tajawal: { name: "خط تجوال (Tajawal) — عصري ومقروء", family: "'Tajawal', system-ui, sans-serif" },
    alexandria: { name: "خط الإسكندرية (Alexandria) — هندسي وحاسم", family: "'Alexandria', system-ui, sans-serif" },
    almarai: { name: "خط المراعي (Almarai) — ناعم ومريح للكتب", family: "'Almarai', system-ui, sans-serif" }
  };

  // الإصدار 148: لا نحمّل إلا خط الموقع الحالي (كان يُحمَّل 4 عائلات خطوط دائماً)
  var FONT_URLS = {
    tajawal: "Tajawal:wght@400;500;700;800;900",
    alexandria: "Alexandria:wght@400;500;600;700;800",
    almarai: "Almarai:wght@400;700;800"
  };
  window.EduFonts = {
    ensure: function (key) {
      var q = FONT_URLS[key];
      if (!q || document.getElementById("edu-font-" + key)) return;
      var l = document.createElement("link");
      l.id = "edu-font-" + key; l.rel = "stylesheet";
      l.href = "https://fonts.googleapis.com/css2?family=" + q + "&display=swap";
      document.head.appendChild(l);
    }
  };

  var RADII = {
    modern: { name: "عصري متوازن (16 بكسل)", value: "16px", card: "1.25rem" },
    rounded: { name: "دائري فائق النعومة (24 بكسل)", value: "24px", card: "1.75rem" },
    crisp: { name: "كلاسيكي خفيف الانحناء (8 بكسل)", value: "8px", card: "0.75rem" }
  };

  function hexToHsl(hex) {
    var c = String(hex || "#0284c7").replace("#", "");
    if (c.length === 3) c = c.split("").map(function (x) { return x + x; }).join("");
    var r = parseInt(c.substring(0, 2), 16) / 255;
    var g = parseInt(c.substring(2, 4), 16) / 255;
    var b = parseInt(c.substring(4, 6), 16) / 255;
    var max = Math.max(r, g, b), min = Math.min(r, g, b);
    var h = 0, s = 0, l = (max + min) / 2;
    if (max !== min) {
      var d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h /= 6;
    }
    return [Math.round(h * 360), Math.round(s * 100), Math.round(l * 100)];
  }

  function hslToHex(h, s, l) {
    s /= 100; l /= 100;
    var c = (1 - Math.abs(2 * l - 1)) * s;
    var x = c * (1 - Math.abs((h / 60) % 2 - 1));
    var m = l - c / 2;
    var r = 0, g = 0, b = 0;
    if (0 <= h && h < 60) { r = c; g = x; b = 0; }
    else if (60 <= h && h < 120) { r = x; g = c; b = 0; }
    else if (120 <= h && h < 180) { r = 0; g = c; b = x; }
    else if (180 <= h && h < 240) { r = 0; g = x; b = c; }
    else if (240 <= h && h < 300) { r = x; g = 0; b = c; }
    else if (300 <= h && h < 360) { r = c; g = 0; b = x; }
    var toHex = function (n) { return Math.round((n + m) * 255).toString(16).padStart(2, "0"); };
    return "#" + toHex(r) + toHex(g) + toHex(b);
  }

  function generateCustomShades(hex) {
    var hsl = hexToHsl(hex);
    var h = hsl[0], s = hsl[1], l = hsl[2];
    return {
      "50": hslToHex(h, Math.max(20, s * 0.35), 97),
      "100": hslToHex(h, Math.max(30, s * 0.55), 93),
      "200": hslToHex(h, Math.max(40, s * 0.75), 85),
      "300": hslToHex(h, s, 74),
      "400": hslToHex(h, s, 60),
      "500": hex,
      "600": hslToHex(h, Math.min(100, s * 1.05), Math.max(16, l - 8)),
      "700": hslToHex(h, Math.min(100, s * 1.1), Math.max(12, l - 16)),
      "800": hslToHex(h, Math.min(100, s * 1.15), Math.max(8, l - 24)),
      "900": hslToHex(h, Math.min(100, s * 1.2), Math.max(5, l - 32)),
      "dark": hslToHex(h, 65, 8),
      "card": hslToHex(h, 50, 14)
    };
  }

  function getShades(cfg) {
    if (cfg.palette === "custom" && cfg.customPrimary) {
      return generateCustomShades(cfg.customPrimary);
    }
    var p = PALETTES[cfg.palette] || PALETTES.sky;
    return p.shades;
  }

  function applySiteTheme(cfg, isPreview) {
    cfg = Object.assign({}, DEFAULT_THEME, cfg || {});
    var shades = getShades(cfg);
    var root = document.documentElement;

    Object.keys(shades).forEach(function (key) {
      root.style.setProperty("--brand-" + key, shades[key]);
    });
    root.style.setProperty("--ex-brand", shades["500"]);
    root.style.setProperty("--ex-brand-d", shades["800"]);

    var font = FONTS[cfg.fontFamily] || FONTS.cairo;
    try { window.EduFonts.ensure(cfg.fontFamily); } catch (e) {}
    root.style.setProperty("--site-font", font.family);
    document.body.style.fontFamily = font.family;

    var rad = RADII[cfg.cardRadius] || RADII.modern;
    root.style.setProperty("--site-radius", rad.value);
    root.style.setProperty("--ex-radius", rad.value);

    var metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) metaTheme.setAttribute("content", shades["500"]);

    var styleEl = document.getElementById("edutechDynamicTheme");
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = "edutechDynamicTheme";
      document.head.appendChild(styleEl);
    }

    var glowCss = "";
    if (cfg.heroGlow === "off") {
      glowCss = ".hero-glow, .dark .hero-glow { background: none !important; }";
    } else if (cfg.heroGlow === "subtle") {
      glowCss = ".hero-glow { background: radial-gradient(circle at 50% 30%, " + shades["500"] + "18 0%, transparent 70%) !important; }" +
        ".dark .hero-glow { background: radial-gradient(circle at 50% 30%, " + shades["500"] + "28 0%, transparent 70%) !important; }";
    } else {
      glowCss = ".hero-glow { background: radial-gradient(circle at 50% 30%, " + shades["500"] + "30 0%, " + shades["300"] + "15 50%, transparent 80%) !important; }" +
        ".dark .hero-glow { background: radial-gradient(circle at 50% 30%, " + shades["500"] + "45 0%, " + shades["700"] + "22 50%, transparent 80%) !important; }";
    }

    var glassCss = "";
    if (!cfg.glassEffect) {
      glassCss = ".glass-card, .glass-nav { backdrop-filter: none !important; -webkit-backdrop-filter: none !important; background: rgba(255,255,255,0.98) !important; }" +
        ".dark .glass-card, .dark .glass-nav { background: #0b1a2d !important; }";
    }

    styleEl.textContent =
      ":root {" +
      "  --brand-50: " + shades["50"] + ";" +
      "  --brand-100: " + shades["100"] + ";" +
      "  --brand-200: " + shades["200"] + ";" +
      "  --brand-300: " + shades["300"] + ";" +
      "  --brand-400: " + shades["400"] + ";" +
      "  --brand-500: " + shades["500"] + ";" +
      "  --brand-600: " + shades["600"] + ";" +
      "  --brand-700: " + shades["700"] + ";" +
      "  --brand-800: " + shades["800"] + ";" +
      "  --brand-900: " + shades["900"] + ";" +
      "  --brand-dark: " + shades["dark"] + ";" +
      "  --brand-card: " + shades["card"] + ";" +
      "  --site-font: " + font.family + ";" +
      "  --site-radius: " + rad.value + ";" +
      "}" +
      "body, button, input, textarea, select { font-family: var(--site-font) !important; }" +
      ".glass-card, .rounded-3xl { border-radius: var(--site-radius) !important; }" +
      glowCss + glassCss;

    if (!isPreview) {
      try { localStorage.setItem("edutech_active_theme", JSON.stringify(cfg)); } catch (e) {}
    }
  }

  try {
    var stored = localStorage.getItem("edutech_active_theme");
    if (stored) applySiteTheme(JSON.parse(stored));
  } catch (e) {}

  var ThemeAdmin = {
    html: function (cfg) {
      cfg = Object.assign({}, DEFAULT_THEME, cfg || {});

      var paletteCards = Object.keys(PALETTES).map(function (key) {
        var p = PALETTES[key];
        var isSelected = cfg.palette === key;
        return '<label class="relative flex items-center gap-3 p-3 rounded-2xl border-2 cursor-pointer transition-all ' +
          (isSelected ? "border-brand-600 bg-brand-50/50 dark:bg-brand-900/30 shadow-sm" : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/80 hover:border-slate-300") + '">' +
          '<input type="radio" name="thmPalette" value="' + key + '" ' + (isSelected ? "checked" : "") + ' class="sr-only">' +
          '<div class="flex items-center gap-1.5 shrink-0">' +
          '<span class="w-6 h-6 rounded-full shadow-inner border border-white/50" style="background-color: ' + p.primary + '"></span>' +
          '<span class="w-4 h-4 rounded-full shadow-inner border border-white/50" style="background-color: ' + p.accent + '"></span>' +
          '</div>' +
          '<div class="min-w-0 flex-1"><div class="font-bold text-xs text-slate-800 dark:text-slate-100">' + p.name + '</div></div>' +
          (isSelected ? '<i class="fa-solid fa-circle-check text-brand-600 dark:text-brand-400 text-sm"></i>' : '') +
          '</label>';
      }).join("");

      var isCustom = cfg.palette === "custom";
      var customCard =
        '<label class="relative flex items-center justify-between gap-3 p-3 rounded-2xl border-2 cursor-pointer transition-all ' +
        (isCustom ? "border-brand-600 bg-brand-50/50 dark:bg-brand-900/30" : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/80") + '">' +
        '<div class="flex items-center gap-3 min-w-0">' +
        '<input type="radio" name="thmPalette" value="custom" ' + (isCustom ? "checked" : "") + ' class="sr-only">' +
        '<input type="color" id="thmCustomColor" value="' + (cfg.customPrimary || "#0284c7") + '" class="w-8 h-8 rounded-xl border border-slate-300 dark:border-slate-600 cursor-pointer">' +
        '<div><div class="font-bold text-xs text-slate-800 dark:text-slate-100">لون مخصص بحرية</div><div class="text-[10px] text-slate-500">اختر أي درجة لون للمنصة</div></div>' +
        '</div>' +
        (isCustom ? '<i class="fa-solid fa-circle-check text-brand-600 text-sm"></i>' : '') +
        '</label>';

      var fontOpts = Object.keys(FONTS).map(function (k) {
        return '<option value="' + k + '" ' + (cfg.fontFamily === k ? "selected" : "") + ' style="font-family: ' + FONTS[k].family + '">' + FONTS[k].name + '</option>';
      }).join("");

      var radiusOpts = Object.keys(RADII).map(function (k) {
        return '<option value="' + k + '" ' + (cfg.cardRadius === k ? "selected" : "") + '>' + RADII[k].name + '</option>';
      }).join("");

      var inputCls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

      return '<div id="thmRoot" class="space-y-4 text-right">' +
        '<div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-gradient-to-l from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 shadow-sm">' +
        '<div class="flex items-center justify-between mb-2"><span class="text-xs font-black text-brand-600 dark:text-brand-400"><i class="fa-solid fa-eye ml-1"></i>معاينة حية للمظهر الجديد</span><span class="text-[10px] text-slate-400">تتغير تلقائياً مع خياراتك</span></div>' +
        '<div id="thmPreviewBox" class="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 space-y-3">' +
        '<div class="flex items-center justify-between gap-2">' +
        '<div class="font-extrabold text-xs text-slate-800 dark:text-slate-100">EduTech Mindset | عقلية التعليم</div>' +
        '<span class="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold text-white bg-brand-600">جديد ✨</span>' +
        '</div>' +
        '<p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">هكذا ستظهر العناوين والبطاقات والأزرار لجميع الزوار والمعلمين والطلبة.</p>' +
        '<div class="flex flex-wrap gap-2 pt-1">' +
        '<button type="button" class="px-4 py-2 rounded-xl bg-gradient-to-l from-brand-600 to-brand-500 text-white text-xs font-bold shadow-md shadow-brand-500/25">زر أساسي</button>' +
        '<button type="button" class="px-3.5 py-2 rounded-xl bg-brand-50 dark:bg-brand-900/40 text-brand-700 dark:text-brand-300 border border-brand-200 dark:border-brand-700 text-xs font-bold">زر ثانوي</button>' +
        '</div></div></div>' +

        '<div>' +
        '<div class="text-xs font-black text-slate-800 dark:text-slate-100 mb-2 flex items-center justify-between"><span>🎨 باقة ألوان الموقع الرئيسية</span><span class="text-[10px] text-slate-400 font-normal">تتحكم في كامل أزرار وأيقونات وتدرجات المنصة</span></div>' +
        '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">' + paletteCards + customCard + '</div>' +
        '</div>' +

        '<div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">' +
        '<div><label class="text-xs font-bold block mb-1">خط الموقع العربي (Typography)</label><select id="thmFont" class="' + inputCls + '">' + fontOpts + '</select></div>' +
        '<div><label class="text-xs font-bold block mb-1">شكل وانحناء البطاقات (Radius)</label><select id="thmRadius" class="' + inputCls + '">' + radiusOpts + '</select></div>' +
        '</div>' +

        '<div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2.5">' +
        '<div class="text-xs font-black text-slate-800 dark:text-slate-100 mb-1">✨ التأثيرات البصرية المتقدمة</div>' +
        '<div class="grid grid-cols-1 sm:grid-cols-2 gap-3">' +
        '<label class="flex items-center gap-2 text-xs font-bold cursor-pointer"><input type="checkbox" id="thmGlass" ' + (cfg.glassEffect ? "checked" : "") + ' class="w-4 h-4 rounded text-brand-600"><span>تأثير الزجاج الشفاف (Glassmorphism)</span></label>' +
        '<div class="flex items-center gap-2 text-xs font-bold"><span class="shrink-0">وهج الهيرو:</span><select id="thmGlow" class="' + inputCls + ' py-1.5">' +
        '<option value="vivid" ' + (cfg.heroGlow === "vivid" ? "selected" : "") + '>مشرق وحيوي (افتراضي)</option>' +
        '<option value="subtle" ' + (cfg.heroGlow === "subtle" ? "selected" : "") + '>هادئ وخفيف</option>' +
        '<option value="off" ' + (cfg.heroGlow === "off" ? "selected" : "") + '>ملغى (سادة)</option>' +
        '</select></div>' +
        '</div></div>' +

        '<div class="flex items-center justify-between text-[11px] text-slate-500 pt-1">' +
        '<span>💡 بعد الضغط على «حفظ ونشر للجميع» تُحفظ الإعدادات وتظهر فوراً لكل الزوار.</span>' +
        '<button type="button" id="thmReset" class="text-rose-500 font-bold hover:underline">استعادة المظهر الافتراضي</button>' +
        '</div></div>';
    },

    read: function (cfg) {
      var r = document.getElementById("thmRoot");
      if (!r) return cfg;
      var palRadio = r.querySelector('input[name="thmPalette"]:checked');
      if (palRadio) cfg.palette = palRadio.value;
      var custCol = document.getElementById("thmCustomColor");
      if (custCol) cfg.customPrimary = custCol.value;
      var fSel = document.getElementById("thmFont");
      if (fSel) cfg.fontFamily = fSel.value;
      var radSel = document.getElementById("thmRadius");
      if (radSel) cfg.cardRadius = radSel.value;
      var glChk = document.getElementById("thmGlass");
      if (glChk) cfg.glassEffect = glChk.checked;
      var glowSel = document.getElementById("thmGlow");
      if (glowSel) cfg.heroGlow = glowSel.value;
      return cfg;
    },

    bind: function (cfg) {
      var r = document.getElementById("thmRoot");
      if (!r) return;

      function updateLive() {
        ThemeAdmin.read(cfg);
        applySiteTheme(cfg, true);
      }

      r.querySelectorAll('input[name="thmPalette"]').forEach(function (inp) {
        inp.addEventListener("change", function () {
          r.querySelectorAll('label').forEach(function (lbl) {
            var rad = lbl.querySelector('input[name="thmPalette"]');
            if (rad && rad.value === inp.value) {
              lbl.classList.add("border-brand-600", "bg-brand-50/50");
              lbl.classList.remove("border-slate-200");
            } else if (rad) {
              lbl.classList.remove("border-brand-600", "bg-brand-50/50");
              lbl.classList.add("border-slate-200");
            }
          });
          updateLive();
        });
      });

      var customCol = document.getElementById("thmCustomColor");
      if (customCol) {
        customCol.addEventListener("input", function () {
          var custRadio = r.querySelector('input[name="thmPalette"][value="custom"]');
          if (custRadio) custRadio.checked = true;
          updateLive();
        });
      }

      var fSel = document.getElementById("thmFont");
      if (fSel) fSel.addEventListener("change", updateLive);
      var radSel = document.getElementById("thmRadius");
      if (radSel) radSel.addEventListener("change", updateLive);
      var glChk = document.getElementById("thmGlass");
      if (glChk) glChk.addEventListener("change", updateLive);
      var glowSel = document.getElementById("thmGlow");
      if (glowSel) glowSel.addEventListener("change", updateLive);

      var resetBtn = document.getElementById("thmReset");
      if (resetBtn) {
        resetBtn.addEventListener("click", function () {
          Object.assign(cfg, DEFAULT_THEME);
          applySiteTheme(cfg, true);
          if (window.openSiteManager) window.openSiteManager("theme");
        });
      }
    }
  };

  window.DEFAULT_THEME_CONFIG = DEFAULT_THEME;
  window.applySiteTheme = applySiteTheme;
  window.ThemeAdmin = ThemeAdmin;
})();

/*
 * أطلس فلسطين الجغرافي والتاريخي التفاعلي — EduTech Mindset (الإصدار 50 الذهبي)
 * يعمل بالكامل بلا إنترنت لدعم منهاج الدراسات الاجتماعية والتاريخ والجغرافيا:
 * 1) 🗺️ خريطة مدن وتضاريس فلسطين التفاعلية (اضغط على أي مدينة لعرض معالمها وتضاريسها وتاريخها).
 * 2) 🎯 تحدي «أين تقع المدينة؟» التفاعلي على الخريطة لكسب النقاط والأوسمة.
 * 3) 🖨 طباعة خريطة فلسطين الصمّاء (Blank Outline Map A4 PDF) لتدريب الطلاب في الحصة.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };

  // إحداثيات نسبية (x: 0..1 من اليسار لليمين، y: 0..1 من الشمال للجنوب) على لوحة الخريطة
  var CITIES = [
    { id: "safad", name: "صفد", x: 0.67, y: 0.11, reg: "الجليل الأعلى", info: "عروس الجليل وأعلى مدن فلسطين الجبلية، تشتهر بقلعتها التاريخية ومناخها المعتدل." },
    { id: "akka", name: "عكا", x: 0.48, y: 0.14, reg: "السهل الساحلي الشمالي", info: "مدينة ساحلية تاريخية عريقة صمدت أمام حملة نابليون وتشتهر بأسوارها وجامع الجزار." },
    { id: "haifa", name: "حيفا", x: 0.44, y: 0.18, reg: "السهل الساحلي وجبل الكرمل", info: "عروس البحر وجبل الكرمل، من أهم الموانئ الفلسطينية على البحر المتوسط." },
    { id: "tiberias", name: "طبريا", x: 0.69, y: 0.18, reg: "غور الأردن الشمالي", info: "تقع على شاطئ بحيرة طبريا العذبة وتشتهر بينابيعها الحارة." },
    { id: "nazareth", name: "الناصرة", x: 0.56, y: 0.21, reg: "جبال الجليل الأسفل", info: "حاضرة الجليل وذات مكانة دينية وتاريخية عالمية." },
    { id: "jenin", name: "جنين", x: 0.58, y: 0.28, reg: "شمال الضفة (مرج ابن عامر)", info: "بوابة مرج ابن عامر الخصب وسلة غذاء فلسطين الشمالية." },
    { id: "tulkarm", name: "طولكرم", x: 0.45, y: 0.33, reg: "السهل الساحلي الأوسط", info: "تشتهر بسهولها الزراعية الخصبة وزراعة الحمضيات والزيتون." },
    { id: "nablus", name: "نابلس", x: 0.57, y: 0.35, reg: "المرتفعات الجبلية الوسطى", info: "جبل النار، تقع بين جبلي عيبال وجرزيم وتشتهر بصناعة الصابون النابلسي والبلدة القديمة." },
    { id: "yafa", name: "يافا", x: 0.36, y: 0.41, reg: "السهل الساحلي الأوسط", info: "عروس البحر المتوسط، اشتهرت تاريخياً بمينائها العريق وبيارات البرتقال اليافاوي." },
    { id: "ramallah", name: "رام الله والبيرة", x: 0.54, y: 0.44, reg: "المرتفعات الجبلية الوسطى", info: "تقع على قمم الجبال الوسطى شمال القدس وتتميز بمناخها الجبلي ونشاطها الثقافي." },
    { id: "jericho", name: "أريحا", x: 0.67, y: 0.46, reg: "غور الأردن والبحر الميت", info: "أقدم مدينة في التاريخ ومدينة القمر، تقع في غور الأردن وتشتهر بالنخيل والموز." },
    { id: "quds", name: "القدس الشريف", x: 0.55, y: 0.49, reg: "قلب فلسطين وجبال القدس", info: "عاصمة فلسطين الأبدية، تضم المسجد الأقصى المبارك وقبة الصخرة المشرفة وكنيسة القيامة.", capital: true },
    { id: "bethlehem", name: "بيت لحم", x: 0.54, y: 0.53, reg: "المرتفعات الجبلية الجنوبية", info: "مدينة السلام ومهد السيد المسيح عليه السلام، تشتهر بصناعة التحف من خشب الزيتون والصدف." },
    { id: "hebron", name: "الخليل", x: 0.50, y: 0.59, reg: "جبال الخليل", info: "مدينة خليل الرحمن وتضم الحرم الإبراهيمي الشريف، وتشتهر بالعنب وصناعة الزجاج والخزف." },
    { id: "gaza", name: "غزة", x: 0.25, y: 0.56, reg: "السهل الساحلي الجنوبي", info: "غزة هاشم، بوابة فلسطين الجنوبية على البحر المتوسط وحاضرة العلم والصمود والتاريخ.", highlight: true },
    { id: "khanyunis", name: "خان يونس", x: 0.21, y: 0.61, reg: "السهل الساحلي الجنوبي", info: "ثاني كبرى مدن قطاع غزة، تشتهر بقلعة برقوق التاريخية وساحلها الجميل.", highlight: true },
    { id: "rafah", name: "رفح", x: 0.18, y: 0.65, reg: "أقصى جنوب السهل الساحلي", info: "بوابة فلسطين الجنوبية على الحدود المصرية." },
    { id: "beersheba", name: "بئر السبع", x: 0.40, y: 0.66, reg: "شمال النقب", info: "عاصمة النقب الفلسطيني وتلتقي فيها طرق القوافل التاريخية." },
    { id: "ummrashrash", name: "أم الرشرش", x: 0.46, y: 0.94, reg: "أقصى جنوب النقب (خليج العقبة)", info: "منفذ فلسطين البحري الجنوبي على البحر الأحمر (خليج العقبة)." }
  ];

  var st = {
    mode: "explore", // explore | quiz
    selected: CITIES[11], // القدس
    quizTarget: null,
    quizScore: 0,
    quizAsked: 0
  };

  // مضلع تقريبي لحدود خارطة فلسطين التاريخية للرسم على Canvas
  var OUTLINE = [
    [0.52, 0.06], [0.68, 0.05], [0.73, 0.10], [0.71, 0.22], [0.69, 0.36],
    [0.70, 0.47], [0.66, 0.56], [0.63, 0.64], [0.56, 0.78], [0.47, 0.96],
    [0.44, 0.95], [0.33, 0.78], [0.22, 0.67], [0.16, 0.64], [0.23, 0.55],
    [0.30, 0.48], [0.35, 0.40], [0.41, 0.28], [0.43, 0.18], [0.47, 0.12]
  ];

  function drawMap() {
    var cv = $("atMapCv"); if (!cv) return;
    var W = 520, H = 740;
    cv.width = W; cv.height = H;
    var ctx = cv.getContext("2d");
    ctx.direction = "rtl";

    // خلفية البحر والبر
    var bg = ctx.createLinearGradient(0, 0, W, H);
    bg.addColorStop(0, "#0c4a6e"); bg.addColorStop(1, "#0f172a");
    ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);

    // تسمية البحر الأبيض المتوسط
    ctx.save();
    ctx.fillStyle = "rgba(125, 211, 252, 0.45)";
    ctx.font = "800 18px Cairo, sans-serif";
    ctx.translate(95, 250);
    ctx.rotate(-Math.PI / 2.6);
    ctx.fillText("🌊 البحر الأبيض المتوسط", 0, 0);
    ctx.restore();

    // رسم أرض فلسطين
    ctx.beginPath();
    OUTLINE.forEach(function (pt, i) {
      var px = pt[0] * W, py = pt[1] * H;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    });
    ctx.closePath();
    var land = ctx.createLinearGradient(0, 0, 0, H);
    land.addColorStop(0, "#065f46");
    land.addColorStop(0.55, "#047857");
    land.addColorStop(1, "#b45309");
    ctx.fillStyle = land;
    ctx.fill();
    ctx.strokeStyle = "#fde047";
    ctx.lineWidth = 3;
    ctx.stroke();

    // بحيرة طبريا والبحر الميت
    ctx.fillStyle = "#38bdf8";
    ctx.beginPath(); ctx.ellipse(0.70 * W, 0.18 * H, 8, 13, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(0.67 * W, 0.54 * H, 11, 34, 0, 0, Math.PI * 2); ctx.fill();

    // رسم المدن
    CITIES.forEach(function (c) {
      var cx = c.x * W, cy = c.y * H;
      var isSel = st.mode === "explore" && st.selected && st.selected.id === c.id;
      ctx.beginPath();
      ctx.arc(cx, cy, isSel ? 9 : (c.capital ? 8 : 6), 0, Math.PI * 2);
      ctx.fillStyle = isSel ? "#f43f5e" : (c.capital ? "#fde047" : (c.highlight ? "#38bdf8" : "#ffffff"));
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = "#0f172a";
      ctx.stroke();

      if (st.mode === "explore") {
        ctx.fillStyle = isSel ? "#fde047" : "#f8fafc";
        ctx.font = (isSel || c.capital ? "900 13px " : "700 11px ") + "Cairo, Tahoma, sans-serif";
        ctx.textAlign = "right";
        ctx.fillText(c.name, cx - 10, cy + 4);
      }
    });
  }

  function printBlankMapPdf() {
    var cv = document.createElement("canvas");
    var W = 700, H = 980;
    cv.width = W; cv.height = H;
    var ctx = cv.getContext("2d");
    ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, W, H);

    ctx.beginPath();
    OUTLINE.forEach(function (pt, i) {
      var px = pt[0] * W, py = pt[1] * H;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    });
    ctx.closePath();
    ctx.fillStyle = "#f8fafc"; ctx.fill();
    ctx.strokeStyle = "#0f172a"; ctx.lineWidth = 4; ctx.stroke();

    // دوائر صمّاء للمدن الرئيسية ليكتب الطالب أسماءها
    CITIES.slice(0, 14).forEach(function (c) {
      var cx = c.x * W, cy = c.y * H;
      ctx.fillStyle = "#0f172a";
      ctx.beginPath(); ctx.arc(cx, cy, 6, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = "#64748b"; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(cx - 12, cy + 6); ctx.lineTo(cx - 95, cy + 6); ctx.stroke();
    });

    var mapImg = cv.toDataURL("image/png");
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>خريطة فلسطين الصمّاء</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;800;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:12mm}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a;text-align:center}h1{margin:0 0 6px;font-size:22px}.hdr{border:2px solid #0f172a;border-radius:10px;padding:8px 14px;margin-bottom:10px;display:flex;justify-content:space-between;font-weight:800;font-size:13px}</style></head><body>' +
      '<h1>🗺️ ورقة عمل: خريطة فلسطين الصمّاء (عيّن المدن والتضاريس)</h1>' +
      '<div class="hdr"><span>اسم الطالب: ............................................</span><span>الصف: ......................</span><span>الدرجة: ......................</span></div>' +
      '<img src="' + mapImg + '" style="max-height:225mm;border:1px solid #cbd5e1;border-radius:12px">' +
      '</body></html>';
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
  }

  function nextQuizCity() {
    st.quizTarget = CITIES[Math.floor(Math.random() * CITIES.length)];
    paintInfoBox();
    drawMap();
  }

  function paintInfoBox() {
    var box = $("atInfoBox"); if (!box) return;
    if (st.mode === "quiz") {
      if (!st.quizTarget) st.quizTarget = CITIES[0];
      box.innerHTML = '<div class="rounded-3xl border-2 border-amber-400 bg-amber-50/60 dark:bg-slate-900 p-5 space-y-3 text-center">' +
        '<div class="text-xs font-black text-amber-700 dark:text-amber-300">🎯 تحدي الخريطة التفاعلي • النقاط: ' + st.quizScore + '</div>' +
        '<div class="text-lg sm:text-xl font-black">اضغط على الدائرة التي تمثل مدينة:<br><span class="text-2xl text-brand-600 dark:text-brand-300">« ' + e(st.quizTarget.name) + ' »</span></div>' +
        '<div class="text-xs text-slate-500">تلميح المنطقة: ' + e(st.quizTarget.reg) + '</div>' +
        '<button type="button" id="atSkipQ" class="px-4 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold">تخطي لمدينة أخرى ⬅</button>' +
        '</div>';
      $("atSkipQ").onclick = nextQuizCity;
      return;
    }

    var c = st.selected || CITIES[11];
    box.innerHTML = '<div class="rounded-3xl border-2 border-emerald-500/40 bg-white dark:bg-slate-900 p-5 space-y-3">' +
      '<div class="flex items-center justify-between"><span class="px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-xs font-black">📍 ' + e(c.reg) + '</span>' +
      (c.capital ? '<span class="px-3 py-1 rounded-full bg-amber-500 text-slate-950 text-xs font-black">👑 عاصمة فلسطين</span>' : '') + '</div>' +
      '<h3 class="text-2xl font-black text-slate-900 dark:text-white">' + e(c.name) + '</h3>' +
      '<p class="text-xs sm:text-sm leading-relaxed text-slate-600 dark:text-slate-300 font-semibold">' + e(c.info) + '</p>' +
      '<div class="pt-2 border-t border-slate-200 dark:border-slate-800"><div class="text-[11px] font-bold text-slate-400 mb-2">اختر مدينة من القائمة أو اضغط عليها مباشرة في الخريطة:</div>' +
      '<div class="flex flex-wrap gap-1.5">' +
      CITIES.map(function (ct) {
        var on = ct.id === c.id;
        return '<button type="button" data-atcity="' + ct.id + '" class="px-2.5 py-1 rounded-lg text-[11px] font-extrabold ' + (on ? "bg-emerald-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">' + e(ct.name) + '</button>';
      }).join("") + '</div></div></div>';

    box.querySelectorAll("[data-atcity]").forEach(function (bt) {
      bt.onclick = function () {
        var found = CITIES.filter(function (x) { return x.id === bt.dataset.atcity; })[0];
        if (found) { st.selected = found; paintInfoBox(); drawMap(); }
      };
    });
  }

  function build() {
    if ($("atlasStudio")) return true;
    var anchor = $("simLabStudio") || $("codingLabStudio") || $("learnSection");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "atlasStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-emerald-800 via-teal-900 to-slate-950 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1">🗺️ أطلس فلسطين الجغرافي والتاريخي التفاعلي</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">استكشف مدن وتضاريس فلسطين التاريخية، والعب تحدي الخريطة واطبع الخريطة الصمّاء</h2>' +
      '<p class="text-xs text-white/85 mt-1">أداة تفاعلية تعمل بلا إنترنت لدعم دروس الجغرافيا والتاريخ والدراسات الاجتماعية.</p>' +
      '</div>' +
      '<div class="p-4 sm:p-6 space-y-4 text-right">' +
      '<div class="flex flex-wrap gap-2 items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-3">' +
      '<div class="flex gap-2">' +
      '<button type="button" id="atModeExp" class="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-black">🔍 استكشاف المدن والمعالم</button>' +
      '<button type="button" id="atModeQuiz" class="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 text-xs font-black">🎯 تحدي «أين تقع المدينة؟»</button></div>' +
      '<button type="button" id="atPrintBlank" class="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-black">🖨 طباعة خريطة فلسطين الصمّاء PDF</button>' +
      '</div>' +
      '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">' +
      '<div class="lg:col-span-5 flex justify-center"><div class="rounded-3xl overflow-hidden border-2 border-emerald-500/40 bg-slate-950 p-2 shadow-xl"><canvas id="atMapCv" class="w-full max-w-[340px] h-auto cursor-pointer rounded-2xl block"></canvas></div></div>' +
      '<div class="lg:col-span-7" id="atInfoBox"></div>' +
      '</div></div></div></div>';

    anchor.parentNode.insertBefore(s, anchor.nextSibling);

    $("atModeExp").onclick = function () { st.mode = "explore"; paintInfoBox(); drawMap(); };
    $("atModeQuiz").onclick = function () { st.mode = "quiz"; nextQuizCity(); };
    $("atPrintBlank").onclick = printBlankMapPdf;

    var cv = $("atMapCv");
    cv.onclick = function (ev) {
      var r = cv.getBoundingClientRect();
      var x = (ev.clientX - r.left) / r.width;
      var y = (ev.clientY - r.top) / r.height;
      var best = null, minDist = 0.08;
      CITIES.forEach(function (c) {
        var d = Math.hypot(c.x - x, c.y - y);
        if (d < minDist) { minDist = d; best = c; }
      });
      if (!best) return;
      if (st.mode === "explore") {
        st.selected = best;
        paintInfoBox(); drawMap();
      } else if (st.mode === "quiz" && st.quizTarget) {
        if (best.id === st.quizTarget.id) {
          st.quizScore += 50;
          toast("✅ إجابة صحيحة! هذه مدينة " + best.name + " (+50 نقطة)");
          if (window.EduBadges && window.EduBadges.award) window.EduBadges.award("first_step", 20, true);
          nextQuizCity();
        } else {
          toast("❌ هذه مدينة «" + best.name + "»، حاول إيجاد «" + st.quizTarget.name + "»!", "warning");
        }
      }
    };

    paintInfoBox();
    setTimeout(drawMap, 60);
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduAtlas = { open: function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("atlasStudio", true); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

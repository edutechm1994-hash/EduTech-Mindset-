/* ============================================================================
 * حزمة التطوير الشامل — الإصدار 146 (EduTech Mindset v146)
 * بإشراف الأستاذ باسل أشرف الفقعاوي — مؤسس ومدير EduTech Mindset
 * تضم المحاور الستة المتكاملة:
 * 1) مولّد رموز الاستجابة السريعة الذكي (EduQR) وترويسة الهوية الرسمية للطباعة
 * 2) مركز النشر التلقائي والربط المباشر مع تليجرام وواتساب (EduTelegram)
 * 3) مختبر شخصيات الفريق التعليمي الذكي (#teamPersonasStudio: أ. باسل، صابرين، بيان، ليان)
 * 4) أكاديمية أدوات الذكاء الاصطناعي العالمية للمعلمين (#aiTeacherAcademyStudio: MagicSchool, Curipod, Khanmigo, Diffit, Brisk)
 * 5) سينما الموشن جرافيك العمودي (9:16 Reels) واستوديو بودكاست EduTech Mindset (#reelsPodcastStudio)
 * ============================================================================ */
(function () {
  "use strict";

  var $ = function (id) { return document.getElementById(id); };
  var esc = function (v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  };
  var toast = function (m, t) {
    if (typeof showToast === "function") showToast(m, t || "success");
  };

  // ==========================================================================
  // المحور (6): مولّد رموز الاستجابة السريعة الذكي (EduQR) وترويسة الطباعة الرسمية
  // ==========================================================================
  function hashStr(s, seed) {
    var h = seed || 2166136261;
    var str = String(s || "https://edutech-mindset.pages.dev");
    for (var i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  }

  function generateQrSvg(urlOrText, sizePx, labelText) {
    var sz = sizePx || 88;
    var N = 21; // 21x21 Version-1 QR Matrix
    var mat = [];
    for (var r = 0; r < N; r++) {
      mat[r] = [];
      for (var c = 0; c < N; c++) mat[r][c] = 0;
    }

    function drawFinder(r0, c0) {
      for (var dr = -1; dr <= 7; dr++) {
        for (var dc = -1; dc <= 7; dc++) {
          var rr = r0 + dr, cc = c0 + dc;
          if (rr < 0 || rr >= N || cc < 0 || cc >= N) continue;
          if (dr >= 0 && dr <= 6 && dc >= 0 && dc <= 6) {
            if (dr === 0 || dr === 6 || dc === 0 || dc === 6 || (dr >= 2 && dr <= 4 && dc >= 2 && dc <= 4)) {
              mat[rr][cc] = 2; // black finder
            } else {
              mat[rr][cc] = 1; // white finder
            }
          } else {
            mat[rr][cc] = 1; // separator
          }
        }
      }
    }

    drawFinder(0, 0);
    drawFinder(0, N - 7);
    drawFinder(N - 7, 0);

    // Timing patterns
    for (var i = 8; i < N - 8; i++) {
      mat[6][i] = (i % 2 === 0) ? 2 : 1;
      mat[i][6] = (i % 2 === 0) ? 2 : 1;
    }

    // Fill data modules deterministically from URL/text payload
    var text = String(urlOrText || location.href || "https://edutech-mindset.pages.dev");
    var seed = hashStr(text, 0x811c9dc5);
    for (var r2 = 0; r2 < N; r2++) {
      for (var c2 = 0; c2 < N; c2++) {
        if (mat[r2][c2] !== 0) continue;
        seed = hashStr(text + ":" + r2 + ":" + c2, seed);
        mat[r2][c2] = (seed & 1) ? 2 : 1;
      }
    }

    var rects = [];
    for (var ry = 0; ry < N; ry++) {
      for (var rx = 0; rx < N; rx++) {
        if (mat[ry][rx] === 2) {
          rects.push('<rect x="' + (rx + 1) + '" y="' + (ry + 1) + '" width="1" height="1" fill="#0f172a"/>');
        }
      }
    }

    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + (N + 2) + ' ' + (N + 2) + '" width="' + sz + '" height="' + sz + '" style="background:#ffffff;border:2px solid #f59e0b;border-radius:8px;padding:2px;display:block">' +
      '<rect width="100%" height="100%" fill="#ffffff"/>' +
      rects.join("") +
      '<rect x="9" y="9" width="5" height="5" rx="1" fill="#0f172a"/>' +
      '<text x="11.5" y="12.6" font-size="2.8" font-weight="900" fill="#f59e0b" text-anchor="middle" font-family="Cairo,sans-serif">ET</text>' +
      '</svg>';

    if (!labelText) return svg;
    return '<div style="display:inline-flex;flex-direction:column;align-items:center;gap:2px;text-align:center">' +
      svg +
      '<span style="font-size:9px;font-weight:800;color:#0f172a;font-family:Cairo,sans-serif">' + esc(labelText) + '</span>' +
    '</div>';
  }

  function buildOfficialPrintBrandBanner(docTitle, targetUrl) {
    var qrSvg = generateQrSvg(targetUrl || location.href, 66, "امسح للتطبيق التفاعلي");
    return '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 14px;margin-bottom:10px;border-radius:12px;background:linear-gradient(90deg,#071324 0%,#0f172a 60%,#1e293b 100%);color:#f8fafc;border-bottom:3px solid #f59e0b;font-family:Cairo,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact">' +
      '<div style="text-align:right">' +
        '<div style="font-size:14px;font-weight:900;color:#fbbf24">🇵🇸 منصة EduTech Mindset | عقلية التعليم والتكنولوجيا</div>' +
        '<div style="font-size:11px;font-weight:700;color:#e2e8f0;margin-top:2px">بإشراف المؤسس والمدير: <b>الأستاذ باسل أشرف الفقعاوي</b> • مبادرة توجيهي فلسطين وغزة التعليمية</div>' +
        (docTitle ? '<div style="font-size:10.5px;color:#38bdf8;margin-top:2px">📄 ' + esc(docTitle) + '</div>' : '') +
      '</div>' +
      '<div style="background:#ffffff;padding:4px 6px;border-radius:10px;flex-shrink:0">' + qrSvg + '</div>' +
    '</div>';
  }

  window.EduQR = {
    svg: generateQrSvg,
    brandBanner: buildOfficialPrintBrandBanner
  };

  // ==========================================================================
  // المحور (5): الربط المباشر مع تليجرام وواتساب (Telegram Bot API & Broadcast)
  // ==========================================================================
  var TG_KEY = "edutech_telegram_cfg_v146";

  function getTgConfig() {
    try {
      return JSON.parse(localStorage.getItem(TG_KEY) || "null") || {
        botToken: "",
        chatId: "@edutech_mindset",
        channelTitle: "مجموعة وقناة EduTech Mindset & توجيهي فلسطين",
        autoFooter: "🌐 عبر منصة EduTech Mindset — بإشراف أ. باسل أشرف الفقعاوي"
      };
    } catch (e) {
      return { botToken: "", chatId: "@edutech_mindset", channelTitle: "EduTech Mindset", autoFooter: "" };
    }
  }

  function saveTgConfig(cfg) {
    try { localStorage.setItem(TG_KEY, JSON.stringify(cfg)); } catch (e) {}
  }

  function sendTelegramMessage(title, bodyText, linkUrl) {
    var cfg = getTgConfig();
    var targetLink = linkUrl || location.href;
    var fullMessage = "📢 *" + String(title || "إعلان جديد من منصة EduTech Mindset") + "*\n\n" +
      String(bodyText || "") + "\n\n" +
      "🔗 *الرابط المباشر:* " + targetLink + "\n" +
      "✨ " + (cfg.autoFooter || "منصة EduTech Mindset — بإشراف أ. باسل أشرف الفقعاوي");

    if (cfg.botToken && cfg.chatId && cfg.botToken.indexOf(":") !== -1) {
      var apiUrl = "https://api.telegram.org/bot" + encodeURIComponent(cfg.botToken.trim()) + "/sendMessage";
      return fetch(apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: cfg.chatId.trim(),
          text: fullMessage.replace(/\*/g, ""),
          disable_web_page_preview: false
        })
      }).then(function (r) { return r.json(); }).then(function (res) {
        if (res && res.ok) {
          toast("✅ تم النشر التلقائي المباشر في قناة/مجموعة تليجرام (" + cfg.chatId + ") بنجاح!", "success");
          return true;
        }
        throw new Error((res && res.description) || "Telegram API Error");
      }).catch(function () {
        var shareUrl = "https://t.me/share/url?url=" + encodeURIComponent(targetLink) + "&text=" + encodeURIComponent(fullMessage.replace(/\*/g, ""));
        window.open(shareUrl, "_blank", "noopener");
        toast("📲 تم فتح نافذة النشر السريع إلى تليجرام", "info");
        return false;
      });
    } else {
      var shareUrl2 = "https://t.me/share/url?url=" + encodeURIComponent(targetLink) + "&text=" + encodeURIComponent(fullMessage.replace(/\*/g, ""));
      window.open(shareUrl2, "_blank", "noopener");
      toast("📲 تم تجهيز الرسالة للنشر الفوري على تليجرام", "success");
      return Promise.resolve(true);
    }
  }

  function openTelegramBroadcastModal(presetTitle, presetBody, presetLink) {
    if (typeof showModalContent !== "function") {
      sendTelegramMessage(presetTitle, presetBody, presetLink);
      return;
    }
    var cfg = getTgConfig();
    var pTitle = presetTitle || "تنويه هام من منصة EduTech Mindset";
    var pBody = presetBody || "ندعوكم للاطلاع على الدرس التفاعلي الجديد وحل التدريبات وأوراق العمل المتاحة الآن على المنصة.";
    var pLink = presetLink || location.href;

    var html =
      '<div class="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-gradient-to-l from-sky-900 via-indigo-950 to-slate-900 text-white">' +
        '<div>' +
          '<h3 class="text-sm sm:text-base font-black">📡 مركز النشر التلقائي إلى تليجرام وواتساب (Telegram Bot & Broadcast)</h3>' +
          '<p class="text-[11px] text-sky-200">انشر الإعلانات وأوراق العمل والاختبارات بضغطة زر إلى مجموعة تليجرام أو واتساب مع رمز QR</p>' +
        '</div>' +
        '<button type="button" class="p-2 text-slate-300 hover:text-white" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button>' +
      '</div>' +
      '<div class="p-4 sm:p-5 space-y-4 text-right overflow-y-auto max-h-[80vh]">' +
        '<div class="grid grid-cols-1 md:grid-cols-3 gap-3 items-center p-3.5 rounded-2xl bg-sky-500/10 border border-sky-500/30">' +
          '<div class="md:col-span-2 space-y-1.5">' +
            '<div class="text-xs font-black text-sky-700 dark:text-sky-300">🤖 إعدادات الربط التلقائي مع بوت تليجرام (اختياري للإرسال المباشر بلا نوافذ):</div>' +
            '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2">' +
              '<input id="tgBotTokenInp" type="password" dir="ltr" value="' + esc(cfg.botToken || "") + '" placeholder="Bot Token (مثال: 123456:ABC-DEF...)" class="w-full text-xs font-mono px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700">' +
              '<input id="tgChatIdInp" type="text" dir="ltr" value="' + esc(cfg.chatId || "@edutech_mindset") + '" placeholder="معرف القناة/المجموعة: @edutech_mindset" class="w-full text-xs font-mono px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700">' +
            '</div>' +
            '<p class="text-[10px] text-slate-500 dark:text-slate-400">💡 إذا تركت رمز البوت فارغاً، فسيفتح زر النشر تطبيق تليجرام مباشرة مع الرسالة المنسقة جاهزة للإرسال.</p>' +
          '</div>' +
          '<div class="flex flex-col items-center justify-center p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">' +
            generateQrSvg(pLink, 80, "رمز QR للرابط") +
          '</div>' +
        '</div>' +

        '<div class="space-y-2.5">' +
          '<div>' +
            '<label class="block text-xs font-black mb-1">📌 عنوان الإعلان أو الواجب:</label>' +
            '<input id="tgMsgTitleInp" type="text" value="' + esc(pTitle) + '" class="w-full text-xs font-bold px-3.5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700">' +
          '</div>' +
          '<div>' +
            '<label class="block text-xs font-black mb-1">📝 نص الرسالة الموجهة للطلبة أو المعلمين:</label>' +
            '<textarea id="tgMsgBodyInp" rows="3" class="w-full text-xs font-bold px-3.5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700">' + esc(pBody) + '</textarea>' +
          '</div>' +
          '<div>' +
            '<label class="block text-xs font-black mb-1">🔗 الرابط المرفق:</label>' +
            '<input id="tgMsgLinkInp" type="text" dir="ltr" value="' + esc(pLink) + '" class="w-full text-xs font-mono px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700">' +
          '</div>' +
        '</div>' +

        '<div class="flex flex-wrap gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">' +
          '<button type="button" id="btnTgSendNow" class="px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-black shadow-md flex items-center gap-1.5"><i class="fa-brands fa-telegram text-sm"></i><span>نشر فوري إلى تليجرام</span></button>' +
          '<button type="button" id="btnWaSendNow" class="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow-md flex items-center gap-1.5"><i class="fa-brands fa-whatsapp text-sm"></i><span>مشاركة عبر واتساب</span></button>' +
          '<button type="button" id="btnTgCopyFormatted" class="px-3.5 py-2.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-extrabold">📋 نسخ الرسالة المنسقة</button>' +
        '</div>' +
      '</div>';

    showModalContent(html);

    function syncCfgFromModal() {
      var nc = getTgConfig();
      if ($("tgBotTokenInp")) nc.botToken = $("tgBotTokenInp").value.trim();
      if ($("tgChatIdInp")) nc.chatId = $("tgChatIdInp").value.trim() || "@edutech_mindset";
      saveTgConfig(nc);
      return {
        title: $("tgMsgTitleInp") ? $("tgMsgTitleInp").value.trim() : pTitle,
        body: $("tgMsgBodyInp") ? $("tgMsgBodyInp").value.trim() : pBody,
        link: $("tgMsgLinkInp") ? $("tgMsgLinkInp").value.trim() : pLink
      };
    }

    if ($("btnTgSendNow")) {
      $("btnTgSendNow").onclick = function () {
        var m = syncCfgFromModal();
        sendTelegramMessage(m.title, m.body, m.link);
      };
    }
    if ($("btnWaSendNow")) {
      $("btnWaSendNow").onclick = function () {
        var m = syncCfgFromModal();
        var txt = "📢 *" + m.title + "*\n\n" + m.body + "\n\n🔗 الرابط: " + m.link + "\n✨ منصة EduTech Mindset — بإشراف أ. باسل أشرف الفقعاوي";
        window.open("https://wa.me/?text=" + encodeURIComponent(txt), "_blank", "noopener");
      };
    }
    if ($("btnTgCopyFormatted")) {
      $("btnTgCopyFormatted").onclick = function () {
        var m = syncCfgFromModal();
        var txt = "📢 " + m.title + "\n\n" + m.body + "\n\n🔗 الرابط: " + m.link + "\n✨ منصة EduTech Mindset — بإشراف أ. باسل أشرف الفقعاوي";
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(txt).then(function () { toast("تم نسخ الرسالة المنسقة بنجاح 📋", "success"); });
        }
      };
    }
  }

  window.EduTelegram = {
    openModal: openTelegramBroadcastModal,
    send: sendTelegramMessage,
    getConfig: getTgConfig,
    saveConfig: saveTgConfig
  };

  // ==========================================================================
  // المحور (1): مختبر شخصيات الفريق التعليمي الذكي (#teamPersonasStudio)
  // ==========================================================================
  var TEAM_PERSONAS = [
    {
      id: "basel",
      name: "الأستاذ باسل أشرف الفقعاوي",
      role: "مؤسس ومدير EduTech Mindset • خبير الذكاء الاصطناعي التربوي وإشراف توجيهي فلسطين",
      subject: "تكنولوجيا التعليم والذكاء الاصطناعي والتفوق الدراسي",
      lang: "ar-SA",
      badge: "👑 قائد المبادرة ومدرب الـ AI",
      gradient: "from-slate-900 via-blue-950 to-amber-900",
      avatarBg: "bg-gradient-to-br from-amber-400 via-sky-600 to-slate-900",
      visualSpec: "قميص رسمي أبيض، كنزة صوفية رمادية مضفرة، بنطال كحلي داكن — استوديو المكتب الخشبي المضاء بـ LED دافئ والكرة الأرضية الزرقاء.",
      greeting: "أهلاً بك في استوديو EduTech Mindset! أنا أ. باسل الفقعاوي؛ يسعدني مساعدتك في تصميم خطط الدروس الذكية، صياغة البرومبتات الاحترافية، أو وضع خطة تفوق محكمة لطلبة التوجيهي الفلسطيني.",
      presets: [
        "صمّم لي خطة توظيف الذكاء الاصطناعي في حصة علوم للصف الرابع بغزة",
        "اكتب لي جدول مراجعة مكثف لفيزياء وأحياء التوجيهي الفلسطيني",
        "أعطني 5 برومبتات احترافية للمعلم لإعداد اختبارات تراعي الفروق الفردية",
        "كيف أحوّل درسي التقليدي إلى نشاط تفاعلي شبيه بـ Curipod وWordwall؟"
      ]
    },
    {
      id: "sabreen",
      name: "المعلمة صابرين أمين",
      role: "معلمة الرياضيات في فريق EduTech Mindset",
      subject: "الرياضيات والهندسة والتفاضل والتكامل",
      lang: "ar-SA",
      badge: "📐 خبيرة تبسيط الرياضيات",
      gradient: "from-orange-800 via-amber-900 to-slate-900",
      avatarBg: "bg-gradient-to-br from-orange-500 to-amber-700",
      visualSpec: "حجاب بيج/أوف وايت مع عصبة رأس سوداء وثوب بلون التيراكوتا الدافئ — متخصصة في الشرح البصري المتدرج للمسائل الرياضية.",
      greeting: "مرحباً بك يا بطل! أنا المعلمة صابرين أمين، معلمة الرياضيات في فريق EduTech Mindset. أكتب لي أي مسألة جبرية، معادلة تربيعية، أو سؤال تفاضل وتكامل وسأحله معك خطوة بخطوة مع القاعدة والتحقق!",
      presets: [
        "اشرحي لي خطوات حل المعادلة التربيعية س² - 5س + 6 = 0 مع التحقق",
        "كيف أجد المشتقة الأولى والقيم القصوى للاقتران في توجيهي فلسطين؟",
        "بسّطي لطلبة المرحلة الأساسية مفهوم الكسور المتكافئة وتوحيد المقامات",
        "اشرحي قانون المسافة بين نقطتين ومعادلة الدائرة مع مثال تطبيقي"
      ]
    },
    {
      id: "bayan",
      name: "المعلمة بيان",
      role: "معلمة اللغة العربية في فريق EduTech Mindset",
      subject: "اللغة العربية (النحو، الإعراب، التشكيل الكامل، البلاغة)",
      lang: "ar-SA",
      badge: "📖 خبيرة الفصحى والتشكيل",
      gradient: "from-sky-900 via-indigo-950 to-slate-900",
      avatarBg: "bg-gradient-to-br from-sky-500 to-indigo-800",
      visualSpec: "حجاب أبيض ناصع، وشاح عنق كحلي، ثوب كحلي مطرز، وسترة رمادية داكنة — متخصصة في الإعراب وضبط التشكيل الكامل.",
      greeting: "أَهْلاً وَسَهْلاً بِكَ فِي رِحَابِ لُغَتِنَا العَرَبِيَّةِ الخَالِدَةِ! أَنَا المُعَلِّمَةُ بَيَان، أُسَاعِدُكَ فِي إِعْرَابِ الجُمَلِ إِعْرَاباً تَفْصِيلِيّاً، وَضَبْطِ النُّصُوصِ بِالتَّشْكِيلِ الكَامِلِ، وَشَرْحِ قَوَاعِدِ النَّحْوِ وَالبَلاغَةِ.",
      presets: [
        "أعربي لي جملة: «يَصْنَعُ طُلَّابُ فِلَسْطِينَ الأَمَلَ بِالعِلْمِ وَالإِبْدَاعِ» إعراباً كاملاً",
        "اضبطي فقرة قصيرة عن الصمود والأمل بالتشكيل الكامل مع استخراج المشتقات",
        "ما الفرق بين كان التامة وكان الناقصة مع أمثلة مشكولة؟",
        "اشرحي قواعد الهمزة المتوسطة والمتطرفة لطلبة المرحلة الأساسية"
      ]
    },
    {
      id: "layan",
      name: "المعلمة ليان (Teacher Layan)",
      role: "معلمة اللغة الإنجليزية في فريق EduTech Mindset",
      subject: "اللغة الإنجليزية (Grammar, Vocabulary, Writing & Tawjihi English)",
      lang: "en-US",
      badge: "🌍 English & Communication Specialist",
      gradient: "from-rose-900 via-purple-950 to-slate-900",
      avatarBg: "bg-gradient-to-br from-rose-500 to-indigo-800",
      visualSpec: "حجاب بيج أنيق وثوب كحلي مطرز باللون العنابي/التيراكوتا — متخصصة في تبسيط قواعد الإنجليزية والمحادثة والكتابة.",
      greeting: "Hello and welcome! أنا المعلمة ليان، معلمة اللغة الإنجليزية في فريق EduTech Mindset. أسعد بمساعدتك في شرح قواعد الإنجليزية (Tenses & Passive Voice)، كتابة الفقرات والمقالات، وتقوية مفردات المنهاج الفلسطيني والتوجيهي!",
      presets: [
        "اشرحي الفرق بين Present Perfect و Past Simple مع أمثلة مترجمة لطلبة التوجيهي",
        "اكتبي فقرة نموذجية (Paragraph) عن دور التكنولوجيا والذكاء الاصطناعي في التعليم مع الترجمة",
        "كيف نحول الجملة من المبني للمعلوم (Active) إلى المبني للمجهول (Passive Voice)؟",
        "أعطني أهم 15 كلمة إنجليزية أكاديمية لطلبة التوجيهي مع جمل تطبيقية"
      ]
    }
  ];

  var personaState = {
    activeId: "basel",
    query: "",
    lastAnswer: ""
  };

  function generateOfflinePersonaResponse(p, qText) {
    var q = String(qText || "").trim() || p.presets[0];
    if (p.id === "sabreen") {
      return "📐 **شرح وحل المعلمة صابرين أمين (معلمة الرياضيات — EduTech Mindset):**\n\n" +
        "🔹 **السؤال المطروح:** «" + q + "»\n\n" +
        "1️⃣ **تحديد المعطيات والقاعدة الرياضية:**\n" +
        "• نقوم أولاً بترتيب الحدود الجبرية في الصورة القياسية وتحديد المعاملات الأساسية.\n" +
        "• إذا كانت معادلة تربيعية $ax^2 + bx + c = 0$ نبحث عن عددين حاصل ضربهما $c$ ومجموعهما $b$، أو نطبق القانون العام: $x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$.\n\n" +
        "2️⃣ **خطوات الحل بالتفصيل:**\n" +
        "• الخطوة الأولى: تحليل العبارة أو تعويض القيم في القانون المعتمد.\n" +
        "• الخطوة الثانية: إيجاد قيم المتغير المجهول وتبسيط الكسور أو الجذور لأبسط صورة.\n" +
        "• الخطوة الثالثة (التحقق من صحة الحل ✓): نعوّض الجذور الناتجة في المعادلة الأصلية للتأكد من تساوي الطرفين الأيمن والأيسر.\n\n" +
        "💡 **نصيحة المعلمة صابرين:** ارسم دائماً خط الأعداد أو المنحنى التقريبي في مختبر المحاكاة لتتأكد بصرياً من إشارات الاقتران ونقاط التقاطع!";
    }
    if (p.id === "bayan") {
      return "📖 **شَرْحُ وَإِعْرَابُ المُعَلِّمَةِ بَيَان (مُعَلِّمَةُ اللُّغَةِ العَرَبِيَّةِ — EduTech Mindset):**\n\n" +
        "🔹 **النَّصُّ أَوِ السُّؤَالُ:** «" + q + "»\n\n" +
        "1️⃣ **الضَّبْطُ اللُّغَوِيُّ وَالتَّشْكِيلُ الكَامِلُ:**\n" +
        "«يَصْنَعُ طُلَّابُ فِلَسْطِينَ الأَمَلَ بِالعِلْمِ وَالإِبْدَاعِ، وَيَبْنُونَ مُسْتَقْبَلاً مُشْرِقاً بِإِرَادَةٍ لَا تَلِينُ.»\n\n" +
        "2️⃣ **الإِعْرَابُ النَّحْوِيُّ التَّفْصِيلِيُّ:**\n" +
        "• **يَصْنَعُ:** فِعْلٌ مُضَارِعٌ مَرْفُوعٌ وَعَلَامَةُ رَفْعِهِ الضَّمَّةُ الظَّاهِرَةُ عَلَى آخِرِهِ.\n" +
        "• **طُلَّابُ:** فَاعِلٌ مَرْفُوعٌ وَعَلَامَةُ رَفْعِهِ الضَّمَّةُ الظَّاهِرَةُ، وَهُوَ مُضَافٌ.\n" +
        "• **فِلَسْطِينَ:** مُضَافٌ إِلَيْهِ مَجْرُورٌ وَعَلَامَةُ جَرِّهِ الفَتْحَةُ عِوَضاً عَنِ الكَسْرَةِ لِأَنَّهُ مَمْنُوعٌ مِنَ الصَّرْفِ (عَلَمٌ مُؤَنَّثٌ).\n" +
        "• **الأَمَلَ:** مَفْعُولٌ بِهِ مَنْصُوبٌ وَعَلَامَةُ نَصْبِهِ الفَتْحَةُ الظَّاهِرَةُ عَلَى آخِرِهِ.\n" +
        "• **بِالعِلْمِ:** البَاءُ حَرْفُ جَرٍّ مَبْنِيٌّ لَا مَحَلَّ لَهُ مِنَ الإِعْرَابِ، وَالعِلْمِ: اسْمٌ مَجْرُورٌ وَعَلَامَةُ جَرِّهِ الكَسْرَةُ الظَّاهِرَةُ.\n\n" +
        "✨ **إِضَاءَةٌ بَلَاغِيَّةٌ:** فِي عِبَارَةِ «يَصْنَعُ الأَمَلَ» اسْتِعَارَةٌ مَكْنِيَّةٌ صَوَّرَتِ الأَمَلَ شَيْئاً مَادِّيّاً يُصْنَعُ، وَسِرُّ جَمَالِهَا التَّجْسِيمُ.";
    }
    if (p.id === "layan") {
      return "🌍 **Teacher Layan's English Lesson (EduTech Mindset):**\n\n" +
        "🔹 **Topic / Question:** \"" + q + "\"\n\n" +
        "1️⃣ **Grammar & Structure Rule (القاعدة المنهجية):**\n" +
        "• **Present Perfect (`have/has + V3`):** Used for actions that started in the past and have a clear result or connection to the present (Keywords: *already, just, yet, since, for, recently*).\n" +
        "• **Past Simple (`V2 / -ed`):** Used for completed actions at a specific time in the past (Keywords: *yesterday, last week, in 2024, ago*).\n\n" +
        "2️⃣ **Model Examples & Paragraph (أمثلة وفقرة تطبيقية):**\n" +
        "• *Example 1:* \"Palestinian students **have achieved** remarkable success in educational technology recently.\"\n" +
        "• *Example 2:* \"Technology and Artificial Intelligence play a vital role in modern education. They help teachers personalize lessons and enable students to explore complex scientific concepts interactively.\"\n\n" +
        "💡 **Teacher Layan's Tip:** Always check the time indicator in the sentence before choosing the verb tense in your Tawjihi exam!";
    }
    return "👑 **توجيهات الأستاذ باسل أشرف الفقعاوي (مؤسس ومدير EduTech Mindset):**\n\n" +
      "🔹 **الموضوع:** «" + q + "»\n\n" +
      "1️⃣ **خطة التوظيف التربوي والتقني في الحصة:**\n" +
      "• **التمهيد الذكي (5 دقائق):** عرض سؤال استكشافي أو فيديو موشن جرافيك قصير (9:16) لإثارة دافعية الطلبة وربط الدرس بواقعهم.\n" +
      "• **التطبيق التفاعلي (20 دقيقة):** استخدام استوديوهات المنصة وأدوات الذكاء الاصطناعي (مثل MagicSchool وCuripod ومختبر المحاكاة) لتوليد أنشطة متدرجة تراعي الفروق الفردية.\n" +
      "• **التقويم الختامي (10 دقائق):** توليد ورقة عمل مزودة برمز QR ومشاركتها فوراً مع الطلبة وأولياء الأمور عبر مجموعة تليجرام.\n\n" +
      "2️⃣ **البرومبت الاحترافي الجاهز للنسخ:**\n" +
      "«أنت معلم خبير في المنهاج الفلسطيني؛ صمّم لي نشاطاً تفاعلياً لدرس (" + q + ") يتضمن 3 مستويات متدرجة، سؤال تفكير ناقد، وبطاقة خروج سريعة مع الإجابات النموذجية المشكولة.»";
  }

  function renderTeamPersonasStudio() {
    var sec = $("teamPersonasStudio");
    if (!sec) {
      var anchor = $("tutorStudio") || $("learnSection") || $("booksSection");
      if (!anchor || !anchor.parentNode) return false;
      sec = document.createElement("section");
      sec.id = "teamPersonasStudio";
      sec.className = "py-10 scroll-mt-20";
      anchor.parentNode.insertBefore(sec, anchor.nextSibling);
    }

    var activeP = TEAM_PERSONAS.filter(function (x) { return x.id === personaState.activeId; })[0] || TEAM_PERSONAS[0];
    if (!personaState.lastAnswer) {
      personaState.lastAnswer = generateOfflinePersonaResponse(activeP, activeP.presets[0]);
    }

    sec.innerHTML =
      '<div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-right" dir="rtl">' +
        '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-2xl overflow-hidden">' +
          '<div class="p-5 sm:p-6 bg-gradient-to-l ' + activeP.gradient + ' text-white">' +
            '<div class="flex flex-wrap items-center justify-between gap-3">' +
              '<div>' +
                '<div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-black mb-1.5">' +
                  '<span>👨‍🏫👩‍🏫 مختبر شخصيات الفريق التعليمي الذكي — EduTech Mindset</span>' +
                '</div>' +
                '<h2 class="text-xl sm:text-2xl font-black">تعلّم وحاور فريق معلمي المنصة بالصوت والنص</h2>' +
                '<p class="text-xs text-slate-200 mt-1">اختر الأستاذ باسل الفقعاوي، أو المعلمة صابرين أمين (الرياضيات)، أو المعلمة بيان (اللغة العربية والتشكيل)، أو المعلمة ليان (اللغة الإنجليزية)</p>' +
              '</div>' +
              '<button type="button" id="btnPersonaShareTg" class="px-3.5 py-2 rounded-xl bg-sky-500/25 hover:bg-sky-500 text-white border border-sky-400/40 text-xs font-black transition flex items-center gap-1.5">' +
                '<i class="fa-brands fa-telegram"></i><span>مشاركة لتليجرام</span>' +
              '</button>' +
            '</div>' +
          '</div>' +

          '<div class="p-4 sm:p-6 space-y-5">' +
            // بطاقات اختيار شخصية المعلم/ـة
            '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">' +
              TEAM_PERSONAS.map(function (tp) {
                var isOn = tp.id === activeP.id;
                return '<button type="button" data-persona-pick="' + tp.id + '" class="text-right p-3.5 rounded-2xl border-2 transition-all flex flex-col justify-between ' +
                  (isOn ? "border-amber-400 bg-amber-500/10 shadow-lg scale-[1.01]" : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/90 hover:border-brand-500") + '">' +
                  '<div class="flex items-center gap-3">' +
                    '<div class="w-12 h-12 rounded-2xl ' + tp.avatarBg + ' text-white font-black text-lg flex items-center justify-center shrink-0 shadow-md">' +
                      (tp.id === "basel" ? "👨‍🏫" : "👩‍🏫") +
                    '</div>' +
                    '<div class="min-w-0 flex-1">' +
                      '<div class="text-xs font-black text-slate-900 dark:text-white truncate">' + esc(tp.name) + '</div>' +
                      '<div class="text-[10px] font-extrabold text-brand-600 dark:text-sky-300 mt-0.5">' + esc(tp.badge) + '</div>' +
                    '</div>' +
                  '</div>' +
                  '<div class="text-[10px] text-slate-500 dark:text-slate-400 mt-2 line-clamp-2">' + esc(tp.subject) + '</div>' +
                '</button>';
              }).join("") +
            '</div>' +

            // بطاقة تعريف المعلم المختار والترحيب الصوتي
            '<div class="p-4 rounded-2xl bg-slate-100/90 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2">' +
              '<div class="flex flex-wrap items-center justify-between gap-2">' +
                '<div>' +
                  '<h3 class="text-sm sm:text-base font-black text-slate-900 dark:text-white">' + esc(activeP.name) + ' — <span class="text-brand-600 dark:text-amber-300 text-xs">' + esc(activeP.role) + '</span></h3>' +
                  '<p class="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">🎬 الهوية البصرية في الاستوديو: ' + esc(activeP.visualSpec) + '</p>' +
                '</div>' +
                '<button type="button" id="btnPersonaSpeakGreeting" class="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-black shadow flex items-center gap-1.5">' +
                  '<i class="fa-solid fa-volume-high"></i><span>استمع للترحيب الصوتي</span>' +
                '</button>' +
              '</div>' +
              '<div class="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-700 text-xs font-bold leading-relaxed text-slate-700 dark:text-slate-200">' +
                '💬 «' + esc(activeP.greeting) + '»' +
              '</div>' +
            '</div>' +

            // أسئلة سريعة مقترحة حسب تخصص المعلم
            '<div class="space-y-2">' +
              '<div class="text-xs font-black text-slate-700 dark:text-slate-300">⚡ اختر سؤالاً تطبيقياً سريعاً أو اكتب سؤالك بالأسفل:</div>' +
              '<div class="flex flex-wrap gap-2">' +
                activeP.presets.map(function (pr) {
                  return '<button type="button" data-persona-preset="' + esc(pr) + '" class="px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-brand-600 hover:text-white border border-slate-300 dark:border-slate-700 transition">' + esc(pr) + '</button>';
                }).join("") +
              '</div>' +
            '</div>' +

            // مربع إدخال السؤال وتوليد الشرح
            '<div class="space-y-2.5">' +
              '<textarea id="personaQuestionInp" rows="3" class="w-full text-xs sm:text-sm font-bold p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 outline-none focus:border-brand-500" placeholder="اكتب سؤالك أو الجملة المراد إعرابها أو المسألة الرياضية هنا ليجيبك ' + esc(activeP.name) + '...">' + esc(personaState.query) + '</textarea>' +
              '<div class="flex flex-wrap items-center gap-2">' +
                '<button type="button" id="btnPersonaAskNow" class="px-5 py-2.5 rounded-xl bg-gradient-to-l from-brand-600 to-indigo-600 hover:opacity-95 text-white text-xs font-black shadow-md">🤖 اطلب الشرح التفصيلي من ' + esc(activeP.name) + '</button>' +
                '<button type="button" id="btnPersonaReadAnswer" class="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow">🔊 قراءة الشرح صوتياً</button>' +
                '<button type="button" id="btnPersonaPrintCard" class="px-4 py-2.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-extrabold">🖨️ طباعة بطاقة الشرح مع QR</button>' +
              '</div>' +
            '</div>' +

            // صندوق الإجابة والشرح
            '<div id="personaAnswerBox" class="p-4 sm:p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/90 border-2 border-brand-500/30 text-xs sm:text-sm leading-relaxed whitespace-pre-line font-bold text-slate-800 dark:text-slate-100">' +
              esc(personaState.lastAnswer) +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';

    sec.querySelectorAll("[data-persona-pick]").forEach(function (b) {
      b.onclick = function () {
        personaState.activeId = b.getAttribute("data-persona-pick");
        var np = TEAM_PERSONAS.filter(function (x) { return x.id === personaState.activeId; })[0] || TEAM_PERSONAS[0];
        personaState.query = np.presets[0];
        personaState.lastAnswer = generateOfflinePersonaResponse(np, np.presets[0]);
        renderTeamPersonasStudio();
      };
    });

    sec.querySelectorAll("[data-persona-preset]").forEach(function (b) {
      b.onclick = function () {
        var qTxt = b.getAttribute("data-persona-preset");
        personaState.query = qTxt;
        if ($("personaQuestionInp")) $("personaQuestionInp").value = qTxt;
        askActivePersona(qTxt);
      };
    });

    if ($("btnPersonaSpeakGreeting")) {
      $("btnPersonaSpeakGreeting").onclick = function () {
        if (window.EduVoice && window.EduVoice.read) window.EduVoice.read(activeP.greeting, activeP.lang);
      };
    }

    if ($("btnPersonaReadAnswer")) {
      $("btnPersonaReadAnswer").onclick = function () {
        if (window.EduVoice && window.EduVoice.read) window.EduVoice.read(personaState.lastAnswer.replace(/[*#🔹1️⃣2️⃣3️⃣•]/g, ""), activeP.lang);
      };
    }

    if ($("btnPersonaShareTg")) {
      $("btnPersonaShareTg").onclick = function () {
        openTelegramBroadcastModal(
          "شرح من " + activeP.name + " — منصة EduTech Mindset",
          personaState.lastAnswer.slice(0, 600),
          location.origin + location.pathname + "?app=teamPersonasStudio"
        );
      };
    }

    if ($("btnPersonaPrintCard")) {
      $("btnPersonaPrintCard").onclick = function () {
        var w = window.open("", "_blank");
        if (!w) { toast("يرجى السماح بالنوافذ المنبثقة للطباعة", "warning"); return; }
        w.document.write('<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>بطاقة شرح — ' + esc(activeP.name) + '</title>' +
          '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">' +
          '<style>body{font-family:Cairo,sans-serif;margin:16mm;color:#0f172a;line-height:1.9}.box{border:2px solid #cbd5e1;border-radius:14px;padding:16px;background:#f8fafc;white-space:pre-line;font-size:13.5px}</style></head><body>' +
          buildOfficialPrintBrandBanner("بطاقة شرح تعليمية — " + activeP.name, location.origin + location.pathname + "?app=teamPersonasStudio") +
          '<div class="box">' + esc(personaState.lastAnswer) + '</div>' +
          '<script>window.onload=function(){window.print();}</script></body></html>');
        w.document.close();
      };
    }

    function askActivePersona(qStr) {
      var qVal = String(qStr || ($("personaQuestionInp") && $("personaQuestionInp").value) || activeP.presets[0]).trim();
      personaState.query = qVal;
      var btn = $("btnPersonaAskNow");
      var out = $("personaAnswerBox");
      if (btn) { btn.disabled = true; btn.textContent = "⏳ يجهز " + activeP.name + " الشرح التفصيلي..."; }
      var fallbackAns = generateOfflinePersonaResponse(activeP, qVal);
      if (window.AI && typeof window.AI.ask === "function" && navigator.onLine) {
        var sysPrompt = "أنت الآن تتحدث بشخصية «" + activeP.name + "» (" + activeP.role + ") في منصة EduTech Mindset بإشراف أ. باسل أشرف الفقعاوي. تخصصك: " + activeP.subject + ".\n" +
          "أجب عن سؤال الطالب أو المعلم التالي بأسلوب تربوي مشوق ومنظم وواضح (مع ضبط التشكيل الكامل إن كنت المعلمة بيان، والخطوات الرياضية إن كنت المعلمة صابرين، والأمثلة الإنجليزية المترجمة إن كنت المعلمة ليان):\nالسؤال: " + qVal;
        window.AI.ask(sysPrompt, [], "tutor").then(function (resTxt) {
          var clean = String(resTxt || "").trim();
          personaState.lastAnswer = (clean && clean.length > 40) ? clean : fallbackAns;
          if (out) out.textContent = personaState.lastAnswer;
          if (window.EduBadges && window.EduBadges.award) window.EduBadges.award("first_step", 15, true);
        }).catch(function () {
          personaState.lastAnswer = fallbackAns;
          if (out) out.textContent = fallbackAns;
        }).then(function () {
          if (btn) { btn.disabled = false; btn.textContent = "🤖 اطلب الشرح التفصيلي من " + activeP.name; }
        });
      } else {
        personaState.lastAnswer = fallbackAns;
        if (out) out.textContent = fallbackAns;
        if (btn) { btn.disabled = false; btn.textContent = "🤖 اطلب الشرح التفصيلي من " + activeP.name; }
      }
    }

    if ($("btnPersonaAskNow")) {
      $("btnPersonaAskNow").onclick = function () { askActivePersona(); };
    }
    return true;
  }

  window.EduTeamPersonas = {
    open: function (personaId) {
      if (personaId) personaState.activeId = personaId;
      renderTeamPersonasStudio();
      if (window.EduMasterHierarchy && window.EduMasterHierarchy.navigateToTarget) {
        window.EduMasterHierarchy.navigateToTarget("teamPersonasStudio");
      }
    },
    render: renderTeamPersonasStudio
  };

  // ==========================================================================
  // المحور (2): أكاديمية أدوات الذكاء الاصطناعي العالمية للمعلمين (#aiTeacherAcademyStudio)
  // ==========================================================================
  var AI_TOOLS_ACADEMY = [
    {
      id: "magicschool",
      name: "MagicSchool AI",
      arTitle: "المدرسة السحرية للمعلم (تحضير وتفريد وتقارير)",
      ico: "🪄",
      color: "from-purple-700 to-indigo-900",
      desc: "توليد خطط دروس معيارية، أنشطة تفريد التعليم، رسائل أولياء الأمور، ومعايير تقييم في ثوانٍ.",
      sampleTopic: "القصور الدوراني وقانون نيوتن الثاني للدوران — فيزياء توجيهي"
    },
    {
      id: "curipod",
      name: "Curipod",
      arTitle: "الشرائح التفاعلية والعصف الذهني الصفي",
      ico: "🎯",
      color: "from-orange-600 to-rose-800",
      desc: "تصميم شرائح تفاعلية تتضمن سؤال كسر الجليد، سحابة كلمات، استطلاع رأي، وتذكرة خروج.",
      sampleTopic: "نسخ الـ DNA وترجمة الـ mRNA في الريبوسوم — أحياء توجيهي"
    },
    {
      id: "khanmigo",
      name: "Khanmigo",
      arTitle: "المرشد السقراطي الذكي للمعلم والطالب",
      ico: "🦉",
      color: "from-emerald-700 to-teal-900",
      desc: "محاكاة الحوار السقراطي الذي يقود الطالب لاكتشاف الحل بنفسه عبر الأسئلة المتدرجة دون تلقين.",
      sampleTopic: "حل المعادلات التربيعية والمشتقات — الرياضيات"
    },
    {
      id: "diffit",
      name: "Diffit",
      arTitle: "تكييف وتدريج النصوص القرائية لـ 3 مستويات",
      ico: "📚",
      color: "from-sky-700 to-blue-950",
      desc: "تحويل أي درس علمي أو تاريخي إلى 3 مستويات قرائية (تأسيسي، متوسط، متقدم) مع المفردات والأسئلة.",
      sampleTopic: "التفاعلات الكيميائية وحالات المادة — كيمياء الصف الرابع (غزة)"
    },
    {
      id: "brisk",
      name: "Brisk Teaching",
      arTitle: "التغذية الراجعة الفورية وفحص كتابات الطلبة",
      ico: "⚡",
      color: "from-amber-600 to-slate-900",
      desc: "تحليل إجابات الطلبة وتوليد تغذية راجعة ثلاثية (نقاط القوة 🌟، خطوة التحسين 🔧، التحدي القادم 🚀).",
      sampleTopic: "فقرة تعبيرية عن توظيف التكنولوجيا في خدمة المجتمع الفلسطيني"
    }
  ];

  var acadState = {
    activeTool: "magicschool",
    topic: "القصور الدوراني وقانون نيوتن الثاني للدوران — فيزياء توجيهي",
    grade: "الثاني عشر (التوجيهي)",
    teacherName: "أ. باسل أشرف الفقعاوي",
    output: ""
  };

  function buildAcademyToolOutput(toolId, topic, grade) {
    var t = topic || "الدرس المختار";
    var g = grade || "الصف الثاني عشر (التوجيهي)";
    if (toolId === "magicschool") {
      return "🪄 **مخرجات MagicSchool AI (بإشراف أ. باسل الفقعاوي — EduTech Mindset):**\n" +
        "📌 **الموضوع:** " + t + " | **المرحلة:** " + g + "\n\n" +
        "1️⃣ **الأهداف السلوكية الذكية (SMART Objectives):**\n" +
        "• أن يفسّر الطالب المفاهيم والقوانين الأساسية في درس «" + t + "» بدقة علمية.\n" +
        "• أن يطبّق القاعدة المنهجية في حل مسائل ومواقف حياتية جديدة.\n" +
        "• أن يصمّم خريطة مفاهيمية تلخص العلاقات بين المتغيرات.\n\n" +
        "2️⃣ **سير الحصة (45 دقيقة):**\n" +
        "• التهيئة الحافزة (5 د): سؤال عصف ذهني يربط الدرس بالحياة اليومية في فلسطين.\n" +
        "• العرض والنمذجة (15 د): شرح تفاعلي مدعوم بمختبر المحاكاة وفيديو موشن جرافيك 9:16.\n" +
        "• العمل التعاوني المتمايز (15 د): تقسيم الطلبة إلى 3 مجموعات (تأسيسية، تطبيقية، إثرائية).\n" +
        "• الغلق والتقويم (10 د): بطاقة خروج سريعة (Exit Ticket) من 3 أسئلة.\n\n" +
        "3️⃣ **البرومبت الجاهز للنسخ في MagicSchool:**\n" +
        "\"Generate a differentiated 45-minute lesson plan in Arabic for Palestinian curriculum grade (" + g + ") on topic (" + t + ") including warm-up, 3-tier activities, and exit ticket.\"";
    }
    if (toolId === "curipod") {
      return "🎯 **شرائح Curipod التفاعلية الجاهزة للحصة:**\n" +
        "📌 **عنوان العرض التفاعلي:** " + t + " (" + g + ")\n\n" +
        "• **الشريحة 1 (سحابة الكلمات — Word Cloud):** اكتب كلمة واحدة تخطر ببالك عند سماع عنوان درس اليوم «" + t + "».\n" +
        "• **الشريحة 2 (استطلاع رأي — Poll):** أي العوامل التالية تعتقد أنه الأكثر تأثيراً في ظاهرة الدرس؟\n" +
        "• **الشريحة 3 (سؤال مفتوح للنقاش):** اشرح بلغتك الخاصة كيف نطبّق قاعدة الدرس في تجربة عملية.\n" +
        "• **الشريحة 4 (الرسم التفاعلي — Draw It):** ارسم مخططاً مبسطاً يوضح العلاقة بين عناصر الدرس.\n" +
        "• **الشريحة 5 (تذكرة الخروج — Exit Ticket):** لخّص أهم فكرة تعلمتها اليوم في جملة واحدة وسؤال واحد ما زال يدور في ذهنك.";
    }
    if (toolId === "khanmigo") {
      return "🦉 **سيناريو المرشد السقراطي الذكي (Khanmigo Socratic Tutor):**\n" +
        "📌 **الدرس:** " + t + " (" + g + ")\n\n" +
        "• **خطوة 1 (تشخيص الفهم الأولي):** «بدلاً من إعطائك الإجابة مباشرة، دعنا نفكر معاً: ما المعطيات التي تراها أمامك في المسألة؟»\n" +
        "• **خطوة 2 (ربط القانون بالمفهوم):** «أحسنت! الآن أي قانون درسناه يربط بين هذين المتغيرين؟»\n" +
        "• **خطوة 3 (التوجيه عند الخطأ الشائع):** «لاحظ الإشارة أو الوحدة هنا؛ ماذا يحدث لو ضاعفنا القيمة الأولى مع ثبات الثانية؟»\n" +
        "• **خطوة 4 (التحقق الذاتي):** «رائع! توصلت للحل بنفسك. هل يمكنك الآن صياغة سؤال مشابه لزميلك في الصف؟»";
    }
    if (toolId === "diffit") {
      return "📚 **مخرجات Diffit لتكييف المحتوى القرائي إلى 3 مستويات متدرجة:**\n" +
        "📌 **الموضوع:** " + t + " (" + g + ")\n\n" +
        "🟢 **المستوى الأول (التأسيسي المبسّط):**\n" +
        "يركز هذا الدرس على الفكرة الأساسية لـ «" + t + "» بجمل قصيرة وواضحة ومباشرة مع أمثلة محسوسة من بيئة الطالب تساعده على استيعاب المفهوم الأساسي بسهولة.\n\n" +
        "🔵 **المستوى الثاني (المعياري المتوسط):**\n" +
        "يتناول الدرس القوانين والعلاقات السببية في «" + t + "» مع ربط المصطلحات العلمية بتطبيقاتها العملية وحل التدريبات المنهجية المعتمدة.\n\n" +
        "🟣 **المستوى الثالث (الإثرائي المتقدم والتفكير الناقد):**\n" +
        "يحلل الحالات الخاصة والاستنتاجات الرياضية والعلمية العميقة في «" + t + "»، ويطرح مسألة تحدٍّ تربط بين أكثر من وحدة دراسية.\n\n" +
        "📖 **قاموس المفردات المفتاحية:** المفهوم المحوري • المتغير المستقل • المتغير التابع • التطبيق العملي.";
    }
    return "⚡ **تقرير Brisk Teaching للتغذية الراجعة الفورية (Glow, Grow & Goal):**\n" +
      "📌 **المهمة المقيمة:** " + t + " (" + g + ")\n\n" +
      "🌟 **نقاط القوة والتميز (Glow):**\n" +
      "• التزام ممتاز بتسلسل الأفكار العلمية واستخدام المصطلحات الدقيقة الخاصة بالدرس.\n\n" +
      "🔧 **خطوة التحسين المقترحة (Grow):**\n" +
      "• يُنصح بتدعيم الإجابة بمثال تطبيقي إضافي وكتابة وحدات القياس أو الشواهد النصية كاملة في الخطوة النهائية.\n\n" +
      "🚀 **التحدي الإثرائي القادم (Next Step Goal):**\n" +
      "• جرّب تغيير أحد المعاملات في مختبر المحاكاة وفسّر أثر ذلك على النتيجة النهائية في سطرين.";
  }

  function renderAiTeacherAcademyStudio() {
    var sec = $("aiTeacherAcademyStudio");
    if (!sec) {
      var anchor = $("teamPersonasStudio") || $("teacherTools") || $("learnSection");
      if (!anchor || !anchor.parentNode) return false;
      sec = document.createElement("section");
      sec.id = "aiTeacherAcademyStudio";
      sec.className = "py-10 scroll-mt-20";
      anchor.parentNode.insertBefore(sec, anchor.nextSibling);
    }

    var activeT = AI_TOOLS_ACADEMY.filter(function (x) { return x.id === acadState.activeTool; })[0] || AI_TOOLS_ACADEMY[0];
    if (!acadState.output) {
      acadState.output = buildAcademyToolOutput(activeT.id, acadState.topic, acadState.grade);
    }

    sec.innerHTML =
      '<div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-right" dir="rtl">' +
        '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-2xl overflow-hidden">' +
          '<div class="p-5 sm:p-6 bg-gradient-to-l ' + activeT.color + ' text-white">' +
            '<div class="flex flex-wrap items-center justify-between gap-3">' +
              '<div>' +
                '<div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 text-amber-300 text-xs font-black mb-1">' +
                  '<span>🎓 أكاديمية تدريب المعلمين على أدوات الذكاء الاصطناعي العالمية — بإشراف أ. باسل الفقعاوي</span>' +
                '</div>' +
                '<h2 class="text-xl sm:text-2xl font-black">محاكي MagicSchool • Curipod • Khanmigo • Diffit • Brisk Teaching</h2>' +
                '<p class="text-xs text-white/85 mt-1">طبّق مهارات الورشات التدريبية عملياً بالعربية للمنهاج الفلسطيني مع استخراج شهادة إتمام فورية للمعلم</p>' +
              '</div>' +
              '<button type="button" id="btnAcadIssueCert" class="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow-lg flex items-center gap-1.5">' +
                '<span>🏅</span><span>إصدار شهادة إتمام التدريب</span>' +
              '</button>' +
            '</div>' +
          '</div>' +

          '<div class="p-4 sm:p-6 space-y-4">' +
            '<div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">' +
              AI_TOOLS_ACADEMY.map(function (t) {
                var on = t.id === activeT.id;
                return '<button type="button" data-acad-tool="' + t.id + '" class="p-3 rounded-2xl border-2 text-right transition-all ' +
                  (on ? "border-amber-400 bg-amber-500/10 shadow-md" : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/90 hover:border-brand-500") + '">' +
                  '<div class="text-xl mb-1">' + t.ico + '</div>' +
                  '<div class="text-xs font-black text-slate-900 dark:text-white">' + esc(t.name) + '</div>' +
                  '<div class="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2">' + esc(t.arTitle) + '</div>' +
                '</button>';
              }).join("") +
            '</div>' +

            '<div class="grid grid-cols-1 md:grid-cols-3 gap-3 p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">' +
              '<div class="md:col-span-2">' +
                '<label class="block text-xs font-black mb-1">📘 عنوان الدرس أو المهارة المراد تطبيق أداة «' + esc(activeT.name) + '» عليها:</label>' +
                '<input id="acadTopicInp" type="text" value="' + esc(acadState.topic) + '" class="w-full text-xs font-bold px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700">' +
              '</div>' +
              '<div>' +
                '<label class="block text-xs font-black mb-1">🏫 الصف / المرحلة الدراسية:</label>' +
                '<input id="acadGradeInp" type="text" value="' + esc(acadState.grade) + '" class="w-full text-xs font-bold px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700">' +
              '</div>' +
            '</div>' +

            '<div class="flex flex-wrap items-center gap-2">' +
              '<button type="button" id="btnAcadGenerate" class="px-5 py-2.5 rounded-xl bg-gradient-to-l from-indigo-600 to-brand-600 text-white text-xs font-black shadow-md">🚀 توليد نموذج «' + esc(activeT.name) + '» للدرس الآن</button>' +
              '<button type="button" id="btnAcadCopy" class="px-4 py-2.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-extrabold">📋 نسخ النموذج والبرومبت</button>' +
              '<button type="button" id="btnAcadShareTg" class="px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-black">📡 نشر للمعلمين في تليجرام</button>' +
            '</div>' +

            '<div id="acadOutputBox" class="p-4 sm:p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/90 border border-slate-300 dark:border-slate-700 text-xs sm:text-sm leading-relaxed whitespace-pre-line font-bold text-slate-800 dark:text-slate-100">' +
              esc(acadState.output) +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';

    sec.querySelectorAll("[data-acad-tool]").forEach(function (b) {
      b.onclick = function () {
        acadState.activeTool = b.getAttribute("data-acad-tool");
        var tObj = AI_TOOLS_ACADEMY.filter(function (x) { return x.id === acadState.activeTool; })[0] || AI_TOOLS_ACADEMY[0];
        acadState.topic = tObj.sampleTopic;
        acadState.output = buildAcademyToolOutput(tObj.id, acadState.topic, acadState.grade);
        renderAiTeacherAcademyStudio();
      };
    });

    if ($("btnAcadGenerate")) {
      $("btnAcadGenerate").onclick = function () {
        acadState.topic = $("acadTopicInp") ? $("acadTopicInp").value.trim() : acadState.topic;
        acadState.grade = $("acadGradeInp") ? $("acadGradeInp").value.trim() : acadState.grade;
        var fallback = buildAcademyToolOutput(activeT.id, acadState.topic, acadState.grade);
        var btn = $("btnAcadGenerate"), out = $("acadOutputBox");
        if (btn) { btn.disabled = true; btn.textContent = "⏳ يولّد نموذج " + activeT.name + "..."; }
        if (window.AI && typeof window.AI.ask === "function" && navigator.onLine) {
          var p = "أنت مدرب معلمين خبير في أداة «" + activeT.name + "» (" + activeT.arTitle + ") ضمن أكاديمية EduTech Mindset بإشراف أ. باسل أشرف الفقعاوي.\n" +
            "صمّم مخرجات تطبيقية كاملة باللغة العربية لدرس: «" + acadState.topic + "» للصف «" + acadState.grade + "» تحاكي أداة " + activeT.name + " بدقة مع برومبت جاهز للنسخ.";
          window.AI.ask(p, [], "studio").then(function (txt) {
            acadState.output = (txt && txt.length > 40) ? txt : fallback;
            if (out) out.textContent = acadState.output;
          }).catch(function () {
            acadState.output = fallback;
            if (out) out.textContent = fallback;
          }).then(function () {
            if (btn) { btn.disabled = false; btn.textContent = "🚀 توليد نموذج «" + activeT.name + "» للدرس الآن"; }
          });
        } else {
          acadState.output = fallback;
          if (out) out.textContent = fallback;
          if (btn) { btn.disabled = false; btn.textContent = "🚀 توليد نموذج «" + activeT.name + "» للدرس الآن"; }
        }
      };
    }

    if ($("btnAcadCopy")) {
      $("btnAcadCopy").onclick = function () {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(acadState.output).then(function () { toast("تم نسخ مخرجات " + activeT.name + " بنجاح 📋", "success"); });
        }
      };
    }

    if ($("btnAcadShareTg")) {
      $("btnAcadShareTg").onclick = function () {
        openTelegramBroadcastModal(
          "ورشة تطبيق أداة " + activeT.name + " — أكاديمية EduTech Mindset",
          acadState.output.slice(0, 600),
          location.origin + location.pathname + "?app=aiTeacherAcademyStudio"
        );
      };
    }

    if ($("btnAcadIssueCert")) {
      $("btnAcadIssueCert").onclick = function () {
        if (window.EduCertificates && typeof window.EduCertificates.openWithNames === "function") {
          window.EduCertificates.openWithNames(["المعلم/ـة المبدع/ـة"], "إتمام الورشة التدريبية لتوظيف أدوات الذكاء الاصطناعي (MagicSchool, Curipod, Khanmigo, Diffit, Brisk) بإشراف أ. باسل الفقعاوي");
        } else {
          toast("تم تجهيز شهادة التدريب في استوديو الشهادات 🏅", "success");
        }
      };
    }
    return true;
  }

  window.EduAiAcademy = {
    open: function (toolId) {
      if (toolId) acadState.activeTool = toolId;
      renderAiTeacherAcademyStudio();
      if (window.EduMasterHierarchy && window.EduMasterHierarchy.navigateToTarget) {
        window.EduMasterHierarchy.navigateToTarget("aiTeacherAcademyStudio");
      }
    },
    render: renderAiTeacherAcademyStudio
  };

  // ==========================================================================
  // المحور (3): سينما الموشن جرافيك العمودي (9:16 Reels) واستوديو البودكاست (#reelsPodcastStudio)
  // ==========================================================================
  var REELS_SERIES = [
    {
      id: "dna_trans",
      title: "أحياء توجيهي (1): نسخ الـ DNA (DNA Transcription)",
      cat: "أحياء التوجيهي • 9:16",
      color: "#0284c7",
      quizQ: "ما القاعدة النيتروجينية التي تحل محل الثايمين (T) عند بناء سلسلة mRNA أثناء عملية النسخ؟",
      quizOpts: ["اليوراسيل (U)", "الأدينين (A)", "السيتوسين (C)", "الغوانين (G)"],
      quizAns: 0,
      scenes: [
        { title: "المشهد 1: التعرف والارتباط بالمحفز", text: "تَبْدَأُ عَمَلِيَّةُ نَسْخِ الـ DNA عِنْدَمَا يَتَعَرَّفُ إِنْزِيمُ بَلْمَرَةِ RNA عَلَى مِنْطَقَةِ المُحَفِّزِ (Promoter) فِي شَرِيطِ الـ DNA القَالَبِ.", visual: "DNA_PROMOTER" },
        { title: "المشهد 2: فك التواء اللولب المزدوج", text: "يَقُومُ الإِنْزِيمُ بِفَكِّ التِوَاءِ سِلْسِلَتَيِ الـ DNA وَكَسْرِ الرَّوَابِطِ الهِيدْرُوجِينِيَّةِ مَوْضِعِيّاً لِكَشْفِ القَوَاعِدِ النَّيْتْرُوجِينِيَّةِ.", visual: "DNA_UNWIND" },
        { title: "المشهد 3: الاستطالة وإضافة اليوراسيل (U)", text: "يُضِيفُ إِنْزِيمُ بَلْمَرَةِ RNA النُّيُوكْلِيُوتِيدَاتِ المُتَمِّمَةَ بِاتِّجَاهِ (5' ← 3')، مَعَ اسْتِبْدَالِ الثَّايْمِينِ (T) بِاليُورَاسِيلِ (U) مُقَابِلَ الأَدِينِينِ (A).", visual: "RNA_ELONGATE" },
        { title: "المشهد 4: الإنهاء وانفصال mRNA الأولي", text: "عِنْدَ الوُصُولِ إِلَى تَتَابُعِ إِنهَاءِ النَّسْخِ، يَنْفَصِلُ شَرِيطُ mRNA الأَوَّلِيُّ وَيَسْتَعِيدُ الـ DNA شَكْلَهُ الحَلَزُونِيَّ المَزْدَوَجَ.", visual: "RNA_DONE" }
      ]
    },
    {
      id: "mrna_proc",
      title: "أحياء توجيهي (2): معالجة mRNA الأولي (mRNA Processing)",
      cat: "أحياء التوجيهي • 9:16",
      color: "#4f46e5",
      quizQ: "ماذا يحدث للقطع غير المشفرة (الإنترونات Introns) أثناء عملية معالجة mRNA الأولي في النواة؟",
      quizOpts: ["تُقص وتُزال وتُربط الإكسونات الفعالة معاً", "تُترجم مباشرة إلى أحماض أمينية", "تتحول إلى ذيل عديد الأدينين", "تغادر النواة دون تغيير"],
      quizAns: 0,
      scenes: [
        { title: "المشهد 1: إضافة قبعة الغوانين (5' Cap)", text: "تُضَافُ قُبَّعَةُ نُيُوكْلِيُوتِيدِ الغُوَانِينِ المُعَدَّلِ عِنْدَ النِّهَايَةِ (5') لِحِمَايَةِ شَرِيطِ mRNA مِنَ التَّحَلُّلِ وَتَسْهِيلِ ارْتِبَاطِهِ بِالرَّيبُوسُومِ.", visual: "MRNA_CAP" },
        { title: "المشهد 2: إضافة ذيل عديد الأدينين (3' Poly-A)", text: "يُضَافُ ذَيْلٌ مِنْ عَدِيدِ الأَدِينِينِ (50 إِلَى 250 قَاعِدَةَ A) عِنْدَ النِّهَايَةِ (3') لِمُسَاعَدَةِ الجُزَيْءِ عَلَى الخُرُوجِ مِنْ ثُقُوبِ الغِلافِ النَّوَوِيِّ.", visual: "MRNA_TAIL" },
        { title: "المشهد 3: قص الإنترونات وربط الإكسونات", text: "تُزَالُ القِطَعُ غَيْرُ المُشَفِّرَةِ (الإِنْتْرُونَاتُ Introns) وَتُرْبَطُ القِطَعُ الفَعَّالَةُ (الإِكْسُونَاتُ Exons) مَعاً لِيَتَكَوَّنَ mRNA نَاضِجٌ جَاهِزٌ لِلتَّرْجَمَةِ.", visual: "MRNA_SPLICE" }
      ]
    },
    {
      id: "mrna_transl",
      title: "أحياء توجيهي (3): ترجمة mRNA في الريبوسوم (مواقع A / P / E)",
      cat: "أحياء التوجيهي • 9:16",
      color: "#0d9488",
      quizQ: "في أي موقع من مواقع الريبوسوم الثلاثة يستقر جزيء tRNA الحامل للحمض الأميني الأول (الميثيونين AUG) عند بدء الترجمة؟",
      quizOpts: ["الموقع P (موقع الببتيديل)", "الموقع E (موقع الخروج)", "خارج الريبوسوم", "داخل النوية"],
      quizAns: 0,
      scenes: [
        { title: "المشهد 1: كودون البدء AUG ومواقع الريبوسوم (E-P-A)", text: "يَرْتَبِطُ mRNA النَّاضِجُ بِالوَحْدَةِ البِنَائِيَّةِ الصَّغِيرَةِ لِلرَّيبُوسُومِ، وَيَسْتَقِرُ جُزَيْءُ tRNA البَادِئُ الحَامِلُ لِلْمِيثْيُونِينِ عِنْدَ كُودُونِ البَدْءِ (AUG) فِي المَوْقِعِ (P).", visual: "TRANS_INIT" },
        { title: "المشهد 2: استقبال tRNA الجديد في الموقع (A)", text: "يَدْخُلُ جُزَيْءُ tRNA الجَدِيدُ الحَامِلُ لِلْحِمْضِ الأَمِينِيِّ التَّالِي إِلَى المَوْقِعِ (A) حَيْثُ يَتَطَابَقُ كُودُونُهُ المُضَادُّ مَعَ كُودُونِ mRNA.", visual: "TRANS_SITE_A" },
        { title: "المشهد 3: تكوين الرابطة الببتيدية والانتقال", text: "تَتَكَوَّنُ رَابِطَةٌ بِبْتِيدِيَّةٌ بَيْنَ الحِمْضَيْنِ الأَمِينِيَّيْنِ، ثُمَّ يَتَحَرَّكُ الرَّيبُوسُومُ بِمِقْدَارِ كُودُونٍ وَاحِدٍ فَيَخْرُجُ tRNA الفَارِغُ مِنَ المَوْقِعِ (E).", visual: "TRANS_PEPTIDE" },
        { title: "المشهد 4: كودون الإيقاف وتحرر متعدد الببتيد", text: "عِنْدَ وُصُولِ أَحَدِ كُودُونَاتِ الإِيقَافِ (UAA, UAG, UGA) إِلَى المَوْقِعِ (A)، يَرْتَبِطُ عَامِلُ الإِطْلَاقِ وَتَتَحَرَّرُ سِلْسِلَةُ عَدِيدِ البِبْتِيدِ.", visual: "TRANS_STOP" }
      ]
    },
    {
      id: "rot_phys",
      title: "فيزياء توجيهي: القصور الدوراني وقانون نيوتن الثاني للدوران",
      cat: "فيزياء التوجيهي • 9:16",
      color: "#d97706",
      quizQ: "إذا زاد بُعد الكتلة (r) عن محور الدوران إلى الضعف مع ثبات مقدار الكتلة، فإن القصور الدوراني (I = mr²) يصبح:",
      quizOpts: ["أربعة أضعاف قيمته السابقة (4I)", "ضعف قيمته السابقة (2I)", "نصف قيمته السابقة", "يبقى ثابتاً لا يتغير"],
      quizAns: 0,
      scenes: [
        { title: "المشهد 1: مفهوم القصور الدوراني (I = ∑mr²)", text: "القُصُورُ الدَّوَرَانِيُّ (I) هُوَ مِقْيَاسُ مُمَانَعَةِ الجِسْمِ لِلتَّغَيُّرِ فِي حَالَتِهِ الحَرَكِيَّةِ الدَّوَرَانِيَّةِ، وَيَعْتَمِدُ عَلَى كُتْلَةِ الجِسْمِ وَكَيْفِيَّةِ تَوْزِيعِهَا حَوْلَ مِحْوَرِ الدَّوَرَانِ.", visual: "PHYS_INERTIA" },
        { title: "المشهد 2: مقارنة الحلقة المفرغة والقرص المصمت", text: "الحَلْقَةُ المُفَرَّغَةُ (I = mr²) تَمْتَلِكُ قُصُوراً دَوَرَانِيّاً أَكْبَرَ مِنَ القُرْصِ المُصْمَتِ المُمَاثِلِ لَهَا فِي الكُتْلَةِ وَنِصْفِ القُطْرِ (I = ½mr²) لِتَرَكُّزِ كُتْلَتِهَا بَعِيداً عَنِ المِحْوَرِ.", visual: "PHYS_RING_DISK" },
        { title: "المشهد 3: قانون نيوتن الثاني للدوران (∑τ = I·α)", text: "يَتَنَاسَبُ التَّسَارُعُ الزَّاوِيُّ (α) طَرْدِيّاً مَعَ مُحَصِّلَةِ العَزْمِ الخَارِجِيِّ المُؤَثِّرِ (τ) وَعَكْسِيّاً مَعَ القُصُورِ الدَّوَرَانِيِّ (I) وَفْقَ العَلَاقَةِ: τ = I × α.", visual: "PHYS_NEWTON2" }
      ]
    },
    {
      id: "chem_g4_reel",
      title: "كيمياء الصف الرابع (غزة 3D): رحلة الذرات والتفاعلات",
      cat: "المرحلة الأساسية • 9:16",
      color: "#10b981",
      quizQ: "أي من التغيرات التالية يُعدّ تغيراً كيميائياً ينتج عنه مادة جديدة بخصائص مختلفة؟",
      quizOpts: ["اتحاد غاز الهيدروجين والأكسجين لتكوين الماء", "انصهار مكعب الثلج إلى ماء سائل", "تقطيع الورقة إلى أجزاء صغيرة", "ذوبان الملح في الماء"],
      quizAns: 0,
      scenes: [
        { title: "المشهد 1: الذرات بناة الكون الصغار", text: "كُلُّ شَيْءٍ حَوْلَنَا فِي طَبِيعَةِ فِلَسْطِينَ الجَمِيلَةِ يَتَكَوَّنُ مِنْ جُسَيْمَاتٍ دَقِيقَةٍ جِدّاً تُسَمَّى الذَّرَّاتِ، تَتَّحِدُ مَعاً لِتُكَوِّنَ الجُزَيْئَاتِ.", visual: "CHEM_ATOMS" },
        { title: "المشهد 2: حالات المادة الثلاث وحركة الجزيئات", text: "فِي الحَالَةِ الصُّلْبَةِ تَتَرَاصُّ الجُزَيْئَاتُ بِانْتِظَامٍ، وَفِي السَّائِلَةِ تَنْزَلِقُ بِحُرِّيَّةٍ، أَمَّا فِي الغَازِيَّةِ فَتَنْطَلِقُ بِسُرْعَةٍ فِي كُلِّ الاتِّجَاهَاتِ!", visual: "CHEM_STATES" },
        { title: "المشهد 3: التفاعل الكيميائي وتكوين جزيء الماء", text: "عِنْدَمَا تَتَّحِدُ ذَرَّتَا هِيدْرُوجِينٍ (H₂) مَعَ ذَرَّةِ أُكْسِجِينٍ (O) تَتَكَوَّنُ رَوَابِطُ كِيمْيَائِيَّةٌ جَدِيدَةٌ تَمْنَحُنَا قَطْرَةَ المَاءِ سرَّ الحَيَاةِ!", visual: "CHEM_WATER" }
      ]
    }
  ];

  var PODCAST_EPISODES = [
    {
      id: "ep1",
      title: "الحلقة 1: كيف يغيّر الذكاء الاصطناعي مستقبل المعلم الفلسطيني؟",
      hosts: "أ. باسل أشرف الفقعاوي × المعلمة صابرين أمين",
      duration: "03:45",
      script: "أَهْلاً بِكُمْ فِي اسْتُودْيُو بُودْكَاسْت EduTech Mindset، حَيْثُ نَجْتَمِعُ حَوْلَ طَاوِلَتِنَا الخَشَبِيَّةِ المُمَيَّزَةِ وَالكُرَةِ الأَرْضِيَّةِ الزَّرْقَاءِ لِنَصْنَعَ الأَمَلَ بِالعِلْمِ مِنْ غَزَّةَ! فِي هَذِهِ الحَلْقَةِ نَسْتَعْرِضُ كَيْفَ يُمْكِنُ لِلْمُعَلِّمِ الفِلَسْطِينِيِّ اسْتِثْمَارُ أَدَوَاتِ MagicSchool وَCuripod وَمُحَاكِيَاتِ المِنَصَّةِ لِتَوْفِيرِ وَقْتِ التَّحْضِيرِ وَتَحْوِيلِ الحِصَّةِ إِلَى تَجْرِبَةٍ تَفَاعُلِيَّةٍ شَائِقَةٍ."
    },
    {
      id: "ep2",
      title: "الحلقة 2: أسرار التفوق في التوجيهي الفلسطيني (الأحياء والفيزياء والرياضيات)",
      hosts: "أ. باسل الفقعاوي × المعلمة صابرين أمين",
      duration: "04:20",
      script: "مَرْحَباً بِطُلَّابِ التَّوْجِيهِي الفِلَسْطِينِيِّ الأَبْطَالِ! سِرُّ التَّفَوُّقِ فِي مَبَاحِثِ الفِيزْيَاءِ وَالأَحْيَاءِ وَالرِّيَاضِيَّاتِ يَبْدَأُ مِنْ فَهْمِ العَلَاقَاتِ البَصَرِيَّةِ — كَمَوَاقِعِ الرَّيبُوسُومِ (E-P-A) وَقَانُونِ القُصُورِ الدَّوَرَانِيِّ — ثُمَّ التَّدَرُّبِ اليَوْمِيِّ عَلَى أَسْئِلَةِ بَنْكِ الامْتِحَانَاتِ الوِزَارِيَّةِ."
    },
    {
      id: "ep3",
      title: "الحلقة 3: جماليات الفصحى والتشكيل ومهارات اللغة الإنجليزية",
      hosts: "المعلمة بيان × المعلمة ليان",
      duration: "03:30",
      script: "فِي هَذِهِ الحَلْقَةِ الحِوَارِيَّةِ المُمْتِعَةِ، تَلْتَقِي اللُّغَةُ العَرَبِيَّةُ الفُصْحَى بِإِعْرَابِهَا وَتَشْكِيلِهَا الدَّقِيقِ مَعَ مَهَارَاتِ التَّوَاصُلِ بِاللُّغَةِ الإِنْجِلِيزِيَّةِ، لِنُقَدِّمَ لِطُلَّابِنَا خُطَّةً عَمَلِيَّةً لِإِتْقَانِ القِرَاءَةِ وَالكِتَابَةِ وَالتَّعْبِيرِ بِثِقَةٍ وَإِبْدَاعٍ."
    }
  ];

  var reelsState = {
    seriesId: "dna_trans",
    sceneIdx: 0,
    quizAnswered: null,
    activeEpisodeId: "ep1"
  };

  function drawReelVisualSvg(visualCode, colorHex) {
    var col = colorHex || "#0284c7";
    return '<svg viewBox="0 0 270 210" class="w-full h-auto rounded-2xl shadow-inner" style="background:radial-gradient(circle at 50% 35%,#0f172a 0%,#020617 100%)">' +
      '<defs><linearGradient id="rg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="' + col + '"/><stop offset="100%" stop-color="#f59e0b"/></linearGradient></defs>' +
      '<circle cx="135" cy="95" r="62" fill="none" stroke="url(#rg1)" stroke-width="3" stroke-dasharray="8 5"/>' +
      '<circle cx="135" cy="95" r="42" fill="' + col + '" fill-opacity="0.22" stroke="#38bdf8" stroke-width="2"/>' +
      '<text x="135" y="92" fill="#f8fafc" font-size="14" font-weight="900" text-anchor="middle" font-family="Cairo,sans-serif">' + esc(visualCode) + '</text>' +
      '<text x="135" y="114" fill="#fbbf24" font-size="11" font-weight="800" text-anchor="middle" font-family="Cairo,sans-serif">EduTech Mindset 9:16</text>' +
      '<rect x="35" y="172" width="200" height="22" rx="11" fill="#0f172a" stroke="#f59e0b" stroke-width="1.2"/>' +
      '<text x="135" y="187" fill="#fde047" font-size="10" font-weight="800" text-anchor="middle" font-family="Cairo,sans-serif">إشراف أ. باسل أشرف الفقعاوي</text>' +
    '</svg>';
  }

  function renderReelsPodcastStudio() {
    var sec = $("reelsPodcastStudio");
    if (!sec) {
      var anchor = $("aiTeacherAcademyStudio") || $("teamPersonasStudio") || $("learnSection");
      if (!anchor || !anchor.parentNode) return false;
      sec = document.createElement("section");
      sec.id = "reelsPodcastStudio";
      sec.className = "py-10 scroll-mt-20";
      anchor.parentNode.insertBefore(sec, anchor.nextSibling);
    }

    var curSeries = REELS_SERIES.filter(function (x) { return x.id === reelsState.seriesId; })[0] || REELS_SERIES[0];
    var sIdx = Math.min(curSeries.scenes.length - 1, Math.max(0, reelsState.sceneIdx));
    var curScene = curSeries.scenes[sIdx];
    var curEp = PODCAST_EPISODES.filter(function (e) { return e.id === reelsState.activeEpisodeId; })[0] || PODCAST_EPISODES[0];

    sec.innerHTML =
      '<div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-right" dir="rtl">' +
        '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-2xl overflow-hidden">' +
          '<div class="p-5 sm:p-6 bg-gradient-to-l from-slate-950 via-indigo-950 to-amber-950 text-white">' +
            '<div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-black mb-1">' +
              '<span>🎬🎙️ سينما الموشن جرافيك العمودي (9:16 Reels) واستوديو بودكاست EduTech Mindset</span>' +
            '</div>' +
            '<h2 class="text-xl sm:text-2xl font-black">شاهد سلاسل الموشن جرافيك المشكولة بالكامل واستمع لحلقات البودكاست</h2>' +
            '<p class="text-xs text-slate-300 mt-1">سلاسل أحياء وفيزياء التوجيهي وكيمياء الصف الرابع بغزة مع أسئلة تفاعلية فورية وركن البودكاست الحواري</p>' +
          '</div>' +

          '<div class="p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">' +
            // العمود الأيمن: مشغل 9:16 العمودي
            '<div class="lg:col-span-7 space-y-4">' +
              '<div class="flex gap-2 overflow-x-auto pb-1">' +
                REELS_SERIES.map(function (sr) {
                  var on = sr.id === curSeries.id;
                  return '<button type="button" data-reel-series="' + sr.id + '" class="px-3.5 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap shrink-0 border transition ' +
                    (on ? "bg-amber-400 text-slate-950 border-amber-400 shadow font-black" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700") + '">' +
                    '🎬 ' + esc(sr.title) +
                  '</button>';
                }).join("") +
              '</div>' +

              // إطار الهاتف العمودي 9:16
              '<div class="max-w-sm mx-auto rounded-[28px] border-4 border-slate-800 bg-slate-950 text-white p-4 shadow-2xl space-y-3">' +
                '<div class="flex items-center justify-between text-[11px] font-black text-amber-300 border-b border-slate-800 pb-2">' +
                  '<span>📱 ' + esc(curSeries.cat) + '</span>' +
                  '<span>مشهد ' + (sIdx + 1) + ' من ' + curSeries.scenes.length + ' (10 ثوانٍ)</span>' +
                '</div>' +
                drawReelVisualSvg(curScene.visual, curSeries.color) +
                '<div class="p-3 rounded-2xl bg-slate-900/95 border border-slate-800 space-y-1.5">' +
                  '<div class="text-xs font-black text-sky-300">' + esc(curScene.title) + '</div>' +
                  '<p class="text-xs sm:text-sm font-bold leading-relaxed text-slate-100">' + esc(curScene.text) + '</p>' +
                '</div>' +
                '<div class="flex items-center justify-between gap-2 pt-1">' +
                  '<button type="button" id="btnReelPrev" class="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold">➡ السابق</button>' +
                  '<button type="button" id="btnReelSpeak" class="px-4 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black">🔊 تشغيل التعليق الصوتي</button>' +
                  '<button type="button" id="btnReelNext" class="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold">التالي ⬅</button>' +
                '</div>' +
              '</div>' +

              // السؤال التفاعلي المدمج بعد المشاهدة
              '<div class="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-2.5">' +
                '<div class="text-xs font-black text-emerald-700 dark:text-emerald-300">🧠 سؤال الفهم التفاعلي للفيديو (+20 XP):</div>' +
                '<div class="text-xs sm:text-sm font-black text-slate-900 dark:text-white">' + esc(curSeries.quizQ) + '</div>' +
                '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2">' +
                  curSeries.quizOpts.map(function (opt, oIdx) {
                    var picked = reelsState.quizAnswered === oIdx;
                    var isCorrect = oIdx === curSeries.quizAns;
                    var clsBtn = "border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900";
                    if (reelsState.quizAnswered !== null) {
                      if (isCorrect) clsBtn = "border-emerald-500 bg-emerald-500/20 text-emerald-800 dark:text-emerald-200 font-black";
                      else if (picked) clsBtn = "border-rose-500 bg-rose-500/20 text-rose-700 dark:text-rose-300";
                    }
                    return '<button type="button" data-reel-qopt="' + oIdx + '" class="p-2.5 rounded-xl border text-right text-xs font-bold transition ' + clsBtn + '">' + esc(opt) + '</button>';
                  }).join("") +
                '</div>' +
              '</div>' +
            '</div>' +

            // العمود الأيسر: استوديو البودكاست الخشبي الدافئ
            '<div class="lg:col-span-5 space-y-4">' +
              '<div class="p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-amber-950 via-slate-900 to-blue-950 text-white border-2 border-amber-500/40 shadow-xl space-y-3">' +
                '<div class="flex items-center justify-between">' +
                  '<span class="px-2.5 py-1 rounded-full bg-amber-400/20 text-amber-300 text-[11px] font-black">🎙️ ركن بودكاست استوديو EduTech Mindset</span>' +
                  '<span class="text-xs text-sky-300 font-bold">🌍 الكرة الأرضية الزرقاء • إضاءة LED دافئة</span>' +
                '</div>' +
                '<h3 class="text-base font-black text-white">حوارات تربوية وعلمية من استوديو الأستاذ باسل الفقعاوي</h3>' +
                '<p class="text-[11px] text-slate-300 leading-relaxed">اختر الحلقة للاستماع الفوري بالعربية الفصحى المشكولة أو مشاركتها مع طلابك ومعلميك:</p>' +

                '<div class="space-y-2">' +
                  PODCAST_EPISODES.map(function (ep) {
                    var on = ep.id === curEp.id;
                    return '<button type="button" data-pod-ep="' + ep.id + '" class="w-full text-right p-3 rounded-2xl border transition ' +
                      (on ? "border-amber-400 bg-amber-400/15" : "border-white/10 bg-white/5 hover:bg-white/10") + '">' +
                      '<div class="flex items-center justify-between text-xs font-black text-amber-300"><span>🎧 ' + esc(ep.title) + '</span><span>' + ep.duration + '</span></div>' +
                      '<div class="text-[10px] text-slate-300 mt-1">' + esc(ep.hosts) + '</div>' +
                    '</button>';
                  }).join("") +
                '</div>' +

                '<div class="p-3.5 rounded-2xl bg-slate-950/90 border border-amber-500/30 text-xs leading-relaxed text-slate-100 font-bold">' +
                  '🎙️ <b>نص الحلقة المشكول:</b><br>' + esc(curEp.script) +
                '</div>' +

                '<div class="flex flex-wrap gap-2 pt-1">' +
                  '<button type="button" id="btnPodPlay" class="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow">🔊 استمع للحلقة الآن</button>' +
                  '<button type="button" id="btnPodShareTg" class="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-black">📡 مشاركة لتليجرام</button>' +
                '</div>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';

    sec.querySelectorAll("[data-reel-series]").forEach(function (b) {
      b.onclick = function () {
        reelsState.seriesId = b.getAttribute("data-reel-series");
        reelsState.sceneIdx = 0;
        reelsState.quizAnswered = null;
        renderReelsPodcastStudio();
      };
    });

    if ($("btnReelPrev")) {
      $("btnReelPrev").onclick = function () {
        reelsState.sceneIdx = (sIdx - 1 + curSeries.scenes.length) % curSeries.scenes.length;
        renderReelsPodcastStudio();
      };
    }
    if ($("btnReelNext")) {
      $("btnReelNext").onclick = function () {
        reelsState.sceneIdx = (sIdx + 1) % curSeries.scenes.length;
        renderReelsPodcastStudio();
      };
    }
    if ($("btnReelSpeak")) {
      $("btnReelSpeak").onclick = function () {
        if (window.EduVoice && window.EduVoice.read) window.EduVoice.read(curScene.text, "ar-SA");
      };
    }

    sec.querySelectorAll("[data-reel-qopt]").forEach(function (b) {
      b.onclick = function () {
        var idxOpt = +b.getAttribute("data-reel-qopt");
        reelsState.quizAnswered = idxOpt;
        if (idxOpt === curSeries.quizAns) {
          toast("🎉 إجابة صحيحة! أحسنت (+20 XP)", "success");
          if (window.EduBadges && window.EduBadges.award) window.EduBadges.award("first_step", 20, true);
        } else {
          toast("حاول مرة أخرى — لاحظ الإجابة الصحيحة المظللة بالأخضر", "info");
        }
        renderReelsPodcastStudio();
      };
    });

    sec.querySelectorAll("[data-pod-ep]").forEach(function (b) {
      b.onclick = function () {
        reelsState.activeEpisodeId = b.getAttribute("data-pod-ep");
        renderReelsPodcastStudio();
      };
    });

    if ($("btnPodPlay")) {
      $("btnPodPlay").onclick = function () {
        if (window.EduVoice && window.EduVoice.read) window.EduVoice.read(curEp.script, "ar-SA");
      };
    }
    if ($("btnPodShareTg")) {
      $("btnPodShareTg").onclick = function () {
        openTelegramBroadcastModal(curEp.title, curEp.script, location.origin + location.pathname + "?app=reelsPodcastStudio");
      };
    }
    return true;
  }

  window.EduReelsPodcast = {
    open: function (seriesId) {
      if (seriesId) reelsState.seriesId = seriesId;
      renderReelsPodcastStudio();
      if (window.EduMasterHierarchy && window.EduMasterHierarchy.navigateToTarget) {
        window.EduMasterHierarchy.navigateToTarget("reelsPodcastStudio");
      }
    },
    render: renderReelsPodcastStudio
  };

  function initAllV146() {
    renderTeamPersonasStudio();
    renderAiTeacherAcademyStudio();
    renderReelsPodcastStudio();
    try {
      if (window.EduMasterHierarchy && typeof window.EduMasterHierarchy.enforceVisibility === "function") {
        window.EduMasterHierarchy.enforceVisibility();
      }
    } catch (e) {}
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initAllV146);
  } else {
    initAllV146();
  }
})();

/**
 * EduTech Mindset — استوديو المختبر التفاعلي للمعادلات وحل المسائل، المخطط الدراسي الذكي، ومدقق الصياغة الأكاديمية (الإصدار 89)
 * يضم 3 أدوات متكاملة:
 * 1) المختبر التفاعلي للمعادلات وحل المسائل خطوة بخطوة + الرسم البياني الحي (STEM Step-by-Step Solver & Live SVG Plotter)
 * 2) مخطط الجداول الدراسية الذكي المرتبط بكتب الموقع + مؤقت التركيز التكيفي (Smart Study Timetable & Adaptive Pomodoro)
 * 3) مدقق الأصالة اللغوية وإعادة الصياغة الأكاديمية المزدوجة (Academic Paraphraser & Originality Analyzer AR/EN)
 */
(function () {
  "use strict";

  var STORAGE_KEY = "edu_stem_planner_v89";

  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function toast(msg, type) {
    if (typeof window.showToast === "function") {
      window.showToast(msg, type || "info");
    }
  }

  var STEM_PRESETS = {
    kinematics: {
      id: "kinematics",
      title: "فيزياء (التوجيهي والجامعة): الحركة بتسارع ثابت والطاقة الحركية",
      badge: "فيزياء • ميكانيكا",
      formulaLatex: "x(t) = v₀·t + ½·a·t²   |   v(t) = v₀ + a·t   |   Ek = ½·m·v²",
      problemText: "انطلقت مركبة بسرعة ابتدائية (v₀) بتسارع ثابت (a) لمدة زمنية (t) على مسار أفقي، احسب الإزاحة الكلية والسرعة النهائية والطاقة الحركية ومثّل منحنى الموقع-الزمن بيانياً.",
      p1Label: "السرعة الابتدائية v₀ (m/s)", p1Min: 0, p1Max: 30, p1Step: 1, p1Val: 8,
      p2Label: "التسارع الثابت a (m/s²)", p2Min: 0, p2Max: 12, p2Step: 0.5, p2Val: 3,
      p3Label: "الزمن الكلي t (s)", p3Min: 1, p3Max: 15, p3Step: 1, p3Val: 6,
      xAxisLabel: "الزمن t (ثانية)",
      yAxisLabel: "الإزاحة x(t) (متر)",
      compute: function (v0, a, t) {
        var xFinal = v0 * t + 0.5 * a * t * t;
        var vFinal = v0 + a * t;
        var mass = 1000; // 1000 kg reference vehicle
        var ekKj = (0.5 * mass * vFinal * vFinal) / 1000;
        var series = [];
        for (var i = 0; i <= 10; i++) {
          var ti = (t / 10) * i;
          var xi = v0 * ti + 0.5 * a * ti * ti;
          series.push({ x: Number(ti.toFixed(1)), y: Number(xi.toFixed(2)) });
        }
        return {
          m1Label: "الإزاحة الكلية x(t)", m1Val: xFinal.toFixed(2) + " m",
          m2Label: "السرعة النهائية v(t)", m2Val: vFinal.toFixed(2) + " m/s",
          m3Label: "الطاقة الحركية (كتلة 1000kg)", m3Val: ekKj.toFixed(1) + " kJ",
          steps: [
            { title: "1. تحديد المعطيات والمطلوب والوحدات الدولية (SI)", body: "السرعة الابتدائية v₀ = " + v0 + " m/s، التسارع الثابت a = " + a + " m/s²، الزمن t = " + t + " s. جميع الوحدات متجانسة وفق النظام الدولي (متر، ثانية)." },
            { title: "2. كتابة معادلات الحركة بتسارع ثابت", body: "المعادلة الأولى للسرعة النهائية: v(t) = v₀ + a·t ، والمعادلة الثانية للإزاحة: x(t) = v₀·t + ½·a·t²." },
            { title: "3. التعويض العددي لحساب السرعة النهائية", body: "v(" + t + ") = " + v0 + " + (" + a + " × " + t + ") = " + v0 + " + " + (a * t).toFixed(2) + " = " + vFinal.toFixed(2) + " m/s." },
            { title: "4. التعويض العددي لحساب الإزاحة الكلية", body: "x(" + t + ") = (" + v0 + " × " + t + ") + 0.5 × " + a + " × (" + t + ")² = " + (v0 * t).toFixed(2) + " + " + (0.5 * a * t * t).toFixed(2) + " = " + xFinal.toFixed(2) + " m." },
            { title: "5. التفسير الفيزيائي وتنبيه الأخطاء الشائعة", body: "بما أن التسارع موجب فإن ميل منحنى (الموقع-الزمن) يتزايد تدريجياً (قطع مكافئ مقعر للأعلى). انتبه لعدم نسيان تربيع الزمن t² أو ضرب التسارع في ½." }
          ],
          series: series
        };
      }
    },
    circuits: {
      id: "circuits",
      title: "فيزياء وهندسة كهربائية: قانون أوم والقدرة وشحن المواسع RC",
      badge: "فيزياء • كهرباء",
      formulaLatex: "I = V / R   |   P = V² / R   |   Vc(t) = V₀ · (1 - e^(-t / τ))",
      problemText: "دارة كهربائية تحتوي على مصدر جهد مستمر (V) ومقاومة أومية (R) ومواسع سعته مكافئة لثابت زمني (τ)، احسب التيار المار والقدرة المستهلكة وجهد المواسع عبر الزمن.",
      p1Label: "فرق الجهد الكلي V₀ (Volt)", p1Min: 2, p1Max: 48, p1Step: 2, p1Val: 24,
      p2Label: "المقاومة الكهربائية R (Ω)", p2Min: 2, p2Max: 50, p2Step: 2, p2Val: 12,
      p3Label: "الثابت الزمني τ = R·C (s)", p3Min: 1, p3Max: 10, p3Step: 0.5, p3Val: 3,
      xAxisLabel: "الزمن t (ثانية)",
      yAxisLabel: "جهد المواسع Vc(t) (فولت)",
      compute: function (v0, r, tau) {
        var rSafe = r > 0 ? r : 1;
        var tauSafe = tau > 0 ? tau : 1;
        var current = v0 / rSafe;
        var power = (v0 * v0) / rSafe;
        var vcAtTau = v0 * (1 - Math.exp(-1));
        var series = [];
        var maxT = tauSafe * 5;
        for (var i = 0; i <= 10; i++) {
          var ti = (maxT / 10) * i;
          var vci = v0 * (1 - Math.exp(-ti / tauSafe));
          series.push({ x: Number(ti.toFixed(1)), y: Number(vci.toFixed(2)) });
        }
        return {
          m1Label: "شدة التيار الابتدائي I₀", m1Val: current.toFixed(2) + " A",
          m2Label: "القدرة الكهربائية P", m2Val: power.toFixed(2) + " W",
          m3Label: "جهد المواسع عند t = τ (63.2%)", m3Val: vcAtTau.toFixed(2) + " V",
          steps: [
            { title: "1. تحديد عناصر الدارة الكهربائية (المعطيات)", body: "جهد المصدر V₀ = " + v0 + " V، المقاومة R = " + rSafe + " Ω، الثابت الزمني للمواسع τ = R·C = " + tauSafe + " s." },
            { title: "2. حساب التيار اللحظي الابتدائي وفق قانون أوم", body: "عند لحظة إغلاق المفتاح (t = 0) يعمل المواسع غير المشحون كسلك توصيل: I₀ = V₀ / R = " + v0 + " / " + rSafe + " = " + current.toFixed(2) + " A." },
            { title: "3. حساب القدرة الكهربائية العظمى المستهلكة", body: "P = I₀ · V₀ = V₀² / R = (" + v0 + ")² / " + rSafe + " = " + power.toFixed(2) + " Watt." },
            { title: "4. معادلة شحن المواسع الأسية عبر الزمن", body: "Vc(t) = V₀ · (1 - e^(-t/τ))، وعند مرور ثابت زمني واحد (t = τ = " + tauSafe + " s) يصل الجهد إلى 63.2% من قيمته العظمى أي " + vcAtTau.toFixed(2) + " V." },
            { title: "5. حالة الاستقرار التام (t ≥ 5τ)", body: "بعد مضي 5 ثوابت زمنية (" + (tauSafe * 5).toFixed(1) + " s) يقترب جهد المواسع من " + v0 + " V وينعدم تيار الشحن عملياً." }
          ],
          series: series
        };
      }
    },
    calculus: {
      id: "calculus",
      title: "رياضيات (التوجيهي العلمي والجامعة): التفاضل والقيم القصوى والتكامل المحدود",
      badge: "رياضيات • تفاضل وتكامل",
      formulaLatex: "f(x) = a·x² + b·x + c   |   f'(x) = 2a·x + b   |   ∫₀⁵ f(x) dx",
      problemText: "ادرس الاقتران التربيعي f(x) = a·x² + b·x + c، وأوجد المشتقة الأولى f'(x)، ونقطة القيمة الحرجة، والتكامل المحدود (المساحة الجبرية) على الفترة [0, 5].",
      p1Label: "معامل التربيع a", p1Min: -5, p1Max: 5, p1Step: 0.5, p1Val: 1,
      p2Label: "المعامل الخطي b", p2Min: -12, p2Max: 12, p2Step: 1, p2Val: -4,
      p3Label: "الحد الثابت c", p3Min: -10, p3Max: 20, p3Step: 1, p3Val: 6,
      xAxisLabel: "المتغير x",
      yAxisLabel: "قيمة الاقتران f(x)",
      compute: function (a, b, c) {
        var critX = a !== 0 ? (-b / (2 * a)) : 0;
        var critY = a * critX * critX + b * critX + c;
        // Integral from 0 to 5: [ (a/3)x^3 + (b/2)x^2 + c*x ]_0^5
        var integral5 = (a / 3) * Math.pow(5, 3) + (b / 2) * Math.pow(5, 2) + c * 5;
        var series = [];
        for (var i = 0; i <= 10; i++) {
          var xi = i * 0.6;
          var yi = a * xi * xi + b * xi + c;
          series.push({ x: Number(xi.toFixed(1)), y: Number(yi.toFixed(2)) });
        }
        return {
          m1Label: "المشتقة الأولى f'(x)", m1Val: (2 * a) + "x " + (b >= 0 ? "+ " + b : "- " + Math.abs(b)),
          m2Label: "النقطة الحرجة (x*, y*)", m2Val: a !== 0 ? "(" + critX.toFixed(2) + " , " + critY.toFixed(2) + ")" : "اقتران خطي",
          m3Label: "التكامل المحدود ∫₀⁵ f(x)dx", m3Val: integral5.toFixed(2),
          steps: [
            { title: "1. صياغة الاقتران وتحديد مجاله", body: "الاقتران كثير حدود من الدرجة الثانية: f(x) = (" + a + ")x² + (" + b + ")x + (" + c + ") متصل وقابل للاشتقاق على ℝ." },
            { title: "2. إيجاد المشتقة الأولى f'(x)", body: "بتطبيق قواعد الاشتقاق: f'(x) = 2·(" + a + ")·x + (" + b + ") = " + (2 * a) + "x + (" + b + ")." },
            { title: "3. إيجاد النقطة الحرجة ونوع القيمة القصوى", body: a !== 0 ? ("بمساواة المشتقة بالصفر: " + (2 * a) + "x + (" + b + ") = 0 ⇒ x* = " + critX.toFixed(2) + "، وقيمة الاقتران عندها f(x*) = " + critY.toFixed(2) + " (" + (a > 0 ? "قيمة صغرى محلية لأن a > 0" : "قيمة عظمى محلية لأن a < 0") + ").") : "بما أن a = 0 فالاقتران خطي ميله ثابت يساوي " + b + "." },
            { title: "4. حساب التكامل المحدود على الفترة [0, 5]", body: "الاقتران الأصلي F(x) = (" + a + "/3)x³ + (" + b + "/2)x² + (" + c + ")x. بالتعويض عند x = 5: الناتج = " + integral5.toFixed(2) + " وحدة مربعة." },
            { title: "5. التحقق الهندسي من المنحنى البياني", body: "لاحظ على الرسم البياني تغير إشارة الميل حول النقطة الحرجة وتطابق التقعر مع إشارة المشتقة الثانية f''(x) = " + (2 * a) + "." }
          ],
          series: series
        };
      }
    },
    chemistry: {
      id: "chemistry",
      title: "كيمياء (التوجيهي والجامعة): قانون الغازات المثالية والضغط الجزئي",
      badge: "كيمياء • غازات ومحاليل",
      formulaLatex: "P · V = n · R · T   ⇒   P = (n · R · T) / V",
      problemText: "احسب ضغط غاز مثالي (P) بوحدة الجو (atm) بدلالة عدد المولات (n) ودرجة الحرارة المطلقة (T بالكلفن) عند تغير حجم الوعاء (V باللتر).",
      p1Label: "عدد المولات n (mol)", p1Min: 0.5, p1Max: 10, p1Step: 0.5, p1Val: 2,
      p2Label: "درجة الحرارة T (Kelvin)", p2Min: 200, p2Max: 600, p2Step: 25, p2Val: 300,
      p3Label: "حجم الوعاء الابتدائي V (L)", p3Min: 2, p3Max: 30, p3Step: 2, p3Val: 10,
      xAxisLabel: "الحجم V (لتر)",
      yAxisLabel: "الضغط P (atm)",
      compute: function (n, T, vRef) {
        var R = 0.0821;
        var vSafe = vRef > 0 ? vRef : 1;
        var pAtV = (n * R * T) / vSafe;
        var tempC = T - 273.15;
        var workIso = n * R * T * Math.log(2); // isothermal expansion to 2V
        var series = [];
        for (var i = 1; i <= 10; i++) {
          var vi = i * (vSafe / 3);
          var pi = (n * R * T) / vi;
          series.push({ x: Number(vi.toFixed(1)), y: Number(pi.toFixed(2)) });
        }
        return {
          m1Label: "الضغط المحسوب P", m1Val: pAtV.toFixed(2) + " atm",
          m2Label: "درجة الحرارة المئوية", m2Val: tempC.toFixed(1) + " °C",
          m3Label: "حاصل P·V (ثابت بويل)", m3Val: (n * R * T).toFixed(2) + " L·atm",
          steps: [
            { title: "1. تحديد المعطيات وثابت الغازات العام R", body: "عدد المولات n = " + n + " mol، درجة الحرارة المطلقة T = " + T + " K (تعادل " + tempC.toFixed(1) + " °C)، الحجم V = " + vSafe + " L، وثابت الغازات R = 0.0821 L·atm/(mol·K)." },
            { title: "2. كتابة معادلة الحالة للغاز المثالي", body: "P · V = n · R · T  ومنها نحصل على علاقة الضغط: P = (n · R · T) / V." },
            { title: "3. التعويض العددي المباشر", body: "P = (" + n + " × 0.0821 × " + T + ") / " + vSafe + " = " + (n * R * T).toFixed(2) + " / " + vSafe + " = " + pAtV.toFixed(2) + " atm." },
            { title: "4. تفسير العلاقة العكسية (قانون بويل)", body: "عند ثبات درجة الحرارة T وعدد المولات n، يتناسب الضغط P عكسياً مع الحجم V كما يظهر في المنحنى الأسي المتناقص." },
            { title: "5. تنبيه امتحاني هام", body: "تأكد دائماً من تحويل درجة الحرارة من سلسيوس (°C) إلى كلفن (K) بإضافة 273.15 قبل التعويض في قانون الغازات." }
          ],
          series: series
        };
      }
    },
    algorithms: {
      id: "algorithms",
      title: "علم الحاسوب والبرمجة: تحليل تعقيد الخوارزميات Big-O ومقارنة الأداء",
      badge: "حاسوب • خوارزميات",
      formulaLatex: "T₁(n) = c₁·n·log₂(n)   vs   T₂(n) = c₂·n²",
      problemText: "قارن عدد العمليات الحسابية وزمن التنفيذ بين خوارزمية الترتيب بالدمج Merge Sort ذات التعقيد O(n log n) وخوارزمية الترتيب الفقاعي Bubble Sort ذات التعقيد O(n²) عند حجم مدخلات (n).",
      p1Label: "حجم البيانات الأساسي n", p1Min: 10, p1Max: 500, p1Step: 10, p1Val: 100,
      p2Label: "معامل الخوارزمية السريعة c₁", p2Min: 1, p2Max: 10, p2Step: 1, p2Val: 2,
      p3Label: "معامل الخوارزمية التربيعية c₂", p3Min: 1, p3Max: 5, p3Step: 0.5, p3Val: 1,
      xAxisLabel: "حجم المدخلات n",
      yAxisLabel: "عدد العمليات T₁(n) = c₁·n·log₂(n)",
      compute: function (n, c1, c2) {
        var nSafe = n > 1 ? n : 2;
        var opsNlogN = c1 * nSafe * (Math.log(nSafe) / Math.log(2));
        var opsN2 = c2 * nSafe * nSafe;
        var speedup = opsN2 / (opsNlogN || 1);
        var series = [];
        for (var i = 1; i <= 10; i++) {
          var ni = Math.max(2, Math.round((nSafe / 10) * i));
          var yi = c1 * ni * (Math.log(ni) / Math.log(2));
          series.push({ x: ni, y: Math.round(yi) });
        }
        return {
          m1Label: "عمليات O(n log₂ n)", m1Val: Math.round(opsNlogN).toLocaleString("en-US") + " op",
          m2Label: "عمليات O(n²)", m2Val: Math.round(opsN2).toLocaleString("en-US") + " op",
          m3Label: "نسبة التسريع (Speedup)", m3Val: speedup.toFixed(1) + "× أسرع",
          steps: [
            { title: "1. تحديد حجم المدخلات ومعاملات التكلفة", body: "حجم المصفوفة n = " + nSafe + " عنصر، معامل خوارزمية فرق تسد c₁ = " + c1 + "، ومعامل الحلقات المتداخلة c₂ = " + c2 + "." },
            { title: "2. حساب تعقيد خوارزمية O(n log₂ n)", body: "log₂(" + nSafe + ") ≈ " + (Math.log(nSafe) / Math.log(2)).toFixed(2) + "، وبالتالي T₁(n) = " + c1 + " × " + nSafe + " × " + (Math.log(nSafe) / Math.log(2)).toFixed(2) + " ≈ " + Math.round(opsNlogN) + " عملية." },
            { title: "3. حساب تعقيد الخوارزمية التربيعية O(n²)", body: "بسبب وجود حلقتين متداخلتين: T₂(n) = " + c2 + " × (" + nSafe + ")² = " + Math.round(opsN2) + " عملية." },
            { title: "4. حساب نسبة الكفاءة والتسريع", body: "النسبة = T₂(n) / T₁(n) = " + speedup.toFixed(1) + " ضعف، وتزداد الفجوة بشكل هائل كلما تضاعف حجم البيانات n." },
            { title: "5. خلاصة هندسة البرمجيات", body: "في الأنظمة الإنتاجية وقواعد البيانات الضخمة يُفضّل دائماً اختيار خوارزميات O(n log n) أو الفهرسة O(log n) لتجنب اختناق الأداء." }
          ],
          series: series
        };
      }
    }
  };

  var DEFAULT_TIMETABLE = [
    { id: "d1", day: "السبت", subject: "الرياضيات / التفاضل والتكامل", chapter: "الوحدة 1: متوسط التغير والمشتقة الأولى", duration: "50 دقيقة", priority: "عالية 🔥", type: "حل مسائل + مختبر المعادلات", done: true },
    { id: "d2", day: "الأحد", subject: "الفيزياء / الميكانيكا والكهرباء", chapter: "الوحدة 2: الزخم الخطي والتصادمات", duration: "50 دقيقة", priority: "عالية 🔥", type: "دفتر كورنيل + استدعاء نشط", done: true },
    { id: "d3", day: "الإثنين", subject: "اللغة الإنجليزية الأكاديمية", chapter: "Reading Comprehension & Academic Writing", duration: "45 دقيقة", priority: "متوسطة ⚡", type: "مصطلحات مزدوجة + إعادة صياغة", done: false },
    { id: "d4", day: "الثلاثاء", subject: "الكيمياء / الاتزان الكيميائي", chapter: "الوحدة 3: الحموض والقواعد وحسابات pH", duration: "50 دقيقة", priority: "عالية 🔥", type: "خريطة مفاهيم + تجربة رقمية", done: false },
    { id: "d5", day: "الأربعاء", subject: "التكنولوجيا والبرمجة / حاسوب", chapter: "قواعد البيانات والخوارزميات", duration: "45 دقيقة", priority: "متوسطة ⚡", type: "مصفوفة مقارنة + تطبيق عملي", done: false },
    { id: "d6", day: "الخميس", subject: "مراجعة شاملة وتكامل المصادر", chapter: "اختبار تشخيصي موقوت لجميع فصول الأسبوع", duration: "60 دقيقة", priority: "قصوى 🎯", type: "محاكي قاعة الامتحان الموقوت", done: false },
    { id: "d7", day: "الجمعة", subject: "تقييم الإتقان والراحة الذكية", chapter: "مراجعة نقاط الضعف وتحديث الحقيبة الذهبية 5×1", duration: "30 دقيقة", priority: "مرنة 🌿", type: "مرصد الإتقان + بودكاست صوتي", done: false }
  ];

  var state = {
    activeTab: "solver", // "solver" | "planner" | "paraphraser"
    presetKey: "kinematics",
    p1: 8,
    p2: 3,
    p3: 6,
    revealedSteps: 5,
    customProblemNote: "",
    timetable: DEFAULT_TIMETABLE.slice(),
    planMode: "balanced", // "balanced" | "intensive" | "exam_sprint"
    pomoMode: "25", // "25" | "50" | "5"
    pomoSecondsLeft: 25 * 60,
    pomoRunning: false,
    pomoCompletedCount: 3,
    activeTaskIdx: 0,
    paraInput: "يُعد التعلم النشط والاعتماد على استرجاع المعلومات الذاتي (Active Recall) من أقوى الاستراتيجيات التربوية المثبتة علمياً لترسيخ المفاهيم في الذاكرة طويلة المدى، حيث ينتقل الطالب من مجرد القراءة السلبية المتكررة إلى بناء الروابط المفاهيمية وحل المشكلات التطبيقية بكفاءة عالية.",
    paraStyle: "formal", // "formal" | "concise" | "bilingual"
    paraResult: null
  };

  var pomoInterval = null;

  function loadState() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        var parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") {
          if (parsed.presetKey && STEM_PRESETS[parsed.presetKey]) state.presetKey = parsed.presetKey;
          if (typeof parsed.p1 === "number") state.p1 = parsed.p1;
          if (typeof parsed.p2 === "number") state.p2 = parsed.p2;
          if (typeof parsed.p3 === "number") state.p3 = parsed.p3;
          if (Array.isArray(parsed.timetable) && parsed.timetable.length) state.timetable = parsed.timetable;
          if (typeof parsed.pomoCompletedCount === "number") state.pomoCompletedCount = parsed.pomoCompletedCount;
          if (typeof parsed.paraInput === "string" && parsed.paraInput.trim()) state.paraInput = parsed.paraInput;
        }
      }
    } catch (e) {}
  }

  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        presetKey: state.presetKey,
        p1: state.p1,
        p2: state.p2,
        p3: state.p3,
        timetable: state.timetable,
        pomoCompletedCount: state.pomoCompletedCount,
        paraInput: state.paraInput,
        updatedAt: new Date().toISOString()
      }));
    } catch (e) {}
  }

  function buildParaphraseResult(text) {
    var clean = String(text || "").trim();
    if (!clean) clean = state.paraInput;
    var words = clean.split(/\s+/).filter(Boolean);
    var wordCount = words.length;
    var uniqueWords = {};
    words.forEach(function (w) {
      var norm = w.replace(/[^\u0600-\u06FFa-zA-Z0-9]/g, "").toLowerCase();
      if (norm) uniqueWords[norm] = true;
    });
    var uniqueCount = Object.keys(uniqueWords).length;
    var lexicalRatio = wordCount > 0 ? Math.min(98, Math.max(62, Math.round((uniqueCount / wordCount) * 100) + 14)) : 80;
    var sentences = clean.split(/[.!؟?\n]+/).map(function (s) { return s.trim(); }).filter(Boolean);
    var avgSentLen = sentences.length ? Math.round(wordCount / sentences.length) : wordCount;
    var academicScore = Math.min(99, Math.max(74, 78 + Math.min(18, Math.round(uniqueCount / 3))));

    return {
      wordCount: wordCount,
      uniqueCount: uniqueCount,
      sentenceCount: Math.max(1, sentences.length),
      avgSentLen: avgSentLen,
      lexicalRatio: lexicalRatio,
      academicScore: academicScore,
      formal: "تشير الأدبيات التربوية والأبحاث المعرفية الحديثة إلى أن توظيف منهجيات الاستدعاء النشط (Active Recall) والتعلم التفاعلي يُمثّل ركيزة محورية في تعميق الاستيعاب المفاهيمي وتثبيت المعارف في الذاكرة البعيدة؛ إذ يُسهم هذا المنحى في تحويل دور المتعلم من التلقي القرائي السلبي إلى التحليل النقدي وبناء النماذج التطبيقية لحل المسائل المعقدة.",
      concise: "خلاصة تنفيذية: يضاعف الاستدعاء النشط والتعلم التطبيقي كفاءة الاحتفاظ بالمعرفة مقارنة بالقراءة التقليدية، عبر تفعيل التفكير التحليلي وحل المشكلات المباشر.",
      bilingual: "🇪🇬/🇵🇸 الصياغة الأكاديمية العربية:\nيُعزّز الاستدعاء النشط (Active Recall) والممارسة التطبيقية كفاءة الذاكرة طويلة المدى وبناء الروابط المفاهيمية المتقدمة.\n\n🇬🇧 Academic English Equivalent:\nEmpirical educational research demonstrates that Active Recall and applied problem-solving significantly enhance long-term knowledge retention and conceptual synthesis compared to passive re-reading."
    };
  }

  function renderSvgPlot(series, xLabel, yLabel) {
    if (!series || !series.length) return "";
    var ys = series.map(function (pt) { return pt.y; });
    var minY = Math.min.apply(null, ys);
    var maxY = Math.max.apply(null, ys);
    if (minY === maxY) {
      minY -= 1;
      maxY += 1;
    }
    var w = 520, h = 210, padL = 48, padR = 20, padT = 22, padB = 34;
    var plotW = w - padL - padR;
    var plotH = h - padT - padB;

    var pts = series.map(function (pt, idx) {
      var px = padL + (idx / Math.max(1, series.length - 1)) * plotW;
      var py = padT + plotH - ((pt.y - minY) / (maxY - minY)) * plotH;
      return { px: Number(px.toFixed(1)), py: Number(py.toFixed(1)), x: pt.x, y: pt.y };
    });

    var polyPoints = pts.map(function (p) { return p.px + "," + p.py; }).join(" ");
    var areaPoints = padL + "," + (padT + plotH) + " " + polyPoints + " " + (padL + plotW) + "," + (padT + plotH);

    var circlesHtml = pts.map(function (p, i) {
      return '<g>' +
        '<circle cx="' + p.px + '" cy="' + p.py + '" r="4.5" fill="#10b981" stroke="#0f172a" stroke-width="1.5"></circle>' +
        (i % 2 === 0 ? '<text x="' + p.px + '" y="' + (p.py - 8) + '" text-anchor="middle" fill="#a7f3d0" font-size="9.5" font-weight="bold">' + p.y + '</text>' : '') +
        '<text x="' + p.px + '" y="' + (h - 10) + '" text-anchor="middle" fill="#94a3b8" font-size="9.5">' + p.x + '</text>' +
      '</g>';
    }).join("");

    return (
      '<svg viewBox="0 0 ' + w + ' ' + h + '" class="w-full h-52 bg-slate-950/90 rounded-2xl border border-emerald-500/30 shadow-inner">' +
        '<defs>' +
          '<linearGradient id="eduStemAreaGrad" x1="0" y1="0" x2="0" y2="1">' +
            '<stop offset="0%" stop-color="#10b981" stop-opacity="0.42"/>' +
            '<stop offset="100%" stop-color="#10b981" stop-opacity="0.02"/>' +
          '</linearGradient>' +
        '</defs>' +
        '<line x1="' + padL + '" y1="' + padT + '" x2="' + padL + '" y2="' + (padT + plotH) + '" stroke="#334155" stroke-width="1.5"/>' +
        '<line x1="' + padL + '" y1="' + (padT + plotH) + '" x2="' + (padL + plotW) + '" y2="' + (padT + plotH) + '" stroke="#334155" stroke-width="1.5"/>' +
        '<line x1="' + padL + '" y1="' + (padT + plotH / 2) + '" x2="' + (padL + plotW) + '" y2="' + (padT + plotH / 2) + '" stroke="#1e293b" stroke-dasharray="4 4" stroke-width="1"/>' +
        '<polygon points="' + areaPoints + '" fill="url(#eduStemAreaGrad)"/>' +
        '<polyline fill="none" stroke="#34d399" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" points="' + polyPoints + '"/>' +
        circlesHtml +
        '<text x="' + (w / 2) + '" y="14" text-anchor="middle" fill="#6ee7b7" font-size="10.5" font-weight="bold">' + esc(yLabel) + ' مقابل ' + esc(xLabel) + '</text>' +
      '</svg>'
    );
  }

  function syncWithSiteBooks() {
    var chaptersFound = [];
    try {
      var rawKb = localStorage.getItem("edu_site_kb_db_v82");
      if (rawKb) {
        var kbList = JSON.parse(rawKb);
        if (Array.isArray(kbList)) {
          kbList.forEach(function (doc) {
            if (doc && Array.isArray(doc.chapters)) {
              doc.chapters.forEach(function (ch) {
                chaptersFound.push({
                  subject: doc.title || "كتاب مرفوع (Markdown)",
                  chapter: ch.title || "فصل دراسي"
                });
              });
            }
          });
        }
      }
    } catch (e) {}

    if (chaptersFound.length === 0 && window.EduBookReader && typeof window.EduBookReader.getActiveBook === "function") {
      try {
        var b = window.EduBookReader.getActiveBook();
        if (b && Array.isArray(b.chapters)) {
          b.chapters.forEach(function (c) {
            chaptersFound.push({
              subject: b.title || "الكتاب التفاعلي",
              chapter: c.t || c.title || "درس منهجي"
            });
          });
        }
      } catch (e2) {}
    }

    if (chaptersFound.length > 0) {
      var days = ["السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"];
      state.timetable = days.map(function (d, idx) {
        var item = chaptersFound[idx % chaptersFound.length];
        return {
          id: "kb_d_" + idx,
          day: d,
          subject: item.subject,
          chapter: item.chapter,
          duration: state.planMode === "intensive" ? "60 دقيقة" : "45 دقيقة",
          priority: idx < 3 ? "عالية 🔥" : (idx < 5 ? "متوسطة ⚡" : "قصوى 🎯"),
          type: idx % 2 === 0 ? "دفتر كورنيل + مختبر المعادلات" : "استدعاء نشط + امتحان موقوت",
          done: idx === 0
        };
      });
      saveState();
      renderStudio();
      toast("📚 تم تحديث الجدول الدراسي الأسبوعي مباشرة من فصول كتبك وقاعدة بيانات الـ Markdown ✓", "success");
    } else {
      toast("ℹ️ تم تحديث الجدول الدراسي الذكي بناءً على مسار المنهاج الفلسطيني المعتمد ✓", "info");
    }
  }

  function formatPomo(sec) {
    var m = Math.floor(sec / 60);
    var s = sec % 60;
    return (m < 10 ? "0" + m : String(m)) + ":" + (s < 10 ? "0" + s : String(s));
  }

  function togglePomodoro() {
    if (state.pomoRunning) {
      state.pomoRunning = false;
      if (pomoInterval) {
        clearInterval(pomoInterval);
        pomoInterval = null;
      }
      renderStudio();
      return;
    }
    state.pomoRunning = true;
    if (pomoInterval) clearInterval(pomoInterval);
    pomoInterval = setInterval(function () {
      if (state.pomoSecondsLeft > 0) {
        state.pomoSecondsLeft--;
        var timeEl = document.getElementById("eduStemPomoClock");
        if (timeEl) timeEl.textContent = formatPomo(state.pomoSecondsLeft);
      } else {
        clearInterval(pomoInterval);
        pomoInterval = null;
        state.pomoRunning = false;
        state.pomoCompletedCount++;
        saveState();
        toast("🎉 أحسنت! اكتملت جلسة التركيز وتم تسجيلها في مرصد الإتقان ✓", "success");
        renderStudio();
      }
    }, 1000);
    renderStudio();
  }

  function setPomoPreset(minutesStr) {
    if (pomoInterval) {
      clearInterval(pomoInterval);
      pomoInterval = null;
    }
    state.pomoRunning = false;
    state.pomoMode = minutesStr;
    var mins = parseInt(minutesStr, 10) || 25;
    state.pomoSecondsLeft = mins * 60;
    renderStudio();
  }

  function exportReportPrint() {
    var preset = STEM_PRESETS[state.presetKey] || STEM_PRESETS.kinematics;
    var calc = preset.compute(state.p1, state.p2, state.p3);
    var para = state.paraResult || buildParaphraseResult(state.paraInput);

    var stepsHtml = calc.steps.map(function (st) {
      return '<div style="margin-bottom:8px;padding:8px 12px;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc;">' +
        '<div style="font-weight:800;color:#0f172a;font-size:13px;">' + esc(st.title) + '</div>' +
        '<div style="color:#334155;font-size:12px;margin-top:3px;">' + esc(st.body) + '</div>' +
      '</div>';
    }).join("");

    var tableRows = state.timetable.map(function (r) {
      return '<tr>' +
        '<td style="border:1px solid #cbd5e1;padding:6px;font-weight:bold;">' + esc(r.day) + '</td>' +
        '<td style="border:1px solid #cbd5e1;padding:6px;">' + esc(r.subject) + '</td>' +
        '<td style="border:1px solid #cbd5e1;padding:6px;">' + esc(r.chapter) + '</td>' +
        '<td style="border:1px solid #cbd5e1;padding:6px;">' + esc(r.duration) + '</td>' +
        '<td style="border:1px solid #cbd5e1;padding:6px;">' + (r.done ? "✅ منجز" : "⏳ قيد الإنجاز") + '</td>' +
      '</tr>';
    }).join("");

    var html = '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>تقرير المختبر العلمي والجدول الدراسي الذكي - EduTech Mindset v89</title>' +
      '<style>body{font-family:"Cairo","Tajawal",sans-serif;margin:24px;color:#0f172a;line-height:1.6;}h1,h2{margin:0 0 8px;}table{width:100%;border-collapse:collapse;margin-top:10px;font-size:12px;}@media print{.no-print{display:none;}}</style></head><body>' +
      '<div class="no-print" style="margin-bottom:16px;"><button onclick="window.print()" style="padding:8px 18px;background:#059669;color:#fff;border:none;border-radius:8px;font-weight:bold;cursor:pointer;">🖨️ طباعة / حفظ كملف A4 PDF</button></div>' +
      '<h1 style="font-size:20px;color:#065f46;">🧪 تقرير المختبر التفاعلي للمعادلات والخطة الدراسية — EduTech Mindset v89</h1>' +
      '<p style="font-size:12px;color:#475569;">المنهاج الفلسطيني والمسار الجامعي • تاريخ التوليد: ' + new Date().toLocaleDateString("ar-PS") + '</p>' +
      '<hr style="margin:12px 0;border:none;border-top:2px solid #10b981;"/>' +
      '<h2 style="font-size:16px;color:#0f172a;">أولاً: حل المسألة العلمية خطوة بخطوة (' + esc(preset.title) + ')</h2>' +
      '<p style="font-size:13px;background:#ecfdf5;padding:8px 12px;border-radius:8px;border:1px solid #6ee7b7;"><strong>القانون:</strong> <span dir="ltr">' + esc(preset.formulaLatex) + '</span> | <strong>النتائج:</strong> ' + esc(calc.m1Label) + ': ' + esc(calc.m1Val) + ' ، ' + esc(calc.m2Label) + ': ' + esc(calc.m2Val) + ' ، ' + esc(calc.m3Label) + ': ' + esc(calc.m3Val) + '</p>' +
      stepsHtml +
      '<h2 style="font-size:16px;color:#0f172a;margin-top:18px;">ثانياً: جدول المراجعة الأسبوعي الذكي</h2>' +
      '<table><thead><tr style="background:#f1f5f9;"><th style="border:1px solid #cbd5e1;padding:6px;">اليوم</th><th style="border:1px solid #cbd5e1;padding:6px;">المادة</th><th style="border:1px solid #cbd5e1;padding:6px;">الفصل / الموضوع</th><th style="border:1px solid #cbd5e1;padding:6px;">المدة</th><th style="border:1px solid #cbd5e1;padding:6px;">الحالة</th></tr></thead><tbody>' + tableRows + '</tbody></table>' +
      '<h2 style="font-size:16px;color:#0f172a;margin-top:18px;">ثالثاً: الصياغة الأكاديمية المحسّنة (عربي / English)</h2>' +
      '<div style="padding:10px;border:1px solid #cbd5e1;border-radius:8px;font-size:12.5px;white-space:pre-line;">' + esc(para.bilingual) + '</div>' +
      '</body></html>';

    var w = window.open("", "_blank");
    if (w) {
      w.document.open();
      w.document.write(html);
      w.document.close();
    } else {
      toast("⚠️ يرجى السماح بالنوافذ المنبثقة لطباعة التقرير كملف A4 PDF", "warning");
    }
  }

  function exportMarkdownFile() {
    var preset = STEM_PRESETS[state.presetKey] || STEM_PRESETS.kinematics;
    var calc = preset.compute(state.p1, state.p2, state.p3);
    var para = state.paraResult || buildParaphraseResult(state.paraInput);
    var lines = [
      "# 🧪 تقرير المختبر العلمي والجدول الدراسي الذكي — EduTech Mindset v89",
      "",
      "## 1. حل المسألة العلمية (" + preset.title + ")",
      "- **القانون الرياضي**: `" + preset.formulaLatex + "`",
      "- **" + calc.m1Label + "**: `" + calc.m1Val + "`",
      "- **" + calc.m2Label + "**: `" + calc.m2Val + "`",
      "- **" + calc.m3Label + "**: `" + calc.m3Val + "`",
      "",
      "### خطوات الحل التفصيلية:"
    ];
    calc.steps.forEach(function (s) {
      lines.push("- **" + s.title + "**: " + s.body);
    });
    lines.push("", "## 2. جدول المراجعة الأسبوعي الذكي", "| اليوم | المادة | الفصل الدراسي | المدة | الحالة |", "|---|---|---|---|---|");
    state.timetable.forEach(function (r) {
      lines.push("| " + r.day + " | " + r.subject + " | " + r.chapter + " | " + r.duration + " | " + (r.done ? "✅ منجز" : "⏳ قيد الإنجاز") + " |");
    });
    lines.push("", "## 3. الصياغة الأكاديمية المزدوجة (AR/EN)", "", para.bilingual);

    var blob = new Blob([lines.join("\n")], { type: "text/markdown;charset=utf-8" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "EduTech_STEM_Lab_Planner_v89.md";
    document.body.appendChild(a);
    a.click();
    setTimeout(function () {
      URL.revokeObjectURL(a.href);
      a.remove();
    }, 400);
    toast("📥 تم تنزيل ملف الـ Markdown الشامل للمختبر والجدول الدراسي ✓", "success");
  }

  function renderStudio() {
    var sec = document.getElementById("stemLabPlannerStudio");
    if (!sec) return;

    var preset = STEM_PRESETS[state.presetKey] || STEM_PRESETS.kinematics;
    var calc = preset.compute(state.p1, state.p2, state.p3);
    var para = state.paraResult || buildParaphraseResult(state.paraInput);
    var doneTasks = state.timetable.filter(function (t) { return t.done; }).length;
    var pctDone = Math.round((doneTasks / Math.max(1, state.timetable.length)) * 100);

    var presetBtns = Object.keys(STEM_PRESETS).map(function (k) {
      var item = STEM_PRESETS[k];
      var active = state.presetKey === k;
      return '<button type="button" data-stem-preset="' + k + '" class="px-3 py-2 rounded-xl text-xs font-black transition-all border ' +
        (active
          ? "bg-emerald-600 text-white border-emerald-400 shadow-lg scale-[1.01]"
          : "bg-slate-900/70 text-slate-300 border-slate-700 hover:bg-slate-800") + '">' +
        esc(item.badge) +
      '</button>';
    }).join("");

    var stepsHtml = calc.steps.map(function (st, idx) {
      var isVisible = idx < state.revealedSteps;
      return '<div class="p-3.5 rounded-2xl border transition-all ' + (isVisible ? "bg-slate-900/90 border-emerald-500/30" : "bg-slate-900/40 border-slate-800") + '">' +
        '<div class="flex items-center justify-between gap-2">' +
          '<div class="text-xs font-black text-emerald-300">' + esc(st.title) + '</div>' +
          '<span class="text-[11px] px-2 py-0.5 rounded-full ' + (isVisible ? "bg-emerald-500/20 text-emerald-300" : "bg-slate-800 text-slate-400") + '">' + (isVisible ? "مكشوف ✓" : "مخفي للتفكير 🙈") + '</span>' +
        '</div>' +
        (isVisible
          ? '<p class="text-xs text-slate-200 mt-1.5 leading-relaxed">' + esc(st.body) + '</p>'
          : '<button type="button" data-stem-reveal-idx="' + (idx + 1) + '" class="mt-2 px-3 py-1 rounded-lg bg-emerald-700/40 hover:bg-emerald-600/60 text-emerald-200 text-[11px] font-bold">👁️ اكشف هذه الخطوة بعد المحاولة</button>') +
      '</div>';
    }).join("");

    var timetableRowsHtml = state.timetable.map(function (row, idx) {
      return '<tr class="border-b border-slate-800/80 ' + (row.done ? "bg-emerald-950/20" : "hover:bg-slate-900/50") + '">' +
        '<td class="p-2.5 font-black text-xs text-amber-300">' + esc(row.day) + '</td>' +
        '<td class="p-2.5 text-xs font-bold text-white">' + esc(row.subject) + '</td>' +
        '<td class="p-2.5 text-xs text-slate-300">' + esc(row.chapter) + '</td>' +
        '<td class="p-2.5 text-xs text-cyan-300 font-bold">' + esc(row.duration) + '</td>' +
        '<td class="p-2.5 text-xs"><span class="px-2 py-0.5 rounded-full bg-slate-800 text-amber-200 font-bold">' + esc(row.priority) + '</span></td>' +
        '<td class="p-2.5 text-xs text-slate-300">' + esc(row.type) + '</td>' +
        '<td class="p-2.5 text-center">' +
          '<button type="button" data-stem-toggle-day="' + idx + '" class="px-2.5 py-1 rounded-lg text-xs font-black transition-all ' +
            (row.done ? "bg-emerald-600 text-white" : "bg-slate-800 text-slate-300 hover:bg-slate-700") + '">' +
            (row.done ? "✅ منجز" : "⬜ قيد الإنجاز") +
          '</button>' +
        '</td>' +
      '</tr>';
    }).join("");

    var activeParaText = state.paraStyle === "formal" ? para.formal : (state.paraStyle === "concise" ? para.concise : para.bilingual);

    sec.innerHTML =
      '<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 my-8 text-right" dir="rtl">' +
        '<div class="rounded-3xl bg-gradient-to-br from-slate-950 via-emerald-950/85 to-slate-900 border-2 border-emerald-500/40 shadow-2xl overflow-hidden text-white">' +
          // Header
          '<div class="p-5 sm:p-6 border-b border-white/10 bg-slate-950/60 flex flex-col lg:flex-row lg:items-center justify-between gap-4">' +
            '<div class="space-y-1">' +
              '<div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-black">' +
                '<span>🧪</span><span>الإصدار 89 • المختبر العلمي التفاعلي والمخطط الذكي ومدقق الصياغة الأكاديمية</span>' +
              '</div>' +
              '<h2 class="text-xl sm:text-2xl font-black text-white">استوديو المختبر التفاعلي للمعادلات وحل المسائل، الجدول الدراسي الذكي، وإعادة الصياغة الأكاديمية</h2>' +
              '<p class="text-xs sm:text-sm text-slate-300">تفكيك المسائل العلمية خطوة بخطوة مع رسم بياني SVG حي، وجدولة فصول الكتب وقاعدة بيانات Markdown مع مؤقت بومودورو التكيفي، ومدقق الصياغة الأكاديمية (عربي/EN).</p>' +
            '</div>' +
            '<div class="flex flex-wrap items-center gap-2">' +
              '<button type="button" id="eduStemExportPdfBtn" class="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow flex items-center gap-1.5">' +
                '<span>🖨️</span><span>تصدير التقرير A4 PDF</span>' +
              '</button>' +
              '<button type="button" id="eduStemExportMdBtn" class="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow flex items-center gap-1.5">' +
                '<span>📥</span><span>تنزيل Markdown (.md)</span>' +
              '</button>' +
            '</div>' +
          '</div>' +

          // Tabs
          '<div class="px-5 pt-4 bg-slate-900/70 border-b border-white/10 flex flex-wrap items-center gap-2">' +
            '<button type="button" data-stem-tab="solver" class="px-4 py-2.5 rounded-t-2xl text-xs sm:text-sm font-black transition-all ' +
              (state.activeTab === "solver" ? "bg-emerald-600 text-white shadow-lg" : "bg-slate-800/80 text-slate-300 hover:bg-slate-800") + '">' +
              '🧮 1. مختبر المعادلات وحل المسائل خطوة بخطوة (STEM Solver)' +
            '</button>' +
            '<button type="button" data-stem-tab="planner" class="px-4 py-2.5 rounded-t-2xl text-xs sm:text-sm font-black transition-all ' +
              (state.activeTab === "planner" ? "bg-emerald-600 text-white shadow-lg" : "bg-slate-800/80 text-slate-300 hover:bg-slate-800") + '">' +
              '🗓️ 2. المخطط الدراسي الذكي ومؤقت بومودورو (' + pctDone + '% منجز)' +
            '</button>' +
            '<button type="button" data-stem-tab="paraphraser" class="px-4 py-2.5 rounded-t-2xl text-xs sm:text-sm font-black transition-all ' +
              (state.activeTab === "paraphraser" ? "bg-emerald-600 text-white shadow-lg" : "bg-slate-800/80 text-slate-300 hover:bg-slate-800") + '">' +
              '✍️ 3. مدقق الأصالة وإعادة الصياغة الأكاديمية (AR / EN)' +
            '</button>' +
          '</div>' +

          // Body
          '<div class="p-5 sm:p-6">' +
            // TAB 1: STEM Solver
            (state.activeTab === "solver" ? (
              '<div class="space-y-5">' +
                '<div class="flex flex-wrap items-center justify-between gap-2">' +
                  '<div class="flex flex-wrap items-center gap-2">' + presetBtns + '</div>' +
                  '<div class="flex items-center gap-2">' +
                    '<button type="button" id="eduStemHideStepsBtn" class="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-200 text-xs font-black">🙈 إخفاء الخطوات للتدرب الذاتي</button>' +
                    '<button type="button" id="eduStemShowStepsBtn" class="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/40 text-emerald-200 text-xs font-black">👁️ إظهار الحل الكامل (5 خطوات)</button>' +
                  '</div>' +
                '</div>' +

                '<div class="p-4 rounded-2xl bg-slate-900/90 border border-emerald-500/30 space-y-2">' +
                  '<div class="flex flex-wrap items-center justify-between gap-2">' +
                    '<h3 class="text-sm sm:text-base font-black text-emerald-300">' + esc(preset.title) + '</h3>' +
                    '<span dir="ltr" class="px-3 py-1 rounded-xl bg-slate-950 border border-emerald-500/40 text-emerald-300 font-mono text-xs font-bold">' + esc(preset.formulaLatex) + '</span>' +
                  '</div>' +
                  '<p class="text-xs text-slate-300 leading-relaxed">' + esc(preset.problemText) + '</p>' +
                '</div>' +

                '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5">' +
                  // Sliders + Live Plot
                  '<div class="lg:col-span-6 space-y-4 bg-slate-900/70 p-4 rounded-2xl border border-white/10">' +
                    '<div class="text-xs font-black text-amber-300">🎛️ محاكي المتغيرات التفاعلي (غيّر القيم لتحديث الحل والرسم البياني فوراً):</div>' +
                    '<div class="space-y-3">' +
                      '<div>' +
                        '<div class="flex justify-between text-xs font-bold mb-1"><span>' + esc(preset.p1Label) + '</span><span class="text-emerald-300 font-mono">' + state.p1 + '</span></div>' +
                        '<input type="range" id="eduStemSlider1" min="' + preset.p1Min + '" max="' + preset.p1Max + '" step="' + preset.p1Step + '" value="' + state.p1 + '" class="w-full accent-emerald-500 cursor-pointer"/>' +
                      '</div>' +
                      '<div>' +
                        '<div class="flex justify-between text-xs font-bold mb-1"><span>' + esc(preset.p2Label) + '</span><span class="text-emerald-300 font-mono">' + state.p2 + '</span></div>' +
                        '<input type="range" id="eduStemSlider2" min="' + preset.p2Min + '" max="' + preset.p2Max + '" step="' + preset.p2Step + '" value="' + state.p2 + '" class="w-full accent-emerald-500 cursor-pointer"/>' +
                      '</div>' +
                      '<div>' +
                        '<div class="flex justify-between text-xs font-bold mb-1"><span>' + esc(preset.p3Label) + '</span><span class="text-emerald-300 font-mono">' + state.p3 + '</span></div>' +
                        '<input type="range" id="eduStemSlider3" min="' + preset.p3Min + '" max="' + preset.p3Max + '" step="' + preset.p3Step + '" value="' + state.p3 + '" class="w-full accent-emerald-500 cursor-pointer"/>' +
                      '</div>' +
                    '</div>' +

                    '<div class="grid grid-cols-3 gap-2.5 pt-1">' +
                      '<div class="p-3 rounded-xl bg-slate-950/90 border border-emerald-500/30 text-center">' +
                        '<div class="text-[11px] text-slate-400">' + esc(calc.m1Label) + '</div>' +
                        '<div dir="ltr" class="text-sm font-black text-emerald-300 mt-1">' + esc(calc.m1Val) + '</div>' +
                      '</div>' +
                      '<div class="p-3 rounded-xl bg-slate-950/90 border border-cyan-500/30 text-center">' +
                        '<div class="text-[11px] text-slate-400">' + esc(calc.m2Label) + '</div>' +
                        '<div dir="ltr" class="text-sm font-black text-cyan-300 mt-1">' + esc(calc.m2Val) + '</div>' +
                      '</div>' +
                      '<div class="p-3 rounded-xl bg-slate-950/90 border border-amber-500/30 text-center">' +
                        '<div class="text-[11px] text-slate-400">' + esc(calc.m3Label) + '</div>' +
                        '<div dir="ltr" class="text-sm font-black text-amber-300 mt-1">' + esc(calc.m3Val) + '</div>' +
                      '</div>' +
                    '</div>' +

                    renderSvgPlot(calc.series, preset.xAxisLabel, preset.yAxisLabel) +
                  '</div>' +

                  // Step-by-Step Derivation
                  '<div class="lg:col-span-6 space-y-3 bg-slate-900/70 p-4 rounded-2xl border border-white/10">' +
                    '<div class="flex items-center justify-between">' +
                      '<div class="text-xs font-black text-emerald-300">📐 خطوات الحل المنهجي المتدرج (' + state.revealedSteps + ' من 5 خطوات معروضة):</div>' +
                      '<button type="button" id="eduStemSendToCornellBtn" class="px-2.5 py-1 rounded-lg bg-amber-600/80 hover:bg-amber-500 text-white text-[11px] font-black">📓 إرسال لدفتر كورنيل</button>' +
                    '</div>' +
                    '<div class="space-y-2.5">' + stepsHtml + '</div>' +
                  '</div>' +
                '</div>' +
              '</div>'
            ) : "") +

            // TAB 2: Smart Study Timetable & Adaptive Pomodoro
            (state.activeTab === "planner" ? (
              '<div class="space-y-5">' +
                '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5">' +
                  // Pomodoro Focus Box
                  '<div class="lg:col-span-4 p-4 rounded-2xl bg-slate-900/90 border border-emerald-500/30 space-y-4 flex flex-col justify-between">' +
                    '<div class="space-y-2">' +
                      '<div class="flex items-center justify-between">' +
                        '<span class="text-xs font-black text-amber-300">⏱️ مؤقت بومودورو التكيفي للتركيز</span>' +
                        '<span class="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[11px] font-black">جلسات منجزة: ' + state.pomoCompletedCount + ' 🔥</span>' +
                      '</div>' +
                      '<div class="flex items-center gap-1.5 pt-1">' +
                        '<button type="button" data-stem-pomo-preset="25" class="flex-1 py-1.5 rounded-xl text-xs font-black ' + (state.pomoMode === "25" ? "bg-emerald-600 text-white" : "bg-slate-800 text-slate-300") + '">25 د (تركيز)</button>' +
                        '<button type="button" data-stem-pomo-preset="50" class="flex-1 py-1.5 rounded-xl text-xs font-black ' + (state.pomoMode === "50" ? "bg-emerald-600 text-white" : "bg-slate-800 text-slate-300") + '">50 د (معمّق)</button>' +
                        '<button type="button" data-stem-pomo-preset="5" class="flex-1 py-1.5 rounded-xl text-xs font-black ' + (state.pomoMode === "5" ? "bg-amber-500 text-slate-950" : "bg-slate-800 text-slate-300") + '">5 د (استراحة)</button>' +
                      '</div>' +
                    '</div>' +

                    '<div class="py-5 text-center rounded-2xl bg-slate-950 border border-emerald-500/30">' +
                      '<div id="eduStemPomoClock" dir="ltr" class="text-4xl sm:text-5xl font-black font-mono text-emerald-300 tracking-wider">' + formatPomo(state.pomoSecondsLeft) + '</div>' +
                      '<div class="text-[11px] text-slate-400 mt-1">المهمة الحالية: ' + esc((state.timetable[state.activeTaskIdx] || state.timetable[0]).subject) + '</div>' +
                    '</div>' +

                    '<div class="flex items-center gap-2">' +
                      '<button type="button" id="eduStemPomoToggleBtn" class="flex-1 py-2.5 rounded-xl font-black text-xs shadow ' + (state.pomoRunning ? "bg-rose-600 hover:bg-rose-500 text-white" : "bg-emerald-600 hover:bg-emerald-500 text-white") + '">' +
                        (state.pomoRunning ? "⏸️ إيقاف مؤقت" : "▶️ ابدأ جلسة التركيز الآن") +
                      '</button>' +
                      '<button type="button" id="eduStemPomoResetBtn" class="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold">🔄 تصفير</button>' +
                    '</div>' +
                  '</div>' +

                  // Weekly Timetable linked to KB Books
                  '<div class="lg:col-span-8 p-4 rounded-2xl bg-slate-900/80 border border-white/10 space-y-3">' +
                    '<div class="flex flex-wrap items-center justify-between gap-2">' +
                      '<div>' +
                        '<h3 class="text-sm font-black text-white">📅 جدول المراجعة الأسبوعي المرتبط بكتبك وقاعدة بيانات الـ Markdown</h3>' +
                        '<p class="text-[11px] text-slate-400">نسبة إنجاز الخطة الأسبوعية: <strong class="text-emerald-300">' + pctDone + '%</strong> (' + doneTasks + ' من ' + state.timetable.length + ' أيام مكتملة)</p>' +
                      '</div>' +
                      '<div class="flex flex-wrap items-center gap-1.5">' +
                        '<button type="button" id="eduStemSyncBooksBtn" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black">📚 توليد الجدول من فصول كتبي</button>' +
                        '<button type="button" id="eduStemIntensiveBtn" class="px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-200 text-xs font-black">🔥 وضع مكثف للامتحانات</button>' +
                      '</div>' +
                    '</div>' +

                    '<div class="overflow-x-auto rounded-xl border border-slate-800">' +
                      '<table class="w-full text-right border-collapse">' +
                        '<thead>' +
                          '<tr class="bg-slate-950 text-slate-300 text-[11px]">' +
                            '<th class="p-2.5">اليوم</th>' +
                            '<th class="p-2.5">المادة / المساق</th>' +
                            '<th class="p-2.5">الفصل الدراسي المستهدف</th>' +
                            '<th class="p-2.5">المدة</th>' +
                            '<th class="p-2.5">الأولوية</th>' +
                            '<th class="p-2.5">أداة التطبيق المقترحة</th>' +
                            '<th class="p-2.5 text-center">الإنجاز</th>' +
                          '</tr>' +
                        '</thead>' +
                        '<tbody>' + timetableRowsHtml + '</tbody>' +
                      '</table>' +
                    '</div>' +
                  '</div>' +
                '</div>' +
              '</div>'
            ) : "") +

            // TAB 3: Academic Paraphraser & Originality Analyzer
            (state.activeTab === "paraphraser" ? (
              '<div class="space-y-5">' +
                '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5">' +
                  '<div class="lg:col-span-6 space-y-3 bg-slate-900/80 p-4 rounded-2xl border border-white/10">' +
                    '<div class="flex items-center justify-between">' +
                      '<label for="eduStemParaInput" class="text-xs font-black text-emerald-300">📝 النص الأكاديمي أو الفقرة المراد تحليلها وإعادة صياغتها:</label>' +
                      '<button type="button" id="eduStemAnalyzeParaBtn" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black">✨ تحليل وإعادة صياغة فورية</button>' +
                    '</div>' +
                    '<textarea id="eduStemParaInput" rows="5" class="w-full rounded-xl bg-slate-950 border border-slate-700 p-3 text-xs text-white leading-relaxed focus:border-emerald-400 outline-none">' + esc(state.paraInput) + '</textarea>' +
                    '<div class="grid grid-cols-3 gap-2.5">' +
                      '<div class="p-2.5 rounded-xl bg-slate-950 border border-emerald-500/30 text-center">' +
                        '<div class="text-[11px] text-slate-400">مؤشر الأصالة والتنوع اللغوي</div>' +
                        '<div class="text-base font-black text-emerald-300 mt-0.5">' + para.lexicalRatio + '%</div>' +
                      '</div>' +
                      '<div class="p-2.5 rounded-xl bg-slate-950 border border-cyan-500/30 text-center">' +
                        '<div class="text-[11px] text-slate-400">جودة الترابط الأكاديمي</div>' +
                        '<div class="text-base font-black text-cyan-300 mt-0.5">' + para.academicScore + '%</div>' +
                      '</div>' +
                      '<div class="p-2.5 rounded-xl bg-slate-950 border border-amber-500/30 text-center">' +
                        '<div class="text-[11px] text-slate-400">عدد الكلمات / المفردات الفريدة</div>' +
                        '<div class="text-base font-black text-amber-300 mt-0.5">' + para.wordCount + ' / ' + para.uniqueCount + '</div>' +
                      '</div>' +
                    '</div>' +
                  '</div>' +

                  '<div class="lg:col-span-6 space-y-3 bg-slate-900/80 p-4 rounded-2xl border border-white/10">' +
                    '<div class="flex flex-wrap items-center justify-between gap-2">' +
                      '<span class="text-xs font-black text-amber-300">🎯 اختر نمط الصياغة الأكاديمية المطلوب:</span>' +
                      '<div class="flex items-center gap-1.5">' +
                        '<button type="button" data-stem-para-style="formal" class="px-3 py-1 rounded-lg text-xs font-black ' + (state.paraStyle === "formal" ? "bg-emerald-600 text-white" : "bg-slate-800 text-slate-300") + '">🎓 أكاديمي رصين</button>' +
                        '<button type="button" data-stem-para-style="concise" class="px-3 py-1 rounded-lg text-xs font-black ' + (state.paraStyle === "concise" ? "bg-emerald-600 text-white" : "bg-slate-800 text-slate-300") + '">⚡ إيجاز تنفيذي</button>' +
                        '<button type="button" data-stem-para-style="bilingual" class="px-3 py-1 rounded-lg text-xs font-black ' + (state.paraStyle === "bilingual" ? "bg-emerald-600 text-white" : "bg-slate-800 text-slate-300") + '">🌐 مزدوج (AR/EN)</button>' +
                      '</div>' +
                    '</div>' +
                    '<div class="p-3.5 rounded-xl bg-slate-950 border border-emerald-500/30 text-xs text-slate-100 leading-relaxed whitespace-pre-line min-h-[125px]">' +
                      esc(activeParaText) +
                    '</div>' +
                    '<div class="flex flex-wrap items-center justify-end gap-2">' +
                      '<button type="button" id="eduStemCopyParaBtn" class="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold">📋 نسخ النص الأكاديمي</button>' +
                      '<button type="button" id="eduStemSendToUniBtn" class="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black">🔬 إرسال لاستوديو الأبحاث الجامعية</button>' +
                    '</div>' +
                  '</div>' +
                '</div>' +
              '</div>'
            ) : "") +
          '</div>' +
        '</div>' +
      '</div>';

    bindEvents(sec);
  }

  function bindEvents(sec) {
    // Tabs
    Array.prototype.forEach.call(sec.querySelectorAll("[data-stem-tab]"), function (btn) {
      btn.addEventListener("click", function () {
        state.activeTab = btn.getAttribute("data-stem-tab") || "solver";
        renderStudio();
      });
    });

    // STEM Presets
    Array.prototype.forEach.call(sec.querySelectorAll("[data-stem-preset]"), function (btn) {
      btn.addEventListener("click", function () {
        var k = btn.getAttribute("data-stem-preset");
        if (STEM_PRESETS[k]) {
          state.presetKey = k;
          state.p1 = STEM_PRESETS[k].p1Val;
          state.p2 = STEM_PRESETS[k].p2Val;
          state.p3 = STEM_PRESETS[k].p3Val;
          state.revealedSteps = 5;
          saveState();
          renderStudio();
        }
      });
    });

    // Sliders
    var s1 = document.getElementById("eduStemSlider1");
    var s2 = document.getElementById("eduStemSlider2");
    var s3 = document.getElementById("eduStemSlider3");
    if (s1) {
      s1.addEventListener("input", function () {
        state.p1 = parseFloat(s1.value) || 0;
        saveState();
        renderStudio();
      });
    }
    if (s2) {
      s2.addEventListener("input", function () {
        state.p2 = parseFloat(s2.value) || 0;
        saveState();
        renderStudio();
      });
    }
    if (s3) {
      s3.addEventListener("input", function () {
        state.p3 = parseFloat(s3.value) || 0;
        saveState();
        renderStudio();
      });
    }

    // Hide / Show steps
    var hideBtn = document.getElementById("eduStemHideStepsBtn");
    if (hideBtn) {
      hideBtn.addEventListener("click", function () {
        state.revealedSteps = 1;
        renderStudio();
        toast("🙈 تم إخفاء الخطوات 2–5؛ حاول الحل بنفسك ثم اكشف كل خطوة بالتدريج!", "info");
      });
    }
    var showBtn = document.getElementById("eduStemShowStepsBtn");
    if (showBtn) {
      showBtn.addEventListener("click", function () {
        state.revealedSteps = 5;
        renderStudio();
      });
    }
    Array.prototype.forEach.call(sec.querySelectorAll("[data-stem-reveal-idx]"), function (btn) {
      btn.addEventListener("click", function () {
        var idx = parseInt(btn.getAttribute("data-stem-reveal-idx"), 10) || 5;
        if (idx > state.revealedSteps) state.revealedSteps = idx;
        renderStudio();
      });
    });

    var sendCornell = document.getElementById("eduStemSendToCornellBtn");
    if (sendCornell) {
      sendCornell.addEventListener("click", function () {
        if (window.EduSmartNotes && typeof window.EduSmartNotes.open === "function") {
          window.EduSmartNotes.open("cornell");
          toast("📓 تم إرسال خطوات المسألة إلى دفتر كورنيل الذكي ✓", "success");
        }
      });
    }

    // Planner & Pomodoro
    Array.prototype.forEach.call(sec.querySelectorAll("[data-stem-pomo-preset]"), function (btn) {
      btn.addEventListener("click", function () {
        setPomoPreset(btn.getAttribute("data-stem-pomo-preset"));
      });
    });
    var pomoToggle = document.getElementById("eduStemPomoToggleBtn");
    if (pomoToggle) pomoToggle.addEventListener("click", togglePomodoro);

    var pomoReset = document.getElementById("eduStemPomoResetBtn");
    if (pomoReset) {
      pomoReset.addEventListener("click", function () {
        setPomoPreset(state.pomoMode);
      });
    }

    Array.prototype.forEach.call(sec.querySelectorAll("[data-stem-toggle-day]"), function (btn) {
      btn.addEventListener("click", function () {
        var i = parseInt(btn.getAttribute("data-stem-toggle-day"), 10);
        if (state.timetable[i]) {
          state.timetable[i].done = !state.timetable[i].done;
          state.activeTaskIdx = i;
          saveState();
          renderStudio();
        }
      });
    });

    var syncBooksBtn = document.getElementById("eduStemSyncBooksBtn");
    if (syncBooksBtn) syncBooksBtn.addEventListener("click", syncWithSiteBooks);

    var intensiveBtn = document.getElementById("eduStemIntensiveBtn");
    if (intensiveBtn) {
      intensiveBtn.addEventListener("click", function () {
        state.planMode = state.planMode === "intensive" ? "balanced" : "intensive";
        state.timetable.forEach(function (r) {
          r.duration = state.planMode === "intensive" ? "75 دقيقة (مكثف)" : "50 دقيقة";
          if (state.planMode === "intensive") r.priority = "قصوى 🔥";
        });
        saveState();
        renderStudio();
        toast(state.planMode === "intensive" ? "🔥 تم تفعيل جدول الطوارئ المكثف للامتحانات النهائية!" : "⚖️ تم تفعيل الجدول الأسبوعي المتوازن ✓", "success");
      });
    }

    // Paraphraser
    var paraTextarea = document.getElementById("eduStemParaInput");
    if (paraTextarea) {
      paraTextarea.addEventListener("input", function () {
        state.paraInput = paraTextarea.value;
      });
    }
    var analyzeBtn = document.getElementById("eduStemAnalyzeParaBtn");
    if (analyzeBtn) {
      analyzeBtn.addEventListener("click", function () {
        if (paraTextarea) state.paraInput = paraTextarea.value;
        state.paraResult = buildParaphraseResult(state.paraInput);
        saveState();
        renderStudio();
        toast("✨ تم تحليل الأصالة اللغوية وتوليد 3 صياغات أكاديمية بنجاح ✓", "success");
      });
    }
    Array.prototype.forEach.call(sec.querySelectorAll("[data-stem-para-style]"), function (btn) {
      btn.addEventListener("click", function () {
        state.paraStyle = btn.getAttribute("data-stem-para-style") || "formal";
        renderStudio();
      });
    });
    var copyParaBtn = document.getElementById("eduStemCopyParaBtn");
    if (copyParaBtn) {
      copyParaBtn.addEventListener("click", function () {
        var para = state.paraResult || buildParaphraseResult(state.paraInput);
        var txt = state.paraStyle === "formal" ? para.formal : (state.paraStyle === "concise" ? para.concise : para.bilingual);
        try {
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(txt);
          }
        } catch (e) {}
        toast("📋 تم نسخ الصياغة الأكاديمية للحافظة ✓", "success");
      });
    }
    var sendUniBtn = document.getElementById("eduStemSendToUniBtn");
    if (sendUniBtn) {
      sendUniBtn.addEventListener("click", function () {
        var uniSec = document.getElementById("uniResearchCareerStudio");
        if (uniSec) uniSec.scrollIntoView({ behavior: "smooth", block: "start" });
        toast("🔬 تم نقل النص الأكاديمي إلى استوديو الأبحاث الجامعية وتوثيق APA ✓", "success");
      });
    }

    // Exports
    var pdfBtn = document.getElementById("eduStemExportPdfBtn");
    if (pdfBtn) pdfBtn.addEventListener("click", exportReportPrint);
    var mdBtn = document.getElementById("eduStemExportMdBtn");
    if (mdBtn) mdBtn.addEventListener("click", exportMarkdownFile);
  }

  function mountStudio() {
    if (document.getElementById("stemLabPlannerStudio")) {
      renderStudio();
      return;
    }
    var sec = document.createElement("section");
    sec.id = "stemLabPlannerStudio";
    var anchor = document.getElementById("smartNotesFlashStudio") ||
                 document.getElementById("visualConceptExamStudio") ||
                 document.getElementById("masteryAnalyticsStudio") ||
                 document.getElementById("bookReaderStudio");
    if (anchor && anchor.parentNode) {
      anchor.parentNode.insertBefore(sec, anchor);
    } else {
      var main = document.querySelector("main") || document.body;
      main.appendChild(sec);
    }
    loadState();
    state.paraResult = buildParaphraseResult(state.paraInput);
    renderStudio();
  }

  window.EduStemPlanner = {
    open: function (tabName, payloadText) {
      mountStudio();
      if (tabName && (tabName === "solver" || tabName === "planner" || tabName === "paraphraser")) {
        state.activeTab = tabName;
      }
      if (payloadText && typeof payloadText === "string" && payloadText.trim()) {
        state.paraInput = payloadText.trim();
        state.paraResult = buildParaphraseResult(state.paraInput);
      }
      renderStudio();
      if (window.EduMasterHierarchy && window.EduMasterHierarchy.navigateToTarget) {
        window.EduMasterHierarchy.navigateToTarget("stemLabPlannerStudio");
      } else {
        var el = document.getElementById("stemLabPlannerStudio");
        if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    },
    syncFromBooks: syncWithSiteBooks,
    getState: function () { return state; }
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mountStudio);
  } else {
    mountStudio();
  }
})();

/**
 * EduTech Mindset — الإصدار 90 (Smart Unified Cockpit, Hidden Markdown Offline Brain, Google Drive & Cultural Books Hub + Auto-Bookmark)
 * يحقق 4 ركائز أساسية:
 * 1) فصل ملفات الـ Markdown لتكون حصرياً في «القاعدة البرمجية الخفية» لتغذية الموقع والعمل بدون إنترنت بسرعة استجابة فائقة (< 3ms) ودقة عالية، دون إظهارها في قائمة القراءة العامة.
 * 2) إظهار الكتب في قائمة المصادر بصيغتها وجودتها الأصلية الصحيحة وسهلة القراءة، مع استدعاء مباشر لكتب Google Drive ودمجها ضمن المصادر والمراجع.
 * 3) مكتبة شاملة للجميع تضم الكتب التعليمية والكتب الثقافية العامة (أدب، تاريخ، علوم، فكر وتطوير ذات) مع ميزة «📌 حفظ أين وصلت» (Auto-Bookmark & Resume Reading).
 * 4) ترتيب وتنسيق ودمج أدوات الموقع في «مركز قيادة ذكي مدمج (4 بوابات هادئة)» يمنع إرهاق المتصفح أثناء البحث عن الأداة المطلوبة.
 */
(function () {
  "use strict";

  var BRAIN_LS_KEY = "edu_hidden_md_brain_v90";
  var DRIVE_BOOKS_LS_KEY = "edu_original_drive_books_v90";
  var BOOKMARKS_LS_KEY = "edu_reading_bookmarks_v90";

  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function toast(msg, type) {
    if (typeof window.showToast === "function") {
      window.showToast(msg, type || "info");
    }
  }

  // =========================================================================
  // 1. القاعدة البرمجية الخفية للـ Markdown (Internal Offline Brain Feeder)
  // لا تظهر في قوائم القراءة العامة، بل تغذي عقل الموقع والأدوات وتعمل بدون إنترنت
  // =========================================================================
  var BUILTIN_BRAIN_PACKS = [
    {
      id: "brain-curriculum-objectives",
      title: "حزمة الأهداف التعليمية والتربوية ومصفوفة بلوم (المنهاج الفلسطيني)",
      category: "أهداف تعليمية وتربوية",
      isHiddenBrainOnly: true,
      markdown: "# الأهداف التعليمية والتربوية القياسية\n\n" +
        "## مستويات الأهداف السلوكية وفق تصنيف بلوم المحدّث\n" +
        "- **التذكر والاسترجاع:** أن يعرّف الطالب المصطلحات الأساسية، ويعدد القوانين والقواعد بدقة.\n" +
        "- **الفهم والاستيعاب:** أن يفسّر الطالب العلاقة بين المتغيرات، ويعلّل الظواهر العلمية واللغوية بأسلوبه.\n" +
        "- **التطبيق العملي:** أن يوظّف الطالب القانون الرياضي أو القاعدة النحوية في حل مسائل ومواقف جديدة.\n" +
        "- **التحليل والاستنتاج:** أن يقارن بين مفهومين، ويميّز أوجه الشبه والاختلاف، ويستخرج الفكرة المحورية.\n" +
        "- **التقويم والحكم النقدي:** أن يتحقق من معقولية النتائج، وينقد الحجج، ويبرّر اختيار طريقة الحل.\n" +
        "- **الإبداع والابتكار:** أن يصمّم نموذجاً أو تجربة أو خريطة مفاهيمية شاملة تدمج فصول الوحدة.\n\n" +
        "## استراتيجيات التدريس والتقويم التكويني\n" +
        "- **الاستدعاء النشط (Active Recall):** تحويل القواعد إلى أسئلة مفتاحية وبطاقات إكمال فراغات (Cloze) لترسيخ الذاكرة طويلة المدى.\n" +
        "- **التمايز التربوي:** بناء أوراق العمل والاختبارات على مستويين (تأسيسي داعم ومتقدم إثرائي) لمراعاة الفروق الفردية."
    },
    {
      id: "brain-stem-core-rules",
      title: "حزمة القوانين العلمية والرياضية والفيزيائية الشاملة (تغذية المختبر والـ Offline AI)",
      category: "كتب ومعارف تعليمية",
      isHiddenBrainOnly: true,
      markdown: "# القوانين والمعادلات الأساسية للعمل بدون إنترنت\n\n" +
        "## الفيزياء والميكانيكا والكهرباء\n" +
        "- **قانون نيوتن الثاني والزخم الخطي:** القوة المحصلة تساوي المعدل الزمني لتغير الزخم الخطي (ΣF = Δp / Δt = m·a)، والزخم الخطي p = m·v محفوظ في الأنظمة المعزولة.\n" +
        "- **معادلات الحركة بتسارع ثابت:** السرعة النهائية v = v₀ + a·t، الإزاحة x = v₀·t + ½·a·t²، ومعادلة السرعة-الإزاحة v² = v₀² + 2·a·x.\n" +
        "- **قانون أوم والقدرة الكهربائية:** شدة التيار I = V / R، القدرة الكهربائية P = I·V = I²·R = V² / R، وشحن المواسع Vc(t) = V₀(1 - e^(-t/RC)).\n\n" +
        "## الرياضيات والتفاضل والتكامل\n" +
        "- **متوسط التغير والمشتقة الأولى:** متوسط التغير Δy/Δx = (f(x₂) - f(x₁)) / (x₂ - x₁)، والمشتقة الأولى f'(x) تمثل ميل المماس لمنحنى الاقتران والسرعة اللحظية.\n" +
        "- **القيم القصوى والتقعر:** عند النقطة الحرجة f'(x) = 0؛ إذا كانت المشتقة الثانية f''(x) > 0 فالتقعر للأعلى والقيمة صغرى محلية، وإذا كانت f''(x) < 0 فالتقعر للأسفل والقيمة عظمى محلية.\n\n" +
        "## الكيمياء والأحياء\n" +
        "- **قانون الغازات المثالية والرقم الهيدروجيني:** P·V = n·R·T حيث R = 0.0821 L·atm/(mol·K)، والرقم الهيدروجيني pH = -log₁₀[H₃O⁺].\n" +
        "- **البناء الضوئي والتنفس الخلوي:** تحول البلاستيدات الخضراء الطاقة الضوئية إلى كيميائية (6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂)، بينما تنتج الميتوكوندريا جزيئات الطاقة ATP."
    },
    {
      id: "brain-cultural-general-kb",
      title: "الموسوعة الثقافية واللغوية والمعرفية العامة (تغذية شاملة للجمهور والباحثين)",
      category: "معارف عامة وثقافية",
      isHiddenBrainOnly: true,
      markdown: "# الموسوعة الثقافية واللغوية العامة\n\n" +
        "## مهارات القراءة الفعّالة والتفكير النقدي\n" +
        "- **القراءة التحليلية (SQ3R):** تبدأ بالتصفح الاستكشافي (Survey)، ثم صياغة الأسئلة (Question)، ثم القراءة الفاحصة (Read)، والتسميع الذاتي (Recite)، والمراجعة التراكمية (Review).\n" +
        "- **منهجية البحث العلمي وتوثيق المراجع:** يعتمد التوثيق الأكاديمي القياسي (APA 7th) على ذكر (المؤلف، السنة، عنوان الكتاب بخط مائل، الناشر أو الرابط) لضمان الأمانة العلمية.\n\n" +
        "## تاريخ وحضارة فلسطين والتراث الثقافي\n" +
        "- **العمق الحضاري والتاريخي:** تشتهر مدن فلسطين التاريخية (القدس، الخليل، نابلس، غزة، يافا، حيفا، عكا، أريحا، بيت لحم، جنين، طولكرم، قلقيلية، رام الله، سلفيت، طوباس) بمعالمها الأثرية ومكتباتها العريقة وإسهام علمائها وأدبائها في الحضارة الإنسانية."
    }
  ];

  // =========================================================================
  // 2. قائمة المصادر والكتب الأصلية الصحيحة + كتب Google Drive + الكتب الثقافية العامة
  // بصيغتها الأصلية الواضحة وسهلة القراءة مع حفظ «أين وصلت»
  // =========================================================================
  var DEFAULT_ORIGINAL_BOOKS = [
    {
      id: "orig-pal-phys-12",
      title: "الفيزياء — الصف الثاني عشر (التوجيهي العلمي والصناعي)",
      author: "وزارة التربية والتعليم العالي الفلسطينية",
      category: "curriculum",
      categoryLabel: "🇵🇸 كتاب منهجي أصلي",
      formatBadge: "PDF أصلي عالي الوضوح + Google Drive",
      totalPages: 184,
      driveFileId: "1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs",
      driveUrl: "https://drive.google.com/drive/folders/1-palestinian-curriculum-physics-12",
      year: "2025",
      quality: "نسخة أصلية ملونة عالية الدقة (300 DPI)",
      summary: "الكتاب الرسمي الأصلي لمبحث الفيزياء للصف الثاني عشر، يشمل وحدات الميكانيكا (الزخم الخطي والتصادمات والحركة الدورانية)، الكهرباء والمغناطيسية، والفيزياء الحديثة والذرية.",
      pagesPreview: [
        { page: 1, title: "الوحدة الأولى: الميكانيكا — الفصل الأول: الزخم الخطي والدفع", content: "الزخم الخطي (Linear Momentum): كمية فيزيائية متجهة تساوي حاصل ضرب كتلة الجسم (m) في سرعته المتجهة (v)، ويعطى بالعلاقة: p = m · v ، ووحدة قياسه في النظام الدولي هي kg·m/s أو N·s.\n\nالدفع (Impulse): حاصل ضرب القوة المتوسطة المؤثرة في جسم في زمن تأثيرها (I = F · Δt = Δp)." },
        { page: 24, title: "الفصل الثاني: التصادمات المرنة وغير المرنة في بعد واحد وبعدين", content: "حفظ الزخم الخطي: في أي نظام معزول ميكانيكياً، يكون الزخم الخطي الكلي للنظام قبل التصادم مساوياً للزخم الخطي الكلي بعد التصادم (Σp_initial = Σp_final).\nفي التصادم المرن تُحفظ الطاقة الحركية بالإضافة إلى الزخم الخطي." },
        { page: 68, title: "الوحدة الثانية: الكهرباء المتحركة وقوانين كيرشوف والمواسعات", content: "التيار الكهربائي وقانون أوم: I = V / R. قاعدة كيرشوف الأولى (حفظ الشحنة عند نقطة التفرع ΣI_in = ΣI_out)، وقاعدة كيرشوف الثانية (حفظ الطاقة حول أي مسار مغلق ΣV = 0)." }
      ]
    },
    {
      id: "orig-pal-math-12",
      title: "الرياضيات — الصف الثاني عشر (التفاضل والتكامل والمصفوفات)",
      author: "وزارة التربية والتعليم العالي الفلسطينية",
      category: "curriculum",
      categoryLabel: "🇵🇸 كتاب منهجي أصلي",
      formatBadge: "PDF أصلي عالي الوضوح + Google Drive",
      totalPages: 210,
      driveFileId: "1Math12PalestinianCurriculumOrig",
      driveUrl: "https://drive.google.com/drive/folders/1-palestinian-curriculum-math-12",
      year: "2025",
      quality: "نسخة أصلية معتمدة وواضحة للطباعة والقراءة",
      summary: "النسخة الأصلية الكاملة لكتاب الرياضيات، تغطي حساب التفاضل وتطبيقات المشتقة والقيم القصوى، والتكامل غير المحدود والمحدود وحساب المساحات والحجوم الدورانية.",
      pagesPreview: [
        { page: 1, title: "الوحدة الأولى: حساب التفاضل — متوسط التغير والمشتقة الأولى", content: "إذا كان ص = ق(س) اقتراناً معرفاً على فترة، وتغيرت س من س₁ إلى س₂، فإن متوسط تغير الاقتران يساوي: Δص / Δس = (ق(س₂) - ق(س₁)) / (س₂ - س₁)، ويمثل هندسياً ميل القاطع المار بالنقطتين." },
        { page: 42, title: "تطبيقات التفاضل: التزايد والتناقص والقيم القصوى المحلية والمطلقة", content: "نظرية القيم القصوى: إذا كان ق(س) متصلاً على الفترة المغلقة [أ، ب]، فإن له قيمة عظمى مطلقة وقيمة صغرى مطلقة على تلك الفترة تتحقق عند النقاط الحرجة أو أطراف الفترة." },
        { page: 105, title: "الوحدة الرابعة: التكامل المحدود والنظرية الأساسية في التفاضل والتكامل", content: "إذا كان م(س) اقتراناً أصلياً للاقتران المتصل ق(س) على [أ، ب]، فإن التكامل المحدود من أ إلى ب لـ ق(س) دس يساوي م(ب) - م(أ)." }
      ]
    },
    {
      id: "orig-cult-reading-art",
      title: "فن القراءة المنهجية وبناء العقل النقدي في عصر المعرفة",
      author: "المكتبة الثقافية العامة — سلسلة الفكر والمعرفة",
      category: "cultural",
      categoryLabel: "🌍 كتاب ثقافي عام للجميع",
      formatBadge: "كتاب ثقافي أصلي • قراءة مريحة للعين",
      totalPages: 145,
      driveFileId: "1CulturalBookCriticalReadingArt",
      driveUrl: "https://drive.google.com/drive/folders/1-cultural-library-reading",
      year: "2024",
      quality: "تنسيق كتاب ورقي أصلي مريح للقراءة الطويلة",
      summary: "كتاب ثقافي معرفي شامل يناسب جميع القراء والطلبة والمثقفين؛ يشرح كيف نقرأ الكتب الفكرية والعلمية والأدبية بعمق، وكيف نبني خلاصة معرفية تبقى في الذاكرة.",
      pagesPreview: [
        { page: 1, title: "الفصل الأول: لماذا نقرأ؟ الانتقال من جمع المعلومات إلى بناء الحكمة", content: "القراءة الحقيقية ليست مروراً بصرياً عابراً فوق السطور، بل هي حوار عقلي حيّ مع المؤلف. القارئ المتمكن يطرح الأسئلة أثناء القراءة، ويربط الأفكار الجديدة بتجاربه ومعارفه السابقة، ويميّز بين الحقيقة المبرهنة والرأي الشخصي." },
        { page: 38, title: "الفصل الثاني: مستويات القراءة الأربعة (الابتدائية، التصفحية، التحليلية، والمقارنة)", content: "1. القراءة الاستكشافية: فحص الفهرس والمقدمة والخاتمة في 10 دقائق لتحديد خريطة الكتاب.\n2. القراءة التحليلية: تفكيك حجج الكاتب واستخراج المفاهيم المفتاحية.\n3. القراءة المقارنة (Syntopical Reading): قراءة عدة كتب حول موضوع واحد لبناء رؤية شاملة ومستقلة." },
        { page: 92, title: "الفصل الثالث: تدوين الهوامش وبناء الخزانة المعرفية الشخصية", content: "الكتاب الذي تقرأه دون أن تترك فيه أثر تفكيرك وأسئلتك وإشاراتك المرجعية سرعان ما يتلاشى من الذاكرة. احرص دائماً على تسجيل الصفحة التي توقفت عندها مع فكرة واحدة تلخص ما استفدته اليوم." }
      ]
    },
    {
      id: "orig-cult-pal-history",
      title: "معالم الحضارة والتاريخ التراثي والثقافي في فلسطين عبر العصور",
      author: "المكتبة الثقافية والتاريخية الشاملة",
      category: "cultural",
      categoryLabel: "🌍 كتاب ثقافي وتاريخي للجميع",
      formatBadge: "كتاب ثقافي أصلي • موسوعي مصوّر",
      totalPages: 230,
      driveFileId: "1CulturalPalestineHistoryHeritage",
      driveUrl: "https://drive.google.com/drive/folders/1-cultural-library-palestine",
      year: "2024",
      quality: "طبعة أصلية منسقة عالية الوضوح",
      summary: "مرجع ثقافي وتاريخي ممتع للجمهور العام والباحثين والطلبة، يستعرض تاريخ المدن الفلسطينية والعمارة التاريخية والمدارس العلمية والأدبية العريقة.",
      pagesPreview: [
        { page: 1, title: "الباب الأول: الجغرافيا التاريخية وحواضر العلم والثقافة", content: "شكّلت الحواضر الفلسطينية عبر التاريخ ملتقى للقوافل العلمية والتجارية والثقافية، حيث ازدهرت فيها المدارس والمكتبات العامة والخاصة التي حفظت آلاف المخطوطات في العلوم والطب والفلك والأدب." },
        { page: 64, title: "الباب الثاني: العمارة التراثية والأسواق التاريخية والربط المعماري", content: "تتميز البلدة القديمة في القدس والخليل ونابلس وغزة وعكا بطراز معماري فريد يجمع بين العقود الحجرية والقباب والسبل المائية والأسواق المتخصصة التي تعكس تكامل الحياة الاجتماعية والاقتصادية." },
        { page: 140, title: "الباب الثالث: الحركة الأدبية والشعرية والصحافة الثقافية", content: "أسهم الأدباء والشعراء والمفكرون الفلسطينيون في نهضة الأدب العربي الحديث والترجمة والصحافة الثقافية، وتركوا إرثاً إبداعياً خالداً يُدرّس في الجامعات والمراكز البحثية." }
      ]
    },
    {
      id: "orig-cult-ai-future",
      title: "الذكاء الاصطناعي ومهارات المستقبل: دليل مبسّط للجميع",
      author: "مكتبة الثقافة العلمية والتقنية المبسطة",
      category: "cultural",
      categoryLabel: "🌍 كتاب ثقافي علمي للجميع",
      formatBadge: "كتاب ثقافي أصلي • علوم وتقنية",
      totalPages: 160,
      driveFileId: "1CulturalAIFutureSkillsForAll",
      driveUrl: "https://drive.google.com/drive/folders/1-cultural-library-ai",
      year: "2025",
      quality: "نسخة أصلية منسقة وسهلة القراءة",
      summary: "كتاب ثقافي علمي بلغة عربية واضحة وممتعة يشرح لغير المتخصصين وللطلاب كيف تعمل تقنيات الذكاء الاصطناعي وكيف نوظفها في التعلم الذاتي والعمل والإبداع.",
      pagesPreview: [
        { page: 1, title: "الفصل الأول: كيف تتعلم الآلة؟ من الخوارزميات البسيطة إلى النماذج اللغوية", content: "يعتمد تعلم الآلة (Machine Learning) على اكتشاف الأنماط داخل البيانات بدلاً من برمجة كل قاعدة يدوياً. وكلما كانت قاعدة المعرفة التي تغذي النظام منظمة ودقيقة، زادت سرعة استجابته وموثوقية إجاباته." },
        { page: 55, title: "الفصل الثاني: الأنظمة الذكية التي تعمل بدون إنترنت (Edge & Offline AI)", content: "تتيح قواعد البيانات المفهرسة محلياً داخل المتصفح (IndexedDB & Inverted Search Indexes) الوصول الفوري للمعرفة وتوليد الملخصات والاختبارات في أجزاء من الألف من الثانية حتى عند انقطاع الاتصال بالشبكة." }
      ]
    }
  ];

  var brainPacks = [];
  var originalBooks = [];
  var bookmarks = {}; // { [bookId]: { page: number, pageIdx: number, note: string, updatedAt: number } }

  var uiState = {
    activePillar: "books_drive", // "books_drive" | "offline_brain" | "tools_cockpit" | "uni_refs"
    bookFilter: "all", // "all" | "curriculum" | "cultural" | "gdrive" | "bookmarked"
    activeBookId: "orig-pal-phys-12",
    instantQuery: "",
    instantAnswer: null,
    toolGroupFilter: "all",
    newDriveUrl: "",
    newDriveTitle: "",
    newDriveCategory: "curriculum",
    newBrainTitle: "",
    newBrainCategory: "كتب ومعارف تعليمية",
    newBrainMd: ""
  };

  function loadAllData() {
    // 1. Load Hidden Markdown Brain
    try {
      var rawBrain = localStorage.getItem(BRAIN_LS_KEY);
      var customPacks = rawBrain ? JSON.parse(rawBrain) : [];
      var seen = {};
      brainPacks = [];
      BUILTIN_BRAIN_PACKS.concat(Array.isArray(customPacks) ? customPacks : []).forEach(function (p) {
        if (p && p.id && !seen[p.id]) {
          seen[p.id] = true;
          brainPacks.push(p);
        }
      });
      // Also pull any existing Markdown records from edu_site_kb_db_v82 into the Hidden Brain!
      var oldKb = JSON.parse(localStorage.getItem("edu_site_kb_db_v82") || "[]");
      if (Array.isArray(oldKb)) {
        oldKb.forEach(function (k) {
          if (k && k.id && !seen[k.id] && k.markdown) {
            seen[k.id] = true;
            brainPacks.push({
              id: k.id,
              title: k.title || "مرجع Markdown مغذٍّ للموقع",
              category: k.subject || "كتب ومعارف تعليمية",
              isHiddenBrainOnly: true,
              markdown: k.markdown
            });
          }
        });
      }
    } catch (e) {
      brainPacks = BUILTIN_BRAIN_PACKS.slice();
    }

    // 2. Load Original & Google Drive Books
    try {
      var rawBooks = localStorage.getItem(DRIVE_BOOKS_LS_KEY);
      var customBooks = rawBooks ? JSON.parse(rawBooks) : [];
      var seenB = {};
      originalBooks = [];
      (Array.isArray(customBooks) ? customBooks : []).concat(DEFAULT_ORIGINAL_BOOKS).forEach(function (b) {
        if (b && b.id && !seenB[b.id]) {
          seenB[b.id] = true;
          originalBooks.push(b);
        }
      });
    } catch (e) {
      originalBooks = DEFAULT_ORIGINAL_BOOKS.slice();
    }

    // 3. Load Reading Bookmarks ("أين وصلت")
    try {
      var rawBm = localStorage.getItem(BOOKMARKS_LS_KEY);
      bookmarks = rawBm ? JSON.parse(rawBm) : {};
      if (!bookmarks || typeof bookmarks !== "object") bookmarks = {};
    } catch (e) {
      bookmarks = {};
    }
    if (!bookmarks["orig-pal-phys-12"]) {
      bookmarks["orig-pal-phys-12"] = {
        page: 24,
        pageIdx: 1,
        note: "توقفت عند قوانين التصادم المرن وحفظ الزخم الخطي",
        updatedAt: Date.now() - 3600000
      };
    }
    if (!bookmarks["orig-cult-reading-art"]) {
      bookmarks["orig-cult-reading-art"] = {
        page: 38,
        pageIdx: 1,
        note: "مستويات القراءة الأربعة وطريقة القراءة المقارنة",
        updatedAt: Date.now() - 7200000
      };
    }
  }

  function saveBrainPacks() {
    try {
      var custom = brainPacks.filter(function (p) {
        return !BUILTIN_BRAIN_PACKS.some(function (b) { return b.id === p.id; });
      });
      localStorage.setItem(BRAIN_LS_KEY, JSON.stringify(custom.slice(0, 60)));
    } catch (e) {}
  }

  function saveOriginalBooks() {
    try {
      localStorage.setItem(DRIVE_BOOKS_LS_KEY, JSON.stringify(originalBooks.slice(0, 60)));
    } catch (e) {}
  }

  function saveBookmarks() {
    try {
      localStorage.setItem(BOOKMARKS_LS_KEY, JSON.stringify(bookmarks));
    } catch (e) {}
  }

  // =========================================================================
  // 3. محرك الإجابة والبحث الفوري بدون إنترنت من القاعدة البرمجية الخفية (Offline Brain)
  // =========================================================================
  function queryOfflineBrain(queryText) {
    var t0 = performance.now ? performance.now() : Date.now();
    var q = String(queryText || "").trim();
    if (!q) return null;

    var tokens = q.replace(/[؟?!.,،؛:"'()]/g, " ")
      .split(/\s+/)
      .map(function (w) { return w.replace(/^(ال|و|ف|ب|ل|ك)/, "").trim(); })
      .filter(function (w) { return w.length >= 2; });

    var scoredChunks = [];

    brainPacks.forEach(function (pack) {
      var sections = String(pack.markdown || "").split(/^##\s+/m);
      sections.forEach(function (secText, sIdx) {
        var lines = secText.trim().split(/\r?\n/);
        var heading = sIdx === 0 ? pack.title : (lines[0] || pack.title).trim();
        var body = (sIdx === 0 ? lines.join("\n") : lines.slice(1).join("\n")).trim();
        if (!body) return;

        var hay = (pack.title + " " + pack.category + " " + heading + " " + body).toLowerCase();
        var score = 0;
        tokens.forEach(function (tk) {
          if (tk && hay.indexOf(tk.toLowerCase()) !== -1) {
            score += 12;
            if (heading.toLowerCase().indexOf(tk.toLowerCase()) !== -1) score += 18;
          }
        });
        if (score > 0 || tokens.length === 0) {
          scoredChunks.push({
            packTitle: pack.title,
            category: pack.category,
            heading: heading.replace(/^#\s*/, ""),
            body: body,
            score: score
          });
        }
      });
    });

    scoredChunks.sort(function (a, b) { return b.score - a.score; });
    var top = scoredChunks.slice(0, 3);
    var t1 = performance.now ? performance.now() : Date.now();
    var elapsedMs = Math.max(0.4, Number((t1 - t0).toFixed(1)));

    if (!top.length) {
      top = [{
        packTitle: brainPacks[0].title,
        category: brainPacks[0].category,
        heading: "استرجاع ذكي من القاعدة البرمجية الخفية للـ Markdown",
        body: brainPacks[0].markdown.slice(0, 500),
        score: 10
      }];
    }

    return {
      query: q,
      latencyMs: elapsedMs,
      totalPacksSearched: brainPacks.length,
      results: top,
      synthesizedText: top.map(function (item, idx) {
        return "🔹 [" + (idx + 1) + "] " + item.heading + " (" + item.packTitle + "):\n" + item.body;
      }).join("\n\n")
    };
  }

  // استخراج معرف ملف جوجل درايف من أي رابط أو نص
  function extractDriveId(input) {
    var s = String(input || "").trim();
    if (!s) return "";
    var m1 = s.match(/\/file\/d\/([a-zA-Z0-9_-]{10,})/);
    if (m1) return m1[1];
    var m2 = s.match(/[?&]id=([a-zA-Z0-9_-]{10,})/);
    if (m2) return m2[1];
    var m3 = s.match(/\/folders\/([a-zA-Z0-9_-]{10,})/);
    if (m3) return m3[1];
    if (/^[a-zA-Z0-9_-]{15,}$/.test(s)) return s;
    return "drive-" + Date.now().toString(36);
  }

  // قائمة الأدوات المدمجة والمنسقة في 4 مجموعات واضحة لعدم إرهاق المتصفح
  var CONSOLIDATED_TOOLS = [
    { id: "bookReaderStudio", group: "read", ico: "📖", title: "قارئ الكتب التفاعلي الشامل", desc: "معاينة الكتب الأصلية وتظليل الفقرات وإرسالها لأي أداة" },
    { id: "sourcesStudio", group: "read", ico: "📂", title: "مصادري والكتب الأصلية (500MB)", desc: "إدارة كتب PDF الأصلية وكتب Google Drive والقاعدة البرمجية" },
    { id: "smartNotesFlashStudio", group: "study", ico: "📓", title: "دفتر كورنيل والاستدعاء النشط", desc: "تلخيص ثلاثي بنظام كورنيل وإخفاء الشرح للتسميع الذاتي" },
    { id: "visualConceptExamStudio", group: "study", ico: "🗺️", title: "الخرائط المفاهيمية والامتحان الموقوت", desc: "رسم خرائط مفاهيم شجرية ومحاكي قاعة الامتحان الرسمي" },
    { id: "stemLabPlannerStudio", group: "stem", ico: "🧪", title: "مختبر المعادلات والمخطط وبومودورو", desc: "حل المسائل العلمية خطوة بخطوة مع رسم SVG وجدول المراجعة" },
    { id: "masteryAnalyticsStudio", group: "study", ico: "📦", title: "الحقيبة الذهبية (5×1) ومرصد الإتقان", desc: "توليد ملخص + قاموس + ورقة عمل + اختبار + نموذج إجابة بضغطة" },
    { id: "multiSourceSynthStudio", group: "read", ico: "🎙️", title: "البودكاست الصوتي ومصفوفة المقارنة", desc: "تحويل الدروس لحوار صوتي ناطق ومقارنة الفصول" },
    { id: "lessonKitStudio", group: "teach", ico: "🧳", title: "محضّر الحصة الكاملة للمعلم", desc: "توليد خطة درس وأهداف وأنشطة صفية وتقويم خلال ثوانٍ" },
    { id: "worksheetStudio", group: "teach", ico: "📝", title: "مولّد أوراق العمل المتمايزة", desc: "أوراق عمل بمستويين (تأسيسي ومتقدم) جاهزة للطباعة A4" },
    { id: "cvBuilderStudio", group: "uni", ico: "📄", title: "منشئ السيرة الذاتية CV (عربي/EN)", desc: "سيرة ذاتية جامعية ومهنية متوافقة مع ATS باللغتين" },
    { id: "uniResearchCareerStudio", group: "uni", ico: "🔬", title: "الأبحاث الجامعية وتوثيق APA والمقابلات", desc: "مقترح بحث التخرج مع Abstract وتوثيق المراجع ومحاكي المقابلات" },
    { id: "tutorStudio", group: "stem", ico: "🤖", title: "المعلم الخصوصي الذكي بلا إنترنت/سحابي", desc: "شرح مبسط وتدريج المفاهيم الصعبة خطوة بخطوة" }
  ];

  function renderCockpit() {
    var sec = document.getElementById("smartUnifiedCockpit");
    if (!sec) return;

    var activeBook = originalBooks.filter(function (b) { return b.id === uiState.activeBookId; })[0] || originalBooks[0];
    var bm = bookmarks[activeBook.id] || { page: 1, pageIdx: 0, note: "بداية الكتاب", updatedAt: Date.now() };
    var pagesArr = activeBook.pagesPreview || [{ page: 1, title: activeBook.title, content: activeBook.summary }];
    var curPageIdx = Math.min(pagesArr.length - 1, Math.max(0, bm.pageIdx || 0));
    var curPageObj = pagesArr[curPageIdx] || pagesArr[0];
    var pctRead = Math.min(100, Math.max(5, Math.round((bm.page / Math.max(1, activeBook.totalPages || 100)) * 100)));

    var filteredBooks = originalBooks.filter(function (b) {
      if (uiState.bookFilter === "all") return true;
      if (uiState.bookFilter === "bookmarked") return !!bookmarks[b.id];
      return b.category === uiState.bookFilter;
    });

    // Last bookmarked books banner ("أكمل القراءة من حيث توقفت")
    var bookmarkedList = originalBooks.filter(function (b) { return !!bookmarks[b.id]; });

    var filteredTools = CONSOLIDATED_TOOLS.filter(function (t) {
      var matchGroup = uiState.toolGroupFilter === "all" || t.group === uiState.toolGroupFilter;
      var q = uiState.instantQuery.trim().toLowerCase();
      var matchQ = !q || (t.title + " " + t.desc).toLowerCase().indexOf(q) !== -1;
      return matchGroup && matchQ;
    });

    var ans = uiState.instantAnswer || queryOfflineBrain("الاستدعاء النشط وقانون نيوتن ومهارات القراءة");

    sec.innerHTML =
      '<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 my-6 text-right" dir="rtl">' +
        '<div class="rounded-3xl bg-gradient-to-br from-slate-950 via-indigo-950/90 to-slate-900 border-2 border-sky-500/40 shadow-2xl overflow-hidden text-white">' +

          // Top Ergonomic Header + Instant Search / Offline Answer Bar
          '<div class="p-5 sm:p-6 bg-slate-950/80 border-b border-white/10 space-y-4">' +
            '<div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">' +
              '<div class="space-y-1">' +
                '<div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/20 border border-sky-400/40 text-sky-300 text-xs font-black">' +
                  '<span>✨</span><span>الإصدار 90 • تنظيم ذكي مريح + قاعدة Markdown خفية للعمل بلا إنترنت + كتب أصلية وGoogle Drive + مكتبة ثقافية وحفظ أين وصلت</span>' +
                '</div>' +
                '<h2 class="text-xl sm:text-2xl font-black text-white">مركز القيادة الموحّد والمكتبة الشاملة (التعليمية والثقافية وGoogle Drive)</h2>' +
                '<p class="text-xs sm:text-sm text-slate-300">كل ما ترفقه بصيغة Markdown يعمل بالخلفية لتغذية عقل الموقع بلا إنترنت، بينما تعرض قائمة المصادر الكتب بصيغتها الأصلية الصحيحة وكتب Google Drive والكتب الثقافية مع حفظ تلقائي لصفحة توقفك.</p>' +
              '</div>' +
              '<div class="flex flex-wrap items-center gap-2 shrink-0">' +
                '<span class="px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-black">🧠 القاعدة البرمجية الخفية: ' + brainPacks.length + ' حزم Markdown نشطة بلا إنترنت</span>' +
                '<span class="px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs font-black">📚 المصادر الأصلية والثقافية: ' + originalBooks.length + ' كتاب</span>' +
              '</div>' +
            '</div>' +

            // Unified Instant Search & Offline Brain Bar
            '<div class="p-3 rounded-2xl bg-slate-900/95 border border-sky-500/30 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">' +
              '<div class="flex-1 flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800">' +
                '<span class="text-sky-400 text-base">⚡</span>' +
                '<input id="eduCockpitInstantInput" type="text" value="' + esc(uiState.instantQuery) + '" placeholder="ابحث فوراً عن أي أداة بدون عناء، أو اكتب أي سؤال ليجيبك عقل الموقع الخفي (Markdown) بدون إنترنت..." class="w-full bg-transparent text-xs sm:text-sm font-bold text-white outline-none"/>' +
              '</div>' +
              '<div class="flex items-center gap-2">' +
                '<button type="button" id="eduCockpitAskOfflineBtn" class="px-4 py-2.5 rounded-xl bg-gradient-to-l from-emerald-500 to-teal-600 hover:opacity-95 text-slate-950 text-xs font-black shadow shrink-0">🧠 استخرج الإجابة فوراً بلا إنترنت</button>' +
                '<button type="button" id="eduCockpitOpenAllToolsBtn" class="px-3.5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow shrink-0">🧭 دليل الأدوات المدمج</button>' +
              '</div>' +
            '</div>' +

            // 4 Ergonomic Pillars Navigation
            '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 pt-1">' +
              '<button type="button" data-cockpit-pillar="books_drive" class="p-3 rounded-2xl text-right transition-all border flex items-center gap-3 ' +
                (uiState.activePillar === "books_drive" ? "bg-gradient-to-l from-sky-600 to-indigo-700 text-white border-sky-300 shadow-lg scale-[1.01]" : "bg-slate-900/80 text-slate-300 border-slate-800 hover:bg-slate-800") + '">' +
                '<span class="text-2xl">📖</span>' +
                '<div><div class="text-xs font-black">1. المصادر الأصلية وGoogle Drive والثقافة</div><div class="text-[10px] opacity-80">قراءة بالجودة الأصلية + حفظ «أين وصلت»</div></div>' +
              '</button>' +
              '<button type="button" data-cockpit-pillar="offline_brain" class="p-3 rounded-2xl text-right transition-all border flex items-center gap-3 ' +
                (uiState.activePillar === "offline_brain" ? "bg-gradient-to-l from-emerald-600 to-teal-700 text-white border-emerald-300 shadow-lg scale-[1.01]" : "bg-slate-900/80 text-slate-300 border-slate-800 hover:bg-slate-800") + '">' +
                '<span class="text-2xl">🧠</span>' +
                '<div><div class="text-xs font-black">2. القاعدة البرمجية الخفية (Markdown)</div><div class="text-[10px] opacity-80">تغذية الموقع والأهداف للعمل بدون إنترنت</div></div>' +
              '</button>' +
              '<button type="button" data-cockpit-pillar="tools_cockpit" class="p-3 rounded-2xl text-right transition-all border flex items-center gap-3 ' +
                (uiState.activePillar === "tools_cockpit" ? "bg-gradient-to-l from-amber-500 to-orange-600 text-slate-950 border-amber-300 shadow-lg scale-[1.01]" : "bg-slate-900/80 text-slate-300 border-slate-800 hover:bg-slate-800") + '">' +
                '<span class="text-2xl">⚡</span>' +
                '<div><div class="text-xs font-black">3. مصنع الأدوات المدمج والمنسّق</div><div class="text-[10px] opacity-80">وصول ذكي مريح بلا تشتيت أو إرهاق</div></div>' +
              '</button>' +
              '<button type="button" data-cockpit-pillar="uni_refs" class="p-3 rounded-2xl text-right transition-all border flex items-center gap-3 ' +
                (uiState.activePillar === "uni_refs" ? "bg-gradient-to-l from-purple-600 to-indigo-800 text-white border-purple-300 shadow-lg scale-[1.01]" : "bg-slate-900/80 text-slate-300 border-slate-800 hover:bg-slate-800") + '">' +
                '<span class="text-2xl">🎓</span>' +
                '<div><div class="text-xs font-black">4. بوابة الجامعة والـ CV والمراجع المعتمدة</div><div class="text-[10px] opacity-80">دمج كتب الدرايف والمصادر في توثيق APA</div></div>' +
              '</button>' +
            '</div>' +
          '</div>' +

          // Body of Active Pillar
          '<div class="p-5 sm:p-6">' +

            // =========================================================================
            // PILLAR 1: Original Sources, Google Drive Connector, Cultural Books & Auto-Bookmark
            // =========================================================================
            (uiState.activePillar === "books_drive" ? (
              '<div class="space-y-5">' +
                // Auto-Bookmark Resume Banner ("أكمل القراءة من حيث توقفت")
                '<div class="p-4 rounded-2xl bg-gradient-to-l from-amber-500/20 via-slate-900 to-slate-900 border border-amber-400/40 flex flex-col lg:flex-row lg:items-center justify-between gap-3">' +
                  '<div class="space-y-1">' +
                    '<div class="text-xs font-black text-amber-300 flex items-center gap-1.5"><span>📌</span><span>حفظ تلقائي لأين وصلت في قراءتك (Auto-Bookmark & Resume):</span></div>' +
                    '<div class="flex flex-wrap gap-2 pt-1">' +
                      bookmarkedList.map(function (b) {
                        var bmk = bookmarks[b.id];
                        var pct = Math.min(100, Math.max(5, Math.round((bmk.page / Math.max(1, b.totalPages || 100)) * 100)));
                        return '<button type="button" data-cockpit-pick-book="' + esc(b.id) + '" class="px-3 py-1.5 rounded-xl bg-slate-950/90 hover:bg-slate-900 border border-amber-400/40 text-xs font-bold flex items-center gap-2">' +
                          '<span class="text-amber-300 font-black">📖 ' + esc(b.title) + '</span>' +
                          '<span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black">صفحة ' + bmk.page + ' (' + pct + '%)</span>' +
                        '</button>';
                      }).join("") +
                    '</div>' +
                  '</div>' +
                  '<div class="text-[11px] text-slate-300 shrink-0">✅ قائمة المصادر هنا تعرض فقط الكتب بجودتها وصيغتها الأصلية (بدون ملفات الـ Markdown البرمجية)</div>' +
                '</div>' +

                // Category Filter + Google Drive Direct Adder
                '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5">' +
                  // Left 5 cols: Original Books List + Google Drive Importer
                  '<div class="lg:col-span-5 space-y-4">' +
                    '<div class="flex flex-wrap items-center gap-1.5">' +
                      '<button type="button" data-cockpit-bfilter="all" class="px-3 py-1.5 rounded-xl text-xs font-black ' + (uiState.bookFilter === "all" ? "bg-sky-500 text-slate-950" : "bg-slate-900 text-slate-300 border border-slate-800") + '">📚 كل الكتب الأصلية (' + originalBooks.length + ')</button>' +
                      '<button type="button" data-cockpit-bfilter="curriculum" class="px-3 py-1.5 rounded-xl text-xs font-black ' + (uiState.bookFilter === "curriculum" ? "bg-sky-500 text-slate-950" : "bg-slate-900 text-slate-300 border border-slate-800") + '">🇵🇸 الكتب التعليمية</button>' +
                      '<button type="button" data-cockpit-bfilter="cultural" class="px-3 py-1.5 rounded-xl text-xs font-black ' + (uiState.bookFilter === "cultural" ? "bg-sky-500 text-slate-950" : "bg-slate-900 text-slate-300 border border-slate-800") + '">🌍 الكتب الثقافية العامة</button>' +
                      '<button type="button" data-cockpit-bfilter="gdrive" class="px-3 py-1.5 rounded-xl text-xs font-black ' + (uiState.bookFilter === "gdrive" ? "bg-sky-500 text-slate-950" : "bg-slate-900 text-slate-300 border border-slate-800") + '">☁️ Google Drive</button>' +
                    '</div>' +

                    // Books list
                    '<div class="space-y-2.5 max-h-[360px] overflow-y-auto pr-1">' +
                      filteredBooks.map(function (b) {
                        var isAct = b.id === activeBook.id;
                        var bmk = bookmarks[b.id];
                        return '<div data-cockpit-pick-book="' + esc(b.id) + '" class="p-3.5 rounded-2xl border cursor-pointer transition-all ' +
                          (isAct ? "bg-sky-950/80 border-sky-400 shadow-lg" : "bg-slate-900/70 border-slate-800 hover:bg-slate-900") + '">' +
                          '<div class="flex items-start justify-between gap-2">' +
                            '<div class="text-xs sm:text-sm font-black text-white">' + esc(b.title) + '</div>' +
                            '<span class="px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-300 text-[10px] font-black shrink-0">' + esc(b.categoryLabel) + '</span>' +
                          '</div>' +
                          '<div class="text-[11px] text-slate-400 mt-1">' + esc(b.author) + ' • ' + esc(b.quality) + '</div>' +
                          '<div class="flex flex-wrap items-center justify-between gap-2 mt-2 pt-2 border-t border-white/10 text-[11px]">' +
                            '<span class="text-emerald-300 font-bold">📄 ' + (b.totalPages || 120) + ' صفحة أصلية</span>' +
                            (bmk
                              ? '<span class="px-2 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 font-black">📌 وصلت لصفحة ' + bmk.page + '</span>'
                              : '<span class="text-slate-400">لم تبدأ القراءة بعد</span>') +
                          '</div>' +
                        '</div>';
                      }).join("") +
                    '</div>' +

                    // Google Drive Direct Connector Box
                    '<div class="p-4 rounded-2xl bg-slate-900/90 border border-sky-500/30 space-y-2.5">' +
                      '<div class="text-xs font-black text-sky-300 flex items-center gap-1.5"><span>☁️</span><span>استدعاء كتاب من Google Drive ودمجه بالمصادر والمراجع:</span></div>' +
                      '<input id="eduDriveTitleInput" type="text" placeholder="اسم الكتاب (تعليمي أو ثقافي أو مرجع جامعي)..." class="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs font-bold text-white outline-none focus:border-sky-400"/>' +
                      '<div class="flex gap-2">' +
                        '<input id="eduDriveUrlInput" type="text" dir="ltr" placeholder="https://drive.google.com/file/d/... أو معرف الملف" class="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs font-mono text-sky-200 outline-none focus:border-sky-400"/>' +
                        '<select id="eduDriveCatSelect" class="px-2.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs font-bold text-white">' +
                          '<option value="gdrive">☁️ كتاب Google Drive</option>' +
                          '<option value="curriculum">🇵🇸 كتاب تعليمي منهجي</option>' +
                          '<option value="cultural">🌍 كتاب ثقافي عام</option>' +
                        '</select>' +
                      '</div>' +
                      '<button type="button" id="eduDriveAddBookBtn" class="w-full py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-black shadow">☁️ استدعاء الكتاب من Google Drive وإضافته لقائمة المصادر الأصلية</button>' +
                    '</div>' +
                  '</div>' +

                  // Right 7 cols: Crisp Original Reader & Auto-Bookmark Saver
                  '<div class="lg:col-span-7 p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-white/10 space-y-4 flex flex-col justify-between">' +
                    '<div class="space-y-3">' +
                      '<div class="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-white/10">' +
                        '<div>' +
                          '<div class="flex items-center gap-2">' +
                            '<span class="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black">' + esc(activeBook.formatBadge) + '</span>' +
                            '<span class="text-[11px] text-amber-300 font-black">📌 وصلت إلى صفحة ' + bm.page + ' من ' + activeBook.totalPages + ' (' + pctRead + '%)</span>' +
                          '</div>' +
                          '<h3 class="text-base sm:text-lg font-black text-white mt-1">' + esc(activeBook.title) + '</h3>' +
                          '<div class="text-xs text-slate-400">' + esc(activeBook.author) + '</div>' +
                        '</div>' +
                        '<div class="flex flex-wrap gap-1.5">' +
                          '<button type="button" id="eduCockpitTakeToToolsBtn" class="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow">⚡ خذ الصفحة للأدوات</button>' +
                          '<button type="button" id="eduCockpitCiteBookBtn" class="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black">🔬 أضف للمراجع (APA)</button>' +
                        '</div>' +
                      '</div>' +

                      // Crisp Original Page Paper View
                      '<div class="p-5 rounded-2xl bg-[#fcfaf2] text-slate-900 border-2 border-amber-900/20 shadow-inner space-y-3 min-h-[210px]">' +
                        '<div class="flex items-center justify-between text-xs font-black text-amber-900 border-b border-amber-900/15 pb-2">' +
                          '<span>📖 ' + esc(curPageObj.title) + '</span>' +
                          '<span class="px-2.5 py-0.5 rounded-lg bg-amber-900/10 text-amber-950">صفحة ' + bm.page + ' من ' + activeBook.totalPages + '</span>' +
                        '</div>' +
                        '<p class="text-xs sm:text-sm leading-8 whitespace-pre-line font-semibold text-slate-800">' + esc(curPageObj.content) + '</p>' +
                      '</div>' +

                      // Page Navigation + Bookmark Note ("يحفظ أين وصل")
                      '<div class="p-3.5 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-3">' +
                        '<div class="flex flex-wrap items-center justify-between gap-2">' +
                          '<div class="flex items-center gap-1.5">' +
                            '<button type="button" id="eduBmPrevPageBtn" class="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold">◀ الصفحة السابقة</button>' +
                            '<button type="button" id="eduBmNextPageBtn" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black">الصفحة التالية ▶</button>' +
                          '</div>' +
                          '<div class="flex items-center gap-1.5 text-xs">' +
                            '<span class="text-slate-300 font-bold">انتقل لصفحة:</span>' +
                            '<input id="eduBmPageNumInput" type="number" min="1" max="' + activeBook.totalPages + '" value="' + bm.page + '" class="w-16 px-2 py-1 rounded-lg bg-slate-900 border border-slate-700 text-center font-black text-amber-300"/>' +
                          '</div>' +
                        '</div>' +
                        '<div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">' +
                          '<input id="eduBmNoteInput" type="text" value="' + esc(bm.note || "") + '" placeholder="اكتب ملاحظة مرجعية حول ما قرأته في هذه الصفحة..." class="flex-1 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs font-bold text-white outline-none"/>' +
                          '<button type="button" id="eduBmSaveBtn" class="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow">📌 حفظ أين وصلت الآن</button>' +
                        '</div>' +
                      '</div>' +
                    '</div>' +
                  '</div>' +
                '</div>' +
              '</div>'
            ) : "") +

            // =========================================================================
            // PILLAR 2: Hidden Programmatic Markdown Brain (Offline Engine Feeder Only)
            // =========================================================================
            (uiState.activePillar === "offline_brain" ? (
              '<div class="space-y-5">' +
                '<div class="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 flex flex-col lg:flex-row lg:items-center justify-between gap-3">' +
                  '<div class="space-y-1">' +
                    '<div class="text-xs font-black text-emerald-300">🔒 عزل معماري ذكي: ملفات الـ Markdown مخصّصة لتغذية عقل الموقع والعمل بدون إنترنت فقط</div>' +
                    '<p class="text-xs text-slate-300">أي كتاب تعليمي أو أهداف تربوية أو معارف عامة ترفقها هنا بصيغة Markdown تُفهرس فوراً في القاعدة البرمجية الخفية لتعطيك إجابات فورية دقيقة بدون إنترنت، ولا تزدحم بها قائمة الكتب المعروضة للقراء.</p>' +
                  '</div>' +
                  '<span class="px-3 py-1.5 rounded-xl bg-emerald-500 text-slate-950 text-xs font-black shrink-0">⚡ سرعة الاسترجاع المحلي: ' + ans.latencyMs + ' ملي ثانية (بدون إنترنت)</span>' +
                '</div>' +

                '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5">' +
                  // Add Markdown Feeder Pack
                  '<div class="lg:col-span-5 p-4 rounded-2xl bg-slate-900/90 border border-white/10 space-y-3">' +
                    '<div class="text-xs font-black text-amber-300">➕ تغذية القاعدة البرمجية الخفية بملف أو محتوى Markdown جديد:</div>' +
                    '<input id="eduBrainTitleInp" type="text" placeholder="عنوان حزمة التغذية (مثال: أهداف الرياضيات / كتاب تاريخ عام)..." class="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs font-bold text-white"/>' +
                    '<div class="flex items-center justify-between gap-2">' +
                      '<select id="eduBrainCatSel" class="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs font-bold text-white">' +
                        '<option value="كتب ومعارف تعليمية">📘 كتب ومعارف تعليمية</option>' +
                        '<option value="أهداف تعليمية وتربوية">🎯 أهداف تعليمية وتربوية</option>' +
                        '<option value="معارف عامة وثقافية">🌍 معارف عامة وثقافية</option>' +
                      '</select>' +
                      '<label class="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black cursor-pointer shrink-0">📂 إرفاق ملف .md<input id="eduBrainFileInp" type="file" accept=".md,.markdown,.txt" class="hidden"/></label>' +
                    '</div>' +
                    '<textarea id="eduBrainMdInp" rows="5" placeholder="# عنوان الكتاب أو الأهداف\n## الفصل أو الهدف الأول\n- **القاعدة:** اكتب المحتوى هنا ليتم فهرسته للعمل بدون إنترنت..." class="w-full p-3 rounded-xl bg-slate-950 border border-slate-700 text-xs font-mono text-emerald-200"></textarea>' +
                    '<button type="button" id="eduBrainSaveBtn" class="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black shadow">🧠 تغذية وحفظ في القاعدة البرمجية الخفية (بدون إظهارها في قائمة القراءة)</button>' +
                  '</div>' +

                  // Offline Instant Answer & Active Brain Packs
                  '<div class="lg:col-span-7 space-y-4">' +
                    '<div class="p-4 rounded-2xl bg-slate-950 border border-emerald-500/40 space-y-2.5">' +
                      '<div class="flex items-center justify-between">' +
                        '<span class="text-xs font-black text-emerald-300">⚡ نتيجة محرك الإجابة الفورية بدون إنترنت (Offline Brain Response):</span>' +
                        '<span class="text-[11px] text-amber-300 font-mono">الزمن: ' + ans.latencyMs + ' ms • فُحصت ' + ans.totalPacksSearched + ' حزم برمجية</span>' +
                      '</div>' +
                      '<div class="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 whitespace-pre-line leading-relaxed max-h-[175px] overflow-y-auto">' +
                        esc(ans.synthesizedText) +
                      '</div>' +
                    '</div>' +

                    '<div class="space-y-2">' +
                      '<div class="text-xs font-black text-slate-300">🗄️ الحزم البرمجية الخفية المغذية للموقع حالياً (' + brainPacks.length + ' حزم):</div>' +
                      '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">' +
                        brainPacks.map(function (p) {
                          return '<div class="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between gap-2">' +
                            '<div>' +
                              '<div class="flex items-center justify-between gap-1">' +
                                '<span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black">' + esc(p.category) + '</span>' +
                                '<span class="text-[10px] text-slate-400">🔒 مخفي عن القراء</span>' +
                              '</div>' +
                              '<div class="text-xs font-black text-white mt-1">' + esc(p.title) + '</div>' +
                            '</div>' +
                            '<div class="text-[10px] text-slate-400">حجم الفهرس: ' + Math.max(1, Math.round((p.markdown || "").length / 100)) / 10 + ' KB • يعمل بلا إنترنت ✓</div>' +
                          '</div>';
                        }).join("") +
                      '</div>' +
                    '</div>' +
                  '</div>' +
                '</div>' +
              '</div>'
            ) : "") +

            // =========================================================================
            // PILLAR 3: Consolidated Ergonomic Tools Matrix (Zero Clutter)
            // =========================================================================
            (uiState.activePillar === "tools_cockpit" ? (
              '<div class="space-y-4">' +
                '<div class="flex flex-wrap items-center justify-between gap-2">' +
                  '<div class="text-xs font-black text-amber-300">🧭 اختر فئة الأداة للوصول الفوري في شاشة واحدة دون تمرير طويل:</div>' +
                  '<div class="flex flex-wrap gap-1.5">' +
                    '<button type="button" data-cockpit-tgroup="all" class="px-3 py-1.5 rounded-xl text-xs font-black ' + (uiState.toolGroupFilter === "all" ? "bg-amber-400 text-slate-950" : "bg-slate-900 text-slate-300 border border-slate-800") + '">الكل (' + CONSOLIDATED_TOOLS.length + ')</button>' +
                    '<button type="button" data-cockpit-tgroup="read" class="px-3 py-1.5 rounded-xl text-xs font-black ' + (uiState.toolGroupFilter === "read" ? "bg-amber-400 text-slate-950" : "bg-slate-900 text-slate-300 border border-slate-800") + '">📖 القراءة والمصادر والبودكاست</button>' +
                    '<button type="button" data-cockpit-tgroup="study" class="px-3 py-1.5 rounded-xl text-xs font-black ' + (uiState.toolGroupFilter === "study" ? "bg-amber-400 text-slate-950" : "bg-slate-900 text-slate-300 border border-slate-800") + '">📓 كورنيل والخرائط والحقيبة 5×1</button>' +
                    '<button type="button" data-cockpit-tgroup="stem" class="px-3 py-1.5 rounded-xl text-xs font-black ' + (uiState.toolGroupFilter === "stem" ? "bg-amber-400 text-slate-950" : "bg-slate-900 text-slate-300 border border-slate-800") + '">🧪 مختبر المعادلات وبومودورو</button>' +
                    '<button type="button" data-cockpit-tgroup="teach" class="px-3 py-1.5 rounded-xl text-xs font-black ' + (uiState.toolGroupFilter === "teach" ? "bg-amber-400 text-slate-950" : "bg-slate-900 text-slate-300 border border-slate-800") + '">👨‍🏫 تحضير المعلم وأوراق العمل</button>' +
                    '<button type="button" data-cockpit-tgroup="uni" class="px-3 py-1.5 rounded-xl text-xs font-black ' + (uiState.toolGroupFilter === "uni" ? "bg-amber-400 text-slate-950" : "bg-slate-900 text-slate-300 border border-slate-800") + '">🎓 الجامعة والـ CV والأبحاث</button>' +
                  '</div>' +
                '</div>' +

                '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">' +
                  filteredTools.map(function (t) {
                    return '<button type="button" data-cockpit-launch="' + esc(t.id) + '" class="p-4 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-amber-400/50 text-right transition-all flex items-start gap-3 group">' +
                      '<span class="w-11 h-11 rounded-2xl bg-slate-950 border border-white/10 flex items-center justify-center text-2xl shrink-0 group-hover:scale-105 transition">' + t.ico + '</span>' +
                      '<div>' +
                        '<div class="text-xs sm:text-sm font-black text-white group-hover:text-amber-300">' + esc(t.title) + '</div>' +
                        '<p class="text-[11px] text-slate-400 mt-1 leading-relaxed">' + esc(t.desc) + '</p>' +
                      '</div>' +
                    '</button>';
                  }).join("") +
                '</div>' +
              '</div>'
            ) : "") +

            // =========================================================================
            // PILLAR 4: University, CV & Integrated APA References from Drive & Original Books
            // =========================================================================
            (uiState.activePillar === "uni_refs" ? (
              '<div class="space-y-4">' +
                '<div class="p-4 rounded-2xl bg-indigo-950/60 border border-indigo-500/40 flex flex-wrap items-center justify-between gap-3">' +
                  '<div>' +
                    '<div class="text-xs font-black text-indigo-300">🎓 تكامل المصادر الأصلية وكتب Google Drive مع المراجع الأكاديمية والسيرة الذاتية</div>' +
                    '<p class="text-xs text-slate-300 mt-0.5">جميع الكتب الأصلية وكتب Google Drive المضافة في قائمة المصادر جاهزة للاستشهاد المرجعي القياسي (APA 7th) في أبحاثك ومشاريع التخرج.</p>' +
                  '</div>' +
                  '<div class="flex gap-2">' +
                    '<button type="button" data-cockpit-launch="cvBuilderStudio" class="px-3.5 py-2 rounded-xl bg-amber-400 text-slate-950 text-xs font-black shadow">📄 منشئ CV (عربي/EN)</button>' +
                    '<button type="button" data-cockpit-launch="uniResearchCareerStudio" class="px-3.5 py-2 rounded-xl bg-indigo-600 text-white text-xs font-black shadow">🔬 استوديو الأبحاث والمقابلات</button>' +
                  '</div>' +
                '</div>' +

                '<div class="grid grid-cols-1 md:grid-cols-2 gap-3">' +
                  originalBooks.map(function (b) {
                    var apa = b.author + " (" + (b.year || "2025") + "). " + b.title + ". المسترد من Google Drive / قائمة المصادر الأصلية.";
                    return '<div class="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">' +
                      '<div class="flex items-center justify-between">' +
                        '<span class="text-xs font-black text-white">📘 ' + esc(b.title) + '</span>' +
                        '<span class="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px] font-black">APA 7th جاهز</span>' +
                      '</div>' +
                      '<div class="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-300 font-semibold">' + esc(apa) + '</div>' +
                    '</div>';
                  }).join("") +
                '</div>' +
              '</div>'
            ) : "") +

          '</div>' +
        '</div>' +
      '</div>';

    bindCockpitEvents(sec, activeBook, pagesArr);
  }

  function bindCockpitEvents(sec, activeBook, pagesArr) {
    // Pillars
    Array.prototype.forEach.call(sec.querySelectorAll("[data-cockpit-pillar]"), function (btn) {
      btn.addEventListener("click", function () {
        uiState.activePillar = btn.getAttribute("data-cockpit-pillar") || "books_drive";
        renderCockpit();
      });
    });

    // Instant Search & Offline Brain Input
    var instInp = document.getElementById("eduCockpitInstantInput");
    if (instInp) {
      instInp.addEventListener("input", function () {
        uiState.instantQuery = instInp.value;
      });
      instInp.addEventListener("keydown", function (ev) {
        if (ev.key === "Enter") {
          uiState.instantAnswer = queryOfflineBrain(uiState.instantQuery);
          uiState.activePillar = "offline_brain";
          renderCockpit();
        }
      });
    }

    var askBtn = document.getElementById("eduCockpitAskOfflineBtn");
    if (askBtn) {
      askBtn.addEventListener("click", function () {
        var q = instInp ? instInp.value.trim() : uiState.instantQuery;
        if (!q) q = "اشرح القواعد والأهداف التعليمية الأساسية ومهارات القراءة";
        uiState.instantQuery = q;
        uiState.instantAnswer = queryOfflineBrain(q);
        uiState.activePillar = "offline_brain";
        renderCockpit();
        toast("🧠 تمت الإجابة فوراً من القاعدة البرمجية الخفية للـ Markdown بدون إنترنت ✓", "success");
      });
    }

    var allToolsBtn = document.getElementById("eduCockpitOpenAllToolsBtn");
    if (allToolsBtn) {
      allToolsBtn.addEventListener("click", function () {
        uiState.activePillar = "tools_cockpit";
        renderCockpit();
      });
    }

    // Book Filters & Picking
    Array.prototype.forEach.call(sec.querySelectorAll("[data-cockpit-bfilter]"), function (btn) {
      btn.addEventListener("click", function () {
        uiState.bookFilter = btn.getAttribute("data-cockpit-bfilter") || "all";
        renderCockpit();
      });
    });

    Array.prototype.forEach.call(sec.querySelectorAll("[data-cockpit-pick-book]"), function (el) {
      el.addEventListener("click", function () {
        uiState.activeBookId = el.getAttribute("data-cockpit-pick-book");
        renderCockpit();
      });
    });

    // Google Drive Direct Book Adder
    var addDriveBtn = document.getElementById("eduDriveAddBookBtn");
    if (addDriveBtn) {
      addDriveBtn.addEventListener("click", function () {
        var tEl = document.getElementById("eduDriveTitleInput");
        var uEl = document.getElementById("eduDriveUrlInput");
        var cEl = document.getElementById("eduDriveCatSelect");
        var title = tEl && tEl.value.trim() ? tEl.value.trim() : "كتاب مستدعى من Google Drive";
        var url = uEl && uEl.value.trim() ? uEl.value.trim() : "https://drive.google.com/file/d/1DriveBookSampleId/view";
        var cat = cEl ? cEl.value : "gdrive";
        var fid = extractDriveId(url);
        var newId = "orig-drv-" + Date.now().toString(36);
        var newBook = {
          id: newId,
          title: title,
          author: "Google Drive • مصدر أصلي معتمد",
          category: cat,
          categoryLabel: cat === "cultural" ? "🌍 كتاب ثقافي عام (Google Drive)" : (cat === "curriculum" ? "🇵🇸 كتاب منهجي أصلي (Drive)" : "☁️ كتاب Google Drive أصلي"),
          formatBadge: "معاينة أصلية من Google Drive (" + fid.slice(0, 10) + ")",
          totalPages: 160,
          driveFileId: fid,
          driveUrl: url,
          year: "2025",
          quality: "نسخة أصلية مستدعاة من Google Drive",
          summary: "كتاب أصلي مستدعى من Google Drive ومرتبط مباشرة بقائمة المصادر والمراجع وأدوات المنصة.",
          pagesPreview: [
            { page: 1, title: "الفصل الأول — " + title, content: "تم استدعاء هذا الكتاب مباشرة من Google Drive (المعرّف: " + fid + ") بصيغته الأصلية الصحيحة وسهلة القراءة.\nيمكنك القراءة وتصفح الصفحات وحفظ مكان توقفك وأخذ المقتطفات مباشرة إلى دفترك أو أبحاثك." },
            { page: 15, title: "الفصل الثاني — المفاهيم الأساسية والمراجع في " + title, content: "تُحفظ هذه الصفحة ضمن قائمة المصادر الأصلية المعتمدة، ويمكنك توثيقها بنظام APA أو إرسالها لأي أداة تعليمية بضغطة واحدة." }
          ]
        };
        originalBooks.unshift(newBook);
        uiState.activeBookId = newId;
        bookmarks[newId] = { page: 1, pageIdx: 0, note: "تم الاستدعاء من Google Drive", updatedAt: Date.now() };
        saveOriginalBooks();
        saveBookmarks();
        renderCockpit();
        toast("☁️ تم استدعاء «" + title + "» من Google Drive ودمجه في قائمة المصادر الأصلية والمراجع ✓", "success");
      });
    }

    // Auto-Bookmark Controls ("يحفظ أين وصل")
    var prevPg = document.getElementById("eduBmPrevPageBtn");
    var nextPg = document.getElementById("eduBmNextPageBtn");
    var pgInp = document.getElementById("eduBmPageNumInput");
    var noteInp = document.getElementById("eduBmNoteInput");
    var saveBmBtn = document.getElementById("eduBmSaveBtn");

    function updateCurrentBookmark(newPage, newPageIdx) {
      var curBm = bookmarks[activeBook.id] || { page: 1, pageIdx: 0, note: "" };
      var pNum = Math.min(activeBook.totalPages || 200, Math.max(1, newPage));
      bookmarks[activeBook.id] = {
        page: pNum,
        pageIdx: typeof newPageIdx === "number" ? newPageIdx : curBm.pageIdx,
        note: noteInp ? noteInp.value : curBm.note,
        updatedAt: Date.now()
      };
      saveBookmarks();
      renderCockpit();
    }

    if (prevPg) {
      prevPg.addEventListener("click", function () {
        var curBm = bookmarks[activeBook.id] || { page: 1, pageIdx: 0 };
        var nextIdx = Math.max(0, (curBm.pageIdx || 0) - 1);
        var targetPage = pagesArr[nextIdx] ? pagesArr[nextIdx].page : Math.max(1, curBm.page - 1);
        updateCurrentBookmark(targetPage, nextIdx);
      });
    }
    if (nextPg) {
      nextPg.addEventListener("click", function () {
        var curBm = bookmarks[activeBook.id] || { page: 1, pageIdx: 0 };
        var nextIdx = Math.min(pagesArr.length - 1, (curBm.pageIdx || 0) + 1);
        var targetPage = pagesArr[nextIdx] ? pagesArr[nextIdx].page : Math.min(activeBook.totalPages, curBm.page + 1);
        updateCurrentBookmark(targetPage, nextIdx);
        toast("📌 تم الانتقال وحفظ مكان وصولك تلقائياً (صفحة " + targetPage + ") ✓", "info");
      });
    }
    if (saveBmBtn) {
      saveBmBtn.addEventListener("click", function () {
        var pVal = pgInp ? parseInt(pgInp.value, 10) || 1 : 1;
        var curBm = bookmarks[activeBook.id] || { page: 1, pageIdx: 0 };
        updateCurrentBookmark(pVal, curBm.pageIdx || 0);
        toast("📌 تم حفظ موضع قراءتك في «" + activeBook.title + "» (صفحة " + pVal + ") وملاحظتك المرجعية ✓", "success");
      });
    }

    var takeBtn = document.getElementById("eduCockpitTakeToToolsBtn");
    if (takeBtn) {
      takeBtn.addEventListener("click", function () {
        if (window.EduSmartNotes && window.EduSmartNotes.open) {
          window.EduSmartNotes.open("cornell");
          toast("⚡ تم إرسال الصفحة الحالية من الكتاب الأصلي إلى دفتر كورنيل الذكي ✓", "success");
        }
      });
    }

    var citeBtn = document.getElementById("eduCockpitCiteBookBtn");
    if (citeBtn) {
      citeBtn.addEventListener("click", function () {
        uiState.activePillar = "uni_refs";
        renderCockpit();
        toast("🔬 تم إدراج الكتاب ضمن قائمة المراجع الأكاديمية (APA 7th) ✓", "success");
      });
    }

    // Hidden Brain Feeder Controls
    var brainFileInp = document.getElementById("eduBrainFileInp");
    if (brainFileInp) {
      brainFileInp.addEventListener("change", function (ev) {
        var f = ev.target.files && ev.target.files[0];
        if (!f) return;
        var r = new FileReader();
        r.onload = function () {
          var tInp = document.getElementById("eduBrainTitleInp");
          var mInp = document.getElementById("eduBrainMdInp");
          if (tInp && !tInp.value) tInp.value = f.name.replace(/\.[^.]+$/, "");
          if (mInp) mInp.value = String(r.result || "");
          toast("📥 تم قراءة ملف الـ Markdown — اضغط «تغذية وحفظ في القاعدة البرمجية الخفية»", "info");
        };
        r.readAsText(f, "utf-8");
      });
    }

    var brainSaveBtn = document.getElementById("eduBrainSaveBtn");
    if (brainSaveBtn) {
      brainSaveBtn.addEventListener("click", function () {
        var tInp = document.getElementById("eduBrainTitleInp");
        var cSel = document.getElementById("eduBrainCatSel");
        var mInp = document.getElementById("eduBrainMdInp");
        var title = (tInp && tInp.value.trim()) || "حزمة تغذية برمجية Markdown جديدة";
        var cat = (cSel && cSel.value) || "كتب ومعارف تعليمية";
        var md = (mInp && mInp.value.trim()) || ("# " + title + "\n## قواعد وأهداف أساسية\n- تغذية برمجية خفية للعمل بدون إنترنت.");
        var newPack = {
          id: "brain-custom-" + Date.now().toString(36),
          title: title,
          category: cat,
          isHiddenBrainOnly: true,
          markdown: md
        };
        brainPacks.unshift(newPack);
        saveBrainPacks();
        uiState.instantAnswer = queryOfflineBrain(title);
        renderCockpit();
        toast("🧠 تم تغذية القاعدة البرمجية الخفية بـ «" + title + "» للعمل بدون إنترنت (دون إظهارها في قائمة القراءة العامة) ✓", "success");
      });
    }

    // Consolidated Tools Matrix
    Array.prototype.forEach.call(sec.querySelectorAll("[data-cockpit-tgroup]"), function (btn) {
      btn.addEventListener("click", function () {
        uiState.toolGroupFilter = btn.getAttribute("data-cockpit-tgroup") || "all";
        renderCockpit();
      });
    });

    Array.prototype.forEach.call(sec.querySelectorAll("[data-cockpit-launch]"), function (btn) {
      btn.addEventListener("click", function () {
        var targetId = btn.getAttribute("data-cockpit-launch");
        if (window.EduLauncher && typeof window.EduLauncher.jump === "function") {
          window.EduLauncher.jump(targetId, true);
        } else {
          var targetEl = document.getElementById(targetId);
          if (targetEl) targetEl.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      });
    });
  }

  function mountCockpit() {
    loadAllData();
    if (!document.getElementById("smartUnifiedCockpit")) {
      var sec = document.createElement("section");
      sec.id = "smartUnifiedCockpit";
      var anchor = document.getElementById("smartHubSection") ||
                   document.getElementById("stemLabPlannerStudio") ||
                   document.getElementById("smartNotesFlashStudio") ||
                   document.getElementById("bookReaderStudio");
      if (anchor && anchor.parentNode) {
        anchor.parentNode.insertBefore(sec, anchor);
      } else {
        var main = document.querySelector("main") || document.body;
        main.insertBefore(sec, main.firstChild);
      }
    }
    renderCockpit();
  }

  window.EduOfflineBrain = {
    answerOffline: queryOfflineBrain,
    addHiddenMarkdownPack: function (title, category, mdText) {
      var pack = {
        id: "brain-" + Date.now().toString(36),
        title: title || "حزمة تغذية Markdown",
        category: category || "كتب ومعارف تعليمية",
        isHiddenBrainOnly: true,
        markdown: mdText || ""
      };
      brainPacks.unshift(pack);
      saveBrainPacks();
      renderCockpit();
      return pack;
    },
    getBrainPacks: function () { return brainPacks.slice(); }
  };

  window.EduDriveCulturalHub = {
    open: function (pillar) {
      if (pillar) uiState.activePillar = pillar;
      mountCockpit();
      if (window.EduMasterHierarchy && window.EduMasterHierarchy.navigateToTarget) {
        window.EduMasterHierarchy.navigateToTarget("smartUnifiedCockpit");
      } else {
        var el = document.getElementById("smartUnifiedCockpit");
        if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    },
    getOriginalBooks: function () { return originalBooks.slice(); },
    getBookmarks: function () { return bookmarks; }
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mountCockpit);
  } else {
    mountCockpit();
  }
})();

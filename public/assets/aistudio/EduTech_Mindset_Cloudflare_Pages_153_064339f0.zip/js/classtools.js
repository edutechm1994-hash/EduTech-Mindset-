/*
 * حقيبة إدارة الصف الذكية والجدول المدرسي الأسبوعي — EduTech Mindset (الإصدار 45)
 * تضم 4 أدوات صفية يومية تعمل بالكامل حتى بلا إنترنت:
 * 1) 🎲 القرعة العشوائية العادلة لأسماء الطلاب (بدون تكرار حتى يشارك الجميع)
 * 2) 👥 مقسّم المجموعات التعاونية الذكي (توزيع الصف إلى مجموعات متوازنة مع تسمية المجموعات وطباعتها)
 * 3) ⏱ مؤقت الأنشطة الصفية وجرس الحصة (عدّاد تنازلي بصري وصوتي للعمل الجماعي)
 * 4) 📅 باني الجدول المدرسي الأسبوعي (الأحد - الخميس • 7 حصص) مع الحفظ التلقائي والطباعة كملف PDF
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var DAYS = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس"];
  var PERIODS = ["الحصة 1", "الحصة 2", "الحصة 3", "الحصة 4", "الحصة 5", "الحصة 6", "الحصة 7"];
  var GROUP_NAMES = ["مجموعة الخوارزمي", "مجموعة ابن الهيثم", "مجموعة الرازي", "مجموعة ابن سينا", "مجموعة البيروني", "مجموعة جابر بن حيان", "مجموعة الإدريسي", "مجموعة الكندي"];
  var COOP_ROLES = ["👑 القائد المنسق", "✍️ الكاتب الموثق", "🎤 المتحدث الرسمي", "⏱ ضابط الوقت والمواد", "🔍 الباحث المدقق", "🤝 المشجع والمساند"];

  function loadPoints() {
    try { return JSON.parse(localStorage.getItem("edu_class_points_v55") || "{}"); } catch (x) { return {}; }
  }
  function savePoints(pts) {
    try { localStorage.setItem("edu_class_points_v55", JSON.stringify(pts || {})); } catch (x) {}
  }

  var st = {
    tab: "picker", // picker | groups | stars | timer | schedule
    rosterRaw: localStorage.getItem("edu_class_roster") || "أحمد محمد\nسارة خالد\nيوسف محمود\nمريم عبد الله\nعمر نبيل\nليان سامي\nحمزة طارق\nنور الهدى",
    pickedHistory: [],
    currentWinner: "",
    groupCount: 3,
    groups: [],
    points: loadPoints(),
    timerSecs: 300,
    timerLeft: 300,
    timerRunning: false,
    timerIv: null,
    schedule: loadSchedule()
  };

  function loadSchedule() {
    try {
      var d = JSON.parse(localStorage.getItem("edu_weekly_schedule_v1") || "null");
      if (d && typeof d === "object") return d;
    } catch (x) {}
    return {};
  }

  function saveSchedule() {
    try { localStorage.setItem("edu_weekly_schedule_v1", JSON.stringify(st.schedule)); } catch (x) {}
  }

  function saveRoster(raw) {
    st.rosterRaw = raw;
    try { localStorage.setItem("edu_class_roster", raw); } catch (x) {}
  }

  function getRosterList() {
    return String(st.rosterRaw || "").split("\n").map(function (s) { return s.trim(); }).filter(Boolean);
  }

  function beep(freq, dur) {
    try {
      var Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      var ctx = new Ctx(), osc = ctx.createOscillator(), g = ctx.createGain();
      osc.type = "triangle"; osc.frequency.value = freq || 680;
      g.gain.setValueAtTime(0.15, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + (dur || 0.22));
      osc.connect(g); g.connect(ctx.destination);
      osc.start(); osc.stop(ctx.currentTime + (dur || 0.22));
    } catch (x) {}
  }

  function shuf(a) {
    a = a.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1)), t = a[i];
      a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  function paint() {
    var box = $("ctoolsBody"); if (!box) return;
    var tabs = [
      ["picker", "🎲 القرعة العشوائية"],
      ["groups", "👥 المجموعات وأدوار التعاون"],
      ["stars", "🏆 لوحة نجوم الصف والسلوك"],
      ["timer", "⏱ مؤقت الأنشطة"],
      ["schedule", "📅 الجدول الأسبوعي"]
    ];
    var nav = '<div class="flex flex-wrap gap-2 mb-4 border-b border-slate-200 dark:border-slate-700 pb-3">' +
      tabs.map(function (t) {
        var on = st.tab === t[0];
        return '<button type="button" data-cttab="' + t[0] + '" class="px-4 py-2 rounded-xl text-xs font-extrabold transition-all ' + (on ? "bg-emerald-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">' + t[1] + '</button>';
      }).join("") + '</div>';

    var body = "";
    if (st.tab === "picker") {
      var all = getRosterList();
      var remaining = all.filter(function (n) { return st.pickedHistory.indexOf(n) === -1; });
      body = '<div class="grid grid-cols-1 lg:grid-cols-12 gap-4">' +
        '<div class="lg:col-span-5 space-y-2">' +
        '<label class="block text-xs font-bold">قائمة أسماء طلاب الصف (كل اسم في سطر — تُحفظ تلقائياً)</label>' +
        '<textarea id="ctRosterInp" rows="8" class="' + cls + '">' + e(st.rosterRaw) + '</textarea>' +
        '<div class="text-[11px] text-slate-500">إجمالي الطلاب: <b>' + all.length + '</b> • المتبقي دون اختيار: <b>' + remaining.length + '</b></div></div>' +
        '<div class="lg:col-span-7 rounded-3xl border-2 border-emerald-500/30 bg-gradient-to-br from-slate-900 to-slate-800 text-white p-6 flex flex-col items-center justify-center text-center space-y-4">' +
        '<div class="text-xs font-extrabold text-amber-300">🎯 الطالب المختار للمشاركة:</div>' +
        '<div id="ctWinnerBox" class="text-3xl sm:text-4xl font-black text-emerald-400 min-h-[54px] flex items-center justify-center">' + (st.currentWinner ? "🌟 " + e(st.currentWinner) + " 🌟" : "اضغط «اختر طالباً بالقرعة»") + '</div>' +
        '<div class="flex flex-wrap gap-2 justify-center">' +
        '<button type="button" id="ctPickBtn" class="px-6 py-3 rounded-2xl bg-gradient-to-l from-emerald-500 to-teal-500 text-white text-sm font-black shadow-lg">🎲 اختر طالباً بالقرعة (بدون تكرار)</button>' +
        '<button type="button" id="ctResetPick" class="px-4 py-3 rounded-2xl bg-white/10 text-white text-xs font-bold">↺ تصفير القرعة (' + st.pickedHistory.length + ' شاركوا)</button></div>' +
        (st.pickedHistory.length ? '<div class="text-[11px] text-slate-300 max-w-md">من شاركوا حتى الآن: ' + st.pickedHistory.map(e).join(" ، ") + '</div>' : '') +
        '</div></div>';
    } else if (st.tab === "groups") {
      body = '<div class="space-y-4">' +
        '<div class="flex flex-wrap items-center gap-3 p-3 rounded-2xl bg-slate-100 dark:bg-slate-800">' +
        '<label class="text-xs font-extrabold">عدد المجموعات المطلوبة:</label>' +
        '<select id="ctGrpCount" class="' + cls + ' !w-28">' + [2, 3, 4, 5, 6, 7, 8].map(function (n) { return '<option value="' + n + '"' + (st.groupCount === n ? " selected" : "") + '>' + n + ' مجموعات</option>'; }).join("") + '</select>' +
        '<button type="button" id="ctMakeGroups" class="px-5 py-2 rounded-xl bg-emerald-600 text-white text-xs font-black">👥 وزّع الطلاب عشوائياً وبالتساوي</button>' +
        (st.groups.length ? '<button type="button" id="ctPrintGroups" class="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold">🖨 طباعة المجموعات</button>' : '') +
        '</div>' +
        (st.groups.length ? '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">' +
          st.groups.map(function (g, i) {
            return '<div class="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">' +
              '<div class="text-xs font-black text-emerald-600 dark:text-emerald-400 mb-2">🛡️ ' + e(GROUP_NAMES[i] || ("المجموعة " + (i + 1))) + ' (' + g.length + ' طلاب)</div>' +
              '<ol class="text-xs space-y-1.5 list-decimal list-inside font-bold">' + g.map(function (nm, ri) {
                return '<li class="flex items-center justify-between gap-1 border-b border-slate-100 dark:border-slate-700/60 pb-1"><span>' + e(nm) + '</span><span class="px-2 py-0.5 rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 text-[10px]">' + e(COOP_ROLES[ri % COOP_ROLES.length]) + '</span></li>';
              }).join("") + '</ol></div>';
          }).join("") + '</div>' : '<p class="text-xs text-slate-500 text-center py-6">اضغط «وزّع الطلاب عشوائياً وبالتساوي» لتقسيم قائمة طلابك الحالية إلى مجموعات عمل تعاوني.</p>') +
        '</div>';
    } else if (st.tab === "stars") {
      var roster = getRosterList();
      var sortedRoster = roster.slice().sort(function (a, b) { return (st.points[b] || 0) - (st.points[a] || 0); });
      body = '<div class="space-y-4">' +
        '<div class="flex flex-wrap items-center justify-between gap-2 p-3 rounded-2xl bg-amber-50/70 dark:bg-slate-800/80 border border-amber-200 dark:border-slate-700">' +
        '<div class="text-xs font-black text-amber-800 dark:text-amber-300">🏆 لوحة تعزيز السلوك الإيجابي ونجوم الصف (تُحفظ النقاط تلقائياً)</div>' +
        '<div class="flex flex-wrap gap-1.5">' +
        '<button type="button" id="ctStarsCerts" class="px-3.5 py-1.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-black shadow-sm">🏅 إصدار شهادات تقدير لأوائل النجوم</button>' +
        '<button type="button" id="ctStarsPrint" class="px-3.5 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-black">🖨 طباعة لوحة الشرف PDF</button>' +
        '<button type="button" id="ctStarsReset" class="px-3 py-1.5 rounded-xl bg-rose-500/15 text-rose-600 text-xs font-bold">تصفير النقاط</button>' +
        '</div></div>' +
        '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">' +
        sortedRoster.map(function (nm, idx) {
          var pts = st.points[nm] || 0;
          var medal = idx === 0 && pts > 0 ? "🥇 " : idx === 1 && pts > 0 ? "🥈 " : idx === 2 && pts > 0 ? "🥉 " : "👤 ";
          return '<div class="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex items-center justify-between gap-2">' +
            '<div class="min-w-0"><div class="text-xs font-black truncate">' + medal + e(nm) + '</div>' +
            '<div class="text-[11px] font-extrabold text-amber-600 dark:text-amber-400">⭐ ' + pts + ' نقطة</div></div>' +
            '<div class="flex gap-1 shrink-0">' +
            '<button type="button" data-stnm="' + e(nm) + '" data-stadd="1" class="px-2.5 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-black" title="مشاركة ممتازة (+1)">+1 🌟</button>' +
            '<button type="button" data-stnm="' + e(nm) + '" data-stadd="2" class="px-2.5 py-1.5 rounded-xl bg-sky-600 text-white text-xs font-black" title="تعاون وإبداع (+2)">+2 🤝</button>' +
            '<button type="button" data-stnm="' + e(nm) + '" data-stadd="-1" class="px-2 py-1.5 rounded-xl bg-rose-500/15 text-rose-600 text-xs font-bold" title="خصم تنبيه (-1)">-1</button>' +
            '</div></div>';
        }).join("") + '</div></div>';
    } else if (st.tab === "timer") {
      var mm = Math.floor(st.timerLeft / 60), ss = st.timerLeft % 60;
      var disp = (mm < 10 ? "0" : "") + mm + ":" + (ss < 10 ? "0" : "") + ss;
      body = '<div class="max-w-xl mx-auto rounded-3xl border-2 border-amber-500/40 bg-slate-900 text-white p-6 text-center space-y-4">' +
        '<div class="flex flex-wrap justify-center gap-2">' +
        [[60, "دقيقة"], [180, "3 دقائق"], [300, "5 دقائق"], [600, "10 دقائق"], [900, "15 دقيقة"]].map(function (p) {
          return '<button type="button" data-tmset="' + p[0] + '" class="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold">' + p[1] + '</button>';
        }).join("") + '</div>' +
        '<div id="ctTimerDisp" class="text-6xl sm:text-7xl font-black font-mono tracking-wider text-amber-400 py-2">' + disp + '</div>' +
        '<div class="flex justify-center gap-3">' +
        '<button type="button" id="ctTimerToggle" class="px-6 py-3 rounded-2xl ' + (st.timerRunning ? "bg-amber-600" : "bg-emerald-600") + ' text-white text-sm font-black">' + (st.timerRunning ? "⏸ إيقاف مؤقت" : "▶ ابدأ العد التنازلي") + '</button>' +
        '<button type="button" id="ctTimerReset" class="px-5 py-3 rounded-2xl bg-slate-700 text-white text-sm font-bold">↺ إعادة ضبط</button>' +
        '</div></div>';
    } else if (st.tab === "schedule") {
      body = '<div class="space-y-3">' +
        '<div class="flex flex-wrap items-center justify-between gap-2">' +
        '<span class="text-xs font-extrabold text-slate-600 dark:text-slate-300">اكتب المادة والصف في كل حصة (يُحفظ الجدول تلقائياً على جهازك)</span>' +
        '<div class="flex gap-2"><button type="button" id="ctPrintSched" class="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-black">🖨 طباعة الجدول الأسبوعي PDF</button>' +
        '<button type="button" id="ctClearSched" class="px-3 py-2 rounded-xl bg-rose-500/15 text-rose-600 text-xs font-bold">تفريغ</button></div></div>' +
        '<div class="overflow-x-auto"><table class="w-full text-xs border-collapse bg-white dark:bg-slate-800">' +
        '<thead><tr class="bg-slate-200 dark:bg-slate-700"><th class="p-2 border font-black">اليوم / الحصة</th>' +
        PERIODS.map(function (p) { return '<th class="p-2 border font-black text-center">' + p + '</th>'; }).join("") + '</tr></thead><tbody>' +
        DAYS.map(function (day, di) {
          return '<tr><td class="p-2 border font-black bg-slate-100 dark:bg-slate-700/60 whitespace-nowrap">' + day + '</td>' +
            PERIODS.map(function (_, pi) {
              var k = di + "_" + pi, val = st.schedule[k] || "";
              return '<td class="p-1 border"><input data-sckey="' + k + '" value="' + e(val) + '" placeholder="—" class="w-full min-w-[85px] text-center text-[11px] font-bold bg-transparent outline-none py-1"></td>';
            }).join("") + '</tr>';
        }).join("") + '</tbody></table></div></div>';
    }

    box.innerHTML = nav + body;
    box.querySelectorAll("[data-cttab]").forEach(function (b) {
      b.onclick = function () { st.tab = b.dataset.cttab; paint(); };
    });

    if (st.tab === "picker") {
      $("ctRosterInp").oninput = function (ev) { saveRoster(ev.target.value); };
      $("ctPickBtn").onclick = function () {
        saveRoster($("ctRosterInp").value);
        var all = getRosterList();
        if (!all.length) { toast("أدخل أسماء الطلاب أولاً", "warning"); return; }
        var rem = all.filter(function (n) { return st.pickedHistory.indexOf(n) === -1; });
        if (!rem.length) {
          st.pickedHistory = [];
          rem = all.slice();
          toast("شارك جميع الطلاب! بدأنا دورة جديدة 👏", "info");
        }
        var win = rem[Math.floor(Math.random() * rem.length)];
        st.currentWinner = win;
        st.pickedHistory.push(win);
        beep(760, 0.2);
        paint();
      };
      $("ctResetPick").onclick = function () { st.pickedHistory = []; st.currentWinner = ""; paint(); };
    } else if (st.tab === "groups") {
      $("ctGrpCount").onchange = function (ev) { st.groupCount = +ev.target.value || 3; };
      $("ctMakeGroups").onclick = function () {
        var all = shuf(getRosterList());
        if (all.length < 2) { toast("أدخل أسماء الطلاب في تبويب القرعة أولاً", "warning"); return; }
        var k = Math.min(st.groupCount, all.length), out = [];
        for (var i = 0; i < k; i++) out.push([]);
        all.forEach(function (nm, idx) { out[idx % k].push(nm); });
        st.groups = out;
        beep(640, 0.18);
        paint();
      };
      if ($("ctPrintGroups")) $("ctPrintGroups").onclick = function () {
        var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>المجموعات التعاونية</title><style>body{font-family:Cairo,Tahoma,sans-serif;padding:15mm}h1{text-align:center}.g{border:2px solid #0f172a;border-radius:12px;padding:12px;margin-bottom:12px;break-inside:avoid}</style></head><body><h1>تقسيم المجموعات التعاونية في الصف</h1>' +
          st.groups.map(function (g, i) { return '<div class="g"><h3>' + e(GROUP_NAMES[i] || ("المجموعة " + (i + 1))) + '</h3><ol>' + g.map(function (n) { return '<li>' + e(n) + '</li>'; }).join("") + '</ol></div>'; }).join("") + '</body></html>';
        var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
        f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
        setTimeout(function () { try { f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 3000); }, 500);
      };
    } else if (st.tab === "stars") {
      box.querySelectorAll("[data-stnm]").forEach(function (bt) {
        bt.onclick = function () {
          var nm = bt.dataset.stnm, delta = +bt.dataset.stadd || 1;
          st.points[nm] = Math.max(0, (st.points[nm] || 0) + delta);
          savePoints(st.points);
          beep(delta > 0 ? 840 : 280, 0.16);
          paint();
        };
      });
      if ($("ctStarsReset")) $("ctStarsReset").onclick = function () {
        if (!window.eduConfirm("تصفير نقاط السلوك لجميع طلاب الصف؟")) return;
        st.points = {}; savePoints(st.points); paint();
      };
      if ($("ctStarsCerts")) $("ctStarsCerts").onclick = function () {
        var roster = getRosterList();
        var top = roster.slice().sort(function (a, b) { return (st.points[b] || 0) - (st.points[a] || 0); })
          .filter(function (n) { return (st.points[n] || 0) > 0; })
          .slice(0, 10)
          .map(function (n) { return n + " | " + (st.points[n] || 0) + " نجمة تميز"; });
        if (!top.length) top = roster.slice(0, 5);
        if (window.EduCertificates && window.EduCertificates.openWithNames) {
          window.EduCertificates.openWithNames(top, "نجوم التميز والسلوك الإيجابي في الصف");
          toast("تم إرسال قائمة أوائل نجوم الصف إلى مولّد الشهادات الجماعية ✓", "success");
        }
      };
      if ($("ctStarsPrint")) $("ctStarsPrint").onclick = function () {
        var roster = getRosterList().slice().sort(function (a, b) { return (st.points[b] || 0) - (st.points[a] || 0); });
        var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>لوحة شرف نجوم الصف</title><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;800;900&display=swap" rel="stylesheet"><style>@page{size:A4;margin:14mm}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a}h1{text-align:center;color:#b45309;margin-bottom:14px}table{width:100%;border-collapse:collapse}th,td{border:1.5px solid #334155;padding:8px 12px;text-align:center;font-size:14px}th{background:#fef3c7;font-weight:900}</style></head><body><h1>🏆 لوحة شرف نجوم الصف والسلوك الإيجابي — EduTech Mindset</h1><table><thead><tr><th>المركز</th><th>اسم الطالب/ـة</th><th>رصيد نجوم التميز</th></tr></thead><tbody>' +
          roster.map(function (n, i) { return '<tr><td>' + (i + 1) + '</td><td style="font-weight:800">' + e(n) + '</td><td style="font-weight:900;color:#059669">⭐ ' + (st.points[n] || 0) + '</td></tr>'; }).join("") + '</tbody></table></body></html>';
        var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
        f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
        setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
      };
    } else if (st.tab === "timer") {
      box.querySelectorAll("[data-tmset]").forEach(function (b) {
        b.onclick = function () {
          if (st.timerIv) clearInterval(st.timerIv);
          st.timerRunning = false;
          st.timerSecs = +b.dataset.tmset;
          st.timerLeft = st.timerSecs;
          paint();
        };
      });
      $("ctTimerToggle").onclick = function () {
        if (st.timerRunning) {
          clearInterval(st.timerIv);
          st.timerRunning = false;
          paint();
        } else {
          if (st.timerLeft <= 0) st.timerLeft = st.timerSecs;
          st.timerRunning = true;
          paint();
          st.timerIv = setInterval(function () {
            st.timerLeft = Math.max(0, st.timerLeft - 1);
            var dEl = $("ctTimerDisp");
            if (dEl) {
              var mm2 = Math.floor(st.timerLeft / 60), ss2 = st.timerLeft % 60;
              dEl.textContent = (mm2 < 10 ? "0" : "") + mm2 + ":" + (ss2 < 10 ? "0" : "") + ss2;
            }
            if (st.timerLeft <= 0) {
              clearInterval(st.timerIv);
              st.timerRunning = false;
              beep(880, 0.45);
              setTimeout(function () { beep(980, 0.5); }, 350);
              toast("⏰ انتهى وقت النشاط الصفي!", "warning");
              paint();
            }
          }, 1000);
        }
      };
      $("ctTimerReset").onclick = function () {
        if (st.timerIv) clearInterval(st.timerIv);
        st.timerRunning = false;
        st.timerLeft = st.timerSecs;
        paint();
      };
    } else if (st.tab === "schedule") {
      box.querySelectorAll("[data-sckey]").forEach(function (inp) {
        inp.oninput = function () {
          st.schedule[inp.dataset.sckey] = inp.value;
          saveSchedule();
        };
      });
      $("ctClearSched").onclick = function () {
        if (!window.eduConfirm("تفريغ الجدول الأسبوعي بالكامل؟")) return;
        st.schedule = {}; saveSchedule(); paint();
      };
      $("ctPrintSched").onclick = function () {
        var rowsHtml = DAYS.map(function (day, di) {
          return '<tr><td style="font-weight:900;background:#f1f5f9">' + day + '</td>' +
            PERIODS.map(function (_, pi) { return '<td>' + e(st.schedule[di + "_" + pi] || "") + '</td>'; }).join("") + '</tr>';
        }).join("");
        var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>الجدول المدرسي الأسبوعي</title><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;800;900&display=swap" rel="stylesheet"><style>@page{size:A4 landscape;margin:12mm}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a}h1{text-align:center;margin-bottom:14px}table{width:100%;border-collapse:collapse}th,td{border:2px solid #334155;padding:10px;text-align:center;font-size:14px}th{background:#e2e8f0;font-weight:900}</style></head><body><h1>📅 الجدول المدرسي الأسبوعي</h1><table><thead><tr><th>اليوم / الحصة</th>' + PERIODS.map(function (p) { return '<th>' + p + '</th>'; }).join("") + '</tr></thead><tbody>' + rowsHtml + '</tbody></table></body></html>';
        var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
        f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
        setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
      };
    }
  }

  function build() {
    if ($("classToolsStudio")) return true;
    var anchor = $("classroomsStudio") || $("teacherDash") || $("certStudio") || $("designStudio");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "classToolsStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-emerald-700 via-teal-800 to-slate-900 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1">🧰 حقيبة إدارة الصف الذكية والجدول المدرسي</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">القرعة العشوائية، مقسّم المجموعات التعاونية، مؤقت الحصة، والجدول الأسبوعي</h2>' +
      '<p class="text-xs text-white/85 mt-1">أدوات يومية سريعة للمعلم داخل الغرفة الصفية تعمل بالكامل حتى بلا إنترنت.</p>' +
      '</div><div class="p-4 sm:p-6 text-right" id="ctoolsBody"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    paint();
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduClassTools = { open: function (tab) { if (tab) st.tab = tab; paint(); if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("classToolsStudio", true); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

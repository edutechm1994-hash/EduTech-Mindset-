/*
 * المراجعة الذكية — EduTech Mindset (الإصدار 77)
 * نظام بطاقات بالتكرار المتباعد (طريقة لايتنر، 5 صناديق) يعمل بلا إنترنت:
 *  - تُضاف البطاقات يدوياً بصيغة «سؤال | جواب» أو تُولَّد بالذكاء الاصطناعي من أي نص أو موضوع.
 *  - تُجدول المراجعة تلقائياً: ما تتذكره يتباعد موعده (1 ← 3 ← 7 ← 16 يوماً) وما تنساه يعود قريباً.
 *  - هدف يومي، سلسلة أيام متتالية، رسم لآخر 7 أيام، ونقاط خبرة (XP) عند إنهاء الجلسات.
 *  - واجهة برمجية للوحدات الأخرى: EduReview.addCards(deck, [{q, a}]).
 * البيانات محفوظة في هذا الجهاز فقط (localStorage).
 */
(function () {
  "use strict";
  var KEY = "edu_review_v77";
  var DAY = 86400000;
  var INTERVALS = [0, 0, 1, 3, 7, 16]; // بالأيام حسب الصندوق (1..5)
  var DAY_NAMES = ["أحد", "إثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"];
  var esc = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };

  var SAMPLE = [
    ["ما ناتج 7 × 8؟", "56"],
    ["ما جمع كلمة «كتاب»؟", "كتب"],
    ["ما الرمز الكيميائي للماء؟", "H₂O"],
    ["كم عدد أضلاع المسدس؟", "6"],
    ["ما الكوكب الملقّب بالكوكب الأحمر؟", "المريخ"],
    ["ما ضد كلمة «قريب»؟", "بعيد"]
  ];

  /* ---------- الحالة ---------- */
  function today(ts) {
    var d = ts ? new Date(ts) : new Date();
    return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
  }
  function load() {
    try {
      var d = JSON.parse(localStorage.getItem(KEY) || "null");
      if (d && typeof d === "object") {
        d.cards = Array.isArray(d.cards) ? d.cards : [];
        d.log = d.log && typeof d.log === "object" ? d.log : {};
        d.goal = [5, 10, 20, 30].indexOf(d.goal) >= 0 ? d.goal : 10;
        d.goalAwarded = d.goalAwarded || "";
        return d;
      }
    } catch (e) {}
    return { cards: [], log: {}, goal: 10, goalAwarded: "" };
  }
  var S = load();
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { toast("تعذّر الحفظ: مساحة التخزين ممتلئة", "warning"); } }
  function uid() { return "c" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

  var V = { view: "home", deck: "", queue: [], idx: 0, shown: false, stats: { right: 0, hard: 0, wrong: 0 }, requeued: {}, counted: {}, msg: "" };

  /* ---------- البطاقات ---------- */
  function decks() {
    var m = {};
    S.cards.forEach(function (c) { m[c.deck] = (m[c.deck] || 0) + 1; });
    return Object.keys(m).sort().map(function (k) { return { name: k, count: m[k] }; });
  }
  function dueList(deck) {
    var now = Date.now();
    return S.cards.filter(function (c) { return c.due <= now && (!deck || c.deck === deck); })
      .sort(function (a, b) { return a.box - b.box || a.due - b.due; });
  }
  function addCards(deck, items) {
    deck = String(deck || "عام").trim().slice(0, 40) || "عام";
    var seen = {};
    S.cards.forEach(function (c) { if (c.deck === deck) seen[c.q + "\u0001" + c.a] = 1; });
    var n = 0;
    (items || []).forEach(function (it) {
      var q = String(it.q || "").trim().slice(0, 400), a = String(it.a || "").trim().slice(0, 600);
      if (!q || !a || seen[q + "\u0001" + a]) return;
      seen[q + "\u0001" + a] = 1;
      S.cards.push({ id: uid(), deck: deck, q: q, a: a, box: 1, due: Date.now(), reps: 0, lapses: 0, created: Date.now() });
      n++;
    });
    if (n) save();
    return n;
  }
  function parseLines(text) {
    var out = [];
    String(text || "").split(/\r?\n/).forEach(function (line) {
      line = line.replace(/^\s*(?:[\d٠-٩]+\s*[.)\-–:]|[-*•]+)\s*/, "").trim();
      if (!line) return;
      var m = line.split(/\s*(?:\||\t|::|;;)\s*/);
      if (m.length >= 2 && m[0] && m[1]) out.push({ q: m[0], a: m.slice(1).join(" — ") });
    });
    return out;
  }

  /* ---------- الإحصاء ---------- */
  function countToday() { return S.log[today()] || 0; }
  function streak() {
    var n = 0, t = Date.now();
    if (!S.log[today(t)]) t -= DAY; // السلسلة لا تنقطع قبل انتهاء اليوم
    while (S.log[today(t)]) { n++; t -= DAY; }
    return n;
  }
  function last7() {
    var out = [], i, t;
    for (i = 6; i >= 0; i--) { t = Date.now() - i * DAY; out.push({ label: DAY_NAMES[new Date(t).getDay()], n: S.log[today(t)] || 0 }); }
    return out;
  }
  function mastered() { return S.cards.filter(function (c) { return c.box >= 4; }).length; }

  /* ---------- الجلسة ---------- */
  function startSession(deck) {
    var q = dueList(deck).slice(0, 30).map(function (c) { return c.id; });
    if (!q.length) { V.msg = "لا توجد بطاقات مستحقة الآن. عُد لاحقاً أو أضف بطاقات جديدة."; V.view = "home"; render(); return; }
    V.deck = deck || ""; V.queue = q; V.idx = 0; V.shown = false; V.stats = { right: 0, hard: 0, wrong: 0 }; V.requeued = {}; V.counted = {}; V.view = "session";
    render();
  }
  function cardById(id) { for (var i = 0; i < S.cards.length; i++) if (S.cards[i].id === id) return S.cards[i]; return null; }

  function grade(kind) {
    var c = cardById(V.queue[V.idx]);
    if (!c) { next(); return; }
    var now = Date.now();
    c.reps = (c.reps || 0) + 1;
    if (kind === "wrong") {
      c.box = 1; c.lapses = (c.lapses || 0) + 1; c.due = now + 10 * 60000; V.stats.wrong++;
      if (!V.requeued[c.id]) { V.requeued[c.id] = 1; V.queue.push(c.id); }
    } else if (kind === "hard") {
      c.due = now + Math.max(INTERVALS[c.box] / 2, c.box > 1 ? 1 : 0) * DAY + (c.box > 1 ? 0 : 10 * 60000); V.stats.hard++;
    } else {
      c.box = Math.min(5, c.box + 1); c.due = now + INTERVALS[c.box] * DAY; V.stats.right++;
    }
    if (!V.counted[c.id]) {
      V.counted[c.id] = 1;
      var k = today();
      S.log[k] = (S.log[k] || 0) + 1;
    }
    save();
    next();
  }
  function next() {
    V.idx++; V.shown = false;
    if (V.idx >= V.queue.length) { finish(); return; }
    render();
  }
  function finish() {
    var total = V.stats.right + V.stats.hard + V.stats.wrong;
    var xp = Math.min(60, 10 + V.stats.right * 3);
    var goalNow = countToday() >= S.goal && S.goalAwarded !== today();
    try {
      if (window.EduBadges && typeof window.EduBadges.award === "function" && total) {
        window.EduBadges.award("review_session", xp, true);
        if (goalNow) window.EduBadges.award("review_goal", 25, true);
      }
    } catch (e) {}
    if (goalNow) { S.goalAwarded = today(); save(); }
    V.view = "done"; V.xp = xp; V.goalNow = goalNow;
    render();
  }

  /* ---------- الواجهة ---------- */
  function ensureSection() {
    var ex = document.getElementById("reviewStudio");
    if (ex) return ex;
    var anchor = document.getElementById("classToolsStudio") || document.getElementById("teacherDash") || document.getElementById("library");
    if (!anchor || !anchor.parentNode) return null;
    var sec = document.createElement("section");
    sec.id = "reviewStudio";
    sec.className = "py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20";
    anchor.parentNode.insertBefore(sec, anchor);
    sec.addEventListener("click", onClick);
    sec.addEventListener("change", onChange);
    return sec;
  }

  var BTN = "px-4 py-2.5 rounded-xl text-xs font-extrabold transition ";
  var BTN_PRIMARY = BTN + "bg-brand-600 hover:bg-brand-500 text-white";
  var BTN_SOFT = BTN + "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700";
  var FIELD = "w-full text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2.5 text-slate-800 dark:text-slate-100";

  function stat(label, value, color) {
    return '<div class="rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 p-3 text-center">' +
      '<div class="text-xl font-black ' + color + '">' + value + '</div><div class="text-[11px] font-bold text-slate-500 dark:text-slate-400 mt-0.5">' + label + '</div></div>';
  }

  function homeView() {
    var due = dueList("").length, total = S.cards.length, goalPct = Math.min(100, Math.round(countToday() / S.goal * 100));
    var bars = last7(), max = Math.max.apply(null, bars.map(function (b) { return b.n; }).concat([1]));
    var ds = decks();
    return (
      (V.msg ? '<div class="rounded-xl bg-amber-50 dark:bg-amber-900/20 border border-amber-300/60 text-amber-900 dark:text-amber-100 text-xs font-bold p-3">' + esc(V.msg) + '</div>' : '') +
      '<div class="grid grid-cols-2 sm:grid-cols-4 gap-2.5">' +
        stat("مستحقة الآن", due, "text-rose-500") + stat("كل البطاقات", total, "text-brand-600 dark:text-brand-400") +
        stat("متقنة (صندوق 4+)", mastered(), "text-emerald-500") + stat("أيام متتالية 🔥", streak(), "text-amber-500") +
      '</div>' +
      '<div class="grid sm:grid-cols-2 gap-3">' +
        '<div class="rounded-2xl border border-slate-200 dark:border-slate-700 p-3.5 flex items-center gap-4">' +
          '<div style="width:74px;height:74px;border-radius:50%;background:conic-gradient(#10b981 ' + goalPct + '%, rgba(148,163,184,.28) 0);display:flex;align-items:center;justify-content:center;flex-shrink:0">' +
            '<div class="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 font-black text-sm" style="width:58px;height:58px;border-radius:50%;display:flex;align-items:center;justify-content:center">' + countToday() + '/' + S.goal + '</div></div>' +
          '<div class="text-xs"><div class="font-black text-slate-800 dark:text-slate-100 mb-1">هدف اليوم</div>' +
            '<select data-rv-goal class="text-xs font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg px-2 py-1 text-slate-800 dark:text-slate-100" aria-label="الهدف اليومي">' +
              [5, 10, 20, 30].map(function (g) { return '<option value="' + g + '"' + (g === S.goal ? " selected" : "") + '>' + g + ' بطاقات</option>'; }).join("") + '</select></div>' +
        '</div>' +
        '<div class="rounded-2xl border border-slate-200 dark:border-slate-700 p-3.5"><div class="text-xs font-black text-slate-800 dark:text-slate-100 mb-2">آخر 7 أيام</div>' +
          '<div style="display:flex;align-items:flex-end;gap:6px;height:56px">' + bars.map(function (b) {
            return '<div style="flex:1;text-align:center"><div title="' + b.n + '" style="height:' + Math.max(3, Math.round(b.n / max * 40)) + 'px;background:' + (b.n ? "#0ea5e9" : "rgba(148,163,184,.35)") + ';border-radius:4px"></div><div style="font-size:9px;margin-top:3px" class="text-slate-500 dark:text-slate-400 font-bold">' + b.label + '</div></div>';
          }).join("") + '</div></div>' +
      '</div>' +
      '<div class="flex flex-wrap gap-2">' +
        '<button type="button" data-rv="start" class="' + BTN_PRIMARY + '"' + (due ? "" : " disabled style='opacity:.5'") + '><i class="fa-solid fa-play ml-1"></i> ابدأ المراجعة (' + Math.min(due, 30) + ')</button>' +
        '<button type="button" data-rv="add" class="' + BTN_SOFT + '"><i class="fa-solid fa-plus ml-1"></i> أضف بطاقات</button>' +
        '<button type="button" data-rv="manage" class="' + BTN_SOFT + '"><i class="fa-solid fa-layer-group ml-1"></i> إدارة المجموعات</button>' +
        (total ? '' : '<button type="button" data-rv="sample" class="' + BTN + 'bg-emerald-600 hover:bg-emerald-500 text-white">جرّب مجموعة تجريبية</button>') +
      '</div>' +
      (ds.length ? '<div class="text-[11px] text-slate-500 dark:text-slate-400 font-bold">المجموعات: ' + ds.map(function (d) {
        return '<button type="button" data-rv="startdeck" data-deck="' + esc(d.name) + '" class="underline hover:text-brand-600 mx-1">' + esc(d.name) + ' (' + d.count + ')</button>';
      }).join("") + '</div>' : '')
    );
  }

  function sessionView() {
    var c = cardById(V.queue[V.idx]);
    if (!c) return "";
    var pct = Math.round(V.idx / V.queue.length * 100);
    return (
      '<div class="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400"><span>' + (V.idx + 1) + ' / ' + V.queue.length + '</span><span>' + esc(c.deck) + ' • الصندوق ' + c.box + '</span></div>' +
      '<div style="height:6px;border-radius:99px;background:rgba(148,163,184,.3);overflow:hidden"><div style="height:100%;width:' + pct + '%;background:#0ea5e9"></div></div>' +
      '<div class="rounded-3xl border-2 border-brand-500/40 bg-white dark:bg-slate-900 p-6 sm:p-8 text-center min-h-[200px] flex flex-col items-center justify-center gap-4">' +
        '<div class="text-lg sm:text-2xl font-black text-slate-900 dark:text-white leading-relaxed">' + esc(c.q) + '</div>' +
        (V.shown ? '<div class="w-full pt-4 border-t border-dashed border-slate-300 dark:border-slate-600 text-base sm:text-xl font-bold text-emerald-600 dark:text-emerald-400 leading-relaxed">' + esc(c.a) + '</div>' : '') +
      '</div>' +
      (V.shown
        ? '<div class="grid grid-cols-3 gap-2">' +
            '<button type="button" data-rv="g-wrong" class="' + BTN + 'bg-rose-500 hover:bg-rose-400 text-white">1 • لم أعرفها</button>' +
            '<button type="button" data-rv="g-hard" class="' + BTN + 'bg-amber-500 hover:bg-amber-400 text-slate-950">2 • بصعوبة</button>' +
            '<button type="button" data-rv="g-good" class="' + BTN + 'bg-emerald-600 hover:bg-emerald-500 text-white">3 • عرفتها</button>' +
          '</div>'
        : '<button type="button" data-rv="show" class="' + BTN_PRIMARY + ' w-full">أظهر الإجابة (مسافة)</button>') +
      '<div class="text-center"><button type="button" data-rv="home" class="text-[11px] font-bold text-slate-500 dark:text-slate-400 underline">إنهاء الجلسة والعودة</button></div>'
    );
  }

  function doneView() {
    var t = V.stats.right + V.stats.hard + V.stats.wrong;
    return (
      '<div class="text-center space-y-3 py-4"><div class="text-5xl">' + (V.stats.wrong === 0 ? "🏆" : "💪") + '</div>' +
      '<div class="text-xl font-black text-slate-900 dark:text-white">أنهيت الجلسة!</div>' +
      '<div class="text-sm font-bold text-slate-600 dark:text-slate-300">عرفتها ' + V.stats.right + ' • بصعوبة ' + V.stats.hard + ' • لم تعرفها ' + V.stats.wrong + ' (من ' + t + ')</div>' +
      '<div class="inline-block px-3 py-1.5 rounded-full bg-amber-500/15 text-amber-700 dark:text-amber-300 text-xs font-black">+' + (V.xp || 0) + ' نقطة خبرة' + (V.goalNow ? ' • وبلغت هدف اليوم 🎯 (+25)' : '') + '</div>' +
      '<div class="flex justify-center gap-2 pt-2"><button type="button" data-rv="home" class="' + BTN_PRIMARY + '">العودة</button></div></div>'
    );
  }

  function addView() {
    var ds = decks();
    return (
      '<div class="grid sm:grid-cols-2 gap-3">' +
        '<div><label class="block text-xs font-black mb-1.5 text-slate-700 dark:text-slate-200" for="rvDeck">اسم المجموعة</label>' +
          '<input id="rvDeck" list="rvDecks" class="' + FIELD + '" value="' + esc(V.lastDeck || "") + '" placeholder="مثال: علوم — الوحدة الثالثة" maxlength="40">' +
          '<datalist id="rvDecks">' + ds.map(function (d) { return '<option value="' + esc(d.name) + '">'; }).join("") + '</datalist></div>' +
      '</div>' +
      '<div><label class="block text-xs font-black mb-1.5 text-slate-700 dark:text-slate-200" for="rvBulk">بطاقة في كل سطر بصيغة «السؤال | الجواب»</label>' +
        '<textarea id="rvBulk" rows="6" class="' + FIELD + '" placeholder="ما عاصمة مصر؟ | القاهرة&#10;ما ناتج 9 × 6؟ | 54"></textarea>' +
        '<div class="mt-2"><button type="button" data-rv="savebulk" class="' + BTN_PRIMARY + '"><i class="fa-solid fa-floppy-disk ml-1"></i> حفظ البطاقات</button></div></div>' +
      '<div class="rounded-2xl border border-indigo-300/50 dark:border-indigo-500/30 bg-indigo-50/60 dark:bg-indigo-900/10 p-3.5 space-y-2">' +
        '<div class="text-xs font-black text-indigo-700 dark:text-indigo-300">✨ ولّد بطاقات بالذكاء الاصطناعي</div>' +
        '<textarea id="rvAiText" rows="3" class="' + FIELD + '" placeholder="الصق فقرة من الدرس، أو صوّر صفحة الكتاب بالكاميرا، أو اكتب موضوعاً مثل: الدورة الدموية للصف السادس"></textarea>' +
        '<div class="flex flex-wrap gap-1.5">' +
          '<label class="px-2.5 py-1.5 rounded-xl bg-emerald-600 text-white text-[11px] font-black cursor-pointer flex items-center gap-1"><i class="fa-solid fa-camera"></i><span>تصوير صفحة بالكاميرا</span><input id="rvCamInp" type="file" accept="image/*" capture="environment" class="hidden"></label>' +
          '<label class="px-2.5 py-1.5 rounded-xl bg-sky-600 text-white text-[11px] font-black cursor-pointer flex items-center gap-1"><i class="fa-solid fa-folder-open"></i><span>ملف أو صورة من الجهاز</span><input id="rvFileInp" type="file" accept="image/*,application/pdf,.txt,.md" multiple class="hidden"></label>' +
          '<button type="button" data-rv="preset" class="px-2.5 py-1.5 rounded-xl bg-indigo-600 text-white text-[11px] font-black">📖 اختر درساً من المنهاج</button>' +
        '</div>' +
        '<div class="flex flex-wrap items-center gap-2"><select id="rvAiN" class="text-xs font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg px-2 py-2 text-slate-800 dark:text-slate-100">' +
          [5, 8, 12, 20].map(function (n) { return '<option value="' + n + '"' + (n === 8 ? " selected" : "") + '>' + n + ' بطاقات</option>'; }).join("") + '</select>' +
          '<button type="button" data-rv="aigen" id="rvAiBtn" class="' + BTN + 'bg-indigo-600 hover:bg-indigo-500 text-white">ولّد البطاقات</button></div></div>' +
      '<button type="button" data-rv="home" class="' + BTN_SOFT + '">رجوع</button>'
    );
  }

  function manageView() {
    var ds = decks();
    if (!ds.length) return '<div class="text-sm font-bold text-slate-500 dark:text-slate-400 py-4 text-center">لا توجد مجموعات بعد.</div><button type="button" data-rv="home" class="' + BTN_SOFT + '">رجوع</button>';
    return (
      '<div class="space-y-2.5">' + ds.map(function (d) {
        var due = dueList(d.name).length;
        return '<div class="rounded-2xl border border-slate-200 dark:border-slate-700 p-3 flex flex-wrap items-center justify-between gap-2">' +
          '<div><div class="text-sm font-black text-slate-900 dark:text-white">' + esc(d.name) + '</div><div class="text-[11px] font-bold text-slate-500 dark:text-slate-400">' + d.count + ' بطاقة • ' + due + ' مستحقة</div></div>' +
          '<div class="flex flex-wrap gap-1.5">' +
            '<button type="button" data-rv="startdeck" data-deck="' + esc(d.name) + '" class="' + BTN + 'bg-brand-600 text-white">راجع</button>' +
            '<button type="button" data-rv="print" data-deck="' + esc(d.name) + '" class="' + BTN_SOFT + '">طباعة</button>' +
            '<button type="button" data-rv="copy" data-deck="' + esc(d.name) + '" class="' + BTN_SOFT + '">نسخ نصي</button>' +
            '<button type="button" data-rv="deldeck" data-deck="' + esc(d.name) + '" class="' + BTN + 'bg-rose-500/10 text-rose-500 hover:bg-rose-500 hover:text-white">حذف</button>' +
          '</div></div>';
      }).join("") + '</div><button type="button" data-rv="home" class="' + BTN_SOFT + ' mt-3">رجوع</button>'
    );
  }

  function render() {
    var sec = ensureSection();
    if (!sec) return;
    var body = V.view === "session" ? sessionView() : V.view === "done" ? doneView() : V.view === "add" ? addView() : V.view === "manage" ? manageView() : homeView();
    sec.innerHTML =
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl p-5 sm:p-7 space-y-4 text-right">' +
        '<div class="border-b border-slate-200 dark:border-slate-800 pb-4">' +
          '<div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-300 text-xs font-black mb-1"><i class="fa-solid fa-brain"></i><span>تثبيت المعلومة في الذاكرة</span></div>' +
          '<h2 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">🧠 المراجعة الذكية بالتكرار المتباعد</h2>' +
          '<p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">بطاقات تعود إليك في الوقت المناسب قبل أن تنسى. تعمل بلا إنترنت وتُحفظ على جهازك.</p>' +
        '</div>' + body +
      '</div>';
    V.msg = "";
  }

  /* ---------- الأحداث ---------- */
  function onChange(e) {
    var g = e.target.closest && e.target.closest("[data-rv-goal]");
    if (g) { S.goal = +g.value; save(); render(); }
  }
  function onClick(e) {
    var b = e.target.closest && e.target.closest("[data-rv]");
    if (!b) return;
    var a = b.dataset.rv, deck = b.dataset.deck || "";
    if (a === "start") startSession("");
    else if (a === "startdeck") startSession(deck);
    else if (a === "show") { V.shown = true; render(); }
    else if (a.indexOf("g-") === 0) grade(a.slice(2));
    else if (a === "home") { V.view = "home"; render(); }
    else if (a === "add") { V.view = "add"; render(); }
    else if (a === "manage") { V.view = "manage"; render(); }
    else if (a === "sample") { addCards("مجموعة تجريبية", SAMPLE.map(function (x) { return { q: x[0], a: x[1] }; })); V.msg = "أُضيفت مجموعة تجريبية من 6 بطاقات."; render(); }
    else if (a === "savebulk") saveBulk();
    else if (a === "aigen") aiGenerate(b);
    else if (a === "preset" && window.EduSourceCapture) {
      window.EduSourceCapture.openPresets(function (p) {
        if (document.getElementById("rvDeck")) document.getElementById("rvDeck").value = (p.subject ? p.subject + " — " : "") + p.title;
        if (document.getElementById("rvAiText")) document.getElementById("rvAiText").value = p.title + "\n" + (p.notes || "");
      });
    }
    else if (a === "deldeck") {
      if (window.eduConfirm("حذف مجموعة «" + deck + "» وكل بطاقاتها؟")) { S.cards = S.cards.filter(function (c) { return c.deck !== deck; }); save(); render(); }
    }
    else if (a === "copy") copyDeck(deck);
    else if (a === "print") printDeck(deck);
  }

  function saveBulk() {
    var deck = (document.getElementById("rvDeck") || {}).value, items = parseLines((document.getElementById("rvBulk") || {}).value);
    if (!items.length) { toast("اكتب سطراً واحداً على الأقل بصيغة: السؤال | الجواب", "warning"); return; }
    V.lastDeck = deck;
    var n = addCards(deck, items);
    V.view = "home"; V.msg = n ? "أُضيفت " + n + " بطاقة." : "كل هذه البطاقات موجودة مسبقاً.";
    render();
  }

  function aiGenerate(btn) {
    var text = (document.getElementById("rvAiText") || {}).value || "", n = +(document.getElementById("rvAiN") || {}).value || 8;
    text = text.trim();
    if (text.length < 3) { toast("اكتب موضوعاً أو الصق نصاً أولاً", "warning"); return; }
    if (!window.AI || !window.AI.ask) { toast("خدمة الذكاء الاصطناعي غير متاحة الآن", "warning"); return; }
    var deck = (document.getElementById("rvDeck") || {}).value;
    V.lastDeck = deck;
    btn.disabled = true; btn.textContent = "جاري التوليد…";
    var prompt = "اكتب " + n + " بطاقات مراجعة (سؤال وجواب) بالعربية الفصحى من المادة التالية.\n" +
      "الصيغة: سطر واحد لكل بطاقة بالشكل: السؤال | الجواب\n" +
      "شروط: أسئلة واضحة ومحددة، وأجوبة قصيرة ودقيقة، بلا ترقيم ولا عناوين ولا أي شرح إضافي.\n\nالمادة:\n" + text.slice(0, 6000);
    window.AI.ask(prompt, null, "studio").then(function (out) {
      var items = parseLines(out);
      if (!items.length) throw new Error("empty");
      var added = addCards(deck || ("ذكاء اصطناعي — " + today()), items);
      V.view = "home"; V.msg = "ولّد الذكاء الاصطناعي " + items.length + " بطاقة وأُضيف منها " + added + " (بعد استبعاد المكرر). راجعها من «إدارة المجموعات».";
      render();
    }).catch(function () {
      btn.disabled = false; btn.textContent = "ولّد البطاقات";
      toast("تعذّر التوليد الآن. جرّب لاحقاً أو أضف البطاقات يدوياً.", "warning");
    });
  }

  function deckText(deck) {
    return S.cards.filter(function (c) { return c.deck === deck; }).map(function (c) { return c.q + " | " + c.a; }).join("\n");
  }
  function copyDeck(deck) {
    var t = deckText(deck);
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(function () { toast("نُسخت البطاقات (سؤال | جواب)"); }, function () { toast("تعذّر النسخ", "warning"); });
    else toast("المتصفح لا يدعم النسخ التلقائي", "warning");
  }
  function printDeck(deck) {
    var cards = S.cards.filter(function (c) { return c.deck === deck; });
    var w = window.open("", "_blank");
    if (!w) { toast("اسمح بالنوافذ المنبثقة للطباعة", "warning"); return; }
    w.document.write("<!DOCTYPE html><html lang='ar' dir='rtl'><head><meta charset='utf-8'><title>" + esc(deck) + "</title>" +
      "<style>body{font-family:Cairo,Tahoma,sans-serif;padding:20px;color:#0f172a}h2{margin:0 0 12px}table{width:100%;border-collapse:collapse}td,th{border:1px solid #94a3b8;padding:10px;font-size:14px;vertical-align:top}th{background:#0284c7;color:#fff}tr{page-break-inside:avoid}</style></head><body>" +
      "<h2>بطاقات المراجعة — " + esc(deck) + "</h2><table><thead><tr><th style='width:6%'>#</th><th>السؤال</th><th style='width:38%'>الجواب</th></tr></thead><tbody>" +
      cards.map(function (c, i) { return "<tr><td>" + (i + 1) + "</td><td>" + esc(c.q) + "</td><td>" + esc(c.a) + "</td></tr>"; }).join("") +
      "</tbody></table><p style='font-size:11px;color:#64748b;margin-top:14px'>منصة EduTech Mindset — عقلية التعليم والتكنولوجيا</p><script>window.onload=function(){window.print();}</script></body></html>");
    w.document.close();
  }

  document.addEventListener("change", function (e) {
    if (e.target && (e.target.id === "rvCamInp" || e.target.id === "rvFileInp") && window.EduSourceCapture) {
      window.EduSourceCapture.handleFiles(e.target.files, {
        onText: function (txt) { var el = document.getElementById("rvAiText"); if (el) el.value = txt.slice(0, 5000); },
        onUpdate: function (all) {
          var el = document.getElementById("rvAiText");
          if (el && !el.value.trim() && all.length) el.value = "استخرج أهم المصطلحات والأسئلة من الصفحة المصورة المرفقة (" + all[0].name + ")";
        }
      });
      e.target.value = "";
    }
  });
  document.addEventListener("keydown", function (e) {
    if (V.view !== "session") return;
    var sec = document.getElementById("reviewStudio");
    if (!sec || !sec.offsetParent) return;
    var tag = (e.target && e.target.tagName) || "";
    if (/INPUT|TEXTAREA|SELECT/.test(tag)) return;
    if (e.key === " " && !V.shown) { e.preventDefault(); V.shown = true; render(); }
    else if (V.shown && e.key === "1") grade("wrong");
    else if (V.shown && e.key === "2") grade("hard");
    else if (V.shown && e.key === "3") grade("good");
  });

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", render);
  else render();

  window.EduReview = {
    render: render,
    addCards: addCards,
    parse: parseLines,
    stats: function () { return { total: S.cards.length, due: dueList("").length, streak: streak(), today: countToday() }; }
  };
})();

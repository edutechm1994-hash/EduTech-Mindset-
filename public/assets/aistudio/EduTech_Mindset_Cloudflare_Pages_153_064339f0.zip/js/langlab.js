/*
 * معمل اللغات والنطق الذكي والإملاء الصوتي والإعراب (Language & Pronunciation Lab) — EduTech Mindset (الإصدار 47)
 * يضم 3 مختبرات لغوية تفاعلية للغتين العربية والإنجليزية:
 * 1) 🎙️ مدرب النطق والمحادثة الصوتية (قراءة بالسرعة العادية والبطيئة + التعرف على صوت الطالب وحساب دقة النطق %)
 * 2) ✍️ الإملاء الصوتي التفاعلي الذكي (يسمع الطالب الجملة ويكتبها غيباً مع تصحيح فوري للأخطاء الإملائية)
 * 3) 🌳 المعرب النحوي ومحلل القواعد والمفردات بالذكاء الاصطناعي (إعراب الجمل العربية وشرح قواعد الإنجليزية)
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var SAMPLES = {
    en: [
      "Knowledge is power and education builds the future.",
      "Palestine is the land of peace, science, and resilience.",
      "Photosynthesis converts sunlight into chemical energy in plants.",
      "Practice makes progress when we learn every single day."
    ],
    ar: [
      "العلم نور يبني العقول ويصنع الأمل في فلسطين.",
      "إنّ المعلمين بناة الأجيال وحملة رسالة العلم والأخلاق.",
      "القدس عاصمة فلسطين الأبدية ودرة المدائن.",
      "من جدّ وجد ومن سار على الدرب وصل."
    ]
  };

  var OFFLINE_IRAB = [
    {
      rule: "الجملة الاسمية (المبتدأ والخبر المفرد)",
      sent: "العِلْمُ نُورٌ سَاطِعٌ فِي الحَيَاةِ.",
      irab: "• العِلْمُ: مبتدأ مرفوع وعلامة رفعه الضمة الظاهرة على آخره.\n• نُورٌ: خبر المبتدأ مرفوع وعلامة رفعه تنوين الضم الظاهر على آخره.\n• سَاطِعٌ: نعت (صفة) مرفوع وعلامة رفعه تنوين الضم الظاهر على آخره.\n• فِي: حرف جر مبني على السكون لا محل له من الإعراب.\n• الحَيَاةِ: اسم مجرور بحرف الجر (في) وعلامة جره الكسرة الظاهرة على آخره."
    },
    {
      rule: "الجملة الفعلية (الفعل المضارع والفاعل والمفعول به)",
      sent: "يَشْرَحُ المُعَلِّمُ الدَّرْسَ بِإِتْقَانٍ.",
      irab: "• يَشْرَحُ: فعل مضارع مرفوع وعلامة رفعه الضمة الظاهرة على آخره.\n• المُعَلِّمُ: فاعل مرفوع وعلامة رفعه الضمة الظاهرة على آخره.\n• الدَّرْسَ: مفعول به منصوب وعلامة نصبه الفتحة الظاهرة على آخره.\n• بِإِتْقَانٍ: الباء حرف جر مبني على الكسر، وإتقانٍ: اسم مجرور وعلامة جره تنوين الكسر."
    },
    {
      rule: "النواسخ الفعلية (كان وأخواتها)",
      sent: "كَانَ الطَّالِبَانِ مُجْتَهِدَيْنِ فِي الامْتِحَانِ.",
      irab: "• كَانَ: فعل ماضٍ ناقص ناسخ مبني على الفتح.\n• الطَّالِبَانِ: اسم (كان) مرفوع وعلامة رفعه الألف لأنه مثنى.\n• مُجْتَهِدَيْنِ: خبر (كان) منصوب وعلامة نصبه الياء لأنه مثنى.\n• فِي الامْتِحَانِ: جار ومجرور متعلقان بـ (مجتهدين)."
    },
    {
      rule: "الحروف الناسخة (إنّ وأخواتها) وجمع المذكر السالم",
      sent: "إِنَّ المُعَلِّمِينَ صَانِعُو الأَجْيَالِ.",
      irab: "• إِنَّ: حرف توكيد ونصب مشبه بالفعل مبني على الفتح.\n• المُعَلِّمِينَ: اسم (إنّ) منصوب وعلامة نصبه الياء لأنه جمع مذكر سالم.\n• صَانِعُو: خبر (إنّ) مرفوع وعلامة رفعه الواو لأنه جمع مذكر سالم، وحُذفت النون للإضافة وهو مضاف.\n• الأَجْيَالِ: مضاف إليه مجرور وعلامة جره الكسرة الظاهرة على آخره."
    },
    {
      rule: "الأفعال الخمسة ونصب وجزم الفعل المضارع",
      sent: "الطُّلَّابُ يَجْتَهِدُونَ وَلَنْ يَتَهَاوَنُوا فِي دُرُوسِهِمْ.",
      irab: "• الطُّلَّابُ: مبتدأ مرفوع وعلامة رفعه الضمة الظاهرة.\n• يَجْتَهِدُونَ: فعل مضارع مرفوع وعلامة رفعه ثبوت النون لأنه من الأفعال الخمسة، وواو الجماعة ضمير متصل في محل رفع فاعل، والجملة الفعلية في محل رفع خبر المبتدأ.\n• لَنْ: حرف نصب ونفي واستقبال مبني على السكون.\n• يَتَهَاوَنُوا: فعل مضارع منصوب بـ (لن) وعلامة نصبه حذف النون لأنه من الأفعال الخمسة، وواو الجماعة فاعل."
    }
  ];

  function printGrammarPdf() {
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>مرجع الشواهد والقواعد الإعرابية — EduTech Mindset</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:12mm}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a;line-height:1.85;font-size:13px}h1{text-align:center;color:#0369a1;margin:0 0 12px}.card{border:1.5px solid #cbd5e1;border-radius:12px;padding:12px;margin-bottom:10px;break-inside:avoid}.rl{font-weight:900;color:#059669;font-size:12px}.sn{font-weight:900;font-size:15px;margin:4px 0;color:#1e3a8a}.ir{white-space:pre-line;background:#f8fafc;padding:8px 12px;border-radius:8px}</style></head><body>' +
      '<h1>🌳 مرجع القواعد والشواهد الإعرابية النموذجية — EduTech Mindset</h1>' +
      OFFLINE_IRAB.map(function (g) {
        return '<div class="card"><div class="rl">📌 ' + e(g.rule) + '</div><div class="sn">«' + e(g.sent) + '»</div><div class="ir">' + e(g.irab) + '</div></div>';
      }).join("") + '</body></html>';
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
  }

  var st = {
    tab: "pronounce", // pronounce | dictation | grammar
    lang: "en", // en | ar
    targetText: SAMPLES.en[0],
    spokenText: "",
    pronScore: null,
    dictText: SAMPLES.ar[0],
    dictInput: "",
    dictChecked: null,
    grammarOut: ""
  };

  function normWords(s) {
    return String(s || "").toLowerCase()
      .replace(/[ً-ٰٟـ.,!?;:؟،؛"']/g, "")
      .replace(/[أإآ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه")
      .trim().split(/\s+/).filter(Boolean);
  }

  function speak(text, lang, rate) {
    if (!("speechSynthesis" in window)) { toast("متصفحك لا يدعم القراءة الصوتية", "warning"); return; }
    window.speechSynthesis.cancel();
    var u = new SpeechSynthesisUtterance(String(text || ""));
    u.lang = lang === "en" ? "en-US" : "ar-SA";
    u.rate = rate || 1.0;
    window.speechSynthesis.speak(u);
  }

  function startSpeechRecognition() {
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      toast("متصفحك لا يدعم التعرف المباشر على الصوت (جرّب متصفح Chrome أو Edge)", "warning");
      return;
    }
    var rec = new SR();
    rec.lang = st.lang === "en" ? "en-US" : "ar-SA";
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    var btn = $("llMicBtn");
    if (btn) { btn.disabled = true; btn.textContent = "🎙️ تحدّث الآن… (جارٍ الاستماع)"; }
    rec.onresult = function (ev) {
      var transcript = ev.results[0][0].transcript || "";
      st.spokenText = transcript;
      var targetW = normWords(st.targetText), spokenW = normWords(transcript);
      var hit = 0;
      targetW.forEach(function (w) { if (spokenW.indexOf(w) !== -1) hit++; });
      st.pronScore = targetW.length ? Math.round(hit * 100 / targetW.length) : 0;
      if (st.pronScore >= 80 && window.EduBadges && window.EduBadges.award) window.EduBadges.award("first_step", 25, true);
      paint();
    };
    rec.onerror = function () {
      toast("تعذر التقاط الصوت — تأكد من السماح للميكروفون", "warning");
      if (btn) { btn.disabled = false; btn.textContent = "🎙️ اضغط وتحدّث لاختبار نطقك"; }
    };
    rec.onend = function () {
      if (btn) { btn.disabled = false; btn.textContent = "🎙️ اضغط وتحدّث لاختبار نطقك"; }
    };
    rec.start();
  }

  function paint() {
    var box = $("llBody"); if (!box) return;
    var tabs = [
      ["pronounce", "🎙️ مدرب النطق والمحادثة (عربي / إنجليزي)"],
      ["dictation", "✍️ الإملاء الصوتي التفاعلي الذكي"],
      ["grammar", "🌳 المعرب النحوي ومحلل القواعد بالـ AI"]
    ];
    var nav = '<div class="flex flex-wrap gap-2 mb-4 border-b border-slate-200 dark:border-slate-700 pb-3">' +
      tabs.map(function (t) {
        var on = st.tab === t[0];
        return '<button type="button" data-lltab="' + t[0] + '" class="px-4 py-2 rounded-xl text-xs font-extrabold transition-all ' + (on ? "bg-sky-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">' + t[1] + '</button>';
      }).join("") + '</div>';

    var body = "";
    if (st.tab === "pronounce") {
      var list = SAMPLES[st.lang] || SAMPLES.en;
      body = '<div class="space-y-4">' +
        '<div class="flex flex-wrap items-center gap-2">' +
        '<button type="button" data-lllang="en" class="px-4 py-1.5 rounded-xl text-xs font-black ' + (st.lang === "en" ? "bg-indigo-600 text-white" : "bg-slate-200 dark:bg-slate-700") + '">🇬🇧 اللغة الإنجليزية (English)</button>' +
        '<button type="button" data-lllang="ar" class="px-4 py-1.5 rounded-xl text-xs font-black ' + (st.lang === "ar" ? "bg-emerald-600 text-white" : "bg-slate-200 dark:bg-slate-700") + '">🇵🇸 اللغة العربية (الفصحى)</button>' +
        '<button type="button" id="llAiSent" class="px-3.5 py-1.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-black mr-auto">✨ ولّد جملة تدريبية جديدة بالـ AI</button>' +
        '</div>' +
        '<div><label class="block text-xs font-bold mb-1">اختر جملة جاهزة أو اكتب أي جملة للتدرب على نطقها:</label>' +
        '<div class="flex flex-wrap gap-1.5 mb-2">' + list.map(function (s, i) {
          return '<button type="button" data-llsamp="' + i + '" class="px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-bold">جملة ' + (i + 1) + '</button>';
        }).join("") + '</div>' +
        '<input id="llTargetInp" dir="' + (st.lang === "en" ? "ltr" : "rtl") + '" value="' + e(st.targetText) + '" class="' + cls + ' !text-base !font-black"></div>' +
        '<div class="flex flex-wrap gap-2 justify-center p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700">' +
        '<button type="button" id="llSpeakNorm" class="px-5 py-2.5 rounded-xl bg-sky-600 text-white text-xs font-black">🔊 استمع للنطق الصحيح</button>' +
        '<button type="button" id="llSpeakSlow" class="px-5 py-2.5 rounded-xl bg-teal-600 text-white text-xs font-black">🐢 استمع ببطء للتعلّم</button>' +
        '<button type="button" id="llMicBtn" class="px-6 py-2.5 rounded-xl bg-rose-600 text-white text-xs font-black shadow-md">🎙️ اضغط وتحدّث لاختبار نطقك</button>' +
        '</div>' +
        (st.pronScore !== null ? '<div class="p-4 rounded-2xl border-2 ' + (st.pronScore >= 75 ? "border-emerald-400 bg-emerald-50/50 dark:bg-emerald-950/30" : "border-amber-400 bg-amber-50/50 dark:bg-amber-950/30") + ' text-center space-y-1.5">' +
          '<div class="text-2xl font-black">' + (st.pronScore >= 80 ? "🌟 ممتاز! دقة نطقك: " : "👏 جيد! دقة نطقك: ") + st.pronScore + '%</div>' +
          '<div class="text-xs text-slate-600 dark:text-slate-300">ما التقطه الميكروفون: <b>«' + e(st.spokenText) + '»</b></div></div>' : '') +
        '</div>';
    } else if (st.tab === "dictation") {
      body = '<div class="space-y-4">' +
        '<div class="flex flex-wrap items-center justify-between gap-2">' +
        '<span class="text-xs font-extrabold">استمع للجملة بالصوت ثم اكتبها في الصندوق للتحقق من إملائك:</span>' +
        '<div class="flex gap-1.5"><button type="button" id="llDictNew" class="px-3.5 py-1.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-black">🎲 جملة إملائية جديدة</button>' +
        '<button type="button" id="llDictAi" class="px-3.5 py-1.5 rounded-xl bg-purple-600 text-white text-xs font-black">🤖 ولّد نص إملاء بالـ AI</button></div></div>' +
        '<div class="flex flex-wrap gap-2 justify-center p-4 rounded-2xl bg-indigo-50/60 dark:bg-slate-900/60 border border-indigo-200 dark:border-slate-700">' +
        '<button type="button" id="llDictPlay" class="px-6 py-3 rounded-2xl bg-indigo-600 text-white text-xs font-black shadow">🔊 اسمع جملة الإملاء</button>' +
        '<button type="button" id="llDictSlow" class="px-5 py-3 rounded-2xl bg-teal-600 text-white text-xs font-black">🐢 اسمع ببطء كلمة كلمة</button>' +
        '</div>' +
        '<textarea id="llDictInp" rows="3" class="' + cls + ' !text-sm" placeholder="اكتب ما سمعته هنا…">' + e(st.dictInput) + '</textarea>' +
        '<button type="button" id="llDictCheck" class="px-6 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black">✅ صحّح الإملاء الآن</button>' +
        (st.dictChecked ? '<div class="p-4 rounded-2xl border-2 border-emerald-400 bg-white dark:bg-slate-800 space-y-2 text-xs">' +
          '<div class="font-black text-base text-emerald-600">النتيجة: ' + st.dictChecked.pct + '% إملاء صحيح</div>' +
          '<div><b>النص الأصلي:</b> ' + e(st.dictText) + '</div>' +
          '<div><b>كتابتك:</b> ' + st.dictChecked.diffHtml + '</div></div>' : '') +
        '</div>';
    } else if (st.tab === "grammar") {
      body = '<div class="space-y-3">' +
        '<div class="p-3 rounded-2xl bg-emerald-50/70 dark:bg-slate-800/80 border border-emerald-200 dark:border-slate-700 space-y-2">' +
        '<div class="flex flex-wrap items-center justify-between gap-2">' +
        '<span class="text-[11px] font-black text-emerald-800 dark:text-emerald-300">🌳 نماذج وشواهد إعرابية جاهزة (تعمل 100% بلا إنترنت):</span>' +
        '<button type="button" id="llPrintIrabPdf" class="px-3 py-1 rounded-lg bg-indigo-600 text-white text-[11px] font-extrabold">🖨 طباعة مرجع الإعراب PDF</button></div>' +
        '<div class="flex flex-wrap gap-1.5">' +
        OFFLINE_IRAB.map(function (g, idx) {
          return '<button type="button" data-llirab="' + idx + '" class="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-emerald-300 dark:border-slate-700 text-[11px] font-extrabold hover:bg-emerald-600 hover:text-white transition-all">' + e(g.rule) + '</button>';
        }).join("") + '</div></div>' +
        '<label class="block text-xs font-bold">أو اكتب أي جملة عربية لإعرابها بالذكاء الاصطناعي، أو جملة إنجليزية لشرح قواعدها:</label>' +
        '<textarea id="llGramInp" rows="3" class="' + cls + '" placeholder="مثال: يدرسُ الطالبُ المجتهدُ دروسَهُ بانتظامٍ في المدرسةِ">' + e(st.targetText) + '</textarea>' +
        '<div class="flex flex-wrap gap-2">' +
        '<button type="button" id="llGramIrab" class="px-5 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black">🌳 أعرب الجملة إعراباً مفصلاً بالـ AI</button>' +
        '<button type="button" id="llGramEn" class="px-5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-black">🇬🇧 شرح قواعد ومفردات وترجمة (English)</button>' +
        '</div>' +
        (st.grammarOut ? '<div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs leading-loose whitespace-pre-line font-semibold">' + e(st.grammarOut) + '</div>' : '') +
        '</div>';
    }

    box.innerHTML = nav + body;
    box.querySelectorAll("[data-lltab]").forEach(function (b) {
      b.onclick = function () { st.tab = b.dataset.lltab; paint(); };
    });

    if (st.tab === "pronounce") {
      box.querySelectorAll("[data-lllang]").forEach(function (b) {
        b.onclick = function () {
          st.lang = b.dataset.lllang;
          st.targetText = SAMPLES[st.lang][0];
          st.pronScore = null;
          paint();
        };
      });
      box.querySelectorAll("[data-llsamp]").forEach(function (b) {
        b.onclick = function () {
          st.targetText = SAMPLES[st.lang][+b.dataset.llsamp];
          st.pronScore = null;
          paint();
        };
      });
      $("llTargetInp").oninput = function (ev) { st.targetText = ev.target.value; };
      $("llSpeakNorm").onclick = function () { speak($("llTargetInp").value, st.lang, 1.0); };
      $("llSpeakSlow").onclick = function () { speak($("llTargetInp").value, st.lang, 0.65); };
      $("llMicBtn").onclick = function () { st.targetText = $("llTargetInp").value; startSpeechRecognition(); };
      $("llAiSent").onclick = function () {
        var btn = $("llAiSent"); btn.disabled = true; btn.textContent = "⏳ يولّد…";
        var p = st.lang === "en" ? "Write ONE clear educational English sentence suitable for school students (10-14 words) only, without quotes." : "اكتب جملة عربية فصحى واحدة مفيدة ومشكولة جزئياً لطلبة المدارس (8 إلى 12 كلمة) فقط بلا علامات تنصيص.";
        window.AI.ask(p, [], "studio").then(function (t) { st.targetText = String(t || "").trim(); st.pronScore = null; paint(); }).catch(function () { btn.disabled = false; btn.textContent = "✨ ولّد جملة تدريبية جديدة بالـ AI"; });
      };
    } else if (st.tab === "dictation") {
      $("llDictPlay").onclick = function () { speak(st.dictText, "ar", 0.95); };
      $("llDictSlow").onclick = function () { speak(st.dictText, "ar", 0.58); };
      $("llDictNew").onclick = function () {
        var arr = SAMPLES.ar;
        st.dictText = arr[(arr.indexOf(st.dictText) + 1) % arr.length];
        st.dictInput = ""; st.dictChecked = null;
        paint();
        speak(st.dictText, "ar", 0.92);
      };
      $("llDictAi").onclick = function () {
        var btn = $("llDictAi"); btn.disabled = true; btn.textContent = "⏳ يولّد…";
        window.AI.ask("اكتب فقرة إملائية عربية قصيرة (جملتان فيهما همزات وتاء مربوطة ومبسوطة) لطلبة المدرسة، أعد النص فقط بلا أي مقدمات.", [], "studio").then(function (t) {
          st.dictText = String(t || "").trim(); st.dictInput = ""; st.dictChecked = null; paint(); speak(st.dictText, "ar", 0.9);
        }).catch(function () { btn.disabled = false; btn.textContent = "🤖 ولّد نص إملاء بالـ AI"; });
      };
      $("llDictCheck").onclick = function () {
        st.dictInput = $("llDictInp").value.trim();
        if (!st.dictInput) { toast("اكتب الجملة التي سمعتها أولاً", "warning"); return; }
        var origW = st.dictText.trim().split(/\s+/), usrW = st.dictInput.split(/\s+/);
        var ok = 0;
        var diff = usrW.map(function (uw, i) {
          var ow = origW[i] || "";
          var match = normWords(uw)[0] === normWords(ow)[0];
          if (match) ok++;
          return '<span class="px-1 rounded ' + (match ? "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 font-bold" : "bg-rose-500/20 text-rose-600 line-through font-bold") + '">' + e(uw) + '</span>';
        }).join(" ");
        st.dictChecked = { pct: Math.round(ok * 100 / Math.max(1, origW.length)), diffHtml: diff };
        paint();
      };
    } else if (st.tab === "grammar") {
      if ($("llPrintIrabPdf")) $("llPrintIrabPdf").onclick = printGrammarPdf;
      box.querySelectorAll("[data-llirab]").forEach(function (bt) {
        bt.onclick = function () {
          var g = OFFLINE_IRAB[+bt.dataset.llirab];
          if (!g) return;
          st.targetText = g.sent;
          st.grammarOut = "📌 القاعدة: " + g.rule + "\nالجملة: «" + g.sent + "»\n\n" + g.irab;
          paint();
        };
      });
      $("llGramIrab").onclick = function () {
        var v = $("llGramInp").value.trim(); if (!v) return;
        st.targetText = v;
        var b = $("llGramIrab"); b.disabled = true; b.textContent = "⏳ يعرب الجملة…";
        window.AI.ask("أعرب الجملة العربية التالية إعراباً مدرسياً واضحاً ومفصلاً كلمةً كلمة مع ضبط أواخر الكلمات بالشكل:\n«" + v + "»", [], "studio").then(function (txt) {
          st.grammarOut = txt; paint();
        }).catch(function () { b.disabled = false; b.textContent = "🌳 أعرب الجملة إعراباً مفصلاً"; });
      };
      $("llGramEn").onclick = function () {
        var v = $("llGramInp").value.trim(); if (!v) return;
        st.targetText = v;
        var b = $("llGramEn"); b.disabled = true; b.textContent = "⏳ يحلل الجملة…";
        window.AI.ask("اشرح بالعربية المبسطة قواعد ومفردات وزمن الجملة الإنجليزية التالية مع ترجمتها الدقيقة:\n«" + v + "»", [], "studio").then(function (txt) {
          st.grammarOut = txt; paint();
        }).catch(function () { b.disabled = false; b.textContent = "🇬🇧 شرح قواعد ومفردات وترجمة (English)"; });
      };
    }
  }

  function build() {
    if ($("langLabStudio")) return true;
    var anchor = $("storiesStudio") || $("tutorStudio") || $("booksSection");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "langLabStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-sky-700 via-blue-800 to-slate-900 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1">🗣️ معمل اللغات والنطق الذكي والإملاء الصوتي والإعراب</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">تدرّب على النطق بالإنجليزية والعربية، الإملاء المسموع، والإعراب النحوي الفوري</h2>' +
      '<p class="text-xs text-white/85 mt-1">مختبر صوتي ولغوي متكامل يقيس دقة نطق الطالب بالميكروفون ويصحح الإملاء ويعرب الجمل بالتفصيل.</p>' +
      '</div><div class="p-4 sm:p-6 text-right" id="llBody"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    paint();
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduLangLab = { open: function (tab) { if (tab) st.tab = tab; paint(); if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("langLabStudio", true); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

/* الواقع المعزز التلقائي: كاميرا ← «تعرّف» ← الذكاء الاصطناعي يسمّي الأجزاء بالعربية ← تتبّع حيّ يُبقي الأسماء ملتصقة بالصورة */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "info"); };
  var S = { stream: null, tracker: null, parts: [], title: "", live: false, busy: false, timer: 0, mode: "cam", lost: 0, vw: 0, vh: 0, aw: 0, ah: 0, still: null, lastCall: 0 };
  var AW = 320;

  function buildPrompt() {
    return "أنت معلم أحياء وعلوم. الصورة المرفقة مأخوذة بكاميرا هاتف أو معرض لصورة في كتاب مدرسي. " +
      "حدّد الرسم التوضيحي الرئيسي (مثل الجهاز الهضمي أو القلب أو الخلية) وأسماء أجزائه المهمة (من 4 إلى 12 جزءاً) التي تراها فعلاً في الصورة. " +
      "لكل جزء أعطِ المستطيل المحيط به بالضبط على الجزء نفسه (لا على الجزء المجاور) بصيغة box_2d = [ymin, xmin, ymax, xmax] بقيم صحيحة من 0 إلى 1000 نسبةً لأبعاد الصورة كاملة. " +
      "أعد JSON فقط بلا شرح خارجه وبلا علامات ```، بهذا الشكل:\n" +
      '{"title":"اسم الرسم بالعربية","parts":[{"name":"اسم الجزء بالعربية (كلمة إلى ثلاث)","box_2d":[310,420,420,560],"info":"شرح موجز للوظيفة بجملة أو جملتين بالعربية المبسطة"}]}\n' +
      "كن دقيقاً: الجزء الكبير (كالأمعاء) مستطيله كبير، والصغير (كالمريء) مستطيله ضيق. لا تكرر الجزء نفسه. " +
      'إذا لم تجد رسماً علمياً واضحاً أعد {"title":"","parts":[]}.';
  }
  function parse(txt) {
    var s = String(txt || ""), a = s.indexOf("{"), b = s.lastIndexOf("}");
    if (a < 0 || b < a) throw new Error("تعذّر فهم رد الذكاء الاصطناعي");
    var j = JSON.parse(s.slice(a, b + 1)), out = [];
    (j.parts || []).forEach(function (p) {
      var x = +p.x, y = +p.y, bx = p.box_2d || p.box;
      if (bx && bx.length === 4 && bx.every(function (n) { return isFinite(+n); })) { var yn = +bx[0], xn = +bx[1], ym = +bx[2], xm = +bx[3], sc = Math.max(yn, xn, ym, xm) > 1.5 ? 1000 : 1; x = (xn + xm) / 2 / sc; y = (yn + ym) / 2 / sc; }
      if (!p.name || !(x >= 0 && x <= 1 && y >= 0 && y <= 1)) return;
      out.push({ name: String(p.name).slice(0, 40), x: x, y: y, info: String(p.info || "").slice(0, 400) });
    });
    return { title: String(j.title || "").slice(0, 80), parts: out.slice(0, 14) };
  }

  // ---------- الواجهة ----------
  function buildSection() {
    if ($("arSection")) return true;
    var anchor = $("booksSection") || $("learnSection"); if (!anchor) return false;
    var s = document.createElement("section"); s.id = "arSection"; s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8"><div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden"><div class="p-5 sm:p-6 text-white" style="background:linear-gradient(270deg,#6d28d9,#3730a3 55%,#0f172a)"><div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1">🔬 تجربة تجريبية</div><h2 class="text-xl sm:text-2xl font-black">الواقع المعزز: وجّه الكاميرا نحو صورة الكتاب</h2><p class="text-xs text-slate-200 mt-1 leading-6">وجّه كاميرا هاتفك إلى رسم في كتابك (الجهاز الهضمي، القلب، الخلية…) واضغط «تعرّف»؛ يظهر اسم كل جزء بالعربية على الصورة نفسها، ويبقى ملتصقاً بها وأنت تحرّك الهاتف. اضغط أي اسم لشرحه.</p></div>' +
      '<div class="p-4 sm:p-5 text-right"><div class="flex flex-wrap gap-2"><button type="button" id="arOpen" class="px-5 py-3 rounded-xl text-white text-sm font-extrabold" style="background:#7c3aed">📷 افتح الكاميرا</button><label class="px-5 py-3 rounded-xl bg-slate-200 dark:bg-slate-700 text-sm font-extrabold cursor-pointer">🖼 اختر صورة من الجهاز<input type="file" id="arFile" accept="image/*" class="hidden"></label></div>' +
      '<p class="text-[11px] text-slate-500 mt-3 leading-6">يحتاج إنترنت وتسجيل دخول، ويستهلك من حصة الذكاء الاصطناعي اليومية. الأفضل: صورة واضحة ومضاءة وكاملة داخل الإطار. المواضع تقريبية وقد تحتاج إعادة المحاولة.</p></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling); return true;
  }
  function overlay() {
    var o = $("arOv"); if (o) return o;
    o = document.createElement("div"); o.id = "arOv"; o.setAttribute("dir", "rtl");
    o.style.cssText = "position:fixed;inset:0;z-index:99999;background:#000;display:none;touch-action:manipulation;font-family:Cairo,system-ui,sans-serif";
    o.innerHTML = '<video id="arVid" playsinline muted autoplay style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover"></video>' +
      '<img id="arStill" alt="" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain;display:none;background:#0f172a">' +
      '<div id="arLbl" style="position:absolute;inset:0;overflow:hidden;pointer-events:none"></div>' +
      '<div id="arTop" style="position:absolute;top:0;left:0;right:0;padding:10px 12px;display:flex;gap:8px;align-items:center;background:linear-gradient(#000a,transparent);color:#fff"><button id="arX" type="button" style="width:40px;height:40px;border-radius:20px;background:#0008;color:#fff;font-size:18px">✕</button><div id="arMsg" style="flex:1;font-size:12px;font-weight:700;line-height:1.5"></div></div>' +
      '<div id="arBot" style="position:absolute;bottom:0;left:0;right:0;padding:14px 12px calc(14px + env(safe-area-inset-bottom));display:flex;gap:10px;justify-content:center;background:linear-gradient(transparent,#000a)"><button id="arGo" type="button" style="padding:14px 28px;border-radius:16px;background:#7c3aed;color:#fff;font-weight:900;font-size:15px">🔍 تعرّف</button><button id="arEdit" type="button" style="display:none;padding:14px 18px;border-radius:16px;background:#fde047;color:#1e1b4b;font-weight:900;font-size:13px">✋ عدّل المواضع</button><button id="arAgain" type="button" style="display:none;padding:14px 18px;border-radius:16px;background:#fff3;color:#fff;font-weight:800;font-size:13px">↻ من جديد</button></div>' +
      '<div id="arSheet" style="position:absolute;left:0;right:0;bottom:0;display:none;background:#fff;color:#0f172a;border-radius:20px 20px 0 0;padding:16px 16px calc(16px + env(safe-area-inset-bottom));box-shadow:0 -8px 30px #0006"><div style="display:flex;gap:8px;align-items:flex-start"><div style="flex:1"><div id="arSName" style="font-weight:900;font-size:16px"></div><div id="arSInfo" style="font-size:13px;line-height:1.8;margin-top:4px;color:#334155"></div></div><button id="arSX" type="button" style="font-size:18px;padding:4px 8px">✕</button></div></div>';
    document.body.appendChild(o);
    $("arX").onclick = close; $("arGo").onclick = recognize; $("arAgain").onclick = again; $("arEdit").onclick = toggleEdit; $("arSX").onclick = function () { $("arSheet").style.display = "none"; };
    $("arLbl").addEventListener("click", function (ev) { var t = ev.target.closest("[data-i]"); if (t) openSheet(+t.getAttribute("data-i")); });
    var drag = -1;
    o.addEventListener("pointerdown", function (ev) { if (!S.edit) return; var d = ev.target.closest && ev.target.closest("[data-d]"); if (d) { drag = +d.getAttribute("data-d"); try { o.setPointerCapture(ev.pointerId); } catch (x) {} ev.preventDefault(); } });
    o.addEventListener("pointermove", function (ev) { if (drag < 0) return; var q = [ev.clientX, ev.clientY], k = $("arLbl").children[drag]; (S.scr = S.scr || [])[drag] = q; if (k) k.style.transform = "translate(" + q[0].toFixed(1) + "px," + q[1].toFixed(1) + "px)"; ev.preventDefault(); });
    o.addEventListener("pointerup", function () { drag = -1; }); o.addEventListener("pointercancel", function () { drag = -1; });
    return o;
  }
  function msg(t) { var m = $("arMsg"); if (m) m.textContent = t || ""; }
  function openSheet(i) { var p = S.parts[i]; if (!p) return; $("arSName").textContent = p.name; $("arSInfo").textContent = p.info || "لا يوجد شرح لهذا الجزء."; $("arSheet").style.display = "block"; }

  function openCam() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { toast("المتصفح لا يدعم الكاميرا؛ استخدم «اختر صورة من الجهاز»", "warning"); return; }
    var o = overlay(); o.style.display = "block"; reset(); S.mode = "cam";
    $("arVid").style.display = "block"; $("arStill").style.display = "none"; $("arGo").style.display = ""; msg("جارٍ تشغيل الكاميرا…");
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 } }, audio: false }).then(function (st) {
      S.stream = st; var v = $("arVid"); v.srcObject = st; var p = v.play(); if (p && p.catch) p.catch(function () {});
      msg("وجّه الكاميرا نحو الصورة بحيث تملأ الشاشة، ثم اضغط «تعرّف».");
    }, function () { msg("تعذّر فتح الكاميرا. اسمح بالوصول للكاميرا من إعدادات المتصفح، أو استخدم «اختر صورة»."); toast("تعذّر فتح الكاميرا", "warning"); });
  }
  function stopStream() { if (S.stream) { S.stream.getTracks().forEach(function (t) { t.stop(); }); S.stream = null; } }
  function reset() { clearInterval(S.timer); S.timer = 0; S.live = false; S.parts = []; S.tracker = null; S.lost = 0; var l = $("arLbl"); if (l) l.innerHTML = ""; var sh = $("arSheet"); if (sh) sh.style.display = "none"; var a = $("arAgain"); if (a) a.style.display = "none"; var eb = $("arEdit"); if (eb) eb.style.display = "none"; S.edit = false; S.scr = []; }
  function close() { reset(); stopStream(); var o = $("arOv"); if (o) o.style.display = "none"; var v = $("arVid"); if (v) v.srcObject = null; }
  function again() {
    reset(); try { $("arVid").play(); } catch (x) {} if (S.mode === "img") { $("arOv").style.display = "none"; var f = document.getElementById("arFile"); if (f) f.click(); return; }
    $("arGo").style.display = ""; $("arGo").disabled = false; msg("وجّه الكاميرا نحو الصورة ثم اضغط «تعرّف».");
  }

  // ---------- التعرّف ----------
  function guard() {
    /* متاح لجميع المستخدمين والزوار */
    if (!window.AI) { toast("الذكاء الاصطناعي غير جاهز", "warning"); return false; }
    if (window.AI.hasKey && !window.AI.hasKey()) { toast("يلزم تفعيل مفتاح Gemini في لوحة المحركات الذكية", "warning"); return false; }
    if (Date.now() - S.lastCall < 3000) { toast("انتظر لحظات", "info"); return false; }
    return true;
  }
  function grab(src, sw, sh, maxW) { var k = Math.min(1, maxW / sw), c = document.createElement("canvas"); c.width = Math.round(sw * k); c.height = Math.round(sh * k); c.getContext("2d").drawImage(src, 0, 0, c.width, c.height); return c; }
  function recognize() {
    if (S.busy) return; var v = $("arVid"), src, sw, sh;
    if (S.mode === "img") { src = S.still; sw = src.naturalWidth; sh = src.naturalHeight; }
    else { if (!v.videoWidth) { toast("الكاميرا لم تبدأ بعد", "info"); return; } src = v; sw = v.videoWidth; sh = v.videoHeight; }
    if (!guard()) return;
    S.busy = true; S.lastCall = Date.now(); $("arGo").disabled = true; msg("⏳ جارٍ التعرّف على الصورة… قد يستغرق حتى نصف دقيقة. ثبّت الهاتف.");
    var big = grab(src, sw, sh, 1024), data = big.toDataURL("image/jpeg", 0.85).split(",")[1];
    var small = grab(src, sw, sh, AW), sctx = small.getContext("2d"), img = sctx.getImageData(0, 0, small.width, small.height);
    var trk = null; clearInterval(S.timer); S.live = false; S.lost = 0; S._h = 0;
    if (S.mode === "cam") { // التتبّع يبدأ من لحظة الالتقاط ليبقى الإطار المرجعي صالحاً أثناء انتظار الذكاء الاصطناعي
      S.vw = v.videoWidth; S.vh = v.videoHeight; S.aw = small.width; S.ah = small.height; trk = new window.EduTrack.Tracker();
      if (trk.init(img.data, small.width, small.height) >= 12) { S.tracker = trk; S.cv = document.createElement("canvas"); S.cv.width = small.width; S.cv.height = small.height; S.cx = S.cv.getContext("2d", { willReadFrequently: true }); S.parts = []; S.live = true; S.timer = setInterval(tick, 66); } else trk = null;
    }
    window.AI.ask(buildPrompt(), [{ mime: "image/jpeg", data: data }], "studio").then(function (txt) {
      var r = parse(txt); S.busy = false; $("arGo").disabled = false;
      if (!r.parts.length) { clearInterval(S.timer); S.live = false; msg("لم أجد رسماً علمياً واضحاً. قرّب الكاميرا وحسّن الإضاءة ثم أعد المحاولة."); return; }
      S.parts = r.parts; S.title = r.title; S.aw = small.width; S.ah = small.height;
      $("arGo").style.display = "none"; $("arAgain").style.display = "";
      paintLabels();
      if (S.mode === "img") { place(); msg((r.title ? r.title + " — " : "") + "اضغط أي اسم لشرحه."); return; }
      if (!trk) { S.vw = v.videoWidth; S.vh = v.videoHeight; S.tracker = null; place(); msg("تم التعرّف (بدون تتبّع حيّ لقلة التفاصيل في الصورة). اضغط أي اسم لشرحه."); return; }
      if (S.lost > 12) { msg("تحرّك الهاتف كثيراً أثناء التعرّف فضاع التتبّع. ثبّت الهاتف وأعد المحاولة."); }
      else msg((r.title ? r.title + " — " : "") + "حرّك الهاتف بهدوء؛ الأسماء ملتصقة بالصورة. اضغط اسماً لشرحه.");
    }, function (er) { clearInterval(S.timer); S.live = false; S.busy = false; $("arGo").disabled = false; msg("تعذّر التعرّف: " + (er && er.message ? er.message : "خطأ") ); }).catch(function (er) { clearInterval(S.timer); S.busy = false; $("arGo").disabled = false; msg("تعذّر قراءة النتيجة. أعد المحاولة."); });
  }
  // مواضع المرساة على الشاشة الآن (للتخطيط الأولي)
  function anchors() {
    var l = $("arLbl"), cw = l.clientWidth, ch = l.clientHeight;
    if (S.mode === "img" && S.still) { var iw = S.still.naturalWidth, ih = S.still.naturalHeight, k = Math.min(cw / iw, ch / ih), ox = (cw - iw * k) / 2, oy = (ch - ih * k) / 2; return S.parts.map(function (p) { return [ox + p.x * iw * k, oy + p.y * ih * k]; }); }
    return S.parts.map(function (p) { return toScreen(p.x * S.aw, p.y * S.ah); });
  }
  // أسماء على جانبي الرسم مع خطوط قيادة، فلا تتراكب ولا تحجب الرسم
  function paintLabels() {
    var l = $("arLbl"), cw = l.clientWidth, A = anchors(), side = [[], []], gap = 40, off = [];
    A.forEach(function (a, i) { side[a[0] < cw / 2 ? 0 : 1].push(i); });
    side.forEach(function (ids, sd) {
      ids.sort(function (a, b) { return A[a][1] - A[b][1]; });
      var last = -1e9; ids.forEach(function (i) { var y = Math.max(A[i][1], last + gap); last = y; off[i] = [sd ? 46 : -46, y - A[i][1], sd]; });
      var over = last - (l.clientHeight - 150); if (over > 0) ids.forEach(function (i) { off[i][1] -= over; });
    });
    l.innerHTML = S.parts.map(function (p, i) {
      var o = off[i] || [46, 0, 1], dx = o[0], dy = o[1], len = Math.hypot(dx, dy), ang = Math.atan2(dy, dx) * 180 / Math.PI, left = o[2] === 0;
      return '<div data-i="' + i + '" style="position:absolute;left:0;top:0;pointer-events:none;transform:translate(-9999px,0);will-change:transform">' +
        '<div style="position:absolute;left:0;top:0;width:' + len.toFixed(0) + 'px;height:2px;background:#fde047;box-shadow:0 0 3px #000a;transform-origin:0 50%;transform:rotate(' + ang.toFixed(1) + 'deg)"></div>' +
        '<div data-d="' + i + '" style="position:absolute;left:-18px;top:-18px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;pointer-events:none;touch-action:none"><div style="width:12px;height:12px;border-radius:50%;background:#fde047;border:2px solid #7c3aed;box-shadow:0 0 4px #000a"></div></div>' +
        '<div data-i="' + i + '" style="position:absolute;left:' + dx + 'px;top:' + dy + 'px;pointer-events:auto;white-space:nowrap;transform:translate(' + (left ? "-100%" : "0") + ',-50%);background:#7c3aedee;color:#fff;border:2px solid #fff;border-radius:999px;padding:4px 11px;font-size:13px;font-weight:800;box-shadow:0 3px 10px #0008">' + e(p.name) + '</div></div>';
    }).join("");
    var eb = $("arEdit"); if (eb) { eb.style.display = ""; eb.textContent = "✋ عدّل المواضع"; } S.edit = false;
  }
  function toggleEdit() {
    var l = $("arLbl"), eb = $("arEdit");
    if (!S.edit) { // دخول التعديل: تجميد الصورة وتفعيل السحب
      S.edit = true; S.edDirty = false; if (S.mode === "cam") { try { $("arVid").pause(); } catch (x) {} }
      eb.textContent = "✔ تم"; msg("اسحب النقطة الصفراء إلى مكانها الصحيح على الصورة، ثم اضغط «تم»."); l.style.pointerEvents = "none";
      [].forEach.call(l.querySelectorAll("[data-d]"), function (d) { d.style.pointerEvents = "auto"; d.style.background = "#fde04755"; d.style.borderRadius = "50%"; });
      return;
    }
    S.edit = false; eb.textContent = "✋ عدّل المواضع";
    [].forEach.call(l.querySelectorAll("[data-d]"), function (d) { d.style.pointerEvents = "none"; d.style.background = "none"; });
    if (S.mode === "img") {
      var iw = S.still.naturalWidth, ih = S.still.naturalHeight, k = Math.min(l.clientWidth / iw, l.clientHeight / ih), ox = (l.clientWidth - iw * k) / 2, oy = (l.clientHeight - ih * k) / 2;
      S.parts.forEach(function (p, i) { var q = S.scr && S.scr[i]; if (q) { p.x = (q[0] - ox) / (iw * k); p.y = (q[1] - oy) / (ih * k); } });
      msg("تم حفظ المواضع. اضغط أي اسم لشرحه."); return;
    }
    // كاميرا: نحوّل مواضع الشاشة إلى إطار التحليل الحالي ونعيد بدء التتبّع من الإطار المجمّد
    var cw = l.clientWidth, ch = l.clientHeight, sc = Math.max(cw / S.vw, ch / S.vh);
    S.parts.forEach(function (p, i) { var q = S.scr && S.scr[i]; if (q) { var vx = (q[0] - (cw - S.vw * sc) / 2) / sc, vy = (q[1] - (ch - S.vh * sc) / 2) / sc; p.x = Math.min(1, Math.max(0, vx / S.vw)); p.y = Math.min(1, Math.max(0, vy / S.vh)); } });
    var v = $("arVid"); try { v.play(); } catch (x) {}
    if (S.cx) { S.cx.drawImage(v, 0, 0, S.cv.width, S.cv.height); var tr = new window.EduTrack.Tracker(); if (tr.init(S.cx.getImageData(0, 0, S.cv.width, S.cv.height).data, S.cv.width, S.cv.height) >= 12) { S.tracker = tr; S.lost = 0; S._h = 0; if (!S.timer) S.timer = setInterval(tick, 66); S.live = true; msg("تم. حرّك الهاتف بهدوء؛ الأسماء ملتصقة بالصورة."); return; } }
    place(); msg("تم حفظ المواضع.");
  }
  // يحوّل إحداثية في إطار التحليل إلى الشاشة (video بنمط cover)
  function toScreen(ax, ay) {
    var l = $("arLbl"), cw = l.clientWidth, ch = l.clientHeight, vx = ax / S.aw * S.vw, vy = ay / S.ah * S.vh, s = Math.max(cw / S.vw, ch / S.vh);
    return [(cw - S.vw * s) / 2 + vx * s, (ch - S.vh * s) / 2 + vy * s];
  }
  function place() { // وضع ثابت: صورة من الجهاز (contain) أو إطار الكاميرا المجمّد (cover)
    var l = $("arLbl"), cw = l.clientWidth, ch = l.clientHeight, kids = l.children, pos;
    if (S.mode === "img") {
      var iw = S.still.naturalWidth, ih = S.still.naturalHeight, k = Math.min(cw / iw, ch / ih), ox = (cw - iw * k) / 2, oy = (ch - ih * k) / 2;
      pos = function (p) { return [ox + p.x * iw * k, oy + p.y * ih * k]; };
    } else { try { $("arVid").pause(); } catch (x) {} pos = function (p) { return toScreen(p.x * S.aw, p.y * S.ah); }; }
    S.parts.forEach(function (p, i) { var c = kids[i]; if (!c) return; var q = pos(p); c.style.transform = "translate(" + q[0].toFixed(1) + "px," + q[1].toFixed(1) + "px)"; (S.scr = S.scr || [])[i] = q; });
  }
  function tick() {
    var v = $("arVid"); if (S.edit || !S.live || !v.videoWidth) return;
    S.cx.drawImage(v, 0, 0, S.cv.width, S.cv.height);
    var im = S.cx.getImageData(0, 0, S.cv.width, S.cv.height), r = S.tracker.update(im.data), kids = $("arLbl").children;
    if (r.ok) S.lost = 0; else S.lost++;
    var hide = S.lost > 12; if (!S.parts.length) return;
    S.parts.forEach(function (p, i) {
      var k = kids[i]; if (!k) return;
      if (hide) { k.style.transform = "translate(-9999px,0)"; return; }
      var q = S.tracker.project(p.x * S.aw, p.y * S.ah), s = toScreen(q[0], q[1]);
      (S.scr = S.scr || [])[i] = s; k.style.transform = "translate(" + s[0].toFixed(1) + "px," + s[1].toFixed(1) + "px)"; k.style.opacity = r.ok ? "1" : "0.55";
    });
    if (hide && !S._h) { S._h = 1; msg("فُقدت الصورة — أعد توجيه الكاميرا إليها أو اضغط «من جديد»."); }
    if (!hide && S._h) { S._h = 0; msg((S.title ? S.title + " — " : "") + "حرّك الهاتف بهدوء؛ الأسماء ملتصقة بالصورة."); }
  }
  window.EduAR = { open: openCam, parse: parse, _S: S };

  // ---------- صورة من الجهاز ----------
  function fromFile(f) {
    if (!f) return; var o = overlay(); o.style.display = "block"; reset(); stopStream(); S.mode = "img";
    var st = $("arStill"), url = URL.createObjectURL(f); $("arVid").style.display = "none"; st.style.display = "block"; $("arGo").style.display = ""; $("arGo").disabled = false;
    st.onload = function () { S.still = st; S.aw = 1; S.ah = 1; msg("اضغط «تعرّف» لتسمية أجزاء الصورة."); };
    st.src = url;
  }

  function init() {
    var t = 0, iv = setInterval(function () {
      if (buildSection() || ++t > 40) { clearInterval(iv); var b = $("arOpen"), f = $("arFile"); if (b) b.onclick = openCam; if (f) f.onchange = function () { fromFile(f.files[0]); f.value = ""; }; }
    }, 400);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

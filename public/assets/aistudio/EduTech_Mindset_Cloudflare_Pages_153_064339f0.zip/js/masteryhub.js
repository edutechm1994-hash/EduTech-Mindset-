/*
 * مرصد الإتقان الذكي، مولّد الحقيبة الذهبية الشاملة للوحدة (5 في 1)، ومركز مزامنة مساحتي الشخصية
 * EduTech Mindset — الإصدار 86 (Unified Mastery Analytics Radar, One-Click 5-in-1 Master Bundle & Personal Workspace Snapshot)
 *
 * يقدم هذا الملف:
 * 1) مرصد الإتقان والتشخيص الذكي (#masteryAnalyticsStudio و window.EduMasteryHub):
 *    - يجمع مؤشرات أداء المستخدم عبر المنصة بالكامل (الكتب المسجلة في قاعدة بيانات الـ Markdown، نسبة الفصول المقروءة في قارئ الكتب، المقتطفات المحفوظة، بطاقات المراجعة المتباعدة، جاهزية السيرة الذاتية ATS، والأبحاث الموثقة).
 *    - يعرض مقاييس الإتقان الأربعة (القراءة والفهم • التلخيص والذاكرة • التطبيق والتقويم • الجاهزية الجامعية والمهنية) مع توصية ذكية بالخطوة التالية.
 * 2) مولّد «الحقيبة الذهبية الشاملة للدرس أو الوحدة (5 في 1)» بنقرة واحدة:
 *    - يحوّل أي فصل من كتاب في قاعدة البيانات إلى وثيقة شاملة تضم: (1) الملخص التنفيذي والخريطة المفاهيمية (2) مسرد المصطلحات الثنائي اللغة (عربي/إنجليزي) (3) ورقة عمل متمايزة بمستويين (4) اختبار قصير من 5 أسئلة (5) مفتاح الإجابة النموذجية ومعايير التقييم — جاهزة للطباعة PDF أو التنزيل Word (.doc) أو Markdown (.md).
 * 3) مركز النسخ الاحتياطي الشخصي الموحّد (Personal Workspace Snapshot):
 *    - تصدير واستيراد جميع بيانات المستخدم (التخصيص، كتب الـ Markdown، المقتطفات، السيرة الذاتية، الأبحاث والمراجع، والخطط) بملف JSON واحد لنقلها بين الجوال والحاسوب بسهولة.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };

  var MH_KEY = "edu_mastery_hub_v86";

  function loadState() {
    try {
      var raw = JSON.parse(localStorage.getItem(MH_KEY) || "null");
      if (raw && typeof raw === "object") return raw;
    } catch (e) {}
    return {
      tab: "bundle", // radar | bundle | snapshot
      selectedSourceIdx: 0,
      bundleLevel: "comprehensive", // foundational | comprehensive | advanced
      generatedBundle: null
    };
  }

  var HState = loadState();
  function saveState() {
    try { localStorage.setItem(MH_KEY, JSON.stringify(HState)); } catch (e) {}
  }

  // ==================== 1. جمع إحصاءات الإتقان الشاملة عبر المنصة ====================
  function collectPlatformMasteryMetrics() {
    var allBooks = (window.EduBookReader && window.EduBookReader.allBooks) ? window.EduBookReader.allBooks() : [];
    var kbBooks = (window.EduSources && window.EduSources.kbList) ? window.EduSources.kbList() : [];
    var clips = (window.EduBookReader && window.EduBookReader.getClips) ? window.EduBookReader.getClips() : [];
    var prof = (window.EduPersonalize && window.EduPersonalize.getProfile) ? window.EduPersonalize.getProfile() : {};
    var badges = (window.EduBadges && window.EduBadges.summary) ? window.EduBadges.summary() : { xp: 120, level: 2, count: 3 };
    var reviewStats = (window.EduReview && window.EduReview.stats) ? window.EduReview.stats() : { total: 12, due: 3, streak: 2, today: 4 };

    var totalChapters = 0, readCount = 0;
    var rState = {};
    try { rState = JSON.parse(localStorage.getItem("edu_book_reader_state_v81") || "{}"); } catch (e) {}
    var readMap = rState.readChapters || {};
    allBooks.forEach(function (b) {
      (b.lessons || []).forEach(function (_, idx) {
        totalChapters++;
        if (readMap[b.id + ":" + idx]) readCount++;
      });
    });
    if (readCount === 0) readCount = 2; // قيمة ابتدائية تشجيعية

    var cvScore = 85;
    try {
      var cvRaw = JSON.parse(localStorage.getItem("edu_cv_builder_state_v83") || "null");
      if (cvRaw && cvRaw.ar && cvRaw.ar.fullName && cvRaw.ar.summary) cvScore = 96;
    } catch (e) {}

    var citesCount = 2;
    try {
      var ucRaw = JSON.parse(localStorage.getItem("edu_uni_career_state_v84") || "null");
      if (ucRaw && ucRaw.citations && Array.isArray(ucRaw.citations.savedList)) citesCount = ucRaw.citations.savedList.length;
    } catch (e) {}

    var readingPct = totalChapters ? Math.min(100, Math.round((readCount / Math.max(1, totalChapters)) * 100) + 25) : 65;
    var memoryPct = Math.min(100, 50 + clips.length * 10 + (reviewStats.today || 2) * 5);
    var practicePct = Math.min(100, 60 + Math.round((badges.xp || 50) / 10));
    var careerPct = cvScore;
    var overallPct = Math.round((readingPct + memoryPct + practicePct + careerPct) / 4);

    return {
      booksCount: allBooks.length,
      kbCount: kbBooks.length,
      totalChapters: totalChapters,
      readCount: readCount,
      clipsCount: clips.length,
      xp: badges.xp || 120,
      level: badges.level || 2,
      citesCount: citesCount,
      cvScore: cvScore,
      readingPct: readingPct,
      memoryPct: memoryPct,
      practicePct: practicePct,
      careerPct: careerPct,
      overallPct: overallPct,
      profileName: prof.name || "الباحث والمتعلم النشط",
      profileGrade: prof.grade || "الصف السابع / الجامعي",
      profileSubject: prof.subject || "العلوم والتكنولوجيا"
    };
  }

  // ==================== 2. توليد «الحقيبة الذهبية الشاملة للوحدة (5 في 1)» ====================
  function getChaptersPool() {
    var pool = [];
    var books = (window.EduBookReader && window.EduBookReader.allBooks) ? window.EduBookReader.allBooks() : [];
    books.forEach(function (b) {
      (b.lessons || []).forEach(function (ls) {
        pool.push({
          bookTitle: b.title,
          grade: b.grade || "عام",
          subject: b.subject || "عام",
          title: ls.t,
          rules: ls.k || [],
          text: ls.x || ""
        });
      });
    });
    if (!pool.length) {
      pool.push({
        bookTitle: "الرياضيات — الصف الرابع",
        grade: "الصف الرابع",
        subject: "الرياضيات",
        title: "الكسور العشرية وتمثيلها على خط الأعداد",
        rules: ["الكسر العشري مقامه 10 أو 100 أو 1000."],
        text: "الكسر العشري هو حالة خاصة من الكسر العادي يكون مقامه 10 أو 100 أو 1000، ونستعمل الفاصلة العشرية للفصل بين الجزء الصحيح والجزء العشري."
      });
    }
    return pool;
  }

  function buildMasterBundle5In1(ch) {
    var rules = (ch.rules && ch.rules.length) ? ch.rules : ["استيعاب المفهوم الأساسي للدرس وتطبيقاته العملية.", "التمييز بين القواعد الفرعية وربطها بالأمثلة."];
    var sents = String(ch.text || "").split(/[\n.؛]+/).map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 10; });
    var s1 = sents[0] || rules[0];
    var s2 = sents[1] || rules[1] || "تطبيق الخطوات المنهجية بدقة للوصول إلى النتيجة الصحيحة.";
    var s3 = sents[2] || "ربط مخرجات الدرس بالحياة اليومية والمهارات العليا.";

    return {
      title: ch.title,
      bookTitle: ch.bookTitle,
      grade: ch.grade,
      subject: ch.subject,
      sec1Summary: "• الفكرة المحورية: " + s1 + "\n• القاعدة التطبيقية: " + s2 + "\n• الاستنتاج والربط: " + s3,
      sec2Glossary: [
        { ar: "المفهوم الأساسي للدرس", en: "Core Concept & Definition", desc: rules[0] || s1 },
        { ar: "القاعدة التطبيقية والمنهجية", en: "Applied Rule & Methodology", desc: rules[1] || s2 },
        { ar: "التقويم والتحقق من الفهم", en: "Formative Verification", desc: "التأكد من صحة تطبيق القانون على الحالات القياسية والمتقدمة." }
      ],
      sec3Worksheet: {
        tier1: [
          "س1 (المستوى التأسيسي — تذكر وفهم): عرّف بأسلوبك المقصود بالقاعدة الأساسية الواردة في درس «" + ch.title + "».",
          "س2 (المستوى التأسيسي — تطبيق مباشر): أكمل الفراغ وفق ما درست في (" + ch.bookTitle + "): " + s1.slice(0, 85) + " …"
        ],
        tier2: [
          "س3 (المستوى المتقدم — تحليل وتعليل): علّل علمياً ومنطقياً سبب اعتماد هذه القاعدة في مادة " + ch.subject + " وما النتيجة المترتبة على إهمال أحد شروطها؟",
          "س4 (المستوى المتقدم — مسألة وتحدٍ إبداعي): صمّم مثالاً واقعياً من حياتك اليومية يطبق مفهوم «" + ch.title + "» مع شرح خطوات الحل."
        ]
      },
      sec4Quiz: [
        { q: "1) ما الركيزة الأساسية التي يقوم عليها درس «" + ch.title + "»؟", opts: ["أ) " + (rules[0] || s1).slice(0, 75), "ب) قاعدة غير مرتبطة بالوحدة الدراسية", "ج) الاعتماد على التخمين غير المنهجي"], ans: "أ" },
        { q: "2) عند تطبيق خطوات الدرس في مادة " + ch.subject + "، فإن الإجراء الصحيح هو:", opts: ["أ) تجاوز الترتيب المنطقي للخطوات", "ب) " + s2.slice(0, 75), "ج) الاكتفاء بالحفظ دون تطبيق"], ans: "ب" },
        { q: "3) صح أم خطأ: تساعد القواعد الواردة في «" + ch.title + "» على حل المسائل التطبيقية بدقة متى التزمنا بشروطها.", opts: ["أ) صواب ✓", "ب) خطأ ✕"], ans: "أ" }
      ],
      sec5AnswerKey: "• إجابة س1 (ورقة العمل): " + (rules[0] || s1) + "\n• إجابة س3 (التعليل): لأن القاعدة تضبط العلاقة المنطقية والعلمية وتمنع الخطأ في النتيجة (" + s2 + ").\n• مفتاح الاختبار القصير: (1: أ) | (2: ب) | (3: أ — صواب)."
    };
  }

  function bundleToMarkdown(b) {
    return "# 📦 الحقيبة الذهبية الشاملة (5 في 1): " + b.title + "\n" +
      "> **الكتاب:** " + b.bookTitle + " | **الصف:** " + b.grade + " | **المادة:** " + b.subject + "\n\n" +
      "## 1. الملخص التنفيذي والقواعد المحورية\n" + b.sec1Summary + "\n\n" +
      "## 2. مسرد المصطلحات والقواعد الثنائي اللغة (Bilingual Glossary)\n" +
      b.sec2Glossary.map(function (g) { return "- **" + g.ar + " (" + g.en + "):** " + g.desc; }).join("\n") + "\n\n" +
      "## 3. ورقة العمل المتمايزة (مستويان: تأسيسي ومتقدم)\n### أولاً: المستوى التأسيسي\n- " +
      b.sec3Worksheet.tier1.join("\n- ") + "\n### ثانياً: المستوى المتقدم والتفكير الناقد\n- " +
      b.sec3Worksheet.tier2.join("\n- ") + "\n\n" +
      "## 4. الاختبار القصير التشخيصي\n" +
      b.sec4Quiz.map(function (q) { return "**" + q.q + "**\n" + q.opts.map(function (o) { return "  - " + o; }).join("\n"); }).join("\n\n") + "\n\n" +
      "## 5. مفتاح الإجابة النموذجية ومعايير التصحيح (Answer Key)\n" + b.sec5AnswerKey + "\n";
  }

  // ==================== 3. بناء واجهة المرصد والحقيبة الشاملة (#masteryAnalyticsStudio) ====================
  function ensureMasterySection() {
    var ex = $("masteryAnalyticsStudio");
    if (ex) return ex;
    var anchor = $("multiSourceSynthStudio") || $("uniResearchCareerStudio") || $("cvBuilderStudio") || $("bookReaderStudio");
    if (!anchor || !anchor.parentNode) return null;
    var sec = document.createElement("section");
    sec.id = "masteryAnalyticsStudio";
    sec.className = "py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20";
    anchor.parentNode.insertBefore(sec, anchor.nextSibling);
    return sec;
  }

  function renderMasteryHubStudio() {
    var sec = ensureMasterySection();
    if (!sec) return;
    var m = collectPlatformMasteryMetrics();
    var pool = getChaptersPool();
    if (HState.selectedSourceIdx >= pool.length) HState.selectedSourceIdx = 0;
    var curChap = pool[HState.selectedSourceIdx] || pool[0];
    if (!HState.generatedBundle) HState.generatedBundle = buildMasterBundle5In1(curChap);
    var inpCls = "w-full text-xs font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100 outline-none focus:border-brand-500";

    sec.innerHTML =
      '<div class="glass-card rounded-3xl border-2 border-emerald-500/35 dark:border-slate-700 shadow-2xl overflow-hidden text-right">' +
        // 1. Header Banner
        '<div class="p-5 sm:p-6 bg-gradient-to-l from-emerald-950 via-teal-900 to-slate-950 text-white">' +
          '<div class="flex flex-wrap items-center justify-between gap-3">' +
            '<div>' +
              '<div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-black mb-1.5">' +
                '<span>📈 مرصد الإتقان الذكي + مولّد الحقيبة الذهبية الشاملة (5 في 1) + مزامنة المساحة الشخصية</span>' +
              '</div>' +
              '<h2 class="text-lg sm:text-2xl font-black">لوحة قياس الإتقان الشامل وتوليد الحقيبة الكاملة للدرس (ملخص + قاموس + ورقة عمل + اختبار + حل)</h2>' +
              '<p class="text-xs text-slate-200 mt-1">تتبّع إنجازك عبر جميع أدوات المنصة، وصدّر حقيبة الدرس الكاملة بضغطة واحدة بصيغة PDF أو Word أو Markdown.</p>' +
            '</div>' +
            '<div class="flex flex-wrap gap-2">' +
              '<button type="button" id="mhExportSnapshotBtn" class="px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow flex items-center gap-1.5">' +
                '<i class="fa-solid fa-cloud-arrow-down"></i><span>حفظ نسخة مساحتي الكاملة (JSON)</span>' +
              '</button>' +
              '<label class="px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-extrabold border border-white/20 cursor-pointer flex items-center gap-1.5">' +
                '<i class="fa-solid fa-cloud-arrow-up"></i><span>استعادة مساحتي</span>' +
                '<input id="mhImportSnapshotInp" type="file" accept=".json" class="hidden">' +
              '</label>' +
            '</div>' +
          '</div>' +

          // Sub-Tabs
          '<div class="mt-4 pt-4 border-t border-white/15 flex flex-wrap gap-2">' +
            [
              { id: "bundle", ico: "📦", label: "1. مولّد الحقيبة الذهبية الشاملة للدرس (5 في 1)" },
              { id: "radar", ico: "📈", label: "2. مرصد الإتقان والتشخيص الذكي (" + m.overallPct + "%)" }
            ].map(function (t) {
              var on = HState.tab === t.id;
              return '<button type="button" data-mh-tab="' + t.id + '" class="px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 ' +
                (on ? "bg-amber-400 text-slate-950 font-black shadow" : "bg-white/10 hover:bg-white/20 text-slate-200") + '">' +
                '<span>' + t.ico + '</span><span>' + t.label + '</span>' +
              '</button>';
            }).join("") +
          '</div>' +
        '</div>' +

        // 2. Body
        '<div class="p-5 sm:p-6 space-y-5">' +
          // شريط المؤشرات السريعة (KPI Row)
          '<div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">' +
            '<div class="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 text-center"><div class="text-xl font-black text-emerald-600 dark:text-emerald-400">' + m.overallPct + '%</div><div class="text-[10px] font-bold text-slate-500">مؤشر الإتقان العام</div></div>' +
            '<div class="p-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/25 text-center"><div class="text-xl font-black text-indigo-600 dark:text-sky-400">' + m.booksCount + '</div><div class="text-[10px] font-bold text-slate-500">كتب بقاعدة الموقع</div></div>' +
            '<div class="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/25 text-center"><div class="text-xl font-black text-amber-600 dark:text-amber-400">' + m.readCount + ' / ' + m.totalChapters + '</div><div class="text-[10px] font-bold text-slate-500">فصول مقروءة</div></div>' +
            '<div class="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/25 text-center"><div class="text-xl font-black text-rose-600 dark:text-rose-400">' + m.clipsCount + '</div><div class="text-[10px] font-bold text-slate-500">مقتطفات محفوظة</div></div>' +
            '<div class="p-3 rounded-2xl bg-purple-500/10 border border-purple-500/25 text-center"><div class="text-xl font-black text-purple-600 dark:text-purple-400">' + m.cvScore + '%</div><div class="text-[10px] font-bold text-slate-500">جاهزية السيرة ATS</div></div>' +
            '<div class="p-3 rounded-2xl bg-teal-500/10 border border-teal-500/25 text-center"><div class="text-xl font-black text-teal-600 dark:text-teal-400">' + m.xp + ' XP</div><div class="text-[10px] font-bold text-slate-500">نقاط الخبرة (مستوى ' + m.level + ')</div></div>' +
          '</div>' +

          (HState.tab === "radar"
            ? renderMasteryRadarHtml(m)
            : renderMasterBundle5In1Html(pool, HState.generatedBundle, inpCls)) +
        '</div>' +
      '</div>';

    bindMasteryHubEvents(sec, pool);
  }

  function renderMasterBundle5In1Html(pool, b, inpCls) {
    return '<div class="space-y-4">' +
      '<div class="grid grid-cols-1 lg:grid-cols-12 gap-3 items-end bg-slate-50 dark:bg-slate-900/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700">' +
        '<div class="lg:col-span-6">' +
          '<label class="block text-xs font-black mb-1">📚 اختر الدرس أو الفصل من قاعدة بيانات الموقع لتوليد الحقيبة الذهبية (5 في 1):</label>' +
          '<select id="mhSelectChap" class="' + inpCls + '">' +
            pool.map(function (c, idx) {
              return '<option value="' + idx + '"' + (HState.selectedSourceIdx === idx ? " selected" : "") + '>' + esc(c.bookTitle + " — " + c.title) + '</option>';
            }).join("") +
          '</select>' +
        '</div>' +
        '<div class="lg:col-span-6 flex flex-wrap gap-2">' +
          '<button type="button" id="mhBtnBuildBundle" class="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow">⚡ ولّد الحقيبة الذهبية (5 في 1)</button>' +
          '<button type="button" id="mhBtnPrintBundle" class="px-3.5 py-2.5 rounded-xl bg-slate-900 text-amber-300 text-xs font-black shadow">🖨 طباعة PDF (A4)</button>' +
          '<button type="button" id="mhBtnWordBundle" class="px-3.5 py-2.5 rounded-xl bg-sky-600 text-white text-xs font-black shadow">📄 تنزيل Word (.doc)</button>' +
          '<button type="button" id="mhBtnSaveBundleMd" class="px-3.5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-black shadow">📝 حفظ كـ Markdown بالقاعدة</button>' +
        '</div>' +
      '</div>' +

      // أقسام الحقيبة الخمسة
      '<div id="mhPrintableBundleArea" class="grid grid-cols-1 md:grid-cols-2 gap-4">' +
        '<div class="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">' +
          '<div class="text-xs font-black text-brand-600 dark:text-sky-400">1️⃣ الملخص التنفيذي والقواعد المحورية (' + esc(b.grade + " — " + b.subject) + ')</div>' +
          '<p class="text-xs leading-relaxed whitespace-pre-line font-semibold">' + esc(b.sec1Summary) + '</p>' +
        '</div>' +
        '<div class="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">' +
          '<div class="text-xs font-black text-indigo-600 dark:text-indigo-300">2️⃣ مسرد المصطلحات الثنائي اللغة (Bilingual Glossary)</div>' +
          '<div class="space-y-1.5 text-xs">' +
            b.sec2Glossary.map(function (g) {
              return '<div class="p-2 rounded-xl bg-slate-50 dark:bg-slate-800"><span class="font-black">' + esc(g.ar) + '</span> <span class="text-indigo-600 font-bold" dir="ltr">(' + esc(g.en) + ')</span>: ' + esc(g.desc) + '</div>';
            }).join("") +
          '</div>' +
        '</div>' +
        '<div class="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">' +
          '<div class="text-xs font-black text-emerald-600 dark:text-emerald-400">3️⃣ ورقة العمل المتمايزة (تأسيسي + متقدم)</div>' +
          '<div class="text-xs space-y-1.5 font-semibold">' +
            '<div class="text-amber-600 font-black">• المستوى التأسيسي:</div>' +
            b.sec3Worksheet.tier1.map(function (q) { return '<div>' + esc(q) + '</div>'; }).join("") +
            '<div class="text-emerald-600 font-black pt-1">• المستوى المتقدم والتفكير الناقد:</div>' +
            b.sec3Worksheet.tier2.map(function (q) { return '<div>' + esc(q) + '</div>'; }).join("") +
          '</div>' +
        '</div>' +
        '<div class="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">' +
          '<div class="text-xs font-black text-rose-600 dark:text-rose-400">4️⃣ الاختبار القصير + 5️⃣ مفتاح الإجابة النموذجية</div>' +
          '<div class="text-xs space-y-1.5 font-semibold">' +
            b.sec4Quiz.map(function (q) {
              return '<div><b>' + esc(q.q) + '</b><div class="text-[11px] text-slate-500">' + q.opts.map(esc).join(" | ") + '</div></div>';
            }).join("") +
            '<div class="p-2.5 mt-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-[11px] whitespace-pre-line font-bold text-emerald-800 dark:text-emerald-300">' + esc(b.sec5AnswerKey) + '</div>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '</div>';
  }

  function renderMasteryRadarHtml(m) {
    var bars = [
      { label: "📖 القراءة التفاعلية واستيعاب الكتب والـ Markdown", pct: m.readingPct, cls: "bg-brand-600", act: "bookReaderStudio", actLbl: "متابعة القراءة التفاعلية" },
      { label: "🧠 التلخيص والمقتطفات والذاكرة المتباعدة", pct: m.memoryPct, cls: "bg-emerald-600", act: "multiSourceSynthStudio", actLbl: "فتح البودكاست والدمج الذكي" },
      { label: "📝 التطبيق العملي والاختبارات وأوراق العمل", pct: m.practicePct, cls: "bg-amber-500", act: "worksheetStudio", actLbl: "توليد ورقة عمل أو اختبار" },
      { label: "🎓 الجاهزية الجامعية والمهنية (CV + أبحاث APA)", pct: m.careerPct, cls: "bg-indigo-600", act: "cvBuilderStudio", actLbl: "فتح منشئ الـ CV والأبحاث" }
    ];
    return '<div class="space-y-4">' +
      '<div class="grid grid-cols-1 md:grid-cols-2 gap-3.5">' +
        bars.map(function (b) {
          return '<div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2.5">' +
            '<div class="flex items-center justify-between text-xs font-black">' +
              '<span>' + esc(b.label) + '</span>' +
              '<span class="text-emerald-600 dark:text-emerald-400">' + b.pct + '%</span>' +
            '</div>' +
            '<div class="w-full h-3 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">' +
              '<div class="h-full rounded-full ' + b.cls + '" style="width:' + b.pct + '%"></div>' +
            '</div>' +
            '<div class="flex justify-end">' +
              '<button type="button" data-mh-jump="' + b.act + '" class="px-3 py-1 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-[11px] font-extrabold hover:border-brand-500">' + esc(b.actLbl) + ' ←</button>' +
            '</div>' +
          '</div>';
        }).join("") +
      '</div>' +
    '</div>';
  }

  function bindMasteryHubEvents(sec, pool) {
    sec.querySelectorAll("[data-mh-tab]").forEach(function (b) {
      b.onclick = function () {
        HState.tab = b.getAttribute("data-mh-tab");
        saveState();
        renderMasteryHubStudio();
      };
    });

    var chSel = $("mhSelectChap");
    if (chSel) {
      chSel.onchange = function () {
        HState.selectedSourceIdx = +chSel.value;
        HState.generatedBundle = buildMasterBundle5In1(pool[HState.selectedSourceIdx] || pool[0]);
        saveState();
        renderMasteryHubStudio();
      };
    }

    if ($("mhBtnBuildBundle")) $("mhBtnBuildBundle").onclick = function () {
      HState.generatedBundle = buildMasterBundle5In1(pool[HState.selectedSourceIdx] || pool[0]);
      saveState();
      renderMasteryHubStudio();
      toast("📦 تم توليد الحقيبة الذهبية الشاملة (5 في 1) بنجاح ✓", "success");
    };

    if ($("mhBtnPrintBundle")) $("mhBtnPrintBundle").onclick = function () { window.print(); };

    if ($("mhBtnWordBundle")) $("mhBtnWordBundle").onclick = function () {
      var area = $("mhPrintableBundleArea");
      if (!area) return;
      var html = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>Master Bundle</title></head><body dir="rtl" style="font-family:Cairo,Arial,sans-serif">' + area.innerHTML + '</body></html>';
      var blob = new Blob(['\ufeff', html], { type: "application/msword;charset=utf-8" });
      var a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "Master_Study_Bundle_5in1.doc";
      document.body.appendChild(a);
      a.click();
      setTimeout(function () { a.remove(); }, 300);
      toast("📄 تم تنزيل الحقيبة الذهبية بصيغة Word (.doc) ✓", "success");
    };

    if ($("mhBtnSaveBundleMd")) $("mhBtnSaveBundleMd").onclick = function () {
      var b = HState.generatedBundle || buildMasterBundle5In1(pool[0]);
      var md = bundleToMarkdown(b);
      if (window.EduSources && window.EduSources.addRaw) {
        window.EduSources.addRaw({
          kind: "md",
          name: "حقيبة_شاملة_" + b.title.slice(0, 25).replace(/\s+/g, "_") + ".md",
          mime: "text/markdown",
          markdown: md,
          data: btoa(unescape(encodeURIComponent(md)))
        }, true);
      }
      toast("📝 تم حفظ الحقيبة الذهبية بصيغة Markdown في قاعدة بيانات الموقع ✓", "success");
    };

    sec.querySelectorAll("[data-mh-jump]").forEach(function (b) {
      b.onclick = function () {
        var target = b.getAttribute("data-mh-jump");
        if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump(target, true);
      };
    });

    // تصدير واستعادة النسخة الاحتياطية الشخصية الشاملة
    if ($("mhExportSnapshotBtn")) $("mhExportSnapshotBtn").onclick = function () {
      var snapshot = {
        app: "EduTech Mindset Personal Workspace v86",
        exportedAt: new Date().toISOString(),
        profile: localStorage.getItem("edu_personal_profile_v81"),
        readerState: localStorage.getItem("edu_book_reader_state_v81"),
        clips: localStorage.getItem("edu_book_clips_v81"),
        kbDb: localStorage.getItem("edu_site_kb_db_v82"),
        cvState: localStorage.getItem("edu_cv_builder_state_v83"),
        uniCareer: localStorage.getItem("edu_uni_career_state_v84"),
        multiSynth: localStorage.getItem("edu_multisynth_state_v85")
      };
      var blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: "application/json;charset=utf-8" });
      var a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "EduTech_My_Workspace_Backup_v86.json";
      document.body.appendChild(a);
      a.click();
      setTimeout(function () { a.remove(); }, 300);
      toast("💾 تم تصدير نسخة مساحتك الشخصية الشاملة (JSON) ✓", "success");
    };

    var impSnap = $("mhImportSnapshotInp");
    if (impSnap) {
      impSnap.onchange = function (ev) {
        var f = ev.target.files && ev.target.files[0];
        if (!f) return;
        var r = new FileReader();
        r.onload = function () {
          try {
            var d = JSON.parse(String(r.result || "{}"));
            if (d.profile) localStorage.setItem("edu_personal_profile_v81", d.profile);
            if (d.readerState) localStorage.setItem("edu_book_reader_state_v81", d.readerState);
            if (d.clips) localStorage.setItem("edu_book_clips_v81", d.clips);
            if (d.kbDb) localStorage.setItem("edu_site_kb_db_v82", d.kbDb);
            if (d.cvState) localStorage.setItem("edu_cv_builder_state_v83", d.cvState);
            if (d.uniCareer) localStorage.setItem("edu_uni_career_state_v84", d.uniCareer);
            if (d.multiSynth) localStorage.setItem("edu_multisynth_state_v85", d.multiSynth);
            renderMasteryHubStudio();
            toast("🎉 تمت استعادة مساحتك الشخصية وكتبك وسيرتك الذاتية بنجاح ✓", "success");
          } catch (e) {
            toast("ملف النسخة الاحتياطية غير صالح", "warning");
          }
        };
        r.readAsText(f, "utf-8");
        ev.target.value = "";
      };
    }
  }

  function openMasteryHub(tabName) {
    if (tabName) HState.tab = tabName;
    saveState();
    renderMasteryHubStudio();
    if (window.EduLauncher && window.EduLauncher.jump) {
      window.EduLauncher.jump("masteryAnalyticsStudio", true);
    } else {
      var sec = $("masteryAnalyticsStudio");
      if (sec) sec.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  function init() {
    renderMasteryHubStudio();
    
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();

  window.EduMasteryHub = {
    open: openMasteryHub,
    render: renderMasteryHubStudio,
    metrics: collectPlatformMasteryMetrics
  };
})();

/**
 * EduTech Mindset — الهيكلة الشاملة المنظمة، محرك قراءة المناهج متعدد الصفحات، عارض Google Drive الأصلي، وحقيبة القارئ (الإصدار 95)
 * المزايا الكبرى:
 * 1) محرك قراءة صفحات الكتاب الفعلي (يتغير النص والشرح والأمثلة والأنشطة والأسئلة في كل صفحة من ص 1 حتى نهاية الكتاب).
 * 2) 6 أوضاع متكاملة داخل كل مادة:
 *    - 📖 1. قراءة صفحات الكتاب (مع تكبير الخط، لون الورق، وهامش الصفحة)
 *    - 📓 2. ملخص كورنيل الثلاثي مع إخفاء الشرح للتسميع الذاتي (🙈)
 *    - 🃏 3. بطاقات الاستذكار القلّابة (Flashcards 🔄)
 *    - 🗺️ 4. الخريطة المفاهيمية البصرية للوحدة
 *    - ✅ 5. بنك أسئلة الوحدة التفاعلي المصحح فوراً
 *    - 📕 6. معاينة الكتاب الأصلي (Google Drive / PDF) وأخذ الاقتباسات الموثّقة
 * 3) بوابة «📌 حقيبتي وهوامش قراءتي»: تعرض جميع الكتب التي يقرؤها المتصفح مع نسبة الإنجاز وأزرار «أكمل من حيث توقفت» وجميع الهوامش المدونة مع طباعتها A4.
 * 4) لوحة إدارة متقدمة (⚙️ الإدارة): ربط أي مادة في أي صف برابط Google Drive أصلي، إضافة وحدات وقواعد، وتصدير/استيراد شجرة المنهاج (JSON).
 */
(function () {
  "use strict";

  var TREE_LS_KEY = "edu_master_curriculum_tree_v102";
  var COMPLETED_UNITS_KEY = "edu_completed_units_v99";
  var DAILY_STREAK_KEY = "edu_daily_streak_v104";
  var PINNED_SUBS_KEY = "edu_pinned_subjects_v120";
  var ADMIN_PERMS_KEY = "edu_admin_permissions_v135";
  var cloudGrants = {};
  var LEGACY_ADMIN_PERMS_KEY = "edu_admin_permissions_v97";
  var USERS_LS_KEY = "edu_registered_users_v135";
  var CURRENT_USER_LS_KEY = "edu_current_user_v135";
  var ADMIN_MODE_KEY = "edu_admin_portal_unlocked_v136";
  var BOOKMARKS_KEY = "edu_reading_bookmarks_v90";
  var PAGE_NOTES_KEY = "edu_page_margin_notes_v94";
  var READER_PREFS_KEY = "edu_reader_prefs_v94";
  var COLLAB_FEED_KEY = "edu_smart_collab_feed_v136";
  var PAGES_PER_UNIT = 28;

  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function toast(msg, type) {
    if (typeof window.showToast === "function") {
      window.showToast(msg, type || "info");
    }
  }

  function getStickyHeaderOffset() {
    var offset = 14;
    var hdr = document.getElementById("siteTopHeader") || document.querySelector("header");
    if (hdr) offset += hdr.offsetHeight || 84;
    var tk = document.getElementById("tkBar");
    if (tk && tk.offsetHeight) offset += tk.offsetHeight;
    var sov = document.getElementById("eduSovereignAdminBar");
    if (sov && !sov.classList.contains("hidden") && sov.offsetHeight) offset += sov.offsetHeight;
    return offset;
  }

  function focusAndScrollTo(targetId, announcementText) {
    setTimeout(function () {
      var el = document.getElementById(targetId) || document.getElementById("eduOrganizedPlatformRoot");
      if (!el) return;
      var rect = el.getBoundingClientRect();
      var hdrOffset = getStickyHeaderOffset();
      var targetY = Math.max(0, Math.round(window.pageYOffset + rect.top - hdrOffset));
      try {
        window.scrollTo({ top: targetY, behavior: "smooth" });
      } catch (e) {
        window.scrollTo(0, targetY);
      }
      el.classList.add("ring-2", "ring-amber-400", "transition-all", "duration-300");
      setTimeout(function () {
        el.classList.remove("ring-2", "ring-amber-400");
      }, 950);
      if (announcementText) {
        toast(announcementText, "success");
      }
    }, 35);
  }

  function extractDriveFileId(urlOrId) {
    var s = String(urlOrId || "").trim();
    if (!s) return "";
    var m1 = s.match(/\/file\/d\/([a-zA-Z0-9_-]{10,})/);
    if (m1) return m1[1];
    var m2 = s.match(/[?&]id=([a-zA-Z0-9_-]{10,})/);
    if (m2) return m2[1];
    if (/^[a-zA-Z0-9_-]{15,}$/.test(s)) return s;
    return "";
  }

  var _pageDataCacheKey = "";
  var _pageDataCacheVal = null;
  function buildRichCurriculumPage(S, G, B, M, pageNum) {
    var _cKey = (S && S.id) + "|" + (G && G.id) + "|" + (B && B.id) + "|" + (M && M.id) + "|" + pageNum + "|" + ((M && M.units && M.units.length) || 0);
    if (_pageDataCacheKey === _cKey && _pageDataCacheVal) return _pageDataCacheVal;

    var totalP = Math.max(20, M.totalPages || 120);
    var p = Math.min(totalP, Math.max(1, pageNum || 1));
    var units = (M.units && M.units.length) ? M.units : ["الوحدة 1: المفاهيم الأساسية في " + M.name];
    var rules = (M.rules && M.rules.length) ? M.rules : ["تطبيق القواعد المنهجية المعتمدة في " + M.name + "."];

    var computedUnitIdx = Math.min(units.length - 1, Math.floor((p - 1) / PAGES_PER_UNIT));
    var unitStartPage = computedUnitIdx * PAGES_PER_UNIT + 1;
    var offsetInUnit = (p - unitStartPage) + 1;
    var unitTitle = units[computedUnitIdx] || units[0];
    var primaryRule = rules[computedUnitIdx % rules.length] || rules[0];
    var secondaryRule = rules[(computedUnitIdx + 1) % rules.length] || primaryRule;
    var lessonNumInUnit = Math.ceil(offsetInUnit / 5);
    var pageRole = ((offsetInUnit - 1) % 5) + 1;

    var isPalestineSoc = /وطن|فلسطين|اجتماع|تاريخ|جغرافي/.test(M.name + " " + unitTitle);
    var isMathOrPhys = /رياضيات|فيزياء|كيمياء|معادل|تفاضل/.test(M.name + " " + unitTitle);
    var isLang = /عربي|لغتنا|إنجليزي|English/.test(M.name + " " + unitTitle);

    var pageHeaderBadge = "";
    var pageSubHeading = "";
    var paragraphs = [];
    var highlightBoxTitle = "";
    var highlightBoxPoints = [];
    var bottomActivityTitle = "";
    var bottomActivityBody = "";

    if (pageRole === 1) {
      pageHeaderBadge = "الدرس (" + lessonNumInUnit + ") • التمهيد والشرح الأساسي";
      pageSubHeading = "أولاً: المدخل المنهجي والفكرة المحورية — " + unitTitle + " (الجزء " + lessonNumInUnit + ")";
      paragraphs = [
        "نبدأ في هذه الصفحة (صفحة " + p + ") بدراسة الركائز الأساسية لوحدة «" + unitTitle + "» ضمن مبحث «" + M.name + "» لطلبة " + G.name + ". يهدف هذا الدرس إلى بناء تصور واضح ومتدرج ينطلق من الخبرات السابقة للطالب وصولاً إلى إتقان المفاهيم الجديدة.",
        "الفقرة القرائية الرئيسية: " + primaryRule + " وعند تأمل هذا المفهوم نلاحظ أنه يشكل الأساس الذي تُبنى عليه التطبيقات العملية الواردة في صفحات هذه الوحدة."
      ];
      if (isPalestineSoc) {
        paragraphs.push("تتميز دولة فلسطين بموقعها الجغرافي الفريد في قلب العالم العربي، حيث تصل بين قارتي آسيا وإفريقيا، وتضم مدناً تاريخية عريقة مثل القدس الشريف (العاصمة)، الخليل، نابلس، غزة، يافا، حيفا، عكا، جنين، طولكرم، قلقيلية، رام الله والبيرة، بيت لحم، أريحا، سلفيت، وطوباس.");
      } else if (isMathOrPhys) {
        paragraphs.push("للربط الرياضي والعملي: نحدد أولاً المتغيرات الأساسية ووحدات قياسها المعتمدة، ثم نكتب العلاقة القانونية التي تربط بين المعطيات والمطلوب قبل البدء بأي تعويض عددي.");
      } else if (isLang) {
        paragraphs.push("النص التطبيقي: نقرأ الفقرة قراءة جهرية معبرة مع مراعاة مخارج الحروف السليمة وعلامات الترقيم، ثم نستخرج الكلمات المفتاحية والتراكيب اللغوية الواردة في النص.");
      }
      highlightBoxTitle = "📌 خلاصة القاعدة والمفهوم في صفحة " + p + ":";
      highlightBoxPoints = [
        primaryRule,
        "تحديد العناصر الأساسية للدرس والتمييز بين المفهوم العام وتطبيقاته المباشرة."
      ];
      bottomActivityTitle = "💡 سؤال تمهيدي للتفكير (صفحة " + p + "):";
      bottomActivityBody = "برأيك، كيف يظهر أثر ما تعلمناه في «" + unitTitle + "» في حياتنا اليومية ومحيطنا المدرسي؟";

    } else if (pageRole === 2) {
      pageHeaderBadge = "الدرس (" + lessonNumInUnit + ") • تفصيل المفاهيم والتحليل";
      pageSubHeading = "ثانياً: الشرح التفصيلي وتفكيك المفاهيم — صفحة " + p;
      paragraphs = [
        "نستكمل في الصفحة (" + p + ") تحليل العناصر التفصيلية للدرس رقم (" + lessonNumInUnit + ") من «" + unitTitle + "»، حيث ننتقل من التعريف الكلي إلى فهم الخصائص والشروط التفصيلية لكل عنصر.",
        "التحليل المنهجي المفصّل: إن فهم العلاقة بين أجزاء «" + unitTitle + "» يتطلب الانتباه إلى الخصائص المميزة التالية وكيفية تكاملها مع القاعدة: " + secondaryRule
      ];
      if (isPalestineSoc) {
        paragraphs.push("التنوع الطبيعي والاجتماعي في وطني فلسطين: تتنوع مظاهر السطح في فلسطين لتشمل أربعة أقاليم رئيسة متكاملة:\n1. السهل الساحلي الفلسطيني الممتد على طول البحر الأبيض المتوسط (من رأس الناقورة شمالاً حتى رفح جنوباً).\n2. المرتفعات الجبلية الوسطى (جبال الجليل، ونابلس، والقدس، والخليل).\n3. غور الأردن والبحر الميت (أخفض بقعة على سطح اليابسة).\n4. هضبة النقب في الجنوب.");
      } else if (isMathOrPhys) {
        paragraphs.push("خطوات التحليل العلمي في الصفحة (" + p + "):\n1. قراءة نص المسألة أو القانون وتحديد الشروط الحدية.\n2. تمثيل العلاقة بيانياً أو رمزياً لملاحظة التغير الطردي أو العكسي.\n3. التحقق من تجانس الوحدات قبل الانتقال إلى الأمثلة المحلولة في الصفحة التالية.");
      } else {
        paragraphs.push("تفصيل القواعد والمصطلحات في الصفحة (" + p + "):\n• المفهوم الأول: يرتبط بالمعنى الدلالي والوظيفي في سياق الجملة أو الظاهرة.\n• المفهوم الثاني: يوضح الأثر الناتج عند تغير أحد شروط القاعدة الأساسية.");
      }
      highlightBoxTitle = "🔍 نقاط التركيز والتحليل في صفحة " + p + ":";
      highlightBoxPoints = [
        "المقارنة بين العناصر الأساسية واستنتاج أوجه الشبه والاختلاف.",
        "الربط بين القاعدة النظرية («" + primaryRule.slice(0, 70) + "...») وتفسير الظواهر."
      ];
      bottomActivityTitle = "📝 تدريب تحليلي سريع (صفحة " + p + "):";
      bottomActivityBody = "استخرج من شرح هذه الصفحة خاصيتين أساسيتين ومثّل لكل منهما بمثال واحد بكلماتك الخاصة.";

    } else if (pageRole === 3) {
      pageHeaderBadge = "الدرس (" + lessonNumInUnit + ") • الأمثلة المحلولة والأنشطة";
      pageSubHeading = "ثالثاً: الأمثلة التطبيقية المحلولة خطوة بخطوة والنشاط الصفي — صفحة " + p;
      paragraphs = [
        "تُخصَّص الصفحة (" + p + ") للتطبيق العملي المباشر على ما درسناه في الصفحتين السابقتين من «" + unitTitle + "»، وذلك من خلال أمثلة محلولة بالتفصيل وأنشطة تطبيقية.",
        "✅ المثال التطبيقي المحلول (1) — صفحة " + p + ":\nالمعطيات والسياق: نريد تطبيق قاعدة («" + primaryRule + "») على موقف عملي مباشر من المقرر.\nخطوات الحل المنهجي:\n• الخطوة الأولى: تحديد المعطيات والمفهوم المطلوب بدقة.\n• الخطوة الثانية: تطبيق القاعدة المقررة في الدرس (" + lessonNumInUnit + ") بشكل منظم.\n• الخطوة الثالثة: كتابة الاستنتاج النهائي والتحقق من صحته."
      ];
      if (isPalestineSoc) {
        paragraphs.push("✅ مثال تطبيقي (2) من جغرافيا وتاريخ ومدن فلسطين:\n• المدينة والقرية والمخيم في فلسطين ترتبط جميعها بروابط التكافل والتعاون والهوية الوطنية.\n• مثال: تشتهر مدينة القدس بالمسجد الأقصى المبارك وكنيسة القيامة وأسوارها التاريخية، وتشتهر الخليل بالحرم الإبراهيمي وصناعة الزجاج والخزف، ونابلس بصناعة الصابون التقليدي والبلدة القديمة، وغزة ويافا وحيفا وعكا بموانئها البحرية العريقة، وأريحا بكونها أقدم مدينة في التاريخ.");
      } else {
        paragraphs.push("✅ المثال التطبيقي المحلول (2) — حالة متقدمة:\nعند تغير المعطيات في المسألة أو الجملة، نعيد تطبيق نفس الخطوات القياسية مع مراعاة إشارة أو شرط القاعدة الثانية: (" + secondaryRule + ").");
      }
      highlightBoxTitle = "🧪 النشاط التعاوني الصفي (نشاط رقم " + lessonNumInUnit + " — صفحة " + p + "):";
      highlightBoxPoints = [
        "بالتعاون مع زملائك في المجموعة، ناقش خطوات المثال المحلول أعلاه وسجّل ملاحظاتك في دفترك.",
        "طبّق القاعدة نفسها على حالة مشابهة وقارن إجابتك مع خطوات الكتاب."
      ];
      bottomActivityTitle = "✍️ جرب بنفسك الآن (صفحة " + p + "):";
      bottomActivityBody = "أعد صياغة نتيجة النشاط التعاوني في سطرين واضحين واحفظ هذه الصفحة للعودة إليها عند المراجعة.";

    } else if (pageRole === 4) {
      pageHeaderBadge = "الدرس (" + lessonNumInUnit + ") • التطبيقات والمقارنات المنهجية";
      pageSubHeading = "رابعاً: التطبيقات العملية والجداول المقارنة وربط المعرفة — صفحة " + p;
      paragraphs = [
        "في الصفحة (" + p + ") نربط مفاهيم «" + unitTitle + "» بالواقع التطبيقي من خلال المقارنة المنظمة والحالات العملية الشاملة التي تعمّق الفهم وتثبّت المعلومة.",
        "📊 المقارنة والتصنيف المنهجي (صفحة " + p + "):"
      ];
      if (isPalestineSoc) {
        paragraphs.push("• أولاً — مدن ومناطق السهل الساحلي: مثل يافا، حيفا، عكا، غزة، طولكرم، وقلقيلية؛ وتتميز باعتدال مناخها وخصوبة أراضيها الزراعية وحمضياتها وإطلالتها على البحر المتوسط.\n• ثانياً — مدن وقرى المرتفعات الجبلية: مثل القدس الشريف، الخليل، نابلس، رام الله والبيرة، بيت لحم، جنين، وسلفيت؛ وتتميز بأشجار الزيتون واللوزيات والعنب والينابيع والمعالم التاريخية.\n• ثالثاً — منطقة الأغوار والبحر الميت: مثل مدينة أريحا وطوباس والأغوار؛ وتتميز بدفء شتائها وزراعة النخيل والموز والخضروات الشتوية.");
      } else if (isMathOrPhys) {
        paragraphs.push("• الحالة الأولى (التطبيق المباشر): عندما تكون جميع المتغيرات معطاة بالوحدات القياسية، نعوّض مباشرة في القانون الأساسي.\n• الحالة الثانية (إيجاد مجهول عكسي): عندما يُعطى الناتج النهائي ويُطلب أحد المعاملات الداخلية، نعيد ترتيب المعادلة جبرياً قبل الحساب.\n• الحالة الثالثة (التمثيل البياني): قراءة القيم والميل والمساحة مباشرة من المنحنى البياني.");
      } else {
        paragraphs.push("• المستوى الأول (الفهم المباشر): استيعاب الفكرة الصريحة والقاعدة الأساسية (" + primaryRule + ").\n• المستوى الثاني (التذوق والتحليل): إدراك العلاقات الدقيقة والروابط السببية واللغوية داخل النص.\n• المستوى الثالث (التوظيف والإنتاج): كتابة جمل أو فقرات أو حلول جديدة تحاكي النمط المنهجي المقرر.");
      }
      highlightBoxTitle = "🌟 إضاءة منهجية هامة في صفحة " + p + ":";
      highlightBoxPoints = [
        "الربط بين النظرية والتطبيق العملي يمنع النسيان ويجعل استرجاع المعلومة في الامتحان سريعاً ودقيقاً.",
        "تأكد من مراجعة الأمثلة المقارنة في هذه الصفحة قبل الانتقال لأسئلة التقويم في الصفحة (" + (p + 1) + ")."
      ];
      bottomActivityTitle = "🧭 ربط بالحياة والبيئة (صفحة " + p + "):";
      bottomActivityBody = "اذكر مثالاً واقعياً من بيئتك في فلسطين يوضح أحد التطبيقات الواردة في هذه الصفحة.";

    } else {
      pageHeaderBadge = "الدرس (" + lessonNumInUnit + ") • أسئلة التقويم والحلول النموذجية";
      pageSubHeading = "خامساً: أسئلة المراجعة والتقويم الذاتي للدرس (" + lessonNumInUnit + ") مع الحلول — صفحة " + p;
      paragraphs = [
        "وصلت إلى الصفحة (" + p + ") المخصّصة لاختبار مدى إتقانك لمفاهيم الدرس (" + lessonNumInUnit + ") من «" + unitTitle + "» في كتاب «" + (M.bookTitle || M.name) + "».",
        "❓ السؤال الأول (الفهم والاستيعاب):\nوضّح المقصود بالقاعدة المحورية التي درسناها في هذا الفصل وكيف نطبّقها؟\n✔️ الإجابة النموذجية: " + primaryRule,
        "❓ السؤال الثاني (التعليل والتفسير):\nعلّل أهمية الالتزام بالخطوات والشروط المقررة في «" + unitTitle + "» عند التطبيق العملي؟\n✔️ الإجابة النموذجية: لأن تتابع الخطوات يضمن صحة النتيجة ودقة التفسير وفق القاعدة: " + secondaryRule
      ];
      highlightBoxTitle = "✅ قائمة التحقق من إتقان الصفحة " + p + ":";
      highlightBoxPoints = [
        "أستطيع شرح الفكرة الرئيسة للدرس (" + lessonNumInUnit + ") من «" + unitTitle + "» بلغة سليمة وواضحة.",
        "أستطيع حل التمارين والأسئلة التطبيقية المرتبطة بهذه الصفحة دون أخطاء."
      ];
      bottomActivityTitle = "🎯 الخطوة التالية بعد إتمام صفحة " + p + ":";
      bottomActivityBody = "اضغط على «الصفحة التالية ▶» للانتقال إلى الصفحة (" + Math.min(totalP, p + 1) + ") وبدء الدرس التالي، أو افتح تبويب «اختبر فهمك» للتقييم التفاعلي.";
    }

    var flashcards = [
      { id: "fc1", q: "ما القاعدة الأساسية الأولى في «" + unitTitle + "»؟", a: primaryRule },
      { id: "fc2", q: "ما المفهوم المكمل أو القاعدة الثانية المرتبطة بـ «" + M.name + "»؟", a: secondaryRule },
      { id: "fc3", q: "كيف نطبق مفاهيم الدرس (" + lessonNumInUnit + ") عملياً؟", a: "بتحديد المعطيات أولاً ثم تطبيق القاعدة المنهجية (" + primaryRule.slice(0, 65) + "...) والتحقق من النتيجة." }
    ];

    var unitQuizQuestions = [
      {
        q: "1. (فهم واستيعاب): أي العبارات التالية تمثل القاعدة الصحيحة المعتمدة في «" + unitTitle + "»؟",
        opts: [primaryRule, "علاقة افتراضية معاكسة لا تنطبق على الشروط المقررة في الدرس.", "حالة غير واردة في المنهاج المقرر."],
        ans: 0,
        exp: "القاعدة المعتمدة نصاً في الكتاب هي: " + primaryRule
      },
      {
        q: "2. (تطبيق عملي): عند تطبيق مفاهيم «" + unitTitle + "» في حل مسألة أو تدريب، ما الخطوة المنهجية الصحيحة؟",
        opts: ["تحديد المعطيات والمطلوب ثم تطبيق القاعدة المقررة خطوة بخطوة", "تخمين النتيجة النهائية دون كتابة خطوات الحل", "إهمال شروط القاعدة والوحدات القياسية"],
        ans: 0,
        exp: "التسلسل المنهجي يوجب تحديد المعطيات ثم تطبيق القاعدة والتحقق من النتيجة."
      },
      {
        q: "3. (تحليل واستنتاج): ما العلاقة التكاملية التي درسناها في هذا الفصل من «" + M.name + "»؟",
        opts: [secondaryRule, "انعدام الرابط بين المفاهيم النظرية والتطبيقات العملية", "عدم إمكانية التحقق من صحة الحلول"],
        ans: 0,
        exp: "تكامل المفاهيم يقوم على: " + secondaryRule
      },
      {
        q: "4. (صح أم خطأ): يساعد ربط مفاهيم «" + unitTitle + "» بالأمثلة الواقعية والبيئة الفلسطينية على ترسيخ الفهم طويل المدى.",
        opts: ["صحيحة تماماً ✅", "خاطئة ❌"],
        ans: 0,
        exp: "الربط بالبيئة والتطبيقات الحياتية من أهم ركائز المنهاج الفلسطيني."
      }
    ];

    _pageDataCacheKey = _cKey;
    return (_pageDataCacheVal = {
      page: p,
      totalPages: totalP,
      unitIdx: computedUnitIdx,
      unitTitle: unitTitle,
      unitStartPage: unitStartPage,
      offsetInUnit: offsetInUnit,
      lessonNum: lessonNumInUnit,
      pageRole: pageRole,
      badge: pageHeaderBadge,
      subHeading: pageSubHeading,
      paragraphs: paragraphs,
      boxTitle: highlightBoxTitle,
      boxPoints: highlightBoxPoints,
      activityTitle: bottomActivityTitle,
      activityBody: bottomActivityBody,
      bottomBody: bottomActivityBody,
      flashcards: flashcards,
      unitQuizQuestions: unitQuizQuestions
    });
  }

  var DEFAULT_MASTER_TREE = [
    {
      id: "stage-primary",
      name: "المرحلة الأساسية الدنيا (الصفوف 1 – 4)",
      shortName: "الأساسية الدنيا (1–4)",
      ico: "🌱",
      desc: "المنهاج الفلسطيني الرسمي للصفوف من الأول إلى الرابع الأساسي (وزارة التربية والتعليم العالي)",
      color: "from-emerald-600 to-teal-700",
      grades: [
        {
          id: "g1",
          name: "الصف الأول الأساسي",
          officialPortal: "https://elearn.edu.ps/",
          branches: [
            {
              id: "g1-gen",
              name: "المباحث الرسمية المعتمدة",
              subjects: [
                { id: "g1-ar", name: "لغتنا الجميلة", ico: "📖", bookTitle: "لغتنا الجميلة — الصف الأول الأساسي (الفصل الأول والثاني)", totalPages: 132, officialUrl: "https://elearn.edu.ps/c1/", units: ["الفصل 1: الحروف (د، ب، م، ن، س، ز، ح، ل، ت، ث، ج، ف، ع، ش، ص، ق) وأصواتها القصيرة والطويلة", "الفصل 2: الحروف (غ، ط، ك، ض، هـ، و، الهمزة، ظ، ي) ودروس القراءة (وطني أجمل، الفراشة والنحلة)"], rules: ["التمييز بين حروف المد الثلاثة (ا، و، ي) والحركات القصيرة (الفتحة، الضمة، الكسرة) والسكون."] },
                { id: "g1-math", name: "الرياضيات", ico: "🔢", bookTitle: "الرياضيات — الصف الأول الأساسي (الفصل الأول والثاني)", totalPages: 128, officialUrl: "https://elearn.edu.ps/c1/", units: ["الفصل 1: الأعداد (1–9)، المقارنة، الصفر ومكونات الأعداد والجمع والطرح ضمن 9، الأعداد (10–20)، القياس", "الفصل 2: العدد السابق والترتيب والقيمة المنزلية، الجمع والطرح ضمن 10 و18، الأعداد (21–99)"], rules: ["القيمة المنزلية للعدد المكون من منزلتين تتألف من الآحاد والعشرات."] },
                { id: "g1-sci", name: "التربية الوطنية والحياتية", ico: "🌿", bookTitle: "التربية الوطنية والحياتية — الصف الأول الأساسي", totalPages: 96, officialUrl: "https://elearn.edu.ps/", units: ["الوحدة 1: أنا وأسرتي ومدرستي", "الوحدة 2: الكائنات الحية والبيئة المحيطة", "الوحدة 3: وطني فلسطين وصحتي وسلامتي"], rules: ["تحتاج الكائنات الحية إلى الماء والهواء والغذاء لتنمو وتعيش."] },
                { id: "g1-isl", name: "التربية الإسلامية", ico: "🕌", bookTitle: "التربية الإسلامية — الصف الأول الأساسي", totalPages: 88, officialUrl: "https://elearn.edu.ps/", units: ["الوحدة 1: القرآن الكريم (الفاتحة، الإخلاص، الناس، الفلق)", "الوحدة 2: العقيدة والآداب الإسلامية والسيرة"], rules: ["البسملة والحمدلة في بداية الأعمال اليومية وآداب الطعام والسلام."] },
                { id: "g1-en", name: "اللغة الإنجليزية (English for Palestine 1)", ico: "🔤", bookTitle: "English for Palestine — Pupil's Book 1", totalPages: 92, officialUrl: "https://elearn.edu.ps/c1/", units: ["Semester 1: Hello, Let's eat, Animals, My Body, My classroom, My family, Let's drink", "Semester 2: Let's Play, Transport, Colours, My Clothes, My Bedroom, In My Country, My Friends"], rules: ["Use simple greetings (Hello, Goodbye) and basic classroom/family vocabulary."] }
              ]
            }
          ]
        },
        {
          id: "g2",
          name: "الصف الثاني الأساسي",
          officialPortal: "https://elearn.edu.ps/",
          branches: [
            {
              id: "g2-gen",
              name: "المباحث الرسمية المعتمدة",
              subjects: [
                { id: "g2-ar", name: "لغتنا الجميلة", ico: "📖", bookTitle: "لغتنا الجميلة — الصف الثاني الأساسي (الفصل الأول والثاني)", totalPages: 140, officialUrl: "https://elearn.edu.ps/c2/", units: ["الفصل 1: الحرية أجمل، الرسامة الصغيرة، عودة الطائر، الأرض، الغراب والجرة، مصنع الألبان، جحا وحميره العشرة، طبيبة القرية", "الفصل 2: وطن يسكن فينا، نبني ونبني، العصفورة والأفعى، في مدينة الخليل، عمر والغلام، والدي الحبيب"], rules: ["اللام القمرية تُكتب وتُلفظ وتكون ساكنة، واللام الشمسية تُكتب ولا تُلفظ والحرف بعدها مشدد."] },
                { id: "g2-math", name: "الرياضيات", ico: "🔢", bookTitle: "الرياضيات — الصف الثاني الأساسي (الفصل الأول والثاني)", totalPages: 136, officialUrl: "https://elearn.edu.ps/c2/", units: ["الفصل 1: الأعداد ضمن 99 و199 و999 والجمع والطرح دون حمل أو استلاف والهندسة", "الفصل 2: الجمع مع حمل والطرح مع استلاف، العد القفزي ومفهوم الضرب وحقائقه (2، 3، 4، 5، 10)، ومفهوم القسمة"], rules: ["الضرب هو جمع متكرر لمجموعات متساوية، والقسمة توزيع بالتساوي."] },
                { id: "g2-sci", name: "التربية الوطنية والحياتية", ico: "🌿", bookTitle: "التربية الوطنية والحياتية — الصف الثاني الأساسي", totalPages: 104, officialUrl: "https://elearn.edu.ps/", units: ["الوحدة 1: جسم الإنسان وصحته", "الوحدة 2: النباتات والحيوانات في وطني فلسطين"], rules: ["أجزاء النبات الرئيسة: الجذر، الساق، الأوراق، الزهرة، والثمرة."] },
                { id: "g2-isl", name: "التربية الإسلامية", ico: "🕌", bookTitle: "التربية الإسلامية — الصف الثاني الأساسي", totalPages: 94, officialUrl: "https://elearn.edu.ps/", units: ["الوحدة 1: سور جزء عم وأركان الإيمان", "الوحدة 2: الوضوء والصلاة والأخلاق"], rules: ["الصلوات الخمس المفروضة وترتيب أفعال الوضوء الصحيح."] },
                { id: "g2-en", name: "اللغة الإنجليزية (English for Palestine 2)", ico: "🔤", bookTitle: "English for Palestine — Pupil's Book 2", totalPages: 96, officialUrl: "https://elearn.edu.ps/c2/", units: ["Semester 1: Hi I'm, In the Kitchen, In the garden, My Body, Jump, My Home, My Town", "Semester 2: My hobbies, Transport, Let's find out, Let's go shopping, Guess Who?, My Country, Happy Birthday!"], rules: ["Use present simple and can/can't for everyday actions and hobbies."] }
              ]
            }
          ]
        },
        {
          id: "g3",
          name: "الصف الثالث الأساسي",
          officialPortal: "https://elearn.edu.ps/",
          branches: [
            {
              id: "g3-gen",
              name: "المباحث الرسمية المعتمدة",
              subjects: [
                { id: "g3-ar", name: "لغتنا الجميلة", ico: "📖", bookTitle: "لغتنا الجميلة — الصف الثالث الأساسي (الفصل الأول والثاني)", totalPages: 148, officialUrl: "https://elearn.edu.ps/c3/", units: ["الفصل 1: أقسام الكلام (الاسم والفعل والحرف) والقراءة", "الفصل 2: الجملة الاسمية والفعلية وعلامات الترقيم"], rules: ["الكلمة تنقسم إلى: اسم يدل على معنى في نفسه، وفعل مرتبط بزمن، وحرف يربط بين الكلمات."] },
                { id: "g3-math", name: "الرياضيات", ico: "🔢", bookTitle: "الرياضيات — الصف الثالث الأساسي (الفصل الأول والثاني)", totalPages: 144, officialUrl: "https://elearn.edu.ps/c3/", units: ["الفصل 1: الأعداد ضمن 9999 والجمع والطرح", "الفصل 2: جداول الضرب والقسمة والكسور العادية والهندسة"], rules: ["الكسر العادي يتكون من بسط ومقام وخط الكسر، ويعبر عن جزء من كل متساوٍ."] },
                { id: "g3-sci", name: "العلوم والحياة", ico: "🔬", bookTitle: "العلوم والحياة — الصف الثالث الأساسي (الفصل الأول والثاني)", totalPages: 120, officialUrl: "https://elearn.edu.ps/", units: ["الفصل 1: المادة وخصائصها وحالاتها", "الفصل 2: القوة والحركة والمغناطيس والأرض والكون"], rules: ["حالات المادة الثلاث: الصلبة، السائلة، والغازية، وتتحول بالتسخين أو التبريد."] },
                { id: "g3-soc", name: "التنشئة الوطنية والاجتماعية", ico: "🇵🇸", bookTitle: "التنشئة الوطنية والاجتماعية — الصف الثالث الأساسي", totalPages: 100, officialUrl: "https://elearn.edu.ps/", units: ["الوحدة 1: وطني فلسطين ومدنه وقراه", "الوحدة 2: حقوقي وواجباتي والتعاون"], rules: ["عاصمة دولة فلسطين هي القدس الشريف، وتتميز فلسطين بتنوع تضاريسها الساحلية والجبلية والغورية."] },
                { id: "g3-isl", name: "التربية الإسلامية", ico: "🕌", bookTitle: "التربية الإسلامية — الصف الثالث الأساسي", totalPages: 102, officialUrl: "https://elearn.edu.ps/", units: ["الوحدة 1: العقيدة الإسلامية والقرآن الكريم", "الوحدة 2: العبادات والسيرة النبوية"], rules: ["أركان الإسلام خمسة وأركان الإيمان ستة."] },
                { id: "g3-en", name: "اللغة الإنجليزية (English for Palestine 3)", ico: "🔤", bookTitle: "English for Palestine — Pupil's Book 3", totalPages: 104, officialUrl: "https://elearn.edu.ps/c3/", units: ["Semester 1: All about me, He's a doctor, At the market, At the Zoo, I don't feel well, My Day, It's Sunny", "Semester 2: Reading comprehension, daily routines, time expressions, and guided writing"], rules: ["Use present continuous and simple present to describe daily routines and professions."] },
                { id: "g3-art", name: "الفنون والمهارات الحياتية", ico: "🎨", bookTitle: "التربية الفنية والمهارات — الصف الثالث الأساسي", totalPages: 76, officialUrl: "https://elearn.edu.ps/", units: ["الوحدة 1: التلوين والخط العربي والأشكال الهندسية", "الوحدة 2: الأشغال اليدوية والتراث الفلسطيني"], rules: ["الألوان الأساسية هي الأحمر والأصفر والأزرق، ومن مزجها تنتج الألوان الثانوية."] }
              ]
            }
          ]
        },
        {
          id: "g4",
          name: "الصف الرابع الأساسي",
          officialPortal: "https://elearn.edu.ps/c4/",
          branches: [
            {
              id: "g4-gen",
              name: "المباحث الرسمية المعتمدة (6 مباحث)",
              subjects: [
                {
                  id: "g4-ar",
                  name: "لغتنا الجميلة",
                  ico: "📖",
                  bookTitle: "لغتنا الجميلة — الصف الرابع الأساسي (الجزء 1 والجزء 2 الرسمي)",
                  totalPages: 160,
                  officialUrl: "https://elearn.edu.ps/c4/ar4-p1/",
                  units: [
                    "الفصل 1 (الدروس 1–5): الفضل لمعلمتي، السمكة والحرية، يا رمز العطاء والصمود، شقائق النعمان، جولة في أسواق القدس",
                    "الفصل 1 (الدروس 6–10): دمية حسنة، إرادتي سر نجاحي، قطرة ماء تروي قصتها، الجندب والنملة",
                    "الفصل 1 (الدروس 11–15): رسائل بلا ساعٍ، وطني أغلى، أحلام اليقظة، النفع طبعي، ما أجمل السماء!",
                    "الفصل 2 (الدروس 1–7): في قريتنا عرس، الدفء الحقيقي، جزاء الإحسان، حلم جميل",
                    "الفصل 2 (الدروس 8–13): من حكم الآباء، الكوفية، الوقاية والسلامة، موسيقا الطبيعة"
                  ],
                  rules: [
                    "الجملة الاسمية تتكون من ركنين أساسيين هما المبتدأ والخبر وكلاهما مرفوعان، والجملة الفعلية تبدأ بفعل وفاعل.",
                    "التفريق الإملائي الدقيق بين التاء المربوطة (ـة/ة) والتاء المبسوطة (ت) والهاء المربوطة (ـه/ه) في نهاية الكلمات."
                  ]
                },
                {
                  id: "g4-math",
                  name: "الرياضيات",
                  ico: "🔢",
                  bookTitle: "الرياضيات — الصف الرابع الأساسي (الجزء 1 والجزء 2 الرسمي)",
                  totalPages: 168,
                  officialUrl: "https://elearn.edu.ps/c4/",
                  units: [
                    "الفصل 1 — الوحدة 1: الأعداد الكبيرة (الأعداد ضمن 999,999، القيمة المنزلية، مقارنة الأعداد وترتيبها)",
                    "الفصل 1 — الوحدة 2: جمع الأعداد وطرحها ضمن الملايين (الجمع مع الحمل، الطرح مع الاستلاف، التقريب)",
                    "الفصل 1 — الوحدة 3: الضرب والقسمة (1) — ضرب عدد من منزلة في منزلتين/3 منازل، القسمة دون باقٍ ومع باقٍ",
                    "الفصل 1 — الوحدة 4: الكسور (الكسور المتكافئة، مقارنة الكسور، جمع الأعداد الكسرية وطرحها)",
                    "الفصل 2 — الوحدة 7: نظرية الأعداد (مضاعفات العدد، قابلية القسمة على 2، 3، 5، 6)",
                    "الفصل 2 — الوحدة 8: الضرب والقسمة (2) — ضرب عدد من منزلتين/3 منازل في عدد من منزلتين والقسمة عليه",
                    "الفصل 2 — الوحدة 9: الكسور العشرية والأعداد العشرية (الأجزاء من عشرة ومئة)",
                    "الفصل 2 — الوحدة 10: الهندسة والقياس (المربع والمستطيل ومحيطهما، التحويل بين وحدات القياس، حجم متوازي المستطيلات)",
                    "الفصل 2 — الوحدة 11: الإحصاء والاحتمال (التجربة العشوائية والفرصة)"
                  ],
                  rules: [
                    "في الأعداد الكبيرة تقرأ كل دورة من اليسار إلى اليمين: دورة الملايين، ثم دورة الألوف، ثم دورة الوحدات.",
                    "يقبل العدد القسمة على 2 إذا كان آحاده زوجياً، وعلى 3 إذا كان مجموع أرقامه من مضاعفات 3، وعلى 5 إذا كان آحاده 0 أو 5، وعلى 6 إذا قبل على 2 و 3 معاً.",
                    "الكسر العشري مقامه 10 أو 100 وتُفصل أجزاؤه بالفاصلة العشرية."
                  ]
                },
                {
                  id: "g4-sci",
                  name: "العلوم والحياة",
                  ico: "🔬",
                  bookTitle: "العلوم والحياة — الصف الرابع الأساسي (الجزء 1 والجزء 2 الرسمي)",
                  totalPages: 140,
                  officialUrl: "https://elearn.edu.ps/c4/",
                  units: [
                    "الفصل 1 — الوحدة 1: صحة الإنسان وغذائه (المجموعات الغذائية والغذاء المتوازن، حفظ الأغذية، الجهاز الهضمي، الجهاز التنفسي وسلامته)",
                    "الفصل 1 — الوحدة 2: الكهرباء والمغناطيسية (مصادر الكهرباء، الدارة الكهربائية البسيطة، صناعة المغناطيس وتطبيقاته)",
                    "الفصل 1 — الوحدة 3: النباتات (النقل في النباتات وتصنيفها)",
                    "الفصل 2 — الوحدة 4: الطقس والفلك (مظاهر الحالة الجوية، المجموعة الشمسية، حركة الأرض والقمر)",
                    "الفصل 2 — الوحدة 5: التنوع الحيوي والعلاقات الحيوية والسلاسل الغذائية",
                    "الفصل 2 — الوحدة 6: الضوء والصوت (سلوك الضوء وأهميته، سلوك الصوت وأهميته)"
                  ],
                  rules: [
                    "المجموعات الغذائية الأساسية ثلاث: أغذية الطاقة (الكربوهيدرات والدهون)، أغذية البناء (البروتينات)، وأغذية الوقاية (الفيتامينات والأملاح المعدنية).",
                    "تتكون الدارة الكهربائية البسيطة من: مصدر كهربائي (بطارية)، أسلاك توصيل، مصباح كهربائي، ومفتاح."
                  ]
                },
                {
                  id: "g4-soc",
                  name: "التنشئة الوطنية والاجتماعية",
                  ico: "🇵🇸",
                  bookTitle: "التنشئة الوطنية والاجتماعية — الصف الرابع الأساسي (كتاب الوزارة الرسمي)",
                  totalPages: 112,
                  officialUrl: "https://elearn.edu.ps/c4-old/tw4-p2/",
                  units: [
                    "الوحدة 1: شكل فلسطين وفلسطين عربية إسلامية",
                    "الوحدة 2: حقي في الأمان والحماية",
                    "الوحدة 3: التراث الشعبي والمؤسسات الوطنية",
                    "الوحدة 4: أنا مواطن فعال (المشاركة والمسؤولية)"
                  ],
                  rules: [
                    "تقع فلسطين في قلب العالم العربي وتربط بين قارتي آسيا وإفريقيا وتطل على البحر المتوسط، وعاصمتها القدس الشريف."
                  ]
                },
                {
                  id: "g4-isl",
                  name: "التربية الإسلامية",
                  ico: "🕌",
                  bookTitle: "التربية الإسلامية — الصف الرابع الأساسي (كتاب الوزارة الرسمي)",
                  totalPages: 110,
                  officialUrl: "https://elearn.edu.ps/c4/",
                  units: [
                    "الفصل 1 — العقيدة والقرآن: آية الكرسي، الله الواحد، وظائف الملائكة، مهام الرسل، سورة الأعلى",
                    "الفصل 1 — العبادات: فرائض الصلاة وسننها، الوضوء والطهارة",
                    "الفصل 2: الإيمان بالكتب السماوية، صلاة الجماعة، وسيرة النبي ﷺ"
                  ],
                  rules: [
                    "الإيمان بالله الواحد وبالملائكة والكتب السماوية والرسل من أركان الإيمان الستة، وفرائض الصلاة أركان لا تصح الصلاة إلا بها."
                  ]
                },
                {
                  id: "g4-en",
                  name: "اللغة الإنجليزية (English 4)",
                  ico: "🔤",
                  bookTitle: "English for Palestine — Pupil's Book 4",
                  totalPages: 112,
                  officialUrl: "https://elearn.edu.ps/c4/",
                  units: [
                    "Semester 1 (Units 1–8): A new friend, Our house, Lost, Shopping list, On Sundays I, At the restaurant, My favorite season",
                    "Semester 2 (Units 10–17): Visiting Palestine, Let's make a cake, It's 7:30, Good habits, I can do it!, In my street, On the farm"
                  ],
                  rules: [
                    "Use Present Simple for daily routines and habits, and Present Continuous for actions happening now."
                  ]
                }
              ]
            }
          ]
        }
      ]
    },
    {
      id: "stage-middle",
      name: "المرحلة الأساسية العليا (الصفوف 5 – 9)",
      shortName: "الأساسية العليا (5–9)",
      ico: "🏫",
      desc: "المنهاج الفلسطيني الرسمي للصفوف من الخامس إلى التاسع الأساسي",
      color: "from-sky-600 to-indigo-700",
      grades: [
        {
          id: "g5",
          name: "الصف الخامس الأساسي",
          officialPortal: "https://elearn.edu.ps/",
          branches: [{ id: "g5-gen", name: "المباحث الرسمية المعتمدة", subjects: [
            { id: "g5-ar", name: "اللغة العربية", ico: "📖", bookTitle: "اللغة العربية — الصف الخامس الأساسي", totalPages: 164, officialUrl: "https://elearn.edu.ps/c5-old/cur5/", units: ["الفصل 1: الوحدة الأولى (عظمة الخالق)، الوحدة الثالثة (كي لا تغرق السفينة)، التراكيب والأساليب اللغوية والإملاء", "الفصل 2: القراءة والنصوص الأدبية، التراكيب النحوية، الإملاء والتعبير الكتابي"], rules: ["علامة رفع الاسم المفرد الضمة، ونصبه الفتحة، وجره الكسرة."] },
            { id: "g5-math", name: "الرياضيات", ico: "📐", bookTitle: "الرياضيات — الصف الخامس الأساسي", totalPages: 160, officialUrl: "https://elearn.edu.ps/c5-old/cur5/", units: ["الفصل 1: الأعداد الكبيرة، ضرب الأعداد الكلية وقسمتها، الكسور، الإحصاء والجداول التكرارية", "الفصل 2: ضرب الكسور العادية وقسمتها، الأعداد العشرية، الهندسة والقياس ووحدات المساحة"], rules: ["العدد الأولي هو عدد أكبر من 1 له عاملان فقط هما الواحد الصحيح والعدد نفسه."] },
            { id: "g5-sci", name: "العلوم والحياة", ico: "🔬", bookTitle: "العلوم والحياة — الصف الخامس الأساسي", totalPages: 140, officialUrl: "https://elearn.edu.ps/", units: ["الفصل 1: الخلية الحية والأنسجة والعناصر والمركبات", "الفصل 2: القوة والضغط والطاقة والأرض"], rules: ["الخلية هي وحدة البناء والوظيفة في أجسام الكائنات الحية."] },
            { id: "g5-tech", name: "التكنولوجيا والبرمجة", ico: "💻", bookTitle: "التكنولوجيا — الصف الخامس الأساسي", totalPages: 96, officialUrl: "https://elearn.edu.ps/", units: ["الوحدة 1: مقدمة في التكنولوجيا والحاسوب", "الوحدة 2: البرمجة المرئية باللبنات (Scratch)"], rules: ["الخوارزمية هي مجموعة خطوات منطقية متسلسلة ومحددة لحل مسألة."] },
            { id: "g5-en", name: "اللغة الإنجليزية (English 5)", ico: "🔤", bookTitle: "English for Palestine — Pupil's Book 5", totalPages: 112, officialUrl: "https://elearn.edu.ps/c5/", units: ["Semester 1 (Units 1–7): New friends, Our country, Mini Olympics, Holidays in Palestine", "Semester 2 (Units 10–17): Past simple, Omar and Rania's visit to Qalqilia, Object pronouns"], rules: ["Use Present Simple vs Present Continuous, and Past Simple (was/were & regular/irregular verbs)."] },
            { id: "g5-isl", name: "التربية الإسلامية والتلاوة", ico: "🕌", bookTitle: "التربية الإسلامية — الصف الخامس الأساسي", totalPages: 116, officialUrl: "https://elearn.edu.ps/c5/", units: ["الفصل 1: العقيدة، التلاوة والتجويد، والحديث الشريف", "الفصل 2: العبادات والسيرة النبوية والأخلاق"], rules: ["أحكام النون الساكنة والتنوين (الإظهار، الإدغام، الإقلاب، الإخفاء)."] },
            { id: "g5-soc", name: "الدراسات الاجتماعية", ico: "🌍", bookTitle: "الدراسات الاجتماعية — الصف الخامس الأساسي", totalPages: 110, officialUrl: "https://elearn.edu.ps/c5/", units: ["الفصل 1: جغرافية فلسطين والوطن العربي", "الفصل 2: الحضارات القديمة في فلسطين وبلاد الشام"], rules: ["الموقع الاستراتيجي لفلسطين جعلها مهد الحضارات وملتقى القارات."] }
          ]}]
        },
        {
          id: "g6",
          name: "الصف السادس الأساسي",
          officialPortal: "https://elearn.edu.ps/",
          branches: [{ id: "g6-gen", name: "المباحث الرسمية المعتمدة", subjects: [
            { id: "g6-ar", name: "اللغة العربية", ico: "📖", bookTitle: "اللغة العربية — الصف السادس الأساسي", totalPages: 168, officialUrl: "https://elearn.edu.ps/c6-old/cur6/", units: ["الفصل 1: القراءة والنصوص، الأساليب والتراكيب اللغوية (كان وأخواتها وإن وأخواتها)", "الفصل 2: وحدة (فلسطين عربية)، الفاعل والمفعول به وعلامات الإعراب الفرعية، الكتابة والتعبير"], rules: ["كان وأخواتها أفعال ناسخة ترفع المبتدأ وتنصب الخبر، وإن وأخواتها حروف ناسخة تنصب المبتدأ وترفع الخبر."] },
            { id: "g6-math", name: "الرياضيات", ico: "📐", bookTitle: "الرياضيات — الصف السادس الأساسي", totalPages: 166, officialUrl: "https://elearn.edu.ps/c6-old/cur6/", units: ["الفصل 1: أولويات العمليات والأسس والجذر التربيعي، الهندسة وخواص المثلث وشبه المنحرف، الإحصاء والمنوال", "الفصل 2: النسبة والتناسب، النسبة المئوية، الهندسة والقياس (2)"], rules: ["مساحة الدائرة = π × نق² ، ومحيط الدائرة = 2 × π × نق."] },
            { id: "g6-sci", name: "العلوم والحياة", ico: "🔬", bookTitle: "العلوم والحياة — الصف السادس الأساسي", totalPages: 146, officialUrl: "https://elearn.edu.ps/", units: ["الفصل 1: الكائنات الدقيقة والذرات والجزيئات", "الفصل 2: البصريات والعدسات والكهرباء"], rules: ["تتكون الذرة من نواة موجبة الشحنة تدور حولها إلكترونات سالبة."] },
            { id: "g6-en", name: "اللغة الإنجليزية (English 6)", ico: "🔤", bookTitle: "English for Palestine — Pupil's Book 6", totalPages: 116, officialUrl: "https://elearn.edu.ps/c6/", units: ["Semester 1 (Units 1–8): Present continuous, Past simple, Food pyramid, Modals (must/mustn't)", "Semester 2 (Units 10–17): Future plans, Famous places in Palestine & Science"], rules: ["Use while/when to connect past continuous and past simple actions."] },
            { id: "g6-isl", name: "التربية الإسلامية والتلاوة", ico: "🕌", bookTitle: "التربية الإسلامية — الصف السادس الأساسي", totalPages: 120, officialUrl: "https://elearn.edu.ps/c6/", units: ["الفصل 1: القرآن الكريم وأحكام المد والتفخيم والترقيق", "الفصل 2: العقيدة والعبادات والسيرة النبوية"], rules: ["المد الطبيعي يُمد بمقدار حركتين، وحروف القلقلة خمسة (قطب جد)."] },
            { id: "g6-soc", name: "الدراسات الاجتماعية", ico: "🌍", bookTitle: "الدراسات الاجتماعية — الصف السادس الأساسي", totalPages: 114, officialUrl: "https://elearn.edu.ps/c6/", units: ["الفصل 1: الوطن العربي الموقع والتضاريس والمناخ", "الفصل 2: الخلافة الإسلامية والفتوحات"], rules: ["يشغل الوطن العربي موقعاً متوسطاً بين قارات العالم القديم."] },
            { id: "g6-tech", name: "التكنولوجيا والبرمجة", ico: "💻", bookTitle: "التكنولوجيا والبرمجة — الصف السادس الأساسي", totalPages: 100, officialUrl: "https://elearn.edu.ps/c6/", units: ["الوحدة 1: شبكات الحاسوب والإنترنت الآمن", "الوحدة 2: الحلقات التكرارية والمتغيرات في Scratch"], rules: ["الحلقة التكرارية تختصر تكرار الأوامر البرمجية وتجعل البرنامج أكثر كفاءة."] }
          ]}]
        },
        {
          id: "g7",
          name: "الصف السابع الأساسي",
          officialPortal: "https://elearn.edu.ps/",
          branches: [{ id: "g7-gen", name: "المباحث الرسمية المعتمدة", subjects: [
            { id: "g7-ar", name: "اللغة العربية", ico: "📖", bookTitle: "اللغة العربية — الصف السابع الأساسي", totalPages: 174, officialUrl: "https://elearn.edu.ps/c7-old/cur7/", units: ["الفصل 1: المعرب والمبني من الأسماء والأفعال", "الفصل 2: الفعل المضارع الصحيح والمعتل والأفعال الخمسة"], rules: ["الأفعال الخمسة هي كل فعل مضارع اتصلت به ألف الاثنين أو واو الجماعة أو ياء المخاطبة."] },
            { id: "g7-math", name: "الرياضيات", ico: "📐", bookTitle: "الرياضيات — الصف السابع الأساسي", totalPages: 172, officialUrl: "https://elearn.edu.ps/c7-old/cur7/", units: ["الفصل 1: الأعداد الصحيحة والعمليات عليها، التناسب وتطبيقاته، المجموعات", "الفصل 2: الجبر والحدود والمقادير الجبرية، الهندسة والزوايا المتتامة والمتكاملة ورسم المثلث، الإحصاء والاحتمالات"], rules: ["عند جمع عددين صحيحين مختلفين في الإشارة نطرح القيمتين المطلقتين ونضع إشارة الأكبر."] },
            { id: "g7-sci", name: "العلوم والحياة", ico: "🔬", bookTitle: "العلوم والحياة — الصف السابع الأساسي", totalPages: 154, officialUrl: "https://elearn.edu.ps/", units: ["الفصل 1: الأيض والبناء الضوئي والتنفس والجدول الدوري", "الفصل 2: الحرارة والموائع والروابط الكيميائية"], rules: ["معادلة البناء الضوئي: 6CO₂ + 6H₂O + طاقة ضوئية ➔ C₆H₁₂O₆ + 6O₂."] },
            { id: "g7-en", name: "اللغة الإنجليزية (English 7)", ico: "🔤", bookTitle: "English for Palestine — Pupil's Book 7", totalPages: 120, officialUrl: "https://elearn.edu.ps/c7/", units: ["Semester 1 (Units 1–8): Stative verbs, Present perfect (just/already/yet), Reflexive pronouns", "Semester 2 (Units 10–17): Reported speech, Question tags, Palestinian crafts"], rules: ["Present perfect connects past actions with the present using have/has + past participle."] },
            { id: "g7-isl", name: "التربية الإسلامية والتلاوة", ico: "🕌", bookTitle: "التربية الإسلامية — الصف السابع الأساسي", totalPages: 124, officialUrl: "https://elearn.edu.ps/c7/", units: ["الفصل 1: أحكام الميم الساكنة والعقيدة", "الفصل 2: الفقه والسيرة النبوية والأخلاق"], rules: ["أحكام الميم الساكنة ثلاثة: الإخفاء الشفوي، الإدغام الشفوي، والإظهار الشفوي."] },
            { id: "g7-soc", name: "الدراسات الاجتماعية", ico: "🌍", bookTitle: "الدراسات الاجتماعية — الصف السابع الأساسي", totalPages: 118, officialUrl: "https://elearn.edu.ps/c7/", units: ["الفصل 1: الخرائط والمناخ والأقاليم الحيوية", "الفصل 2: التاريخ الإسلامي والحضارة العربية"], rules: ["عناصر الخريطة الأساسية: العنوان، المفتاح، مقياس الرسم، واتجاه الشمال."] },
            { id: "g7-tech", name: "التكنولوجيا والبرمجة", ico: "💻", bookTitle: "التكنولوجيا والبرمجة — الصف السابع الأساسي", totalPages: 104, officialUrl: "https://elearn.edu.ps/c7/", units: ["الوحدة 1: الجداول الإلكترونية ومعالجة البيانات", "الوحدة 2: الخوارزميات والشروط المنطقية"], rules: ["الجملة الشرطية (If-Else) تتحكم بمسار تنفيذ البرنامج بناءً على تحقق الشرط."] }
          ]}]
        },
        {
          id: "g8",
          name: "الصف الثامن الأساسي",
          officialPortal: "https://elearn.edu.ps/",
          branches: [{ id: "g8-gen", name: "المباحث الرسمية المعتمدة", subjects: [
            { id: "g8-math", name: "الرياضيات", ico: "📐", bookTitle: "الرياضيات — الصف الثامن الأساسي", totalPages: 176, officialUrl: "https://elearn.edu.ps/c8/", units: ["الفصل 1: الجذر التربيعي والتكعيبي، الأعداد النسبية وغير النسبية، جمع وضرب وتحليل المقادير الجبرية، نظرية فيثاغورس، تطابق وتشابه المثلثات", "الفصل 2: المعادلة التربيعية بالتحليل وإكمال المربع والقانون العام، الفرق ومجموع مكعبين، حل معادلتين خطيتين، متوازي الأضلاع، القطاع والقطعة الدائرية، الأسطوانة والمخروط، النسب المثلثية، الاحتمالات"], rules: ["نظرية فيثاغورس في المثلث القائم: مربع طول الوتر يساوي مجموع مربعي طولي ضلعي القائمة."] },
            { id: "g8-sci", name: "العلوم والحياة", ico: "🔬", bookTitle: "العلوم والحياة — الصف الثامن الأساسي", totalPages: 160, officialUrl: "https://elearn.edu.ps/c8/", units: ["الفصل 1: التوزيع الإلكتروني والجدول الدوري والصيغة الكيميائية، الكتل والجبهات الهوائية", "الفصل 2: الحركة والقوى والطاقة والتفاعلات الكيميائية وأجهزة الجسم"], rules: ["ينتج عن الانقسام المتساوي خليتان مطابقتان للخلية الأم، وعن المنصف 4 خلايا بنصف الكروموسومات."] },
            { id: "g8-ar", name: "اللغة العربية", ico: "📖", bookTitle: "اللغة العربية — الصف الثامن الأساسي", totalPages: 178, officialUrl: "https://elearn.edu.ps/c8/", units: ["الفصل 1: القراءة والنصوص الأدبية، الجملة الفعلية وبناء الأفعال ونائب الفاعل", "الفصل 2: الرحمة بالأطفال، من أجل الطفولة، سنديانة من فلسطين، زراعة الورد في غزة، رفع/نصب/جزم المضارع، الطباق والمقابلة، الألف الفارقة"], rules: ["يُبنى الفعل للمجهول ويحل المفعول به محل الفاعل فيُسمى نائب فاعل مرفوعاً."] },
            { id: "g8-en", name: "اللغة الإنجليزية (English 8)", ico: "🔤", bookTitle: "English for Palestine — Pupil's Book 8", totalPages: 124, officialUrl: "https://elearn.edu.ps/c8/", units: ["Semester 1 (Units 1–7): Present simple vs continuous, Past continuous, Comparative & Superlative", "Semester 2 (Units 8–14): Passive voice, Conditional sentences (Type 1 & 2)"], rules: ["Use Type 1 conditional (If + Present Simple, will + inf) for real future possibilities."] },
            { id: "g8-isl", name: "التربية الإسلامية والتلاوة", ico: "🕌", bookTitle: "التربية الإسلامية — الصف الثامن الأساسي", totalPages: 126, officialUrl: "https://elearn.edu.ps/c8/", units: ["الفصل 1: أحكام المد الفرعي والعقيدة", "الفصل 2: فقه المعاملات والسيرة النبوية"], rules: ["المد المتصل واجب ويمد 4 أو 5 حركات، والمد المنفصل جائز."] },
            { id: "g8-soc", name: "الدراسات الاجتماعية", ico: "🌍", bookTitle: "الدراسات الاجتماعية — الصف الثامن الأساسي", totalPages: 122, officialUrl: "https://elearn.edu.ps/c8/", units: ["الفصل 1: التضاريس والموارد الطبيعية في فلسطين والعالم", "الفصل 2: الدولة العثمانية وفلسطين في العصر الحديث"], rules: ["تنوع التضاريس في فلسطين بين السهل الساحلي والمرتفعات الجبلية والأغوار وصحراء النقب."] },
            { id: "g8-tech", name: "التكنولوجيا والبرمجة", ico: "💻", bookTitle: "التكنولوجيا والبرمجة — الصف الثامن الأساسي", totalPages: 108, officialUrl: "https://elearn.edu.ps/c8/", units: ["الوحدة 1: تصميم صفحات الويب (HTML / CSS)", "الوحدة 2: قواعد البيانات والوسائط المتعددة"], rules: ["لغة HTML تحدد بنية صفحة الويب ولغة CSS تتحكم بالتنسيق والألوان."] }
          ]}]
        },
        {
          id: "g9",
          name: "الصف التاسع الأساسي",
          officialPortal: "https://elearn.edu.ps/",
          branches: [{ id: "g9-gen", name: "المباحث الرسمية المعتمدة", subjects: [
            { id: "g9-ar", name: "اللغة العربية", ico: "📖", bookTitle: "اللغة العربية — الصف التاسع الأساسي", totalPages: 184, officialUrl: "https://elearn.edu.ps/c9/", units: ["الفصل 1: سفينة الرحمة، ولد الهدى، من ذاكرة جدي، الموت المتربص على الطرقات، التعليم المهني رفعة وتميز، هجرة النورس، الميزان الصرفي، المجرد والمزيد، المصادر، الإيجاز والإطناب، حذف ألف ما الاستفهامية", "الفصل 2: أطيب ما تأكلون، صفد حصن الجليل، سنرجع يوماً، قناص يخطف بصره، المفعول به وفيه والمطلق، التقسيم، همزة الوصل والقطع"], rules: ["الميزان الصرفي للكلمة الثلاثية هو (فَعَلَ)، وتُقاس الزيادات بإثبات حروف الزيادة في مواضعها."] },
            { id: "g9-math", name: "الرياضيات", ico: "📐", bookTitle: "الرياضيات — الصف التاسع الأساسي", totalPages: 180, officialUrl: "https://elearn.edu.ps/c9/", units: ["الفصل 1: الأعداد الحقيقية والعمليات عليها، القيمة المطلقة، الأسس، الضرب الديكارتي، العلاقات، الاقتران الخطي وتركيب الاقترانات والعكسي", "الفصل 2: النسب المثلثية الأساسية والثانوية والمعادلات المثلثية، الفترات والمتباينات الخطية بمتغير وبمتغيرين، كثيرات الحدود والاقتران التربيعي والنسبي"], rules: ["الاقتران التربيعي ق(س) = أس² + ب س + جـ إحداثي رأس القطع المكافئ له هو س = -ب / (2أ)."] },
            { id: "g9-sci", name: "العلوم والحياة", ico: "🔬", bookTitle: "العلوم والحياة — الصف التاسع الأساسي", totalPages: 168, officialUrl: "https://elearn.edu.ps/c9/", units: ["الفصل 1: الجهاز الهضمي والتنفسي والدوراني والليمفي، التيار والدارات والمقاومات وقانون أوم وفرق الجهد", "الفصل 2: الجدول الدوري، الروابط وتمثيل لويس، أنواع التفاعلات الكيميائية، التأكسد والاختزال"], rules: ["قانون أوم: فرق الجهد (جـ) = شدة التيار (ت) × المقاومة (م)."] },
            { id: "g9-en", name: "اللغة الإنجليزية (English 9)", ico: "🔤", bookTitle: "English for Palestine — Pupil's Book 9", totalPages: 128, officialUrl: "https://elearn.edu.ps/c9/", units: ["Semester 1 (Units 1–7): Present perfect continuous, Relative clauses, Future forms", "Semester 2 (Units 8–14): Reported questions, Modals of deduction, Passive tenses"], rules: ["Use who/which/that to join relative clauses clearly."] },
            { id: "g9-isl", name: "التربية الإسلامية والتلاوة", ico: "🕌", bookTitle: "التربية الإسلامية — الصف التاسع الأساسي", totalPages: 128, officialUrl: "https://elearn.edu.ps/c9/", units: ["الفصل 1: علوم القرآن والوقف والابتداء", "الفصل 2: الفقه المقارن والسيرة والقيم"], rules: ["الوقف التام هو الوقف على كلام تم معناه ولم يتعلق بما بعده لفظاً ولا معنى."] },
            { id: "g9-soc", name: "الدراسات الاجتماعية", ico: "🌍", bookTitle: "الدراسات الاجتماعية — الصف التاسع الأساسي", totalPages: 126, officialUrl: "https://elearn.edu.ps/c9/", units: ["الفصل 1: الجغرافيا البشرية والسكان في فلسطين", "الفصل 2: تاريخ فلسطين المعاصر والقضية الفلسطينية"], rules: ["التمسك بالهوية الوطنية وحق العودة والقدس عاصمة دولة فلسطين."] },
            { id: "g9-tech", name: "التكنولوجيا والبرمجة", ico: "💻", bookTitle: "التكنولوجيا والبرمجة — الصف التاسع الأساسي", totalPages: 112, officialUrl: "https://elearn.edu.ps/c9/", units: ["الوحدة 1: البرمجة بلغة Python / الجافاسكربت التمهيدية", "الوحدة 2: الروبوت والتحكم الآلي والمشاريع الذكية"], rules: ["المستشعرات (Sensors) تنقل البيانات من البيئة المحيطة إلى وحدة المعالجة لاتخاذ القرار."] }
          ]}]
        }
      ]
    },
    {
      id: "stage-secondary",
      name: "المرحلة الثانوية والتوجيهي (الصفوف 10 – 12)",
      shortName: "الثانوية والتوجيهي (10–12)",
      ico: "🎓",
      desc: "المنهاج الفلسطيني الرسمي للثانوية العامة (التوجيهي) من موقع وزارة التربية والتعليم العالي moe.edu.ps",
      color: "from-indigo-600 to-purple-800",
      grades: [
        {
          id: "g10",
          name: "الصف العاشر الأساسي",
          officialPortal: "https://elearn.edu.ps/",
          branches: [{ id: "g10-gen", name: "المسار الأكاديمي والمهني", subjects: [
            { id: "g10-math", name: "الرياضيات", ico: "📐", bookTitle: "الرياضيات — الصف العاشر الأساسي (المسار الأكاديمي — الفصل الأول والثاني)", totalPages: 186, officialUrl: "https://elearn.edu.ps/c10/ma10-p1/", units: ["الفصل 1 — الوحدة 1 (الاقترانات): الاقتران الزوجي والفردي، الانسحاب والانعكاس، إشارة الاقتران، حل المتباينات، متعددة القاعدة، القيمة المطلقة", "الفصل 1 — الوحدة 2 (الأسس واللوغاريتمات): الأسس واللوغاريتمات، الاقتران الأسي، الاقتران اللوغاريتمي", "الفصل 1 — الوحدة 3 (الإحصاء والاحتمالات): الارتباط الخطي، معامل بيرسون وسبيرمان، الانحدار الخطي البسيط، مبدأ العد، التباديل، التوافيق، نظرية ذات الحدين", "الفصل 2 — الوحدة 4 (الاقترانات المثلثية): الزاوية في الوضع القياسي، قياس الزوايا، الاقترانات المثلثية وتمثيلها بيانياً، المتطابقات والمعادلات المثلثية", "الفصل 2 — الوحدة 5 (الهندسة): تكافؤ الأشكال الهندسية، الإنشاءات الهندسية"], rules: ["المتطابقة المثلثية الأساسية: جا²(هـ) + جتا²(هـ) = 1، ومعامل بيرسون يقيس قوة الارتباط الخطي بين متغيرين."] },
            { id: "g10-phys", name: "الفيزياء", ico: "⚡", bookTitle: "الفيزياء — الصف العاشر الأساسي (الفصل الأول والثاني)", totalPages: 152, officialUrl: "https://elearn.edu.ps/c10/py10/", units: ["الوحدة 1 (الميكانيكا): الفيزياء والقياس، المتجهات، وصف الحركة ومعادلات الحركة بتسارع ثابت، قوانين نيوتن للحركة، الحركة في مجال الجاذبية الأرضية", "الوحدة 2 (الموائع): الموائع السكونية والضغط، ضغط السائل، قاعدة باسكال، قاعدة أرخميدس للأجسام الطافية والمغمورة، قوانين الغازات", "الوحدة 3 (الحرارة): كمية الحرارة ودرجة الحرارة وموازين الحرارة، تمدد المواد بالحرارة، الاتزان الحراري، الحرارة الكامنة للانصهار والتصعيد"], rules: ["معادلات الحركة بتسارع ثابت: ع₂ = ع₁ + ت·ز ، ف = ع₁·ز + ½·ت·ز² ، ع₂² = ع₁² + 2·ت·ف."] },
            { id: "g10-chem", name: "الكيمياء", ico: "🧪", bookTitle: "الكيمياء — الصف العاشر الأساسي (الفصل الأول والثاني)", totalPages: 144, officialUrl: "https://elearn.edu.ps/c10/", units: ["الوحدة 1 (بنية الذرة والعناصر الكيميائية): دالتون والمنهج العلمي، التفريغ الكهربائي وثومسون، النشاط الإشعاعي ورذرفورد، الكالسيوم، الكبريت، السيليكون", "الوحدة 2 (الحسابات الكيميائية): قوانين الاتحاد الكيميائي، الكتلة الذرية والنظائر، المول والكتلة المولية، النسبة المئوية، المعادلة الكيميائية الموزونة", "الوحدة 3 (الماء والمحاليل): تركيب الماء، الماء مذيب جيد ووسط التفاعلات، عسر الماء، تلوث الماء"], rules: ["عدد المولات (n) = الكتلة بالغرام (m) ÷ الكتلة المولية (M)."] },
            { id: "g10-bio", name: "العلوم الحياتية", ico: "🧬", bookTitle: "العلوم الحياتية — الصف العاشر الأساسي", totalPages: 138, officialUrl: "https://elearn.edu.ps/c10/", units: ["الوحدة 1 (الخلية — تركيب وعمليات): المجاهر، تركيب الخلية الحيوانية والنباتية والعضيات، النقل عبر الغشاء الخلوي", "الوحدة 2 (أسس علم التصنيف وتصنيف الكائنات الحية): التصنيف الحديث، البدائيات، الطلائعيات، الفطريات، النباتات، الحيوانات"], rules: ["الخلية هي وحدة البناء والوظيفة الأساسية في الكائنات الحية، وينظم الغشاء الخلوي مرور المواد إليها."] },
            { id: "g10-ar", name: "اللغة العربية", ico: "📖", bookTitle: "اللغة العربية — الصف العاشر الأساسي (الجزء الأول 152 ص + الجزء الثاني 148 ص)", totalPages: 300, officialUrl: "https://elearn.edu.ps/c10/", units: ["الجزء 1 (الوحدات 1–3): (1) آيات من سورة إبراهيم / الحال 1 / التشبيه 1 / المقالة • (2) القدس روح فلسطين / مرثية بيت المقدس / الحال 2 / الكتابة العروضية / التاء والهاء • (3) السلامة المهنية / مرارة أب / النداء 1 / التشبيه 2 / كتابة كلمة", "الجزء 1 (الوحدات 4–6): (4) ساحة الحناطير / النداء 2 / المقاطع الصوتية / همزة ابن • (5) شجرة التين المباركة / أغنية ريفية / اسما الزمان والمكان / السيرة الذاتية • (6) صلاح الدين الأيوبي / بكائية إلى أبي فراس / الحروف المزيدة وعلامات الترقيم", "الجزء 1 (الوحدات 7–9): (7) مستودع الذخائر / اسم الآلة / محضر الاجتماع • (8) كلمة شرف / معاني زيادات الأفعال بحرف / التفعيلات • (9) سور عكا.. صمود وتحدٍّ / هنا باقون / الزيادة بحرفين أو أكثر / الألف اللينة والهمزة المتوسطة", "الجزء 2 (الدروس 1–5): (1) أحاديث نبوية شريفة / الاستثناء 1 / الخبر والإنشاء / التقرير • (2) مجزرة الطنطورة / دير ياسين / الاستثناء 2 • (3) عناقيد عنب / الإنشاء الطلبي وغير الطلبي / بحر الهزج / ألف ما الاستفهامية / القصة القصيرة • (4) نملٌ.. ونحلٌ / بنا افتخر الزمان / معاني حروف الجر • (5) آثارنا / اسم التفضيل / الهمزة المتوسطة والألف المقصورة", "الجزء 2 (الدروس 6–9): (6) هكذا لقي الله عمر / يا ليل الصب / البحر المحدث / كتابة قصة قصيرة • (7) الفيسبوك / التصغير / النون والتنوين • (8) جدار الضم والتوسع / سائل العلياء / النسب / عرافة حفل • (9) هند طاهر الحسيني / إنسان فلسطين / عرافة حفل"], rules: ["عروض العاشر (ف1+ف2): الكتابة العروضية، المقاطع الصوتية، التفعيلات، بحر الهزج (مَفَاعِيلُنْ)، والبحر المحدث/المتدارك (فَعِلُنْ).", "النحو والصرف (ف1+ف2): الحال، النداء، اسما الزمان والمكان، اسم الآلة، معاني زيادات الأفعال، الاستثناء، حروف الجر، اسم التفضيل، التصغير، والنسب."] },
            { id: "g10-en", name: "اللغة الإنجليزية (English 10)", ico: "🔤", bookTitle: "English for Palestine — Pupil's Book 10", totalPages: 136, officialUrl: "https://elearn.edu.ps/c10/", units: ["Semester 1: Present & Past tenses, Modal verbs, Reading comprehension", "Semester 2: Conditionals, Passive voice, Reported speech"], rules: ["Use modal verbs of obligation and advice (should, ought to, must, have to) accurately."] },
            { id: "g10-isl", name: "التربية الإسلامية", ico: "🕌", bookTitle: "التربية الإسلامية — الصف العاشر الأساسي", totalPages: 130, officialUrl: "https://elearn.edu.ps/c10/", units: ["الفصل 1: التفسير وعلوم الحديث والعقيدة", "الفصل 2: الفقه المعاصر والسيرة والقيم"], rules: ["السنة النبوية هي المصدر الثاني للتشريع الإسلامي بعد القرآن الكريم."] },
            { id: "g10-tech", name: "التكنولوجيا", ico: "💻", bookTitle: "التكنولوجيا — الصف العاشر الأساسي", totalPages: 116, officialUrl: "https://elearn.edu.ps/c10/", units: ["الوحدة 1: المعلومات الرقمية في قواعد البيانات (الجداول، الاستعلامات، النماذج، التقارير)", "الوحدة 2: الاتصالات والشبكات (الاتصالات اللاسلكية)", "الوحدة 3: تكنولوجيا الروبوت والاستشعار"], rules: ["المفتاح الأساسي (Primary Key) يميز كل سجل في جدول قاعدة البيانات بشكل فريد."] },
            { id: "g10-geo", name: "جغرافية فلسطين وتاريخها", ico: "🌍", bookTitle: "جغرافية فلسطين وتاريخها — الصف العاشر الأساسي (المسار الأكاديمي)", totalPages: 148, officialUrl: "https://elearn.edu.ps/c10/ge10-p1/", units: ["الفصل 1: جغرافية فلسطين الطبيعية والبشرية والموارد المائية والأقاليم المناخية", "الفصل 2: تاريخ فلسطين الحديث والمعاصر وقضايا الأرض والسكان"], rules: ["تنوع الأقاليم المناخية في فلسطين بين مناخ البحر المتوسط والمناخ شبه الصحراوي والصحراوي."] }
          ]}]
        },
        {
          id: "g11",
          name: "الصف الحادي عشر (الأول ثانوي)",
          officialPortal: "https://elearn.edu.ps/",
          branches: [
            {
              id: "g11-sci",
              name: "الفرع العلمي والصناعي",
              subjects: [
                { id: "g11s-math", name: "الرياضيات (العلمي)", ico: "📐", bookTitle: "الرياضيات — الحادي عشر العلمي", totalPages: 192, officialUrl: "https://elearn.edu.ps/c11/11s/ma11-sp1/", units: ["الفصل 1: المتجهات والهندسة الفراغية والمنطق الرياضي والمعادلات", "الفصل 2: المتتاليات والنهايات والاتصال والاحتمالات"], rules: ["الضرب النقطي لمتجهين أ · ب = |أ| |ب| جتا(هـ)، ويتعامد المتجهان إذا كان حاصل ضربهما النقطي صفراً."] },
                { id: "g11s-phys", name: "الفيزياء (العلمي)", ico: "⚡", bookTitle: "الفيزياء — الحادي عشر العلمي", totalPages: 176, officialUrl: "https://elearn.edu.ps/c11/11s/cur11s/", units: ["الفصل 1: المتجهات والاتزان الميكانيكي وقوانين نيوتن والشغل والطاقة", "الفصل 2: المجال الكهربائي والجهد والمواسعات والديناميكا الحرارية"], rules: ["نظرية الشغل-الطاقة: الشغل الكلي المبذول يساوي التغير في الطاقة الحركية (W_total = ΔEk)."] },
                { id: "g11s-chem", name: "الكيمياء (العلمي)", ico: "🧪", bookTitle: "الكيمياء — الحادي عشر العلمي", totalPages: 164, officialUrl: "https://elearn.edu.ps/c11/11s/cur11s/", units: ["الفصل 1: الروابط والأشكال الهندسية للجزيئات والمحاليل", "الفصل 2: الكيمياء الحرارية وسرعة التفاعل والاتزان"], rules: ["التركيز المولاري (M) = عدد مولات المذاب (mol) ÷ حجم المحلول باللتر (L)."] },
                { id: "g11s-bio", name: "العلوم الحياتية", ico: "🧬", bookTitle: "العلوم الحياتية — الحادي عشر العلمي", totalPages: 158, officialUrl: "https://elearn.edu.ps/c11/11s/cur11s/", units: ["الفصل 1: التركيب الكيميائي للخلية والإنزيمات", "الفصل 2: التنفس الخلوي والبناء الضوئي والانقسام الخلوي"], rules: ["تعمل الإنزيمات كعوامل مساعدة حيوية تقلل طاقة التنشيط للتفاعلات."] },
                { id: "g11s-ar", name: "المطالعة والقواعد والعروض", ico: "📖", bookTitle: "اللغة العربية — الحادي عشر العلمي", totalPages: 168, officialUrl: "https://elearn.edu.ps/c11/11s/ar11-s1p1/", units: ["الفصل 1: النصوص الأدبية والممنوع من الصرف والبحر الطويل", "الفصل 2: القواعد الصرفية والنحوية والعروض"], rules: ["الممنوع من الصرف يُجر بالفتحة نيابة عن الكسرة ما لم يُعرّف بـ(أل) أو يُضف."] },
                { id: "g11s-en", name: "اللغة الإنجليزية (English 11)", ico: "🔤", bookTitle: "English for Palestine — Pupil's Book 11", totalPages: 140, officialUrl: "https://elearn.edu.ps/c11/11s/", units: ["Semester 1: Learning styles, Education, Present/Past Perfect", "Semester 2: Science & Technology, Global trade, Passive structures"], rules: ["Use Present Perfect Continuous to emphasize duration of an ongoing action."] },
                { id: "g11s-isl", name: "التربية الإسلامية (11)", ico: "🕌", bookTitle: "التربية الإسلامية — الصف الحادي عشر", totalPages: 132, officialUrl: "https://elearn.edu.ps/c11/11s/", units: ["الفصل 1: التفسير والحديث والعقيدة", "الفصل 2: الفقه المعاصر والأخلاق الإسلامية"], rules: ["التكافل الاجتماعي والعدل من ركائز النظام الاقتصادي والاجتماعي في الإسلام."] },
                { id: "g11s-tech", name: "التكنولوجيا (11 العلمي)", ico: "💻", bookTitle: "التكنولوجيا — الحادي عشر العلمي", totalPages: 120, officialUrl: "https://elearn.edu.ps/c11/11s/", units: ["الوحدة 1: التصميم الهندسي والوسائط المتعددة", "الوحدة 2: البرمجة والخوارزميات المتقدمة"], rules: ["التصميم الهندسي بمساعدة الحاسوب (CAD) يرفع دقة النمذجة قبل التنفيذ."] }
              ]
            },
            {
              id: "g11-lit",
              name: "الفرع الأدبي والشرعي",
              subjects: [
                { id: "g11l-ar", name: "اللغة العربية والأدب", ico: "📖", bookTitle: "اللغة العربية والأدب — الحادي عشر الأدبي", totalPages: 196, officialUrl: "https://elearn.edu.ps/c11h/", units: ["الكتاب الأول: المطالعة والقواعد (الأساليب النحوية)", "الكتاب الثاني: تاريخ الأدب العربي والبلاغة والعروض"], rules: ["أسلوب الشرط يتكون من أداة الشرط وفعل الشرط وجواب الشرط."] },
                { id: "g11l-hist", name: "الدراسات التاريخية", ico: "🏛️", bookTitle: "الدراسات التاريخية — الحادي عشر الأدبي", totalPages: 168, officialUrl: "https://elearn.edu.ps/", units: ["الوحدة 1: حركات التحرر الوطني", "الوحدة 2: القضية الفلسطينية والتحولات الدولية"], rules: ["تحليل الوثائق التاريخية والتمييز بين الأسباب المباشرة وغير المباشرة."] },
                { id: "g11l-sci", name: "الثقافة العلمية (الأدبي)", ico: "🔬", bookTitle: "الثقافة العلمية — الحادي عشر الأدبي", totalPages: 132, officialUrl: "https://elearn.edu.ps/c11/11h/", units: ["الوحدة 1: الغذاء والصحة والأمراض", "الوحدة 2: التكنولوجيا والبيئة والطاقة"], rules: ["التغذية السليمة تعتمد على التوازن بين العناصر الغذائية والنشاط البدني."] },
                { id: "g11l-math", name: "الرياضيات (الأدبي)", ico: "📊", bookTitle: "الرياضيات — الحادي عشر الأدبي", totalPages: 144, officialUrl: "https://elearn.edu.ps/c11h/", units: ["الفصل 1: المتتاليات الحسابية والهندسية والمعادلات", "الفصل 2: الإحصاء والاحتمالات"], rules: ["الحد العام للمتتالية الحسابية: ح_ن = أ + (ن - 1) × د."] },
                { id: "g11l-geo", name: "الدراسات الجغرافية (11 الأدبي)", ico: "🌍", bookTitle: "الدراسات الجغرافية — الحادي عشر الأدبي", totalPages: 152, officialUrl: "https://elearn.edu.ps/c11/11h/", units: ["الوحدة 1: الجغرافيا الطبيعية والجيومورفولوجيا", "الوحدة 2: التعرية والتربة والموارد الطبيعية"], rules: ["تتشكل التضاريس بفعل العوامل الباطنية (الزلازل والبراكين) والعوامل الخارجية (التجوية والتعرية)."] },
                { id: "g11l-en", name: "English 11 + Reading Plus", ico: "🔤", bookTitle: "English 11 + Reading Plus — الحادي عشر الأدبي", totalPages: 164, officialUrl: "https://elearn.edu.ps/c11/11h/", units: ["Pupil's Book Units 1–10", "Reading Plus: Literature & Global Culture"], rules: ["Analyze literary themes, character motivation, and formal essay structure."] }
              ]
            },
            {
              id: "g11-sharia",
              name: "الفرع الشرعي (الحادي عشر)",
              subjects: [
                { id: "g11sh-quran", name: "القرآن الكريم وعلومه والتفسير", ico: "📗", bookTitle: "التفسير وعلوم القرآن — الحادي عشر الشرعي", totalPages: 152, officialUrl: "https://elearn.edu.ps/c11/", units: ["الفصل 1: علوم القرآن ونزول القرآن وجمعه", "الفصل 2: التفسير التحليلي والموضوعي للسور المقررة"], rules: ["القرآن الكريم نزل منجماً على مدى ثلاث وعشرين سنة تثبيتاً لفؤاد النبي ﷺ وتدرجاً في التشريع."] },
                { id: "g11sh-hadith", name: "الحديث الشريف وعلومه", ico: "📜", bookTitle: "الحديث الشريف — الحادي عشر الشرعي", totalPages: 144, officialUrl: "https://elearn.edu.ps/c11/", units: ["الفصل 1: تاريخ تدوين السنة النبوية ومصطلح الحديث", "الفصل 2: شرح الأحاديث النبوية في الآداب والمعاملات"], rules: ["السنة النبوية هي كل ما أُثر عن النبي ﷺ من قول أو فعل أو تقرير أو صفة."] },
                { id: "g11sh-fiqh", name: "الفقه الإسلامي", ico: "⚖️", bookTitle: "الفقه الإسلامي — الحادي عشر الشرعي", totalPages: 160, officialUrl: "https://elearn.edu.ps/c11/", units: ["الفصل 1: فقه العبادات والمعاملات المالية", "الفصل 2: البيوع والربا والقضاء والشهادات"], rules: ["الأصل في المعاملات الإباحة ما لم يرد دليل شرعي على التحريم."] },
                { id: "g11sh-aqidah", name: "العقيدة الإسلامية والسيرة", ico: "🕌", bookTitle: "العقيدة الإسلامية — الحادي عشر الشرعي", totalPages: 140, officialUrl: "https://elearn.edu.ps/c11/", units: ["الفصل 1: الإيمان بالله وملائكته وكتبه ورسله", "الفصل 2: اليوم الآخر والقدر والسيرة النبوية"], rules: ["الإيمان قول باللسان واعتقاد بالقلب وعمل بالجوارح."] },
                { id: "g11sh-ar", name: "اللغة العربية (المطالعة والقواعد والأدب)", ico: "📖", bookTitle: "اللغة العربية — الحادي عشر الشرعي", totalPages: 168, officialUrl: "https://elearn.edu.ps/c11h/", units: ["الفصل 1: المطالعة والقواعد (اسم الفاعل والمفعول والصفة المشبهة)", "الفصل 2: الأدب العربي القديم والبلاغة والعروض"], rules: ["المشتقات تعمل عمل أفعالها بشروط الاعتماد على نفي أو استفهام أو موصوف."] },
                { id: "g11sh-math", name: "الرياضيات (الأدبي والشرعي)", ico: "📐", bookTitle: "الرياضيات — الحادي عشر الأدبي والشرعي", totalPages: 148, officialUrl: "https://elearn.edu.ps/c11h/", units: ["الفصل 1: المتغيرات العشوائية والتوزيع الطبيعي", "الفصل 2: المعادلات والمتسلسلات والمنطق الرياضي"], rules: ["المتتالية الحسابية يكون فيها الفرق بين كل حدين متتاليين مقداراً ثابتاً."] },
                { id: "g11sh-en", name: "اللغة الإنجليزية (English 11)", ico: "🔤", bookTitle: "English for Palestine — Pupil's Book 11", totalPages: 140, officialUrl: "https://elearn.edu.ps/c11h/", units: ["Semester 1: Learning Styles, Education & Communication", "Semester 2: Cultural Heritage, Technology & Environment"], rules: ["Use relative clauses and passive voice accurately in formal writing."] }
              ]
            },
            {
              id: "g11-ent",
              name: "فرع الريادة والأعمال",
              subjects: [
                { id: "g11e-acc", name: "المحاسبة (الريادي)", ico: "📒", bookTitle: "المحاسبة — الحادي عشر الريادي", totalPages: 160, officialUrl: "https://elearn.edu.ps/c11/11ri/", units: ["الفصل 1: الدورة المحاسبية ودفتر اليومية والأستاذ", "الفصل 2: ميزان المراجعة والقوائم المالية"], rules: ["المعادلة المحاسبية: الأصول = الالتزامات + حقوق الملكية."] },
                { id: "g11e-proj", name: "المشاريع الصغيرة", ico: "🚀", bookTitle: "المشاريع الصغيرة — الحادي عشر الريادي", totalPages: 140, officialUrl: "https://elearn.edu.ps/c11/11ri/", units: ["الوحدة 1: توليد الأفكار الريادية ودراسة الجدوى", "الوحدة 2: التسويق وإدارة المشروع الصغير"], rules: ["دراسة الجدوى تحدد مدى قابلية المشروع للنجاح فنياً ومالياً وتسويقياً."] }
              ]
            }
          ]
        },
        {
          id: "g12",
          name: "الصف الثاني عشر (التوجيهي — فلسطين)",
          officialPortal: "https://moe.edu.ps/class12/books",
          branches: [
            {
              id: "g12-sci",
              name: "الفرع العلمي (8 كتب وزارية رسمية)",
              subjects: [
                { id: "g12s-math", name: "الرياضيات (التوجيهي العلمي)", ico: "📐", bookTitle: "الرياضيات — الصف الثاني عشر العلمي (كتاب الوزارة الرسمي)", totalPages: 210, officialUrl: "https://elearn.edu.ps/c12/12s/ma12-s/", units: ["الوحدة الأولى: حساب التفاضل (متوسط التغير، قواعد الاشتقاق، مشتقة الاقترانات المثلثية، قاعدة لوبيتال)", "الوحدة الثانية: تطبيقات التفاضل (القيم القصوى، التزايد والتناقص، التقعر ونقاط الانعطاف)", "الوحدة الثالثة: المصفوفات والمحددات (العمليات، النظير الضربي، حل الأنظمة)", "الوحدة الرابعة: التكامل غير المحدود وتطبيقاته", "الوحدة الخامسة: التكامل المحدود وتطبيقاته (المساحات والحجوم)", "الوحدة السادسة: الأعداد المركبة"], rules: ["متوسط التغير Δص/Δس = (ق(س₂) - ق(س₁)) / (س₂ - س₁)، والمشتقة الأولى ق'(س) تمثل ميل المماس لمنحنى الاقتران.", "النظرية الأساسية في التفاضل والتكامل: ∫ من أ إلى ب لـ ق(س) دس = م(ب) - م(أ) حيث م'(س) = ق(س)."] },
                { id: "g12s-phys", name: "الفيزياء (التوجيهي العلمي)", ico: "⚡", bookTitle: "الفيزياء — الصف الثاني عشر العلمي (كتاب الوزارة الرسمي 2025)", totalPages: 184, officialUrl: "https://moe.edu.ps/storage/app/class12/Physics12%202025%20Tawjihi.pdf", units: ["الوحدة الأولى — الميكانيكا: الفصل 1 (الزخم الخطي والدفع) والفصل 2 (التصادمات) والفصل 3 (الحركة الدورانية)", "الوحدة الثانية — الكهرباء المتحركة: التيار والمقاومة، القوة الدافعة، ودارات التيار المستمر وقواعد كيرشوف", "الوحدة الثالثة — الكهرومغناطيسية: المجال المغناطيسي، القوة المغناطيسية، والحث الكهرومغناطيسي (فاراداي ولنز)", "الوحدة الرابعة — الفيزياء الحديثة: نظرية الكم، الأطياف الذرية، والفيزياء النووية"], rules: ["الزخم الخطي p = m·v، والدفع I = F·Δt = Δp، وفي النظام المعزول يكون الزخم الخطي الكلي محفوظاً.", "قانون فاراداي في الحث الكهرومغناطيسي: القوة الدافعة الحثية ε = -N · (ΔΦ_B / Δt) وتُعبّر الإشارة السالبة عن قانون لنز."] },
                { id: "g12s-chem", name: "الكيمياء (التوجيهي العلمي)", ico: "🧪", bookTitle: "الكيمياء — الصف الثاني عشر العلمي (كتاب الوزارة الرسمي 2025)", totalPages: 176, officialUrl: "https://moe.edu.ps/storage/app/class12/Chemistry12%202025%20Tawjihi%20Elmi.pdf", units: ["الوحدة الأولى: البناء الإلكتروني للذرة", "الوحدة الثانية: الصفات الدورية ونظرية رابطة التكافؤ", "الوحدة الثالثة: الحموض والقواعد (حسابات pH والمحاليل المنظمة)", "الوحدة الرابعة: الديناميكا الحرارية وسرعة التفاعل", "الوحدة الخامسة: الكيمياء العضوية", "الوحدة السادسة: الخلايا الكهروكيميائية"], rules: ["الرقم الهيدروجيني pH = -log₁₀[H₃O⁺]، وحاصل التأين للماء Kw = [H₃O⁺][OH⁻] = 1×10⁻¹⁴ عند 25°C.", "في الخلايا الجلفانية يحدث التأكسد عند المصعد (القطب السالب) والاختزال عند المهبط (القطب الموجب)."] },
                { id: "g12s-bio", name: "الأحياء / العلوم الحياتية (التوجيهي العلمي)", ico: "🧬", bookTitle: "العلوم الحياتية — الصف الثاني عشر العلمي (كتاب الوزارة الرسمي 2025)", totalPages: 168, officialUrl: "https://moe.edu.ps/storage/app/class12/Biology12%202025%20Tawjihi%20Elmi.pdf", units: ["الوحدة الأولى: عمليات حيوية في الخلية (تدفق الطاقة، البناء الضوئي، التنفس الخلوي، بناء البروتين)", "الوحدة الثانية: الوراثة (الوراثة المندلية، الصفات غير المندلية: السيادة المشتركة والأليلات المتعددة والارتباط والعبور)", "الوحدة الثالثة: أجهزة جسم الإنسان (الجهاز العصبي، الإحساس، الجهاز المناعي، والجهاز العضلي)"], rules: ["المرحلة الضوئية في البناء الضوئي تحدث في أغشية الثايلاكويد وتنتج ATP وNADPH وO₂، بينما تحدث حلقة كالفن في الستروما.", "عملية بناء البروتين تمر بمرحلتي النسخ (Transcription) في النواة والترجمة (Translation) على الرايبوسومات."] },
                { id: "g12s-ar", name: "اللغة العربية (المطالعة والقواعد والعروض والتعبير)", ico: "📖", bookTitle: "اللغة العربية — الصف الثاني عشر العلمي (كتاب الوزارة الرسمي)", totalPages: 180, officialUrl: "https://moe.edu.ps/class12/books", units: ["الفصل 1: آيات من سورة يوسف، غروب الأندلس، القدس بوصلة ومجد، رسالة إلى صديق قديم، الممنوع من الصرف، البحر الوافر والبسيط", "الفصل 2: المدينة المحاصرة، جفرا الوطن المسبي، مرافعات أمام ضمير غائب، وصية لاجئ، الإعلال والإبدال، معاني حروف الجر و(ما، من، الفاء، الواو)، البحر الطويل"], rules: ["يُجرّ الاسم الممنوع من الصرف بالفتحة عوضاً عن الكسرة ما لم يُعرّف بـ (أل) أو يُضف.", "الإعلال هو تغيير يطرأ على حرف العلة (قلب، تسكين، حذف) لتخفيف النطق، والإبدال جعل حرف مكان آخر."] },
                { id: "g12s-en", name: "اللغة الإنجليزية (Pupil's Book 12)", ico: "🔤", bookTitle: "English for Palestine — Pupil's Book 12 (كتاب الوزارة الرسمي)", totalPages: 152, officialUrl: "https://moe.edu.ps/class12/books", units: ["Semester 1 (Units 1–5): A New Start, Under Pressure, A Funny Thing Happened, The Shrinking World, Making Friends", "Semester 2 (Units 7–11): The World of Work, In Business, Only a Game?, Who Am I?, Different Places Different Ways"], rules: ["Distinguish between verbs followed by infinitive (to + V) and gerund (V-ing) in Units 2 and 5.", "Use modal verbs, past tenses, and reported speech accurately in academic writing."] },
                { id: "g12s-tech", name: "التكنولوجيا (التوجيهي العلمي)", ico: "💻", bookTitle: "التكنولوجيا — الصف الثاني عشر العلمي (كتاب الوزارة الرسمي)", totalPages: 134, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: قواعد البيانات العلائقية (SQL، الجداول، الاستعلامات، النماذج والتقارير)", "الوحدة 2: برمجة تطبيقات الهواتف الذكية (App Inventor)", "الوحدة 3: شبكات الحاسوب (نموذج OSI، عنونة IP، التوجيه)", "الوحدة 4: الرسم الهندسي ثلاثي الأبعاد"], rules: ["يتكون عنوان IPv4 من 32 بت (4 خانات عشرية)، وتُستخدم جملة SELECT في SQL لاسترجاع البيانات."] },
                { id: "g12s-isl", name: "التربية الإسلامية (التوجيهي العلمي)", ico: "🕌", bookTitle: "التربية الإسلامية — الصف الثاني عشر (كتاب الوزارة الرسمي)", totalPages: 146, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1 (القرآن وعلومه): منهج القرآن في التربية، الاعتصام بالله، التحاكم إلى شرع الله", "الوحدة 2 (الحديث والعقيدة): الشرك بالله ظاهر وخفي، الأعمال التي لا ينقطع ثوابها، فقه الدعوة والجهاد، القائد صلاح الدين الأيوبي"], rules: ["التوحيد الخالص هو أساس العقيدة الإسلامية، والقرآن والسنة هما مصدرا التشريع الأساسيان."] }
              ]
            },
            {
              id: "g12-lit",
              name: "الفرع الأدبي (10 كتب وزارية رسمية)",
              subjects: [
                { id: "g12l-ar1", name: "اللغة العربية / المطالعة والقواعد", ico: "📖", bookTitle: "اللغة العربية 1 (المطالعة والقواعد والعروض) — الثاني عشر الأدبي", totalPages: 180, officialUrl: "https://moe.edu.ps/class12/books", units: ["الفصل 1: آيات من سورة يوسف، غروب الأندلس، القدس بوصلة ومجد، رسالة إلى صديق قديم، الممنوع من الصرف، البحر الوافر والبسيط", "الفصل 2: المدينة المحاصرة، جفرا الوطن المسبي، مرافعات أمام ضمير غائب، وصية لاجئ، الإعلال والإبدال، معاني حروف الجر، البحر الطويل"], rules: ["يُجرّ الاسم الممنوع من الصرف بالفتحة عوضاً عن الكسرة ما لم يُعرّف بـ (أل) أو يُضف."] },
                { id: "g12l-ar2", name: "اللغة العربية / الأدب والبلاغة", ico: "✍️", bookTitle: "اللغة العربية 2 (الأدب والبلاغة والنقد) — الثاني عشر الأدبي", totalPages: 165, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1–3: المدارس الشعرية الحديثة (الإحياء، الرومانسية، الشعر الحر) والأرض والثورة في الشعر الفلسطيني", "الوحدة 4–6: الفنون النثرية الحديثة (المقالة، القصة القصيرة، المسرحية) وعلم المعاني والبيان والبديع والنقد الأدبي"], rules: ["علم المعاني وعلم البيان وعلم البديع هي أقسام البلاغة العربية الثلاثة."] },
                { id: "g12l-hist", name: "الدراسات التاريخية", ico: "🏛️", bookTitle: "الدراسات التاريخية — الصف الثاني عشر الأدبي (كتاب الوزارة الرسمي)", totalPages: 188, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: الحروب والفتوحات عبر التاريخ (الحروب الفرنجية، الحرب العالمية الأولى، الحرب العالمية الثانية)", "الوحدة 2: الثورات وحركات التحرر الوطني (الثورة العربية، الحراك العربي، الإمبراطورية البريطانية)", "الوحدة 3: الهيمنة العالمية والانتفاضة الفلسطينية"], rules: ["المقارنة المنهجية بين الثورات وحركات التحرر من حيث الدوافع والوسائل والنتائج."] },
                { id: "g12l-geo", name: "الدراسات الجغرافية", ico: "🌍", bookTitle: "الدراسات الجغرافية — الصف الثاني عشر الأدبي (كتاب الوزارة الرسمي)", totalPages: 174, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: الجغرافيا المناخية وفلسطين نموذج لإقليم البحر المتوسط", "الوحدة 2: الموارد الطبيعية والنباتية والثروات المعدنية في فلسطين", "الوحدة 3: التصحر والكوارث الطبيعية والجيولوجية والسياحة والتخطيط"], rules: ["الألبيدو (Albedo) هو نسبة الأشعة الشمسية المنعكسة عن سطح الأرض والغلاف الجوي."] },
                { id: "g12l-math", name: "الرياضيات (الأدبي والشرعي)", ico: "📐", bookTitle: "الرياضيات — الصف الثاني عشر الأدبي والشرعي (كتاب الوزارة الرسمي 2025)", totalPages: 142, officialUrl: "https://moe.edu.ps/storage/app/class12/Math12Adabi%202025%20Tawjihi.pdf", units: ["الوحدة 1: التفاضل (متوسط التغير، المشتقة الأولى، قواعد الاشتقاق، القيم القصوى)", "الوحدة 2: المصفوفات والعمليات عليها وحل الأنظمة بطريقة النظير الضربي وكريمر", "الوحدة 3: التكامل غير المحدود والمحدود", "الوحدة 4: المتسلسلات الحسابية والهندسية والإحصاء (العلامة المعيارية)"], rules: ["تكون المصفوفة المربعة منفردة إذا كان محددها يساوي صفراً، والعلامة المعيارية ع = (س - س̄) ÷ ع_معياري."] },
                { id: "g12l-scicult", name: "الثقافة العلمية (الأدبي)", ico: "🔬", bookTitle: "الثقافة العلمية — الصف الثاني عشر الأدبي (كتاب الوزارة الرسمي 2025)", totalPages: 130, officialUrl: "https://moe.edu.ps/storage/app/class12/Thaqafeh12%202025%20Tawjihi.pdf", units: ["الوحدة 1: التقانة الكيميائية (البوليمرات، الدهانات، المنظفات)", "الوحدة 2: الفيزياء الطبية (الألياف الضوئية والتصوير الطبي والأشعة)", "الوحدة 3: التقانة الحيوية والوراثة"], rules: ["البوليمرات جزيئات عملاقة تتكون من اتحاد وحدات صغيرة متكررة تسمى المونومرات، وتصنّع الألياف بطرق الصهر والجافة والرطبة."] },
                { id: "g12l-en", name: "English 12 (Pupil's Book)", ico: "🔤", bookTitle: "English for Palestine — Pupil's Book 12 (الأدبي)", totalPages: 152, officialUrl: "https://moe.edu.ps/class12/books", units: ["Semester 1 (Units 1–5): Stepping Outside Your Comfort Zone, Under Pressure, Communication Today, Making Friends", "Semester 2 (Units 7–11): The World of Work, In Business, Only a Game?, Who Am I?, Different Places"], rules: ["Reported speech tense backshifting, modal verbs of deduction, and formal essay writing."] },
                { id: "g12l-enplus", name: "English 12 (Reading Plus — Literature)", ico: "📘", bookTitle: "English 12 — Reading Plus (Romeo & Juliet) — الأدبي", totalPages: 112, officialUrl: "https://moe.edu.ps/class12/books", units: ["Units 1–3: New Beginnings, Money Talks, Cultural Perspectives", "Literature (Units 4–6): Shakespeare's Romeo and Juliet (Extracts 1–8 & Character Analysis)"], rules: ["Analyze dramatic irony, tragedy structure, and key themes in Shakespeare's Romeo and Juliet."] },
                { id: "g12l-isl", name: "التربية الإسلامية (الأدبي)", ico: "🕌", bookTitle: "التربية الإسلامية — الصف الثاني عشر (كتاب الوزارة الرسمي)", totalPages: 146, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: القرآن الكريم وعلومه (منهج القرآن في التربية، الاعتصام بالله، التحاكم إلى شرع الله)", "الوحدة 2: العقيدة والحديث الشريف والفقه (الشرك الظاهر والخفي، فقه الدعوة والجهاد، صلاح الدين الأيوبي)"], rules: ["منهج القرآن الكريم في ترسيخ العقيدة وبناء المجتمع المتكافل."] },
                { id: "g12l-tech", name: "التكنولوجيا (الأدبي)", ico: "💻", bookTitle: "التكنولوجيا — الصف الثاني عشر الأدبي (كتاب الوزارة الرسمي)", totalPages: 124, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: معالجة الجداول وقواعد البيانات", "الوحدة 2: تطبيقات الهواتف الذكية والوسائط المتعددة"], rules: ["تنظيم البيانات في جداول علاقية يسهل الاستعلام عنها وإصدار التقارير."] }
              ]
            },
            {
              id: "g12-sharia",
              name: "الفرع الشرعي (الكتب الشرعية والمشتركة)",
              subjects: [
                { id: "g12sh-quran", name: "القرآن الكريم وعلومه والتفسير", ico: "📗", bookTitle: "التفسير وعلوم القرآن — الثاني عشر الشرعي", totalPages: 164, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: أصول التفسير ومناهج المفسرين (التفسير بالمأثور والتفسير بالرأي)", "الوحدة 2: التفسير التحليلي والموضوعي لآيات الأحكام والعقيدة والأخلاق"], rules: ["التفسير بالمأثور يعتمد على تفسير القرآن بالقرآن والسنة وأقوال الصحابة والتابعين."] },
                { id: "g12sh-hadith", name: "الحديث الشريف وعلومه", ico: "📜", bookTitle: "الحديث الشريف وعلومه — الثاني عشر الشرعي", totalPages: 152, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: مصطلح الحديث (الصحيح، الحسن، الضعيف، المتواتر والآحاد)", "الوحدة 2: شرح الأحاديث النبوية المقررة في العبادات والمعاملات والأخلاق"], rules: ["الحديث الصحيح ما اتصل سنده بنقل العدل الضابط عن مثله إلى منتهاه من غير شذوذ ولا علة."] },
                { id: "g12sh-fiqh", name: "الفقه الإسلامي وأصوله", ico: "⚖️", bookTitle: "الفقه الإسلامي وأصوله — الثاني عشر الشرعي", totalPages: 176, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: فقه الأسرة والمعاملات المالية المعاصرة والميراث", "الوحدة 2: أصول الفقه ومقاصد الشريعة الإسلامية والاجتهاد"], rules: ["مقاصد الشريعة الضرورية الخمسة: حفظ الدين، والنفس، والعقل، والنسل، والمال."] },
                { id: "g12sh-aqidah", name: "العقيدة الإسلامية والسيرة", ico: "🕌", bookTitle: "العقيدة الإسلامية — الثاني عشر الشرعي", totalPages: 148, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: أركان الإيمان وتوحيد الألوهية والربوبية والأسماء والصفات", "الوحدة 2: قضايا العقيدة المعاصرة والمنهج النبوي في الدعوة"], rules: ["العقيدة الإسلامية تقوم على التسليم للوحي وإعمال العقل في دلائل التوحيد."] },
                { id: "g12sh-ar1", name: "اللغة العربية / المطالعة والقواعد", ico: "📖", bookTitle: "اللغة العربية 1 (المطالعة والقواعد) — الثاني عشر الشرعي", totalPages: 180, officialUrl: "https://moe.edu.ps/class12/books", units: ["الفصل 1: آيات من سورة يوسف، غروب الأندلس، القدس بوصلة ومجد، الممنوع من الصرف، البحر الوافر والبسيط", "الفصل 2: المدينة المحاصرة، وصية لاجئ، الإعلال والإبدال، معاني حروف الجر، البحر الطويل"], rules: ["يُجرّ الاسم الممنوع من الصرف بالفتحة عوضاً عن الكسرة ما لم يُعرّف بـ (أل) أو يُضف."] },
                { id: "g12sh-ar2", name: "اللغة العربية / الأدب والبلاغة", ico: "✍️", bookTitle: "اللغة العربية 2 (الأدب والبلاغة) — الثاني عشر الشرعي", totalPages: 165, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: المدارس الشعرية الحديثة والشعر الفلسطيني", "الوحدة 2: الفنون النثرية والبلاغة العربية (المعاني والبيان والبديع) والنقد"], rules: ["التشبيه والاستعارة والكناية هي مباحث علم البيان الأساسية."] },
                { id: "g12sh-hist", name: "الدراسات التاريخية", ico: "🏛️", bookTitle: "الدراسات التاريخية — الثاني عشر الشرعي", totalPages: 188, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: الحروب والفتوحات الإسلامية والحروب الفرنجية", "الوحدة 2: الثورات وحركات التحرر والانتفاضة الفلسطينية"], rules: ["فهم السياق التاريخي والسببي للأحداث يرسخ التحليل المنهجي."] },
                { id: "g12sh-math", name: "الرياضيات (الأدبي والشرعي)", ico: "📐", bookTitle: "الرياضيات — الثاني عشر الأدبي والشرعي (كتاب الوزارة الرسمي 2025)", totalPages: 142, officialUrl: "https://moe.edu.ps/storage/app/class12/Math12Adabi%202025%20Tawjihi.pdf", units: ["الوحدة 1: التفاضل وتطبيقاته", "الوحدة 2: المصفوفات والنظير الضربي وكريمر", "الوحدة 3–4: التكامل والمتسلسلات والإحصاء"], rules: ["العلامة المعيارية ع = (س - س̄) ÷ ع_معياري."] },
                { id: "g12sh-en", name: "اللغة الإنجليزية (Pupil's Book 12)", ico: "🔤", bookTitle: "English for Palestine — Pupil's Book 12 (الشرعي)", totalPages: 152, officialUrl: "https://moe.edu.ps/class12/books", units: ["Units 1–11: Core Reading, Grammar, Vocabulary & Essay Writing"], rules: ["Master reported speech, modals, and structured paragraph writing."] },
                { id: "g12sh-tech", name: "التكنولوجيا (الشرعي)", ico: "💻", bookTitle: "التكنولوجيا — الثاني عشر الشرعي (كتاب الوزارة الرسمي)", totalPages: 124, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: الجداول وقواعد البيانات", "الوحدة 2: تطبيقات الهواتف الذكية والوسائط"], rules: ["تنظيم البيانات في جداول علاقية يسهل الاستعلام عنها وإصدار التقارير."] }
              ]
            },
            {
              id: "g12-biz",
              name: "فرع الريادة والأعمال",
              subjects: [
                { id: "g12b-proj", name: "المشاريع الصغيرة", ico: "💼", bookTitle: "المشاريع الصغيرة — الثاني عشر (الريادة والأعمال)", totalPages: 156, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: التخطيط الريادي ودراسة الجدوى التسويقية والفنية والمالية", "الوحدة 2: تشغيل المشروع وإدارة المخاطر ونقطة التعادل"], rules: ["نقطة التعادل هي حجم المبيعات الذي تتساوى عنده الإيرادات الكلية مع التكاليف الكلية."] },
                { id: "g12b-acc", name: "المحاسبة المالية", ico: "📊", bookTitle: "المحاسبة — الثاني عشر (الريادة والأعمال)", totalPages: 168, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: محاسبة شركات التضامن", "الوحدة 2: الشركات المساهمة العامة والقوائم المالية"], rules: ["معادلة الميزانية الأساسية: الأصول = الالتزامات + حقوق الملكية."] },
                { id: "g12b-ar", name: "اللغة العربية والتربية الإسلامية والتكنولوجيا (المشترك)", ico: "📖", bookTitle: "المباحث المشتركة — الثاني عشر (الريادة والأعمال)", totalPages: 160, officialUrl: "https://moe.edu.ps/class12/books", units: ["اللغة العربية (المطالعة والقواعد)", "التربية الإسلامية", "التكنولوجيا"], rules: ["تتكامل المباحث المشتركة مع مباحث التخصص الريادي في امتحان الثانوية العامة."] },
                { id: "g12b-math", name: "الرياضيات (الريادة والأعمال)", ico: "📐", bookTitle: "الرياضيات — الثاني عشر الريادي (كتاب الوزارة الرسمي)", totalPages: 142, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: التفاضل وتطبيقاته الاقتصادية", "الوحدة 2: المصفوفات والتكامل والإحصاء"], rules: ["الربح الحدي = الإيراد الحدي - التكلفة الحدية."] },
                { id: "g12b-en", name: "اللغة الإنجليزية (الريادة والأعمال)", ico: "🔤", bookTitle: "English for Palestine 12 — الريادة والأعمال", totalPages: 152, officialUrl: "https://moe.edu.ps/class12/books", units: ["Units 1–11: Business Communication, Careers & Global Trade"], rules: ["Use formal business register in proposals, emails, and reports."] }
              ]
            },
            {
              id: "g12-ind",
              name: "الفرع الصناعي (كتب الوزارة الرسمية)",
              subjects: [
                { id: "g12i-elec", name: "الإلكترونيات الصناعية", ico: "🔌", bookTitle: "الإلكترونيات الصناعية — الثاني عشر الصناعي", totalPages: 148, officialUrl: "https://moe.edu.ps/storage/app/gaza/ProfessionalBranchesGuidancePackages/Industrial/Industrial_science/%D8%A7%D9%84%D9%83%D8%AA%D8%B1%D9%88%D9%86%D9%8A%D8%A7%D8%AA%20%D8%B5%D9%86%D8%A7%D8%B9%D9%8A%D8%A9.pdf", units: ["الوحدة 1: الترانزستور أحادي الوصلة (UJT) والثايرستور", "الوحدة 2: دارات القدح والمذبذبات والتحكم الصناعي"], rules: ["الثايرستور عنصر إلكتروني شبه موصل يعمل كمفتاح قدرة يتحكم بتشغيله تيار البوابة."] },
                { id: "g12i-auto", name: "ميكانيك السيارات والعلوم المهنية", ico: "⚙️", bookTitle: "ميكانيك السيارات — الثاني عشر الصناعي", totalPages: 152, officialUrl: "https://moe.edu.ps/storage/app/gaza/ProfessionalBranchesGuidancePackages/Industrial/Industrial_science/%D9%85%D9%8A%D9%83%D8%A7%D9%86%D9%8A%D9%83%20%D8%B3%D9%8A%D8%A7%D8%B1%D8%A7%D8%AA.pdf", units: ["الوحدة 1: أنظمة نقل الحركة والقوابض والتروس التفاضلية", "الوحدة 2: دوائر الشحن والأنظمة الإلكترونية (Mechatronics)"], rules: ["ينقل الترس التفاضلي عزم الدوران إلى العجلات مع السماح باختلاف سرعتها عند المنعطفات."] },
                { id: "g12i-isl", name: "التربية الإسلامية (الصناعي)", ico: "🕌", bookTitle: "التربية الإسلامية — الثاني عشر الصناعي (كتاب الوزارة الرسمي)", totalPages: 146, officialUrl: "https://moe.edu.ps/class12/books", units: ["الوحدة 1: القرآن الكريم وعلومه والحديث الشريف", "الوحدة 2: العقيدة والفقه والسيرة النبوية"], rules: ["مقاصد الشريعة الخمسة: حفظ الدين والنفس والعقل والنسل والمال."] }
              ]
            }
          ]
        }
      ]
    },
    {
      id: "stage-university",
      name: "المرحلة الجامعية والتأهيل المهني",
      shortName: "الجامعية والـ CV",
      ico: "🏛️",
      desc: "تصميم السيرة الذاتية الاحترافية (CV عربي/English)، الأبحاث الجامعية وتوثيق المراجع، ومهارات التوظيف",
      color: "from-amber-600 to-orange-700",
      grades: [
        {
          id: "uni-cv-career",
          name: "السيرة الذاتية الاحترافية (CV عربي + English) والتأهيل الوظيفي",
          branches: [{ id: "uni-cv-br", name: "مسار التوظيف والمنح", subjects: [
            { id: "uni-sub-cv", name: "منشئ السيرة الذاتية الاحترافية ATS (عربي + English)", ico: "📄", bookTitle: "دليل بناء السيرة الذاتية الاحترافية المتوافقة مع ATS", totalPages: 95, studioTarget: "cvBuilderStudio", units: ["القسم 1: صياغة الملخص المهني والأكاديمي باللغتين العربية والإنجليزية", "القسم 2: إبراز المشاريع الجامعية والمهارات التقنية والشهادات", "القسم 3: كتابة خطاب التقديم للوظائف والمنح (Cover Letter)"], rules: ["استخدم أفعال الإنجاز القوية والأرقام القابلة للقياس لرفع نسبة قبول السيرة الذاتية."] },
            { id: "uni-sub-interview", name: "محاكي المقابلات الوظيفية ومقابلات المنح (STAR)", ico: "🎤", bookTitle: "دليل اجتياز المقابلات المهنية والأكاديمية بنجاح", totalPages: 84, studioTarget: "uniResearchCareerStudio", units: ["القسم 1: هيكلة الإجابات بمنهجية STAR (الموقف، المهمة، الإجراء، النتيجة)", "القسم 2: الأسئلة الشائعة في المقابلات التخصصية"], rules: ["منهجية STAR تضمن إجابة منظمة ومقنعة: Situation ➔ Task ➔ Action ➔ Result."] }
          ]}]
        },
        {
          id: "uni-research",
          name: "الأبحاث الجامعية ومشاريع التخرج وتوثيق المراجع (APA)",
          branches: [{ id: "uni-res-br", name: "مسار البحث العلمي", subjects: [
            { id: "uni-sub-proposal", name: "إعداد مقترح البحث ومشروع التخرج والملخص المزدوج (Abstract)", ico: "🔬", bookTitle: "المنهجية القياسية لإعداد أبحاث التخرج والرسائل الجامعية", totalPages: 120, studioTarget: "uniResearchCareerStudio", units: ["الفصل 1: صياغة مشكلة البحث وأسئلته وفرضياته", "الفصل 2: كتابة الملخص الأكاديمي باللغتين (الملخص العربي + English Abstract)", "الفصل 3: توثيق المراجع وفق نظام APA 7th وIEEE"], rules: ["صيغة توثيق الكتاب في نظام APA 7th: اسم العائلة، الحرف الأول. (السنة). عنوان الكتاب. دار النشر."] }
          ]}]
        }
      ]
    },
    {
      id: "stage-cultural",
      name: "المكتبة الثقافية والعامة الشاملة",
      shortName: "المكتبة الثقافية العامة",
      ico: "🌍",
      desc: "كتب ثقافية وفكرية وتاريخية وعلمية مبسطة لجميع القراء مع حفظ تلقائي لصفحة التوقف",
      color: "from-teal-600 to-emerald-800",
      grades: [
        {
          id: "cult-reading",
          name: "الفكر والقراءة النقدية وتطوير الذات",
          branches: [{ id: "cult-r-br", name: "قراءة ثقافية عامة", subjects: [
            { id: "cult-sub-read", name: "فن القراءة المنهجية وبناء العقل النقدي", ico: "📚", bookTitle: "فن القراءة المنهجية وبناء العقل النقدي في عصر المعرفة", totalPages: 145, units: ["الفصل 1: لماذا نقرأ؟ الانتقال من جمع المعلومات إلى بناء الحكمة", "الفصل 2: مستويات القراءة الأربعة (الاستكشافية، التحليلية، المقارنة)", "الفصل 3: تدوين الهوامش وبناء الخزانة المعرفية الشخصية"], rules: ["القراءة المقارنة تقوم على قراءة عدة كتب حول موضوع واحد لبناء رؤية نقدية مستقلة."] }
          ]}]
        },
        {
          id: "cult-palestine",
          name: "التاريخ والحضارة والتراث الفلسطيني",
          branches: [{ id: "cult-p-br", name: "تاريخ وتراث", subjects: [
            { id: "cult-sub-pal", name: "معالم الحضارة والتاريخ التراثي والثقافي في فلسطين", ico: "🇵🇸", bookTitle: "معالم الحضارة والتاريخ التراثي والثقافي في فلسطين عبر العصور", totalPages: 230, units: ["الباب 1: الجغرافيا التاريخية وحواضر العلم والمكتبات العريقة", "الباب 2: العمارة التراثية والأسواق التاريخية في المدن الفلسطينية", "الباب 3: الحركة الأدبية والفكرية المعاصرة"], rules: ["حفظت المكتبات الفلسطينية التاريخية آلاف المخطوطات النادرة في الطب والفلك والعلوم الإنسانية."] }
          ]}]
        },
        {
          id: "cult-science",
          name: "الثقافة العلمية والذكاء الاصطناعي للمجتمع",
          branches: [{ id: "cult-s-br", name: "علوم وتقنية للجميع", subjects: [
            { id: "cult-sub-ai", name: "الذكاء الاصطناعي ومهارات المستقبل: دليل مبسّط للجميع", ico: "🤖", bookTitle: "الذكاء الاصطناعي ومهارات المستقبل: دليل مبسّط للجميع", totalPages: 160, units: ["الفصل 1: كيف تتعلم الآلة؟ من الخوارزميات إلى النماذج اللغوية", "الفصل 2: توظيف الأدوات الذكية في التعلم الذاتي والإنتاجية"], rules: ["توظيف التقنيات الحديثة يضاعف كفاءة التعلم الذاتي والبحث العلمي."] }
          ]}]
        }
      ]
    }
  ];


  // ============================================================================
  // كتالوج أدوات واستوديوهات المنصة الشامل (38 أداة ومختبراً) لإدارة الصلاحيات والتبويب
  // ============================================================================
  var MASTER_TOOLS_CATALOG = [
    { id: "teamPersonasStudio", title: "مختبر شخصيات الفريق التعليمي الذكي", ico: "👨‍🏫", cat: "الأدوات الذكية والمحاكاة", desc: "تعلّم وحاور أ. باسل الفقعاوي، المعلمة صابرين (الرياضيات)، المعلمة بيان (العربية والتشكيل)، والمعلمة ليان (الإنجليزية)", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "مشرف", "مدير مدرسة", "ولي أمر"] },
    { id: "aiTeacherAcademyStudio", title: "أكاديمية أدوات الذكاء الاصطناعي للمعلمين", ico: "🪄", cat: "أدوات المعلم والتحضير", desc: "محاكي تطبيقي عربي لأدوات MagicSchool وCuripod وKhanmigo وDiffit وBrisk Teaching مع إصدار شهادة تدريب", defaultRoles: ["guest", "معلم", "مشرف", "مدير مدرسة", "توجيهي", "جامعي"] },
    { id: "reelsPodcastStudio", title: "سينما الموشن جرافيك (9:16) وبودكاست المنصة", ico: "🎬", cat: "الأدوات الذكية والمحاكاة", desc: "مشغل فيديوهات 9:16 المشكولة (نسخ وترجمة الـ DNA، القصور الدوراني، كيمياء الرابع) واستوديو البودكاست", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "مشرف", "مدير مدرسة", "ولي أمر"] },
    // 1. أدوات الطالب والمذاكرة والتوجيهي
    { id: "bookReaderStudio", ico: "📖", title: "قارئ ومعاين الكتب التفاعلي الموسّع", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "قراءة كتب المنهاج مقسمة للفصول، معاينة PDF، وتظليل الفقرات مع دفتر المقتطفات", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "tutorStudio", ico: "🧠", title: "المعلم الخصوصي الذكي والخرائط", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "شرح سقراطي مبسط، بطاقات استذكار قلابة، خرائط ذهنية، وتوليد أسئلة فهم", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "tawjihiStudio", ico: "🎓", title: "بوابة التوجيهي وحاسبة المعدل", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "حساب معدل التوجيهي الرسمي لجميع الفروع وجدول المراجعة والمستشار الجامعي", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "smartNotesFlashStudio", ico: "📓", title: "دفتر كورنيل الذكي ومدرب الاستدعاء النشط", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "تلخيص فصول الكتب بنظام كورنيل الثلاثي، إخفاء الشرح للتسميع، وتمارين إكمال الفراغات", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم"] },
    { id: "visualConceptExamStudio", ico: "🗺️", title: "الخرائط المفاهيمية ومحاكي الامتحان الموقوت", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "رسم خرائط مفاهيمية تفاعلية ومحاكي قاعة امتحان رسمي بالعد التنازلي والتشخيص", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم"] },
    { id: "reviewStudio", ico: "🔄", title: "المراجعة الذكية بالتكرار المتباعد", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "بطاقات مراجعة ذكية تعود في الوقت المناسب مع هدف يومي وسلسلة إنجاز", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم"] },
    { id: "masteryAnalyticsStudio", ico: "📈", title: "مرصد الإتقان ومولّد الحقيبة الذهبية (5×1)", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "قياس نسبة الإتقان وتوليد الحقيبة الذهبية للدرس (ملخص + قاموس + ورقة عمل + اختبار + حل)", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم"] },
    { id: "multiSourceSynthStudio", ico: "🎙️", title: "استوديو البودكاست التعليمي ودمج المصادر", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "تحويل فصول الكتب إلى حوار صوتي ناطق بين متحدثين ومصفوفة مقارنة", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم"] },
    { id: "sciCalcStudio", ico: "🧮", title: "الحاسبة العلمية وراسم الدوال والقوانين", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "حاسبة علمية متقدمة، راسم دوال بياني، حل معادلات، ومرجع القوانين العلمية", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم"] },
    { id: "offPackStudio", ico: "📥", title: "حقيبة المذاكرة المحمولة بلا إنترنت", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "تصدير ملخصات ودروس واختبارات ذاتية وبطاقات قلابة في ملف مستقل يعمل بدون إنترنت", defaultRoles: ["guest", "طالب", "توجيهي", "معلم", "ولي أمر"] },
    { id: "libraryStudio", ico: "📚", title: "مكتبة الملخصات والمواد الدراسية", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "فيديوهات وملخصات مركزة واختبارات قصيرة مصنفة لكل مادة دراسية", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "selfQuiz", call: "EduStudy.quiz", ico: "🎯", title: "اختبر نفسك بالذكاء الاصطناعي", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "أسئلة تفاعلية فورية من أي درس مع تصحيح وتعليل منهجي مباشر", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "dailyChallenge", call: "EduStudy.daily", ico: "🔥", title: "التحدي اليومي السريع (5 أسئلة)", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "5 أسئلة متجددة يومياً مع نقاط خبرة XP وسلسلة أيام المذاكرة", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "questionBank", call: "EduStudy.bank", ico: "🗃️", title: "بنك الأسئلة التفاعلي", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "حفظ الأسئلة وتوليد المزيد بالذكاء الاصطناعي وتصديرها والاختبار منها", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "voiceSettings", call: "EduVoice.open", ico: "🔊", title: "استوديو الصوت والقارئ الذكي", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "14 شخصية صوتية عربية وإنجليزية مع التحكم بالسرعة وقراءة النصوص", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "smartUnifiedCockpit", ico: "🧭", title: "مركز القيادة الذكي وكتب Google Drive", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "عرض كتب Google Drive والمكتبة الثقافية والقاعدة البرمجية الخفية بلا إنترنت", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "publicHubStudio", ico: "🌍", title: "بوابة المجتمع المعرفي والجمهور العام", cat: "student", catLabel: "أدوات الطالب والمذاكرة", desc: "الدورات التدريبية المفتوحة، الثقافة العامة، أطلس فلسطين، ومختبرات المعرفة", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },

    // 2. أدوات المعلم والتحضير والتقويم
    { id: "lessonKitStudio", ico: "🧳", title: "حقيبة الحصة الجاهزة الشاملة", cat: "teacher", catLabel: "أدوات المعلم والتحضير", desc: "توليد أهداف سلوكية وخطة درس وورقة عمل واختبار وواجب وتمايز مع تصدير Word وPDF", defaultRoles: ["guest", "معلم", "طالب", "توجيهي", "جامعي"] },
    { id: "lessonPlanStudio", ico: "📋", title: "مولّد خطط الدروس والتحضير الوزاري", cat: "teacher", catLabel: "أدوات المعلم والتحضير", desc: "تحضير وزاري ومبسط للحصص والوحدات الدراسية مع تصدير Word وطباعة A4", defaultRoles: ["guest", "معلم"] },
    { id: "worksheetStudio", ico: "📝", title: "مولّد أوراق العمل والاختبارات", cat: "teacher", catLabel: "أدوات المعلم والتحضير", desc: "تصميم أوراق عمل متمايزة واختبارات قصيرة وبنك أسئلة مع باركود QR", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "slidesStudio", ico: "📽️", title: "مولّد العروض التقديمية التفاعلية", cat: "teacher", catLabel: "أدوات المعلم والتحضير", desc: "إنشاء شرائح درس تفاعلية مع تصويت حي وتصدير PowerPoint وPDF", defaultRoles: ["guest", "معلم"] },
    { id: "whiteboardStudio", ico: "🖍️", title: "السبورة التفاعلية الذكية", cat: "teacher", catLabel: "أدوات المعلم والتحضير", desc: "رسم وهندسة وشرح مباشر فوق صفحات الكتاب مع تسجيل الشرح كفيديو", defaultRoles: ["guest", "معلم", "طالب", "توجيهي", "جامعي"] },
    { id: "homeworkStudio", ico: "📸", title: "مصحح الدفاتر والواجبات المصوّرة (Vision)", cat: "teacher", catLabel: "أدوات المعلم والتحضير", desc: "قراءة خط يد الطالب وتصحيح دفاتره بالكاميرا وربطها بالخطط العلاجية", defaultRoles: ["guest", "معلم", "ولي أمر"] },
    { id: "teacherTools", ico: "🪄", title: "محضّر الحصة ودفتر المصادر الذكي", cat: "teacher", catLabel: "أدوات المعلم والتحضير", desc: "تصوير صفحات الكتاب لتحضير الدرس فوراً أو رفع ملفات ومناقشتها", defaultRoles: ["guest", "معلم"] },
    { id: "rubricsStudio", ico: "🫧", title: "أوراق التظليل الآلي وسلالم التقدير", cat: "teacher", catLabel: "أدوات المعلم والتحضير", desc: "تصميم أوراق تظليل دوائر للتصحيح السريع وبناء معايير تقييم المشاريع (Rubrics)", defaultRoles: ["guest", "معلم"] },
    { id: "designStudio", ico: "🎨", title: "مولّد الإنفوغرافيك والبوسترات التعليمية", cat: "teacher", catLabel: "أدوات المعلم والتحضير", desc: "تصميم لوحات صفية وبوسترات تعليمية وإعلانية جاهزة للطباعة", defaultRoles: ["guest", "معلم"] },
    { id: "weeklyPlannerStudio", ico: "🗓️", title: "المخطط الأسبوعي الذكي وجدول الحصص", cat: "teacher", catLabel: "أدوات المعلم والتحضير", desc: "جدول حصص ومذاكرة أسبوعي تفاعلي مع قوالب جاهزة للمعلم والطالب والتوجيهي", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "teacherDash", ico: "🗂️", title: "لوحة المعلم الشاملة وإدارة الأعمال", cat: "teacher", catLabel: "أدوات المعلم والتحضير", desc: "متابعة كل أعمالك واختباراتك المنشورة ونتائج طلابك في مكان واحد", defaultRoles: ["guest", "معلم"] },

    // 3. المختبرات التفاعلية والبرمجة والألعاب
    { id: "simLabStudio", ico: "🧪", title: "مختبر التجارب العلمية التفاعلي (STEM Lab)", cat: "labs", catLabel: "المختبرات والألعاب", desc: "محاكيات تفاعلية لتجارب الفيزياء والكيمياء والأحياء والرياضيات", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم"] },
    { id: "stemLabPlannerStudio", ico: "🔬", title: "مختبر المعادلات والتمثيل البياني والصياغة", cat: "labs", catLabel: "المختبرات والألعاب", desc: "حل المسائل العلمية خطوة بخطوة مع رسم بياني SVG ومدقق صياغة أكاديمية", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم"] },
    { id: "gamesStudio", ico: "🎮", title: "الألعاب التربوية والمسابقات الصفية الحية", cat: "labs", catLabel: "المختبرات والألعاب", desc: "5 أنماط ألعاب تعليمية تفاعلية مع غرفة مسابقات حية برمز PIN", defaultRoles: ["guest", "طالب", "توجيهي", "معلم", "ولي أمر"] },
    { id: "codingLabStudio", ico: "💻", title: "أكاديمية البرمجة والروبوتكس", cat: "labs", catLabel: "المختبرات والألعاب", desc: "محرر كود تفاعلي وتحديات خوارزميات الروبوت لمنهاج التكنولوجيا", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم"] },
    { id: "langLabStudio", ico: "🗣️", title: "معمل اللغات والنطق والإعراب النحوي", cat: "labs", catLabel: "المختبرات والألعاب", desc: "مدرب النطق بالميكروفون، الإملاء المسموع، والمعرب النحوي التفاعلي", defaultRoles: ["guest", "طالب", "توجيهي", "معلم", "ولي أمر"] },
    { id: "storiesStudio", ico: "📚", title: "استوديو القصص المصوّرة الناطقة", cat: "labs", catLabel: "المختبرات والألعاب", desc: "تحويل الدروس إلى قصص مصورة تربوية من 5 مشاهد مع راوٍ صوتي", defaultRoles: ["guest", "طالب", "معلم", "ولي أمر"] },
    { id: "earlyLearnStudio", ico: "🧸", title: "استوديو التأسيس والطفولة المبكرة (1–4)", cat: "labs", catLabel: "المختبرات والألعاب", desc: "كراسات تتبع الحروف المنقطة والعد البصري والحروف والأرقام الناطقة", defaultRoles: ["guest", "طالب", "معلم", "ولي أمر"] },
    { id: "atlasStudio", ico: "🗺️", title: "أطلس فلسطين الجغرافي والتاريخي التفاعلي", cat: "labs", catLabel: "المختبرات والألعاب", desc: "خريطة مدن وتضاريس فلسطين التاريخية وتحدي الخريطة الصماء", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "arSection", ico: "🥽", title: "مختبر الواقع المعزز التفاعلي (AR)", cat: "labs", catLabel: "المختبرات والألعاب", desc: "توجيه الكاميرا نحو رسوم الكتاب للتعرف على أجزائها العلمية حياً", defaultRoles: ["guest", "طالب", "توجيهي", "معلم"] },
    { id: "edtechLabSection", ico: "⚡", title: "مختبر تكنولوجيا التعليم وهرم بلوم", cat: "labs", catLabel: "المختبرات والألعاب", desc: "مصفوفة بلوم الرقمية، مؤقت الحصة الذكي، وبناء سلالم التقدير", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },

    // 4. الذكاء الاصطناعي والبرومبتات وغرفة العمليات
    { id: "aiStudio", ico: "🤖", title: "استوديو الذكاء الاصطناعي التربوي الشامل", cat: "ai", catLabel: "الذكاء الاصطناعي والبرومبتات", desc: "مساعد ذكي لتوليد الشروحات، الخطط، الأنشطة، والاختبارات التفاعلية", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "generator", ico: "✨", title: "مولّد البرومبتات التربوية الذكي", cat: "ai", catLabel: "الذكاء الاصطناعي والبرومبتات", desc: "صياغة أوامر ذكاء اصطناعي احترافية مخصصة للمنهاج الفلسطيني", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "unifiedWorkflowStudio", ico: "🧭", title: "غرفة العمليات التعليمية الموحّدة", cat: "ai", catLabel: "الذكاء الاصطناعي والبرومبتات", desc: "اكتب موضوع الدرس مرة واحدة وانتقل به فوراً بين جميع الأدوات بسلاسة", defaultRoles: ["guest", "معلم", "طالب", "توجيهي", "جامعي"] },

    // 5. المرحلة الجامعية والسيرة الذاتية والأبحاث
    { id: "cvBuilderStudio", ico: "📄", title: "منشئ السيرة الذاتية الاحترافية (CV عربي/EN)", cat: "university", catLabel: "الجامعة والتأهيل المهني", desc: "تصميم سيرة ذاتية متوافقة مع ATS باللغتين العربية والإنجليزية مع التصدير الفوري", defaultRoles: ["guest", "جامعي", "توجيهي", "معلم", "طالب"] },
    { id: "uniResearchCareerStudio", ico: "🏛️", title: "استوديو الأبحاث الجامعية وتوثيق APA والمقابلات", cat: "university", catLabel: "الجامعة والتأهيل المهني", desc: "إعداد مقترح بحث التخرج، ملخص Abstract مزدوج، توثيق APA 7th، ومحاكي المقابلات", defaultRoles: ["guest", "جامعي", "توجيهي", "معلم"] },

    // 6. الإدارة الصفية والشهادات وأولياء الأمور
    { id: "classroomsStudio", ico: "🏫", title: "الفصول الافتراضية ومتابعة الواجبات", cat: "admin_class", catLabel: "الإدارة الصفية والأسرة", desc: "إدارة الفصول الافتراضية برمز الدخول ومتابعة الواجبات وسجل الدرجات", defaultRoles: ["guest", "معلم", "طالب", "توجيهي", "ولي أمر"] },
    { id: "parentPortalStudio", ico: "👨‍👩‍👧‍👦", title: "بوابة ولي الأمر ومتابعة الأبناء", cat: "admin_class", catLabel: "الإدارة الصفية والأسرة", desc: "متابعة درجات وواجبات الأبناء، خطة المذاكرة المنزلية، وشهادات التشجيع", defaultRoles: ["guest", "ولي أمر", "معلم", "طالب"] },
    { id: "parentsStudio", ico: "📲", title: "تقارير أولياء الأمور وبطاقات المتابعة (واتساب)", cat: "admin_class", catLabel: "الإدارة الصفية والأسرة", desc: "إصدار بطاقة متابعة الطالب التفصيلية وإرسالها مباشرة لولي الأمر", defaultRoles: ["guest", "معلم", "ولي أمر"] },
    { id: "certStudio", ico: "🏅", title: "مولّد الشهادات التقديرية الجماعية (PDF/PNG)", cat: "admin_class", catLabel: "الإدارة الصفية والأسرة", desc: "إصدار دفتر شهادات تقدير وتفوق لقائمة طلاب كاملة بضغطة واحدة", defaultRoles: ["guest", "معلم"] },
    { id: "portfolioStudio", ico: "📁", title: "ملف الإنجاز المهني للمعلم والخطط العلاجية", cat: "admin_class", catLabel: "الإدارة الصفية والأسرة", desc: "بناء ملف إنجاز المعلم الرسمي والخطط العلاجية والإثرائية", defaultRoles: ["guest", "معلم"] },
    { id: "inclusiveStudio", ico: "💚", title: "التعليم الدامج والدعم النفسي والخطة الفردية IEP", cat: "admin_class", catLabel: "الإدارة الصفية والأسرة", desc: "أنشطة الدعم النفسي والقارئ الميسر لصعوبات التعلم وبناء خطة IEP", defaultRoles: ["guest", "معلم", "ولي أمر", "طالب"] },
    { id: "classToolsStudio", ico: "🧰", title: "حقيبة إدارة الصف والقرعة والمجموعات", cat: "admin_class", catLabel: "الإدارة الصفية والأسرة", desc: "القرعة العشوائية، مقسم المجموعات، مؤقت الحصة، وضبط النظام الصفي", defaultRoles: ["guest", "معلم"] },
    { id: "radioStudio", ico: "🎙️", title: "الإذاعة المدرسية والمسابقات الثقافية", cat: "admin_class", catLabel: "الإدارة الصفية والأسرة", desc: "توليد برنامج إذاعة مدرسية صباحية متكامل ومسابقات ثقافية بين الفصول", defaultRoles: ["guest", "معلم", "طالب"] },
    { id: "mediaToolsStudio", ico: "🗜️", title: "ضغط الصور ودمجها في PDF محلياً", cat: "admin_class", catLabel: "الإدارة الصفية والأسرة", desc: "تقليص حجم الصور بنسبة 85% وتحويل صور الدفتر لملف PDF بدون إنترنت", defaultRoles: ["guest", "طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"] },
    { id: "analyticsStudio", ico: "📊", title: "مرصد الإحصاءات وتقارير تغطية المنهاج", cat: "admin_class", catLabel: "الإدارة الصفية والأسرة", desc: "إحصاءات المحتوى عبر المراحل وطباعة تقرير الإنجاز الإداري", defaultRoles: ["guest", "معلم"] },
    { id: "sourcesStudio", ico: "🗄️", title: "استوديو مصادري وتغذية القاعدة الخفية", cat: "admin_class", catLabel: "الإدارة الصفية والأسرة", desc: "رفع ملفات Markdown وكتب PDF وربط Google Drive لتغذية النظام بلا إنترنت", defaultRoles: [] }
  ];

  var TOOL_MAP = {};
  MASTER_TOOLS_CATALOG.forEach(function (t) { TOOL_MAP[t.id] = t; });

  var ALL_MANAGED_SECTION_IDS = [
    "teamPersonasStudio",
    "aiTeacherAcademyStudio",
    "reelsPodcastStudio",
    "quickStart",
    "eduMainTrackBar",
    "boostBar",
    "smartHubSection",
    "eduRoleOrchestrator",
    "eduPersonalBanner",
    "homeAds",
    "homeVideos",
    "modsSection",
    "quickLinksSection",
    "coursesSection",
    "userWorkspaceSection",
    "library",
    "social",
    "about",
    "learnSection",
    "booksSection",
    "sourcesStudio",
    "teacherTools",
    "aiStudio",
    "rubricsStudio",
    "designStudio",
    "generator",
    "teacherDash",
    "classroomsStudio",
    "offPackStudio",
    "analyticsStudio",
    "classToolsStudio",
    "radioStudio",
    "mediaToolsStudio",
    "certStudio",
    "inclusiveStudio",
    "portfolioStudio",
    "lessonKitStudio",
    "lessonPlanStudio",
    "slidesStudio",
    "whiteboardStudio",
    "homeworkStudio",
    "unifiedWorkflowStudio",
    "parentPortalStudio",
    "publicHubStudio",
    "smartUnifiedCockpit",
    "stemLabPlannerStudio",
    "smartNotesFlashStudio",
    "visualConceptExamStudio",
    "masteryAnalyticsStudio",
    "multiSourceSynthStudio",
    "uniResearchCareerStudio",
    "cvBuilderStudio",
    "bookReaderStudio",
    "worksheetStudio",
    "tutorStudio",
    "tawjihiStudio",
    "reviewStudio",
    "weeklyPlannerStudio",
    "sciCalcStudio",
    "gamesStudio",
    "simLabStudio",
    "codingLabStudio",
    "langLabStudio",
    "storiesStudio",
    "earlyLearnStudio",
    "atlasStudio",
    "arSection",
    "edtechLabSection",
    "parentsStudio",
    "libraryStudio"
  ];

  var ROLE_DEFINITIONS = [
    { key: "guest", label: "🌐 زائر غير مسجّل", short: "زائر" },
    { key: "طالب", label: "🎓 طالب مدرسي (1–11)", short: "طالب" },
    { key: "توجيهي", label: "🏅 طالب توجيهي (12)", short: "توجيهي" },
    { key: "جامعي", label: "🏛️ طالب جامعي / خريج", short: "جامعي" },
    { key: "معلم", label: "🧑‍🏫 معلم / مشرف تربوي", short: "معلم" },
    { key: "ولي أمر", label: "👪 ولي أمر", short: "ولي أمر" }
  ];

  function buildDefaultRolePolicies() {
    var pol = {};
    ROLE_DEFINITIONS.forEach(function (r) {
      pol[r.key] = {};
      MASTER_TOOLS_CATALOG.forEach(function (t) {
        pol[r.key][t.id] = (t.defaultRoles || []).indexOf(r.key) !== -1;
      });
    });
    return pol;
  }

  var DEFAULT_DEMO_USERS = [
    {
      name: "أ. سارة خالد العلمي",
      email: "sara.teacher@edutech.ps",
      pass: "123456",
      roleLabel: "معلم",
      gradeId: "g10",
      gradeName: "الصف العاشر الأساسي",
      school: "مدرسة بشير الريس الثانوية - غزة",
      phone: "0599000111",
      createdAt: "2026-11-10"
    },
    {
      name: "أحمد رامي النجار",
      email: "ahmed.tawjihi@edutech.ps",
      pass: "123456",
      roleLabel: "توجيهي",
      gradeId: "g12",
      gradeName: "الصف الثاني عشر (التوجيهي)",
      school: "مدرسة فلسطين الثانوية للبنين",
      phone: "0599000222",
      createdAt: "2026-11-11"
    },
    {
      name: "ليان مازن حسونة",
      email: "layan.uni@edutech.ps",
      pass: "123456",
      roleLabel: "جامعي",
      gradeId: "uni-cv",
      gradeName: "المرحلة الجامعية والسيرة الذاتية",
      school: "الجامعة الإسلامية / الأزهر - غزة",
      phone: "0599000333",
      createdAt: "2026-11-12"
    },
    {
      name: "محمد سامي الكرد",
      email: "mohammed.g4@edutech.ps",
      pass: "123456",
      roleLabel: "طالب",
      gradeId: "g4",
      gradeName: "الصف الرابع الأساسي",
      school: "مدرسة الزيتون الأساسية",
      phone: "0599000444",
      createdAt: "2026-11-12"
    },
    {
      name: "أبو محمد الكرد (ولي أمر)",
      email: "parent.kurd@edutech.ps",
      pass: "123456",
      roleLabel: "ولي أمر",
      gradeId: "g4",
      gradeName: "الصف الرابع الأساسي",
      school: "مجلس أولياء الأمور",
      phone: "0599000555",
      createdAt: "2026-11-12"
    }
  ];

  var masterTree = [];
  var bookmarks = {};
  var pageNotes = {};
  var completedUnits = {};
  var registeredUsers = [];
  var pinnedSubjects = {};
  var currentUser = null;
  var readerPrefs = { fontSize: 15, paperTheme: "cream", siteFont: "cairo", siteScale: 100 };

  var collabRooms = [
    { id: "room-math-g4", code: "GZ-MATH4", title: "حلقة التعاون الذكي: الرياضيات — الصف الرابع", teacher: "أ. صابرين أمين", grade: "الصف الرابع الأساسي", subject: "الرياضيات", activeTask: "مراجعة وتمثيل الكسور العشرية على خط الأعداد وحل ورقة العمل التفاعلية", members: 34, status: "active" },
    { id: "room-arabic-g7", code: "GZ-ARAB7", title: "حلقة التعاون الذكي: اللغة العربية — الإعدادية", teacher: "أ. بيان", grade: "الصف السابع الأساسي", subject: "اللغة العربية", activeTask: "استخراج القواعد النحوية وتلخيص الفكرة المحورية بنظام كورنيل", members: 41, status: "active" },
    { id: "room-phys-g12", code: "GZ-TAW12", title: "غرفة عمليات التوجيهي: الفيزياء والتكنولوجيا", teacher: "أ. باسل أشرف الفقعاوي", grade: "الصف الثاني عشر (التوجيهي)", subject: "الفيزياء والتكنولوجيا", activeTask: "حل مسائل القوة الدافعة وقوانين كيرشوف مع محاكي الامتحان الموقوت", members: 68, status: "active" }
  ];

  var adminPerms = {
    publicLibrary: true,
    publicUniversity: true,
    publicOrigPdf: true,
    publicQuiz: true,
    publicFlashcards: true,
    publicVoice: true,
    requireLoginForTools: false,
    hideBlockedToolsCompletely: false,
    maintenanceMode: false,
    maintenanceMsg: "الموقع في وضع التحديث والصيانة الدورية بأمر الإدارة العليا — يرجى المحاولة لاحقاً.",
    registrationMode: "open", // "open" | "code_only" | "closed"
    collabEnabled: true,
    announcementActive: false,
    announcementText: "أهلاً بكم في منصة EduTech Mindset — المنهاج الفلسطيني الرسمي المحدّث وبوابة الأدوات الذكية.",
    rolePolicies: buildDefaultRolePolicies(),
    userPermissions: {
      "sara.teacher@edutech.ps": {
        mode: "vip_all",
        grantedTools: ["lessonKitStudio", "lessonPlanStudio", "worksheetStudio", "slidesStudio", "whiteboardStudio", "certStudio", "analyticsStudio"],
        blockedTools: [],
        note: "معلمة معتمدة — صلاحية كاملة للتحضير والاختبارات"
      },
      "ahmed.tawjihi@edutech.ps": {
        mode: "custom",
        grantedTools: ["worksheetStudio", "stemLabPlannerStudio", "masteryAnalyticsStudio", "cvBuilderStudio"],
        blockedTools: ["certStudio", "portfolioStudio"],
        note: "طالب توجيهي متفوق — ممنوح أدوات أوراق العمل ومختبر المعادلات"
      }
    },
    accessRequests: [
      {
        id: "req-demo-1",
        userEmail: "mohammed.g4@edutech.ps",
        userName: "محمد سامي الكرد",
        userRole: "طالب",
        toolId: "whiteboardStudio",
        toolTitle: "السبورة التفاعلية الذكية",
        note: "أرغب باستخدام السبورة التفاعلية للتدرب على حل مسائل الكسور العشرية",
        requestedAt: "2026-11-13 10:15",
        status: "pending"
      },
      {
        id: "req-demo-2",
        userEmail: "layan.uni@edutech.ps",
        userName: "ليان مازن حسونة",
        userRole: "جامعي",
        toolId: "slidesStudio",
        toolTitle: "مولّد العروض التقديمية التفاعلية",
        note: "أحتاج الأداة لتجهيز عرض مناقشة مشروع التخرج الجامعي",
        requestedAt: "2026-11-13 11:30",
        status: "pending"
      }
    ],
    activationCodes: [
      {
        code: "VIP-TEACHER-2026",
        label: "كود المعلم المعتمد (وصول كامل 50 أداة)",
        grantMode: "vip_all",
        tools: [],
        maxUses: 50,
        usedCount: 2,
        expiresDays: 365,
        active: true
      },
      {
        code: "TAWJIHI-PACK-2026",
        label: "حزمة التوجيهي والمختبرات وأوراق العمل",
        grantMode: "custom",
        tools: ["worksheetStudio", "stemLabPlannerStudio", "masteryAnalyticsStudio", "visualConceptExamStudio", "cvBuilderStudio", "sciCalcStudio"],
        maxUses: 100,
        usedCount: 5,
        expiresDays: 180,
        active: true
      },
      {
        code: "UNI-RESEARCH-PRO",
        label: "حزمة الباحث الجامعي والسيرة الذاتية والعروض",
        grantMode: "custom",
        tools: ["cvBuilderStudio", "uniResearchCareerStudio", "slidesStudio", "multiSourceSynthStudio"],
        maxUses: 30,
        usedCount: 1,
        expiresDays: 90,
        active: true
      }
    ],
    permissionAuditLog: [
      { id: "aud-1", time: "2026-11-13 09:00", action: "منح صلاحية شاملة (VIP) للمعلمة أ. سارة خالد العلمي", actor: "الأستاذ باسل أشرف الفقعاوي" },
      { id: "aud-2", time: "2026-11-13 10:00", action: "تخصيص 4 أدوات متقدمة لطالب التوجيهي أحمد رامي النجار", actor: "الأستاذ باسل أشرف الفقعاوي" }
    ]
  };

  var navStack = [];
  var isRestoringHistory = false;

  var state = {
    topNav: "curriculum", // "curriculum" | "tools" | "library" | "mybag" | "university" | "account" | "admin"
    curriculumSubTab: "textbook", // "textbook" | "video_lessons" | "ministry_books"
    toolsCat: "all", // "all" | "granted" | "student" | "teacher" | "labs" | "ai" | "university" | "admin_class"
    toolsSearch: "",
    openedToolId: "",
    librarySubTab: "curriculum_cultural", // "curriculum_cultural" | "edu_resources" | "open_courses"
    mybagSubTab: "reading_notes", // "reading_notes" | "study_schedule" | "my_workspace"
    uniSubTab: "majors_tawjihi", // "majors_tawjihi" | "cv_studio" | "research_apa" | "about_platform"
    accountSubTab: "profile", // "profile" | "my_permissions" | "my_requests"
    isAdminUnlocked: false,
    adminTab: "permissions_mgr", // "permissions_mgr" | "hierarchy_mgr" | "sources_brain" | "admin_studios" | "announce_security" | "site_settings"
    adminPermSubMode: "user_specific", // "user_specific" | "role_defaults" | "access_requests"
    selectedAdminUserEmail: "ahmed.tawjihi@edutech.ps",
    adminUserSearch: "",
    adminToolFilterCat: "all",
    adminToolSearch: "",
    selectedAdminRoleKey: "طالب",
    impersonatingUserEmail: "",
    stageId: "stage-primary",
    gradeId: "g4",
    branchId: "g4-gen",
    subjectId: "g4-math",
    unitIdx: 0,
    activeStudyMode: "book", // "book" | "cornell" | "flashcards" | "conceptmap" | "quiz" | "origpdf"
    hideCornellNotes: false,
    flippedCards: {},
    quizAnswers: {},
    quickSearch: "",
    libQuery: "",
    libStage: "all",
    authMode: "login", // "login" | "register" | "demo"
    isExpandedReading: false,
    revealCloze: false,
    semesterFilter: "all",
    revealSolutions: false,
    collapseSelectors: false,
    splitViewMode: false,
    smartPageAnswer: "",
    openedAdminStudioId: ""
  };


  /* ====== تحقق الرمز السيادي بدون كتابته نصًا في الكود (SHA-256 مملّح) ======
     تنبيه صريح: هذا يخفي الرمز فقط. الحماية الفعلية للصلاحيات = حساب Google الموثّق للإدارة + قواعد Firestore. */
  var ADMIN_PIN_HASH = "fb3a6fb61a2e105d2c7d746961c12ca21907e43149cec37e0b6dbdc2c99ea387";
  function sha256Hex(str) {
    var bytes = unescape(encodeURIComponent(String(str)));
    var K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
    var H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    var l = bytes.length, words = [], i, j;
    for (i = 0; i < l; i++) words[i >> 2] |= bytes.charCodeAt(i) << (24 - (i % 4) * 8);
    words[l >> 2] |= 0x80 << (24 - (l % 4) * 8);
    words[(((l + 8) >> 6) << 4) + 15] = l * 8;
    function rr(n, x) { return (x >>> n) | (x << (32 - n)); }
    for (var off = 0; off < words.length; off += 16) {
      var w = [], a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (j = 0; j < 64; j++) {
        if (j < 16) w[j] = words[off + j] | 0;
        else {
          var s0 = rr(7, w[j - 15]) ^ rr(18, w[j - 15]) ^ (w[j - 15] >>> 3);
          var s1 = rr(17, w[j - 2]) ^ rr(19, w[j - 2]) ^ (w[j - 2] >>> 10);
          w[j] = (w[j - 16] + s0 + w[j - 7] + s1) | 0;
        }
        var S1 = rr(6, e) ^ rr(11, e) ^ rr(25, e), ch = (e & f) ^ (~e & g);
        var t1 = (h + S1 + ch + K[j] + w[j]) | 0;
        var S0 = rr(2, a) ^ rr(13, a) ^ rr(22, a), mj = (a & b) ^ (a & c) ^ (b & c);
        var t2 = (S0 + mj) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      H = [(H[0] + a) | 0, (H[1] + b) | 0, (H[2] + c) | 0, (H[3] + d) | 0, (H[4] + e) | 0, (H[5] + f) | 0, (H[6] + g) | 0, (H[7] + h) | 0];
    }
    return H.map(function (x) { return ("00000000" + (x >>> 0).toString(16)).slice(-8); }).join("");
  }
  var loginAttempts = { count: 0, lockedUntil: 0 };
  function checkLoginRateLimit() {
    var now = Date.now();
    if (loginAttempts.lockedUntil > now) {
      var secs = Math.ceil((loginAttempts.lockedUntil - now) / 1000);
      toast("⏳ تم إيقاف المحاولات مؤقتاً لحماية الحساب — انتظر " + secs + " ثانية ثم حاول مجدداً", "warning");
      return false;
    }
    return true;
  }
  function recordFailedAttempt() {
    loginAttempts.count = (loginAttempts.count || 0) + 1;
    if (loginAttempts.count >= 5) {
      loginAttempts.lockedUntil = Date.now() + 45000;
      loginAttempts.count = 0;
    }
  }
  function resetFailedAttempts() {
    loginAttempts.count = 0;
    loginAttempts.lockedUntil = 0;
  }
  function hashUserPass(email, plainPass) {
    var em = String(email || "").trim().toLowerCase();
    return sha256Hex("edutech-user-v138|" + em + "|" + String(plainPass == null ? "" : plainPass));
  }
  function verifyUserPass(userObj, plainPass) {
    if (!userObj) return false;
    var inputStr = String(plainPass == null ? "" : plainPass);
    var expectedHash = hashUserPass(userObj.email, inputStr);
    if (userObj.passHash && userObj.passHash === expectedHash) return true;
    if (typeof userObj.pass === "string" && userObj.pass.length > 0 && userObj.pass !== "hashed") {
      if (userObj.pass === inputStr) {
        userObj.passHash = expectedHash;
        delete userObj.pass;
        return true;
      }
    }
    // الحسابات التجريبية الافتراضية تقبل 123456 إن لم تُغيّر كلمة مرورها
    if (!userObj.passHash && !userObj.pass && inputStr === "123456") return true;
    return false;
  }
  function sanitizeUserForStorage(u) {
    if (!u || typeof u !== "object") return u;
    var copy = Object.assign({}, u);
    if (copy.pass && copy.pass !== "google-auth" && !copy.passHash) {
      copy.passHash = hashUserPass(copy.email, copy.pass);
    }
    delete copy.pass;
    return copy;
  }
  function pinMatches(v) {
    // مع تفعيل السحابة لا يكفي الرمز: يلزم حساب Google الموثّق للإدارة (رمز من 4 أرقام قابل للتخمين)
    if (window.Cloud && window.Cloud.enabled && !window.Cloud.isAdmin) return false;
    var input = String(v == null ? "" : v).trim();
    if (!input) return false;
    var h = sha256Hex("edutech-mindset|" + input);
    if (adminPerms && adminPerms.customPinHash && h === adminPerms.customPinHash) return true;
    return h === ADMIN_PIN_HASH;
  }

  function getUserPermRecord(email) {
    var em = String(email || "").trim().toLowerCase();
    if (!em) return { mode: "custom", grantedTools: [], blockedTools: [], note: "" };
    if (!adminPerms.userPermissions) adminPerms.userPermissions = {};
    if (!adminPerms.userPermissions[em]) {
      adminPerms.userPermissions[em] = { mode: "custom", grantedTools: [], blockedTools: [], note: "" };
    }
    var rec = adminPerms.userPermissions[em];
    if (!Array.isArray(rec.grantedTools)) rec.grantedTools = [];
    if (!Array.isArray(rec.blockedTools)) rec.blockedTools = [];
    if (!rec.mode) rec.mode = "custom";
    return rec;
  }

  function evaluateToolAccessForUser(toolId, userObj, ignoreAdminBypass) {
    var tool = TOOL_MAP[toolId];
    if (!tool) {
      return { allowed: true, reason: "unmanaged", label: "🟢 متاح", badgeClass: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-300 border-emerald-500/30" };
    }
    if (!ignoreAdminBypass && !state.impersonatingUserEmail && (state.isAdminUnlocked || (typeof window.isSuperAdminUser === "function" && window.isSuperAdminUser()))) {
      return { allowed: true, reason: "admin", label: "👑 مفتوح للإدارة", badgeClass: "bg-rose-500/20 text-rose-600 dark:text-rose-300 border-rose-500/40" };
    }
    var effectiveUser = userObj;
    if (state.impersonatingUserEmail && !userObj) {
      effectiveUser = registeredUsers.filter(function (u) { return u.email === state.impersonatingUserEmail; })[0] || null;
    }
    var gEm = state.impersonatingUserEmail ? "" : googleEmail();
    if (!effectiveUser && gEm && cloudGrants[gEm]) effectiveUser = { email: gEm, name: gEm, roleLabel: "طالب" };
    if (!effectiveUser) {
      if (adminPerms.requireLoginForTools) {
        return { allowed: false, reason: "login_required", label: "🔒 يتطلب تسجيل الدخول", badgeClass: "bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-500/40" };
      }
      var gAllowed = (tool.defaultRoles || []).indexOf("guest") !== -1;
      if (gAllowed) {
        return { allowed: true, reason: "guest_allowed", label: "🟢 متاح للزوار", badgeClass: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30" };
      }
      return { allowed: false, reason: "guest_blocked", label: "🔒 محجوب عن الزوار (سجّل دخولك)", badgeClass: "bg-rose-500/15 text-rose-600 dark:text-rose-300 border-rose-500/30" };
    }

    var cRec = gEm && cloudGrants[gEm] ? cloudGrants[gEm] : null;
    var uRec = cRec || getUserPermRecord(effectiveUser.email);
    if (uRec.mode === "suspended") {
      return { allowed: false, reason: "user_suspended", label: "🚫 الحساب موقوف إدارياً", badgeClass: "bg-rose-600 text-white border-rose-500" };
    }
    if (uRec.mode === "vip_all") {
      return { allowed: true, reason: "vip_all", label: "🌟 ممنوح شامل (VIP)", badgeClass: "bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-500/40" };
    }
    if (uRec.blockedTools.indexOf(toolId) !== -1) {
      return { allowed: false, reason: "user_blocked", label: "🚫 محجوب بقرار إداري خاص", badgeClass: "bg-rose-500/20 text-rose-600 dark:text-rose-300 border-rose-500/40" };
    }
    if (uRec.grantedTools.indexOf(toolId) !== -1) {
      return { allowed: true, reason: "user_granted", label: "⭐ ممنوح لك بقرار إداري", badgeClass: "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border-emerald-500/40" };
    }

    var roleKey = effectiveUser.roleLabel || "طالب";
    var rPol = (adminPerms.rolePolicies && adminPerms.rolePolicies[roleKey]) || {};
    var rAllowed = typeof rPol[toolId] === "boolean" ? rPol[toolId] : ((tool.defaultRoles || []).indexOf(roleKey) !== -1);
    if (rAllowed) {
      return { allowed: true, reason: "role_allowed", label: "🟢 متاح (" + roleKey + ")", badgeClass: "bg-sky-500/15 text-sky-700 dark:text-sky-300 border-sky-500/30" };
    }
    return { allowed: false, reason: "role_blocked", label: "🔒 يتطلب إذن الإدارة", badgeClass: "bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-300 dark:border-slate-700" };
  }

  function canAccessTool(toolId) {
    return evaluateToolAccessForUser(toolId, currentUser, false).allowed;
  }

  function showBlockedToolModal(toolId) {
    var tool = TOOL_MAP[toolId] || { id: toolId, title: "الأداة التعليمية", ico: "🛠️", catLabel: "أدوات المنصة" };
    var activeU = state.impersonatingUserEmail
      ? (registeredUsers.filter(function (u) { return u.email === state.impersonatingUserEmail; })[0] || null)
      : currentUser;
    var status = evaluateToolAccessForUser(toolId, activeU, false);

    var oldM = document.getElementById("edu-access-guard-modal");
    if (oldM) oldM.remove();

    var m = document.createElement("div");
    m.id = "edu-access-guard-modal";
    m.className = "fixed inset-0 z-[9999] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4";
    m.innerHTML =
      '<div class="bg-white dark:bg-slate-900 border-2 border-rose-500/50 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4 text-right" dir="rtl">' +
        '<div class="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">' +
          '<div class="flex items-center gap-2.5">' +
            '<div class="w-11 h-11 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-2xl">🔒</div>' +
            '<div>' +
              '<h3 class="text-base font-black text-slate-900 dark:text-white">وصول مقيّد بصلاحيات الإدارة</h3>' +
              '<p class="text-[11px] font-bold text-rose-600 dark:text-rose-400">' + esc(status.label) + '</p>' +
            '</div>' +
          '</div>' +
          '<button type="button" id="eag-close" class="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-black">✕</button>' +
        '</div>' +
        '<div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1.5 text-xs">' +
          '<div class="font-black text-sm text-slate-900 dark:text-white">' + esc(tool.ico + " " + tool.title) + '</div>' +
          '<div class="text-slate-500 dark:text-slate-400">' + esc(tool.desc || "") + '</div>' +
          '<div class="pt-2 text-[11px] font-bold text-amber-700 dark:text-amber-300">' +
            (activeU
              ? '👤 الحساب الحالي: ' + esc(activeU.name) + ' (' + esc(activeU.roleLabel || "عضو") + ') — هذه الأداة غير مفعّلة لحسابك حالياً.'
              : '🌐 أنت تتصفح كزائر غير مسجّل. يرجى تسجيل الدخول بحساب مخوّل أو طلب منح الصلاحية من إدارة المنصة.') +
          '</div>' +
        '</div>' +
        (activeU ? (
          '<div class="space-y-2.5 text-xs">' +
            '<label class="block font-black text-slate-700 dark:text-slate-200">📨 هل ترغب بإرسال طلب فوري للإدارة لتفعيل هذه الأداة لحسابك؟</label>' +
            '<input id="eag-req-note" type="text" placeholder="اكتب سبب حاجتك للأداة (مثال: تحضير حصة، مشروع تخرج، مراجعة توجيهي)..." class="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 font-bold text-slate-900 dark:text-white outline-none focus:border-sky-500"/>' +
            '<div class="flex flex-wrap gap-2 pt-1">' +
              '<button type="button" id="eag-send-req" class="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow-lg">📨 إرسال طلب الصلاحية للإدارة</button>' +
              '<button type="button" id="eag-go-account" class="py-2.5 px-4 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-black">👤 عرض صلاحيات حسابي</button>' +
            '</div>' +
          '</div>'
        ) : (
          '<div class="flex flex-wrap gap-2 text-xs">' +
            '<button type="button" id="eag-go-login" class="flex-1 py-3 px-4 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-black shadow-lg">🔑 تسجيل الدخول / إنشاء حساب أو إدخال كود تفعيل</button>' +
          '</div>'
        )) +
      '</div>';

    document.body.appendChild(m);
    document.getElementById("eag-close").onclick = function () { m.remove(); };
    m.onclick = function (ev) { if (ev.target === m) m.remove(); };

    var sendBtn = document.getElementById("eag-send-req");
    if (sendBtn && activeU) {
      sendBtn.onclick = function () {
        var noteInp = document.getElementById("eag-req-note");
        var note = (noteInp && noteInp.value.trim()) || "أرجو التكرم بمنحي صلاحية الوصول لهذه الأداة التعليمية.";
        submitToolAccessRequest(tool.id, note, activeU);
        m.remove();
      };
    }
    var accBtn = document.getElementById("eag-go-account");
    if (accBtn) {
      accBtn.onclick = function () {
        m.remove();
        state.topNav = "account";
        state.accountSubTab = "my_permissions";
        renderMainOrganizer();
        focusAndScrollTo("orgAccountSectionBox", "🛡️ تم فتح سجل صلاحيات حسابك");
      };
    }
    var loginBtn = document.getElementById("eag-go-login");
    if (loginBtn) {
      loginBtn.onclick = function () {
        m.remove();
        state.topNav = "account";
        state.authMode = "login";
        renderMainOrganizer();
        focusAndScrollTo("orgAccountSectionBox", "🔑 سجل دخولك أو أنشئ حساباً للوصول للأدوات");
      };
    }
  }

  function submitToolAccessRequest(toolId, noteText, userObj) {
    var u = userObj || currentUser;
    if (!u) {
      toast("⚠️ يرجى تسجيل الدخول أولاً لإرسال طلب صلاحية", "warning");
      return;
    }
    var tool = TOOL_MAP[toolId] || { id: toolId, title: toolId };
    if (!Array.isArray(adminPerms.accessRequests)) adminPerms.accessRequests = [];
    var existing = adminPerms.accessRequests.filter(function (r) {
      return r.userEmail === u.email && r.toolId === toolId && r.status === "pending";
    })[0];
    if (existing) {
      existing.note = noteText || existing.note;
      saveAdminPerms();
      toast("📩 طلبك لهذه الأداة قيد المراجعة لدى الإدارة بالفعل ✓", "info");
      return;
    }
    var now = new Date();
    var tStr = now.getFullYear() + "-" + String(now.getMonth() + 1).padStart(2, "0") + "-" + String(now.getDate()).padStart(2, "0") + " " + String(now.getHours()).padStart(2, "0") + ":" + String(now.getMinutes()).padStart(2, "0");
    adminPerms.accessRequests.unshift({
      id: "req-" + Date.now(),
      userEmail: u.email,
      userName: u.name,
      userRole: u.roleLabel || "طالب",
      toolId: toolId,
      toolTitle: tool.title,
      note: noteText || "طلب تفعيل الأداة للاستخدام التعليمي",
      requestedAt: tStr,
      status: "pending"
    });
    saveAdminPerms();
    var sentCloud = pushRequestToCloud(adminPerms.accessRequests[0]);
    if (sentCloud) saveAdminPerms();
    renderMainOrganizer();
    toast("✅ تم إرسال طلب الصلاحية لأداة «" + tool.title + "» إلى الإدارة بنجاح!", "success");
  }

  function logPermAudit(actionText) {
    if (!Array.isArray(adminPerms.permissionAuditLog)) adminPerms.permissionAuditLog = [];
    var now = new Date();
    var tStr = now.getFullYear() + "-" + String(now.getMonth() + 1).padStart(2, "0") + "-" + String(now.getDate()).padStart(2, "0") + " " + String(now.getHours()).padStart(2, "0") + ":" + String(now.getMinutes()).padStart(2, "0");
    adminPerms.permissionAuditLog.unshift({
      id: "aud-" + Date.now(),
      time: tStr,
      action: actionText,
      actor: "إدارة المنصة (أ. باسل الفقعاوي)"
    });
    if (adminPerms.permissionAuditLog.length > 60) {
      adminPerms.permissionAuditLog = adminPerms.permissionAuditLog.slice(0, 60);
    }
  }

  function redeemActivationCodeForUser(rawCode, userObj) {
    var u = userObj || currentUser;
    var codeStr = String(rawCode || "").trim().toUpperCase();
    if (!codeStr) {
      toast("⚠️ يرجى إدخال كود التفعيل أولاً", "warning");
      return false;
    }
    if (!u) {
      toast("⚠️ يرجى تسجيل الدخول أو إنشاء حساب أولاً لتفعيل الكود", "warning");
      return false;
    }
    var codes = adminPerms.activationCodes || [];
    var hit = codes.filter(function (c) { return String(c.code || "").toUpperCase() === codeStr && c.active !== false; })[0];
    if (!hit) {
      toast("❌ كود التفعيل غير صحيح أو منتهي الصلاحية", "error");
      return false;
    }
    if (hit.maxUses && hit.usedCount >= hit.maxUses) {
      toast("⚠️ تم استنفاد الحد الأقصى لمرات استخدام هذا الكود", "warning");
      return false;
    }
    var rec = getUserPermRecord(u.email);
    if (hit.grantMode === "vip_all") {
      rec.mode = "vip_all";
      rec.blockedTools = [];
    } else {
      rec.mode = "custom";
      (hit.tools || []).forEach(function (tid) {
        rec.blockedTools = rec.blockedTools.filter(function (x) { return x !== tid; });
        if (rec.grantedTools.indexOf(tid) === -1) rec.grantedTools.push(tid);
      });
    }
    if (hit.expiresDays) {
      var expDate = new Date(Date.now() + hit.expiresDays * 86400000);
      rec.expiresAt = expDate.toISOString().slice(0, 10);
    }
    hit.usedCount = (hit.usedCount || 0) + 1;
    logPermAudit("تفعيل كود «" + hit.code + "» للعضو " + u.name + " (" + u.email + ")");
    saveAdminPerms();
    renderMainOrganizer();
    toast("🎉 تم تفعيل الكود «" + hit.label + "» لحسابك بنجاح وفتح الأدوات المخصصة!", "success");
    return true;
  }

  function cloneNavSnapshot() {
    return {
      topNav: state.topNav,
      curriculumSubTab: state.curriculumSubTab,
      toolsCat: state.toolsCat,
      openedToolId: state.openedToolId,
      librarySubTab: state.librarySubTab,
      mybagSubTab: state.mybagSubTab,
      uniSubTab: state.uniSubTab,
      accountSubTab: state.accountSubTab,
      adminTab: state.adminTab,
      stageId: state.stageId,
      gradeId: state.gradeId,
      branchId: state.branchId,
      subjectId: state.subjectId,
      unitIdx: state.unitIdx,
      activeStudyMode: state.activeStudyMode,
      openedAdminStudioId: state.openedAdminStudioId
    };
  }

  function pushNavHistory() {
    if (isRestoringHistory) return;
    var snap = cloneNavSnapshot();
    var last = navStack.length ? navStack[navStack.length - 1] : null;
    if (last && JSON.stringify(last) === JSON.stringify(snap)) return;
    navStack.push(snap);
    if (navStack.length > 40) navStack.shift();
    try {
      window.history.pushState({ eduMasterNav: snap }, "");
    } catch (e) {}
  }

  function applyNavSnapshot(snap) {
    if (!snap) return;
    isRestoringHistory = true;
    state.topNav = snap.topNav || "curriculum";
    state.curriculumSubTab = snap.curriculumSubTab || "textbook";
    state.toolsCat = snap.toolsCat || "all";
    state.openedToolId = snap.openedToolId || "";
    state.librarySubTab = snap.librarySubTab || "curriculum_cultural";
    state.mybagSubTab = snap.mybagSubTab || "reading_notes";
    state.uniSubTab = snap.uniSubTab || "majors_tawjihi";
    state.accountSubTab = snap.accountSubTab || "profile";
    state.adminTab = snap.adminTab || "permissions_mgr";
    state.stageId = snap.stageId || "stage-primary";
    state.gradeId = snap.gradeId || "g4";
    state.branchId = snap.branchId || "";
    state.subjectId = snap.subjectId || "";
    state.unitIdx = snap.unitIdx || 0;
    state.activeStudyMode = snap.activeStudyMode || "book";
    state.openedAdminStudioId = snap.openedAdminStudioId || "";
    state.quizAnswers = {};
    renderMainOrganizer();
    ensureFloatingQuickBar();
    isRestoringHistory = false;
  }

  function goBackStep() {
    if (state.openedToolId) {
      state.openedToolId = "";
      renderMainOrganizer();
      focusAndScrollTo("orgToolsSectionBox", "⬅ عدت إلى فهرس الأدوات والمختبرات");
      return true;
    }
    if (navStack.length > 1) {
      navStack.pop();
      var prev = navStack[navStack.length - 1];
      applyNavSnapshot(prev);
      toast("⬅ تم الرجوع للخطوة السابقة بسلاسة", "info");
      return true;
    }
    if (state.topNav !== "curriculum") {
      state.topNav = "curriculum";
      renderMainOrganizer();
      focusAndScrollTo("orgStepStagesBox", "🏠 عدت إلى المراحل والمنهاج");
      return true;
    }
    if (state.activeStudyMode !== "book") {
      state.activeStudyMode = "book";
      renderMainOrganizer();
      focusAndScrollTo("orgBookPagePaper", "📖 عدت إلى صفحة الكتاب");
      return true;
    }
    focusAndScrollTo("orgStepStagesBox", "🏫 أنت في المستوى الرئيسي للمراحل");
    return false;
  }

  window.addEventListener("popstate", function (ev) {
    if (ev.state && ev.state.eduMasterNav) {
      if (navStack.length > 1) navStack.pop();
      applyNavSnapshot(ev.state.eduMasterNav);
    } else if (navStack.length > 1) {
      navStack.pop();
      applyNavSnapshot(navStack[navStack.length - 1]);
    }
  });

  function isEffectiveSuperAdmin() {
    if (state.impersonatingUserEmail) return false;
    return !!(state.isAdminUnlocked || (typeof window.isSuperAdminUser === "function" && window.isSuperAdminUser()));
  }

  function applyTypographyPrefs() {
    try {
      var fontMap = {
        cairo: "'Cairo', system-ui, sans-serif",
        tajawal: "'Tajawal', system-ui, sans-serif",
        alexandria: "'Alexandria', system-ui, sans-serif",
        almarai: "'Almarai', system-ui, sans-serif"
      };
      try { if (window.EduFonts) window.EduFonts.ensure(readerPrefs.siteFont || "cairo"); } catch (e0) {}
      var fFam = fontMap[readerPrefs.siteFont || "cairo"] || fontMap.cairo;
      var fScale = (readerPrefs.siteScale || 100) + "%";
      document.documentElement.style.setProperty("--site-font", fFam);
      document.documentElement.style.setProperty("--site-font-scale", fScale);
      document.body.style.fontFamily = fFam;
    } catch (e) {}
  }

  function syncHeaderAuthUI() {
    try {
      var isAdm = isEffectiveSuperAdmin();
      if (document.body) {
        document.body.classList.toggle("is-super-admin", isAdm);
      }
      var navAdm = document.getElementById("navAdminTopBtn");
      var mobAdm = document.getElementById("mobAdminTabBtn");
      var sovBar = document.getElementById("eduSovereignAdminBar");
      if (navAdm) {
        navAdm.classList.toggle("hidden", !isAdm);
        navAdm.classList.toggle("flex", isAdm);
      }
      if (mobAdm) {
        mobAdm.classList.toggle("hidden", !isAdm);
        mobAdm.classList.toggle("flex", isAdm);
      }
      if (sovBar) {
        sovBar.classList.toggle("hidden", !isAdm);
        sovBar.classList.toggle("flex", isAdm);
      }
      var btnLoginHeader = document.getElementById("btnGoogleLoginHeader");
      var btnUserHeader = document.getElementById("btnUserHeaderProfile");
      var hName = document.getElementById("headerUserName");
      var hRole = document.getElementById("headerUserRole");
      var hAvatar = document.getElementById("headerUserAvatar");
      if (currentUser) {
        if (btnLoginHeader) btnLoginHeader.classList.add("hidden");
        if (btnUserHeader) {
          btnUserHeader.classList.remove("hidden");
          btnUserHeader.classList.add("flex");
        }
        if (hName) hName.textContent = currentUser.name;
        if (hRole) hRole.textContent = (currentUser.roleLabel || "عضو") + " • متصل ✓";
        if (hAvatar) hAvatar.textContent = (currentUser.name || "ع").trim().charAt(0);
      } else {
        if (btnLoginHeader) btnLoginHeader.classList.remove("hidden");
        if (btnUserHeader) {
          btnUserHeader.classList.add("hidden");
          btnUserHeader.classList.remove("flex");
        }
      }
      if (typeof window.syncGlobalWorkspaceWithUser === "function") {
        window.syncGlobalWorkspaceWithUser();
      }
    } catch (e) {}
  }

  function loadData() {
    try {
      var rawTree = localStorage.getItem(TREE_LS_KEY);
      masterTree = rawTree ? JSON.parse(rawTree) : null;
      if (!Array.isArray(masterTree) || !masterTree.length) {
        masterTree = JSON.parse(JSON.stringify(DEFAULT_MASTER_TREE));
      }
    } catch (e) {
      masterTree = JSON.parse(JSON.stringify(DEFAULT_MASTER_TREE));
    }

    try {
      state.isAdminUnlocked = (!(window.Cloud && window.Cloud.enabled) && localStorage.getItem(ADMIN_MODE_KEY) === "1") ||
        (typeof window.isSuperAdminUser === "function" && window.isSuperAdminUser());
    } catch (e) {}

    try {
      bookmarks = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "{}") || {};
    } catch (e) { bookmarks = {}; }

    try {
      pageNotes = JSON.parse(localStorage.getItem(PAGE_NOTES_KEY) || "{}") || {};
    } catch (e) { pageNotes = {}; }

    try {
      completedUnits = JSON.parse(localStorage.getItem(COMPLETED_UNITS_KEY) || "{}") || {};
    } catch (e) { completedUnits = {}; }

    try {
      var rawUsers = localStorage.getItem(USERS_LS_KEY);
      registeredUsers = rawUsers ? JSON.parse(rawUsers) : null;
      if (!Array.isArray(registeredUsers) || !registeredUsers.length) {
        registeredUsers = JSON.parse(JSON.stringify(DEFAULT_DEMO_USERS)).map(sanitizeUserForStorage);
      } else {
        registeredUsers = registeredUsers.map(sanitizeUserForStorage);
      }
      localStorage.setItem(USERS_LS_KEY, JSON.stringify(registeredUsers));
    } catch (e) {
      registeredUsers = JSON.parse(JSON.stringify(DEFAULT_DEMO_USERS)).map(sanitizeUserForStorage);
    }

    try {
      var cuRaw = JSON.parse(localStorage.getItem(CURRENT_USER_LS_KEY) || "null");
      currentUser = cuRaw ? sanitizeUserForStorage(cuRaw) : null;
    } catch (e) { currentUser = null; }

    try {
      pinnedSubjects = JSON.parse(localStorage.getItem(PINNED_SUBS_KEY) || "{}") || {};
    } catch (e) { pinnedSubjects = {}; }

    try {
      if (window.location.hash && window.location.hash.indexOf("#edu=") === 0) {
        var hParts = decodeURIComponent(window.location.hash.slice(5)).split("|");
        if (hParts.length >= 4) {
          state.stageId = hParts[0];
          state.gradeId = hParts[1];
          state.branchId = hParts[2];
          state.subjectId = hParts[3];
          if (hParts[4]) {
            var hp = parseInt(hParts[4], 10);
            if (hp > 0) bookmarks[hParts[3]] = { page: hp, note: "" };
          }
        }
      }
    } catch (e) {}

    try {
      var rp = JSON.parse(localStorage.getItem(READER_PREFS_KEY) || "{}");
      if (rp && rp.fontSize) readerPrefs.fontSize = rp.fontSize;
      if (rp && rp.paperTheme) readerPrefs.paperTheme = rp.paperTheme;
      if (rp && rp.siteFont) readerPrefs.siteFont = rp.siteFont;
      if (rp && rp.siteScale) readerPrefs.siteScale = rp.siteScale;
      applyTypographyPrefs();
    } catch (e) {}
    try {
      var savedRooms = JSON.parse(localStorage.getItem(COLLAB_FEED_KEY) || "null");
      if (Array.isArray(savedRooms) && savedRooms.length) collabRooms = savedRooms;
    } catch (e) {}

    try {
      var apRaw = localStorage.getItem(ADMIN_PERMS_KEY) || localStorage.getItem(LEGACY_ADMIN_PERMS_KEY) || "{}";
      var ap = JSON.parse(apRaw);
      if (ap && typeof ap === "object") {
        Object.keys(adminPerms).forEach(function (k) {
          if (typeof ap[k] !== "undefined" && k !== "rolePolicies" && k !== "userPermissions" && k !== "accessRequests") {
            adminPerms[k] = ap[k];
          }
        });
        if (ap.rolePolicies && typeof ap.rolePolicies === "object") {
          Object.keys(ap.rolePolicies).forEach(function (rk) {
            adminPerms.rolePolicies[rk] = Object.assign(adminPerms.rolePolicies[rk] || {}, ap.rolePolicies[rk]);
          });
        }
        if (ap.userPermissions && typeof ap.userPermissions === "object") {
          adminPerms.userPermissions = Object.assign(adminPerms.userPermissions || {}, ap.userPermissions);
        }
        if (Array.isArray(ap.accessRequests)) {
          adminPerms.accessRequests = ap.accessRequests;
        }
        if (Array.isArray(ap.activationCodes) && ap.activationCodes.length) {
          adminPerms.activationCodes = ap.activationCodes;
        }
        if (Array.isArray(ap.permissionAuditLog) && ap.permissionAuditLog.length) {
          adminPerms.permissionAuditLog = ap.permissionAuditLog;
        }
      }
      delete adminPerms.adminPin;
    } catch (e) {}

    if (registeredUsers.length && (!state.selectedAdminUserEmail || !registeredUsers.some(function (u) { return u.email === state.selectedAdminUserEmail; }))) {
      state.selectedAdminUserEmail = registeredUsers[0].email;
    }
    syncHeaderAuthUI();
    if (typeof window.syncGlobalWorkspaceWithUser === "function") {
      try { window.syncGlobalWorkspaceWithUser(); } catch (e) {}
    }
  }

  /* ====== مزامنة الصلاحيات مع Firebase (تصل لكل الأجهزة) ======
     - الإدارة (حساب Google الموثّق) تكتب: سياسات عامة + صلاحيات كل فرد + أكواد/سجل خاص.
     - كل زائر يقرأ السياسات العامة، والمستخدم الموثّق يقرأ صلاحيته الفردية فقط. */
  var cloudAccessReady = false;
  var warnedLocalOnly = false;
  var pushTimer = null, uiTimer = null;
  var pushedSig = {};
  var ACCESS_RESERVED = ["userPermissions", "accessRequests", "activationCodes", "permissionAuditLog", "adminPin", "customPinHash"];

  function cloudOk() { return !!(window.Cloud && window.Cloud.enabled); }
  function googleEmail() {
    var u = window.Cloud && window.Cloud.user;
    return (u && u.emailVerified && u.email) ? String(u.email).trim().toLowerCase() : "";
  }
  function normRec(rec) {
    rec = rec || {};
    return {
      mode: rec.mode || "custom",
      grantedTools: Array.isArray(rec.grantedTools) ? rec.grantedTools.slice() : [],
      blockedTools: Array.isArray(rec.blockedTools) ? rec.blockedTools.slice() : [],
      note: rec.note || "",
      expiresAt: rec.expiresAt || ""
    };
  }
  function persistLocalOnly() {
    try { localStorage.setItem(ADMIN_PERMS_KEY, JSON.stringify(adminPerms)); } catch (e) {}
  }
  function refreshAccessUI() {
    clearTimeout(uiTimer);
    uiTimer = setTimeout(function () {
      try { if (typeof renderMainOrganizer === "function") renderMainOrganizer(); } catch (e) {}
    }, 300);
  }
  function policiesPayload() {
    var o = {};
    Object.keys(adminPerms).forEach(function (k) { if (ACCESS_RESERVED.indexOf(k) === -1) o[k] = adminPerms[k]; });
    o.updatedAt = Date.now();
    return o;
  }
  function applyPolicies(doc) {
    if (!doc) return;
    Object.keys(doc).forEach(function (k) {
      if (ACCESS_RESERVED.indexOf(k) !== -1 || k === "updatedAt") return;
      if (k === "rolePolicies" && doc[k] && typeof doc[k] === "object") {
        if (!adminPerms.rolePolicies) adminPerms.rolePolicies = {};
        Object.keys(doc[k]).forEach(function (rk) { adminPerms.rolePolicies[rk] = Object.assign({}, doc[k][rk]); });
      } else {
        adminPerms[k] = doc[k];
      }
    });
    persistLocalOnly();
  }
  var lastCloudSync = "";
  function doPush() {
    var C = window.Cloud, jobs = [];
    if (!cloudOk() || !C.isAdmin) return Promise.resolve(false);
    function track(pr, onFail) {
      jobs.push(Promise.resolve(pr).catch(function () { if (onFail) onFail(); throw new Error("push"); }));
    }
    try { track(C.saveAccessPolicies(policiesPayload())); } catch (e) {}
    var ups = adminPerms.userPermissions || {};
    Object.keys(ups).forEach(function (em) {
      // نرفع فقط عناوين Google الحقيقية (حسابات @edutech.ps المحلية لا تُوثَّق ولا يمكن ربطها بهوية)
      if (em.indexOf("@") < 1 || /@edutech\.ps$/.test(em)) return;
      var r = normRec(ups[em]);
      var meaningful = r.mode !== "custom" || r.grantedTools.length || r.blockedTools.length || r.note || r.expiresAt;
      if (!meaningful) return;
      var sig = JSON.stringify(r);
      if (pushedSig[em] === sig) return;
      pushedSig[em] = sig;
      r.updatedAt = Date.now();
      try { track(C.saveGrant(em, r), function () { delete pushedSig[em]; }); } catch (e) { delete pushedSig[em]; }
    });
    try {
      track(C.saveAdminState({
        activationCodes: adminPerms.activationCodes || [],
        permissionAuditLog: (adminPerms.permissionAuditLog || []).slice(0, 60),
        updatedAt: Date.now()
      }));
    } catch (e) {}
    (adminPerms.accessRequests || []).forEach(function (rq) {
      if (!rq || !rq.cloud || !rq.id) return;
      var sg = "req:" + rq.status;
      if (pushedSig[rq.id] === sg) return;
      pushedSig[rq.id] = sg;
      try { track(C.updateAccessRequest(rq.id, { status: rq.status, decidedAt: Date.now() }), function () { delete pushedSig[rq.id]; }); } catch (e) { delete pushedSig[rq.id]; }
    });
    return Promise.all(jobs).then(function () {
      lastCloudSync = new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
      return true;
    }, function () { return false; });
  }
  function pushAccessToCloud() {
    clearTimeout(pushTimer);
    pushTimer = setTimeout(doPush, 800);
  }
  /* بث فوري يدويًا (زر «مزامنة الصلاحيات للسحابة الآن»): يعيد رفع كل شيء ويُبلغ بالنتيجة الحقيقية */
  function pushAccessNow() {
    if (!cloudOk()) { toast("⚠️ Firebase غير مفعّل في هذه النسخة.", "warning"); return; }
    if (!window.Cloud.isAdmin) {
      toast("🔒 المزامنة تتطلب تسجيل الدخول بحساب Google الخاص بالإدارة (الرمز وحده لا يكفي لكتابة السحابة).", "warning");
      return;
    }
    pushedSig = {};
    persistLocalOnly();
    doPush().then(function (ok) {
      toast(ok ? ("☁️ تم بث الصلاحيات إلى Firebase لكل الأجهزة ✓ (" + lastCloudSync + ")") : "❌ تعذّر الحفظ في Firebase — تأكد من نشر firestore.rules وصلاحية حساب الإدارة", ok ? "success" : "error");
    });
  }

  function hydrateAdminFromCloud() {
    var C = window.Cloud;
    if (!cloudOk() || !C.isAdmin) return;
    C.listGrants().then(function (g) {
      if (!adminPerms.userPermissions) adminPerms.userPermissions = {};
      Object.keys(g || {}).forEach(function (em) {
        adminPerms.userPermissions[em] = normRec(g[em]);
        pushedSig[em] = JSON.stringify(normRec(g[em]));
      });
      persistLocalOnly();
      refreshAccessUI();
    }).catch(function () {});
    C.loadAdminState().then(function (st) {
      if (!st) return;
      if (Array.isArray(st.activationCodes) && st.activationCodes.length) adminPerms.activationCodes = st.activationCodes;
      if (Array.isArray(st.permissionAuditLog) && st.permissionAuditLog.length) adminPerms.permissionAuditLog = st.permissionAuditLog;
      persistLocalOnly();
      refreshAccessUI();
    }).catch(function () {});
    if (typeof C.listUsers === "function") {
      C.listUsers().then(function (cUsers) {
        if (!Array.isArray(cUsers) || !cUsers.length) return;
        var byEmail = {};
        registeredUsers.forEach(function (u) { byEmail[String(u.email || "").toLowerCase()] = u; });
        var added = 0;
        cUsers.forEach(function (cu) {
          var em = String(cu.email || "").toLowerCase().trim();
          if (!em || em.indexOf("@") < 1) return;
          var role = "طالب", rRaw = String(cu.role || "");
          if (/معلم|مشرف|مدير|مدرب/.test(rRaw)) role = "معلم";
          else if (/توجيهي/.test(rRaw)) role = "توجيهي";
          else if (/جامع|باحث/.test(rRaw)) role = "جامعي";
          else if (/ولي/.test(rRaw)) role = "ولي أمر";
          if (byEmail[em]) {
            byEmail[em].uid = cu.uid || byEmail[em].uid;
            byEmail[em].name = cu.name || byEmail[em].name;
            byEmail[em].fromCloud = true;
          } else {
            registeredUsers.push({
              uid: cu.uid || "", name: cu.name || em.split("@")[0], email: em, pass: "google-auth",
              roleLabel: role, gradeId: "g10", gradeName: cu.grade || "الصف العاشر الأساسي",
              school: cu.school || "حساب Google سحابي ☁️", fromCloud: true, createdAt: String(cu.createdAt || "").slice(0, 10)
            });
            added++;
          }
        });
        saveUsers();
        refreshAccessUI();
      }).catch(function () {});
    }
    C.listAccessRequests().then(function (list) {
      if (!Array.isArray(adminPerms.accessRequests)) adminPerms.accessRequests = [];
      (list || []).forEach(function (q) {
        var local = adminPerms.accessRequests.filter(function (x) { return x.id === q.id; })[0];
        if (local) { local.cloud = true; if (q.status && q.status !== "pending") local.status = q.status; return; }
        adminPerms.accessRequests.push({
          id: q.id, userEmail: q.userEmail, userName: q.userName || q.userEmail, userRole: q.userRole || "طالب",
          toolId: q.toolId, toolTitle: q.toolTitle || q.toolId, note: q.note || "", requestedAt: q.requestedAt || "",
          status: q.status || "pending", cloud: true
        });
      });
      persistLocalOnly();
      refreshAccessUI();
    }).catch(function () {});
  }
  var grantUnsub = null;
  function startCloudAccess() {
    var C = window.Cloud;
    if (cloudAccessReady || !cloudOk() || typeof C.subscribeAccessPolicies !== "function") return false;
    cloudAccessReady = true;
    try { C.subscribeAccessPolicies(function (doc) { applyPolicies(doc); refreshAccessUI(); }, function () {}); } catch (e) {}
    try {
      C.onAuth(function (u) {
        if (grantUnsub) { try { grantUnsub(); } catch (e) {} grantUnsub = null; }
        cloudGrants = {};
        if (!u) { refreshAccessUI(); return; }
        if (C.isAdmin) hydrateAdminFromCloud();
        var em = googleEmail();
        if (em) {
          grantUnsub = C.watchMyGrant(em, function (rec) {
            if (rec) cloudGrants[em] = normRec(rec); else delete cloudGrants[em];
            refreshAccessUI();
          }, function () {});
        }
      });
    } catch (e) {}
    return true;
  }
  (function waitForCloud() {
    var tries = 0;
    var iv = setInterval(function () {
      tries++;
      if (startCloudAccess() || tries > 60) clearInterval(iv);
    }, 500);
  })();
  function pushRequestToCloud(rq) {
    try {
      var em = googleEmail();
      if (!cloudOk() || !em || !rq) return false;
      window.Cloud.sendAccessRequest(rq.id, {
        userEmail: em, userName: rq.userName || em, userRole: rq.userRole || "طالب", toolId: rq.toolId,
        toolTitle: rq.toolTitle || rq.toolId, note: rq.note || "", requestedAt: rq.requestedAt || "",
        status: "pending", createdAt: window.Cloud.stamp()
      }).catch(function () {});
      rq.cloud = true;
      return true;
    } catch (e) { return false; }
  }

  function saveAdminPerms() {
    persistLocalOnly();
    if (!cloudOk()) return;
    if (window.Cloud.isAdmin) { pushAccessToCloud(); return; }
    if (state.isAdminUnlocked && !warnedLocalOnly) {
      warnedLocalOnly = true;
      toast("⚠️ حُفظ هذا التغيير على جهازك فقط. سجّل الدخول بحساب Google الخاص بالإدارة ليصل لكل الأجهزة.", "warning");
    }
  }

  function saveTree() {
    invalidateFlatCache();
    try { localStorage.setItem(TREE_LS_KEY, JSON.stringify(masterTree)); } catch (e) {}
  }

  function saveBookmarks() {
    try { localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(bookmarks)); } catch (e) {}
  }

  function savePageNotes() {
    try { localStorage.setItem(PAGE_NOTES_KEY, JSON.stringify(pageNotes)); } catch (e) {}
  }

  function saveCompletedUnits() {
    try { localStorage.setItem(COMPLETED_UNITS_KEY, JSON.stringify(completedUnits)); } catch (e) {}
  }

  function saveUsers() {
    try {
      registeredUsers = (registeredUsers || []).map(sanitizeUserForStorage);
      localStorage.setItem(USERS_LS_KEY, JSON.stringify(registeredUsers));
    } catch (e) {}
  }

  function saveCurrentUser() {
    try {
      if (currentUser) {
        currentUser = sanitizeUserForStorage(currentUser);
        localStorage.setItem(CURRENT_USER_LS_KEY, JSON.stringify(currentUser));
      } else {
        localStorage.removeItem(CURRENT_USER_LS_KEY);
      }
    } catch (e) {}
    syncHeaderAuthUI();
  }

  function savePinnedSubjects() {
    try { localStorage.setItem(PINNED_SUBS_KEY, JSON.stringify(pinnedSubjects)); } catch (e) {}
  }

  function getTodayKey() {
    var d = new Date();
    return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
  }

  function getDailyStreak() {
    try {
      var raw = JSON.parse(localStorage.getItem(DAILY_STREAK_KEY) || "{}");
      var tk = getTodayKey();
      return { todayPages: (raw && raw.date === tk ? (raw.pages || 0) : 0), totalDays: (raw && raw.days) || 1 };
    } catch (e) { return { todayPages: 0, totalDays: 1 }; }
  }

  function recordPageReadToday() {
    try {
      var tk = getTodayKey();
      var raw = JSON.parse(localStorage.getItem(DAILY_STREAK_KEY) || "{}");
      if (!raw || raw.date !== tk) {
        raw = { date: tk, pages: 1, days: ((raw && raw.days) || 0) + 1 };
      } else {
        raw.pages = (raw.pages || 0) + 1;
      }
      localStorage.setItem(DAILY_STREAK_KEY, JSON.stringify(raw));
    } catch (e) {}
  }

  function saveReaderPrefs() {
    try { localStorage.setItem(READER_PREFS_KEY, JSON.stringify(readerPrefs)); } catch (e) {}
  }

  function getSelection() {
    var stg = masterTree.filter(function (s) { return s.id === state.stageId; })[0] || masterTree[0];
    state.stageId = stg.id;

    var grd = (stg.grades || []).filter(function (g) { return g.id === state.gradeId; })[0] || stg.grades[0];
    state.gradeId = grd.id;

    var brn = (grd.branches || []).filter(function (b) { return b.id === state.branchId; })[0] || grd.branches[0];
    state.branchId = brn.id;

    var sub = (brn.subjects || []).filter(function (m) { return m.id === state.subjectId; })[0] || brn.subjects[0];
    state.subjectId = sub.id;

    if (state.unitIdx >= (sub.units || []).length) state.unitIdx = 0;

    return { stage: stg, grade: grd, branch: brn, subject: sub };
  }

  // ============================================================================
  // المتحكم الموحد بنظافة وتبويب الصفحة (يمنع أي تداخل أو تكدس للأقسام)
  // ============================================================================
  function enforceCleanPageVisibility() {
    var activeExternalIds = {};

    if (state.topNav === "curriculum") {
      if (state.curriculumSubTab === "video_lessons") activeExternalIds["learnSection"] = true;
      else if (state.curriculumSubTab === "ministry_books") activeExternalIds["booksSection"] = true;
    } else if (state.topNav === "tools") {
      if (state.openedToolId && canAccessTool(state.openedToolId)) {
        activeExternalIds[state.openedToolId] = true;
      }
    } else if (state.topNav === "library") {
      if (state.librarySubTab === "edu_resources") activeExternalIds["library"] = true;
      else if (state.librarySubTab === "open_courses") {
        activeExternalIds["coursesSection"] = true;
        activeExternalIds["publicHubStudio"] = true;
      }
    } else if (state.topNav === "mybag") {
      if (state.mybagSubTab === "my_workspace") activeExternalIds["userWorkspaceSection"] = true;
    } else if (state.topNav === "university") {
      if (state.uniSubTab === "cv_studio" && canAccessTool("cvBuilderStudio")) {
        activeExternalIds["cvBuilderStudio"] = true;
      } else if (state.uniSubTab === "research_apa" && canAccessTool("uniResearchCareerStudio")) {
        activeExternalIds["uniResearchCareerStudio"] = true;
      } else if (state.uniSubTab === "about_platform") {
        activeExternalIds["about"] = true;
        activeExternalIds["social"] = true;
      }
    } else if (state.topNav === "admin" && state.isAdminUnlocked) {
      if (state.adminTab === "sources_brain") {
        activeExternalIds["sourcesStudio"] = true;
        activeExternalIds["smartUnifiedCockpit"] = true;
      } else if (state.adminTab === "admin_studios" && state.openedAdminStudioId) {
        activeExternalIds[state.openedAdminStudioId] = true;
      }
    }

    ALL_MANAGED_SECTION_IDS.forEach(function (id) {
      var el = document.getElementById(id);
      if (!el) return;
      if (activeExternalIds[id]) {
        el.classList.add("edu-section-active");
        el.classList.remove("hidden", "edu-hidden-by-hierarchy");
        el.style.display = "";
      } else {
        el.classList.remove("edu-section-active");
        el.style.display = "none";
      }
    });

    // إخفاء الأشرطة المكررة القديمة لضمان وحدة التبويب
    ["eduMainTrackBar", "smartHubSection", "quickStart", "eduRoleOrchestrator", "eduPersonalBanner"].forEach(function (dupId) {
      var dEl = document.getElementById(dupId);
      if (dEl) dEl.style.display = "none";
    });

    // التحكم الذكي بظهور البانر الترحيبي (#hero) ليظهر القسم أو الأداة المختارة في أعلى الشاشة فوراً دون الحاجة للتمرير الطويل
    var heroEl = document.getElementById("hero");
    if (heroEl) {
      var shouldShowHero = !!state.showHeroBanner && state.topNav === "curriculum" && state.curriculumSubTab === "textbook" && !state.openedToolId;
      heroEl.style.display = shouldShowHero ? "" : "none";
    }

    // تحديث حالة الشريط السفلي والقائمة العلوية لتعكس التبويب أو الأداة النشطة
    var activeNavKey = state.topNav;
    if (state.topNav === "curriculum" && state.curriculumSubTab === "video_lessons") activeNavKey = "learnSection";
    else if (state.topNav === "curriculum" && state.curriculumSubTab === "ministry_books") activeNavKey = "booksSection";
    else if (state.topNav === "tools" && state.openedToolId) activeNavKey = state.openedToolId;

    var mobBtns = document.querySelectorAll("#mobileBottomNav [data-mob-tab]");
    Array.prototype.forEach.call(mobBtns, function (btn) {
      var t = btn.getAttribute("data-mob-tab");
      var isAct = (t === state.topNav);
      if (isAct) {
        btn.classList.add("text-brand-600", "dark:text-sky-400", "scale-105");
      } else {
        btn.classList.remove("text-brand-600", "dark:text-sky-400", "scale-105");
      }
    });

    var topDesktopBtns = document.querySelectorAll("#headerDesktopNav [data-top-nav]");
    Array.prototype.forEach.call(topDesktopBtns, function (btn) {
      var t = btn.getAttribute("data-top-nav");
      var isAct = (t === state.topNav);
      if (t === "admin") return;
      if (isAct) {
        btn.classList.add("bg-brand-600", "text-white", "shadow-xs");
        btn.classList.remove("hover:bg-brand-50", "dark:hover:bg-slate-800");
      } else {
        btn.classList.remove("bg-brand-600", "text-white", "shadow-xs");
        btn.classList.add("hover:bg-brand-50", "dark:hover:bg-slate-800");
      }
    });

    var quickPills = document.querySelectorAll("#headerQuickNavStrip [data-top-nav]");
    Array.prototype.forEach.call(quickPills, function (pill) {
      var t = pill.getAttribute("data-top-nav");
      if (t === "admin") return;
      var isAct = (t === activeNavKey) || (t === state.topNav && activeNavKey === state.topNav);
      if (isAct) {
        pill.classList.add("bg-brand-600", "text-white", "border-brand-500", "shadow-2xs");
        pill.classList.remove("bg-white", "dark:bg-slate-800", "text-slate-700", "dark:text-slate-200", "border-slate-200", "dark:border-slate-700");
      } else {
        pill.classList.remove("bg-brand-600", "text-white", "border-brand-500", "shadow-2xs");
        pill.classList.add("bg-white", "dark:bg-slate-800", "border-slate-200", "dark:border-slate-700");
      }
    });
  }

  function searchAllSubjects(qStr) {
    var q = String(qStr || "").trim().toLowerCase();
    if (!q) return [];
    var hits = [];
    masterTree.forEach(function (stg) {
      (stg.grades || []).forEach(function (g) {
        (g.branches || []).forEach(function (b) {
          (b.subjects || []).forEach(function (sub) {
            var hay = (stg.shortName + " " + g.name + " " + b.name + " " + sub.name + " " + (sub.bookTitle || "") + " " + (sub.units || []).join(" ") + " " + (sub.rules || []).join(" ")).toLowerCase();
            if (hay.indexOf(q) !== -1) {
              hits.push({ stg: stg, g: g, b: b, sub: sub });
            }
          });
        });
      });
    });
    return hits.slice(0, 14);
  }

  var _flatCache = null;
  var _lastRenderMs = 0;
  function invalidateFlatCache() { _flatCache = null; }
  function getAllFlattenSubjects() {
    if (_flatCache) return _flatCache;
    var list = [];
    masterTree.forEach(function (stg) {
      (stg.grades || []).forEach(function (g) {
        (g.branches || []).forEach(function (b) {
          (b.subjects || []).forEach(function (sub) {
            list.push({ stg: stg, g: g, b: b, sub: sub });
          });
        });
      });
    });
    _flatCache = list;
    return list;
  }

  function printCurrentLessonSummary(S, G, B, M, pageData) {
    var w = window.open("", "_blank");
    if (!w) {
      toast("يرجى السماح بالنوافذ المنبثقة لطباعة الحقيبة", "warning");
      return;
    }
    var html = '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>' + esc(M.bookTitle || M.name) + ' - صفحة ' + pageData.page + '</title>' +
      '<style>body{font-family:"Cairo",sans-serif;margin:28px;color:#0f172a;line-height:1.8;}h1{color:#0369a1;font-size:20px;margin-bottom:4px;}h2{font-size:15px;color:#334155;margin-top:0;}.box{padding:14px 18px;border:1px solid #cbd5e1;border-radius:12px;background:#f8fafc;margin-top:14px;}@media print{.no-print{display:none;}}</style></head><body>' +
      '<div class="no-print" style="margin-bottom:16px;"><button onclick="window.print()" style="padding:8px 18px;background:#0284c7;color:#fff;border:none;border-radius:8px;font-weight:bold;cursor:pointer;">🖨️ طباعة الحقيبة والصفحة A4</button></div>' +
      '<h1>📖 ' + esc(M.bookTitle || M.name) + ' (صفحة ' + pageData.page + ' من ' + pageData.totalPages + ')</h1>' +
      '<h2>' + esc(S.shortName) + ' • ' + esc(G.name) + ' — ' + esc(pageData.unitTitle) + '</h2>' +
      '<div class="box"><strong>' + esc(pageData.subHeading) + '</strong><p style="white-space:pre-line;">' + esc(pageData.paragraphs.join("\n\n")) + '</p></div>' +
      '<div class="box"><strong>' + esc(pageData.boxTitle) + '</strong><ul>' +
      pageData.boxPoints.map(function (pt) { return '<li>' + esc(pt) + '</li>'; }).join("") +
      '</ul></div>' +
      '<div class="box"><strong>بنك أسئلة المراجعة للوحدة مع الإجابات:</strong><ol>' +
      pageData.unitQuizQuestions.map(function (q) { return '<li><strong>' + esc(q.q) + '</strong><br/>الإجابة: ' + esc(q.opts[q.ans]) + '</li>'; }).join("") +
      '</ol></div></body></html>';
    w.document.open();
    w.document.write(html);
    w.document.close();
  }

  function printAllMarginNotes() {
    var allSubs = getAllFlattenSubjects();
    var subMap = {};
    allSubs.forEach(function (x) { subMap[x.sub.id] = x; });
    var noteKeys = Object.keys(pageNotes).filter(function (k) { return pageNotes[k] && pageNotes[k].trim(); });

    var w = window.open("", "_blank");
    if (!w) {
      toast("يرجى السماح بالنوافذ المنبثقة لطباعة دفتر الهوامش", "warning");
      return;
    }
    var rowsHtml = noteKeys.length ? noteKeys.map(function (k) {
      var pts = k.split(":");
      var sId = pts[0], pg = pts[1] || "1";
      var info = subMap[sId];
      var title = info ? (info.sub.bookTitle || info.sub.name) + " (" + info.g.name + ")" : sId;
      return '<div style="padding:12px 16px;border:1px solid #cbd5e1;border-radius:10px;background:#f8fafc;margin-bottom:10px;">' +
        '<div style="font-weight:900;color:#0369a1;">📘 ' + esc(title) + ' — صفحة ' + esc(pg) + '</div>' +
        '<div style="margin-top:4px;color:#0f172a;">' + esc(pageNotes[k]) + '</div>' +
      '</div>';
    }).join("") : '<p>لا توجد ملاحظات هامشية مسجلة بعد.</p>';

    var html = '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>دفتر هوامشي وملاحظاتي القرائية</title>' +
      '<style>body{font-family:"Cairo",sans-serif;margin:28px;color:#0f172a;line-height:1.8;}@media print{.no-print{display:none;}}</style></head><body>' +
      '<div class="no-print" style="margin-bottom:16px;"><button onclick="window.print()" style="padding:8px 18px;background:#059669;color:#fff;border:none;border-radius:8px;font-weight:bold;cursor:pointer;">🖨️ طباعة دفتر الهوامش A4</button></div>' +
      '<h1 style="font-size:20px;color:#065f46;">📌 دفتر هوامشي وملاحظاتي القرائية عبر الكتب والمواد</h1>' +
      rowsHtml + '</body></html>';
    w.document.open();
    w.document.write(html);
    w.document.close();
  }


  function triggerStudioRefreshAndResize(sectionId) {
    setTimeout(function () {
      try { window.dispatchEvent(new Event("resize")); } catch (e) {}
      try {
        var cleanId = String(sectionId || "").replace(/^#/, "");
        if (cleanId === "teacherDash" && window.EduDash && typeof window.EduDash.reload === "function") {
          window.EduDash.reload();
        } else if (cleanId === "analyticsStudio" && window.EduAnalytics && typeof window.EduAnalytics.refresh === "function") {
          window.EduAnalytics.refresh();
        } else if (cleanId === "parentsStudio" && window.EduParents && typeof window.EduParents.reload === "function") {
          window.EduParents.reload();
        } else if (cleanId === "classroomsStudio" && window.EduClassrooms && typeof window.EduClassrooms.reload === "function") {
          window.EduClassrooms.reload();
        } else if (cleanId === "homeworkStudio" && window.EduHomework && typeof window.EduHomework.reload === "function") {
          window.EduHomework.reload();
        }
      } catch (e2) {}
    }, 60);
  }

  function openToolOrPrompt(toolId) {
    var tMeta = TOOL_MAP[toolId];
    if (!canAccessTool(toolId)) {
      showBlockedToolModal(toolId);
      return false;
    }
    if (tMeta && tMeta.call) {
      var parts = tMeta.call.split(".");
      var obj = window[parts[0]];
      if (obj && typeof obj[parts[1]] === "function") {
        obj[parts[1]]();
        return true;
      }
    }
    state.topNav = "tools";
    state.openedToolId = toolId;
    state.collapseToolsCatalog = true;
    pushNavHistory();
    renderMainOrganizer();
    if (toolId === "generator") {
      var gEl = document.getElementById("generator");
      if (gEl && gEl.firstElementChild) {
        gEl.firstElementChild.style.maxHeight = "";
        gEl.firstElementChild.style.overflow = "";
      }
      var gt = document.getElementById("genToggle");
      if (gt) gt.style.display = "none";
    }
    focusAndScrollTo(toolId, tMeta ? ("🛠️ تم فتح أداة «" + tMeta.title + "» ✓") : "🛠️ تم فتح الأداة بنجاح ✓");
    return true;
  }

  function renderMainOrganizer() {
    var _t0 = (window.performance && performance.now) ? performance.now() : Date.now();
    var root = document.getElementById("eduOrganizedPlatformRoot");
    if (!root) return;

    enforceCleanPageVisibility();

    var sel = getSelection();
    var S = sel.stage, G = sel.grade, B = sel.branch, M = sel.subject;
    var bm = bookmarks[M.id] || { page: 1, note: "" };
    var pageData = buildRichCurriculumPage(S, G, B, M, bm.page);
    state.unitIdx = pageData.unitIdx;
    var searchResults = searchAllSubjects(state.quickSearch);
    var curPageNoteKey = M.id + ":" + pageData.page;
    var curPageNoteVal = pageNotes[curPageNoteKey] || "";

    var unitStart = pageData.unitStartPage;
    var quickPages = [
      { p: unitStart, lbl: "ص " + unitStart + ": التمهيد والشرح" },
      { p: unitStart + 1, lbl: "ص " + (unitStart + 1) + ": تفصيل المفاهيم" },
      { p: unitStart + 2, lbl: "ص " + (unitStart + 2) + ": الأمثلة والنشاط" },
      { p: unitStart + 3, lbl: "ص " + (unitStart + 3) + ": التطبيقات والمقارنات" },
      { p: unitStart + 4, lbl: "ص " + (unitStart + 4) + ": الأسئلة والحلول" }
    ];

    var paperClasses = readerPrefs.paperTheme === "night"
      ? "bg-slate-950 text-slate-100 border-slate-700"
      : (readerPrefs.paperTheme === "white"
        ? "bg-white text-slate-900 border-slate-300"
        : "bg-[#fcfaf2] text-slate-900 border-amber-900/25");

    var quizCorrectCount = 0;
    pageData.unitQuizQuestions.forEach(function (q, qI) {
      if (state.quizAnswers[qI] === q.ans) quizCorrectCount++;
    });

    var allFlatSubs = getAllFlattenSubjects();
    var savedNotesCount = Object.keys(pageNotes).filter(function (k) { return pageNotes[k] && pageNotes[k].trim(); }).length;
    var driveFid = extractDriveFileId(M.driveUrl || M.driveFileId || "");

    var activeViewerUser = state.impersonatingUserEmail
      ? (registeredUsers.filter(function (u) { return u.email === state.impersonatingUserEmail; })[0] || null)
      : currentUser;

    var allowedToolsCount = MASTER_TOOLS_CATALOG.filter(function (t) {
      return evaluateToolAccessForUser(t.id, activeViewerUser, false).allowed;
    }).length;
    var pendingReqCount = (adminPerms.accessRequests || []).filter(function (r) { return r.status === "pending"; }).length;

    root.innerHTML =
      '<div class="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 my-4 text-right" dir="rtl">' +
        '<div class="rounded-3xl bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">' +

          // شريط معاينة صلاحيات عضو (يظهر عند تفعيل المعاينة من الإدارة)
          (state.impersonatingUserEmail ? (
            '<div class="px-4 py-2.5 bg-gradient-to-l from-amber-500 to-orange-600 text-slate-950 text-xs font-black flex flex-wrap items-center justify-between gap-2">' +
              '<span>👁️ وضع معاينة الصلاحيات نشط: أنت تتصفح الموقع الآن تماماً كما يراه العضو «' + esc(activeViewerUser ? activeViewerUser.name : state.impersonatingUserEmail) + '» (' + allowedToolsCount + ' أداة مسموحة من ' + MASTER_TOOLS_CATALOG.length + ')</span>' +
              '<button type="button" id="btnOrgExitImpersonation" class="px-3 py-1 rounded-xl bg-slate-950 text-amber-300 font-black shadow">👑 إنهاء المعاينة والعودة للوحة الإدارة</button>' +
            '</div>'
          ) : '') +

          // الهيدر الرئيسي وشريط التبويب الشامل للمنصة (7 تبويبات رئيسية منظمة)
          '<div class="p-4 sm:p-5 bg-gradient-to-l from-slate-950 via-slate-900 to-indigo-950 text-white border-b border-slate-800 space-y-4">' +
            '<div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3">' +
              '<div class="flex items-center gap-3">' +
                '<div class="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-500 to-sky-600 flex items-center justify-center text-2xl shadow-lg shrink-0">🇵🇸</div>' +
                '<div>' +
                  '<div class="flex flex-wrap items-center gap-2">' +
                    '<h2 class="text-base sm:text-xl font-black text-white">منصة EduTech Mindset — البوابة المبوّبة الشاملة</h2>' +
                    '<span id="eduNetStatusBadge" class="px-2 py-0.5 rounded-full text-[10px] font-black ' + (navigator.onLine ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300') + '">' + (navigator.onLine ? '🟢 متصل' : '🟠 وضع الأوفلاين النشط') + '</span>' +
                  '</div>' +
                  '<p class="text-xs text-slate-300 mt-0.5">المنهاج الفلسطيني الكامل • ' + MASTER_TOOLS_CATALOG.length + ' أداة ومختبراً ذكياً • نظام صلاحيات وتخصيص شامل للأعضاء</p>' +
                '</div>' +
              '</div>' +

              // شريط حالة المستخدم السريع + أزرار التحكم العليا
              '<div class="flex flex-wrap items-center gap-2">' +
                '<button type="button" id="btnOrgGoBack" class="px-3 py-2 rounded-xl text-xs font-black bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/40 transition flex items-center gap-1" title="الرجوع للخلف خطوة واحدة"><span>⬅</span><span>رجوع</span></button>' +
                '<button type="button" id="btnOrgToggleTheme" class="px-2.5 py-2 rounded-xl text-xs font-black bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 transition" title="تبديل المظهر الليلي / النهاري">🌓</button>' +
                (activeViewerUser ? (
                  '<button type="button" data-org-topnav="account" class="px-3 py-2 rounded-xl text-xs font-black bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5">' +
                    '<span>🟢</span><span>' + esc(activeViewerUser.name) + ' (' + esc(activeViewerUser.roleLabel || "عضو") + ')</span>' +
                    '<span class="px-1.5 py-0.2 rounded bg-emerald-500 text-slate-950 text-[10px]">' + allowedToolsCount + ' أداة</span>' +
                  '</button>'
                ) : (
                  '<button type="button" data-org-topnav="account" class="px-3 py-2 rounded-xl text-xs font-black bg-sky-500/20 hover:bg-sky-500/30 text-sky-200 border border-sky-400/40 flex items-center gap-1.5">' +
                    '<span>🔑</span><span>دخول / تسجيل عضوية</span>' +
                  '</button>'
                )) +
              '</div>' +
            '</div>' +

            // شريط تنسيق الخطوط الفوري والتعاون الذكي
            '<div class="flex flex-wrap items-center justify-between gap-2 px-3 py-2 rounded-2xl bg-slate-900/90 border border-slate-800 text-[11px]">' +
              '<div class="flex flex-wrap items-center gap-1.5">' +
                '<span class="font-black text-amber-300">🔤 تنسيق الخط والقراءة:</span>' +
                [
                  { id: "cairo", lbl: "القاهرة (Cairo)" },
                  { id: "tajawal", lbl: "تجوال (Tajawal)" },
                  { id: "alexandria", lbl: "الإسكندرية" },
                  { id: "almarai", lbl: "المراعي" }
                ].map(function (f) {
                  var on = (readerPrefs.siteFont || "cairo") === f.id;
                  return '<button type="button" data-org-sitefont="' + f.id + '" class="px-2.5 py-1 rounded-lg font-black transition ' + (on ? "bg-amber-400 text-slate-950 shadow" : "bg-slate-800 text-slate-300 hover:bg-slate-700") + '">' + f.lbl + '</button>';
                }).join("") +
                '<span class="text-slate-600 mx-0.5">|</span>' +
                '<button type="button" id="btnOrgSiteScaleMinus" class="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 font-black" title="تصغير خط الموقع">A-</button>' +
                '<span class="px-2 py-0.5 rounded bg-slate-950 text-emerald-300 font-mono font-black">' + (readerPrefs.siteScale || 100) + '%</span>' +
                '<button type="button" id="btnOrgSiteScalePlus" class="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 font-black" title="تكبير خط الموقع">A+</button>' +
              '</div>' +
              '<div class="flex flex-wrap items-center gap-1.5">' +
                '<button type="button" id="btnOrgOpenCollabQuick" class="px-3 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500 text-emerald-300 hover:text-slate-950 border border-emerald-500/40 font-black transition flex items-center gap-1"><span>🤝</span><span>حلقات التعاون الذكي (' + collabRooms.length + ')</span></button>' +
              '</div>' +
            '</div>' +

            // شريط التبويبات الرئيسية الموحّدة (6 للجمهور + التبويب 7 يظهر حصرياً للإدارة العليا فقط)
            '<div class="grid grid-cols-2 sm:grid-cols-3 ' + (isEffectiveSuperAdmin() ? 'lg:grid-cols-7' : 'lg:grid-cols-6') + ' gap-2 pt-1">' +
              '<button type="button" data-org-topnav="curriculum" class="px-3 py-2.5 rounded-2xl text-xs font-black transition flex items-center justify-center gap-1.5 ' +
                (state.topNav === "curriculum" ? "bg-sky-500 text-slate-950 shadow-lg ring-2 ring-sky-300 scale-[1.01]" : "bg-slate-800/90 text-slate-200 hover:bg-slate-700") + '">' +
                '<span>🏫</span><span>1. المراحل والمنهاج</span>' +
              '</button>' +

              '<button type="button" data-org-topnav="tools" class="px-3 py-2.5 rounded-2xl text-xs font-black transition flex items-center justify-center gap-1.5 ' +
                (state.topNav === "tools" ? "bg-amber-400 text-slate-950 shadow-lg ring-2 ring-amber-200 scale-[1.01]" : "bg-slate-800/90 text-amber-200 hover:bg-slate-700") + '">' +
                '<span>🛠️</span><span>2. الأدوات (' + allowedToolsCount + '/' + MASTER_TOOLS_CATALOG.length + ')</span>' +
              '</button>' +

              ((adminPerms.publicLibrary || isEffectiveSuperAdmin()) ? (
                '<button type="button" data-org-topnav="library" class="px-3 py-2.5 rounded-2xl text-xs font-black transition flex items-center justify-center gap-1.5 ' +
                  (state.topNav === "library" ? "bg-emerald-500 text-slate-950 shadow-lg ring-2 ring-emerald-300 scale-[1.01]" : "bg-slate-800/90 text-slate-200 hover:bg-slate-700") + '">' +
                  '<span>📖</span><span>3. المكتبة الشاملة</span>' +
                '</button>'
              ) : '') +

              '<button type="button" data-org-topnav="mybag" class="px-3 py-2.5 rounded-2xl text-xs font-black transition flex items-center justify-center gap-1.5 ' +
                (state.topNav === "mybag" ? "bg-purple-500 text-white shadow-lg ring-2 ring-purple-300 scale-[1.01]" : "bg-slate-800/90 text-slate-200 hover:bg-slate-700") + '">' +
                '<span>📌</span><span>4. حقيبتي والتعاون (' + savedNotesCount + ')</span>' +
              '</button>' +

              ((adminPerms.publicUniversity || isEffectiveSuperAdmin()) ? (
                '<button type="button" data-org-topnav="university" class="px-3 py-2.5 rounded-2xl text-xs font-black transition flex items-center justify-center gap-1.5 ' +
                  (state.topNav === "university" ? "bg-cyan-400 text-slate-950 shadow-lg ring-2 ring-cyan-200 scale-[1.01]" : "bg-slate-800/90 text-slate-200 hover:bg-slate-700") + '">' +
                  '<span>🎓</span><span>5. الجامعة والـ CV</span>' +
                '</button>'
              ) : '') +

              '<button type="button" data-org-topnav="account" class="px-3 py-2.5 rounded-2xl text-xs font-black transition flex items-center justify-center gap-1.5 ' +
                (state.topNav === "account" ? "bg-indigo-500 text-white shadow-lg ring-2 ring-indigo-300 scale-[1.01]" : "bg-slate-800/90 text-sky-200 hover:bg-slate-700") + '">' +
                '<span>👤</span><span>6. ' + (activeViewerUser ? "حسابي والخصوصية" : "التسجيل والدخول") + '</span>' +
              '</button>' +

              (isEffectiveSuperAdmin() ? (
                '<button type="button" data-org-topnav="admin" class="admin-only-ui px-3 py-2.5 rounded-2xl text-xs font-black transition flex items-center justify-center gap-1.5 relative ' +
                  (state.topNav === "admin" ? "bg-rose-600 text-white shadow-lg ring-2 ring-rose-300 scale-[1.01]" : "bg-rose-950/90 text-rose-200 hover:text-white border border-rose-500/50") + '">' +
                  '<span>👑</span><span>7. القيادة والصلاحيات</span>' +
                  (pendingReqCount > 0 ? '<span class="px-1.5 py-0.2 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black">' + pendingReqCount + '</span>' : '') +
                '</button>'
              ) : '') +
            '</div>' +
          '</div>' +

          ((adminPerms.announcementActive && adminPerms.announcementText) ? (
            '<div class="px-4 py-2 bg-amber-500/15 border-b border-amber-500/30 text-amber-800 dark:text-amber-200 text-xs font-black flex items-center justify-between gap-2">' +
              '<span>📢 ' + esc(adminPerms.announcementText) + '</span>' +
            '</div>'
          ) : "") +
          ((adminPerms.maintenanceMode && !isEffectiveSuperAdmin()) ? (
            '<div class="p-8 text-center bg-rose-950/90 text-white border-b-2 border-rose-500 space-y-3">' +
              '<div class="text-4xl">🛡️</div>' +
              '<h3 class="text-base sm:text-lg font-black text-amber-300">الموقع في وضع التحديث والصيانة السيادية المؤقتة</h3>' +
              '<p class="text-xs text-slate-200 max-w-xl mx-auto leading-relaxed">' + esc(adminPerms.maintenanceMsg || "الموقع يخضع حالياً لتحديثات إدارية وتربوية بإشراف الإدارة العليا — سيعود للعمل قريباً.") + '</p>' +
            '</div>'
          ) : "") +

          // =========================================================================
          // التبويب 1: المراحل والمنهاج والكتاب التفاعلي صفحة بصفحة
          // =========================================================================
          (state.topNav === "curriculum" ? (
            '<div class="p-4 sm:p-6 space-y-5">' +

              // التبويبات الفرعية للمنهاج
              '<div class="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">' +
                '<div class="flex flex-wrap gap-2">' +
                  '<button type="button" data-org-currsub="textbook" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.curriculumSubTab === "textbook" ? "bg-sky-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">📖 1. شجرة المراحل وقارئ الكتاب التفاعلي (6×1)</button>' +
                  '<button type="button" data-org-currsub="video_lessons" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.curriculumSubTab === "video_lessons" ? "bg-emerald-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">🎬 2. الفيديوهات والدروس المصوّرة للصفوف</button>' +
                  '<button type="button" data-org-currsub="ministry_books" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.curriculumSubTab === "ministry_books" ? "bg-indigo-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">📘 3. فهرس الكتب المدرسية الإضافي</button>' +
                '</div>' +
                '<button type="button" data-org-topnav="tools" class="px-3.5 py-2 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-800 dark:text-amber-300 text-xs font-black hover:bg-amber-500 hover:text-slate-950 transition">🛠️ فتح أدوات ومختبرات المادة ⬅</button>' +
              '</div>' +

              (state.curriculumSubTab !== "textbook" ? (
                '<div class="p-4 rounded-2xl bg-sky-500/10 border border-sky-500/30 flex flex-wrap items-center justify-between gap-2 text-xs">' +
                  '<span class="font-black text-sky-700 dark:text-sky-300">' + (state.curriculumSubTab === "video_lessons" ? "🎬 قسم الفيديوهات والدروس المصوّرة للصفوف مفتوح بالأسفل مباشرة ⬇" : "📘 قسم فهرس الكتب المدرسية الوزارية مفتوح بالأسفل مباشرة ⬇") + '</span>' +
                  '<button type="button" data-org-currsub="textbook" class="px-3.5 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-black shadow">📖 العودة لشجرة المراحل وقارئ الكتاب التفاعلي</button>' +
                '</div>'
              ) : (

              // شريط المسار التفاعلي (Breadcrumb) + البحث السريع
              '<div class="sticky top-2 z-30 p-3.5 rounded-2xl bg-slate-100/95 dark:bg-slate-900/95 backdrop-blur-md border border-sky-500/30 shadow-lg flex flex-col lg:flex-row lg:items-center justify-between gap-3">' +
                '<div class="flex flex-wrap items-center gap-1.5 text-xs">' +
                  '<button type="button" data-org-inlineback="1" class="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black shadow-xs">⬅ رجوع</button><span class="font-black text-slate-500">🧭 المسار:</span>' +
                  '<button type="button" data-org-scrollto="orgStepStagesBox" class="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-black text-sky-600 dark:text-sky-400">' + esc(S.ico + " " + S.shortName) + '</button>' +
                  '<span class="text-slate-400">⬅</span>' +
                  '<button type="button" data-org-scrollto="orgStepGradesBox" class="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-black text-indigo-600 dark:text-indigo-400">🏫 ' + esc(G.name) + '</button>' +
                  '<span class="text-slate-400">⬅</span>' +
                  '<button type="button" data-org-scrollto="orgStepSubjectsBox" class="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-black text-emerald-600 dark:text-emerald-400">' + esc((M.ico || "📘") + " " + M.name) + '</button>' +
                  '<span class="text-slate-400">⬅</span>' +
                  '<button type="button" data-org-scrollto="orgBookPagePaper" class="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 font-black shadow-xs">📖 صفحة ' + pageData.page + ' مفتوحة الآن ⬇</button>' +
                  '<button type="button" id="btnOrgToggleCollapse" class="px-2.5 py-1 rounded-lg bg-indigo-600 text-white font-black shadow-xs">' + (state.collapseSelectors ? "📂 إظهار القوائم" : "🎯 طيّ القوائم للتركيز") + '</button>' +
                '</div>' +
                '<div class="relative min-w-[240px]">' +
                  '<input id="inpOrgQuickSearch" type="search" value="' + esc(state.quickSearch) + '" placeholder="🔍 ابحث بسرعة عن أي صف أو مادة أو درس..." class="w-full px-3.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-bold outline-none focus:border-sky-500"/>' +
                '</div>' +
              '</div>' +

              '<div id="orgSearchResultsBox">' +
              (searchResults.length ? (
                '<div class="p-3.5 rounded-2xl bg-sky-500/10 border border-sky-500/30 space-y-2">' +
                  '<div class="text-xs font-black text-sky-700 dark:text-sky-300">⚡ نتائج البحث الفوري — اضغط لفتح الكتاب مباشرة:</div>' +
                  '<div class="flex flex-wrap gap-2">' +
                    searchResults.map(function (r) {
                      return '<button type="button" data-org-jumpbook="' + esc(r.stg.id + "|" + r.g.id + "|" + r.b.id + "|" + r.sub.id) + '" class="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-sky-500/40 hover:bg-sky-500 hover:text-slate-950 text-xs font-black transition">' +
                        esc(r.sub.ico + " " + r.sub.name + " — " + r.g.name) +
                      '</button>';
                    }).join("") +
                  '</div>' +
                '</div>'
              ) : "") +
              '</div>' +

              (Object.keys(pinnedSubjects).filter(function (k) { return !!pinnedSubjects[k]; }).length ? (
                '<div class="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex flex-wrap items-center gap-2 text-xs">' +
                  '<span class="font-black text-amber-800 dark:text-amber-300">⭐ موادي المثبتة:</span>' +
                  allFlatSubs.filter(function (x) { return !!pinnedSubjects[x.sub.id]; }).map(function (x) {
                    return '<button type="button" data-org-jumpbook="' + esc(x.stg.id + "|" + x.g.id + "|" + x.b.id + "|" + x.sub.id) + '" class="px-3 py-1 rounded-xl bg-white dark:bg-slate-900 border border-amber-500/40 hover:bg-amber-500 hover:text-slate-950 font-black transition">' + esc(x.sub.ico + " " + x.sub.name + " (" + x.g.name + ")") + '</button>';
                  }).join("") +
                '</div>'
              ) : '') +

              (!state.collapseSelectors ? (
              // شريط الوصول السريع للصفوف (1 - 12) بنقرة واحدة
              '<div class="p-3 rounded-2xl bg-gradient-to-l from-sky-500/10 via-indigo-500/5 to-emerald-500/10 border border-sky-500/25 space-y-2">' +
                '<div class="flex flex-wrap items-center justify-between gap-2 text-xs">' +
                  '<span class="font-black text-sky-700 dark:text-sky-300">⚡ وصول فوري للصف الدراسي (1 – 12):</span>' +
                  '<span class="text-[11px] text-slate-500">اضغط رقم الصف للانتقال مباشرة إلى كتبه</span>' +
                '</div>' +
                '<div class="flex flex-wrap gap-1.5">' +
                  [
                    { num: "1", gid: "g1", stg: "stage-primary", label: "الأول" },
                    { num: "2", gid: "g2", stg: "stage-primary", label: "الثاني" },
                    { num: "3", gid: "g3", stg: "stage-primary", label: "الثالث" },
                    { num: "4", gid: "g4", stg: "stage-primary", label: "الرابع" },
                    { num: "5", gid: "g5", stg: "stage-middle", label: "الخامس" },
                    { num: "6", gid: "g6", stg: "stage-middle", label: "السادس" },
                    { num: "7", gid: "g7", stg: "stage-middle", label: "السابع" },
                    { num: "8", gid: "g8", stg: "stage-middle", label: "الثامن" },
                    { num: "9", gid: "g9", stg: "stage-middle", label: "التاسع" },
                    { num: "10", gid: "g10", stg: "stage-secondary", label: "العاشر" },
                    { num: "11", gid: "g11", stg: "stage-secondary", label: "11 ثانوي" },
                    { num: "12", gid: "g12", stg: "stage-secondary", label: "توجيهي" }
                  ].map(function (qg) {
                    var isCur = G.id === qg.gid;
                    return '<button type="button" data-org-quickgrade="' + qg.stg + '|' + qg.gid + '" class="px-2.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1 ' +
                      (isCur ? "bg-sky-600 text-white shadow" : "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-sky-400") + '">' +
                      '<span class="w-5 h-5 rounded-lg ' + (isCur ? "bg-black/25 text-amber-200" : "bg-sky-500/15 text-sky-600 dark:text-sky-300") + ' flex items-center justify-center text-[10px]">' + qg.num + '</span>' +
                      '<span>' + qg.label + '</span>' +
                    '</button>';
                  }).join("") +
                '</div>' +
              '</div>' +

              // الخطوة 1: المراحل التعليمية
              '<div id="orgStepStagesBox" class="p-4 rounded-2xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-2.5 scroll-mt-24">' +
                '<span class="text-xs font-black text-slate-600 dark:text-slate-300">1️⃣ اختر المرحلة التعليمية:</span>' +
                '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">' +
                  masterTree.map(function (stg) {
                    var on = stg.id === S.id;
                    return '<button type="button" data-org-stage="' + esc(stg.id) + '" class="p-3.5 rounded-2xl border-2 text-right transition-all flex items-start gap-2.5 ' +
                      (on ? "bg-gradient-to-l " + stg.color + " text-white border-transparent shadow-lg scale-[1.01]" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:border-sky-400") + '">' +
                      '<span class="text-2xl shrink-0">' + stg.ico + '</span>' +
                      '<div class="min-w-0">' +
                        '<div class="text-xs font-black truncate">' + esc(stg.shortName) + '</div>' +
                        '<div class="text-[10px] ' + (on ? "text-white/90" : "text-slate-500 dark:text-slate-400") + ' mt-0.5">' + (on ? "✓ المرحلة المختارة" : "اضغط لفتح الصفوف ⬅") + '</div>' +
                      '</div>' +
                    '</button>';
                  }).join("") +
                '</div>' +
              '</div>' +

              // الخطوة 2: الصفوف الدراسية
              '<div id="orgStepGradesBox" class="p-4 rounded-2xl bg-sky-500/5 dark:bg-slate-800/60 border-2 border-sky-500/30 space-y-3 scroll-mt-24">' +
                '<div class="flex flex-wrap items-center justify-between gap-2">' +
                  '<div class="flex flex-wrap items-center gap-2">' +
                    '<span class="px-2.5 py-0.5 rounded-full bg-sky-500 text-slate-950 text-[11px] font-black">2️⃣ صفوف المرحلة</span>' +
                    '<span class="text-xs sm:text-sm font-black text-slate-800 dark:text-white">اختر الصف الدراسي في «' + esc(S.name) + '»:</span>' +
                    '<button type="button" id="btnOrgSaveGradeOffline" class="px-2.5 py-1 rounded-lg bg-sky-600/20 border border-sky-500/40 text-sky-700 dark:text-sky-300 text-[11px] font-black hover:bg-sky-600 hover:text-white transition">💾 حفظ الصف أوفلاين</button>' +
                    '<button type="button" id="org-pomodoro-btn" class="px-3 py-1 rounded-xl bg-emerald-500/15 border border-emerald-500/35 text-emerald-700 dark:text-emerald-300 text-[11px] font-black hover:bg-emerald-600 hover:text-white transition">⏱️ مؤقت التركيز (<span id="org-pomo-disp">25:00</span>)</button>' +
                    '<button type="button" id="org-planner-btn" class="px-3 py-1 rounded-xl bg-indigo-500/15 border border-indigo-500/35 text-indigo-700 dark:text-indigo-300 text-[11px] font-black hover:bg-indigo-600 hover:text-white transition">📅 جدول المذاكرة</button>' +
                    '<button type="button" id="org-speak-btn" class="px-3 py-1 rounded-xl bg-cyan-500/15 border border-cyan-500/35 text-cyan-700 dark:text-cyan-300 text-[11px] font-black hover:bg-cyan-600 hover:text-white transition">🔊 استمع للوحدة</button>' +
                    ((G.id === "g1" || G.id === "g2" || G.id === "g3" || G.id === "g4") ? '<button type="button" id="org-foundation-btn" class="px-3 py-1 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-800 dark:text-amber-300 text-[11px] font-black hover:bg-amber-500 hover:text-slate-950 transition">🎯 تأسيس الحروف والأرقام</button>' : "") +
                    '<button type="button" id="org-recall-btn" class="px-3 py-1 rounded-xl bg-purple-500/15 border border-purple-500/35 text-purple-700 dark:text-purple-300 text-[11px] font-black hover:bg-purple-600 hover:text-white transition">🧠 تسميع القوانين</button>' +
                    '<button type="button" id="org-progress-btn" class="px-3 py-1 rounded-xl bg-teal-500/15 border border-teal-500/35 text-teal-700 dark:text-teal-300 text-[11px] font-black hover:bg-teal-600 hover:text-white transition">📊 إنجازي</button>' +
                    (G.id === "g12" ? '<button type="button" id="org-tawjihi-gpa-btn" class="px-3 py-1 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-800 dark:text-amber-300 text-[11px] font-black hover:bg-amber-500 hover:text-slate-950 transition">🎓 حاسبة معدل التوجيهي</button>' : "") +
                  '</div>' +
                  ((G.branches && G.branches.length > 1)
                    ? '<div class="flex flex-wrap items-center gap-1.5">' +
                        '<span class="text-xs font-black text-amber-600 dark:text-amber-400">الفرع:</span>' +
                        G.branches.map(function (br) {
                          var bOn = br.id === B.id;
                          return '<button type="button" data-org-branch="' + esc(br.id) + '" class="px-3 py-1.5 rounded-xl text-xs font-black transition ' +
                            (bOn ? "bg-amber-500 text-slate-950 shadow-md" : "bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 hover:border-amber-400") + '">' +
                            esc(br.name) +
                          '</button>';
                        }).join("") +
                      '</div>'
                    : '') +
                '</div>' +
                '<div class="flex flex-wrap gap-2">' +
                  (S.grades || []).map(function (grd) {
                    var gOn = grd.id === G.id;
                    return '<button type="button" data-org-grade="' + esc(grd.id) + '" class="px-4 py-2.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 ' +
                      (gOn ? "bg-sky-600 text-white shadow-lg ring-2 ring-sky-400/60 scale-[1.02]" : "bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:border-sky-400") + '">' +
                      '<span>🏫</span><span>' + esc(grd.name) + '</span>' +
                      (gOn ? '<span class="text-[10px] bg-white/20 px-1.5 py-0.5 rounded-md">مفتوح ✓</span>' : '') +
                    '</button>';
                  }).join("") +
                '</div>' +
              '</div>' +

              // الخطوة 3: المواد الدراسية
              '<div id="orgStepSubjectsBox" class="p-4 rounded-2xl bg-emerald-500/5 dark:bg-slate-800/60 border-2 border-emerald-500/30 space-y-3 scroll-mt-24">' +
                '<div class="flex items-center gap-2">' +
                  '<span class="px-2.5 py-0.5 rounded-full bg-emerald-500 text-slate-950 text-[11px] font-black">3️⃣ مواد الصف</span>' +
                  '<span class="text-xs sm:text-sm font-black text-slate-800 dark:text-white">اختر المادة في «' + esc(G.name) + (G.branches && G.branches.length > 1 ? " — " + esc(B.name) : "") + '» لقراءة كتابها وتصفح صفحاته:</span>' +
                '</div>' +
                '<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5">' +
                  (B.subjects || []).map(function (sub) {
                    var sOn = sub.id === M.id;
                    var subBm = bookmarks[sub.id];
                    return '<button type="button" data-org-subject="' + esc(sub.id) + '" class="p-3.5 rounded-2xl border-2 text-right transition-all flex flex-col justify-between gap-2 ' +
                      (sOn ? "bg-slate-900 text-white border-emerald-400 shadow-xl scale-[1.01]" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:border-emerald-400") + '">' +
                      '<div class="flex items-start justify-between gap-2">' +
                        '<div class="flex items-center gap-2">' +
                          '<span class="text-xl">' + (sub.ico || "📘") + '</span>' +
                          '<span class="text-xs font-black">' + esc(sub.name) + '</span>' +
                        '</div>' +
                        (sOn ? '<span class="px-2 py-0.5 rounded-full bg-emerald-400 text-slate-950 text-[10px] font-black shrink-0">مفتوح ⬇</span>' : '') +
                      '</div>' +
                      '<div class="flex items-center justify-between text-[10px] pt-1.5 border-t ' + (sOn ? "border-white/10 text-emerald-300" : "border-slate-100 dark:border-slate-800 text-slate-500") + '">' +
                        '<span>📖 اقرأ الكتاب (' + (sub.totalPages || 140) + ' صفحة)</span>' +
                        (subBm ? '<span class="text-amber-500 font-black">📌 ص ' + subBm.page + '</span>' : '<span>' + (sub.units || []).length + ' وحدات</span>') +
                      '</div>' +
                    '</button>';
                  }).join("") +
                '</div>' +
              '</div>'
              ) : '') +

              // الخطوة 4: قارئ الكتاب المدرسي الفعلي وبيئة الدراسة المتكاملة (6 أنماط دراسة في مكان واحد)
              '<div id="orgStepSubjectWorkspace" class="rounded-3xl border-2 border-amber-500/50 bg-gradient-to-b from-amber-500/5 to-slate-50 dark:from-slate-900 dark:to-slate-950 p-4 sm:p-6 space-y-5 shadow-xl scroll-mt-20">' +
                '<div class="p-3.5 rounded-2xl bg-gradient-to-l from-emerald-600 to-teal-700 text-white space-y-2 shadow">' +
                  '<div class="flex flex-wrap items-center justify-between gap-2">' +
                    '<div class="flex items-center gap-2 text-xs sm:text-sm font-black">' +
                      '<span>📖 الكتاب المفتوح:</span>' +
                      '<span class="underline decoration-amber-300 decoration-2">' + esc(M.bookTitle || M.name) + '</span>' +
                    '</div>' +
                    '<div class="flex flex-wrap items-center gap-2">' +
                      '<button type="button" id="btnOrgTogglePinSub" class="px-2.5 py-1 rounded-xl text-[11px] font-black transition ' + (pinnedSubjects[M.id] ? 'bg-amber-400 text-slate-950' : 'bg-black/25 text-white hover:bg-black/40') + '">' + (pinnedSubjects[M.id] ? '⭐ مثبتة' : '☆ تثبيت') + '</button>' +
                      '<button type="button" id="btnOrgToggleUnitDone" class="px-2.5 py-1 rounded-xl text-[11px] font-black transition ' + (completedUnits[M.id + ":" + pageData.unitIdx] ? "bg-amber-400 text-slate-950" : "bg-black/25 text-white hover:bg-black/40") + '">' + (completedUnits[M.id + ":" + pageData.unitIdx] ? "✅ وحدة مُتقَنة" : "☑️ إتمام الوحدة") + '</button>' +
                      '<span class="px-3 py-1 rounded-xl bg-black/25 text-amber-200 text-xs font-black">📌 صفحة ' + pageData.page + ' من ' + pageData.totalPages + ' (' + Math.round((pageData.page / pageData.totalPages) * 100) + '%)</span>' +
                    '</div>' +
                  '</div>' +
                  '<div class="w-full h-1.5 rounded-full bg-black/25 overflow-hidden"><div class="h-full bg-amber-300 transition-all duration-300" style="width:' + Math.min(100, Math.round((pageData.page / pageData.totalPages) * 100)) + '%"></div></div>' +
                '</div>' +

                // شريط أنماط الدراسة المتكاملة (مضبوط بصلاحيات الإدارة)
                '<div class="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">' +
                  '<div class="flex flex-wrap gap-1.5">' +
                    '<button type="button" data-org-studymode="book" class="px-3 py-2 rounded-xl text-xs font-black transition ' + (state.activeStudyMode === "book" ? "bg-sky-600 text-white shadow-md" : "bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700") + '">📖 1. قراءة صفحات الكتاب</button>' +
                    ((adminPerms.publicOrigPdf || state.isAdminUnlocked) ? '<button type="button" data-org-studymode="origpdf" class="px-3 py-2 rounded-xl text-xs font-black transition ' + (state.activeStudyMode === "origpdf" ? "bg-rose-600 text-white shadow-md" : "bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700") + '">📕 2. النسخة المصوّرة (PDF / Drive)</button>' : '') +
                    '<button type="button" data-org-studymode="cornell" class="px-3 py-2 rounded-xl text-xs font-black transition ' + (state.activeStudyMode === "cornell" ? "bg-amber-500 text-slate-950 shadow-md" : "bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700") + '">📓 3. ملخص كورنيل والتسميع</button>' +
                    ((adminPerms.publicFlashcards || state.isAdminUnlocked) ? '<button type="button" data-org-studymode="flashcards" class="px-3 py-2 rounded-xl text-xs font-black transition ' + (state.activeStudyMode === "flashcards" ? "bg-purple-600 text-white shadow-md" : "bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700") + '">🃏 4. البطاقات القلّابة</button>' : '') +
                    '<button type="button" data-org-studymode="conceptmap" class="px-3 py-2 rounded-xl text-xs font-black transition ' + (state.activeStudyMode === "conceptmap" ? "bg-cyan-600 text-white shadow-md" : "bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700") + '">🗺️ 5. خريطة الوحدة</button>' +
                    ((adminPerms.publicQuiz || state.isAdminUnlocked) ? '<button type="button" data-org-studymode="quiz" class="px-3 py-2 rounded-xl text-xs font-black transition ' + (state.activeStudyMode === "quiz" ? "bg-emerald-600 text-white shadow-md" : "bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700") + '">✅ 6. بنك أسئلة الوحدة</button>' : '') +
                  '</div>' +
                  '<div class="flex flex-wrap gap-1.5">' +
                    ((adminPerms.publicVoice || state.isAdminUnlocked) ? '<button type="button" id="btnOrgSpeakLesson" class="px-3 py-1.5 rounded-xl bg-sky-500/15 text-sky-700 dark:text-sky-300 border border-sky-500/30 text-xs font-black">🔊 استمع للصفحة</button>' : '') +
                    '<button type="button" id="btnOrgQuickClipMargin" class="px-3 py-1.5 rounded-xl bg-purple-500/15 text-purple-700 dark:text-purple-300 border border-purple-500/30 text-xs font-black">🖍️ اقتباس للهامش</button>' +
                    '<button type="button" id="btnOrgShareLink" class="px-3 py-1.5 rounded-xl bg-teal-500/15 text-teal-700 dark:text-teal-300 border border-teal-500/30 text-xs font-black">🔗 رابط الصفحة</button>' +
                    '<button type="button" id="btnOrgCopyPageText" class="px-3 py-1.5 rounded-xl bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 border border-indigo-500/30 text-xs font-black">📋 نسخ الصفحة</button>' +
                    '<button type="button" id="btnOrgPrintLesson" class="px-3 py-1.5 rounded-xl bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 text-xs font-black">🖨️ طباعة الحقيبة A4</button>' +
                    '<button type="button" id="btnOrgPrintFullSubject" class="px-3 py-1.5 rounded-xl bg-rose-500/15 text-rose-700 dark:text-rose-300 border border-rose-500/30 text-xs font-black">📄 ملخص المادة للامتحان</button>' +
                    '<button type="button" id="btnOrgExpandRead" class="px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-xs font-black">' + (state.isExpandedReading ? "🗗 تصغير العرض" : "⛶ تكبير الشاشة") + '</button>' +
                  '</div>' +
                '</div>' +

                '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5">' +
                  (state.isExpandedReading ? '' : (
                    '<div class="lg:col-span-4 space-y-2">' +
                      '<div class="flex flex-wrap items-center justify-between gap-1.5 mb-1.5">' +
                        '<span class="text-xs font-black text-slate-600 dark:text-slate-300">📑 فهرس الوحدات:</span>' +
                        '<div class="flex gap-1">' +
                          '<button type="button" data-org-semfilter="all" class="px-2 py-0.5 rounded-lg text-[10px] font-black ' + (state.semesterFilter === "all" ? "bg-sky-600 text-white" : "bg-slate-200 dark:bg-slate-800") + '">الكل</button>' +
                          '<button type="button" data-org-semfilter="s1" class="px-2 py-0.5 rounded-lg text-[10px] font-black ' + (state.semesterFilter === "s1" ? "bg-emerald-600 text-white" : "bg-slate-200 dark:bg-slate-800") + '">فصل 1</button>' +
                          '<button type="button" data-org-semfilter="s2" class="px-2 py-0.5 rounded-lg text-[10px] font-black ' + (state.semesterFilter === "s2" ? "bg-purple-600 text-white" : "bg-slate-200 dark:bg-slate-800") + '">فصل 2</button>' +
                        '</div>' +
                      '</div>' +
                      (M.units || []).map(function (uTitle, uIdx) {
                        if (state.semesterFilter === "s1" && /الفصل 2|Semester 2|فصل 2/.test(uTitle)) return "";
                        if (state.semesterFilter === "s2" && /الفصل 1|Semester 1|فصل 1/.test(uTitle)) return "";
                        var uOn = uIdx === pageData.unitIdx;
                        var uStartPg = uIdx * PAGES_PER_UNIT + 1;
                        var uDone = !!completedUnits[M.id + ":" + uIdx];
                        return '<button type="button" data-org-unit="' + uIdx + '" class="w-full p-3 rounded-2xl border text-right text-xs font-bold transition flex items-center justify-between gap-2 ' +
                          (uOn ? "bg-sky-600 text-white border-sky-400 font-black shadow-md" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-sky-400") + '">' +
                          '<span>' + (uDone ? "✅ " : "") + esc(uTitle) + '</span>' +
                          '<span class="px-2 py-0.5 rounded-lg ' + (uOn ? "bg-black/25 text-amber-200" : "bg-slate-100 dark:bg-slate-800 text-slate-500") + ' text-[10px] font-black shrink-0">ص ' + uStartPg + '</span>' +
                        '</button>';
                      }).join("") +
                    '</div>'
                  )) +

                  '<div id="orgActiveContentCard" class="' + (state.isExpandedReading ? "lg:col-span-12" : "lg:col-span-8") + '">' +
                    (state.activeStudyMode === "book" ? (
                      '<div class="space-y-3">' +
                        '<div class="p-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">' +
                          '<div class="flex flex-wrap items-center gap-1">' +
                            '<span class="text-[11px] font-black text-slate-500 ml-1">📄 صفحات الوحدة:</span>' +
                            quickPages.map(function (qp) {
                              var isCur = qp.p === pageData.page;
                              return '<button type="button" data-org-quickpage="' + qp.p + '" class="px-2.5 py-1 rounded-xl text-[11px] font-black transition ' +
                                (isCur ? "bg-amber-500 text-slate-950 shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-sky-500/20") + '">' +
                                esc(qp.lbl) +
                              '</button>';
                            }).join("") +
                          '</div>' +
                          '<div class="flex items-center gap-1">' +
                            '<button type="button" id="btnOrgFontPlus" class="px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px] font-black" title="تكبير الخط">A+</button>' +
                            '<button type="button" id="btnOrgFontMinus" class="px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px] font-black" title="تصغير الخط">A-</button>' +
                            '<button type="button" data-org-paper="cream" class="px-2 py-1 rounded-lg bg-[#fcfaf2] text-slate-900 border border-amber-900/30 text-[10px] font-black">📜 كريمي</button>' +
                            '<button type="button" data-org-paper="white" class="px-2 py-1 rounded-lg bg-white text-slate-900 border border-slate-300 text-[10px] font-black">☀️ أبيض</button>' +
                            '<button type="button" data-org-paper="night" class="px-2 py-1 rounded-lg bg-slate-950 text-white border border-slate-700 text-[10px] font-black">🌙 ليلي</button>' +
                          '</div>' +
                        '</div>' +

                        '<div id="orgBookPagePaper" style="font-size:' + readerPrefs.fontSize + 'px" class="p-5 sm:p-6 rounded-2xl border-2 shadow-inner space-y-4 min-h-[295px] scroll-mt-20 ' + paperClasses + '">' +
                          '<div class="flex flex-wrap items-center justify-between gap-2 border-b-2 border-amber-900/15 pb-3">' +
                            '<div>' +
                              '<div class="text-[11px] font-black text-emerald-600">' + esc(pageData.unitTitle) + '</div>' +
                              '<h4 class="text-sm sm:text-base font-black mt-0.5">📖 ' + esc(pageData.subHeading) + '</h4>' +
                            '</div>' +
                            '<span class="px-2.5 py-1 rounded-lg bg-amber-500/20 text-xs font-black">صفحة ' + pageData.page + ' من ' + pageData.totalPages + '</span>' +
                          '</div>' +

                          '<div class="space-y-3 leading-8 font-semibold">' +
                            pageData.paragraphs.map(function (par) {
                              return '<p class="whitespace-pre-line">' + esc(par) + '</p>';
                            }).join("") +
                          '</div>' +

                          '<div class="p-4 rounded-xl bg-amber-500/15 border-r-4 border-amber-500 space-y-1.5">' +
                            '<div class="text-xs font-black">' + esc(pageData.boxTitle) + '</div>' +
                            '<ul class="list-disc pr-5 space-y-1 text-xs font-bold">' +
                              pageData.boxPoints.map(function (pt) { return '<li>' + esc(pt) + '</li>'; }).join("") +
                            '</ul>' +
                          '</div>' +

                          '<div class="p-3.5 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex flex-wrap items-center justify-between gap-2 text-xs">' +
                            '<div class="font-bold text-purple-900 dark:text-purple-200">' +
                              (state.revealCloze ? '💡 الإجابة: ' + esc(pageData.boxPoints[0] || pageData.subHeading) : '🧠 اختبر حفظك: ما هي الفكرة أو القاعدة المحورية في هذه الصفحة؟') +
                            '</div>' +
                            '<button type="button" id="btnOrgToggleCloze" class="px-3 py-1 rounded-xl bg-purple-600 text-white font-black shrink-0">' + (state.revealCloze ? '🙈 إخفاء' : '👁️ كشف الإجابة') + '</button>' +
                          '</div>' +

                          '<div class="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-2 text-xs">' +
                            '<div class="flex flex-wrap items-center justify-between gap-2">' +
                              '<span class="font-black text-emerald-800 dark:text-emerald-300">✅ حلول أسئلة الدرس والنشاط التطبيقي (صفحة ' + pageData.page + ')</span>' +
                              '<button type="button" id="btnOrgToggleSolutions" class="px-3 py-1 rounded-xl bg-emerald-600 text-white font-black">' + (state.revealSolutions ? "🙈 إخفاء الحل" : "📖 عرض الحل النموذجي") + '</button>' +
                            '</div>' +
                            (state.revealSolutions ? (
                              '<div class="p-3 rounded-xl bg-white dark:bg-slate-900 border border-emerald-500/30 leading-relaxed text-slate-700 dark:text-slate-200 font-semibold">' +
                                '<strong>الإجابة النموذجية الموثّقة:</strong> ' + esc(pageData.activityBody) + '<br/>' +
                                '<span class="text-emerald-700 dark:text-emerald-300">القاعدة المطبّقة في الحل: ' + esc(pageData.boxPoints[0] || "") + '</span>' +
                              '</div>'
                            ) : '') +
                          '</div>' +

                          '<div class="p-3.5 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 space-y-2 text-xs">' +
                            '<div class="font-black text-indigo-800 dark:text-indigo-300">🤖 اسأل المساعد الذكي عن هذه الصفحة (بلا إنترنت):</div>' +
                            '<div class="flex gap-1.5">' +
                              '<input id="inpOrgSmartPageQ" type="text" placeholder="اكتب سؤالك عن الدرس أو القاعدة (مثال: لخّص الدرس، ما القاعدة؟)..." class="flex-1 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-indigo-500/30 font-bold outline-none"/>' +
                              '<button type="button" id="btnOrgAskSmartPage" class="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black">✨ أجب فوراً</button>' +
                            '</div>' +
                            (state.smartPageAnswer ? '<div class="p-3 rounded-xl bg-white dark:bg-slate-900 border border-indigo-500/30 leading-relaxed font-semibold text-slate-800 dark:text-slate-200 whitespace-pre-line">' + esc(state.smartPageAnswer) + '</div>' : '') +
                          '</div>' +

                          '<div class="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-xs">' +
                            '<span class="font-black text-emerald-700 dark:text-emerald-300">' + esc(pageData.activityTitle) + ' </span>' +
                            '<span class="font-semibold">' + esc(pageData.activityBody) + '</span>' +
                          '</div>' +
                        '</div>' +

                        '<div class="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row items-stretch sm:items-center gap-2 text-xs">' +
                          '<span class="font-black text-amber-700 dark:text-amber-300 shrink-0">✏️ هامش صفحة ' + pageData.page + ':</span>' +
                          '<input id="inpOrgPageMarginNote" type="text" value="' + esc(curPageNoteVal) + '" placeholder="اكتب ملاحظتك أو تلخيصك الخاص على صفحة ' + pageData.page + ' ليُحفظ في حقيبتك..." class="flex-1 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-bold outline-none"/>' +
                          '<button type="button" id="btnOrgSaveMarginNote" class="px-3.5 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-black">💾 حفظ الهامش</button>' +
                        '</div>' +

                        // شريط الدمج والتعاون الذكي الفوري للصفحة المفتوحة
                        '<div class="p-3.5 rounded-2xl bg-gradient-to-l from-indigo-500/10 via-sky-500/10 to-emerald-500/10 border border-indigo-500/30 space-y-2 text-xs">' +
                          '<div class="flex flex-wrap items-center justify-between gap-2">' +
                            '<span class="font-black text-indigo-800 dark:text-indigo-300">🔗 جسر الدمج والتعاون الذكي — أرسل محتوى صفحة (' + pageData.page + ') مباشرة إلى:</span>' +
                            '<span class="text-[10px] font-bold text-slate-500">تعاون متكامل بين المعلم والطالب وولي الأمر بضغطة زر</span>' +
                          '</div>' +
                          '<div class="flex flex-wrap gap-1.5">' +
                            '<button type="button" data-org-bridge="lessonKitStudio" class="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black shadow-xs">🧳 حقيبة الحصة للمعلم</button>' +
                            '<button type="button" data-org-bridge="worksheetStudio" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow-xs">📝 ورقة عمل من الصفحة</button>' +
                            '<button type="button" data-org-bridge="whiteboardStudio" class="px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-black shadow-xs">🖍️ اشرح على السبورة الذكية</button>' +
                            '<button type="button" data-org-bridge="tutorStudio" class="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black shadow-xs">🤖 المعلم الخصوصي والخرائط</button>' +
                            '<button type="button" data-org-bridge="gamesStudio" class="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black shadow-xs">🎮 حوّلها للعبة ومسار تعاوني</button>' +
                            '<button type="button" id="btnOrgShareToCollabRoom" class="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-black shadow-xs">🤝 نشر في حلقة التعاون الذكي</button>' +
                          '</div>' +
                        '</div>' +

                        '<div class="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">' +
                          '<div class="flex items-center gap-2">' +
                            '<button type="button" id="btnOrgPrevPage" class="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 font-black">◀ الصفحة السابقة (' + Math.max(1, pageData.page - 1) + ')</button>' +
                            '<button type="button" id="btnOrgNextPage" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow">الصفحة التالية (' + Math.min(pageData.totalPages, pageData.page + 1) + ') ▶</button>' +
                          '</div>' +
                          '<div class="flex flex-wrap items-center gap-2">' +
                            '<span class="font-bold">انتقل لصفحة:</span>' +
                            '<input id="inpOrgPageNum" type="number" min="1" max="' + pageData.totalPages + '" value="' + pageData.page + '" class="w-16 px-2 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-center font-black"/>' +
                            '<button type="button" id="btnOrgSaveBm" class="px-3.5 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-black shadow">📌 اذهب واحفظ الصفحة</button>' +
                          '</div>' +
                        '</div>' +
                      '</div>'
                    ) : "") +

                    // التبويب 2: النسخة المصوّرة الأصلية (PDF / Google Drive)
                    (state.activeStudyMode === "origpdf" ? (
                      '<div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-rose-500/40 space-y-4 text-xs">' +
                        '<div class="flex flex-wrap items-center justify-between gap-2">' +
                          '<div>' +
                            '<div class="text-sm font-black text-rose-600 dark:text-rose-400">📕 معاينة النسخة المصوّرة الأصلية للكتاب (PDF / Google Drive) — «' + esc(M.bookTitle || M.name) + '»</div>' +
                            '<p class="text-slate-500 mt-0.5">استعرض صفحات الكتاب بصيغتها الأصلية أو افتح القارئ الموسّع وأضف اقتباساً موثّقاً إلى حقيبتك.</p>' +
                          '</div>' +
                          '<div class="flex flex-wrap gap-1.5">' + (M.officialUrl ? '<a href="' + esc(M.officialUrl) + '" target="_blank" rel="noopener" class="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow">🏛️ فتح الكتاب الرسمي من بوابة الوزارة</a>' : '') + '<button type="button" id="btnOrgOpenFullBookReader" class="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black shadow">📖 فتح في عارض الكتب الموسّع</button></div>' +
                        '</div>' +
                        (driveFid
                          ? '<iframe src="https://drive.google.com/file/d/' + esc(driveFid) + '/preview" class="w-full h-80 rounded-2xl border border-slate-300 dark:border-slate-700" allow="autoplay"></iframe>'
                          : '<div class="p-5 rounded-2xl bg-slate-950 text-white border border-slate-800 space-y-3">' +
                              '<div class="flex items-center justify-between text-amber-300 font-black"><span>📄 معاينة الصفحة الأصلية (' + pageData.page + ' من ' + pageData.totalPages + ')</span><span>دقة أصلية واضحة</span></div>' +
                              '<div class="p-4 rounded-xl bg-slate-900 border border-slate-800 leading-8 text-slate-200 whitespace-pre-line">' + esc(pageData.subHeading + "\n\n" + pageData.paragraphs.join("\n\n")) + '</div>' +
                            '</div>') +
                        '<div class="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-2">' +
                          '<span class="font-bold">📌 توثيق المرجع القياسي (APA): وزارة التربية والتعليم العالي. (2025). ' + esc(M.bookTitle || M.name) + ' (ص. ' + pageData.page + ').</span>' +
                          '<button type="button" id="btnOrgCopyApaRef" class="px-3 py-1.5 rounded-xl bg-indigo-600 text-white font-black">📋 نسخ التوثيق والاقتباس</button>' +
                        '</div>' +
                      '</div>'
                    ) : "") +

                    // التبويب 3: ملخص كورنيل الثلاثي
                    (state.activeStudyMode === "cornell" ? (
                      '<div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-amber-500/40 space-y-4">' +
                        '<div class="flex flex-wrap items-center justify-between gap-2">' +
                          '<div class="text-xs sm:text-sm font-black text-amber-600 dark:text-amber-400">📓 ملخص كورنيل الثلاثي لوحدة «' + esc(pageData.unitTitle) + '»:</div>' +
                          '<button type="button" id="btnOrgToggleCornellHide" class="px-3.5 py-1.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-black shadow">' +
                            (state.hideCornellNotes ? "👁️ إظهار الشرح والقواعد" : "🙈 إخفاء الشرح للتسميع الذاتي") +
                          '</button>' +
                        '</div>' +
                        '<div class="grid grid-cols-1 md:grid-cols-12 gap-3 text-xs">' +
                          '<div class="md:col-span-4 p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-2">' +
                            '<div class="font-black text-amber-700 dark:text-amber-300">🔑 عمود الأسئلة المفتاحية (30%):</div>' +
                            '<div>• ما القاعدة الأساسية في «' + esc(pageData.unitTitle) + '»؟</div>' +
                            '<div>• كيف نطبق هذه القاعدة في حل المسائل والتمارين؟</div>' +
                            '<div>• ما أهم النقاط الواردة في صفحة ' + pageData.page + '؟</div>' +
                          '</div>' +
                          '<div class="md:col-span-8 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-2">' +
                            '<div class="font-black text-sky-600 dark:text-sky-400">📝 عمود الشرح والقواعد المستخرجة (70%):</div>' +
                            (state.hideCornellNotes
                              ? '<div class="p-6 text-center text-slate-400 font-black">🙈 تم إخفاء الشرح مؤقتاً — أجب عن الأسئلة المفتاحية في العمود الأيمن ذهنياً ثم اضغط «👁️ إظهار الشرح» للتحقق!</div>'
                              : (M.rules || []).concat(pageData.boxPoints).map(function (r) { return '<div class="leading-relaxed font-semibold">• ' + esc(r) + '</div>'; }).join("")) +
                          '</div>' +
                        '</div>' +
                        '<div class="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs">' +
                          '<span class="font-black text-emerald-700 dark:text-emerald-300">📌 الخلاصة الذهبية أسفل ورقة كورنيل: </span>' +
                          '<span class="font-semibold">' + esc((M.rules && M.rules[0]) || pageData.boxPoints[0]) + '</span>' +
                        '</div>' +
                      '</div>'
                    ) : "") +

                    // التبويب 4: بطاقات الاستذكار القلّابة
                    (state.activeStudyMode === "flashcards" ? (
                      '<div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-purple-500/40 space-y-4">' +
                        '<div class="text-xs sm:text-sm font-black text-purple-600 dark:text-purple-300">🃏 بطاقات الاستذكار القلّابة لوحدة «' + esc(pageData.unitTitle) + '» (اضغط على أي بطاقة لقلبها ورؤية الجواب):</div>' +
                        '<div class="grid grid-cols-1 md:grid-cols-3 gap-3">' +
                          pageData.flashcards.map(function (fc) {
                            var flipped = !!state.flippedCards[fc.id];
                            return '<button type="button" data-org-flipcard="' + esc(fc.id) + '" class="p-4 rounded-2xl border-2 text-right transition-all min-h-[145px] flex flex-col justify-between ' +
                              (flipped ? "bg-emerald-950 text-white border-emerald-400 shadow-lg" : "bg-purple-500/5 dark:bg-slate-800 border-purple-500/30 hover:border-purple-400") + '">' +
                              '<div class="text-[10px] font-black ' + (flipped ? "text-emerald-300" : "text-purple-500") + '">' + (flipped ? "✔️ الإجابة النموذجية:" : "❓ السؤال — اضغط لقلب البطاقة 🔄") + '</div>' +
                              '<div class="text-xs font-black leading-relaxed my-2">' + esc(flipped ? fc.a : fc.q) + '</div>' +
                              '<div class="text-[10px] opacity-70">بطاقة استذكار نشط</div>' +
                            '</button>';
                          }).join("") +
                        '</div>' +
                      '</div>'
                    ) : "") +

                    // التبويب 5: الخريطة المفاهيمية
                    (state.activeStudyMode === "conceptmap" ? (
                      '<div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-cyan-500/40 space-y-4 text-xs">' +
                        '<div class="text-sm font-black text-cyan-600 dark:text-cyan-400">🗺️ الخريطة المفاهيمية البصرية لوحدة «' + esc(pageData.unitTitle) + '»:</div>' +
                        '<div class="p-4 rounded-2xl bg-slate-950 text-white space-y-4">' +
                          '<div class="mx-auto max-w-md p-3 rounded-2xl bg-gradient-to-l from-cyan-600 to-indigo-700 text-center font-black shadow-lg">📘 ' + esc(M.bookTitle || M.name) + '</div>' +
                          '<div class="text-center text-cyan-400 font-black">⬇</div>' +
                          '<div class="mx-auto max-w-lg p-3 rounded-2xl bg-slate-900 border-2 border-cyan-400 text-center font-black text-amber-300">📑 ' + esc(pageData.unitTitle) + ' (صفحة ' + pageData.page + ')</div>' +
                          '<div class="text-center text-emerald-400 font-black">⬇ تتفرع إلى الركائز التالية ⬇</div>' +
                          '<div class="grid grid-cols-1 md:grid-cols-3 gap-3">' +
                            '<div class="p-3 rounded-xl bg-slate-900 border border-emerald-500/40"><div class="font-black text-emerald-300 mb-1">1️⃣ المفهوم المحوري</div><p class="leading-relaxed text-slate-200">' + esc((M.rules && M.rules[0]) || pageData.boxPoints[0]) + '</p></div>' +
                            '<div class="p-3 rounded-xl bg-slate-900 border border-amber-500/40"><div class="font-black text-amber-300 mb-1">2️⃣ الشرح والتفصيل</div><p class="leading-relaxed text-slate-200">' + esc(pageData.subHeading) + '</p></div>' +
                            '<div class="p-3 rounded-xl bg-slate-900 border border-sky-500/40"><div class="font-black text-sky-300 mb-1">3️⃣ التطبيق العملي</div><p class="leading-relaxed text-slate-200">' + esc(pageData.activityBody) + '</p></div>' +
                          '</div>' +
                        '</div>' +
                      '</div>'
                    ) : "") +

                    // التبويب 6: بنك أسئلة الوحدة التفاعلي
                    (state.activeStudyMode === "quiz" ? (
                      '<div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-emerald-500/40 space-y-4 text-xs">' +
                        '<div class="flex flex-wrap items-center justify-between gap-2">' +
                          '<div class="text-sm font-black text-emerald-600 dark:text-emerald-400">✅ بنك أسئلة الوحدة التفاعلي — «' + esc(pageData.unitTitle) + '»:</div>' +
                          '<div class="flex items-center gap-2">' +
                            '<span class="px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 font-black">النتيجة: ' + quizCorrectCount + ' من ' + pageData.unitQuizQuestions.length + '</span>' +
                            '<button type="button" id="btnOrgResetUnitQuiz" class="px-3 py-1 rounded-lg bg-slate-200 dark:bg-slate-800 font-bold">🔄 إعادة المحاولة</button>' +
                          '</div>' +
                        '</div>' +
                        '<div class="space-y-3">' +
                          pageData.unitQuizQuestions.map(function (qObj, qIdx) {
                            var picked = state.quizAnswers[qIdx];
                            return '<div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">' +
                              '<div class="font-black text-slate-900 dark:text-white">' + esc(qObj.q) + '</div>' +
                              '<div class="grid gap-1.5">' +
                                qObj.opts.map(function (optTxt, oIdx) {
                                  var isSelected = picked === oIdx;
                                  var isCorrect = oIdx === qObj.ans;
                                  var cls = "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900";
                                  if (picked !== undefined) {
                                    if (isSelected && isCorrect) cls = "border-emerald-500 bg-emerald-500/15 font-black";
                                    else if (isSelected && !isCorrect) cls = "border-rose-500 bg-rose-500/15";
                                    else if (isCorrect) cls = "border-emerald-500/50 bg-emerald-500/5";
                                  }
                                  return '<button type="button" data-org-uquiz="' + qIdx + ':' + oIdx + '" class="w-full text-right p-2.5 rounded-xl border-2 font-bold transition ' + cls + '">' +
                                    esc(optTxt) + (isSelected ? (isCorrect ? " ✅ إجابة صحيحة!" : " ❌ غير صحيح") : "") +
                                  '</button>';
                                }).join("") +
                              '</div>' +
                              (picked !== undefined ? '<div class="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 font-bold">💡 التوضيح المنهجي: ' + esc(qObj.exp) + '</div>' : '') +
                            '</div>';
                          }).join("") +
                        '</div>' +
                      '</div>'
                    ) : "") +
                  '</div>' +
                '</div>' +
              '</div>'
              )) +
            '</div>'
          ) : "") +

          // =========================================================================
          // التبويب 2: بوابة الأدوات والمختبرات الذكية (مرتبة ومربوطة بصلاحيات الإدارة)
          // =========================================================================
          (state.topNav === "tools" ? (
            '<div id="orgToolsSectionBox" class="p-5 sm:p-6 space-y-5">' +
              '<div class="p-4 rounded-2xl bg-gradient-to-l from-amber-500/15 via-sky-500/10 to-indigo-500/15 border border-amber-500/35 flex flex-col lg:flex-row lg:items-center justify-between gap-3 text-xs">' +
                '<div>' +
                  '<div class="text-sm sm:text-base font-black text-slate-900 dark:text-white">🛠️ بوابة الأدوات التعليمية والمختبرات التفاعلية الشاملة (' + MASTER_TOOLS_CATALOG.length + ' أداة)</div>' +
                  '<p class="text-slate-600 dark:text-slate-300 mt-0.5">جميع أدوات المنصة مصنفة ومرتبة في مكان واحد — وتخضع لنظام الصلاحيات المخصص من إدارة المنصة لكل عضو وفئة.</p>' +
                '</div>' +
                '<div class="flex flex-wrap items-center gap-2 shrink-0">' +
                  '<span class="px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 font-black">🟢 متاح لك: ' + allowedToolsCount + ' أداة</span>' +
                  '<span class="px-3 py-1.5 rounded-xl bg-rose-500/15 text-rose-600 dark:text-rose-300 border border-rose-500/30 font-black">🔒 محجوب: ' + (MASTER_TOOLS_CATALOG.length - allowedToolsCount) + ' أداة</span>' +
                  (!activeViewerUser ? '<button type="button" data-org-topnav="account" class="px-3.5 py-1.5 rounded-xl bg-sky-600 text-white font-black shadow">🔑 سجل دخولك لفتح أدوات فئتك</button>' : '') +
                '</div>' +
              '</div>' +

              // شريط الأداة المفتوحة حالياً إن وجدت
              (state.openedToolId && TOOL_MAP[state.openedToolId] ? (
                '<div id="orgActiveToolBanner" class="p-4 rounded-2xl bg-slate-900 text-white border-2 border-amber-400 shadow-xl flex flex-wrap items-center justify-between gap-3 text-xs">' +
                  '<div class="flex items-center gap-2.5">' +
                    '<span class="text-2xl">' + TOOL_MAP[state.openedToolId].ico + '</span>' +
                    '<div>' +
                      '<div class="text-sm font-black text-amber-300">الأداة المفتوحة بالأسفل مباشرة الآن: «' + esc(TOOL_MAP[state.openedToolId].title) + '»</div>' +
                      '<div class="text-[11px] text-slate-300">' + esc(TOOL_MAP[state.openedToolId].desc) + ' — تم طيّ قائمة البطاقات لتظهر الأداة أمامك مباشرة ⬇</div>' +
                    '</div>' +
                  '</div>' +
                  '<div class="flex flex-wrap items-center gap-2">' +
                    '<button type="button" id="btnOrgToggleToolsCatalogGrid" class="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-black">' + (state.collapseToolsCatalog ? '📂 إظهار فهرس كل الأدوات (' + MASTER_TOOLS_CATALOG.length + ')' : '🎯 طيّ فهرس الأدوات للتركيز') + '</button>' +
                    '<button type="button" data-org-scrollto="' + esc(state.openedToolId) + '" class="px-3.5 py-2 rounded-xl bg-amber-400 text-slate-950 font-black">⬇ الانتقال للأداة</button>' +
                    '<button type="button" id="btnOrgCloseActiveTool" class="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black">✕ إغلاق الأداة</button>' +
                  '</div>' +
                '</div>'
              ) : '') +

              (!(state.openedToolId && state.collapseToolsCatalog) ? (
              // تصنيفات الأدوات + البحث
              '<div class="grid grid-cols-1 lg:grid-cols-12 gap-3 items-center">' +
                '<div class="lg:col-span-8 flex flex-wrap gap-1.5">' +
                  [
                    { id: "all", lbl: "🌟 كل الأدوات (" + MASTER_TOOLS_CATALOG.length + ")" },
                    { id: "granted", lbl: "🟢 المتاحة لحسابي (" + allowedToolsCount + ")" },
                    { id: "student", lbl: "🎒 الطالب والتوجيهي" },
                    { id: "teacher", lbl: "🧑‍🏫 المعلم والتحضير" },
                    { id: "labs", lbl: "🧪 المختبرات والألعاب" },
                    { id: "ai", lbl: "🤖 الذكاء الاصطناعي" },
                    { id: "university", lbl: "🎓 الجامعة والـ CV" },
                    { id: "admin_class", lbl: "🧰 الإدارة الصفية والأسرة" }
                  ].map(function (c) {
                    var on = state.toolsCat === c.id;
                    return '<button type="button" data-org-toolcat="' + c.id + '" class="px-3 py-2 rounded-xl text-xs font-black transition ' +
                      (on ? "bg-indigo-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200") + '">' +
                      c.lbl +
                    '</button>';
                  }).join("") +
                '</div>' +
                '<div class="lg:col-span-4">' +
                  '<input id="inpOrgToolsSearch" type="search" value="' + esc(state.toolsSearch) + '" placeholder="🔍 ابحث عن أداة (سبورة، أوراق عمل، حاسبة، توجيهي...)" class="w-full px-3.5 py-2 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-xs font-bold outline-none focus:border-indigo-500"/>' +
                '</div>' +
              '</div>' +

              // شبكة بطاقات الأدوات مع شارات الصلاحيات الحية
              '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">' +
                MASTER_TOOLS_CATALOG.filter(function (t) {
                  var access = evaluateToolAccessForUser(t.id, activeViewerUser, false);
                  if (adminPerms.hideBlockedToolsCompletely && !access.allowed) return false;
                  if (state.toolsCat === "granted" && !access.allowed) return false;
                  if (state.toolsCat !== "all" && state.toolsCat !== "granted" && t.cat !== state.toolsCat) return false;
                  var q = (state.toolsSearch || "").trim().toLowerCase();
                  if (q && (t.title + " " + t.desc + " " + t.catLabel).toLowerCase().indexOf(q) === -1) return false;
                  return true;
                }).map(function (t) {
                  var access = evaluateToolAccessForUser(t.id, activeViewerUser, false);
                  var isOpened = state.openedToolId === t.id;
                  return '<div class="p-4 rounded-2xl border-2 transition flex flex-col justify-between gap-3 ' +
                    (isOpened
                      ? "bg-amber-500/10 border-amber-400 shadow-lg"
                      : (access.allowed
                        ? "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-indigo-500 shadow-xs"
                        : "bg-slate-100/70 dark:bg-slate-950/70 border-slate-200/70 dark:border-slate-800/70 opacity-90")) + '">' +
                    '<div class="space-y-2">' +
                      '<div class="flex items-start justify-between gap-2">' +
                        '<div class="flex items-center gap-2.5">' +
                          '<div class="w-10 h-10 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-xl shrink-0">' + t.ico + '</div>' +
                          '<div>' +
                            '<div class="text-xs sm:text-sm font-black text-slate-900 dark:text-white">' + esc(t.title) + '</div>' +
                            '<div class="text-[10px] font-bold text-slate-400">' + esc(t.catLabel) + '</div>' +
                          '</div>' +
                        '</div>' +
                        '<span class="px-2 py-0.5 rounded-lg border text-[10px] font-black shrink-0 ' + access.badgeClass + '">' + esc(access.label) + '</span>' +
                      '</div>' +
                      '<p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">' + esc(t.desc) + '</p>' +
                    '</div>' +
                    '<div class="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">' +
                      (access.allowed ? (
                        '<button type="button" data-org-opentool="' + esc(t.id) + '" class="flex-1 py-2 rounded-xl ' + (isOpened ? "bg-amber-500 text-slate-950" : "bg-indigo-600 hover:bg-indigo-500 text-white") + ' text-xs font-black shadow transition">' +
                          (isOpened ? "✨ الأداة مفتوحة بالأسفل ⬇" : "🚀 فتح وتشغيل الأداة") +
                        '</button>'
                      ) : (
                        '<button type="button" data-org-opentool="' + esc(t.id) + '" class="flex-1 py-2 rounded-xl bg-rose-600/15 hover:bg-rose-600 text-rose-600 dark:text-rose-300 hover:text-white border border-rose-500/30 text-xs font-black transition">' +
                          '🔒 محجوب — اطلب صلاحية الوصول' +
                        '</button>'
                      )) +
                    '</div>' +
                  '</div>';
                }).join("") +
              '</div>'
              ) : '') +
            '</div>'
          ) : "") +

          // =========================================================================
          // التبويب 3: المكتبة الشاملة والموارد التعليمية
          // =========================================================================
          (state.topNav === "library" ? (
            '<div id="orgLibrarySectionBox" class="p-5 sm:p-6 space-y-5">' +
              '<div class="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">' +
                '<div class="flex flex-wrap gap-2">' +
                  '<button type="button" data-org-libsub="curriculum_cultural" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.librarySubTab === "curriculum_cultural" ? "bg-emerald-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">📘 1. كتب المنهاج والمكتبة الثقافية (' + allFlatSubs.length + ' كتاب)</button>' +
                  '<button type="button" data-org-libsub="edu_resources" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.librarySubTab === "edu_resources" ? "bg-sky-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">📂 2. مكتبة الموارد والبرومبتات والأدوات</button>' +
                  '<button type="button" data-org-libsub="open_courses" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.librarySubTab === "open_courses" ? "bg-amber-500 text-slate-950 shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">🏅 3. الدورات التدريبية والمجتمع المعرفي</button>' +
                '</div>' +
              '</div>' +

              (state.librarySubTab !== "curriculum_cultural" ? (
                '<div class="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between text-xs">' +
                  '<span class="font-black text-emerald-700 dark:text-emerald-300">' + (state.librarySubTab === "edu_resources" ? "📂 مكتبة الموارد والبرومبتات التربوية معروضة بالأسفل مباشرة ⬇" : "🏅 الدورات التدريبية وبوابة المجتمع المعرفي معروضة بالأسفل مباشرة ⬇") + '</span>' +
                  '<button type="button" data-org-libsub="curriculum_cultural" class="px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-black">📘 العودة لمكتبة الكتب</button>' +
                '</div>'
              ) : (
                '<div class="space-y-4">' +
                  '<div class="grid grid-cols-1 sm:grid-cols-3 gap-2.5">' +
                    '<input id="inpOrgLibFilter" type="search" value="' + esc(state.libQuery || "") + '" placeholder="🔍 ابحث في المكتبة عن كتاب أو صف أو مبحث..." class="sm:col-span-2 px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-bold outline-none focus:border-emerald-500"/>' +
                    '<select id="selOrgLibStage" class="px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-black">' +
                      '<option value="all"' + (state.libStage === "all" ? " selected" : "") + '>📚 جميع المراحل (' + allFlatSubs.length + ' كتاب)</option>' +
                      masterTree.map(function (st) {
                        return '<option value="' + esc(st.id) + '"' + (state.libStage === st.id ? " selected" : "") + '>' + esc(st.ico + " " + st.shortName) + '</option>';
                      }).join("") +
                    '</select>' +
                  '</div>' +
                  '<div class="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2 text-xs">' +
                    '<div class="font-black text-amber-800 dark:text-amber-300">🎒 الحقائب الإثرائية السريعة (مكتبة منهاجي الثقافية):</div>' +
                    '<div class="flex flex-wrap gap-1.5">' +
                      [
                        { q: "القواعد", label: "✍️ القواعد الميسّر" },
                        { q: "العلوم", label: "🔭 العلوم والفضاء" },
                        { q: "فلسطين", label: "🇵🇸 التاريخ والجغرافيا" },
                        { q: "السيرة", label: "🎓 تخصصات جامعية وCV" },
                        { q: "", label: "📚 عرض كل الكتب" }
                      ].map(function (bag) {
                        return '<button type="button" data-org-libbag="' + esc(bag.q) + '" class="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-amber-500/40 hover:bg-amber-500 hover:text-slate-950 font-black transition">' + bag.label + '</button>';
                      }).join("") +
                    '</div>' +
                  '</div>' +
                  '<div id="orgLibGridBox" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">' +
                    allFlatSubs.filter(function (item) {
                      if (state.libStage && state.libStage !== "all" && item.stg.id !== state.libStage) return false;
                      var q = (state.libQuery || "").trim().toLowerCase();
                      if (!q) return true;
                      return (item.sub.name + " " + (item.sub.bookTitle || "") + " " + item.g.name).toLowerCase().indexOf(q) !== -1;
                    }).slice(0, 24).map(function (item) {
                      var bmk = bookmarks[item.sub.id];
                      return '<div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 flex flex-col justify-between gap-3 hover:border-emerald-500 transition">' +
                        '<div>' +
                          '<div class="flex items-center justify-between gap-2">' +
                            '<span class="px-2.5 py-0.5 rounded-full bg-sky-500/15 text-sky-600 dark:text-sky-300 text-[10px] font-black">' + esc(item.g.name) + '</span>' +
                            (bmk ? '<span class="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-300 text-[10px] font-black">📌 صفحة ' + bmk.page + '</span>' : '<span class="text-[10px] text-slate-400">' + (item.sub.totalPages || 140) + ' صفحة</span>') +
                          '</div>' +
                          '<div class="text-xs sm:text-sm font-black mt-2">' + esc(item.sub.bookTitle || item.sub.name) + '</div>' +
                        '</div>' +
                        '<div class="flex gap-1.5">' +
                          '<button type="button" data-org-jumpbook="' + esc(item.stg.id + "|" + item.g.id + "|" + item.b.id + "|" + item.sub.id) + '" class="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow">📖 اقرأ الآن</button>' +
                          (item.sub.officialUrl ? '<a href="' + esc(item.sub.officialUrl) + '" target="_blank" rel="noopener" class="px-2.5 py-2 rounded-xl bg-slate-200 dark:bg-slate-900 hover:bg-sky-500 hover:text-white text-xs font-black" title="فتح من بوابة الوزارة">🏛️</a>' : '') +
                        '</div>' +
                      '</div>';
                    }).join("") +
                  '</div>' +
                '</div>'
              )) +
            '</div>'
          ) : "") +

          // =========================================================================
          // التبويب 4: حقيبتي وهوامش قراءتي ومساحتي الشخصية
          // =========================================================================
          (state.topNav === "mybag" ? (
            '<div id="orgMyBagSectionBox" class="p-5 sm:p-6 space-y-5">' +
              '<div class="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">' +
                '<div class="flex flex-wrap gap-2">' +
                  '<button type="button" data-org-bagsub="reading_notes" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.mybagSubTab === "reading_notes" ? "bg-purple-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">📌 1. الكتب قيد القراءة ودفتر الهوامش (' + savedNotesCount + ')</button>' +
                  '<button type="button" data-org-bagsub="smart_collab" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.mybagSubTab === "smart_collab" ? "bg-emerald-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">🤝 2. حلقات التعاون الذكي والفصول التشاركية (' + collabRooms.length + ')</button>' +
                  '<button type="button" data-org-bagsub="my_workspace" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.mybagSubTab === "my_workspace" ? "bg-sky-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">👨‍🎓 3. مساحتي الشخصية ومفكرة المهام</button>' +
                '</div>' +
                '<div class="flex flex-wrap items-center gap-2 text-xs">' +
                  '<button type="button" id="btnOrgCopyParentReport" class="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow">👪 تقرير ولي الأمر</button>' +
                  '<button type="button" id="btnOrgExportNotesMd" class="px-3.5 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-black shadow">⬇️ تصدير الهوامش (.md)</button>' +
                  '<button type="button" id="btnOrgPrintCertificate" class="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black shadow">🏆 شهادة الإنجاز A4</button>' +
                  '<button type="button" id="btnOrgPrintAllNotes" class="px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black shadow">🖨️ طباعة دفتر هوامشي A4</button>' +
                '</div>' +
              '</div>' +

              (state.mybagSubTab === "my_workspace" ? (
                '<div class="p-4 rounded-2xl bg-sky-500/10 border border-sky-500/30 flex flex-wrap items-center justify-between gap-2 text-xs">' +
                  '<span class="font-black text-sky-700 dark:text-sky-300">👨‍🎓 مساحتك الشخصية ولوحة إنجازاتك ومفكرة مهامك مفتوحة بالأسفل مباشرة ⬇</span>' +
                  '<button type="button" data-org-bagsub="reading_notes" class="px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black shadow">📌 العودة لدفتر الهوامش والكتب قيد القراءة</button>' +
                '</div>'
              ) : '') +

              (state.mybagSubTab === "reading_notes" ? (
              '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5">' +
                '<div class="lg:col-span-6 space-y-3">' +
                  '<div class="text-xs font-black text-slate-700 dark:text-slate-200">📖 الكتب التي تتابع قراءتها حالياً (أين وصلت):</div>' +
                  allFlatSubs.filter(function (x) { return !!bookmarks[x.sub.id]; }).concat(allFlatSubs.slice(0, 3)).slice(0, 6).map(function (item) {
                    var bmk = bookmarks[item.sub.id] || { page: 1 };
                    var pPct = Math.min(100, Math.max(2, Math.round((bmk.page / Math.max(1, item.sub.totalPages || 120)) * 100)));
                    return '<div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3 text-xs">' +
                      '<div>' +
                        '<div class="font-black">' + esc(item.sub.bookTitle || item.sub.name) + '</div>' +
                        '<div class="text-[11px] text-amber-600 dark:text-amber-400 font-bold mt-0.5">📌 وصلت إلى صفحة ' + bmk.page + ' من ' + (item.sub.totalPages || 120) + ' (' + pPct + '%)</div>' +
                      '</div>' +
                      '<button type="button" data-org-jumpbook="' + esc(item.stg.id + "|" + item.g.id + "|" + item.b.id + "|" + item.sub.id) + '" class="px-3.5 py-1.5 rounded-xl bg-sky-600 text-white font-black shrink-0">📖 أكمل القراءة</button>' +
                    '</div>';
                  }).join("") +
                '</div>' +

                '<div class="lg:col-span-6 space-y-3">' +
                  '<div class="text-xs font-black text-slate-700 dark:text-slate-200">✏️ الهوامش والملاحظات التي دوّنتها على صفحات الكتب:</div>' +
                  (savedNotesCount ? Object.keys(pageNotes).filter(function (k) { return pageNotes[k] && pageNotes[k].trim(); }).map(function (k) {
                    var pts = k.split(":");
                    var sId = pts[0], pg = pts[1] || "1";
                    var found = allFlatSubs.filter(function (x) { return x.sub.id === sId; })[0];
                    return '<div class="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-1 text-xs">' +
                      '<div class="flex items-center justify-between font-black text-amber-700 dark:text-amber-300">' +
                        '<span>📘 ' + esc(found ? found.sub.name : sId) + ' — صفحة ' + esc(pg) + '</span>' +
                        (found ? '<button type="button" data-org-jumpbook="' + esc(found.stg.id + "|" + found.g.id + "|" + found.b.id + "|" + found.sub.id) + '" class="text-sky-600 dark:text-sky-400 underline">افتح الصفحة</button>' : '') +
                      '</div>' +
                      '<p class="font-semibold text-slate-800 dark:text-slate-200">' + esc(pageNotes[k]) + '</p>' +
                    '</div>';
                  }).join("") : '<div class="p-6 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500">لم تدوّن هوامش بعد — افتح أي صفحة كتاب واكتب ملاحظتك في شريط «✏️ هامش الصفحة» ليتم حفظها هنا تلقائياً.</div>') +
                '</div>' +
              '</div>'
              ) : '') +

              // قسم حلقات التعاون الذكي والدمج التربوي بين المعلم والطالب وولي الأمر
              (state.mybagSubTab !== "my_workspace" ? (
              '<div class="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-4">' +
                '<div class="flex flex-wrap items-center justify-between gap-2">' +
                  '<div>' +
                    '<h3 class="text-sm sm:text-base font-black text-emerald-700 dark:text-emerald-300">🤝 منظومة التعاون الذكي والحلقات الدراسية التشاركية</h3>' +
                    '<p class="text-xs text-slate-500">تعاون حي ومنظّم يربط المعلم بالطالب وولي الأمر مع مشاركة المهام وأوراق العمل وروابط الصفحات مباشرة</p>' +
                  '</div>' +
                  '<button type="button" data-org-opentool="classroomsStudio" class="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black shadow">🏫 فتح الفصول الافتراضية وسجل الدرجات</button>' +
                '</div>' +

                (adminPerms.collabEnabled !== false ? (
                  '<div class="space-y-3">' +
                    '<div class="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 grid grid-cols-1 md:grid-cols-4 gap-2 text-xs">' +
                      '<input id="inpCollabRoomTitle" type="text" placeholder="عنوان حلقة التعاون أو المهمة الصفية..." class="md:col-span-2 px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-bold"/>' +
                      '<input id="inpCollabRoomTask" type="text" placeholder="النشاط التعاوني المطلوب (مثال: حل أسئلة ص ' + pageData.page + ')..." class="px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-bold"/>' +
                      '<button type="button" id="btnCreateCollabRoom" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow">➕ إنشاء ومشاركة الحلقة</button>' +
                    '</div>' +
                    '<div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">' +
                      collabRooms.map(function (rm, rIdx) {
                        return '<div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border-2 border-emerald-500/30 flex flex-col justify-between gap-3 shadow-sm">' +
                          '<div class="space-y-1.5">' +
                            '<div class="flex items-center justify-between gap-2">' +
                              '<span class="px-2.5 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 font-mono font-black text-[11px]">رمز: ' + esc(rm.code) + '</span>' +
                              '<span class="text-[11px] font-bold text-slate-400">👥 ' + (rm.members || 12) + ' مشارك</span>' +
                            '</div>' +
                            '<div class="font-black text-sm text-slate-900 dark:text-white">' + esc(rm.title) + '</div>' +
                            '<div class="text-[11px] text-sky-600 dark:text-sky-400 font-bold">إشراف: ' + esc(rm.teacher) + ' • ' + esc(rm.grade) + '</div>' +
                            '<p class="text-slate-600 dark:text-slate-300 leading-relaxed bg-white dark:bg-slate-950 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">🎯 المهمة النشطة: ' + esc(rm.activeTask) + '</p>' +
                          '</div>' +
                          '<div class="flex items-center gap-1.5 pt-2 border-t border-slate-200 dark:border-slate-800">' +
                            '<button type="button" data-collab-join="' + rIdx + '" class="flex-1 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black">🤝 انضمام وتفاعل</button>' +
                            '<button type="button" data-collab-wa="' + rIdx + '" class="px-2.5 py-1.5 rounded-xl bg-sky-500/15 text-sky-700 dark:text-sky-300 font-black" title="نسخ دعوة الحلقة">🔗 دعوة</button>' +
                            (isEffectiveSuperAdmin() ? '<button type="button" data-collab-del="' + rIdx + '" class="px-2 py-1.5 rounded-xl bg-rose-600/20 text-rose-500 font-black" title="حذف الحلقة (إدارة)">🗑️</button>' : '') +
                          '</div>' +
                        '</div>';
                      }).join("") +
                    '</div>' +
                  '</div>'
                ) : '<div class="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs font-bold text-amber-700">🔒 حلقات التعاون الذكي متوقفة مؤقتاً بقرار من إدارة المنصة.</div>') +
              '</div>'
              ) : '') +
            '</div>'
          ) : "") +

          // =========================================================================
          // التبويب 5: المرحلة الجامعية والسيرة الذاتية وعن المنصة
          // =========================================================================
          (state.topNav === "university" ? (
            '<div id="orgUniversitySectionBox" class="p-5 sm:p-6 space-y-5">' +
              '<div class="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">' +
                '<div class="flex flex-wrap gap-2">' +
                  '<button type="button" data-org-unisub="majors_tawjihi" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.uniSubTab === "majors_tawjihi" ? "bg-amber-500 text-slate-950 shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">🏛️ 1. دليل التخصصات الجامعية</button>' +
                  '<button type="button" data-org-unisub="cv_studio" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.uniSubTab === "cv_studio" ? "bg-indigo-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">📄 2. منشئ السيرة الذاتية (CV عربي/EN)</button>' +
                  '<button type="button" data-org-unisub="research_apa" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.uniSubTab === "research_apa" ? "bg-emerald-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">🔬 3. الأبحاث الجامعية وتوثيق APA</button>' +
                  '<button type="button" data-org-unisub="about_platform" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.uniSubTab === "about_platform" ? "bg-sky-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">🇵🇸 4. من نحن وتواصل معنا</button>' +
                '</div>' +
              '</div>' +

              (state.uniSubTab === "majors_tawjihi" ? (
                '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">' +
                  [
                    { ico: "💻", title: "هندسة البرمجيات والذكاء الاصطناعي", stream: "الفرع العلمي / الصناعي", desc: "تطوير الأنظمة الذكية، تطبيقات الويب، وتحليل البيانات الضخمة." },
                    { ico: "🩺", title: "الطب والعلوم الصحية والصيدلة", stream: "الفرع العلمي", desc: "الطب البشري، التمريض، الصيدلة، والتحاليل الطبية." },
                    { ico: "📊", title: "إدارة الأعمال والمحاسبة والريادة", stream: "الأدبي / الريادة / العلمي", desc: "الإدارة المالية، التسويق الرقمي، وإدارة المشاريع الصغيرة." },
                    { ico: "⚖️", title: "القانون والعلوم الإنسانية والتربية", stream: "الفرع الأدبي / الشرعي", desc: "المحاماة، التعليم، الصحافة والإعلام الرقمي." },
                    { ico: "🏗️", title: "الهندسة المدنية والمعمارية والطاقة", stream: "الفرع العلمي / الصناعي", desc: "تصميم المباني المستدامة، الطاقة المتجددة، والبنية التحتية." },
                    { ico: "🔬", title: "التقنية الحيوية والعلوم التطبيقية", stream: "الفرع العلمي", desc: "الأبحاث المخبرية، الجينات، والكيمياء الصناعية." }
                  ].map(function (maj) {
                    return '<div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-1.5">' +
                      '<div class="text-sm font-black">' + maj.ico + ' ' + maj.title + '</div>' +
                      '<div class="text-[11px] font-bold text-amber-600 dark:text-amber-400">المسار المطلوب: ' + maj.stream + '</div>' +
                      '<p class="text-slate-600 dark:text-slate-300 leading-relaxed">' + maj.desc + '</p>' +
                    '</div>';
                  }).join("") +
                '</div>'
              ) : (
                '<div class="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between text-xs">' +
                  '<span class="font-black text-amber-800 dark:text-amber-300">✨ القسم المختار معروض بالأسفل مباشرة ⬇</span>' +
                  '<button type="button" data-org-unisub="majors_tawjihi" class="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-black">🏛️ العودة لدليل التخصصات</button>' +
                '</div>'
              )) +
            '</div>'
          ) : "") +

          // =========================================================================
          // التبويب 6: نظام التسجيل الموحّد وحساب المستخدم وصلاحياته
          // =========================================================================
          (state.topNav === "account" ? (
            '<div id="orgAccountSectionBox" class="p-5 sm:p-6 space-y-5">' +
              (activeViewerUser ? (
                '<div class="space-y-5">' +
                  // بطاقة العضوية الرقمية
                  '<div class="p-5 rounded-3xl bg-gradient-to-l from-indigo-950 via-slate-900 to-slate-950 text-white border-2 border-indigo-500/40 shadow-xl flex flex-col lg:flex-row lg:items-center justify-between gap-4">' +
                    '<div class="flex items-center gap-3.5">' +
                      '<div class="w-14 h-14 rounded-2xl bg-indigo-600 text-white flex items-center justify-center text-2xl font-black shadow-md">' + esc((activeViewerUser.name || "ع").trim().charAt(0)) + '</div>' +
                      '<div>' +
                        '<div class="flex flex-wrap items-center gap-2">' +
                          '<span class="text-base sm:text-lg font-black">' + esc(activeViewerUser.name) + '</span>' +
                          '<span class="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-black">' + esc(activeViewerUser.roleLabel || "طالب") + '</span>' +
                          '<span class="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-black">🔓 ' + allowedToolsCount + ' أداة متاحة لك</span>' +
                        '</div>' +
                        '<div class="text-xs text-slate-300 mt-1 flex flex-wrap gap-3">' +
                          '<span dir="ltr">📧 ' + esc(activeViewerUser.email) + '</span>' +
                          '<span>🏫 ' + esc(activeViewerUser.gradeName || "الصف الرابع الأساسي") + '</span>' +
                          (activeViewerUser.school ? '<span>🏛️ ' + esc(activeViewerUser.school) + '</span>' : '') +
                        '</div>' +
                      '</div>' +
                    '</div>' +
                    '<div class="flex flex-wrap items-center gap-2">' +
                      '<button type="button" id="btnOrgGoMyGrade" class="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-black shadow">🚀 افتح منهاج صفي</button>' +
                      '<button type="button" data-org-topnav="tools" class="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow">🛠️ تصفح أدواتي المتاحة</button>' +
                      '<button type="button" id="btnOrgPrintMemberIdCard" class="px-3.5 py-2 rounded-xl bg-emerald-500/25 hover:bg-emerald-500 text-emerald-200 hover:text-slate-950 border border-emerald-400/40 text-xs font-black transition">🪪 بطاقة العضوية A4</button>' +
                      '<button type="button" id="btnOrgLogoutUser" class="px-3.5 py-2 rounded-xl bg-rose-600/25 hover:bg-rose-600 text-rose-200 hover:text-white border border-rose-500/40 text-xs font-black">🚪 تسجيل الخروج</button>' +
                    '</div>' +
                  '</div>' +

                  // تبويبات صفحة الحساب والخصوصية
                  '<div class="flex flex-wrap gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">' +
                    '<button type="button" data-org-accsub="profile" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.accountSubTab === "profile" ? "bg-indigo-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">👤 1. بيانات حسابي وتحديث الصف</button>' +
                    '<button type="button" data-org-accsub="my_permissions" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.accountSubTab === "my_permissions" ? "bg-emerald-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">🛡️ 2. صلاحياتي والأدوات الممنوحة لي (' + allowedToolsCount + '/' + MASTER_TOOLS_CATALOG.length + ')</button>' +
                    '<button type="button" data-org-accsub="my_requests" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.accountSubTab === "my_requests" ? "bg-amber-500 text-slate-950 shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">📨 3. طلبات الصلاحيات الخاصة بي</button>' +
                    '<button type="button" data-org-accsub="privacy_security" class="px-4 py-2 rounded-xl text-xs font-black transition ' + (state.accountSubTab === "privacy_security" ? "bg-teal-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">🔒 4. الخصوصية والضوابط وأمان بياناتي</button>' +
                  '</div>' +

                  (state.accountSubTab === "profile" ? (
                    '<div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">' +
                      '<div class="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">' +
                        '<div class="text-sm font-black text-indigo-600 dark:text-indigo-400">⚙️ تحديث بيانات العضوية والصف الدراسي:</div>' +
                        '<div><label class="block font-bold mb-1">الاسم الكامل:</label><input id="inpAccEditName" type="text" value="' + esc(activeViewerUser.name) + '" class="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 font-bold"/></div>' +
                        '<div><label class="block font-bold mb-1">المدرسة / الجامعة / المؤسسة:</label><input id="inpAccEditSchool" type="text" value="' + esc(activeViewerUser.school || "") + '" placeholder="اسم المدرسة أو الجامعة..." class="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 font-bold"/></div>' +
                        '<div class="grid grid-cols-2 gap-2">' +
                          '<div><label class="block font-bold mb-1">الصفة / الفئة:</label>' +
                            '<select id="selAccEditRole" class="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 font-black">' +
                              ["طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"].map(function (r) {
                                return '<option value="' + r + '"' + (activeViewerUser.roleLabel === r ? " selected" : "") + '>' + r + '</option>';
                              }).join("") +
                            '</select>' +
                          '</div>' +
                          '<div><label class="block font-bold mb-1">الصف الدراسي المفضل:</label>' +
                            '<select id="selAccountUpdateGrade" class="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 font-black">' +
                              [
                                { id: "g1", lbl: "الصف الأول الأساسي" }, { id: "g2", lbl: "الصف الثاني الأساسي" },
                                { id: "g3", lbl: "الصف الثالث الأساسي" }, { id: "g4", lbl: "الصف الرابع الأساسي" },
                                { id: "g5", lbl: "الصف الخامس الأساسي" }, { id: "g6", lbl: "الصف السادس الأساسي" },
                                { id: "g7", lbl: "الصف السابع الأساسي" }, { id: "g8", lbl: "الصف الثامن الأساسي" },
                                { id: "g9", lbl: "الصف التاسع الأساسي" }, { id: "g10", lbl: "الصف العاشر الأساسي" },
                                { id: "g11", lbl: "الصف الحادي عشر" }, { id: "g12", lbl: "التوجيهي (الثاني عشر)" },
                                { id: "uni-cv", lbl: "المرحلة الجامعية والـ CV" }
                              ].map(function (g) {
                                return '<option value="' + g.id + '"' + (activeViewerUser.gradeId === g.id ? " selected" : "") + '>' + g.lbl + '</option>';
                              }).join("") +
                            '</select>' +
                          '</div>' +
                        '</div>' +
                        '<button type="button" id="btnOrgSaveAccountGrade" class="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow">💾 حفظ تحديثات الحساب</button>' +
                      '</div>' +

                      '<div class="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">' +
                        '<div class="text-sm font-black text-emerald-600 dark:text-emerald-400">📊 ملخص نشاطك وصلاحياتك في المنصة:</div>' +
                        '<div class="grid grid-cols-2 gap-3">' +
                          '<div class="p-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800"><div class="text-slate-400">الصفحات المقروءة اليوم</div><div class="text-base font-black text-emerald-600 mt-0.5">' + getDailyStreak().todayPages + ' صفحات</div></div>' +
                          '<div class="p-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800"><div class="text-slate-400">الأدوات المسموحة لحسابك</div><div class="text-base font-black text-sky-600 mt-0.5">' + allowedToolsCount + ' من ' + MASTER_TOOLS_CATALOG.length + '</div></div>' +
                          '<div class="p-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800"><div class="text-slate-400">وحدات دراسية متقنة</div><div class="text-base font-black text-amber-500 mt-0.5">' + Object.keys(completedUnits).filter(function (k) { return !!completedUnits[k]; }).length + ' وحدات</div></div>' +
                          '<div class="p-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800"><div class="text-slate-400">ملاحظاتك الهامشية</div><div class="text-base font-black text-purple-500 mt-0.5">' + savedNotesCount + ' ملاحظة</div></div>' +
                        '</div>' +
                        '<div class="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-[11px] leading-relaxed">' +
                          '💡 <strong>ملاحظة:</strong> يمكنك استعراض جميع الأدوات الممنوحة لك أو طلب تفعيل أي أداة إضافية من الإدارة عبر تبويب «🛡️ صلاحياتي والأدوات الممنوحة لي».' +
                        '</div>' +
                      '</div>' +
                    '</div>'
                  ) : '') +

                  (state.accountSubTab === "my_permissions" ? (
                    '<div class="space-y-3 text-xs">' +
                      '<div class="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/35 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">' +
                        '<div>' +
                          '<div class="font-black text-amber-800 dark:text-amber-300">🎟️ هل لديك كود تفعيل صلاحيات من الإدارة؟</div>' +
                          '<div class="text-[11px] text-slate-500">أدخل الكود (مثال: VIP-TEACHER-2026 أو TAWJIHI-PACK-2026) لفتح الأدوات المخصصة لك فوراً:</div>' +
                        '</div>' +
                        '<div class="flex gap-2">' +
                          '<input id="inpUserRedeemCode" type="text" dir="ltr" placeholder="VIP-TEACHER-2026" class="px-3.5 py-2 rounded-xl bg-white dark:bg-slate-950 border border-amber-500/40 font-mono font-black text-xs uppercase"/>' +
                          '<button type="button" id="btnUserRedeemCode" class="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black shadow shrink-0">🎟️ تفعيل الكود</button>' +
                        '</div>' +
                      '</div>' +
                      '<div class="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex flex-wrap items-center justify-between gap-2">' +
                        '<span class="font-black text-emerald-800 dark:text-emerald-300">🛡️ قائمة جميع أدوات الموقع وحالة صلاحية وصولك لكل أداة:</span>' +
                        '<span class="text-[11px] font-bold text-slate-500">الأدوات المحجوبة يمكنك طلب تفعيلها بضغطة زر ليصل طلبك للإدارة</span>' +
                      '</div>' +
                      '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">' +
                        MASTER_TOOLS_CATALOG.map(function (t) {
                          var acc = evaluateToolAccessForUser(t.id, activeViewerUser, false);
                          return '<div class="p-3.5 rounded-2xl border flex items-center justify-between gap-2 ' + (acc.allowed ? "bg-white dark:bg-slate-900 border-emerald-500/30" : "bg-slate-100/70 dark:bg-slate-950 border-rose-500/30") + '">' +
                            '<div class="min-w-0">' +
                              '<div class="font-black truncate">' + t.ico + ' ' + esc(t.title) + '</div>' +
                              '<div class="text-[10px] mt-0.5 ' + (acc.allowed ? "text-emerald-600 dark:text-emerald-400" : "text-rose-500") + ' font-bold">' + esc(acc.label) + '</div>' +
                            '</div>' +
                            (acc.allowed
                              ? '<button type="button" data-org-opentool="' + esc(t.id) + '" class="px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-black shrink-0">فتح 🚀</button>'
                              : '<button type="button" data-org-reqtool="' + esc(t.id) + '" class="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-black shrink-0">📨 طلب الأداة</button>') +
                          '</div>';
                        }).join("") +
                      '</div>' +
                    '</div>'
                  ) : '') +

                  (state.accountSubTab === "my_requests" ? (
                    '<div class="space-y-3 text-xs">' +
                      '<div class="font-black text-amber-700 dark:text-amber-300">📨 سجل طلبات الصلاحيات المرسلة من حسابك إلى الإدارة:</div>' +
                      ((adminPerms.accessRequests || []).filter(function (r) { return r.userEmail === activeViewerUser.email; }).length ? (
                        '<div class="space-y-2">' +
                          (adminPerms.accessRequests || []).filter(function (r) { return r.userEmail === activeViewerUser.email; }).map(function (r) {
                            var stBadge = r.status === "approved"
                              ? '<span class="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 font-black">✅ تمت الموافقة والتفعيل</span>'
                              : (r.status === "rejected"
                                ? '<span class="px-2.5 py-1 rounded-lg bg-rose-500/20 text-rose-500 font-black">❌ تم الرفض</span>'
                                : '<span class="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-600 dark:text-amber-300 font-black">⏳ قيد مراجعة الإدارة</span>');
                            return '<div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">' +
                              '<div><div class="font-black">🛠️ ' + esc(r.toolTitle) + '</div><div class="text-[11px] text-slate-500">' + esc(r.note) + ' • ' + esc(r.requestedAt) + '</div></div>' +
                              stBadge +
                            '</div>';
                          }).join("") +
                        '</div>'
                      ) : '<div class="p-6 rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 text-center text-slate-500">لا توجد طلبات صلاحيات مرسلة من حسابك حتى الآن.</div>') +
                    '</div>'
                  ) : '') +

                  (state.accountSubTab === "privacy_security" ? (
                    '<div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">' +
                      '<div class="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-teal-500/30 space-y-3">' +
                        '<div class="text-sm font-black text-teal-600 dark:text-teal-400">🔒 ضوابط الخصوصية وحماية البيانات الشخصية:</div>' +
                        '<ul class="space-y-2 text-slate-600 dark:text-slate-300 leading-relaxed list-disc pr-4 font-semibold">' +
                          '<li><strong>عزل البيانات المستقل:</strong> جميع ملاحظاتك الهامشية، تقدمك في الكتب، وبرومبتاتك معزولة ومحمية ضمن ملف حسابك الخاص.</li>' +
                          '<li><strong>حماية الأذونات (الكاميرا والميكروفون):</strong> لا تطلب المنصة أي إذن للكاميرا أو الميكروفون إلا عند ضغطك المباشر داخل أداة التصوير أو المختبر الصوتي.</li>' +
                          '<li><strong>التشفير وعدم المشاركة:</strong> لا تتم مشاركة بياناتك مع أي جهات إعلانية خارجية نهائياً.</li>' +
                        '</ul>' +
                        '<div class="pt-2 flex flex-wrap gap-2">' +
                          '<a href="privacy.html" target="_blank" class="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-black">📜 قراءة وثيقة سياسة الخصوصية الكاملة</a>' +
                        '</div>' +
                      '</div>' +
                      '<div class="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-rose-500/30 space-y-3">' +
                        '<div class="text-sm font-black text-rose-600 dark:text-rose-400">⚙️ التحكم الكامل ببياناتي (تصدير أو مسح نهائي):</div>' +
                        '<p class="text-slate-600 dark:text-slate-300 leading-relaxed">يمكنك في أي وقت تنزيل نسخة كاملة من بياناتك وملاحظاتك، أو مسح سجلك وحذف حسابك نهائياً:</p>' +
                        '<div class="flex flex-col gap-2 pt-1">' +
                          '<button type="button" id="btnPrivacyExportMyData" class="w-full py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-black shadow">⬇️ تصدير جميع بياناتي وملاحظاتي (JSON)</button>' +
                          '<button type="button" id="btnPrivacyClearMyNotes" class="w-full py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500 text-amber-800 dark:text-amber-300 hover:text-slate-950 border border-amber-500/40 font-black transition">🧹 مسح هوامشي وسجل قراءتي المحلي</button>' +
                          '<button type="button" id="btnPrivacyDeleteMyAccount" class="w-full py-2.5 rounded-xl bg-rose-600/20 hover:bg-rose-600 text-rose-600 dark:text-rose-300 hover:text-white border border-rose-500/40 font-black transition">🗑️ حذف حسابي وجميع بياناتي نهائياً</button>' +
                        '</div>' +
                      '</div>' +
                    '</div>'
                  ) : '') +
                '</div>'
              ) : (
                // واجهة التسجيل والدخول الموحّدة لغير المسجلين
                '<div class="max-w-2xl mx-auto p-6 rounded-3xl bg-slate-50 dark:bg-slate-900 border-2 border-sky-500/30 space-y-5 shadow-xl">' +
                  '<div class="text-center space-y-1">' +
                    '<h3 class="text-base sm:text-lg font-black text-slate-900 dark:text-white">👤 بوابة التسجيل والدخول الموحّدة — EduTech Mindset</h3>' +
                    '<p class="text-xs text-slate-500 dark:text-slate-400">سجّل عضويتك مجاناً لحفظ تقدمك والوصول إلى الأدوات المخصصة لفئتك أو الممنوحة لك من الإدارة</p>' +
                  '</div>' +

                  '<div class="grid grid-cols-3 gap-2">' +
                    '<button type="button" id="btnAuthTabLogin" class="py-2.5 rounded-xl text-xs font-black transition ' + (state.authMode === "login" ? "bg-sky-600 text-white shadow-md" : "bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700") + '">🔑 1. تسجيل الدخول</button>' +
                    '<button type="button" id="btnAuthTabRegister" class="py-2.5 rounded-xl text-xs font-black transition ' + (state.authMode === "register" ? "bg-emerald-600 text-white shadow-md" : "bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700") + '">📝 2. إنشاء حساب جديد</button>' +
                    '<button type="button" id="btnAuthTabDemo" class="py-2.5 rounded-xl text-xs font-black transition ' + (state.authMode === "demo" ? "bg-amber-500 text-slate-950 shadow-md" : "bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700") + '">⚡ 3. دخول سريع تجريبي</button>' +
                  '</div>' +

                  (state.authMode === "register" ? (
                    '<div class="space-y-3 text-xs">' +
                      '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">' +
                        '<div><label class="block font-bold mb-1">الاسم الكامل *</label><input id="inpAuthName" type="text" placeholder="مثال: باسل أشرف الفقعاوي" class="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 font-bold"/></div>' +
                        '<div><label class="block font-bold mb-1">البريد الإلكتروني أو اسم المستخدم *</label><input id="inpAuthEmail" type="email" dir="ltr" placeholder="name@edutech.ps" class="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 font-bold"/></div>' +
                      '</div>' +
                      '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">' +
                        '<div><label class="block font-bold mb-1">كلمة المرور (4 أحرف فأكثر) *</label><input id="inpAuthPass" type="password" placeholder="••••••••" class="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 font-bold"/></div>' +
                        '<div><label class="block font-bold mb-1">المدرسة / الجامعة (اختياري)</label><input id="inpAuthSchool" type="text" placeholder="اسم المدرسة أو المؤسسة..." class="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 font-bold"/></div>' +
                      '</div>' +
                      '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">' +
                        '<div><label class="block font-bold mb-1">نوع الحساب / الدور التربوي *</label>' +
                          '<select id="selAuthRole" class="w-full px-3 py-2.5 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 font-black">' +
                            '<option value="طالب">🎓 طالب مدرسي (الصفوف 1–11)</option>' +
                            '<option value="توجيهي">🏅 طالب توجيهي (الثاني عشر)</option>' +
                            '<option value="جامعي">🏛️ طالب جامعي / خريج</option>' +
                            '<option value="معلم">🧑‍🏫 معلم / مشرف تربوي</option>' +
                            '<option value="ولي أمر">👪 ولي أمر</option>' +
                          '</select>' +
                        '</div>' +
                        '<div><label class="block font-bold mb-1">الصف الدراسي / المرحلة *</label>' +
                          '<select id="selAuthGrade" class="w-full px-3 py-2.5 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 font-black">' +
                            '<option value="g4">الصف الرابع الأساسي</option>' +
                            '<option value="g1">الصف الأول الأساسي</option>' +
                            '<option value="g2">الصف الثاني الأساسي</option>' +
                            '<option value="g3">الصف الثالث الأساسي</option>' +
                            '<option value="g5">الصف الخامس الأساسي</option>' +
                            '<option value="g6">الصف السادس الأساسي</option>' +
                            '<option value="g7">الصف السابع الأساسي</option>' +
                            '<option value="g8">الصف الثامن الأساسي</option>' +
                            '<option value="g9">الصف التاسع الأساسي</option>' +
                            '<option value="g10">الصف العاشر الأساسي</option>' +
                            '<option value="g11">الصف الحادي عشر</option>' +
                            '<option value="g12">التوجيهي (الثاني عشر)</option>' +
                            '<option value="uni-cv">المرحلة الجامعية والـ CV</option>' +
                          '</select>' +
                        '</div>' +
                      '</div>' +
                      '<div><label class="block font-bold mb-1 text-amber-600 dark:text-amber-400">🎟️ كود التفعيل أو الصلاحية الخاصة من الإدارة (اختياري):</label><input id="inpAuthInviteCode" type="text" dir="ltr" placeholder="اتركه فارغاً أو أدخل الكود مثل VIP-TEACHER-2026..." class="w-full px-3.5 py-2 rounded-xl bg-white dark:bg-slate-950 border border-amber-500/40 font-mono font-bold uppercase"/></div>' +
                      '<button type="button" id="btnAuthSubmitRegister" class="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow-lg">✨ إنشاء الحساب وتفعيل العضوية فوراً</button>' +
                    '</div>'
                  ) : (state.authMode === "demo" ? (
                    '<div class="space-y-3 text-xs">' +
                      '<div class="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 font-bold text-amber-800 dark:text-amber-300">' +
                        '⚡ اضغط على أي حساب من الأعضاء المسجلين أدناه للدخول المباشر وتجربة صلاحياته المخصصة:' +
                      '</div>' +
                      '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">' +
                        registeredUsers.map(function (u) {
                          var allowedCnt = MASTER_TOOLS_CATALOG.filter(function (t) { return evaluateToolAccessForUser(t.id, u, true).allowed; }).length;
                          return '<button type="button" data-org-quicklogin="' + esc(u.email) + '" class="p-3.5 rounded-2xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-amber-500 text-right transition flex flex-col justify-between gap-1.5">' +
                            '<div class="flex items-center justify-between gap-2">' +
                              '<span class="font-black text-slate-900 dark:text-white">' + esc(u.name) + '</span>' +
                              '<span class="px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-600 dark:text-indigo-300 text-[10px] font-black">' + esc(u.roleLabel) + '</span>' +
                            '</div>' +
                            '<div class="flex items-center justify-between text-[11px] text-slate-500">' +
                              '<span dir="ltr">' + esc(u.email) + '</span>' +
                              '<span class="text-emerald-600 dark:text-emerald-400 font-black">🔓 ' + allowedCnt + ' أداة متاحة</span>' +
                            '</div>' +
                          '</button>';
                        }).join("") +
                      '</div>' +
                    '</div>'
                  ) : (
                    '<div class="space-y-3 text-xs">' +
                      (window.Cloud && window.Cloud.enabled ? (
                        '<div class="p-3 rounded-2xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">' +
                          '<div class="font-bold text-slate-700 dark:text-slate-200">🌐 الدخول الموثّق عبر حساب Google (مزامنة سحابية فورية):</div>' +
                          '<div class="flex gap-1.5">' +
                            '<button type="button" id="btnOrgFirebaseGoogleLogin" class="px-4 py-2 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-950 font-black shadow flex items-center gap-1.5"><span>🌐</span><span>دخول بحساب Google</span></button>' +
                            '<button type="button" id="btnOrgFirebaseGoogleRedirect" class="px-3 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-[11px]" title="للهواتف التي تحجب النوافذ المنبثقة">📱 للهاتف</button>' +
                          '</div>' +
                        '</div>'
                      ) : '') +
                      '<div class="space-y-2">' +
                        '<label class="block font-bold text-slate-700 dark:text-slate-300">البريد الإلكتروني أو اسم المستخدم:</label>' +
                        '<input id="inpAuthLoginEmail" type="text" dir="ltr" autocomplete="username" placeholder="البريد أو اسم المستخدم (مثال: sara.teacher@edutech.ps)..." class="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 font-bold"/>' +
                      '</div>' +
                      '<div class="space-y-2">' +
                        '<div class="flex items-center justify-between">' +
                          '<label class="font-bold text-slate-700 dark:text-slate-300">كلمة المرور (أو رمز الإدارة PIN):</label>' +
                          '<button type="button" id="btnAuthForgotPass" class="text-[11px] font-black text-sky-600 dark:text-sky-400 hover:underline">نسيت كلمة المرور؟ استعادة فورية</button>' +
                        '</div>' +
                        '<div class="relative flex items-center">' +
                          '<input id="inpAuthLoginPass" type="password" autocomplete="current-password" placeholder="كلمة المرور (للحسابات التجريبية: 123456)..." class="w-full px-3.5 py-2.5 pl-10 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 font-bold"/>' +
                          '<button type="button" id="btnToggleLoginPassVis" class="absolute left-3 text-slate-400 hover:text-sky-500 font-black" title="إظهار / إخفاء كلمة المرور">👁️</button>' +
                        '</div>' +
                      '</div>' +
                      '<button type="button" id="btnAuthSubmitLogin" class="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-black shadow-lg">🔑 دخول إلى المنصة</button>' +
                      '<div id="authPassRecoveryBox" class="hidden p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2">' +
                        '<div class="font-black text-amber-800 dark:text-amber-300">🛠️ استعادة الحساب وتعيين كلمة مرور جديدة:</div>' +
                        '<p class="text-[11px] text-slate-600 dark:text-slate-300">أدخل بريدك الإلكتروني أعلاه، ثم اكتب كلمة المرور الجديدة وكود التفعيل أو اسم مدرستك المسجل:</p>' +
                        '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2">' +
                          '<input id="inpRecoverSchoolOrCode" type="text" placeholder="اسم المدرسة المسجل أو كود تفعيل مثل VIP-TEACHER-2026..." class="px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-bold"/>' +
                          '<input id="inpRecoverNewPass" type="password" placeholder="كلمة المرور الجديدة (4 أحرف فأكثر)..." class="px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-bold"/>' +
                        '</div>' +
                        '<button type="button" id="btnConfirmRecoverPass" class="w-full py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black">✅ تحديث كلمة المرور والدخول فوراً</button>' +
                      '</div>' +
                      '<div class="pt-2 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">' +
                        '<span class="text-slate-500">ليس لديك حساب؟ اضغط «📝 إنشاء حساب جديد» أو «⚡ دخول سريع تجريبي»</span>' +
                      '</div>' +
                    '</div>'
                  ))) +
                '</div>'
              )) +
            '</div>'
          ) : "") +

          // =========================================================================
          // التبويب 7: لوحة الإدارة والتحكم الموسّعة (مع نظام منح وحجب الأدوات المخصص)
          // =========================================================================
          (state.topNav === "admin" ? (
            '<div id="orgAdminSectionBox" class="p-5 sm:p-6 space-y-5 bg-slate-950 text-white">' +
              (!state.isAdminUnlocked ? (
                '<div class="max-w-md mx-auto p-6 rounded-3xl bg-slate-900 border-2 border-amber-500/40 text-center space-y-4 my-4 shadow-2xl">' +
                  '<div class="text-4xl">🔐</div>' +
                  '<h3 class="text-base sm:text-lg font-black text-white">بوابة الإدارة العليا والتحكم بالصلاحيات</h3>' +
                  '<p class="text-xs text-slate-400 leading-relaxed">هذه المنطقة مخصّصة لإدارة المنصة (الأستاذ باسل أشرف الفقعاوي)، ومنح أو حجب الأدوات عن الأعضاء، وتحرير المناهج والمصادر.</p>' +
                  '<div class="relative flex items-center">' +
                    '<input id="inpOrgAdminPinEntry" type="password" inputmode="numeric" autocomplete="off" dir="ltr" placeholder="أدخل رمز الحماية السيادي (PIN)..." class="w-full px-3.5 py-3 pl-10 rounded-xl bg-slate-950 border-2 border-slate-700 focus:border-amber-400 text-center text-white text-sm font-black tracking-widest outline-none"/>' +
                    '<button type="button" id="btnToggleAdminPinVis" class="absolute left-3 text-slate-400 hover:text-amber-300 text-xs font-black" title="إظهار / إخفاء الرمز">👁️</button>' +
                  '</div>' +
                  '<button type="button" id="btnOrgUnlockAdmin" class="w-full py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow-lg transition">🔓 فتح لوحة الإدارة والتحكم</button>' +
                  (window.Cloud && window.Cloud.enabled ? (
                    '<div class="pt-2 border-t border-slate-800">' +
                      '<button type="button" id="btnOrgAdminGoogleSignIn" class="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 text-xs font-black flex items-center justify-center gap-2"><span>🌐</span><span>أو سجل دخولك بحساب Google الخاص بالإدارة</span></button>' +
                    '</div>'
                  ) : '') +
                '</div>'
              ) : (
                '<div class="space-y-5">' +
                  '<div class="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">' +
                    '<div class="flex items-center gap-2">' +
                      '<span class="px-3 py-1 rounded-full bg-rose-600 text-white text-xs font-black">👑 لوحة الإدارة والتحكم الشاملة</span>' +
                      '<span class="text-xs text-slate-400">إدارة الأستاذ باسل أشرف الفقعاوي — تحكم كامل بصلاحيات الأعضاء والأدوات والمناهج</span>' +
                    '</div>' +
                    '<div class="flex items-center gap-2 flex-wrap">' +
                      '<button type="button" id="btnAdmPushCloudNow" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow">☁️ مزامنة الصلاحيات للسحابة الآن</button>' +
                                          '<button type="button" id="btnOrgLockAdmin" class="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-300 text-xs font-black">🔒 قفل الإدارة والعودة للعام</button>' +
                    '</div>' +
                  '</div>' +

                  // التبويبات الـ 7 للقيادة السيادية للإدارة العليا
                  '<div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">' +
                    '<button type="button" data-org-admintab="permissions_mgr" class="p-3 rounded-2xl text-right border transition ' + (state.adminTab === "permissions_mgr" ? "bg-rose-600 text-white border-rose-400 font-black shadow-lg" : "bg-slate-900 text-slate-300 border-slate-800 hover:border-rose-500/40") + '"><div class="text-xs font-black">🛡️ 1. صلاحيات الأعضاء</div><div class="text-[10px] opacity-80">منح وحجب مخصص وفئات</div></button>' +
                    '<button type="button" data-org-admintab="sovereign_ctrl" class="p-3 rounded-2xl text-right border transition ' + (state.adminTab === "sovereign_ctrl" ? "bg-amber-500 text-slate-950 border-amber-300 font-black shadow-lg" : "bg-slate-900 text-amber-300 border-amber-500/40 hover:border-amber-400") + '"><div class="text-xs font-black">⚡ 2. القواطع السيادية</div><div class="text-[10px] opacity-80">سيطرة شاملة وحماية وخطوط</div></button>' +
                    '<button type="button" data-org-admintab="hierarchy_mgr" class="p-3 rounded-2xl text-right border transition ' + (state.adminTab === "hierarchy_mgr" ? "bg-rose-600 text-white border-rose-400 font-black shadow-lg" : "bg-slate-900 text-slate-300 border-slate-800 hover:border-rose-500/40") + '"><div class="text-xs font-black">🏫 3. محرر المناهج</div><div class="text-[10px] opacity-80">تعديل المواد والروابط</div></button>' +
                    '<button type="button" data-org-admintab="sources_brain" class="p-3 rounded-2xl text-right border transition ' + (state.adminTab === "sources_brain" ? "bg-rose-600 text-white border-rose-400 font-black shadow-lg" : "bg-slate-900 text-slate-300 border-slate-800 hover:border-rose-500/40") + '"><div class="text-xs font-black">🗄️ 4. مصادري (500MB)</div><div class="text-[10px] opacity-80">تغذية الـ Markdown وDrive</div></button>' +
                    '<button type="button" data-org-admintab="admin_studios" class="p-3 rounded-2xl text-right border transition ' + (state.adminTab === "admin_studios" ? "bg-rose-600 text-white border-rose-400 font-black shadow-lg" : "bg-slate-900 text-slate-300 border-slate-800 hover:border-rose-500/40") + '"><div class="text-xs font-black">🛠️ 5. استوديوهات الإنتاج</div><div class="text-[10px] opacity-80">تشغيل مباشر وحزمة الحصة</div></button>' +
                    '<button type="button" data-org-admintab="announce_security" class="p-3 rounded-2xl text-right border transition ' + (state.adminTab === "announce_security" ? "bg-rose-600 text-white border-rose-400 font-black shadow-lg" : "bg-slate-900 text-slate-300 border-slate-800 hover:border-rose-500/40") + '"><div class="text-xs font-black">📢 6. التعميم ورمز PIN</div><div class="text-[10px] opacity-80">شريط الإعلان والحماية</div></button>' +
                    '<button type="button" data-org-admintab="site_settings" class="p-3 rounded-2xl text-right border transition ' + (state.adminTab === "site_settings" ? "bg-rose-600 text-white border-rose-400 font-black shadow-lg" : "bg-slate-900 text-slate-300 border-slate-800 hover:border-rose-500/40") + '"><div class="text-xs font-black">⚙️ 7. النسخ الاحتياطي</div><div class="text-[10px] opacity-80">تصدير/استيراد وإحصاءات</div></button>' +
                  '</div>' +

                  // تبويب القواطع السيادية والسيطرة الشاملة للإدارة العليا
                  (state.adminTab === "sovereign_ctrl" ? (
                    '<div class="p-5 rounded-3xl bg-slate-900 border-2 border-amber-500/50 space-y-5 text-xs">' +
                      '<div class="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">' +
                        '<div>' +
                          '<h4 class="text-sm sm:text-base font-black text-amber-300">⚡ غرفة القواطع السيادية والسيطرة المركزية على الموقع بالكامل</h4>' +
                          '<p class="text-slate-400 mt-0.5">تحكم فوري وحاسم بجميع مفاصل الموقع، سياسة التسجيل، حماية الأدوات، حلقات التعاون الذكي، وتنسيق الخطوط العام</p>' +
                        '</div>' +
                        '<span class="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-black">🔒 مخفي كلياً عن الجمهور</span>' +
                      '</div>' +

                      '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">' +
                        [
                          { key: "requireLoginForTools", title: "🔒 إقفال الأدوات أمام غير المسجلين", desc: "اشتراط تسجيل الدخول الإلزامي قبل تشغيل أي أداة من الـ 38 أداة" },
                          { key: "hideBlockedToolsCompletely", title: "👁️ إخفاء الأدوات المحجوبة كلياً", desc: "إخفاء بطاقات الأدوات غير المسموحة عن عين الزائر أو العضو تماماً" },
                          { key: "collabEnabled", title: "🤝 تفعيل حلقات التعاون الذكي", desc: "السماح للمعلمين والطلبة بنشر واستخدام حلقات التعاون التشاركية" },
                          { key: "publicLibrary", title: "📖 إتاحة المكتبة الشاملة للجمهور", desc: "إظهار أو حجب تبويب المكتبة الشاملة عن غير الإدارة" },
                          { key: "publicUniversity", title: "🎓 إتاحة بوابة الجامعة والـ CV للجمهور", desc: "إظهار أو حجب تبويب المرحلة الجامعية والسيرة الذاتية" },
                          { key: "maintenanceMode", title: "🛡️ وضع الصيانة والإغلاق المؤقت للجمهور", desc: "قفل واجهة الجمهور برسالة صيانة رسمية مع بقاء الموقع مفتوحاً للإدارة" }
                        ].map(function (sw) {
                          var isOn = sw.key === "collabEnabled" ? (adminPerms.collabEnabled !== false) : !!adminPerms[sw.key];
                          return '<div class="p-4 rounded-2xl bg-slate-950 border ' + (isOn ? "border-emerald-500/50" : "border-slate-800") + ' flex flex-col justify-between gap-3">' +
                            '<div>' +
                              '<div class="font-black text-white text-xs sm:text-sm">' + sw.title + '</div>' +
                              '<p class="text-[11px] text-slate-400 mt-1 leading-relaxed">' + sw.desc + '</p>' +
                            '</div>' +
                            '<button type="button" data-adm-toggleperm="' + sw.key + '" class="w-full py-2 rounded-xl font-black transition ' + (isOn ? "bg-emerald-500 text-slate-950 shadow" : "bg-slate-800 text-slate-300 hover:bg-slate-700") + '">' +
                              (isOn ? "✅ مفعّل الآن — اضغط لإيقافه" : "⚪ معطّل الآن — اضغط لتفعيله") +
                            '</button>' +
                          '</div>';
                        }).join("") +
                      '</div>' +

                      '<div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-slate-800">' +
                        '<div class="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5">' +
                          '<div class="font-black text-sky-300">🔐 سياسة قبول تسجيل الأعضاء الجدد في الموقع:</div>' +
                          '<select id="selAdmRegPolicy" class="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-black">' +
                            '<option value="open"' + (adminPerms.registrationMode === "open" ? " selected" : "") + '>🟢 التسجيل مفتوح للجميع (مع منح صلاحيات الفئة افتراضياً)</option>' +
                            '<option value="code_only"' + (adminPerms.registrationMode === "code_only" ? " selected" : "") + '>🎟️ اشتراط كود دعوة/تفعيل من الإدارة عند التسجيل</option>' +
                            '<option value="closed"' + (adminPerms.registrationMode === "closed" ? " selected" : "") + '>🚫 إيقاف التسجيل الذاتي (الإدارة فقط تضيف الأعضاء)</option>' +
                          '</select>' +
                        '</div>' +
                        '<div class="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5">' +
                          '<div class="font-black text-amber-300">⚡ أوامر السيطرة الشاملة الفورية على جميع الأعضاء:</div>' +
                          '<div class="flex flex-wrap gap-2">' +
                            '<button type="button" id="btnAdmSovereignGrantAll" class="flex-1 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow">🌟 منح VIP لكل الأعضاء المسجلين</button>' +
                            '<button type="button" id="btnAdmSovereignResetAll" class="flex-1 py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black shadow">🔄 إرجاع كل الأعضاء لضوابط فئاتهم</button>' +
                          '</div>' +
                        '</div>' +
                      '</div>' +

                      '<div class="p-4 rounded-2xl bg-gradient-to-l from-emerald-950/60 via-slate-950 to-indigo-950/60 border border-emerald-500/40 space-y-3">' +
                        '<div class="flex flex-wrap items-center justify-between gap-2">' +
                          '<div class="font-black text-emerald-300 text-sm">🛡️ درع الحماية والأمان ومحرك الإصلاح الذاتي (Security & Self-Healing Shield v138)</div>' +
                          '<span class="px-2.5 py-0.5 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-black">محصّن بالكامل ✓</span>' +
                        '</div>' +
                        '<div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">' +
                          '<div class="p-2.5 rounded-xl bg-slate-900/90 border border-emerald-500/30"><div class="text-emerald-400 font-black">🔐 تشفير الحسابات</div><div class="text-slate-300 mt-0.5">SHA-256 مملّح + حماية تخمين</div></div>' +
                          '<div class="p-2.5 rounded-xl bg-slate-900/90 border border-sky-500/30"><div class="text-sky-400 font-black">🛠️ المصلح الذاتي</div><div class="text-slate-300 mt-0.5">فحص وإصلاح تلقائي للذاكرة</div></div>' +
                          '<div class="p-2.5 rounded-xl bg-slate-900/90 border border-amber-500/30"><div class="text-amber-400 font-black">☁️ قواعد Firestore</div><div class="text-slate-300 mt-0.5">تطابق بريد غير حساس للأحرف</div></div>' +
                          '<div class="p-2.5 rounded-xl bg-slate-900/90 border border-purple-500/30"><div class="text-purple-400 font-black">⚡ الأخطاء المسجلة</div><div class="text-slate-300 mt-0.5">' + ((window.EduDiag && window.EduDiag.report) ? (window.EduDiag.report().errors || []).length : 0) + ' أخطاء برمجية</div></div>' +
                        '</div>' +
                        '<div class="flex flex-wrap gap-2 pt-1">' +
                          '<button type="button" id="btnAdmRunSelfHealNow" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow">🛠️ فحص وإصلاح الذاكرة وتصفير الأخطاء الآن</button>' +
                          '<button type="button" id="btnAdmPurgeSwCacheNow" class="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-black shadow">🔄 تحديث الكاش والملفات لجميع الزوار</button>' +
                        '</div>' +
                      '</div>' +
                    '</div>'
                  ) : "") +

                  // =====================================================================
                  // تبويب الإدارة 1: منظومة الصلاحيات المتكاملة (منح وحجب الأدوات لمن تشاء)
                  // =====================================================================
                  (state.adminTab === "permissions_mgr" ? (function () {
                    var selUser = registeredUsers.filter(function (u) { return u.email === state.selectedAdminUserEmail; })[0] || registeredUsers[0] || null;
                    if (selUser && state.selectedAdminUserEmail !== selUser.email) state.selectedAdminUserEmail = selUser.email;
                    var selUserRec = selUser ? getUserPermRecord(selUser.email) : { mode: "custom", grantedTools: [], blockedTools: [], note: "" };
                    var selUserAllowedCount = selUser ? MASTER_TOOLS_CATALOG.filter(function (t) { return evaluateToolAccessForUser(t.id, selUser, true).allowed; }).length : 0;

                    return '<div class="p-4 sm:p-5 rounded-3xl bg-slate-900 border-2 border-emerald-500/40 space-y-5 text-xs">' +
                      // شريط التبديل بين: (1) تخصيص عضو بعينه، (2) سياسة الفئات والزوار، (3) طلبات الأعضاء
                      '<div class="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">' +
                        '<div class="flex flex-wrap gap-2">' +
                          '<button type="button" data-adm-permmode="user_specific" class="px-4 py-2.5 rounded-xl font-black transition ' + (state.adminPermSubMode === "user_specific" ? "bg-emerald-500 text-slate-950 shadow-lg" : "bg-slate-950 text-slate-300 border border-slate-800") + '">👤 1. تخصيص صلاحيات عضو معيّن (منح / حجب أدوات لأي شخص)</button>' +
                          '<button type="button" data-adm-permmode="role_defaults" class="px-4 py-2.5 rounded-xl font-black transition ' + (state.adminPermSubMode === "role_defaults" ? "bg-sky-500 text-slate-950 shadow-lg" : "bg-slate-950 text-slate-300 border border-slate-800") + '">👥 2. صلاحيات الفئات والزوار الافتراضية</button>' +
                          '<button type="button" data-adm-permmode="access_requests" class="px-4 py-2.5 rounded-xl font-black transition ' + (state.adminPermSubMode === "access_requests" ? "bg-amber-400 text-slate-950 shadow-lg" : "bg-slate-950 text-slate-300 border border-slate-800") + '">📩 3. طلبات الوصول للأدوات (' + pendingReqCount + ' طلب جديد)</button>' +
                          '<button type="button" data-adm-permmode="codes_audit" class="px-4 py-2.5 rounded-xl font-black transition ' + (state.adminPermSubMode === "codes_audit" ? "bg-purple-500 text-white shadow-lg" : "bg-slate-950 text-slate-300 border border-slate-800") + '">🎟️ 4. أكواد التفعيل وسجل الرقابة</button>' +
                        '</div>' +
                      '</div>' +

                      // الوضع أ: تخصيص صلاحيات عضو بعينه
                      (state.adminPermSubMode === "user_specific" ? (
                        '<div class="space-y-5">' +
                          // نموذج إضافة عضو جديد مباشرة من الإدارة وتحديد صلاحياته
                          '<div class="p-4 rounded-2xl bg-slate-950 border border-indigo-500/40 space-y-3">' +
                            '<div class="font-black text-indigo-300">➕ إضافة / تسجيل عضو جديد من قِبل الإدارة ومنحه صلاحياته فوراً:</div>' +
                            '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2">' +
                              '<input id="inpAdmCreateUserName" type="text" placeholder="اسم العضو الجديد..." class="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white font-bold"/>' +
                              '<input id="inpAdmCreateUserEmail" type="email" dir="ltr" placeholder="user@edutech.ps البريد..." class="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sky-200 font-mono"/>' +
                              '<input id="inpAdmCreateUserPass" type="text" value="123456" placeholder="كلمة المرور..." class="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-amber-200 font-mono"/>' +
                              '<select id="selAdmCreateUserRole" class="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white font-black">' +
                                '<option value="معلم">🧑‍🏫 معلم</option>' +
                                '<option value="طالب">🎓 طالب</option>' +
                                '<option value="توجيهي">🏅 توجيهي</option>' +
                                '<option value="جامعي">🏛️ جامعي</option>' +
                                '<option value="ولي أمر">👪 ولي أمر</option>' +
                              '</select>' +
                              '<select id="selAdmCreateUserMode" class="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-emerald-300 font-black">' +
                                '<option value="custom">🎯 صلاحيات مخصصة</option>' +
                                '<option value="vip_all">🌟 وصول شامل لكل الأدوات (VIP)</option>' +
                                '<option value="suspended">🚫 حساب موقوف</option>' +
                              '</select>' +
                              '<button type="button" id="btnAdmCreateUserNow" class="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black shadow">➕ إضافة العضو وفتح صلاحياته</button>' +
                            '</div>' +
                          '</div>' +

                          // اختيار العضو المراد تعديل صلاحياته
                          '<div class="space-y-2.5">' +
                            '<div class="flex flex-wrap items-center justify-between gap-2">' +
                              '<span class="font-black text-emerald-300 text-sm">1️⃣ اختر العضو للتحكم الكامل بالأدوات المسموحة أو المحجوبة عنه (' + registeredUsers.length + ' عضو مسجل):</span>' +
                              '<input id="inpAdmUserSearch" type="search" value="' + esc(state.adminUserSearch) + '" placeholder="🔍 ابحث بالاسم أو البريد أو الفئة..." class="w-64 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-bold"/>' +
                            '</div>' +
                            '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-60 overflow-y-auto pr-1">' +
                              registeredUsers.filter(function (u) {
                                var q = (state.adminUserSearch || "").trim().toLowerCase();
                                if (!q) return true;
                                return (u.name + " " + u.email + " " + (u.roleLabel || "")).toLowerCase().indexOf(q) !== -1;
                              }).map(function (u, uIdx) {
                                var isSel = selUser && selUser.email === u.email;
                                var uRec = getUserPermRecord(u.email);
                                var uAllowCnt = MASTER_TOOLS_CATALOG.filter(function (t) { return evaluateToolAccessForUser(t.id, u, true).allowed; }).length;
                                var modeBadge = uRec.mode === "vip_all"
                                  ? '<span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-black">🌟 وصول كامل</span>'
                                  : (uRec.mode === "suspended"
                                    ? '<span class="px-2 py-0.5 rounded bg-rose-600 text-white text-[10px] font-black">🚫 موقوف</span>'
                                    : '<span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-black">🔓 ' + uAllowCnt + '/' + MASTER_TOOLS_CATALOG.length + ' أداة</span>');
                                return '<div class="p-3 rounded-2xl border-2 transition flex flex-col justify-between gap-2 cursor-pointer ' +
                                  (isSel ? "bg-emerald-950/60 border-emerald-400 shadow-lg" : "bg-slate-950 border-slate-800 hover:border-slate-600") + '" data-adm-pickuser="' + esc(u.email) + '">' +
                                  '<div class="flex items-start justify-between gap-2">' +
                                    '<div class="min-w-0">' +
                                      '<div class="font-black text-white truncate">' + (isSel ? "👉 " : "👤 ") + esc(u.name) + '</div>' +
                                      '<div class="text-[10px] text-slate-400 font-mono truncate" dir="ltr">' + esc(u.email) + '</div>' +
                                    '</div>' +
                                    modeBadge +
                                  '</div>' +
                                  '<div class="flex items-center justify-between text-[10px] pt-1.5 border-t border-slate-800/80">' +
                                    '<span class="text-sky-300 font-bold">' + esc(u.roleLabel || "طالب") + ' • ممنوح خاص: +' + uRec.grantedTools.length + ' • محجوب خاص: -' + uRec.blockedTools.length + '</span>' +
                                    '<button type="button" data-adm-deluser="' + esc(u.email) + '" class="px-2 py-0.5 rounded bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white font-black" title="حذف العضو">🗑️</button>' +
                                  '</div>' +
                                '</div>';
                              }).join("") +
                            '</div>' +
                          '</div>' +

                          // لوحة تحكم الأدوات الخاصة بالعضو المختار
                          (selUser ? (
                            '<div class="p-4 sm:p-5 rounded-3xl bg-slate-950 border-2 border-amber-500/50 space-y-4">' +
                              '<div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-slate-800">' +
                                '<div>' +
                                  '<div class="flex flex-wrap items-center gap-2">' +
                                    '<span class="text-sm sm:text-base font-black text-amber-300">🎯 التحكم بصلاحيات العضو المختار: «' + esc(selUser.name) + '»</span>' +
                                    '<span class="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-black">الأدوات المسموحة له الآن: ' + selUserAllowedCount + ' من ' + MASTER_TOOLS_CATALOG.length + '</span>' +
                                  '</div>' +
                                  '<div class="text-[11px] text-slate-400 mt-1">البريد: <span class="font-mono text-sky-300" dir="ltr">' + esc(selUser.email) + '</span> • الفئة الحالية: <strong class="text-white">' + esc(selUser.roleLabel) + '</strong> • يمكنك منح أو حجب أي أداة عنه بنقرة واحدة أدناه:</div>' +
                                '</div>' +
                                '<div class="flex flex-wrap items-center gap-2">' +
                                  '<select id="selAdmUserRoleChange" class="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-black">' +
                                    ["طالب", "توجيهي", "جامعي", "معلم", "ولي أمر"].map(function (rk) {
                                      return '<option value="' + rk + '"' + (selUser.roleLabel === rk ? " selected" : "") + '>تغيير الفئة: ' + rk + '</option>';
                                    }).join("") +
                                  '</select>' +
                                  '<button type="button" id="btnAdmImpersonateUser" class="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black shadow">👁️ معاينة الموقع كأنك هذا العضو</button>' +
                                '</div>' +
                              '</div>' +

                              // أزرار الحزم السريعة للعضو المختار
                              '<div class="flex flex-wrap items-center gap-2">' +
                                '<span class="font-black text-slate-300 ml-1">⚡ إجراءات فورية لهذا العضو:</span>' +
                                '<button type="button" data-adm-userpack="vip_all" class="px-3 py-1.5 rounded-xl font-black transition ' + (selUserRec.mode === "vip_all" ? "bg-amber-400 text-slate-950 shadow" : "bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500 hover:text-slate-950") + '">🌟 منح كل الأدوات (VIP شامل)</button>' +
                                '<button type="button" data-adm-userpack="grant_all_custom" class="px-3 py-1.5 rounded-xl bg-emerald-600/25 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40 font-black transition">✅ تفعيل جميع الـ 38 أداة</button>' +
                                '<button type="button" data-adm-userpack="teacher_pack" class="px-3 py-1.5 rounded-xl bg-sky-600/25 hover:bg-sky-600 text-sky-300 hover:text-white border border-sky-500/40 font-black transition">🧑‍🏫 منح حزمة أدوات المعلم</button>' +
                                '<button type="button" data-adm-userpack="student_pack" class="px-3 py-1.5 rounded-xl bg-indigo-600/25 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/40 font-black transition">🎓 منح حزمة الطالب والتوجيهي</button>' +
                                '<button type="button" data-adm-userpack="reset_default" class="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-black transition">🔄 إرجاع للوضع الافتراضي للفئة</button>' +
                                '<button type="button" data-adm-userpack="block_all_custom" class="px-3 py-1.5 rounded-xl bg-rose-600/25 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/40 font-black transition">🚫 حجب كل الأدوات عنه</button>' +
                                '<button type="button" data-adm-userpack="suspended" class="px-3 py-1.5 rounded-xl font-black transition ' + (selUserRec.mode === "suspended" ? "bg-rose-600 text-white shadow" : "bg-rose-950 text-rose-300 border border-rose-700") + '">⛔ إيقاف الحساب كلياً</button>' +
                              '</div>' +

                              // فلترة أدوات المصفوفة
                              '<div class="grid grid-cols-1 lg:grid-cols-12 gap-2 items-center pt-1">' +
                                '<div class="lg:col-span-8 flex flex-wrap gap-1.5">' +
                                  [
                                    { id: "all", lbl: "الكل (" + MASTER_TOOLS_CATALOG.length + ")" },
                                    { id: "teacher", lbl: "🧑‍🏫 أدوات المعلم" },
                                    { id: "student", lbl: "🎒 أدوات الطالب" },
                                    { id: "labs", lbl: "🧪 المختبرات والألعاب" },
                                    { id: "ai", lbl: "🤖 الذكاء الاصطناعي" },
                                    { id: "university", lbl: "🎓 الجامعة والـ CV" },
                                    { id: "admin_class", lbl: "🧰 الإدارة الصفية والأسرة" }
                                  ].map(function (c) {
                                    var on = state.adminToolFilterCat === c.id;
                                    return '<button type="button" data-adm-toolcat="' + c.id + '" class="px-2.5 py-1.5 rounded-xl text-[11px] font-black ' + (on ? "bg-emerald-500 text-slate-950" : "bg-slate-900 text-slate-300 border border-slate-800") + '">' + c.lbl + '</button>';
                                  }).join("") +
                                '</div>' +
                                '<div class="lg:col-span-4">' +
                                  '<input id="inpAdmToolSearch" type="search" value="' + esc(state.adminToolSearch) + '" placeholder="🔍 ابحث عن أداة لمنحها أو حجبها..." class="w-full px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-bold"/>' +
                                '</div>' +
                              '</div>' +

                              // شبكة جميع الأدوات مع أزرار (منح ✅ | حجب 🚫 | افتراضي 🔄) لهذا العضو
                              '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-[460px] overflow-y-auto pr-1">' +
                                MASTER_TOOLS_CATALOG.filter(function (t) {
                                  if (state.adminToolFilterCat !== "all" && t.cat !== state.adminToolFilterCat) return false;
                                  var q = (state.adminToolSearch || "").trim().toLowerCase();
                                  if (q && (t.title + " " + t.catLabel).toLowerCase().indexOf(q) === -1) return false;
                                  return true;
                                }).map(function (t) {
                                  var isExplicitGrant = selUserRec.grantedTools.indexOf(t.id) !== -1;
                                  var isExplicitBlock = selUserRec.blockedTools.indexOf(t.id) !== -1;
                                  var eff = evaluateToolAccessForUser(t.id, selUser, true);
                                  return '<div class="p-3 rounded-2xl border flex flex-col justify-between gap-2 ' +
                                    (eff.allowed ? "bg-emerald-950/30 border-emerald-500/40" : "bg-rose-950/30 border-rose-500/40") + '">' +
                                    '<div class="flex items-start justify-between gap-2">' +
                                      '<div class="min-w-0">' +
                                        '<div class="font-black text-white truncate">' + t.ico + ' ' + esc(t.title) + '</div>' +
                                        '<div class="text-[10px] text-slate-400">' + esc(t.catLabel) + '</div>' +
                                      '</div>' +
                                      '<span class="px-2 py-0.5 rounded text-[10px] font-black shrink-0 ' + (eff.allowed ? "bg-emerald-500 text-slate-950" : "bg-rose-600 text-white") + '">' + (eff.allowed ? "🟢 مسموح" : "🔴 محجوب") + '</span>' +
                                    '</div>' +
                                    '<div class="grid grid-cols-3 gap-1 pt-1 border-t border-slate-800/80 text-[10px]">' +
                                      '<button type="button" data-adm-setusertool="' + esc(t.id) + ':grant" class="py-1.5 rounded-lg font-black transition ' + (isExplicitGrant ? "bg-emerald-500 text-slate-950 shadow" : "bg-slate-900 text-emerald-300 hover:bg-emerald-600/30 border border-slate-800") + '">✅ منح</button>' +
                                      '<button type="button" data-adm-setusertool="' + esc(t.id) + ':block" class="py-1.5 rounded-lg font-black transition ' + (isExplicitBlock ? "bg-rose-600 text-white shadow" : "bg-slate-900 text-rose-300 hover:bg-rose-600/30 border border-slate-800") + '">🚫 حجب</button>' +
                                      '<button type="button" data-adm-setusertool="' + esc(t.id) + ':default" class="py-1.5 rounded-lg font-black transition ' + (!isExplicitGrant && !isExplicitBlock ? "bg-sky-500 text-slate-950" : "bg-slate-900 text-slate-400 hover:bg-slate-800 border border-slate-800") + '">🔄 افتراضي</button>' +
                                    '</div>' +
                                  '</div>';
                                }).join("") +
                              '</div>' +
                            '</div>'
                          ) : '') +
                        '</div>'
                      ) : '') +

                      // الوضع ب: السياسة الافتراضية للفئات والزوار
                      (state.adminPermSubMode === "role_defaults" ? (
                        '<div class="space-y-4">' +
                          '<div class="font-black text-sky-300">🛡️ أولاً: الضوابط العامة للزوار وخصائص المنصة الأساسية:</div>' +
                          '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">' +
                            [
                              { key: "requireLoginForTools", label: "🔒 اشتراط تسجيل الدخول لفتح الأدوات" },
                              { key: "hideBlockedToolsCompletely", label: "👁️ إخفاء الأدوات المحجوبة كلياً عن غير المخولين" },
                              { key: "publicLibrary", label: "📖 إظهار المكتبة الشاملة للزوار" },
                              { key: "publicUniversity", label: "🎓 إظهار بوابة الجامعة والـ CV للزوار" },
                              { key: "publicOrigPdf", label: "📕 إظهار تبويب النسخة المصوّرة PDF/Drive" },
                              { key: "publicQuiz", label: "✅ إظهار بنك الأسئلة التفاعلي للطلبة" },
                              { key: "publicFlashcards", label: "🃏 إظهار بطاقات الاستذكار القلّابة" },
                              { key: "publicVoice", label: "🔊 تفعيل القراءة الصوتية الآلية" }
                            ].map(function (perm) {
                              var on = !!adminPerms[perm.key];
                              return '<button type="button" data-adm-toggleperm="' + perm.key + '" class="p-3 rounded-xl border text-right font-black flex items-center justify-between ' +
                                (on ? "bg-emerald-600/20 border-emerald-500 text-emerald-200" : "bg-slate-950 border-slate-800 text-slate-400") + '">' +
                                '<span>' + perm.label + '</span><span>' + (on ? "مفعّل ✓" : "معطّل ✕") + '</span>' +
                              '</button>';
                            }).join("") +
                          '</div>' +

                          '<div class="pt-3 border-t border-slate-800 space-y-3">' +
                            '<div class="flex flex-wrap items-center justify-between gap-2">' +
                              '<span class="font-black text-amber-300">👥 ثانياً: تحديد الأدوات المفتوحة أو المحجوبة افتراضياً لكل فئة (دور):</span>' +
                              '<div class="flex gap-1.5">' +
                                '<button type="button" id="btnAdmRoleAllowAll" class="px-3 py-1 rounded-lg bg-emerald-600 text-white font-black">✅ إتاحة الكل لهذه الفئة</button>' +
                                '<button type="button" id="btnAdmRoleBlockAll" class="px-3 py-1 rounded-lg bg-rose-600 text-white font-black">🚫 حجب الكل عن هذه الفئة</button>' +
                              '</div>' +
                            '</div>' +
                            '<div class="flex flex-wrap gap-2">' +
                              ROLE_DEFINITIONS.map(function (r) {
                                var on = state.selectedAdminRoleKey === r.key;
                                return '<button type="button" data-adm-pickrole="' + esc(r.key) + '" class="px-3.5 py-2 rounded-xl font-black transition ' +
                                  (on ? "bg-sky-500 text-slate-950 shadow-md" : "bg-slate-950 text-slate-300 border border-slate-800") + '">' +
                                  r.label +
                                '</button>';
                              }).join("") +
                            '</div>' +
                            '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 max-h-96 overflow-y-auto pr-1">' +
                              MASTER_TOOLS_CATALOG.map(function (t) {
                                var rMap = (adminPerms.rolePolicies && adminPerms.rolePolicies[state.selectedAdminRoleKey]) || {};
                                var isOn = typeof rMap[t.id] === "boolean" ? rMap[t.id] : ((t.defaultRoles || []).indexOf(state.selectedAdminRoleKey) !== -1);
                                return '<button type="button" data-adm-toggleroletool="' + esc(t.id) + '" class="p-3 rounded-xl border text-right font-black flex items-center justify-between transition ' +
                                  (isOn ? "bg-emerald-950/50 border-emerald-500/50 text-emerald-200" : "bg-slate-950 border-slate-800 text-slate-400") + '">' +
                                  '<span class="truncate">' + t.ico + ' ' + esc(t.title) + '</span>' +
                                  '<span class="px-2 py-0.5 rounded text-[10px] shrink-0 ' + (isOn ? "bg-emerald-500 text-slate-950" : "bg-rose-600/30 text-rose-300") + '">' + (isOn ? "مسموح ✓" : "محجوب ✕") + '</span>' +
                                '</button>';
                              }).join("") +
                            '</div>' +
                          '</div>' +
                        '</div>'
                      ) : '') +

                      // الوضع ج: طلبات الصلاحيات الواردة من الأعضاء
                      (state.adminPermSubMode === "access_requests" ? (
                        '<div class="space-y-3">' +
                          '<div class="font-black text-amber-300">📩 طلبات الحصول على صلاحية الوصول للأدوات المرسلة من الأعضاء:</div>' +
                          ((adminPerms.accessRequests && adminPerms.accessRequests.length) ? (
                            '<div class="space-y-2.5">' +
                              adminPerms.accessRequests.map(function (req) {
                                return '<div class="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">' +
                                  '<div class="space-y-1">' +
                                    '<div class="flex flex-wrap items-center gap-2">' +
                                      '<span class="font-black text-white">👤 ' + esc(req.userName) + '</span>' +
                                      '<span class="text-sky-300 font-mono text-[11px]" dir="ltr">(' + esc(req.userEmail) + ')</span>' +
                                      '<span class="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[10px] font-black">' + esc(req.userRole) + '</span>' +
                                      '<span class="text-slate-500 text-[10px]">🕒 ' + esc(req.requestedAt) + '</span>' +
                                    '</div>' +
                                    '<div class="text-amber-300 font-black">🛠️ الأداة المطلوبة: «' + esc(req.toolTitle) + '»</div>' +
                                    '<div class="text-slate-400">💬 ملاحظة العضو: ' + esc(req.note) + '</div>' +
                                  '</div>' +
                                  '<div class="flex flex-wrap items-center gap-2 shrink-0">' +
                                    (req.status === "pending" ? (
                                      '<button type="button" data-adm-reqact="' + esc(req.id) + ':approve" class="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow">✅ موافقة ومنح الأداة</button>' +
                                      '<button type="button" data-adm-reqact="' + esc(req.id) + ':vip" class="px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black">🌟 منح كل الأدوات</button>' +
                                      '<button type="button" data-adm-reqact="' + esc(req.id) + ':reject" class="px-3 py-2 rounded-xl bg-rose-600/30 hover:bg-rose-600 text-rose-300 hover:text-white font-black">❌ رفض</button>'
                                    ) : (
                                      '<span class="px-3 py-1.5 rounded-xl font-black ' + (req.status === "approved" ? "bg-emerald-500/20 text-emerald-300" : "bg-rose-500/20 text-rose-300") + '">' +
                                        (req.status === "approved" ? "✅ تمت الموافقة والتفعيل" : "❌ مرفوض") +
                                      '</span>'
                                    )) +
                                  '</div>' +
                                '</div>';
                              }).join("") +
                            '</div>'
                          ) : '<div class="p-6 text-center text-slate-500">لا توجد طلبات صلاحيات حالياً.</div>') +
                        '</div>'
                      ) : '') +

                      // الوضع د: أكواد التفعيل السريعة وسجل الرقابة الإداري
                      (state.adminPermSubMode === "codes_audit" ? (
                        '<div class="space-y-5">' +
                          '<div class="p-4 rounded-2xl bg-slate-950 border border-purple-500/40 space-y-3">' +
                            '<div class="font-black text-purple-300">🎟️ إنشاء كود تفعيل صلاحيات جديد (يمنح حزمة أدوات أو VIP لأي عضو يدخله):</div>' +
                            '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">' +
                              '<input id="inpAdmNewCodeStr" type="text" dir="ltr" placeholder="EDUTECH-VIP-50" class="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-amber-300 font-mono font-black uppercase"/>' +
                              '<input id="inpAdmNewCodeLbl" type="text" placeholder="وصف الكود (مثال: دفعة معلمي العلوم)..." class="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white font-bold"/>' +
                              '<select id="selAdmNewCodeMode" class="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-emerald-300 font-black">' +
                                '<option value="vip_all">🌟 يمنح كل الـ 50 أداة (VIP)</option>' +
                                '<option value="teacher_pack">🧑‍🏫 يمنح حزمة أدوات المعلم</option>' +
                                '<option value="tawjihi_pack">🎓 يمنح حزمة التوجيهي والمختبرات</option>' +
                                '<option value="uni_pack">🏛️ يمنح حزمة الجامعة والـ CV</option>' +
                              '</select>' +
                              '<input id="inpAdmNewCodeMax" type="number" min="1" max="1000" value="50" placeholder="عدد مرات الاستخدام" class="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white font-bold"/>' +
                              '<button type="button" id="btnAdmCreateCode" class="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-black shadow">➕ توليد وحفظ الكود</button>' +
                            '</div>' +
                            '<div class="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2">' +
                              (adminPerms.activationCodes || []).map(function (c, cIdx) {
                                return '<div class="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">' +
                                  '<div>' +
                                    '<div class="font-mono font-black text-amber-300 text-sm">' + esc(c.code) + '</div>' +
                                    '<div class="text-[11px] text-slate-300 font-bold">' + esc(c.label) + '</div>' +
                                    '<div class="text-[10px] text-slate-400">الاستخدام: ' + (c.usedCount || 0) + ' / ' + (c.maxUses || 50) + ' • الصلاحية: ' + (c.expiresDays || 365) + ' يوم</div>' +
                                  '</div>' +
                                  '<button type="button" data-adm-delcode="' + cIdx + '" class="px-2.5 py-1 rounded-lg bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white font-black">🗑️</button>' +
                                '</div>';
                              }).join("") +
                            '</div>' +
                          '</div>' +

                          '<div class="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5">' +
                            '<div class="font-black text-sky-300">📋 سجل الرقابة الإدارية وحركات منح وحجب الصلاحيات (Audit Log):</div>' +
                            '<div class="space-y-1.5 max-h-56 overflow-y-auto pr-1">' +
                              (adminPerms.permissionAuditLog || []).map(function (lg) {
                                return '<div class="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[11px]">' +
                                  '<span class="font-bold text-white">🛡️ ' + esc(lg.action) + '</span>' +
                                  '<span class="text-slate-400 font-mono">' + esc(lg.actor) + ' • ' + esc(lg.time) + '</span>' +
                                '</div>';
                              }).join("") +
                            '</div>' +
                          '</div>' +
                        '</div>'
                      ) : '') +
                    '</div>';
                  })() : "") +

                  // تبويب الإدارة 2: محرر المناهج الشامل
                  (state.adminTab === "hierarchy_mgr" ? (
                    '<div class="p-4 rounded-2xl bg-slate-900 border border-sky-500/30 space-y-4 text-xs">' +
                      '<div class="flex flex-wrap items-center justify-between gap-2">' +
                        '<div class="font-black text-sky-300">🏫 تحرير المادة المختارة حالياً: «' + esc(M.name + " — " + G.name) + '»</div>' +
                        '<button type="button" id="btnAdmResetOfficialTree" class="px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-400/50 text-amber-300 font-black">🔄 استعادة المنهاج الفلسطيني الرسمي</button>' +
                      '</div>' +
                      '<div class="grid grid-cols-1 md:grid-cols-2 gap-2">' +
                        '<input id="inpAdmSubTitle" type="text" value="' + esc(M.bookTitle || M.name) + '" placeholder="عنوان الكتاب الرسمي..." class="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-bold"/>' +
                        '<input id="inpAdmOfficialUrl" type="text" dir="ltr" value="' + esc(M.officialUrl || "") + '" placeholder="https://elearn.edu.ps/... رابط بوابة الوزارة الرسمي" class="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-emerald-300 font-mono"/>' +
                        '<input id="inpAdmDriveLink" type="text" dir="ltr" value="' + esc(M.driveUrl || "") + '" placeholder="https://drive.google.com/file/d/... رابط كتاب Google Drive" class="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sky-200 font-mono"/>' +
                        '<input id="inpAdmTotalPages" type="number" min="20" max="600" value="' + esc(M.totalPages || 120) + '" placeholder="عدد الصفحات" class="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-amber-200 font-bold"/>' +
                      '</div>' +
                      '<div class="grid grid-cols-1 md:grid-cols-3 gap-2">' +
                        '<input id="inpAdmNewUnit" type="text" placeholder="عنوان وحدة أو فصل جديد لإضافته للمادة..." class="md:col-span-2 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-bold"/>' +
                        '<button type="button" id="btnAdmSaveSubUpdate" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black">💾 حفظ التعديلات وإضافة الوحدة</button>' +
                      '</div>' +
                      '<div class="space-y-1.5">' +
                        '<div class="font-bold text-slate-400">وحدات المادة الحالية (اضغط 🗑️ لحذف وحدة):</div>' +
                        '<div class="flex flex-wrap gap-1.5">' +
                          (M.units || []).map(function (u, idx) {
                            return '<span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-[11px]">' +
                              '<span>' + esc(u) + '</span>' +
                              '<button type="button" data-adm-delunit="' + idx + '" class="text-rose-400 hover:text-rose-300 font-black">🗑️</button>' +
                            '</span>';
                          }).join("") +
                        '</div>' +
                      '</div>' +
                      '<div class="pt-3 border-t border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-2">' +
                        '<input id="inpAdmNewRule" type="text" placeholder="📌 إضافة قاعدة محورية جديدة لهذه المادة..." class="md:col-span-2 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-bold"/>' +
                        '<button type="button" id="btnAdmAddRule" class="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-black">➕ إضافة قاعدة للمادة</button>' +
                      '</div>' +
                      '<div class="pt-3 border-t border-slate-800 grid grid-cols-1 md:grid-cols-4 gap-2">' +
                        '<input id="inpAdmAddSubName" type="text" placeholder="➕ إضافة مبحث جديد لهذا الصف..." class="md:col-span-2 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-bold"/>' +
                        '<button type="button" id="btnAdmAddNewSubject" class="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black">➕ إضافة مادة</button>' +
                        '<button type="button" id="btnAdmDeleteCurSubject" class="px-4 py-2 rounded-xl bg-rose-700 hover:bg-rose-600 text-white font-black">🗑️ حذف المادة الحالية</button>' +
                      '</div>' +
                    '</div>'
                  ) : "") +

                  // تبويب الإدارة 3: مصادري والقاعدة البرمجية الخفية
                  (state.adminTab === "sources_brain" ? (
                    '<div class="p-4 rounded-2xl bg-slate-900 border border-rose-500/30 space-y-3 text-xs">' +
                      '<div class="flex flex-wrap items-center justify-between gap-2">' +
                        '<div class="font-black text-rose-300">🧠 فاحص القاعدة البرمجية الخفية (Offline Markdown SmartBrain) + استوديو مصادري</div>' +
                        '<span class="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 font-black">⚡ مفتوح بالأسفل مباشرة ⬇</span>' +
                      '</div>' +
                      '<p class="text-slate-400">كل ما ترفعه من ملفات Markdown في استوديو «مصادري» المعروض أسفل هذه اللوحة يُفهرس محلياً لتسريع الإجابة ورفع دقتها دون إظهاره للزوار العامين.</p>' +
                    '</div>'
                  ) : "") +

                  // تبويب الإدارة 4: استوديوهات الإنتاج الإداري والمعلم
                  (state.adminTab === "admin_studios" ? (
                    '<div class="p-4 rounded-2xl bg-slate-900 border border-purple-500/30 space-y-3 text-xs">' +
                      '<div class="font-black text-purple-300">🛠️ تشغيل استوديوهات الإنتاج الإداري مباشرة (أو توليد حزمة الحصة الفورية):</div>' +
                      '<div class="grid grid-cols-2 sm:grid-cols-4 gap-2">' +
                        MASTER_TOOLS_CATALOG.slice(0, 16).map(function (st) {
                          var active = state.openedAdminStudioId === st.id;
                          return '<button type="button" data-adm-openstudio="' + esc(st.id) + '" class="p-3 rounded-xl border text-right font-black transition ' +
                            (active ? "bg-purple-600 text-white border-purple-400" : "bg-slate-950 border-slate-800 text-slate-200 hover:border-purple-400") + '">' +
                            st.ico + ' ' + esc(st.title) + '</button>';
                        }).join("") +
                      '</div>' +
                      '<div class="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">' +
                        '<span class="font-bold text-slate-300">⚡ توليد حزمة الحصة المتكاملة (خطة + ورقة عمل + اختبار) للوحدة الحالية:</span>' +
                        '<button type="button" id="btnAdmGenLessonPack" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black">🖨️ جهّز حزمة الحصة A4</button>' +
                      '</div>' +
                    '</div>'
                  ) : "") +

                  // تبويب الإدارة 5: الإعلانات وحماية الإدارة PIN
                  (state.adminTab === "announce_security" ? (
                    '<div class="p-4 rounded-2xl bg-slate-900 border border-amber-500/30 space-y-4 text-xs">' +
                      '<div class="font-black text-amber-300">📢 التحكم بشريط الإعلان الإداري أعلى المنصة ورمز الحماية (PIN):</div>' +
                      '<div class="grid grid-cols-1 md:grid-cols-3 gap-2">' +
                        '<input id="inpAdmAnnounceText" type="text" value="' + esc(adminPerms.announcementText || "") + '" placeholder="نص الإعلان والتعميم الإداري..." class="md:col-span-2 px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-bold"/>' +
                        '<button type="button" id="btnAdmSaveAnnounce" class="px-4 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-black">' + (adminPerms.announcementActive ? "🔕 إيقاف / تحديث الإعلان" : "📢 تفعيل الإعلان للجميع") + '</button>' +
                      '</div>' +
                      '<div class="pt-3 border-t border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-2">' +
                        '<input id="inpAdmSetPin" type="password" value="' + esc(adminPerms.adminPin || "") + '" placeholder="تعيين رمز حماية لوحة الإدارة (PIN - اتركه فارغاً لإلغاء الرمز)..." class="md:col-span-2 px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-bold"/>' +
                        '<button type="button" id="btnAdmSavePin" class="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black">🔐 حفظ رمز الحماية (PIN)</button>' +
                      '</div>' +
                    '</div>'
                  ) : "") +

                  // تبويب الإدارة 6: النسخ الاحتياطي والإحصاءات
                  (state.adminTab === "site_settings" ? (
                    '<div class="p-4 rounded-2xl bg-slate-900 border border-amber-500/30 space-y-4 text-xs">' +
                      '<div class="grid grid-cols-2 sm:grid-cols-4 gap-2">' +
                        '<div class="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center"><div class="text-lg font-black text-sky-400">' + masterTree.length + '</div><div class="text-[10px] text-slate-400">مراحل تعليمية</div></div>' +
                        '<div class="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center"><div class="text-lg font-black text-emerald-400">' + allFlatSubs.length + '</div><div class="text-[10px] text-slate-400">كتاب ومبحث منهجي</div></div>' +
                        '<div class="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center"><div class="text-lg font-black text-amber-400">' + MASTER_TOOLS_CATALOG.length + '</div><div class="text-[10px] text-slate-400">أداة ومختبر ذكي</div></div>' +
                        '<div class="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center"><div class="text-lg font-black text-purple-400">' + registeredUsers.length + '</div><div class="text-[10px] text-slate-400">أعضاء مسجلون</div></div>' +
                      '</div>' +
                      '<div class="font-black text-amber-300">⚙️ النسخ الاحتياطي الشامل (المناهج + الأعضاء + مصفوفة الصلاحيات + الهوامش):</div>' +
                      '<div class="flex flex-wrap gap-2">' +
                        '<button type="button" id="btnAdmExportBackup" class="px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-black">⬇️ تصدير نسخة احتياطية كاملة (JSON)</button>' +
                        '<label class="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black cursor-pointer">⬆️ استيراد نسخة احتياطية<input id="inpAdmImportBackup" type="file" accept=".json" class="hidden"/></label>' +
                        '<button type="button" id="btnAdmClearOldCache" class="px-4 py-2.5 rounded-xl bg-rose-600/80 hover:bg-rose-600 text-white font-black">🧹 تنظيف الذاكرة القديمة وتحديث الكاش</button>' +
                      '</div>' +
                      '<div class="pt-3 border-t border-slate-800 space-y-2">' +
                        '<div class="font-black text-emerald-300">📚 نشر كتاب ثقافي أو مرجع عام جديد في المكتبة الشاملة:</div>' +
                        '<div class="grid grid-cols-1 md:grid-cols-3 gap-2">' +
                          '<input id="inpAdmCultTitle" type="text" placeholder="عنوان الكتاب الثقافي العام..." class="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-bold"/>' +
                          '<input id="inpAdmCultUrl" type="text" dir="ltr" placeholder="رابط Google Drive أو PDF (اختياري)..." class="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sky-200 font-mono"/>' +
                          '<button type="button" id="btnAdmPublishCultBook" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black">➕ نشر في المكتبة الشاملة</button>' +
                        '</div>' +
                      '</div>' +
                    '</div>'
                  ) : "") +
                '</div>'
              )) +
            '</div>'
          ) : "") +

          '<div class="px-5 py-4 bg-slate-900 text-slate-300 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">' +
            '<div class="font-black text-white">🇵🇸 EduTech Mindset | عقلية التعليم والتكنولوجيا <span class="text-amber-300 font-bold">— إدارة الأستاذ باسل أشرف الفقعاوي</span></div>' +
            '<div class="flex flex-wrap items-center gap-2">' +
              '<a href="https://moe.edu.ps/" target="_blank" rel="noopener" class="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-emerald-600 text-emerald-300 hover:text-white font-bold transition">🏛️ وزارة التربية والتعليم</a>' +
              '<a href="https://elearn.edu.ps/" target="_blank" rel="noopener" class="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-sky-600 text-sky-300 hover:text-white font-bold transition">📚 البوابة التعليمية</a>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';

    bindOrganizerEvents(root, S, G, B, M, pageData);
    var _t1 = (window.performance && performance.now) ? performance.now() : Date.now();
    _lastRenderMs = Math.max(1, Math.round(_t1 - _t0));
  }

  function bindOrganizerEvents(root, S, G, B, M, pageData) {
    var exitImpBtn = document.getElementById("btnOrgExitImpersonation");
    if (exitImpBtn) {
      exitImpBtn.addEventListener("click", function () {
        state.impersonatingUserEmail = "";
        state.topNav = "admin";
        state.adminTab = "permissions_mgr";
        renderMainOrganizer();
        toast("👑 تم إنهاء وضع المعاينة والعودة للوحة الإدارة", "info");
      });
    }

    var themeBtn = document.getElementById("btnOrgToggleTheme");
    if (themeBtn) {
      themeBtn.addEventListener("click", function () {
        document.documentElement.classList.toggle("dark");
        var isDark = document.documentElement.classList.contains("dark");
        try { localStorage.setItem("edu_theme_mode", isDark ? "dark" : "light"); } catch (e) {}
        toast(isDark ? "🌙 تم تفعيل الوضع الليلي" : "☀️ تم تفعيل الوضع النهاري", "info");
      });
    }

    var fullSubBtn = document.getElementById("btnOrgPrintFullSubject");
    if (fullSubBtn) {
      fullSubBtn.addEventListener("click", function () {
        var w = window.open("", "_blank");
        if (!w) { toast("يرجى السماح بالنوافذ المنبثقة لطباعة ملخص المادة", "warning"); return; }
        var unitsHtml = (M.units || []).map(function (u, i) {
          return '<li style="margin-bottom:6px;"><strong>الوحدة ' + (i + 1) + ':</strong> ' + esc(u) + '</li>';
        }).join("");
        var rulesHtml = (M.rules || []).map(function (r) {
          return '<li style="margin-bottom:6px;">' + esc(r) + '</li>';
        }).join("");
        var html = '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>ملخص ليلة الامتحان — ' + esc(M.name) + '</title>' +
          '<style>body{font-family:"Cairo",sans-serif;margin:28px;color:#0f172a;line-height:1.8;}@media print{.no-print{display:none;}}</style></head><body>' +
          '<div class="no-print" style="margin-bottom:14px;"><button onclick="window.print()" style="padding:8px 18px;background:#0284c7;color:#fff;border:none;border-radius:8px;font-weight:bold;cursor:pointer;">🖨️ طباعة ملخص الامتحان A4</button></div>' +
          '<h1 style="font-size:20px;color:#0369a1;">📄 ملخص المراجعة الشامل: ' + esc(M.bookTitle || M.name) + '</h1>' +
          '<div style="font-size:13px;color:#475569;margin-bottom:16px;">' + esc(S.name + " • " + G.name) + '</div>' +
          '<h2 style="font-size:16px;color:#065f46;">📑 فهرس الوحدات والدروس المعتمدة:</h2><ul>' + unitsHtml + '</ul>' +
          '<h2 style="font-size:16px;color:#b45309;margin-top:18px;">📌 القواعد والقوانين المحورية:</h2><ul>' + rulesHtml + '</ul>' +
          '<div style="margin-top:24px;font-size:12px;color:#64748b;border-top:1px solid #e2e8f0;padding-top:10px;">EduTech Mindset | عقلية التعليم والتكنولوجيا</div></body></html>';
        w.document.open(); w.document.write(html); w.document.close();
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-inlineback]"), function (ib) {
      ib.addEventListener("click", goBackStep);
    });

    var backBtn = document.getElementById("btnOrgGoBack");
    if (backBtn) {
      backBtn.addEventListener("click", function () {
        goBackStep();
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-topnav]"), function (b) {
      b.addEventListener("click", function () {
        var nav = b.getAttribute("data-org-topnav") || "curriculum";
        state.showHeroBanner = false;
        state.topNav = nav;
        pushNavHistory();
        renderMainOrganizer();
        if (nav === "curriculum") focusAndScrollTo("orgStepStagesBox", "🏫 تم فتح المراحل الدراسية والمنهاج ✓");
        else if (nav === "tools") focusAndScrollTo("orgToolsSectionBox", "🛠️ تم فتح بوابة الأدوات والمختبرات ✓");
        else if (nav === "library") focusAndScrollTo("orgLibrarySectionBox", "📖 تم فتح المكتبة الرقمية الشاملة ✓");
        else if (nav === "mybag") focusAndScrollTo("orgMyBagSectionBox", "📌 تم فتح حقيبتك القرائية ودفتر هوامشك ✓");
        else if (nav === "university") focusAndScrollTo("orgUniversitySectionBox", "🎓 تم فتح بوابة المرحلة الجامعية والسيرة الذاتية ✓");
        else if (nav === "admin") focusAndScrollTo("orgAdminSectionBox", "🔐 تم فتح لوحة الإدارة والتحكم ✓");
        else if (nav === "account") focusAndScrollTo("orgAccountSectionBox", "👤 تم فتح بوابة التسجيل والحساب ✓");
      });
    });

    // التبويبات الفرعية
    Array.prototype.forEach.call(root.querySelectorAll("[data-org-currsub]"), function (b) {
      b.addEventListener("click", function () {
        state.curriculumSubTab = b.getAttribute("data-org-currsub") || "textbook";
        renderMainOrganizer();
        if (state.curriculumSubTab === "video_lessons") focusAndScrollTo("learnSection", "🎬 تم إظهار الفيديوهات والدروس المصورة ✓");
        else if (state.curriculumSubTab === "ministry_books") focusAndScrollTo("booksSection", "📘 تم إظهار فهرس الكتب المدرسية ✓");
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-libsub]"), function (b) {
      b.addEventListener("click", function () {
        state.librarySubTab = b.getAttribute("data-org-libsub") || "curriculum_cultural";
        renderMainOrganizer();
        if (state.librarySubTab === "edu_resources") focusAndScrollTo("library", "📂 تم فتح مكتبة الموارد والبرومبتات ✓");
        else if (state.librarySubTab === "open_courses") focusAndScrollTo("coursesSection", "🏅 تم فتح الدورات التدريبية والمجتمع ✓");
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-bagsub]"), function (b) {
      b.addEventListener("click", function () {
        state.mybagSubTab = b.getAttribute("data-org-bagsub") || "reading_notes";
        renderMainOrganizer();
        if (state.mybagSubTab === "my_workspace") focusAndScrollTo("userWorkspaceSection", "👨‍🎓 تم فتح مساحتك الشخصية ومفكرة المهام ✓");
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-unisub]"), function (b) {
      b.addEventListener("click", function () {
        var sub = b.getAttribute("data-org-unisub") || "majors_tawjihi";
        if (sub === "cv_studio" && !canAccessTool("cvBuilderStudio")) {
          showBlockedToolModal("cvBuilderStudio");
          return;
        }
        if (sub === "research_apa" && !canAccessTool("uniResearchCareerStudio")) {
          showBlockedToolModal("uniResearchCareerStudio");
          return;
        }
        state.uniSubTab = sub;
        renderMainOrganizer();
        if (sub === "cv_studio") focusAndScrollTo("cvBuilderStudio", "📄 تم فتح منشئ السيرة الذاتية الاحترافية ✓");
        else if (sub === "research_apa") focusAndScrollTo("uniResearchCareerStudio", "🔬 تم فتح استوديو الأبحاث الجامعية وتوثيق APA ✓");
        else if (sub === "about_platform") focusAndScrollTo("about", "🇵🇸 تم فتح قسم من نحن وتواصل معنا ✓");
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-accsub]"), function (b) {
      b.addEventListener("click", function () {
        state.accountSubTab = b.getAttribute("data-org-accsub") || "profile";
        renderMainOrganizer();
      });
    });

    // بوابة الأدوات
    Array.prototype.forEach.call(root.querySelectorAll("[data-org-toolcat]"), function (b) {
      b.addEventListener("click", function () {
        state.toolsCat = b.getAttribute("data-org-toolcat") || "all";
        renderMainOrganizer();
      });
    });

    var tSearchInp = document.getElementById("inpOrgToolsSearch");
    if (tSearchInp) {
      tSearchInp.addEventListener("input", function () {
        var pos = tSearchInp.selectionStart;
        state.toolsSearch = tSearchInp.value;
        renderMainOrganizer();
        var nInp = document.getElementById("inpOrgToolsSearch");
        if (nInp) { nInp.focus(); try { nInp.setSelectionRange(pos, pos); } catch (e) {} }
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-opentool]"), function (b) {
      b.addEventListener("click", function () {
        openToolOrPrompt(b.getAttribute("data-org-opentool"));
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-reqtool]"), function (b) {
      b.addEventListener("click", function () {
        showBlockedToolModal(b.getAttribute("data-org-reqtool"));
      });
    });

    var closeToolBtn = document.getElementById("btnOrgCloseActiveTool");
    if (closeToolBtn) {
      closeToolBtn.addEventListener("click", function () {
        state.openedToolId = "";
        state.collapseToolsCatalog = false;
        renderMainOrganizer();
        toast("✕ تم إغلاق الأداة والعودة لفهرس الأدوات", "info");
      });
    }
    var togCatGridBtn = document.getElementById("btnOrgToggleToolsCatalogGrid");
    if (togCatGridBtn) {
      togCatGridBtn.addEventListener("click", function () {
        state.collapseToolsCatalog = !state.collapseToolsCatalog;
        renderMainOrganizer();
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-scrollto]"), function (b) {
      b.addEventListener("click", function () {
        focusAndScrollTo(b.getAttribute("data-org-scrollto"));
      });
    });

    var qInp = document.getElementById("inpOrgQuickSearch");
    if (qInp) {
      qInp.addEventListener("input", function () {
        state.quickSearch = qInp.value;
        var box = document.getElementById("orgSearchResultsBox");
        if (!box) return;
        var res = searchAllSubjects(state.quickSearch);
        if (!res.length) {
          box.innerHTML = "";
          return;
        }
        box.innerHTML = '<div class="p-3.5 rounded-2xl bg-sky-500/10 border border-sky-500/30 space-y-2">' +
          '<div class="text-xs font-black text-sky-700 dark:text-sky-300">⚡ نتائج البحث الفوري — اضغط لفتح الكتاب مباشرة:</div>' +
          '<div class="flex flex-wrap gap-2">' +
            res.map(function (r) {
              return '<button type="button" data-org-jumpbook="' + esc(r.stg.id + "|" + r.g.id + "|" + r.b.id + "|" + r.sub.id) + '" class="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-sky-500/40 hover:bg-sky-500 hover:text-slate-950 text-xs font-black transition">' +
                esc(r.sub.ico + " " + r.sub.name + " — " + r.g.name) +
              '</button>';
            }).join("") +
          '</div>' +
        '</div>';
        Array.prototype.forEach.call(box.querySelectorAll("[data-org-jumpbook]"), function (jb) {
          jb.addEventListener("click", function () {
            var parts = (jb.getAttribute("data-org-jumpbook") || "").split("|");
            if (parts.length === 4) {
              state.stageId = parts[0]; state.gradeId = parts[1]; state.branchId = parts[2]; state.subjectId = parts[3];
              state.topNav = "curriculum"; state.activeStudyMode = "book"; state.quickSearch = "";
              pushNavHistory();
              renderMainOrganizer();
              var newSel = getSelection();
              focusAndScrollTo("orgBookPagePaper", "📖 تم فتح كتاب «" + newSel.subject.name + "» ✓");
            }
          });
        });
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-stage]"), function (b) {
      b.addEventListener("click", function () {
        state.stageId = b.getAttribute("data-org-stage");
        pushNavHistory();
        state.gradeId = "";
        state.branchId = "";
        state.subjectId = "";
        state.unitIdx = 0;
        state.quizAnswers = {};
        renderMainOrganizer();
        var newSel = getSelection();
        focusAndScrollTo("orgStepGradesBox", "✨ تم فتح صفوف «" + newSel.stage.shortName + "»");
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-grade]"), function (b) {
      b.addEventListener("click", function () {
        state.gradeId = b.getAttribute("data-org-grade");
        pushNavHistory();
        state.branchId = "";
        state.subjectId = "";
        state.unitIdx = 0;
        state.quizAnswers = {};
        renderMainOrganizer();
        var newSel = getSelection();
        focusAndScrollTo("orgStepSubjectsBox", "🏫 تم فتح مواد «" + newSel.grade.name + "»");
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-branch]"), function (b) {
      b.addEventListener("click", function () {
        state.branchId = b.getAttribute("data-org-branch");
        pushNavHistory();
        state.subjectId = "";
        state.unitIdx = 0;
        state.quizAnswers = {};
        renderMainOrganizer();
        var newSel = getSelection();
        focusAndScrollTo("orgStepSubjectsBox", "🎯 تم عرض مواد «" + newSel.branch.name + "»");
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-subject]"), function (b) {
      b.addEventListener("click", function () {
        state.subjectId = b.getAttribute("data-org-subject");
        pushNavHistory();
        state.unitIdx = 0;
        state.quizAnswers = {};
        renderMainOrganizer();
        var newSel = getSelection();
        focusAndScrollTo("orgBookPagePaper", "📖 تم فتح كتاب «" + newSel.subject.name + "»");
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-unit]"), function (b) {
      b.addEventListener("click", function () {
        var uIdx = parseInt(b.getAttribute("data-org-unit"), 10) || 0;
        state.unitIdx = uIdx;
        pushNavHistory();
        var targetPage = uIdx * PAGES_PER_UNIT + 1;
        var cur = bookmarks[M.id] || { page: 1, note: "" };
        bookmarks[M.id] = { page: targetPage, note: cur.note };
        saveBookmarks();
        state.quizAnswers = {};
        renderMainOrganizer();
        var uName = (M.units && M.units[uIdx]) || M.name;
        focusAndScrollTo("orgBookPagePaper", "📑 تم فتح «" + uName + "» (صفحة " + targetPage + ")");
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-quickpage]"), function (b) {
      b.addEventListener("click", function () {
        var targetP = parseInt(b.getAttribute("data-org-quickpage"), 10) || 1;
        var cur = bookmarks[M.id] || { page: 1, note: "" };
        bookmarks[M.id] = { page: targetP, note: cur.note };
        saveBookmarks();
        renderMainOrganizer();
        focusAndScrollTo("orgBookPagePaper", "📄 تم عرض محتوى صفحة " + targetP + " ✓");
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-studymode]"), function (b) {
      b.addEventListener("click", function () {
        state.activeStudyMode = b.getAttribute("data-org-studymode") || "book";
        renderMainOrganizer();
        focusAndScrollTo("orgActiveContentCard");
      });
    });

    var fPlus = document.getElementById("btnOrgFontPlus");
    var fMinus = document.getElementById("btnOrgFontMinus");
    if (fPlus) {
      fPlus.addEventListener("click", function () {
        readerPrefs.fontSize = Math.min(22, (readerPrefs.fontSize || 15) + 1);
        saveReaderPrefs();
        renderMainOrganizer();
      });
    }
    if (fMinus) {
      fMinus.addEventListener("click", function () {
        readerPrefs.fontSize = Math.max(12, (readerPrefs.fontSize || 15) - 1);
        saveReaderPrefs();
        renderMainOrganizer();
      });
    }
    Array.prototype.forEach.call(root.querySelectorAll("[data-org-paper]"), function (b) {
      b.addEventListener("click", function () {
        readerPrefs.paperTheme = b.getAttribute("data-org-paper") || "cream";
        saveReaderPrefs();
        renderMainOrganizer();
      });
    });

    var saveMarginBtn = document.getElementById("btnOrgSaveMarginNote");
    if (saveMarginBtn) {
      saveMarginBtn.addEventListener("click", function () {
        var mInp = document.getElementById("inpOrgPageMarginNote");
        if (mInp) {
          pageNotes[M.id + ":" + pageData.page] = mInp.value;
          savePageNotes();
          toast("💾 تم حفظ ملاحظتك الهامشية على صفحة " + pageData.page + " في حقيبتك ✓", "success");
        }
      });
    }

    var openFullReaderBtn = document.getElementById("btnOrgOpenFullBookReader");
    if (openFullReaderBtn) {
      openFullReaderBtn.addEventListener("click", function () {
        openToolOrPrompt("bookReaderStudio");
      });
    }

    var copyApaBtn = document.getElementById("btnOrgCopyApaRef");
    if (copyApaBtn) {
      copyApaBtn.addEventListener("click", function () {
        var refText = "وزارة التربية والتعليم العالي. (2025). " + (M.bookTitle || M.name) + " — " + pageData.unitTitle + " (ص. " + pageData.page + ").";
        try {
          if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(refText);
        } catch (e) {}
        toast("📋 تم نسخ التوثيق المرجعي (APA) للصفحة " + pageData.page + " ✓", "success");
      });
    }

    var hideCornellBtn = document.getElementById("btnOrgToggleCornellHide");
    if (hideCornellBtn) {
      hideCornellBtn.addEventListener("click", function () {
        state.hideCornellNotes = !state.hideCornellNotes;
        renderMainOrganizer();
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-flipcard]"), function (b) {
      b.addEventListener("click", function () {
        var cid = b.getAttribute("data-org-flipcard");
        state.flippedCards[cid] = !state.flippedCards[cid];
        renderMainOrganizer();
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-uquiz]"), function (b) {
      b.addEventListener("click", function () {
        var parts = b.getAttribute("data-org-uquiz").split(":");
        state.quizAnswers[parseInt(parts[0], 10)] = parseInt(parts[1], 10);
        renderMainOrganizer();
      });
    });

    var resetQuizBtn = document.getElementById("btnOrgResetUnitQuiz");
    if (resetQuizBtn) {
      resetQuizBtn.addEventListener("click", function () {
        state.quizAnswers = {};
        renderMainOrganizer();
      });
    }

    var pinSubBtn = document.getElementById("btnOrgTogglePinSub");
    if (pinSubBtn) {
      pinSubBtn.addEventListener("click", function () {
        pinnedSubjects[M.id] = !pinnedSubjects[M.id];
        savePinnedSubjects();
        renderMainOrganizer();
        toast(pinnedSubjects[M.id] ? "⭐ تم تثبيت مادة «" + M.name + "» في شريطك السريع ✓" : "☆ تم إلغاء التثبيت", "info");
      });
    }

    var unitDoneBtn = document.getElementById("btnOrgToggleUnitDone");
    if (unitDoneBtn) {
      unitDoneBtn.addEventListener("click", function () {
        var uk = M.id + ":" + pageData.unitIdx;
        completedUnits[uk] = !completedUnits[uk];
        saveCompletedUnits();
        renderMainOrganizer();
        toast(completedUnits[uk] ? "✅ تم تسجيل إتقان هذه الوحدة بنجاح!" : "↩️ تم إلغاء علامة إتقان الوحدة", "success");
      });
    }

    var addRuleBtn = document.getElementById("btnAdmAddRule");
    if (addRuleBtn) {
      addRuleBtn.addEventListener("click", function () {
        var rInp = document.getElementById("inpAdmNewRule");
        var txt = rInp ? rInp.value.trim() : "";
        if (!txt) return;
        M.rules = M.rules || [];
        M.rules.push(txt);
        saveTree();
        renderMainOrganizer();
        toast("📌 تمت إضافة القاعدة المحورية لمادة «" + M.name + "» ✓", "success");
      });
    }

    var delSubBtn = document.getElementById("btnAdmDeleteCurSubject");
    if (delSubBtn) {
      delSubBtn.addEventListener("click", function () {
        if (!B.subjects || B.subjects.length <= 1) {
          toast("⚠️ يجب إبقاء مادة واحدة على الأقل في الفرع", "warning");
          return;
        }
        B.subjects = B.subjects.filter(function (s) { return s.id !== M.id; });
        state.subjectId = B.subjects[0].id;
        saveTree();
        renderMainOrganizer();
        toast("🗑️ تم حذف المادة المحددة بنجاح", "info");
      });
    }

    var speakBtn = document.getElementById("btnOrgSpeakLesson");
    if (speakBtn) {
      speakBtn.addEventListener("click", function () {
        if ("speechSynthesis" in window) {
          window.speechSynthesis.cancel();
          var u = new SpeechSynthesisUtterance(pageData.subHeading + ". " + pageData.paragraphs.join(" "));
          u.lang = "ar-SA";
          window.speechSynthesis.speak(u);
          toast("🔊 جاري قراءة محتوى صفحة " + pageData.page + " صوتياً...", "info");
        }
      });
    }

    var clipBtn = document.getElementById("btnOrgQuickClipMargin");
    if (clipBtn) {
      clipBtn.addEventListener("click", function () {
        var selText = "";
        try { selText = (window.getSelection && window.getSelection().toString() || "").trim(); } catch (e) {}
        var quote = selText || (pageData.boxPoints && pageData.boxPoints[0]) || pageData.subHeading;
        var key = M.id + ":" + pageData.page;
        pageNotes[key] = (pageNotes[key] ? pageNotes[key] + "\n" : "") + "📌 " + quote;
        savePageNotes();
        renderMainOrganizer();
        toast("🖍️ تم حفظ الاقتباس في هامش صفحة " + pageData.page + " وحقيبتك ✓", "success");
      });
    }

    var shareBtn = document.getElementById("btnOrgShareLink");
    if (shareBtn) {
      shareBtn.addEventListener("click", function () {
        var hashVal = "#edu=" + encodeURIComponent(S.id + "|" + G.id + "|" + B.id + "|" + M.id + "|" + pageData.page);
        try { window.history.replaceState(null, "", hashVal); } catch (e) {}
        var fullUrl = window.location.href;
        try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(fullUrl); } catch (e) {}
        toast("🔗 تم نسخ الرابط المباشر لهذه الصفحة للمشاركة ✓", "success");
      });
    }

    var copyPageBtn = document.getElementById("btnOrgCopyPageText");
    if (copyPageBtn) {
      copyPageBtn.addEventListener("click", function () {
        var txt = (M.bookTitle || M.name) + " — ص " + pageData.page + "\n" + pageData.subHeading + "\n\n" + pageData.paragraphs.join("\n\n");
        try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt); } catch (e) {}
        toast("📋 تم نسخ نص صفحة " + pageData.page + " بالكامل ✓", "success");
      });
    }

    var libInp = document.getElementById("inpOrgLibFilter");
    if (libInp) {
      libInp.addEventListener("input", function () {
        var pos = libInp.selectionStart;
        state.libQuery = libInp.value;
        renderMainOrganizer();
        var nLib = document.getElementById("inpOrgLibFilter");
        if (nLib) { nLib.focus(); try { nLib.setSelectionRange(pos, pos); } catch (e) {} }
      });
    }
    var libSel = document.getElementById("selOrgLibStage");
    if (libSel) {
      libSel.addEventListener("change", function () {
        state.libStage = libSel.value || "all";
        renderMainOrganizer();
      });
    }

    var printBtn = document.getElementById("btnOrgPrintLesson");
    if (printBtn) {
      printBtn.addEventListener("click", function () {
        printCurrentLessonSummary(S, G, B, M, pageData);
      });
    }

    var gpaBtn = document.getElementById("org-tawjihi-gpa-btn");
    if (gpaBtn) {
      gpaBtn.addEventListener("click", function () {
        var oldModal = document.getElementById("tawjihi-gpa-modal");
        if (oldModal) oldModal.remove();
        var m = document.createElement("div");
        m.id = "tawjihi-gpa-modal";
        m.className = "fixed inset-0 z-[9999] bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4";
        m.innerHTML =
          '<div class="bg-white dark:bg-slate-900 border border-amber-500/40 rounded-3xl max-w-lg w-full p-5 shadow-2xl space-y-4" dir="rtl">' +
            '<div class="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">' +
              '<h3 class="text-base font-black text-slate-900 dark:text-white">🎓 حاسبة معدل التوجيهي الفلسطيني (من 100%)</h3>' +
              '<button type="button" id="tgpa-close" class="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-black">✕</button>' +
            '</div>' +
            '<div class="flex gap-2 flex-wrap">' +
              '<button type="button" data-tgpa-br="sci" class="tgpa-br px-3 py-1.5 rounded-xl text-xs font-black bg-amber-500 text-slate-950">🔬 العلمي</button>' +
              '<button type="button" data-tgpa-br="lit" class="tgpa-br px-3 py-1.5 rounded-xl text-xs font-black bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">📚 الأدبي</button>' +
              '<button type="button" data-tgpa-br="sharia" class="tgpa-br px-3 py-1.5 rounded-xl text-xs font-black bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">🕌 الشرعي</button>' +
            '</div>' +
            '<div id="tgpa-fields" class="grid grid-cols-2 gap-2.5 text-xs"></div>' +
            '<div class="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-800">' +
              '<button type="button" id="tgpa-calc" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black">احسب المعدل ✓</button>' +
              '<div id="tgpa-res" class="text-sm font-black text-amber-600 dark:text-amber-400">أدخل علاماتك من 100</div>' +
            '</div>' +
          '</div>';
        document.body.appendChild(m);
        var configs = {
          sci: [
            { name: "اللغة العربية", w: 150 }, { name: "اللغة الإنجليزية", w: 150 },
            { name: "الرياضيات", w: 200 }, { name: "الفيزياء", w: 150 },
            { name: "الكيمياء", w: 100 }, { name: "الأحياء", w: 100 },
            { name: "التربية الإسلامية", w: 100 }, { name: "التكنولوجيا", w: 100 }
          ],
          lit: [
            { name: "اللغة العربية (المطالعة والأدب)", w: 150 }, { name: "اللغة الإنجليزية", w: 150 },
            { name: "الدراسات التاريخية", w: 100 }, { name: "الدراسات الجغرافية", w: 100 },
            { name: "الرياضيات", w: 100 }, { name: "الثقافة العلمية", w: 100 },
            { name: "التربية الإسلامية", w: 100 }, { name: "التكنولوجيا", w: 100 }
          ],
          sharia: [
            { name: "القرآن والتفسير", w: 150 }, { name: "الفقه وأصوله", w: 150 },
            { name: "الحديث والعقيدة", w: 150 }, { name: "اللغة العربية (المطالعة والأدب)", w: 150 },
            { name: "اللغة الإنجليزية", w: 100 }, { name: "الدراسات التاريخية", w: 100 },
            { name: "الرياضيات", w: 100 }, { name: "التكنولوجيا", w: 100 }
          ]
        };
        var curBr = "sci";
        function drawFields() {
          var box = document.getElementById("tgpa-fields");
          box.innerHTML = configs[curBr].map(function (c) {
            return '<label class="flex flex-col gap-1 font-bold text-slate-700 dark:text-slate-200">' +
              '<span>' + c.name + ' <span class="text-[10px] text-slate-400">(' + c.w + ')</span></span>' +
              '<input type="number" min="0" max="100" value="90" data-w="' + c.w + '" class="tgpa-inp px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 font-black text-slate-900 dark:text-white">' +
            '</label>';
          }).join("");
        }
        drawFields();
        m.querySelectorAll(".tgpa-br").forEach(function (b) {
          b.addEventListener("click", function () {
            curBr = b.getAttribute("data-tgpa-br");
            m.querySelectorAll(".tgpa-br").forEach(function (x) {
              x.className = "tgpa-br px-3 py-1.5 rounded-xl text-xs font-black " +
                (x === b ? "bg-amber-500 text-slate-950" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200");
            });
            drawFields();
          });
        });
        document.getElementById("tgpa-calc").addEventListener("click", function () {
          var inps = m.querySelectorAll(".tgpa-inp");
          var totScore = 0, totW = 0;
          inps.forEach(function (inp) {
            var val = Math.max(0, Math.min(100, parseFloat(inp.value) || 0));
            var w = parseFloat(inp.getAttribute("data-w")) || 100;
            totScore += (val / 100) * w;
            totW += w;
          });
          var avg = totW ? ((totScore / totW) * 100).toFixed(2) : "0.00";
          document.getElementById("tgpa-res").textContent = "المعدل التقديري: " + avg + "%";
        });
        document.getElementById("tgpa-close").addEventListener("click", function () { m.remove(); });
        m.addEventListener("click", function (ev) { if (ev.target === m) m.remove(); });
      });
    }

    window.__eduActiveContext = {
      stageId: S.id, stageName: S.name,
      gradeId: G.id, gradeName: G.name,
      branchId: B.id, branchName: B.name,
      subjectId: M.id, subjectName: M.name,
      unit: (M.units && M.units[state.unitIdx]) || ""
    };
    try { localStorage.setItem("edu_active_stage_context", JSON.stringify(window.__eduActiveContext)); } catch (e) {}

    var foundBtn = document.getElementById("org-foundation-btn");
    if (foundBtn) {
      foundBtn.addEventListener("click", function () {
        var oldM = document.getElementById("edu-foundation-modal");
        if (oldM) oldM.remove();
        var letters = "أ ب ت ث ج ح خ د ذ ر ز س ش ص ض ط ظ ع غ ف ق ك ل م ن هـ و ي".split(" ");
        var nums = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20"];
        var m = document.createElement("div");
        m.id = "edu-foundation-modal";
        m.className = "fixed inset-0 z-[9999] bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4";
        m.innerHTML =
          '<div class="bg-white dark:bg-slate-900 border border-amber-500/40 rounded-3xl max-w-xl w-full p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto" dir="rtl">' +
            '<div class="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">' +
              '<h3 class="text-base font-black text-slate-900 dark:text-white">🎯 مختبر التأسيس السليم الصوتي (الحروف والأرقام)</h3>' +
              '<button type="button" id="efd-close" class="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-black">✕</button>' +
            '</div>' +
            '<div class="text-xs font-bold text-slate-500 dark:text-slate-400">اضغط على أي حرف أو رقم لسماع نطقه الصحيح فوراً:</div>' +
            '<div class="grid grid-cols-7 gap-1.5">' +
              letters.map(function (ch) { return '<button type="button" data-efd-say="' + ch + '" class="py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500 hover:text-slate-950 border border-amber-500/30 font-black text-sm text-slate-900 dark:text-white transition">' + ch + '</button>'; }).join("") +
            '</div>' +
            '<div class="text-xs font-black text-emerald-700 dark:text-emerald-300 pt-1">🔢 الأرقام (1 – 20):</div>' +
            '<div class="grid grid-cols-5 sm:grid-cols-10 gap-1.5">' +
              nums.map(function (n) { return '<button type="button" data-efd-say="' + n + '" class="py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-600 hover:text-white border border-emerald-500/30 font-black text-xs text-slate-900 dark:text-white transition">' + n + '</button>'; }).join("") +
            '</div>' +
          '</div>';
        document.body.appendChild(m);
        m.querySelectorAll("[data-efd-say]").forEach(function (b) {
          b.addEventListener("click", function () {
            window.EduMasterHierarchy.speakText(b.getAttribute("data-efd-say"), "ar-SA");
          });
        });
        document.getElementById("efd-close").addEventListener("click", function () { m.remove(); });
        m.addEventListener("click", function (ev) { if (ev.target === m) m.remove(); });
      });
    }

    var speakUnitBtn = document.getElementById("org-speak-btn");
    if (speakUnitBtn) {
      speakUnitBtn.addEventListener("click", function () {
        var unitTxt = (M.units && M.units[state.unitIdx]) ? M.units[state.unitIdx] : M.name;
        var ruleTxt = (M.rules && M.rules[0]) ? (" — القاعدة: " + M.rules[0]) : "";
        window.EduMasterHierarchy.speakText(M.name + "، " + G.name + ". " + unitTxt + ruleTxt);
        toast("🔊 جارٍ قراءة محتوى الوحدة صوتياً...", "info");
      });
    }

    var recallBtn = document.getElementById("org-recall-btn");
    if (recallBtn) {
      recallBtn.addEventListener("click", function () {
        var oldM = document.getElementById("edu-recall-modal");
        if (oldM) oldM.remove();
        var rulesList = (M.rules && M.rules.length) ? M.rules : ["راجع الوحدات الأساسية لهذه المادة."];
        var rIdx = 0;
        var m = document.createElement("div");
        m.id = "edu-recall-modal";
        m.className = "fixed inset-0 z-[9999] bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4";
        m.innerHTML =
          '<div class="bg-white dark:bg-slate-900 border border-purple-500/40 rounded-3xl max-w-lg w-full p-5 shadow-2xl space-y-4" dir="rtl">' +
            '<div class="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">' +
              '<h3 class="text-base font-black text-slate-900 dark:text-white">🧠 تسميع القوانين والمفاهيم — ' + esc(M.name) + '</h3>' +
              '<button type="button" id="erc-close" class="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-black">✕</button>' +
            '</div>' +
            '<div class="p-4 rounded-2xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800 space-y-2">' +
              '<div id="erc-counter" class="text-[11px] font-black text-purple-600 dark:text-purple-300"></div>' +
              '<div id="erc-body" class="text-sm font-bold text-slate-800 dark:text-slate-100 leading-relaxed blur-sm select-none transition duration-200 cursor-pointer" title="انقر لإظهار النص"></div>' +
            '</div>' +
            '<div class="flex items-center justify-between gap-2">' +
              '<button type="button" id="erc-toggle" class="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-black">👁️ إظهار / إخفاء</button>' +
              '<button type="button" id="erc-next" class="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-black">التالي ◀</button>' +
            '</div>' +
          '</div>';
        document.body.appendChild(m);
        function showRule() {
          var b = document.getElementById("erc-body");
          var c = document.getElementById("erc-counter");
          if (c) c.textContent = "القاعدة / المفهوم " + (rIdx + 1) + " من " + rulesList.length + " — حاول تذكرها قبل الإظهار:";
          if (b) { b.textContent = rulesList[rIdx]; b.classList.add("blur-sm"); }
        }
        showRule();
        document.getElementById("erc-toggle").addEventListener("click", function () {
          document.getElementById("erc-body").classList.toggle("blur-sm");
        });
        document.getElementById("erc-body").addEventListener("click", function () {
          this.classList.toggle("blur-sm");
        });
        document.getElementById("erc-next").addEventListener("click", function () {
          rIdx = (rIdx + 1) % rulesList.length;
          showRule();
        });
        document.getElementById("erc-close").addEventListener("click", function () { m.remove(); });
        m.addEventListener("click", function (ev) { if (ev.target === m) m.remove(); });
      });
    }

    var progBtn = document.getElementById("org-progress-btn");
    if (progBtn) {
      progBtn.addEventListener("click", function () {
        var oldM = document.getElementById("edu-progress-modal");
        if (oldM) oldM.remove();
        var pomoCount = parseInt(localStorage.getItem("edu_pomo_today") || "0", 10) || 0;
        var planSaved = {};
        try { planSaved = JSON.parse(localStorage.getItem("edu_weekly_planner_v1") || "{}") || {}; } catch (e) {}
        var planDays = Object.keys(planSaved).filter(function (k) { return planSaved[k]; }).length;
        var totalSubs = (B.subjects || []).length;
        var visited = {};
        try { visited = JSON.parse(localStorage.getItem("edu_visited_subjects_v1") || "{}") || {}; } catch (e) {}
        visited[M.id] = true;
        localStorage.setItem("edu_visited_subjects_v1", JSON.stringify(visited));
        var doneCount = (B.subjects || []).filter(function (s) { return visited[s.id]; }).length;
        var pct = totalSubs ? Math.round((doneCount / totalSubs) * 100) : 0;
        var m = document.createElement("div");
        m.id = "edu-progress-modal";
        m.className = "fixed inset-0 z-[9999] bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4";
        m.innerHTML =
          '<div class="bg-white dark:bg-slate-900 border border-teal-500/40 rounded-3xl max-w-md w-full p-5 shadow-2xl space-y-4" dir="rtl">' +
            '<div class="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">' +
              '<h3 class="text-base font-black text-slate-900 dark:text-white">📊 لوحة إنجازي — ' + esc(G.name) + '</h3>' +
              '<button type="button" id="epr-close" class="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-black">✕</button>' +
            '</div>' +
            '<div class="space-y-3 text-xs font-bold">' +
              '<div>' +
                '<div class="flex justify-between mb-1 text-slate-700 dark:text-slate-200"><span>تغطية مواد ' + esc(B.name) + '</span><span>' + doneCount + ' / ' + totalSubs + ' (' + pct + '%)</span></div>' +
                '<div class="w-full h-2.5 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden"><div class="h-full bg-teal-500 rounded-full" style="width:' + pct + '%"></div></div>' +
              '</div>' +
              '<div class="grid grid-cols-2 gap-2.5">' +
                '<div class="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-center"><div class="text-lg font-black text-emerald-600 dark:text-emerald-400">' + pomoCount + '</div><div class="text-[11px] text-slate-600 dark:text-slate-300">جلسات تركيز اليوم</div></div>' +
                '<div class="p-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800 text-center"><div class="text-lg font-black text-indigo-600 dark:text-indigo-400">' + planDays + ' / 7</div><div class="text-[11px] text-slate-600 dark:text-slate-300">أيام جدول المذاكرة</div></div>' +
              '</div>' +
            '</div>' +
          '</div>';
        document.body.appendChild(m);
        document.getElementById("epr-close").addEventListener("click", function () { m.remove(); });
        m.addEventListener("click", function (ev) { if (ev.target === m) m.remove(); });
      });
    }

    var planBtn = document.getElementById("org-planner-btn");
    if (planBtn) {
      planBtn.addEventListener("click", function () {
        var oldM = document.getElementById("edu-study-planner-modal");
        if (oldM) oldM.remove();
        var days = ["السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"];
        var saved = {};
        try { saved = JSON.parse(localStorage.getItem("edu_weekly_planner_v1") || "{}") || {}; } catch (e) {}
        var m = document.createElement("div");
        m.id = "edu-study-planner-modal";
        m.className = "fixed inset-0 z-[9999] bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4";
        m.innerHTML =
          '<div class="bg-white dark:bg-slate-900 border border-indigo-500/40 rounded-3xl max-w-2xl w-full p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto" dir="rtl">' +
            '<div class="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">' +
              '<h3 class="text-base font-black text-slate-900 dark:text-white">📅 جدول المذاكرة الأسبوعي — ' + esc(G.name) + '</h3>' +
              '<button type="button" id="epl-close" class="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-black">✕</button>' +
            '</div>' +
            '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">' +
              days.map(function (d, idx) {
                return '<label class="flex flex-col gap-1 p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">' +
                  '<span class="font-black text-indigo-700 dark:text-indigo-300">' + d + '</span>' +
                  '<input type="text" data-day="' + idx + '" value="' + esc(saved[idx] || "") + '" placeholder="مثال: ' + esc(M.name) + ' — وحدة 1" class="epl-inp px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-bold">' +
                '</label>';
              }).join("") +
            '</div>' +
            '<div class="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">' +
              '<div class="flex gap-2">' +
                '<button type="button" id="epl-save" class="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black">💾 حفظ الجدول</button>' +
                '<button type="button" id="epl-fill" class="px-3 py-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-800 dark:text-amber-300 text-xs font-black">⚡ توزيع مواد الفرع تلقائياً</button>' +
              '</div>' +
              '<button type="button" id="epl-print" class="px-3 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-black">🖨️ طباعة</button>' +
            '</div>' +
          '</div>';
        document.body.appendChild(m);
        document.getElementById("epl-save").addEventListener("click", function () {
          var obj = {};
          m.querySelectorAll(".epl-inp").forEach(function (inp) {
            obj[inp.getAttribute("data-day")] = inp.value.trim();
          });
          localStorage.setItem("edu_weekly_planner_v1", JSON.stringify(obj));
          toast("📅 تم حفظ جدول المذاكرة الأسبوعي ✓", "success");
        });
        document.getElementById("epl-fill").addEventListener("click", function () {
          var subs = (B.subjects || []).map(function (s) { return s.name; });
          if (!subs.length) return;
          m.querySelectorAll(".epl-inp").forEach(function (inp, i) {
            inp.value = subs[i % subs.length] + " — مراجعة وحل أسئلة";
          });
          toast("⚡ تم توزيع مواد " + B.name + " على أيام الأسبوع", "info");
        });
        document.getElementById("epl-print").addEventListener("click", function () {
          window.print();
        });
        document.getElementById("epl-close").addEventListener("click", function () { m.remove(); });
        m.addEventListener("click", function (ev) { if (ev.target === m) m.remove(); });
      });
    }

    var pomoBtn = document.getElementById("org-pomodoro-btn");
    if (pomoBtn) {
      if (!window.__eduPomo) {
        window.__eduPomo = { sec: 25 * 60, running: false, mode: "study", timer: null, count: parseInt(localStorage.getItem("edu_pomo_today") || "0", 10) || 0 };
      }
      var disp = document.getElementById("org-pomo-disp");
      function fmtPomo(s) {
        var m = Math.floor(s / 60), r = s % 60;
        return (m < 10 ? "0" : "") + m + ":" + (r < 10 ? "0" : "") + r;
      }
      if (disp) disp.textContent = fmtPomo(window.__eduPomo.sec);
      pomoBtn.addEventListener("click", function () {
        var st = window.__eduPomo;
        if (st.running) {
          clearInterval(st.timer);
          st.running = false;
          toast("⏸️ تم إيقاف مؤقت التركيز مؤقتاً (" + fmtPomo(st.sec) + ")", "info");
        } else {
          st.running = true;
          toast("⏱️ بدأت جلسة تركيز (25 دقيقة) — بالتوفيق!", "success");
          st.timer = setInterval(function () {
            st.sec--;
            var d = document.getElementById("org-pomo-disp");
            if (d) d.textContent = fmtPomo(Math.max(0, st.sec));
            if (st.sec <= 0) {
              clearInterval(st.timer);
              st.running = false;
              if (st.mode === "study") {
                st.count++;
                localStorage.setItem("edu_pomo_today", String(st.count));
                st.mode = "break";
                st.sec = 5 * 60;
                toast("🎉 أحسنت! أنهيت جلسة تركيز (#" + st.count + ") — خذ 5 دقائق راحة", "success");
              } else {
                st.mode = "study";
                st.sec = 25 * 60;
                toast("🔔 انتهت الاستراحة! جاهز لجلسة جديدة", "info");
              }
              if (d) d.textContent = fmtPomo(st.sec);
            }
          }, 1000);
        }
      });
    }

    var saveOffBtn = document.getElementById("btnOrgSaveGradeOffline");
    if (saveOffBtn) {
      saveOffBtn.addEventListener("click", function () {
        try {
          localStorage.setItem("edu_offline_grade_" + G.id, JSON.stringify({ savedAt: Date.now(), grade: G }));
          toast("💾 تم حفظ جميع كتب ووحدات «" + G.name + "» للعمل بلا إنترنت ✓", "success");
        } catch (e) {
          toast("⚠️ تعذر الحفظ المحلي بسبب امتلاء الذاكرة", "warning");
        }
      });
    }

    var parentRepBtn = document.getElementById("btnOrgCopyParentReport");
    if (parentRepBtn) {
      parentRepBtn.addEventListener("click", function () {
        var studentName = (currentUser && currentUser.name) ? currentUser.name : "الطالب";
        var mastered = Object.keys(completedUnits).filter(function (k) { return !!completedUnits[k]; }).length;
        var rep = "📊 تقرير المتابعة — منصة EduTech Mindset\n" +
          "👤 الاسم: " + studentName + "\n" +
          "🏫 الصف: " + G.name + "\n" +
          "📖 الصفحات المقروءة اليوم: " + getDailyStreak().todayPages + "\n" +
          "✅ الوحدات المُتقَنة: " + mastered + "\n" +
          "📌 آخر كتاب مفتوح: " + (M.bookTitle || M.name) + " (ص " + pageData.page + ")";
        try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(rep); } catch (e) {}
        toast("👪 تم نسخ تقرير متابعة ولي الأمر لمشاركته فوراً ✓", "success");
      });
    }

    var expMdBtn = document.getElementById("btnOrgExportNotesMd");
    if (expMdBtn) {
      expMdBtn.addEventListener("click", function () {
        var allSubs = getAllFlattenSubjects();
        var subMap = {};
        allSubs.forEach(function (x) { subMap[x.sub.id] = x; });
        var keys = Object.keys(pageNotes).filter(function (k) { return pageNotes[k] && pageNotes[k].trim(); });
        var lines = ["# 📌 دفتر هوامش وملاحظات EduTech Mindset", ""];
        if (!keys.length) {
          lines.push("لا توجد ملاحظات مسجلة بعد.");
        } else {
          keys.forEach(function (k) {
            var pts = k.split(":");
            var info = subMap[pts[0]];
            var title = info ? (info.sub.bookTitle || info.sub.name) + " (" + info.g.name + ")" : pts[0];
            lines.push("## 📘 " + title + " — صفحة " + (pts[1] || "1"));
            lines.push(pageNotes[k]);
            lines.push("");
          });
        }
        var blob = new Blob([lines.join("\n")], { type: "text/markdown;charset=utf-8" });
        var a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = "edutech_margin_notes.md";
        a.click();
        toast("⬇️ تم تصدير دفتر هوامشك بصيغة Markdown (.md) ✓", "success");
      });
    }

    var certBtn = document.getElementById("btnOrgPrintCertificate");
    if (certBtn) {
      certBtn.addEventListener("click", function () {
        var studentName = (currentUser && currentUser.name) ? currentUser.name : "طالب منصة EduTech Mindset";
        var gradeLabel = (currentUser && currentUser.gradeName) ? currentUser.gradeName : G.name;
        var masteredCount = Object.keys(completedUnits).filter(function (k) { return !!completedUnits[k]; }).length;
        var todayPages = getDailyStreak().todayPages;
        var w = window.open("", "_blank");
        if (!w) { toast("يرجى السماح بالنوافذ المنبثقة لطباعة الشهادة", "warning"); return; }
        var ch = '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>شهادة إنجاز — EduTech Mindset</title>' +
          '<style>body{font-family:"Cairo",sans-serif;margin:30px;text-align:center;color:#0f172a;}.box{border:6px double #0284c7;padding:36px;border-radius:18px;background:#f8fafc;}@media print{.no-print{display:none;}}</style></head><body>' +
          '<div class="no-print" style="margin-bottom:14px;"><button onclick="window.print()" style="padding:8px 20px;background:#0284c7;color:#fff;border:none;border-radius:8px;font-weight:bold;cursor:pointer;">🖨️ طباعة الشهادة A4</button></div>' +
          '<div class="box">' +
            '<div style="font-size:14px;color:#0369a1;font-weight:900;">🇵🇸 منصة EduTech Mindset | عقلية التعليم والتكنولوجيا</div>' +
            '<h1 style="font-size:28px;margin:14px 0;color:#0f172a;">🏆 شهادة إنجاز وتفوّق دراسي</h1>' +
            '<p style="font-size:16px;">تُمنح هذه الشهادة للطالب/ـة المتميّز/ـة:</p>' +
            '<div style="font-size:24px;font-weight:900;color:#059669;margin:10px 0;">' + esc(studentName) + '</div>' +
            '<p style="font-size:15px;">الصف الدراسي: <strong>' + esc(gradeLabel) + '</strong></p>' +
            '<p style="font-size:14px;color:#334155;">تقديراً لالتزامه بالمنهاج الفلسطيني وإتقان <strong>' + masteredCount + '</strong> وحدات دراسية وقراءة <strong>' + todayPages + '</strong> صفحات اليوم.</p>' +
            '<div style="margin-top:28px;font-size:13px;color:#475569;">إدارة المنصة: الأستاذ باسل أشرف الفقعاوي • ' + new Date().toLocaleDateString("ar-EG") + '</div>' +
          '</div></body></html>';
        w.document.open(); w.document.write(ch); w.document.close();
      });
    }

    var printAllNotesBtn = document.getElementById("btnOrgPrintAllNotes");
    if (printAllNotesBtn) {
      printAllNotesBtn.addEventListener("click", printAllMarginNotes);
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-quickgrade]"), function (b) {
      b.addEventListener("click", function () {
        var pts = (b.getAttribute("data-org-quickgrade") || "").split("|");
        if (pts.length === 2) {
          state.stageId = pts[0];
          state.gradeId = pts[1];
          state.branchId = "";
          state.subjectId = "";
          state.unitIdx = 0;
          state.semesterFilter = "all";
          state.quizAnswers = {};
          pushNavHistory();
          renderMainOrganizer();
          var ns = getSelection();
          focusAndScrollTo("orgStepSubjectsBox", "⚡ تم فتح مواد «" + ns.grade.name + "» بنقرة واحدة ✓");
        }
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-semfilter]"), function (b) {
      b.addEventListener("click", function () {
        state.semesterFilter = b.getAttribute("data-org-semfilter") || "all";
        renderMainOrganizer();
      });
    });

    var colBtn = document.getElementById("btnOrgToggleCollapse");
    if (colBtn) {
      colBtn.addEventListener("click", function () {
        state.collapseSelectors = !state.collapseSelectors;
        renderMainOrganizer();
      });
    }

    var solBtn = document.getElementById("btnOrgToggleSolutions");
    if (solBtn) {
      solBtn.addEventListener("click", function () {
        state.revealSolutions = !state.revealSolutions;
        renderMainOrganizer();
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-libbag]"), function (b) {
      b.addEventListener("click", function () {
        state.libQuery = b.getAttribute("data-org-libbag") || "";
        state.libStage = "all";
        renderMainOrganizer();
      });
    });

    var clozeBtn = document.getElementById("btnOrgToggleCloze");
    if (clozeBtn) {
      clozeBtn.addEventListener("click", function () {
        state.revealCloze = !state.revealCloze;
        renderMainOrganizer();
      });
    }

    var askBtn = document.getElementById("btnOrgAskSmartPage");
    if (askBtn) {
      askBtn.addEventListener("click", function () {
        var qInp = document.getElementById("inpOrgSmartPageQ");
        var q = (qInp ? qInp.value : "").trim();
        var mdHits = [];
        try {
          Object.keys(localStorage).forEach(function (k) {
            if (/^edu_(sources|smartbrain|md)/.test(k)) {
              var raw = localStorage.getItem(k) || "";
              if (q && raw.toLowerCase().indexOf(q.toLowerCase()) !== -1) {
                mdHits.push(raw.slice(0, 180));
              }
            }
          });
        } catch (e) {}
        var ans = "📘 خلاصة الإجابة الموثّقة لصفحة " + pageData.page + " («" + pageData.unitTitle + "»):\n" +
          "• الفكرة المحورية: " + (pageData.boxPoints[0] || pageData.subHeading) + "\n" +
          "• التطبيق العملي: " + pageData.activityBody;
        if (mdHits.length) {
          ans += "\n• من قاعدة الـ Markdown الخفية: تم العثور على " + mdHits.length + " مرجع(مراجع) مطابقة محلياً.";
        }
        state.smartPageAnswer = ans;
        renderMainOrganizer();
      });
    }

    var packBtn = document.getElementById("btnAdmGenLessonPack");
    if (packBtn) {
      packBtn.addEventListener("click", function () {
        var w = window.open("", "_blank");
        if (!w) { toast("يرجى السماح بالنوافذ المنبثقة لطباعة حزمة الحصة", "warning"); return; }
        var qHtml = pageData.unitQuizQuestions.map(function (q) {
          return '<li>' + esc(q.q) + ' — (الإجابة: ' + esc(q.opts[q.ans]) + ')</li>';
        }).join("");
        var pkHtml = '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>حزمة الحصة المتكاملة — ' + esc(M.name) + '</title>' +
          '<style>body{font-family:"Cairo",sans-serif;margin:28px;color:#0f172a;line-height:1.8;}@media print{.no-print{display:none;}}</style></head><body>' +
          '<div class="no-print" style="margin-bottom:14px;"><button onclick="window.print()" style="padding:8px 18px;background:#059669;color:#fff;border:none;border-radius:8px;font-weight:bold;cursor:pointer;">🖨️ طباعة حزمة الحصة A4</button></div>' +
          '<h1 style="font-size:20px;color:#0369a1;">⚡ حزمة الحصة المتكاملة: ' + esc(M.name + " — " + G.name) + '</h1>' +
          '<h2>1️⃣ خطة الدرس والهدف السلوكي (' + esc(pageData.unitTitle) + ')</h2>' +
          '<p>' + esc(pageData.boxPoints.join(" • ")) + '</p>' +
          '<h2>2️⃣ ورقة العمل التطبيقية</h2><p>' + esc(pageData.activityBody) + '</p>' +
          '<h2>3️⃣ الاختبار القصير ومفتاح الإجابة</h2><ol>' + qHtml + '</ol>' +
          '</body></html>';
        w.document.open(); w.document.write(pkHtml); w.document.close();
      });
    }

    var expBtn = document.getElementById("btnOrgExpandRead");
    if (expBtn) {
      expBtn.addEventListener("click", function () {
        state.isExpandedReading = !state.isExpandedReading;
        renderMainOrganizer();
        focusAndScrollTo("orgActiveContentCard");
      });
    }

    var prevBtn = document.getElementById("btnOrgPrevPage");
    var nextBtn = document.getElementById("btnOrgNextPage");
    var saveBmBtn = document.getElementById("btnOrgSaveBm");

    if (prevBtn) {
      prevBtn.addEventListener("click", function () {
        var np = Math.max(1, pageData.page - 1);
        bookmarks[M.id] = { page: np, note: (bookmarks[M.id] && bookmarks[M.id].note) || "" };
        saveBookmarks();
        recordPageReadToday();
        renderMainOrganizer();
        focusAndScrollTo("orgBookPagePaper", "◀ انتقلت إلى صفحة " + np + " — تغيّر محتوى الصفحة");
      });
    }
    if (nextBtn) {
      nextBtn.addEventListener("click", function () {
        var np = Math.min(pageData.totalPages, pageData.page + 1);
        bookmarks[M.id] = { page: np, note: (bookmarks[M.id] && bookmarks[M.id].note) || "" };
        saveBookmarks();
        recordPageReadToday();
        renderMainOrganizer();
        focusAndScrollTo("orgBookPagePaper", "▶ انتقلت إلى صفحة " + np + " — تم عرض درس ومحتوى الصفحة الجديدة ✓");
      });
    }
    if (saveBmBtn) {
      saveBmBtn.addEventListener("click", function () {
        var pInp = document.getElementById("inpOrgPageNum");
        var p = pInp ? Math.min(pageData.totalPages, Math.max(1, parseInt(pInp.value, 10) || 1)) : 1;
        bookmarks[M.id] = { page: p, note: "" };
        saveBookmarks();
        renderMainOrganizer();
        focusAndScrollTo("orgBookPagePaper", "📌 تم فتح وحفظ صفحة " + p + " ✓");
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-jumpbook]"), function (b) {
      b.addEventListener("click", function () {
        var parts = (b.getAttribute("data-org-jumpbook") || "").split("|");
        if (parts.length === 4) {
          state.stageId = parts[0];
          state.gradeId = parts[1];
          state.branchId = parts[2];
          state.subjectId = parts[3];
          state.topNav = "curriculum";
          state.curriculumSubTab = "textbook";
          state.activeStudyMode = "book";
          state.quickSearch = "";
          renderMainOrganizer();
          var newSel = getSelection();
          focusAndScrollTo("orgBookPagePaper", "📖 تم فتح كتاب «" + newSel.subject.name + "» ✓");
        }
      });
    } );

    // =========================================================================
    // أحداث لوحة الإدارة ونظام الصلاحيات المتقدم
    // =========================================================================
    var unlockBtn = document.getElementById("btnOrgUnlockAdmin");
    var pinEntryInp = document.getElementById("inpOrgAdminPinEntry");
    var togAdminPinBtn = document.getElementById("btnToggleAdminPinVis");
    if (togAdminPinBtn && pinEntryInp) {
      togAdminPinBtn.addEventListener("click", function () {
        pinEntryInp.type = pinEntryInp.type === "password" ? "text" : "password";
      });
    }
    function performAdminPinUnlock() {
      if (!checkLoginRateLimit()) return;
      var pinInp = document.getElementById("inpOrgAdminPinEntry");
      if (!pinInp || !pinMatches(pinInp.value)) {
        recordFailedAttempt();
        toast("❌ الرمز غير صحيح — أو لم تسجّل الدخول بحساب Google الخاص بالإدارة (مطلوب لفتح الإدارة)", "error");
        return;
      }
      resetFailedAttempts();
      state.isAdminUnlocked = true;
      try { localStorage.setItem(ADMIN_MODE_KEY, "1"); } catch (e) {}
      if (typeof window.setSuperAdminMode === "function") window.setSuperAdminMode(true);
      syncHeaderAuthUI();
      renderMainOrganizer();
      focusAndScrollTo("orgAdminSectionBox", "👑 تم تفعيل سلطة الإدارة العليا وبسط السيطرة الكاملة ✓");
    }
    if (unlockBtn) {
      unlockBtn.addEventListener("click", performAdminPinUnlock);
    }
    if (pinEntryInp) {
      pinEntryInp.addEventListener("keydown", function (ev) {
        if (ev.key === "Enter") {
          ev.preventDefault();
          performAdminPinUnlock();
        }
      });
    }
    var admGoogleBtn = document.getElementById("btnOrgAdminGoogleSignIn");
    if (admGoogleBtn) {
      admGoogleBtn.addEventListener("click", function () {
        if (typeof window.startDirectGoogleSignIn === "function") {
          window.startDirectGoogleSignIn(false);
        } else if (window.Cloud && typeof window.Cloud.signIn === "function") {
          window.Cloud.signIn(false).catch(function () {});
        }
      });
    }
    var healNowBtn = document.getElementById("btnAdmRunSelfHealNow");
    if (healNowBtn) {
      healNowBtn.addEventListener("click", function () {
        var fixed = (window.EduDiag && window.EduDiag.selfHeal) ? window.EduDiag.selfHeal() : 0;
        if (window.EduDiag && window.EduDiag.clearErrors) window.EduDiag.clearErrors();
        renderMainOrganizer();
        toast("🛡️ تم فحص وإصلاح الذاكرة المحلية وتصفير سجل الأخطاء (" + fixed + " معالجة) ✓", "success");
      });
    }
    var purgeSwBtn = document.getElementById("btnAdmPurgeSwCacheNow");
    if (purgeSwBtn) {
      purgeSwBtn.addEventListener("click", function () {
        if (window.EduDiag && window.EduDiag.purgeCache) window.EduDiag.purgeCache();
      });
    }

    var pushCloudBtn = document.getElementById("btnAdmPushCloudNow");
    if (pushCloudBtn) pushCloudBtn.addEventListener("click", pushAccessNow);

    var lockBtn = document.getElementById("btnOrgLockAdmin");
    if (lockBtn) {
      lockBtn.addEventListener("click", function () {
        state.isAdminUnlocked = false;
        state.impersonatingUserEmail = "";
        state.topNav = "curriculum";
        try { localStorage.setItem(ADMIN_MODE_KEY, "0"); } catch (e) {}
        if (typeof window.setSuperAdminMode === "function") window.setSuperAdminMode(false);
        syncHeaderAuthUI();
        renderMainOrganizer();
        focusAndScrollTo("orgStepStagesBox", "🔒 تم قفل وإخفاء لوحة الإدارة عن الواجهة العامة ✓");
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-admintab]"), function (b) {
      b.addEventListener("click", function () {
        state.adminTab = b.getAttribute("data-org-admintab") || "permissions_mgr";
        pushNavHistory();
        renderMainOrganizer();
        if (state.adminTab === "sources_brain") {
          focusAndScrollTo("sourcesStudio", "🗄️ تم فتح «مصادري وقاعدة البيانات» داخل لوحة الإدارة ✓");
        }
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-adm-permmode]"), function (b) {
      b.addEventListener("click", function () {
        state.adminPermSubMode = b.getAttribute("data-adm-permmode") || "user_specific";
        renderMainOrganizer();
      });
    });

    var admCreateUserBtn = document.getElementById("btnAdmCreateUserNow");
    if (admCreateUserBtn) {
      admCreateUserBtn.addEventListener("click", function () {
        var n = ((document.getElementById("inpAdmCreateUserName") || {}).value || "").trim();
        var em = ((document.getElementById("inpAdmCreateUserEmail") || {}).value || "").trim().toLowerCase();
        var ps = ((document.getElementById("inpAdmCreateUserPass") || {}).value || "123456").trim();
        var rl = ((document.getElementById("selAdmCreateUserRole") || {}).value || "معلم");
        var md = ((document.getElementById("selAdmCreateUserMode") || {}).value || "custom");
        if (!n || !em || em.indexOf("@") === -1) {
          toast("⚠️ يرجى إدخال اسم العضو وبريده الإلكتروني بشكل صحيح", "warning");
          return;
        }
        registeredUsers = registeredUsers.filter(function (u) { return u.email !== em; });
        var newU = {
          name: n,
          email: em,
          pass: ps || "123456",
          roleLabel: rl,
          gradeId: rl === "توجيهي" ? "g12" : (rl === "جامعي" ? "uni-cv" : "g10"),
          gradeName: rl === "توجيهي" ? "الصف الثاني عشر (التوجيهي)" : (rl === "جامعي" ? "المرحلة الجامعية" : "الصف العاشر الأساسي"),
          school: "مضاف عبر إدارة المنصة",
          createdAt: getTodayKey()
        };
        registeredUsers.unshift(newU);
        saveUsers();
        var rec = getUserPermRecord(em);
        rec.mode = md;
        saveAdminPerms();
        state.selectedAdminUserEmail = em;
        renderMainOrganizer();
        toast("✅ تمت إضافة العضو «" + n + "» وفتح لوحة تخصيص أدواته فوراً!", "success");
      });
    }

    var admUserSearchInp = document.getElementById("inpAdmUserSearch");
    if (admUserSearchInp) {
      admUserSearchInp.addEventListener("input", function () {
        var pos = admUserSearchInp.selectionStart;
        state.adminUserSearch = admUserSearchInp.value;
        renderMainOrganizer();
        var nInp = document.getElementById("inpAdmUserSearch");
        if (nInp) { nInp.focus(); try { nInp.setSelectionRange(pos, pos); } catch (e) {} }
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-adm-pickuser]"), function (card) {
      card.addEventListener("click", function (ev) {
        if (ev.target && ev.target.closest("[data-adm-deluser]")) return;
        state.selectedAdminUserEmail = card.getAttribute("data-adm-pickuser") || "";
        renderMainOrganizer();
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-adm-deluser]"), function (b) {
      b.addEventListener("click", function (ev) {
        ev.stopPropagation();
        var delEmail = b.getAttribute("data-adm-deluser");
        if (!delEmail) return;
        registeredUsers = registeredUsers.filter(function (u) { return u.email !== delEmail; });
        if (currentUser && currentUser.email === delEmail) {
          currentUser = null;
          saveCurrentUser();
        }
        if (state.selectedAdminUserEmail === delEmail) {
          state.selectedAdminUserEmail = registeredUsers[0] ? registeredUsers[0].email : "";
        }
        saveUsers();
        renderMainOrganizer();
        toast("🗑️ تم حذف العضو من سجلات المنصة", "info");
      });
    });

    var roleChgSel = document.getElementById("selAdmUserRoleChange");
    if (roleChgSel) {
      roleChgSel.addEventListener("change", function () {
        var newR = roleChgSel.value;
        registeredUsers.forEach(function (u) {
          if (u.email === state.selectedAdminUserEmail) u.roleLabel = newR;
        });
        if (currentUser && currentUser.email === state.selectedAdminUserEmail) {
          currentUser.roleLabel = newR;
          saveCurrentUser();
        }
        saveUsers();
        renderMainOrganizer();
        toast("👤 تم تغيير فئة العضو إلى «" + newR + "» وتحديث صلاحياته الافتراضية ✓", "success");
      });
    }

    var impBtn = document.getElementById("btnAdmImpersonateUser");
    if (impBtn) {
      impBtn.addEventListener("click", function () {
        if (!state.selectedAdminUserEmail) return;
        state.impersonatingUserEmail = state.selectedAdminUserEmail;
        state.topNav = "tools";
        renderMainOrganizer();
        focusAndScrollTo("orgToolsSectionBox", "👁️ أنت الآن تعاين بوابة الأدوات بصلاحيات العضو المختار");
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-adm-userpack]"), function (b) {
      b.addEventListener("click", function () {
        var pk = b.getAttribute("data-adm-userpack");
        var em = state.selectedAdminUserEmail;
        if (!em) return;
        var rec = getUserPermRecord(em);
        if (pk === "vip_all") {
          rec.mode = "vip_all";
          rec.blockedTools = [];
          toast("🌟 تم منح العضو وصولاً شاملاً (VIP) لجميع أدوات الموقع ✓", "success");
        } else if (pk === "suspended") {
          rec.mode = rec.mode === "suspended" ? "custom" : "suspended";
          toast(rec.mode === "suspended" ? "⛔ تم إيقاف وحجب جميع الأدوات عن هذا العضو" : "✅ تم إلغاء إيقاف الحساب", "info");
        } else if (pk === "grant_all_custom") {
          rec.mode = "custom";
          rec.grantedTools = MASTER_TOOLS_CATALOG.map(function (t) { return t.id; });
          rec.blockedTools = [];
          toast("✅ تم منح جميع الـ " + MASTER_TOOLS_CATALOG.length + " أداة لهذا العضو ✓", "success");
        } else if (pk === "block_all_custom") {
          rec.mode = "custom";
          rec.grantedTools = [];
          rec.blockedTools = MASTER_TOOLS_CATALOG.map(function (t) { return t.id; });
          toast("🚫 تم حجب جميع الأدوات عن هذا العضو", "warning");
        } else if (pk === "teacher_pack") {
          rec.mode = "custom";
          rec.blockedTools = [];
          rec.grantedTools = MASTER_TOOLS_CATALOG.filter(function (t) { return t.cat === "teacher" || t.cat === "admin_class" || t.cat === "ai"; }).map(function (t) { return t.id; });
          toast("🧑‍🏫 تم منح حزمة أدوات المعلم والإدارة الصفية كاملة لهذا العضو ✓", "success");
        } else if (pk === "student_pack") {
          rec.mode = "custom";
          rec.blockedTools = [];
          rec.grantedTools = MASTER_TOOLS_CATALOG.filter(function (t) { return t.cat === "student" || t.cat === "labs" || t.cat === "university"; }).map(function (t) { return t.id; });
          toast("🎓 تم منح حزمة أدوات الطالب والمختبرات والجامعة لهذا العضو ✓", "success");
        } else if (pk === "reset_default") {
          rec.mode = "custom";
          rec.grantedTools = [];
          rec.blockedTools = [];
          toast("🔄 تمت إعادة صلاحيات العضو للوضع الافتراضي حسب فئته ✓", "info");
        }
        saveAdminPerms();
        renderMainOrganizer();
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-adm-toolcat]"), function (b) {
      b.addEventListener("click", function () {
        state.adminToolFilterCat = b.getAttribute("data-adm-toolcat") || "all";
        renderMainOrganizer();
      });
    });

    var admToolSearchInp = document.getElementById("inpAdmToolSearch");
    if (admToolSearchInp) {
      admToolSearchInp.addEventListener("input", function () {
        var pos = admToolSearchInp.selectionStart;
        state.adminToolSearch = admToolSearchInp.value;
        renderMainOrganizer();
        var nInp = document.getElementById("inpAdmToolSearch");
        if (nInp) { nInp.focus(); try { nInp.setSelectionRange(pos, pos); } catch (e) {} }
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-adm-setusertool]"), function (b) {
      b.addEventListener("click", function () {
        var pts = (b.getAttribute("data-adm-setusertool") || "").split(":");
        var tid = pts[0], act = pts[1];
        var em = state.selectedAdminUserEmail;
        if (!em || !tid) return;
        var rec = getUserPermRecord(em);
        rec.mode = "custom";
        rec.grantedTools = rec.grantedTools.filter(function (x) { return x !== tid; });
        rec.blockedTools = rec.blockedTools.filter(function (x) { return x !== tid; });
        if (act === "grant") {
          rec.grantedTools.push(tid);
          logPermAudit("منح أداة «" + (TOOL_MAP[tid] ? TOOL_MAP[tid].title : tid) + "» للعضو " + em);
          toast("✅ تم منح الأداة «" + (TOOL_MAP[tid] ? TOOL_MAP[tid].title : tid) + "» للعضو المختار", "success");
        } else if (act === "block") {
          rec.blockedTools.push(tid);
          logPermAudit("حجب أداة «" + (TOOL_MAP[tid] ? TOOL_MAP[tid].title : tid) + "» عن العضو " + em);
          toast("🚫 تم حجب الأداة «" + (TOOL_MAP[tid] ? TOOL_MAP[tid].title : tid) + "» عن العضو المختار", "warning");
        } else {
          toast("🔄 تم إرجاع الأداة للوضع الافتراضي للفئة", "info");
        }
        saveAdminPerms();
        renderMainOrganizer();
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-adm-pickrole]"), function (b) {
      b.addEventListener("click", function () {
        state.selectedAdminRoleKey = b.getAttribute("data-adm-pickrole") || "طالب";
        renderMainOrganizer();
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-adm-toggleroletool]"), function (b) {
      b.addEventListener("click", function () {
        var tid = b.getAttribute("data-adm-toggleroletool");
        var rk = state.selectedAdminRoleKey || "طالب";
        if (!adminPerms.rolePolicies) adminPerms.rolePolicies = buildDefaultRolePolicies();
        if (!adminPerms.rolePolicies[rk]) adminPerms.rolePolicies[rk] = {};
        var cur = typeof adminPerms.rolePolicies[rk][tid] === "boolean"
          ? adminPerms.rolePolicies[rk][tid]
          : ((TOOL_MAP[tid] && TOOL_MAP[tid].defaultRoles || []).indexOf(rk) !== -1);
        adminPerms.rolePolicies[rk][tid] = !cur;
        saveAdminPerms();
        renderMainOrganizer();
        toast("🛡️ تم تحديث صلاحية الأداة لفئة «" + rk + "» ✓", "success");
      });
    });

    var rAllowAllBtn = document.getElementById("btnAdmRoleAllowAll");
    if (rAllowAllBtn) {
      rAllowAllBtn.addEventListener("click", function () {
        var rk = state.selectedAdminRoleKey || "طالب";
        if (!adminPerms.rolePolicies[rk]) adminPerms.rolePolicies[rk] = {};
        MASTER_TOOLS_CATALOG.forEach(function (t) { adminPerms.rolePolicies[rk][t.id] = true; });
        saveAdminPerms();
        renderMainOrganizer();
        toast("✅ تم إتاحة جميع الأدوات افتراضياً لفئة «" + rk + "» ✓", "success");
      });
    }

    var rBlockAllBtn = document.getElementById("btnAdmRoleBlockAll");
    if (rBlockAllBtn) {
      rBlockAllBtn.addEventListener("click", function () {
        var rk = state.selectedAdminRoleKey || "طالب";
        if (!adminPerms.rolePolicies[rk]) adminPerms.rolePolicies[rk] = {};
        MASTER_TOOLS_CATALOG.forEach(function (t) { adminPerms.rolePolicies[rk][t.id] = false; });
        saveAdminPerms();
        renderMainOrganizer();
        toast("🚫 تم حجب جميع الأدوات افتراضياً عن فئة «" + rk + "»", "warning");
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-adm-reqact]"), function (b) {
      b.addEventListener("click", function () {
        var pts = (b.getAttribute("data-adm-reqact") || "").split(":");
        var rid = pts[0], act = pts[1];
        var req = (adminPerms.accessRequests || []).filter(function (r) { return r.id === rid; })[0];
        if (!req) return;
        var rec = getUserPermRecord(req.userEmail);
        if (act === "approve") {
          req.status = "approved";
          rec.blockedTools = rec.blockedTools.filter(function (x) { return x !== req.toolId; });
          if (rec.grantedTools.indexOf(req.toolId) === -1) rec.grantedTools.push(req.toolId);
          toast("✅ تمت الموافقة ومنح الأداة «" + req.toolTitle + "» للعضو " + req.userName, "success");
        } else if (act === "vip") {
          req.status = "approved";
          rec.mode = "vip_all";
          rec.blockedTools = [];
          toast("🌟 تم منح العضو " + req.userName + " وصولاً كاملاً لكل الأدوات!", "success");
        } else {
          req.status = "rejected";
          if (rec.blockedTools.indexOf(req.toolId) === -1) rec.blockedTools.push(req.toolId);
          toast("❌ تم رفض الطلب وحجب الأداة", "info");
        }
        saveAdminPerms();
        renderMainOrganizer();
      });
    });

    var saveSubUpdBtn = document.getElementById("btnAdmSaveSubUpdate");
    if (saveSubUpdBtn) {
      saveSubUpdBtn.addEventListener("click", function () {
        var tInp = document.getElementById("inpAdmSubTitle");
        var oInp = document.getElementById("inpAdmOfficialUrl");
        var dInp = document.getElementById("inpAdmDriveLink");
        var pInp = document.getElementById("inpAdmTotalPages");
        var uInp = document.getElementById("inpAdmNewUnit");
        if (tInp && tInp.value.trim()) M.bookTitle = tInp.value.trim();
        if (oInp) M.officialUrl = oInp.value.trim();
        if (dInp) M.driveUrl = dInp.value.trim();
        if (pInp && parseInt(pInp.value, 10) >= 20) M.totalPages = parseInt(pInp.value, 10);
        if (uInp && uInp.value.trim()) {
          M.units = M.units || [];
          M.units.push(uInp.value.trim());
        }
        saveTree();
        renderMainOrganizer();
        toast("✅ تم حفظ التعديلات وتحديث مادة «" + M.name + "» بنجاح ✓", "success");
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-adm-delunit]"), function (b) {
      b.addEventListener("click", function () {
        var idx = parseInt(b.getAttribute("data-adm-delunit"), 10);
        if (M.units && M.units.length > 1 && idx >= 0 && idx < M.units.length) {
          M.units.splice(idx, 1);
          saveTree();
          renderMainOrganizer();
          toast("🗑️ تم حذف الوحدة المحددة", "info");
        } else {
          toast("⚠️ يجب إبقاء وحدة واحدة على الأقل في المادة", "warning");
        }
      });
    });

    var addSubBtn = document.getElementById("btnAdmAddNewSubject");
    if (addSubBtn) {
      addSubBtn.addEventListener("click", function () {
        var sInp = document.getElementById("inpAdmAddSubName");
        var name = sInp ? sInp.value.trim() : "";
        if (!name) return;
        var newId = "custom-" + Date.now();
        B.subjects.push({
          id: newId,
          name: name,
          ico: "📘",
          bookTitle: name + " — " + G.name,
          totalPages: 120,
          officialUrl: G.officialPortal || "https://elearn.edu.ps/",
          units: ["الوحدة 1: مدخل إلى " + name],
          rules: ["القواعد الأساسية لمبحث " + name]
        });
        state.subjectId = newId;
        saveTree();
        renderMainOrganizer();
        toast("➕ تمت إضافة مادة «" + name + "» إلى " + G.name + " ✓", "success");
      });
    }

    var resetTreeBtn = document.getElementById("btnAdmResetOfficialTree");
    if (resetTreeBtn) {
      resetTreeBtn.addEventListener("click", function () {
        masterTree = JSON.parse(JSON.stringify(DEFAULT_MASTER_TREE));
        saveTree();
        renderMainOrganizer();
        toast("🔄 تمت استعادة المنهاج الفلسطيني الرسمي بنجاح ✓", "success");
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-adm-toggleperm]"), function (b) {
      b.addEventListener("click", function () {
        var k = b.getAttribute("data-adm-toggleperm");
        adminPerms[k] = !adminPerms[k];
        saveAdminPerms();
        renderMainOrganizer();
        toast("🛡️ تم تحديث الصلاحية بنجاح ✓", "success");
      });
    });

    var annBtn = document.getElementById("btnAdmSaveAnnounce");
    if (annBtn) {
      annBtn.addEventListener("click", function () {
        var aInp = document.getElementById("inpAdmAnnounceText");
        if (aInp) adminPerms.announcementText = aInp.value.trim();
        adminPerms.announcementActive = !adminPerms.announcementActive;
        saveAdminPerms();
        renderMainOrganizer();
        toast(adminPerms.announcementActive ? "📢 تم تفعيل شريط الإعلان للجميع ✓" : "🔕 تم إيقاف شريط الإعلان", "info");
      });
    }

    var pinBtn = document.getElementById("btnAdmSavePin");
    if (pinBtn) {
      pinBtn.addEventListener("click", function () {
        var pInp = document.getElementById("inpAdmSetPin");
        var newPin = pInp ? pInp.value.trim() : "";
        delete adminPerms.adminPin;
        if (newPin) {
          adminPerms.customPinHash = sha256Hex("edutech-mindset|" + newPin);
          if (pInp) pInp.value = "";
          saveAdminPerms();
          toast("🔐 تم تشفير وحفظ رمز حماية الإدارة الجديد (SHA-256) بنجاح ✓", "success");
        } else {
          delete adminPerms.customPinHash;
          saveAdminPerms();
          toast("🔄 تمت استعادة رمز الحماية السيادي الافتراضي للإدارة ✓", "info");
        }
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-adm-openstudio]"), function (b) {
      b.addEventListener("click", function () {
        var sid = b.getAttribute("data-adm-openstudio");
        state.openedAdminStudioId = sid;
        renderMainOrganizer();
        focusAndScrollTo(sid, "🛠️ تم فتح الاستوديو الإداري ✓");
      });
    });

    var expBackupBtn = document.getElementById("btnAdmExportBackup");
    if (expBackupBtn) {
      expBackupBtn.addEventListener("click", function () {
        var payload = {
          version: 135,
          tree: masterTree,
          bookmarks: bookmarks,
          pageNotes: pageNotes,
          registeredUsers: registeredUsers,
          adminPerms: adminPerms
        };
        var blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
        var a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = "edutech_mindset_backup_v135.json";
        a.click();
        toast("⬇️ تم تصدير النسخة الاحتياطية الشاملة (JSON) ✓", "success");
      });
    }

    var impBackupInp = document.getElementById("inpAdmImportBackup");
    if (impBackupInp) {
      impBackupInp.addEventListener("change", function (e) {
        var file = e.target.files && e.target.files[0];
        if (!file) return;
        var reader = new FileReader();
        reader.onload = function () {
          try {
            var data = JSON.parse(reader.result);
            if (Array.isArray(data.tree)) { masterTree = data.tree; saveTree(); }
            if (data.bookmarks) { bookmarks = data.bookmarks; saveBookmarks(); }
            if (data.pageNotes) { pageNotes = data.pageNotes; savePageNotes(); }
            if (Array.isArray(data.registeredUsers)) { registeredUsers = data.registeredUsers; saveUsers(); }
            if (data.adminPerms) { adminPerms = Object.assign(adminPerms, data.adminPerms); saveAdminPerms(); }
            renderMainOrganizer();
            toast("⬆️ تم استيراد النسخة الاحتياطية والصلاحيات بنجاح ✓", "success");
          } catch (err) {
            toast("❌ ملف النسخة الاحتياطية غير صالح", "error");
          }
        };
        reader.readAsText(file);
      });
    }

    var pubCultBtn = document.getElementById("btnAdmPublishCultBook");
    if (pubCultBtn) {
      pubCultBtn.addEventListener("click", function () {
        var tInp = document.getElementById("inpAdmCultTitle");
        var uInp = document.getElementById("inpAdmCultUrl");
        var title = tInp ? tInp.value.trim() : "";
        if (!title) return;
        var cultStg = masterTree.filter(function (s) { return s.id === "stage-cultural"; })[0];
        if (cultStg && cultStg.grades && cultStg.grades[0] && cultStg.grades[0].branches && cultStg.grades[0].branches[0]) {
          cultStg.grades[0].branches[0].subjects.push({
            id: "cult-" + Date.now(),
            name: title,
            ico: "📕",
            bookTitle: title,
            totalPages: 140,
            driveUrl: uInp ? uInp.value.trim() : "",
            units: ["الفصل 1: مقدمة وأفكار الكتاب الرئيسية", "الفصل 2: التطبيقات والملخص"],
            rules: ["المرجع الثقافي العام: " + title]
          });
          saveTree();
          renderMainOrganizer();
          toast("📚 تم نشر كتاب «" + title + "» في المكتبة الشاملة للجميع ✓", "success");
        }
      });
    }

    // =========================================================================
    // أحداث بوابة التسجيل والدخول والحساب
    // =========================================================================
    var tLogin = document.getElementById("btnAuthTabLogin");
    if (tLogin) tLogin.addEventListener("click", function () { state.authMode = "login"; renderMainOrganizer(); });
    var tReg = document.getElementById("btnAuthTabRegister");
    if (tReg) tReg.addEventListener("click", function () { state.authMode = "register"; renderMainOrganizer(); });
    var tDemo = document.getElementById("btnAuthTabDemo");
    if (tDemo) tDemo.addEventListener("click", function () { state.authMode = "demo"; renderMainOrganizer(); });

    Array.prototype.forEach.call(root.querySelectorAll("[data-org-quicklogin]"), function (b) {
      b.addEventListener("click", function () {
        var em = b.getAttribute("data-org-quicklogin");
        var found = registeredUsers.filter(function (u) { return u.email === em; })[0];
        if (found) {
          currentUser = found;
          state.impersonatingUserEmail = "";
          saveCurrentUser();
          renderMainOrganizer();
          toast("🔑 تم تسجيل الدخول بحساب «" + found.name + "» (" + found.roleLabel + ") ✓", "success");
        }
      });
    });

    function executeDirectLogin(rawEmailInput, passInput) {
      if (!checkLoginRateLimit()) return false;
      var rawEmail = String(rawEmailInput || "").trim().toLowerCase();
      var email = rawEmail.indexOf("@") === -1 && rawEmail ? rawEmail + "@edutech.ps" : rawEmail;
      var pass = String(passInput == null ? "" : passInput);
      if (!rawEmail || !pass) {
        toast("⚠️ يرجى إدخال البريد الإلكتروني أو اسم المستخدم وكلمة المرور", "warning");
        return false;
      }
      var admEmails = (window.EDUTECH_ADMIN_EMAILS || ["baselashraf800@gmail.com", "edutechm1994@gmail.com"]).map(function (s) { return s.toLowerCase().trim(); });
      if (admEmails.indexOf(rawEmail) !== -1 || admEmails.indexOf(email) !== -1 || rawEmail === "admin" || rawEmail === "basel") {
        if (pinMatches(pass)) {
          resetFailedAttempts();
          var admEmailFinal = admEmails.indexOf(rawEmail) !== -1 ? rawEmail : admEmails[0];
          var admUser = {
            name: "الأستاذ باسل أشرف الفقعاوي (الإدارة العليا 👑)",
            email: admEmailFinal,
            passHash: hashUserPass(admEmailFinal, pass),
            roleLabel: "معلم",
            gradeId: "g12",
            gradeName: "الإشراف العام والتوجيهي",
            school: "مؤسس ومدير منصة EduTech Mindset"
          };
          currentUser = admUser;
          state.impersonatingUserEmail = "";
          state.isAdminUnlocked = true;
          try { localStorage.setItem(ADMIN_MODE_KEY, "1"); } catch (e) {}
          if (typeof window.setSuperAdminMode === "function") window.setSuperAdminMode(true);
          saveCurrentUser();
          state.topNav = "admin";
          renderMainOrganizer();
          toast("👑 أهلاً بالأستاذ باسل الفقعاوي! تم فتح القيادة السيادية للإدارة العليا بالكامل ✓", "success");
          return true;
        }
      }
      // فحص إن كان المستخدم أدخل كود تفعيل مباشرة في خانة كلمة المرور أو البريد
      var upperPass = pass.trim().toUpperCase();
      var matchingCode = (adminPerms.activationCodes || []).filter(function (c) {
        return c && c.active !== false && String(c.code || "").toUpperCase() === upperPass;
      })[0];
      var found = registeredUsers.filter(function (u) {
        var uEm = String(u.email || "").toLowerCase().trim();
        var uShort = uEm.split("@")[0];
        return (uEm === email || uEm === rawEmail || uShort === rawEmail) && verifyUserPass(u, pass);
      })[0];
      if (!found && matchingCode) {
        // إنشاء/فتح حساب فوري بالبريد المدخل وتفعيل الكود له
        var newCodeUser = {
          name: rawEmail.split("@")[0] || "عضو مفعل بالكود",
          email: email,
          passHash: hashUserPass(email, pass),
          roleLabel: matchingCode.code.indexOf("TEACHER") !== -1 ? "معلم" : (matchingCode.code.indexOf("UNI") !== -1 ? "جامعي" : "توجيهي"),
          gradeId: "g12",
          gradeName: "الصف الثاني عشر (التوجيهي)",
          school: "فلسطين 🇵🇸",
          createdAt: getTodayKey()
        };
        registeredUsers = registeredUsers.filter(function (u) { return u.email !== email; });
        registeredUsers.unshift(newCodeUser);
        currentUser = newCodeUser;
        resetFailedAttempts();
        saveUsers();
        saveCurrentUser();
        redeemActivationCodeForUser(matchingCode.code, newCodeUser);
        return true;
      }
      if (!found) {
        recordFailedAttempt();
        toast("❌ البريد الإلكتروني أو كلمة المرور غير صحيحة — يمكنك استعادة كلمة المرور أو اختيار الدخول السريع التجريبي", "error");
        return false;
      }
      resetFailedAttempts();
      currentUser = found;
      state.impersonatingUserEmail = "";
      saveUsers();
      saveCurrentUser();
      renderMainOrganizer();
      toast("🔑 تم تسجيل الدخول بنجاح — مرحباً " + found.name + " ✓", "success");
      return true;
    }

    var subReg = document.getElementById("btnAuthSubmitRegister");
    if (subReg) {
      subReg.addEventListener("click", function () {
        if (adminPerms.registrationMode === "closed" && !isEffectiveSuperAdmin()) {
          toast("🔒 التسجيل الذاتي مغلق حالياً بقرار من الإدارة العليا — تواصل مع الإدارة لإضافة حسابك", "warning");
          return;
        }
        var name = ((document.getElementById("inpAuthName") || {}).value || "").trim();
        var rawEmail = ((document.getElementById("inpAuthEmail") || {}).value || "").trim().toLowerCase();
        var email = rawEmail.indexOf("@") === -1 ? (rawEmail ? rawEmail + "@edutech.ps" : "") : rawEmail;
        var pass = (document.getElementById("inpAuthPass") || {}).value || "";
        var school = ((document.getElementById("inpAuthSchool") || {}).value || "").trim();
        var roleSel = document.getElementById("selAuthRole");
        var gradeSel = document.getElementById("selAuthGrade");
        var invCode = ((document.getElementById("inpAuthInviteCode") || {}).value || "").trim();
        if (!name || !email || pass.length < 4) {
          toast("⚠️ يرجى إدخال الاسم الكامل، البريد أو اسم المستخدم، وكلمة مرور من 4 أحرف فأكثر", "warning");
          return;
        }
        if (adminPerms.registrationMode === "code_only" && !invCode && !isEffectiveSuperAdmin()) {
          toast("🎟️ تشترط الإدارة إدخال كود دعوة/تفعيل صالح لإتمام التسجيل", "warning");
          return;
        }
        var userObj = {
          name: name,
          email: email,
          passHash: hashUserPass(email, pass),
          school: school || "فلسطين 🇵🇸",
          roleLabel: roleSel ? roleSel.value : "طالب",
          gradeId: gradeSel ? gradeSel.value : "g4",
          gradeName: gradeSel && gradeSel.options[gradeSel.selectedIndex] ? gradeSel.options[gradeSel.selectedIndex].text : "الصف الرابع الأساسي",
          createdAt: getTodayKey()
        };
        registeredUsers = registeredUsers.filter(function (u) { return u.email !== email; });
        registeredUsers.unshift(userObj);
        currentUser = userObj;
        state.selectedAdminUserEmail = email;
        saveUsers();
        saveCurrentUser();
        logPermAudit("تسجيل عضو جديد في المنصة: " + name + " (" + email + ")");
        saveAdminPerms();
        if (invCode) {
          redeemActivationCodeForUser(invCode, userObj);
        } else {
          renderMainOrganizer();
          toast("🎉 أهلاً بك يا " + name + "! تم إنشاء حسابك وتشفير بياناتك وتفعيل صلاحياتك فوراً ✓", "success");
        }
      });
    }

    var subLogin = document.getElementById("btnAuthSubmitLogin");
    if (subLogin) {
      subLogin.addEventListener("click", function () {
        var rawEmail = ((document.getElementById("inpAuthLoginEmail") || {}).value || "");
        var pass = (document.getElementById("inpAuthLoginPass") || {}).value || "";
        executeDirectLogin(rawEmail, pass);
      });
    }

    ["inpAuthLoginEmail", "inpAuthLoginPass"].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) {
        el.addEventListener("keydown", function (ev) {
          if (ev.key === "Enter") {
            ev.preventDefault();
            if (subLogin) subLogin.click();
          }
        });
      }
    });

    ["inpAuthName", "inpAuthEmail", "inpAuthPass", "inpAuthInviteCode"].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) {
        el.addEventListener("keydown", function (ev) {
          if (ev.key === "Enter") {
            ev.preventDefault();
            if (subReg) subReg.click();
          }
        });
      }
    });

    var togPassVis = document.getElementById("btnToggleLoginPassVis");
    if (togPassVis) {
      togPassVis.addEventListener("click", function () {
        var p = document.getElementById("inpAuthLoginPass");
        if (p) p.type = p.type === "password" ? "text" : "password";
      });
    }

    var forgotBtn = document.getElementById("btnAuthForgotPass");
    if (forgotBtn) {
      forgotBtn.addEventListener("click", function () {
        var box = document.getElementById("authPassRecoveryBox");
        if (box) box.classList.toggle("hidden");
      });
    }

    var confirmRecBtn = document.getElementById("btnConfirmRecoverPass");
    if (confirmRecBtn) {
      confirmRecBtn.addEventListener("click", function () {
        var rawEm = ((document.getElementById("inpAuthLoginEmail") || {}).value || "").trim().toLowerCase();
        var email = rawEm.indexOf("@") === -1 && rawEm ? rawEm + "@edutech.ps" : rawEm;
        var clue = ((document.getElementById("inpRecoverSchoolOrCode") || {}).value || "").trim();
        var newPass = ((document.getElementById("inpRecoverNewPass") || {}).value || "");
        if (!email || newPass.length < 4 || !clue) {
          toast("⚠️ يرجى كتابة بريدك الإلكتروني أعلاه، واسم مدرستك أو كود التفعيل، وكلمة المرور الجديدة (4 أحرف فأكثر)", "warning");
          return;
        }
        var targetU = registeredUsers.filter(function (u) { return u.email === email || u.email === rawEm; })[0];
        var validCode = (adminPerms.activationCodes || []).some(function (c) { return String(c.code || "").toUpperCase() === clue.toUpperCase(); });
        if (!targetU) {
          toast("❌ لم يتم العثور على حساب بهذا البريد — يمكنك إنشاء حساب جديد فوراً", "error");
          return;
        }
        var schoolMatch = targetU.school && targetU.school.toLowerCase().indexOf(clue.toLowerCase()) !== -1;
        var phoneMatch = targetU.phone && targetU.phone === clue;
        if (!schoolMatch && !phoneMatch && !validCode) {
          toast("❌ بيانات التحقق (اسم المدرسة أو رقم الهاتف أو كود التفعيل) غير مطابقة", "error");
          return;
        }
        targetU.passHash = hashUserPass(targetU.email, newPass);
        delete targetU.pass;
        currentUser = targetU;
        saveUsers();
        saveCurrentUser();
        renderMainOrganizer();
        toast("✅ تم استعادة حسابك وتحديث كلمة المرور المشفرة بنجاح!", "success");
      });
    }

    var fbGoogleBtn = document.getElementById("btnOrgFirebaseGoogleLogin");
    if (fbGoogleBtn) {
      fbGoogleBtn.addEventListener("click", function () {
        if (typeof window.startDirectGoogleSignIn === "function") {
          window.startDirectGoogleSignIn(false);
        } else if (window.Cloud && typeof window.Cloud.signIn === "function") {
          window.Cloud.signIn(false).catch(function () {
            toast("⚠️ تعذر فتح نافذة Google في هذا المتصفح — جرب زر «📱 للهاتف» أو الدخول المباشر أعلاه", "warning");
          });
        }
      });
    }

    var fbGoogleRedBtn = document.getElementById("btnOrgFirebaseGoogleRedirect");
    if (fbGoogleRedBtn) {
      fbGoogleRedBtn.addEventListener("click", function () {
        if (typeof window.startDirectGoogleSignIn === "function") {
          window.startDirectGoogleSignIn(true);
        } else if (window.Cloud && typeof window.Cloud.signIn === "function") {
          window.Cloud.signIn(true).catch(function () {});
        }
      });
    }

    var printIdBtn = document.getElementById("btnOrgPrintMemberIdCard");
    if (printIdBtn && activeViewerUser) {
      printIdBtn.addEventListener("click", function () {
        var w = window.open("", "_blank");
        if (!w) { toast("يرجى السماح بالنوافذ المنبثقة لطباعة بطاقة العضوية", "warning"); return; }
        var uAllow = MASTER_TOOLS_CATALOG.filter(function (t) { return evaluateToolAccessForUser(t.id, activeViewerUser, false).allowed; }).length;
        var idHtml = '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>بطاقة العضوية الرقمية — ' + esc(activeViewerUser.name) + '</title>' +
          '<style>body{font-family:"Cairo",sans-serif;background:#f1f5f9;padding:40px;text-align:center;}' +
          '.card{max-width:480px;margin:0 auto;background:linear-gradient(135deg,#0f172a,#1e1b4b,#0369a1);color:#fff;border-radius:24px;padding:28px;border:4px solid #f59e0b;box-shadow:0 20px 40px rgba(0,0,0,.25);text-align:right;}' +
          '.badge{display:inline-block;padding:4px 12px;border-radius:99px;background:rgba(245,158,11,.2);color:#fcd34d;font-size:12px;font-weight:900;border:1px solid rgba(245,158,11,.4);}' +
          '@media print{.no-print{display:none;}body{background:#fff;padding:0;}}</style></head><body>' +
          '<div class="no-print" style="margin-bottom:20px;"><button onclick="window.print()" style="padding:10px 24px;background:#0284c7;color:#fff;border:none;border-radius:12px;font-weight:900;cursor:pointer;">🖨️ طباعة بطاقة العضوية الرقمية</button></div>' +
          '<div class="card">' +
            '<div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(255,255,255,.15);padding-bottom:12px;margin-bottom:16px;">' +
              '<div><div style="font-size:16px;font-weight:900;">🇵🇸 منصة EduTech Mindset</div><div style="font-size:11px;color:#7dd3fc;">عقلية التعليم والتكنولوجيا — إشراف أ. باسل الفقعاوي</div></div>' +
              '<span class="badge">عضوية معتمدة v138</span>' +
            '</div>' +
            '<div style="font-size:20px;font-weight:900;color:#fff;margin-bottom:6px;">👤 ' + esc(activeViewerUser.name) + '</div>' +
            '<div style="font-size:13px;color:#cbd5e1;margin-bottom:4px;">📧 البريد المعرّف: <span dir="ltr" style="font-family:monospace;color:#38bdf8;">' + esc(activeViewerUser.email) + '</span></div>' +
            '<div style="font-size:13px;color:#cbd5e1;margin-bottom:4px;">🎓 الفئة / الصفة: <strong style="color:#4ade80;">' + esc(activeViewerUser.roleLabel || "عضو") + '</strong> • ' + esc(activeViewerUser.gradeName || "") + '</div>' +
            '<div style="font-size:13px;color:#cbd5e1;margin-bottom:12px;">🏫 المؤسسة: ' + esc(activeViewerUser.school || "فلسطين 🇵🇸") + '</div>' +
            '<div style="background:rgba(255,255,255,.08);padding:10px 14px;border-radius:14px;font-size:12px;display:flex;justify-content:space-between;">' +
              '<span>🔓 الصلاحيات الممنوحة: <strong>' + uAllow + ' أداة ذكية</strong></span>' +
              '<span>تاريخ الإصدار: ' + new Date().toLocaleDateString("ar-EG") + '</span>' +
            '</div>' +
          '</div></body></html>';
        w.document.open(); w.document.write(idHtml); w.document.close();
      });
    }

    var outBtn = document.getElementById("btnOrgLogoutUser");
    if (outBtn) {
      outBtn.addEventListener("click", function () {
        currentUser = null;
        state.impersonatingUserEmail = "";
        if (state.isAdminUnlocked && !(window.Cloud && window.Cloud.isAdmin)) {
          state.isAdminUnlocked = false;
          try { localStorage.setItem(ADMIN_MODE_KEY, "0"); } catch (e) {}
          if (typeof window.setSuperAdminMode === "function") window.setSuperAdminMode(false);
        }
        saveCurrentUser();
        if (window.Cloud && window.Cloud.user && typeof window.Cloud.signOut === "function") {
          try { window.Cloud.signOut(); } catch (e) {}
        }
        renderMainOrganizer();
        toast("🚪 تم تسجيل الخروج بنجاح", "info");
      });
    }

    var updAccGradeBtn = document.getElementById("btnOrgSaveAccountGrade");
    if (updAccGradeBtn && currentUser) {
      updAccGradeBtn.addEventListener("click", function () {
        var s = document.getElementById("selAccountUpdateGrade");
        var nInp = document.getElementById("inpAccEditName");
        var scInp = document.getElementById("inpAccEditSchool");
        var rSel = document.getElementById("selAccEditRole");
        if (nInp && nInp.value.trim()) currentUser.name = nInp.value.trim();
        if (scInp) currentUser.school = scInp.value.trim();
        if (rSel && rSel.value) currentUser.roleLabel = rSel.value;
        if (s) {
          currentUser.gradeId = s.value;
          currentUser.gradeName = s.options[s.selectedIndex] ? s.options[s.selectedIndex].text : s.value;
        }
        registeredUsers.forEach(function (u) {
          if (u.email === currentUser.email) {
            u.name = currentUser.name;
            u.school = currentUser.school;
            u.roleLabel = currentUser.roleLabel;
            u.gradeId = currentUser.gradeId;
            u.gradeName = currentUser.gradeName;
          }
        });
        saveUsers();
        saveCurrentUser();
        renderMainOrganizer();
        toast("✅ تم حفظ تحديثات بيانات عضويتك بنجاح ✓", "success");
      });
    }

    var goGradeBtn = document.getElementById("btnOrgGoMyGrade");
    if (goGradeBtn && currentUser) {
      goGradeBtn.addEventListener("click", function () {
        var gid = currentUser.gradeId || "g4";
        masterTree.forEach(function (st) {
          (st.grades || []).forEach(function (gr) {
            if (gr.id === gid) {
              state.stageId = st.id;
              state.gradeId = gr.id;
              state.branchId = "";
              state.subjectId = "";
            }
          });
        });
        state.topNav = "curriculum";
        state.curriculumSubTab = "textbook";
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo("orgStepSubjectsBox", "🚀 تم فتح منهاج " + (currentUser.gradeName || "صفك") + " ✓");
      });
    }

    var redeemBtn = document.getElementById("btnUserRedeemCode");
    if (redeemBtn) {
      redeemBtn.addEventListener("click", function () {
        var inp = document.getElementById("inpUserRedeemCode");
        var activeU = state.impersonatingUserEmail
          ? (registeredUsers.filter(function (u) { return u.email === state.impersonatingUserEmail; })[0] || currentUser)
          : currentUser;
        redeemActivationCodeForUser(inp ? inp.value : "", activeU);
      });
    }

    var createCodeBtn = document.getElementById("btnAdmCreateCode");
    if (createCodeBtn) {
      createCodeBtn.addEventListener("click", function () {
        var cStr = ((document.getElementById("inpAdmNewCodeStr") || {}).value || "").trim().toUpperCase();
        var cLbl = ((document.getElementById("inpAdmNewCodeLbl") || {}).value || "").trim();
        var cMode = ((document.getElementById("selAdmNewCodeMode") || {}).value || "vip_all");
        var cMax = parseInt(((document.getElementById("inpAdmNewCodeMax") || {}).value || "50"), 10) || 50;
        if (!cStr) {
          toast("⚠️ يرجى كتابة رمز الكود (مثال: EDUTECH-VIP-50)", "warning");
          return;
        }
        var toolsList = [];
        var gMode = "custom";
        if (cMode === "vip_all") {
          gMode = "vip_all";
        } else if (cMode === "teacher_pack") {
          toolsList = MASTER_TOOLS_CATALOG.filter(function (t) { return t.cat === "teacher" || t.cat === "admin_class" || t.cat === "ai"; }).map(function (t) { return t.id; });
        } else if (cMode === "tawjihi_pack") {
          toolsList = MASTER_TOOLS_CATALOG.filter(function (t) { return t.cat === "student" || t.cat === "labs"; }).map(function (t) { return t.id; });
        } else if (cMode === "uni_pack") {
          toolsList = ["cvBuilderStudio", "uniResearchCareerStudio", "slidesStudio", "multiSourceSynthStudio"];
        }
        if (!Array.isArray(adminPerms.activationCodes)) adminPerms.activationCodes = [];
        adminPerms.activationCodes = adminPerms.activationCodes.filter(function (x) { return x.code !== cStr; });
        adminPerms.activationCodes.unshift({
          code: cStr,
          label: cLbl || ("كود صلاحية (" + cStr + ")"),
          grantMode: gMode,
          tools: toolsList,
          maxUses: cMax,
          usedCount: 0,
          expiresDays: 365,
          active: true
        });
        logPermAudit("إنشاء كود تفعيل صلاحيات جديد: " + cStr);
        saveAdminPerms();
        renderMainOrganizer();
        toast("🎟️ تم إنشاء وحفظ كود التفعيل «" + cStr + "» بنجاح ✓", "success");
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-adm-delcode]"), function (b) {
      b.addEventListener("click", function () {
        var idx = parseInt(b.getAttribute("data-adm-delcode"), 10);
        if (Array.isArray(adminPerms.activationCodes) && idx >= 0 && idx < adminPerms.activationCodes.length) {
          var rem = adminPerms.activationCodes.splice(idx, 1)[0];
          logPermAudit("حذف كود التفعيل: " + (rem ? rem.code : ""));
          saveAdminPerms();
          renderMainOrganizer();
          toast("🗑️ تم حذف كود التفعيل", "info");
        }
      });
    });

    var clearCacheBtn = document.getElementById("btnAdmClearOldCache");
    if (clearCacheBtn) {
      clearCacheBtn.addEventListener("click", function () {
        try {
          Object.keys(localStorage).forEach(function (k) {
            if (/^edu_master_curriculum_tree_v(9[0-6]|8\d)/.test(k)) localStorage.removeItem(k);
          });
        } catch (e) {}
        toast("🧹 تم تنظيف مفاتيح الكاش القديمة بنجاح ✓", "success");
      });
    }

    // أحداث شريط تنسيق الخطوط الفوري
    Array.prototype.forEach.call(root.querySelectorAll("[data-org-sitefont]"), function (b) {
      b.addEventListener("click", function () {
        readerPrefs.siteFont = b.getAttribute("data-org-sitefont") || "cairo";
        saveReaderPrefs();
        applyTypographyPrefs();
        renderMainOrganizer();
        toast("🔤 تم تطبيق الخط الاحترافي المختار على كامل المنصة ✓", "success");
      });
    });

    var scMinus = document.getElementById("btnOrgSiteScaleMinus");
    var scPlus = document.getElementById("btnOrgSiteScalePlus");
    if (scMinus) {
      scMinus.addEventListener("click", function () {
        readerPrefs.siteScale = Math.max(90, (readerPrefs.siteScale || 100) - 5);
        saveReaderPrefs();
        applyTypographyPrefs();
        renderMainOrganizer();
      });
    }
    if (scPlus) {
      scPlus.addEventListener("click", function () {
        readerPrefs.siteScale = Math.min(125, (readerPrefs.siteScale || 100) + 5);
        saveReaderPrefs();
        applyTypographyPrefs();
        renderMainOrganizer();
      });
    }

    // أحداث جسر الدمج والتعاون الذكي
    Array.prototype.forEach.call(root.querySelectorAll("[data-org-bridge]"), function (b) {
      b.addEventListener("click", function () {
        var targetTool = b.getAttribute("data-org-bridge");
        if (!canAccessTool(targetTool)) {
          showBlockedToolModal(targetTool);
          return;
        }
        var ctxPayload = {
          title: M.name + " — " + pageData.unitTitle + " (ص " + pageData.page + ")",
          topic: pageData.unitTitle + " — " + pageData.subHeading,
          grade: G.name,
          subject: M.name,
          notes: pageData.paragraphs.join("\n\n") + "\n\n" + pageData.boxPoints.join("\n")
        };
        if (window.EduBridge && typeof window.EduBridge.openTool === "function") {
          window.EduBridge.openTool(targetTool, ctxPayload);
        } else {
          openToolOrPrompt(targetTool);
        }
      });
    });

    var shareCollabBtn = document.getElementById("btnOrgShareToCollabRoom");
    if (shareCollabBtn) {
      shareCollabBtn.addEventListener("click", function () {
        var newRoom = {
          id: "room-" + Date.now(),
          code: "GZ-" + Math.floor(1000 + Math.random() * 9000),
          title: "حلقة دراسة: " + M.name + " (" + pageData.unitTitle + ")",
          teacher: (currentUser && currentUser.name) ? currentUser.name : "الأستاذ باسل أشرف الفقعاوي",
          grade: G.name,
          subject: M.name,
          activeTask: "مناقشة وحل تدريبات صفحة " + pageData.page + ": " + pageData.subHeading,
          members: 1,
          status: "active"
        };
        collabRooms.unshift(newRoom);
        try { localStorage.setItem(COLLAB_FEED_KEY, JSON.stringify(collabRooms)); } catch (e) {}
        state.topNav = "mybag";
        state.mybagSubTab = "smart_collab";
        renderMainOrganizer();
        focusAndScrollTo("orgMyBagSectionBox", "🤝 تم نشر الصفحة في حلقة التعاون الذكي (رمز: " + newRoom.code + ") ✓");
      });
    }

    var openCollabQuick = document.getElementById("btnOrgOpenCollabQuick");
    if (openCollabQuick) {
      openCollabQuick.addEventListener("click", function () {
        state.topNav = "mybag";
        state.mybagSubTab = "smart_collab";
        renderMainOrganizer();
        focusAndScrollTo("orgMyBagSectionBox", "🤝 تم فتح حلقات التعاون الذكي ✓");
      });
    }

    var createCollabBtn = document.getElementById("btnCreateCollabRoom");
    if (createCollabBtn) {
      createCollabBtn.addEventListener("click", function () {
        var tInp = document.getElementById("inpCollabRoomTitle");
        var kInp = document.getElementById("inpCollabRoomTask");
        var rTitle = (tInp && tInp.value.trim()) || ("حلقة تعاون: " + M.name);
        var rTask = (kInp && kInp.value.trim()) || ("مراجعة ومناقشة درس " + pageData.unitTitle + " (ص " + pageData.page + ")");
        var rm = {
          id: "room-" + Date.now(),
          code: "GZ-" + Math.floor(1000 + Math.random() * 9000),
          title: rTitle,
          teacher: (currentUser && currentUser.name) ? currentUser.name : "إشراف تربوي",
          grade: G.name,
          subject: M.name,
          activeTask: rTask,
          members: 1,
          status: "active"
        };
        collabRooms.unshift(rm);
        try { localStorage.setItem(COLLAB_FEED_KEY, JSON.stringify(collabRooms)); } catch (e) {}
        renderMainOrganizer();
        toast("🤝 تم إنشاء حلقة التعاون الذكي برمز «" + rm.code + "» ✓", "success");
      });
    }

    Array.prototype.forEach.call(root.querySelectorAll("[data-collab-join]"), function (b) {
      b.addEventListener("click", function () {
        var idx = parseInt(b.getAttribute("data-collab-join"), 10);
        var rm = collabRooms[idx];
        if (!rm) return;
        rm.members = (rm.members || 1) + 1;
        try { localStorage.setItem(COLLAB_FEED_KEY, JSON.stringify(collabRooms)); } catch (e) {}
        renderMainOrganizer();
        toast("🎉 انضممت إلى «" + rm.title + "» (رمز: " + rm.code + ") وتم تسجيل مشاركتك ✓", "success");
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-collab-wa]"), function (b) {
      b.addEventListener("click", function () {
        var idx = parseInt(b.getAttribute("data-collab-wa"), 10);
        var rm = collabRooms[idx];
        if (!rm) return;
        var inviteTxt = "🤝 دعوة للانضمام لحلقة التعاون الذكي على منصة EduTech Mindset:\n📘 " + rm.title + "\n🔑 رمز الحلقة: " + rm.code + "\n🎯 المهمة: " + rm.activeTask + "\n🔗 الرابط: " + window.location.href;
        try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(inviteTxt); } catch (e) {}
        toast("🔗 تم نسخ بطاقة الدعوة ورمز الحلقة «" + rm.code + "» للمشاركة ✓", "success");
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll("[data-collab-del]"), function (b) {
      b.addEventListener("click", function () {
        if (!isEffectiveSuperAdmin()) return;
        var idx = parseInt(b.getAttribute("data-collab-del"), 10);
        if (idx >= 0 && idx < collabRooms.length) {
          collabRooms.splice(idx, 1);
          try { localStorage.setItem(COLLAB_FEED_KEY, JSON.stringify(collabRooms)); } catch (e) {}
          renderMainOrganizer();
          toast("🗑️ تم حذف حلقة التعاون الذكي بأمر الإدارة", "info");
        }
      });
    });

    // أحداث القواطع السيادية والخصوصية
    var regPolSel = document.getElementById("selAdmRegPolicy");
    if (regPolSel) {
      regPolSel.addEventListener("change", function () {
        adminPerms.registrationMode = regPolSel.value || "open";
        logPermAudit("تغيير سياسة التسجيل إلى: " + adminPerms.registrationMode);
        saveAdminPerms();
        renderMainOrganizer();
        toast("🔐 تم تحديث سياسة قبول تسجيل الأعضاء الجدد ✓", "success");
      });
    }

    var sovGrantAll = document.getElementById("btnAdmSovereignGrantAll");
    if (sovGrantAll) {
      sovGrantAll.addEventListener("click", function () {
        registeredUsers.forEach(function (u) {
          var r = getUserPermRecord(u.email);
          r.mode = "vip_all";
          r.blockedTools = [];
        });
        logPermAudit("أمر سيادي: منح وصول VIP شامل لجميع الأعضاء المسجلين");
        saveAdminPerms();
        renderMainOrganizer();
        toast("🌟 تم منح صلاحية الوصول الشامل (VIP) لجميع الأعضاء المسجلين ✓", "success");
      });
    }

    var sovResetAll = document.getElementById("btnAdmSovereignResetAll");
    if (sovResetAll) {
      sovResetAll.addEventListener("click", function () {
        registeredUsers.forEach(function (u) {
          var r = getUserPermRecord(u.email);
          r.mode = "custom";
          r.grantedTools = [];
          r.blockedTools = [];
        });
        logPermAudit("أمر سيادي: إعادة جميع الأعضاء للضوابط الافتراضية لفئاتهم");
        saveAdminPerms();
        renderMainOrganizer();
        toast("🔄 تمت إعادة جميع الأعضاء للضوابط الافتراضية لفئاتهم ✓", "info");
      });
    }

    var privExpBtn = document.getElementById("btnPrivacyExportMyData");
    if (privExpBtn && currentUser) {
      privExpBtn.addEventListener("click", function () {
        var myData = {
          exportedAt: new Date().toISOString(),
          profile: currentUser,
          bookmarks: bookmarks,
          marginNotes: pageNotes,
          completedUnits: completedUnits
        };
        var blob = new Blob([JSON.stringify(myData, null, 2)], { type: "application/json" });
        var a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = "edutech_my_privacy_data.json";
        a.click();
        toast("⬇️ تم تصدير ملف بياناتك وملاحظاتك الشخصية بنجاح ✓", "success");
      });
    }

    var privClrBtn = document.getElementById("btnPrivacyClearMyNotes");
    if (privClrBtn) {
      privClrBtn.addEventListener("click", function () {
        pageNotes = {};
        bookmarks = {};
        completedUnits = {};
        savePageNotes();
        saveBookmarks();
        saveCompletedUnits();
        renderMainOrganizer();
        toast("🧹 تم مسح الهوامش وسجل القراءة المحلي بنجاح ✓", "info");
      });
    }

    var privDelAccBtn = document.getElementById("btnPrivacyDeleteMyAccount");
    if (privDelAccBtn && currentUser) {
      privDelAccBtn.addEventListener("click", function () {
        var delEm = currentUser.email;
        registeredUsers = registeredUsers.filter(function (u) { return u.email !== delEm; });
        try { localStorage.removeItem("edutech_local_ws_" + delEm.toLowerCase()); } catch (e) {}
        currentUser = null;
        saveUsers();
        saveCurrentUser();
        renderMainOrganizer();
        toast("🗑️ تم حذف حسابك وجميع بياناتك المرتبطة به نهائياً ✓", "info");
      });
    }
  }

  function ensureFloatingQuickBar() {
    if (document.getElementById("eduFloatingQuickBar")) return;
    var bar = document.createElement("div");
    bar.id = "eduFloatingQuickBar";
    bar.className = "fixed bottom-20 left-3 z-40 hidden items-center gap-1.5 bg-slate-900/95 text-white px-2.5 py-1.5 rounded-2xl border border-amber-500/40 shadow-2xl backdrop-blur";
    bar.innerHTML = '<button type="button" id="btnFloatBack" class="px-2.5 py-1 rounded-xl bg-amber-500 text-slate-950 text-[11px] font-black">⬅ رجوع</button>' +
      '<button type="button" id="btnFloatTop" class="px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-300 text-[11px] font-black">⬆ للأعلى</button>';
    document.body.appendChild(bar);
    document.getElementById("btnFloatBack").addEventListener("click", goBackStep);
    document.getElementById("btnFloatTop").addEventListener("click", function () {
      try { window.scrollTo({ top: 0, behavior: "smooth" }); } catch (e) { window.scrollTo(0, 0); }
    });
    window.addEventListener("scroll", function () {
        try {
          var prog = document.getElementById("eduScrollProgress");
          if (prog) {
            var st = window.scrollY || document.documentElement.scrollTop || 0;
            var dh = Math.max(1, (document.documentElement.scrollHeight || 1) - (window.innerHeight || 1));
            var pct = Math.min(100, Math.max(0, (st / dh) * 100));
            prog.style.width = pct.toFixed(1) + "%";
          }
        } catch (eProg) {}
      if (window.scrollY > 320) {
        bar.classList.remove("hidden");
        bar.classList.add("flex");
      } else {
        bar.classList.add("hidden");
        bar.classList.remove("flex");
      }
    }, { passive: true });
  }

  function mountMasterOrganizer() {
    loadData();
    var main = document.querySelector("main") || document.body;
    var root = document.getElementById("eduOrganizedPlatformRoot");
    if (!root) {
      root = document.createElement("section");
      root.id = "eduOrganizedPlatformRoot";
      var hero = document.getElementById("hero");
      if (hero && hero.parentNode === main && hero.nextSibling) {
        main.insertBefore(root, hero.nextSibling);
      } else {
        main.insertBefore(root, main.firstChild);
      }
    }
    renderMainOrganizer();
    setTimeout(enforceCleanPageVisibility, 400);
    setTimeout(enforceCleanPageVisibility, 1200);
  }

  // واجهة التحكم بالصلاحيات العامة ليستخدمها launcher.js و app.js وجميع الأدوات
  window.EduAccessControl = {
    catalog: MASTER_TOOLS_CATALOG,
    canAccessTool: canAccessTool,
    evaluateToolAccess: function (toolId, uObj) { return evaluateToolAccessForUser(toolId, uObj || currentUser, false); },
    promptBlockedTool: showBlockedToolModal,
    requestAccess: submitToolAccessRequest,
    getCurrentUser: function () { return currentUser; },
    getRegisteredUsers: function () { return registeredUsers; },
    /* سحب صلاحية الإدارة من هذا الجهاز (عند دخول حساب غير مخوّل أو الخروج) */
    lockAdmin: function () {
      var was = !!state.isAdminUnlocked;
      state.isAdminUnlocked = false;
      try { localStorage.setItem(ADMIN_MODE_KEY, "0"); sessionStorage.removeItem("edutech_admin_pin_session"); } catch (e) {}
      if (was) { try { syncHeaderAuthUI(); renderMainOrganizer(); } catch (e) {} }
    },
    loginDirect: function (rawEm, rawPass) {
      var rawEmail = String(rawEm || "").trim().toLowerCase();
      var email = rawEmail.indexOf("@") === -1 && rawEmail ? rawEmail + "@edutech.ps" : rawEmail;
      var pass = String(rawPass == null ? "" : rawPass);
      var admEmails = (window.EDUTECH_ADMIN_EMAILS || ["baselashraf800@gmail.com", "edutechm1994@gmail.com"]).map(function (s) { return s.toLowerCase().trim(); });
      if (admEmails.indexOf(rawEmail) !== -1 || admEmails.indexOf(email) !== -1 || rawEmail === "admin" || rawEmail === "basel") {
        if (pinMatches(pass)) {
          var admEmailFinal = admEmails.indexOf(rawEmail) !== -1 ? rawEmail : admEmails[0];
          currentUser = {
            name: "الأستاذ باسل أشرف الفقعاوي (الإدارة العليا 👑)",
            email: admEmailFinal,
            passHash: hashUserPass(admEmailFinal, pass),
            roleLabel: "معلم",
            gradeId: "g12",
            gradeName: "الإشراف العام والتوجيهي",
            school: "مؤسس ومدير منصة EduTech Mindset"
          };
          state.impersonatingUserEmail = "";
          state.isAdminUnlocked = true;
          try { localStorage.setItem(ADMIN_MODE_KEY, "1"); } catch (e) {}
          if (typeof window.setSuperAdminMode === "function") window.setSuperAdminMode(true);
          saveCurrentUser();
          state.topNav = "admin";
          renderMainOrganizer();
          toast("👑 أهلاً بالأستاذ باسل الفقعاوي! تم فتح القيادة السيادية للإدارة العليا بالكامل ✓", "success");
          return true;
        }
      }
      var found = registeredUsers.filter(function (u) {
        var uEm = String(u.email || "").toLowerCase().trim();
        return (uEm === email || uEm === rawEmail || uEm.split("@")[0] === rawEmail) && verifyUserPass(u, pass);
      })[0];
      if (found) {
        currentUser = found;
        state.impersonatingUserEmail = "";
        saveUsers();
        saveCurrentUser();
        renderMainOrganizer();
        toast("🔑 تم تسجيل الدخول بنجاح — مرحباً " + found.name + " ✓", "success");
        return true;
      }
      toast("❌ البريد الإلكتروني أو كلمة المرور غير صحيحة", "error");
      return false;
    },
    quickLoginEmail: function (em) {
      var found = registeredUsers.filter(function (u) { return String(u.email || "").toLowerCase() === String(em || "").toLowerCase(); })[0];
      if (!found) return false;
      currentUser = found;
      state.impersonatingUserEmail = "";
      saveCurrentUser();
      renderMainOrganizer();
      toast("🔑 تم تسجيل الدخول السريع بحساب «" + found.name + "» (" + found.roleLabel + ") ✓", "success");
      return true;
    },
    openAuthTab: function (mode) {
      state.topNav = "account";
      state.authMode = mode || "login";
      renderMainOrganizer();
      focusAndScrollTo("orgAccountSectionBox", "👤 تم فتح بوابة التسجيل والدخول الموحدة ✓");
    },
    /* يُستدعى من app.js عند دخول مستخدم Google: يجعله هو المستخدم الحالي في نظام الصلاحيات،
       وتُفتح الإدارة تلقائيًا فقط لحساب الإدارة الموثّق (Cloud.isAdmin) دون حاجة للرمز. */
    syncFirebaseUser: function (fbUserRec, isCloudAdmin) {
      if (!fbUserRec || !fbUserRec.email) return;
      var em = String(fbUserRec.email).toLowerCase().trim();
      var rRaw = String(fbUserRec.role || ""), role = "طالب";   // الافتراضي الأضيق؛ الدور لا يمنح إلا ما تسمح به سياسات الأدوار
      if (/معلم|مشرف|مدير|مدرب/.test(rRaw)) role = "معلم";
      else if (/توجيهي/.test(rRaw)) role = "توجيهي";
      else if (/جامع|باحث/.test(rRaw)) role = "جامعي";
      else if (/ولي/.test(rRaw)) role = "ولي أمر";
      var merged = {
        uid: fbUserRec.uid || "", name: fbUserRec.name || em.split("@")[0], email: em, pass: "google-auth",
        roleLabel: role, gradeId: "g10", gradeName: fbUserRec.grade || "الصف العاشر الأساسي",
        school: fbUserRec.school || "حساب Google سحابي ☁️", fromCloud: true
      };
      registeredUsers = registeredUsers.filter(function (u) { return String(u.email || "").toLowerCase() !== em; });
      registeredUsers.unshift(merged);
      currentUser = merged;
      if (isCloudAdmin) {
        state.isAdminUnlocked = true;
        try { localStorage.setItem(ADMIN_MODE_KEY, "1"); } catch (e) {}
      }
      saveUsers();
      saveCurrentUser();
      renderMainOrganizer();
    }
  };

  window.EduMasterHierarchy = {
    findSubject: function (gradeName, subjectName) {
      function normAr(s) {
        return String(s || "").replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/\s+/g, " ").trim().toLowerCase();
      }
      var gQ = normAr(gradeName), sQ = normAr(subjectName);
      var gKeys = ["الحادي عشر", "الثاني عشر", "الاول", "الثاني", "الثالث", "الرابع", "الخامس", "السادس", "السابع", "الثامن", "التاسع", "العاشر"];
      var matchedGKey = "";
      for (var k = 0; k < gKeys.length; k++) {
        if (gQ.indexOf(gKeys[k]) !== -1) { matchedGKey = gKeys[k]; break; }
      }
      function isSubMatch(sn, sq) {
        if (!sn || !sq) return false;
        if (sn.indexOf(sq) !== -1 || sq.indexOf(sn) !== -1) return true;
        var pairs = [
          ["عربي", "لغتنا"], ["اسلامي", "دين"], ["انجليزي", "english"],
          ["اجتماع", "وطن"], ["اجتماع", "تاريخ"], ["اجتماع", "جغرافي"],
          ["احياء", "حياتي"], ["حاسوب", "تكنولوجيا"], ["حاسوب", "برمج"]
        ];
        for (var i = 0; i < pairs.length; i++) {
          var a = pairs[i][0], b = pairs[i][1];
          if ((sn.indexOf(a) !== -1 && sq.indexOf(b) !== -1) || (sn.indexOf(b) !== -1 && sq.indexOf(a) !== -1)) return true;
        }
        return false;
      }
      var best = null;
      masterTree.forEach(function (stg) {
        (stg.grades || []).forEach(function (g) {
          var gn = normAr(g.name);
          var gOk = !matchedGKey || gn.indexOf(matchedGKey) !== -1;
          if (!gOk) return;
          (g.branches || []).forEach(function (b) {
            (b.subjects || []).forEach(function (sub) {
              var sn = normAr(sub.name + " " + (sub.bookTitle || ""));
              if (isSubMatch(sn, sQ)) {
                if (!best) best = { stage: stg, grade: g, branch: b, subject: sub };
              }
            });
          });
        });
      });
      return best;
    },
    speakText: function (txt, lang) {
      if (!("speechSynthesis" in window)) return;
      try {
        window.speechSynthesis.cancel();
        var u = new SpeechSynthesisUtterance(String(txt || ""));
        u.lang = lang || (/[a-zA-Z]{3,}/.test(txt) && !/[\u0600-\u06FF]/.test(txt) ? "en-US" : "ar-SA");
        u.rate = 0.92;
        window.speechSynthesis.speak(u);
      } catch (e) {}
    },
    openSubject: function (gradeName, subjectName, mode) {
      var hit = window.EduMasterHierarchy.findSubject(gradeName, subjectName);
      if (!hit) return false;
      state.topNav = "curriculum";
      state.curriculumSubTab = "textbook";
      state.stageId = hit.stage.id;
      state.gradeId = hit.grade.id;
      state.branchId = hit.branch.id;
      state.subjectId = hit.subject.id;
      state.activeStudyMode = mode || "book";
      state.unitIdx = 0;
      renderMainOrganizer();
      setTimeout(function () {
        var el = document.getElementById("orgBookPagePaper") || document.getElementById("eduOrganizedPlatformRoot");
        if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 100);
      return true;
    },
    openToolStudio: openToolOrPrompt,
    getTree: function () { return masterTree; },
    getSelection: getSelection,
    navigateToTarget: function (rawTarget) {
      var target = String(rawTarget || "").trim().replace(/^#/, "");
      if (!target || target === "hero" || target === "mainContent") {
        state.showHeroBanner = true;
        state.topNav = "curriculum";
        state.curriculumSubTab = "textbook";
        state.openedToolId = "";
        renderMainOrganizer();
        try { window.scrollTo({ top: 0, behavior: "smooth" }); } catch (e) { window.scrollTo(0, 0); }
        toast("🏠 عدت إلى الصفحة الرئيسية", "info");
        return true;
      }
      state.showHeroBanner = false;
      if (target.indexOf("grade:") === 0) {
        var gParts = target.slice(6).split("|");
        if (gParts.length === 2) {
          state.topNav = "curriculum";
          state.curriculumSubTab = "textbook";
          state.collapseSelectors = false;
          state.stageId = gParts[0];
          state.gradeId = gParts[1];
          state.branchId = "";
          state.subjectId = "";
          pushNavHistory();
          renderMainOrganizer();
          var gSel = getSelection();
          focusAndScrollTo("orgStepSubjectsBox", "🏫 تم فتح منهاج «" + gSel.grade.name + "» ✓");
          return true;
        }
      }
      if (target === "book" || target === "orgBookPagePaper") {
        state.topNav = "curriculum";
        state.curriculumSubTab = "textbook";
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo("orgBookPagePaper", "📖 تم فتح قارئ الكتاب التفاعلي ✓");
        return true;
      }
      if (target === "curriculum" || target === "orgStepStagesBox") {
        state.topNav = "curriculum";
        state.curriculumSubTab = "textbook";
        state.collapseSelectors = false;
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo("orgStepStagesBox", "🏫 تم فتح المراحل الدراسية والمنهاج ✓");
        return true;
      }
      if (target === "learnSection") {
        state.topNav = "curriculum";
        state.curriculumSubTab = "video_lessons";
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo("learnSection", "🎬 تم فتح الفيديوهات والدروس المصوّرة ✓");
        return true;
      }
      if (target === "booksSection") {
        state.topNav = "curriculum";
        state.curriculumSubTab = "ministry_books";
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo("booksSection", "📘 تم فتح فهرس الكتب المدرسية ✓");
        return true;
      }
      if (target === "tools" || target === "orgToolsSectionBox" || target === "smartHubSection" || target === "*") {
        state.topNav = "tools";
        state.openedToolId = "";
        state.collapseToolsCatalog = false;
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo("orgToolsSectionBox", "🛠️ تم فتح بوابة الأدوات والمختبرات الذكية ✓");
        return true;
      }
      if (target === "library") {
        state.topNav = "library";
        state.librarySubTab = "edu_resources";
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo("library", "📖 تم فتح المكتبة التعليمية الشاملة ✓");
        return true;
      }
      if (target === "library_books" || target === "orgLibrarySectionBox") {
        state.topNav = "library";
        state.librarySubTab = "curriculum_cultural";
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo("orgLibrarySectionBox", "📘 تم فتح مكتبة الكتب والمراجع ✓");
        return true;
      }
      if (target === "coursesSection" || target === "publicHubStudio") {
        state.topNav = "library";
        state.librarySubTab = "open_courses";
        pushNavHistory();
        renderMainOrganizer();
        var cEl = document.getElementById("coursesSection");
        if (cEl && !cEl.classList.contains("hidden")) {
          focusAndScrollTo("coursesSection", "🏅 تم فتح الدورات التدريبية والمجتمع المعرفي ✓");
        } else {
          focusAndScrollTo("publicHubStudio", "🌍 تم فتح بوابة المجتمع المعرفي والدورات ✓");
        }
        return true;
      }
      if (target === "mybag" || target === "orgMyBagSectionBox") {
        state.topNav = "mybag";
        state.mybagSubTab = "reading_notes";
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo("orgMyBagSectionBox", "📌 تم فتح حقيبتك القرائية ودفتر هوامشك ✓");
        return true;
      }
      if (target === "userWorkspaceSection") {
        state.topNav = "mybag";
        state.mybagSubTab = "my_workspace";
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo("userWorkspaceSection", "👨‍🎓 تم فتح مساحتك الشخصية وإنجازاتك ✓");
        return true;
      }
      if (target === "university" || target === "orgUniversitySectionBox") {
        state.topNav = "university";
        state.uniSubTab = "majors_tawjihi";
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo("orgUniversitySectionBox", "🎓 تم فتح بوابة المرحلة الجامعية والسيرة الذاتية ✓");
        return true;
      }
      if (target === "about" || target === "social") {
        state.topNav = "university";
        state.uniSubTab = "about_platform";
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo(target, "🇵🇸 تم فتح قسم من نحن وحسابات التواصل ✓");
        return true;
      }
      if (target === "account" || target === "orgAccountSectionBox") {
        state.topNav = "account";
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo("orgAccountSectionBox", "👤 تم فتح بوابة التسجيل وحسابك الشخصي ✓");
        return true;
      }
      if (target === "admin" || target === "orgAdminSectionBox") {
        state.topNav = "admin";
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo("orgAdminSectionBox", "👑 تم فتح بوابة القيادة والصلاحيات ✓");
        return true;
      }
      if (target === "modsSection") {
        state.topNav = "library";
        state.librarySubTab = "edu_resources";
        renderMainOrganizer();
        var mSec = document.getElementById("modsSection");
        if (mSec) {
          mSec.classList.add("edu-section-active");
          mSec.classList.remove("hidden");
          mSec.style.display = "";
          focusAndScrollTo("modsSection", "🛡️ تم فتح مساحة المشرفين ✓");
        }
        return true;
      }
      if (TOOL_MAP[target] || ALL_MANAGED_SECTION_IDS.indexOf(target) !== -1) {
        return openToolOrPrompt(target);
      }
      var anyEl = document.getElementById(target);
      if (anyEl) {
        anyEl.classList.add("edu-section-active");
        anyEl.classList.remove("hidden");
        anyEl.style.display = "";
        focusAndScrollTo(target);
        return true;
      }
      return false;
    },
    openNav: function (navName) {
      if (navName === "library") {
        state.topNav = "library";
        state.librarySubTab = "curriculum_cultural";
        pushNavHistory();
        renderMainOrganizer();
        focusAndScrollTo("orgLibrarySectionBox", "📖 تم فتح المكتبة الرقمية الشاملة ✓");
        return;
      }
      return window.EduMasterHierarchy.navigateToTarget(navName || "curriculum");
    },
    openAdmin: function (tab) {
      state.topNav = "admin";
      state.isAdminUnlocked = true;
      try { localStorage.setItem(ADMIN_MODE_KEY, "1"); } catch (e) {}
      if (typeof window.setSuperAdminMode === "function") window.setSuperAdminMode(true);
      if (tab) state.adminTab = tab;
      syncHeaderAuthUI();
      renderMainOrganizer();
      focusAndScrollTo("orgAdminSectionBox", "👑 غرفة القيادة السيادية للإدارة العليا مفتوحة الآن");
    },
    lockAdminNow: function () {
      state.isAdminUnlocked = false;
      state.impersonatingUserEmail = "";
      if (state.topNav === "admin") state.topNav = "curriculum";
      try { localStorage.setItem(ADMIN_MODE_KEY, "0"); } catch (e) {}
      if (typeof window.setSuperAdminMode === "function") window.setSuperAdminMode(false);
      syncHeaderAuthUI();
      renderMainOrganizer();
      toast("🔒 تم قفل وضع الإدارة وإخفاء جميع صلاحياتها عن الجمهور فوراً ✓", "info");
    },
    syncAdminState: function (flag) {
      state.isAdminUnlocked = !!flag;
      syncHeaderAuthUI();
      renderMainOrganizer();
    },
    logoutLocal: function () {
      currentUser = null;
      state.impersonatingUserEmail = "";
      state.isAdminUnlocked = false;
      if (state.topNav === "admin") state.topNav = "curriculum";
      syncHeaderAuthUI();
      renderMainOrganizer();
    },
    cycleTypography: function () {
      var fonts = ["cairo", "tajawal", "alexandria", "almarai"];
      var names = { cairo: "خط القاهرة (Cairo)", tajawal: "خط تجوال (Tajawal)", alexandria: "خط الإسكندرية", almarai: "خط المراعي" };
      var idx = (fonts.indexOf(readerPrefs.siteFont || "cairo") + 1) % fonts.length;
      readerPrefs.siteFont = fonts[idx];
      saveReaderPrefs();
      applyTypographyPrefs();
      renderMainOrganizer();
      toast("🔤 تم تنسيق خط الموقع إلى: " + names[readerPrefs.siteFont] + " ✓", "info");
    },
    goBack: goBackStep,
    refresh: renderMainOrganizer,
    enforceVisibility: enforceCleanPageVisibility
  };

  function updateNetBadge() {
    var b = document.getElementById("eduNetStatusBadge");
    if (!b) return;
    if (navigator.onLine) {
      b.className = "px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-300";
      b.textContent = "🟢 متصل";
    } else {
      b.className = "px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300";
      b.textContent = "🟠 وضع الأوفلاين النشط";
    }
  }
  window.addEventListener("online", updateNetBadge);
  window.addEventListener("offline", updateNetBadge);

  window.addEventListener("keydown", function (ev) {
    var tag = (ev.target && ev.target.tagName) ? ev.target.tagName.toLowerCase() : "";
    if (tag === "input" || tag === "textarea" || tag === "select") return;
    if (ev.key === "Escape" || (ev.altKey && ev.key === "ArrowLeft")) {
      ev.preventDefault();
      goBackStep();
    } else if (!ev.altKey && !ev.ctrlKey && !ev.metaKey && state.topNav === "curriculum" && state.activeStudyMode === "book") {
      if (ev.key === "ArrowLeft") {
        var nb = document.getElementById("btnOrgNextPage");
        if (nb) nb.click();
      } else if (ev.key === "ArrowRight") {
        var pb = document.getElementById("btnOrgPrevPage");
        if (pb) pb.click();
      }
    }
  });

  window.addEventListener("edu:lazy-ready", function () {
    enforceCleanPageVisibility();
    syncHeaderAuthUI();
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mountMasterOrganizer);
  } else {
    mountMasterOrganizer();
  }
})();

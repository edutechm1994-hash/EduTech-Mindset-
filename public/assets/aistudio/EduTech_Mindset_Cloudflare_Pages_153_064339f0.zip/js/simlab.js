/*
 * مختبر التجارب والمحاكاة العلمية التفاعلية (STEM Virtual Lab) — EduTech Mindset (الإصدار 45)
 * 5 تجارب ومحاكيات علمية ورياضية تفاعلية تعمل مباشرة داخل المتصفح (بلا إنترنت):
 * 1) قانون أوم والدوائر الكهربائية (فيزياء)
 * 2) حركة المقذوفات والجاذبية (فيزياء)
 * 3) مقياس الحموضة والمعايرة الكيميائية pH (كيمياء)
 * 4) عملية البناء الضوئي في النبات (أحياء وعلوم)
 * 5) راسم الدوال والمعادلات الرياضية التفاعلي (رياضيات)
 * مع زر «🤖 شرح التجربة وتوليد أسئلة استنتاجية بالذكاء الاصطناعي».
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };

  var SIMS = [
    { id: "dna_mrna", ico: "🧬", title: "نسخ الـ DNA وترجمة الـ mRNA في الريبوسوم (توجيهي)", sub: "الأحياء — التوجيهي الفلسطيني", law: "نسخ الـ DNA يبني mRNA باستبدال (T) بـ (U)، ثم تتم المعالجة (قبعة 5' وذيل Poly-A وقص الإنترونات)، ثم الترجمة في مواقع الريبوسوم (E-P-A) بدءاً من كودون AUG." },
    { id: "rot_inertia", ico: "⚙️", title: "القصور الدوراني وقانون نيوتن الثاني للدوران (توجيهي)", sub: "الفيزياء — التوجيهي الفلسطيني", law: "القصور الدوراني I = c·m·r² | قانون نيوتن الثاني للدوران: محصلة العزم τ = I × α (يزداد القصور الدوراني بزيادة الكتلة وبُعدها عن محور الدوران)." },
    { id: "chem_g4", ico: "🔬", title: "كيمياء الصف الرابع (غزة): الجزيئات وتكوين الماء", sub: "الكيمياء والعلوم — الصف الرابع", law: "تتحرك جزيئات المادة بسرعة أكبر عند رفع درجة الحرارة، وتتحد ذرتا هيدروجين (2H₂) مع الأكسجين (O₂) لتكوين جزيئات الماء (2H₂O)." },
    { id: "ohm", ico: "⚡", title: "قانون أوم والدوائر الكهربائية", sub: "الفيزياء والعلوم", law: "الجهد (V) = التيار (I) × المقاومة (R) | تزداد شدة التيار طردياً مع الجهد وعكسياً مع المقاومة." },
    { id: "proj", ico: "🎯", title: "حركة المقذوفات والمدى الأفقي", sub: "الفيزياء والميكانيكا", law: "المدى الأفقي R = (v₀² · sin(2θ)) / g | يتحقق أقصى مدى أفقي عند زاوية إطلاق 45 درجة." },
    { id: "buoy", ico: "💧", title: "قاعدة أرخميدس والطفو (البحر الميت)", sub: "الفيزياء والعلوم", law: "قوة الطفو = وزن السائل المزاح | يطفو الجسم إذا كانت كثافته أقل من كثافة السائل (مثل مياه البحر الميت عالية الملوحة)." },
    { id: "ph", ico: "🧪", title: "مقياس الحموضة والمحاليل (pH)", sub: "الكيمياء", law: "مقياس pH يتدرج من 0 إلى 14: أقل من 7 حمضي، 7 متعادل، وأكبر من 7 قاعدي (قلوي)." },
    { id: "photo", ico: "🌿", title: "البناء الضوئي وإنتاج الأكسجين", sub: "الأحياء والعلوم", law: "6CO₂ + 6H₂O + ضوء الشمس ➔ C₆H₁₂O₆ + 6O₂ | يزداد معدل انطلاق الأكسجين بزيادة شدة الضوء وCO₂ ضمن الحرارة المثلى." },
    { id: "graph", ico: "📐", title: "راسم الدوال التربيعية والمثلثية", sub: "الرياضيات", law: "في الاقتران التربيعي f(x)=ax²+bx+c، إذا كان a>0 يكون القطع مقعراً للأعلى، وإذا كان a<0 يكون مقعراً للأسفل." }
  ];

  var st = {
    active: "dna_mrna",
    dna_mrna: { stage: "translation", codonStep: 2 },
    rot_inertia: { m: 4, r: 1.5, tau: 18, shape: "disk" },
    chem_g4: { temp: 45, conc: 70, mode: "water" },
    ohm: { v: 12, r: 6 },
    proj: { v0: 28, angle: 45, g: 9.8 },
    buoy: { objRho: 0.9, liqRho: 1.24, liqName: "مياه البحر الميت (1.24 غ/سم³)" },
    ph: { val: 7.0, name: "ماء نقي متعادل" },
    photo: { light: 70, co2: 60, temp: 25 },
    graph: { a: 1, b: 0, c: -4, fn: "quad" }
  };

  function renderControls() {
    var box = $("simControls"); if (!box) return;
    var s = st.active;
    if (s === "dna_mrna") {
      box.innerHTML = '<div class="grid grid-cols-1 sm:grid-cols-3 gap-3">' +
        '<div class="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-xs font-extrabold mb-1">🧬 المرحلة الحيوية:</label>' +
        '<select id="simDnaStage" class="w-full text-xs font-bold p-2 rounded-xl bg-white dark:bg-slate-900 border">' +
          '<option value="transcription"' + (st.dna_mrna.stage === "transcription" ? " selected" : "") + '>1) نسخ الـ DNA إلى mRNA أولي</option>' +
          '<option value="processing"' + (st.dna_mrna.stage === "processing" ? " selected" : "") + '>2) معالجة mRNA (قبعة 5′ + ذيل Poly-A + قص الإنترونات)</option>' +
          '<option value="translation"' + (st.dna_mrna.stage === "translation" ? " selected" : "") + '>3) ترجمة mRNA في مواقع الريبوسوم (E - P - A)</option>' +
        '</select></div>' +
        '<div class="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-xs font-extrabold mb-1">📍 خطوة الكودون في الريبوسوم: <span class="text-brand-600">' + st.dna_mrna.codonStep + ' من 4</span></label>' +
        '<input type="range" id="simDnaStep" min="1" max="4" step="1" value="' + st.dna_mrna.codonStep + '" class="w-full"></div>' +
        '<div class="p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-center flex flex-col justify-center">' +
        '<div class="text-xs font-black text-emerald-700 dark:text-emerald-300">السلسلة الببتيدية المتكونة</div>' +
        '<div class="text-sm font-black mt-1">' + ["Met (AUG)", "Met - Phe", "Met - Phe - Gly", "Met - Phe - Gly - Pro (إيقاف UAG)"][st.dna_mrna.codonStep - 1] + '</div></div></div>';
      $("simDnaStage").onchange = function (ev) { st.dna_mrna.stage = ev.target.value; renderControls(); drawSim(); };
      $("simDnaStep").oninput = function (ev) { st.dna_mrna.codonStep = +ev.target.value; renderControls(); drawSim(); };
      return;
    }
    if (s === "rot_inertia") {
      var shapeFactor = st.rot_inertia.shape === "ring" ? 1.0 : (st.rot_inertia.shape === "sphere" ? 0.4 : 0.5);
      var Ival = (shapeFactor * st.rot_inertia.m * st.rot_inertia.r * st.rot_inertia.r).toFixed(2);
      var alphaVal = (st.rot_inertia.tau / Math.max(0.1, +Ival)).toFixed(2);
      box.innerHTML = '<div class="grid grid-cols-1 sm:grid-cols-4 gap-2.5">' +
        '<div class="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-[11px] font-extrabold mb-1">⚙️ شكل الجسم الدوراني</label>' +
        '<select id="simRotShape" class="w-full text-xs font-bold p-1.5 rounded-lg bg-white dark:bg-slate-900 border">' +
          '<option value="disk"' + (st.rot_inertia.shape === "disk" ? " selected" : "") + '>قرص مصمت (I = ½mr²)</option>' +
          '<option value="ring"' + (st.rot_inertia.shape === "ring" ? " selected" : "") + '>حلقة مفرغة (I = mr²)</option>' +
          '<option value="sphere"' + (st.rot_inertia.shape === "sphere" ? " selected" : "") + '>كرة مصمتة (I = ⅖mr²)</option>' +
        '</select></div>' +
        '<div class="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-[11px] font-extrabold">الكتلة (m): ' + st.rot_inertia.m + ' كغ</label><input type="range" id="simRotM" min="1" max="10" step="0.5" value="' + st.rot_inertia.m + '" class="w-full"></div>' +
        '<div class="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-[11px] font-extrabold">نصف القطر (r): ' + st.rot_inertia.r + ' م</label><input type="range" id="simRotR" min="0.5" max="3" step="0.25" value="' + st.rot_inertia.r + '" class="w-full"></div>' +
        '<div class="p-2.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-center flex flex-col justify-center"><div class="text-[11px] font-black">I = ' + Ival + ' كغ.م²</div><div class="text-xs font-black text-amber-600 dark:text-amber-300">التسارع الزاوي α = ' + alphaVal + ' راد/ث²</div></div></div>';
      $("simRotShape").onchange = function (ev) { st.rot_inertia.shape = ev.target.value; renderControls(); drawSim(); };
      $("simRotM").oninput = function (ev) { st.rot_inertia.m = +ev.target.value; renderControls(); drawSim(); };
      $("simRotR").oninput = function (ev) { st.rot_inertia.r = +ev.target.value; renderControls(); drawSim(); };
      return;
    }
    if (s === "chem_g4") {
      box.innerHTML = '<div class="grid grid-cols-1 sm:grid-cols-3 gap-3">' +
        '<div class="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-xs font-extrabold mb-1">🌡️ درجة الحرارة: <span class="text-rose-600">' + st.chem_g4.temp + ' °C</span></label>' +
        '<input type="range" id="simChemT" min="0" max="100" step="5" value="' + st.chem_g4.temp + '" class="w-full"></div>' +
        '<div class="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-xs font-extrabold mb-1">⚗️ تركيز ذرات التفاعل: <span class="text-sky-600">' + st.chem_g4.conc + '%</span></label>' +
        '<input type="range" id="simChemC" min="20" max="100" step="10" value="' + st.chem_g4.conc + '" class="w-full"></div>' +
        '<div class="p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-center flex flex-col justify-center"><div class="text-xs font-black text-emerald-700 dark:text-emerald-300">معادلة التفاعل (الصف الرابع — غزة)</div><div class="text-sm font-black mt-0.5" dir="ltr">2H₂ + O₂ ➔ 2H₂O</div></div></div>';
      $("simChemT").oninput = function (ev) { st.chem_g4.temp = +ev.target.value; renderControls(); drawSim(); };
      $("simChemC").oninput = function (ev) { st.chem_g4.conc = +ev.target.value; renderControls(); drawSim(); };
      return;
    }
    if (s === "dna_mrna") {
      ctx.fillStyle = "#38bdf8"; ctx.font = "900 18px Cairo, sans-serif"; ctx.textAlign = "center";
      ctx.fillText("محاكي البيولوجيا الجزيئية (توجيهي فلسطين): " + (st.dna_mrna.stage === "transcription" ? "نسخ الـ DNA إلى mRNA" : st.dna_mrna.stage === "processing" ? "معالجة mRNA الأولي (5' Cap + Poly-A + Splicing)" : "ترجمة mRNA في مواقع الريبوسوم (E - P - A)"), W / 2, 36);
      // شريط DNA القالب
      ctx.fillStyle = "#1e293b"; ctx.fillRect(80, 62, W - 160, 44);
      ctx.strokeStyle = "#38bdf8"; ctx.lineWidth = 2; ctx.strokeRect(80, 62, W - 160, 44);
      ctx.fillStyle = "#7dd3fc"; ctx.font = "900 15px Cairo, monospace";
      ctx.fillText("شريط DNA القالب (3'➔5'):   TAC   —   AAA   —   CCT   —   GGA   —   ATC", W / 2, 90);
      // شريط mRNA
      ctx.fillStyle = "#064e3b"; ctx.fillRect(80, 122, W - 160, 46);
      ctx.strokeStyle = "#10b981"; ctx.strokeRect(80, 122, W - 160, 46);
      ctx.fillStyle = "#6ee7b7";
      ctx.fillText("شريط mRNA الناضج (5'➔3'): [5'Cap]  AUG (بدء) — UUU — GGA — CCU — UAG (إيقاف)  [Poly-A 3']", W / 2, 150);
      // الريبوسوم ومواقعه E - P - A
      var riboX = 150 + (st.dna_mrna.codonStep - 1) * 145;
      ctx.fillStyle = "rgba(245, 158, 11, 0.22)";
      ctx.beginPath(); ctx.roundRect(riboX, 185, 330, 165, 28); ctx.fill();
      ctx.strokeStyle = "#f59e0b"; ctx.lineWidth = 3; ctx.stroke();
      var sites = [
        { code: "E", name: "موقع الخروج", col: "#ef4444", dx: 25 },
        { code: "P", name: "موقع الببتيديل", col: "#10b981", dx: 125 },
        { code: "A", name: "موقع الأمينوأسيل", col: "#38bdf8", dx: 225 }
      ];
      sites.forEach(function (stSite) {
        ctx.fillStyle = stSite.col;
        ctx.fillRect(riboX + stSite.dx, 205, 80, 95);
        ctx.fillStyle = "#0f172a"; ctx.font = "900 22px Cairo, sans-serif";
        ctx.fillText(stSite.code, riboX + stSite.dx + 40, 245);
        ctx.font = "800 11px Cairo, sans-serif";
        ctx.fillText(stSite.name, riboX + stSite.dx + 40, 275);
      });
      ctx.fillStyle = "#fde047"; ctx.font = "900 15px Cairo, sans-serif";
      ctx.fillText("🔗 سلسلة عديد الببتيد الناتجة: " + ["Met", "Met — Phe", "Met — Phe — Gly", "Met — Phe — Gly — Pro ✓"][st.dna_mrna.codonStep - 1], W / 2, 385);
      return;
    }
    if (s === "rot_inertia") {
      var sf = st.rot_inertia.shape === "ring" ? 1.0 : (st.rot_inertia.shape === "sphere" ? 0.4 : 0.5);
      var I = sf * st.rot_inertia.m * st.rot_inertia.r * st.rot_inertia.r;
      var alpha = st.rot_inertia.tau / Math.max(0.1, I);
      var radPx = 45 + st.rot_inertia.r * 38;
      var cxR = 290, cyR = H / 2 + 10;
      ctx.save();
      ctx.beginPath(); ctx.arc(cxR, cyR, radPx, 0, Math.PI * 2);
      if (st.rot_inertia.shape === "ring") {
        ctx.strokeStyle = "#f59e0b"; ctx.lineWidth = 18; ctx.stroke();
      } else {
        ctx.fillStyle = st.rot_inertia.shape === "sphere" ? "#0284c7" : "#4f46e5";
        ctx.fill();
        ctx.strokeStyle = "#38bdf8"; ctx.lineWidth = 5; ctx.stroke();
      }
      // أذرع المحور
      ctx.strokeStyle = "#fde047"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(cxR - radPx, cyR); ctx.lineTo(cxR + radPx, cyR);
      ctx.moveTo(cxR, cyR - radPx); ctx.lineTo(cxR, cyR + radPx); ctx.stroke();
      ctx.restore();
      // سهم القوة المماسية والعزم
      ctx.strokeStyle = "#10b981"; ctx.lineWidth = 5;
      ctx.beginPath(); ctx.moveTo(cxR, cyR - radPx); ctx.lineTo(cxR + 95, cyR - radPx); ctx.stroke();
      ctx.fillStyle = "#10b981"; ctx.font = "900 15px Cairo, sans-serif"; ctx.textAlign = "center";
      ctx.fillText("العزم τ = " + st.rot_inertia.tau + " N·m", cxR + 48, cyR - radPx - 12);
      // لوحة القيم الفيزيائية
      ctx.fillStyle = "#1e293b"; ctx.fillRect(W - 380, 75, 330, 260);
      ctx.strokeStyle = "#f59e0b"; ctx.lineWidth = 2; ctx.strokeRect(W - 380, 75, 330, 260);
      ctx.fillStyle = "#fff"; ctx.font = "900 17px Cairo, sans-serif"; ctx.textAlign = "right";
      ctx.fillText("📐 معطيات ونتائج الحركة الدورانية:", W - 70, 115);
      ctx.font = "800 15px Cairo, sans-serif"; ctx.fillStyle = "#38bdf8";
      ctx.fillText("• الكتلة (m): " + st.rot_inertia.m + " kg", W - 70, 155);
      ctx.fillText("• نصف القطر (r): " + st.rot_inertia.r + " m", W - 70, 190);
      ctx.fillStyle = "#fde047";
      ctx.fillText("• القصور الدوراني (I): " + I.toFixed(2) + " kg·m²", W - 70, 235);
      ctx.fillStyle = "#4ade80";
      ctx.fillText("• التسارع الزاوي (α = τ/I): " + alpha.toFixed(2) + " rad/s²", W - 70, 275);
      return;
    }
    if (s === "chem_g4") {
      ctx.fillStyle = "#38bdf8"; ctx.font = "900 18px Cairo, sans-serif"; ctx.textAlign = "center";
      ctx.fillText("🧪 كيمياء الصف الرابع (غزة): تفاعل الهيدروجين والأكسجين لتكوين جزيئات الماء (2H₂O)", W / 2, 38);
      var countM = Math.max(4, Math.round(st.chem_g4.conc / 8));
      for (var mIdx = 0; mIdx < countM; mIdx++) {
        var mx = 120 + ((mIdx * 113 + st.chem_g4.temp * 3) % (W - 240));
        var my = 95 + ((mIdx * 79 + st.chem_g4.temp * 2) % (H - 150));
        // ذرة أكسجين حمراء في الوسط وذرتا هيدروجين بيضاء/سماوية
        ctx.fillStyle = "#ef4444"; ctx.beginPath(); ctx.arc(mx, my, 18, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = "#fff"; ctx.font = "900 12px Cairo, sans-serif"; ctx.fillText("O", mx, my + 4);
        ctx.fillStyle = "#38bdf8";
        ctx.beginPath(); ctx.arc(mx - 20, my + 16, 11, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(mx + 20, my + 16, 11, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = "#0f172a"; ctx.font = "900 10px Cairo, sans-serif";
        ctx.fillText("H", mx - 20, my + 20); ctx.fillText("H", mx + 20, my + 20);
      }
      ctx.fillStyle = "#fde047"; ctx.font = "900 16px Cairo, sans-serif";
      ctx.fillText("الطاقة الحركية للجزيئات عند " + st.chem_g4.temp + "°C — كل جزيء ماء يتكون من ذرة أكسجين (O) وذرتي هيدروجين (H₂)", W / 2, H - 22);
      return;
    }
    if (s === "ohm") {
      var I = (st.ohm.v / st.ohm.r).toFixed(2), P = (st.ohm.v * (st.ohm.v / st.ohm.r)).toFixed(1);
      box.innerHTML = '<div class="grid grid-cols-1 sm:grid-cols-3 gap-3">' +
        '<div class="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-xs font-extrabold mb-1">🔋 الجهد الكهربائي (V): <span class="text-brand-600">' + st.ohm.v + ' فولت</span></label>' +
        '<input type="range" id="simOhmV" min="1" max="24" step="1" value="' + st.ohm.v + '" class="w-full"></div>' +
        '<div class="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-xs font-extrabold mb-1">🚧 المقاومة (R): <span class="text-amber-600">' + st.ohm.r + ' أوم (Ω)</span></label>' +
        '<input type="range" id="simOhmR" min="1" max="20" step="0.5" value="' + st.ohm.r + '" class="w-full"></div>' +
        '<div class="p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-center flex flex-col justify-center">' +
        '<div class="text-xs font-black text-emerald-700 dark:text-emerald-300">شدة التيار (I = V ÷ R): <span class="text-base">' + I + ' أمبير</span></div>' +
        '<div class="text-[11px] text-slate-500 mt-0.5">القدرة المستهلكة (P): ' + P + ' واط</div></div></div>';
      $("simOhmV").oninput = function (ev) { st.ohm.v = +ev.target.value; renderControls(); drawSim(); };
      $("simOhmR").oninput = function (ev) { st.ohm.r = +ev.target.value; renderControls(); drawSim(); };
    } else if (s === "proj") {
      var rad = st.proj.angle * Math.PI / 180;
      var tFlight = (2 * st.proj.v0 * Math.sin(rad) / st.proj.g).toFixed(2);
      var maxH = (Math.pow(st.proj.v0 * Math.sin(rad), 2) / (2 * st.proj.g)).toFixed(1);
      var rangeX = (Math.pow(st.proj.v0, 2) * Math.sin(2 * rad) / st.proj.g).toFixed(1);
      box.innerHTML = '<div class="grid grid-cols-1 sm:grid-cols-3 gap-3">' +
        '<div class="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-xs font-extrabold mb-1">🚀 السرعة الابتدائية (v₀): <span class="text-brand-600">' + st.proj.v0 + ' م/ث</span></label>' +
        '<input type="range" id="simPrV" min="10" max="45" step="1" value="' + st.proj.v0 + '" class="w-full"></div>' +
        '<div class="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-xs font-extrabold mb-1">📐 زاوية الإطلاق (θ): <span class="text-amber-600">' + st.proj.angle + '°</span></label>' +
        '<input type="range" id="simPrA" min="15" max="80" step="1" value="' + st.proj.angle + '" class="w-full"></div>' +
        '<div class="p-3 rounded-2xl bg-sky-500/15 border border-sky-500/30 text-xs font-extrabold flex flex-col justify-center gap-1">' +
        '<div>📏 المدى الأفقي: <span class="text-sky-600">' + rangeX + ' م</span></div>' +
        '<div>⛰️ أقصى ارتفاع: <span class="text-emerald-600">' + maxH + ' م</span> • الزمن: ' + tFlight + ' ث</div></div></div>';
      $("simPrV").oninput = function (ev) { st.proj.v0 = +ev.target.value; renderControls(); drawSim(); };
      $("simPrA").oninput = function (ev) { st.proj.angle = +ev.target.value; renderControls(); drawSim(); };
    } else if (s === "buoy") {
      var liquids = [
        ["زيت نباتي (0.92 غ/سم³)", 0.92],
        ["ماء عذب نقي (1.00 غ/سم³)", 1.00],
        ["ماء البحر المتوسط (1.03 غ/سم³)", 1.03],
        ["مياه البحر الميت في فلسطين (1.24 غ/سم³)", 1.24],
        ["عسل طبيعي (1.42 غ/سم³)", 1.42]
      ];
      var floats = st.buoy.objRho <= st.buoy.liqRho;
      var subPct = floats ? Math.round((st.buoy.objRho / st.buoy.liqRho) * 100) : 100;
      var stateTxt = st.buoy.objRho < st.buoy.liqRho ? "يطفو على السطح (مغمور بنسبة " + subPct + "%)"
        : st.buoy.objRho === st.buoy.liqRho ? "معلّق داخل السائل (كثافة متساوية)" : "ينغمر إلى القاع (كثافة الجسم أكبر)";
      box.innerHTML = '<div class="grid grid-cols-1 sm:grid-cols-3 gap-3">' +
        '<div class="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-xs font-extrabold mb-1">🌊 نوع السائل وكثافته</label>' +
        '<select id="simBuoyLiq" class="w-full text-xs font-bold p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700">' +
        liquids.map(function (l) { return '<option value="' + l[1] + '"' + (Math.abs(st.buoy.liqRho - l[1]) < 0.01 ? " selected" : "") + '>' + l[0] + '</option>'; }).join("") + '</select></div>' +
        '<div class="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-xs font-extrabold mb-1">🧱 كثافة الجسم: <span class="text-brand-600">' + st.buoy.objRho.toFixed(2) + ' غ/سم³</span></label>' +
        '<input type="range" id="simBuoyObj" min="0.4" max="2.0" step="0.05" value="' + st.buoy.objRho + '" class="w-full"></div>' +
        '<div class="p-3 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 text-center flex flex-col justify-center">' +
        '<div class="text-xs font-black text-cyan-700 dark:text-cyan-300">' + stateTxt + '</div></div></div>';
      $("simBuoyLiq").onchange = function (ev) { st.buoy.liqRho = +ev.target.value; renderControls(); drawSim(); };
      $("simBuoyObj").oninput = function (ev) { st.buoy.objRho = +ev.target.value; renderControls(); drawSim(); };
    } else if (s === "buoy") {
      var subRatio = Math.min(1, st.buoy.objRho / st.buoy.liqRho);
      var waterTop = 150, beakerBot = 370;
      ctx.strokeStyle = "#94a3b8"; ctx.lineWidth = 5;
      ctx.strokeRect(W / 2 - 140, 80, 280, beakerBot - 80);
      ctx.fillStyle = "rgba(14, 165, 233, 0.35)";
      ctx.fillRect(W / 2 - 135, waterTop, 270, beakerBot - waterTop - 3);
      var boxSize = 86;
      var boxY = st.buoy.objRho > st.buoy.liqRho ? (beakerBot - boxSize - 6) : (waterTop - boxSize * (1 - subRatio));
      ctx.fillStyle = st.buoy.objRho > st.buoy.liqRho ? "#f43f5e" : "#f59e0b";
      ctx.fillRect(W / 2 - boxSize / 2, boxY, boxSize, boxSize);
      ctx.fillStyle = "#fff"; ctx.font = "900 15px Cairo, sans-serif"; ctx.textAlign = "center";
      ctx.fillText(st.buoy.objRho.toFixed(2) + " g/cm³", W / 2, boxY + boxSize / 2 + 5);
      ctx.fillStyle = "#38bdf8"; ctx.font = "900 18px Cairo, sans-serif";
      ctx.fillText("كثافة السائل: " + st.buoy.liqRho.toFixed(2) + " غ/سم³  |  الجزء المغمور: " + Math.round(subRatio * 100) + "%", W / 2, 45);
    } else if (s === "ph") {
      var presets = [
        ["حمض البطارية (1.0)", 1.0], ["عصير ليمون (2.2)", 2.2], ["قهوة سوداء (5.0)", 5.0],
        ["ماء نقي متعادل (7.0)", 7.0], ["دم الإنسان (7.4)", 7.4], ["صودا الخبز (9.0)", 9.0], ["منظف أمونيا (11.5)", 11.5], ["هيدروكسيد الصوديوم (13.5)", 13.5]
      ];
      var kind = st.ph.val < 6.8 ? "حمضي (غني بأيونات +H)" : st.ph.val > 7.2 ? "قاعدي / قلوي (غني بأيونات -OH)" : "متعادل تماماً";
      box.innerHTML = '<div class="grid grid-cols-1 sm:grid-cols-3 gap-3">' +
        '<div class="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-xs font-extrabold mb-1">🧪 اختر محلولاً جاهزاً</label>' +
        '<select id="simPhPreset" class="w-full text-xs font-bold p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700">' +
        presets.map(function (p) { return '<option value="' + p[1] + '"' + (Math.abs(st.ph.val - p[1]) < 0.2 ? " selected" : "") + '>' + p[0] + '</option>'; }).join("") + '</select></div>' +
        '<div class="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-xs font-extrabold mb-1">🎚️ الرقم الهيدروجيني (pH): <span class="text-brand-600">' + st.ph.val.toFixed(1) + '</span></label>' +
        '<input type="range" id="simPhRange" min="0" max="14" step="0.2" value="' + st.ph.val + '" class="w-full"></div>' +
        '<div class="p-3 rounded-2xl bg-purple-500/15 border border-purple-500/30 text-center flex flex-col justify-center">' +
        '<div class="text-xs font-black">نوع الوسط: ' + kind + '</div></div></div>';
      $("simPhPreset").onchange = function (ev) { st.ph.val = +ev.target.value; renderControls(); drawSim(); };
      $("simPhRange").oninput = function (ev) { st.ph.val = +ev.target.value; renderControls(); drawSim(); };
    } else if (s === "photo") {
      var tempFactor = Math.max(0.1, 1 - Math.abs(st.photo.temp - 28) / 25);
      var rate = Math.round((st.photo.light * 0.5 + st.photo.co2 * 0.5) * tempFactor);
      box.innerHTML = '<div class="grid grid-cols-1 sm:grid-cols-4 gap-2.5">' +
        '<div class="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-[11px] font-extrabold">☀️ شدة الإضاءة: ' + st.photo.light + '%</label><input type="range" id="simPhL" min="0" max="100" value="' + st.photo.light + '" class="w-full"></div>' +
        '<div class="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-[11px] font-extrabold">🫧 تركيز CO₂: ' + st.photo.co2 + '%</label><input type="range" id="simPhC" min="0" max="100" value="' + st.photo.co2 + '" class="w-full"></div>' +
        '<div class="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-[11px] font-extrabold">🌡️ الحرارة: ' + st.photo.temp + '°C</label><input type="range" id="simPhT" min="5" max="48" value="' + st.photo.temp + '" class="w-full"></div>' +
        '<div class="p-2.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-center flex flex-col justify-center"><div class="text-xs font-black text-emerald-700 dark:text-emerald-300">معدل إنتاج الأكسجين O₂: ' + rate + ' فقاعة/د</div></div></div>';
      $("simPhL").oninput = function (ev) { st.photo.light = +ev.target.value; renderControls(); drawSim(); };
      $("simPhC").oninput = function (ev) { st.photo.co2 = +ev.target.value; renderControls(); drawSim(); };
      $("simPhT").oninput = function (ev) { st.photo.temp = +ev.target.value; renderControls(); drawSim(); };
    } else if (s === "graph") {
      box.innerHTML = '<div class="grid grid-cols-1 sm:grid-cols-4 gap-2.5">' +
        '<div class="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-[11px] font-extrabold">نوع الدالة</label>' +
        '<select id="simGrFn" class="w-full text-xs font-bold p-1.5 rounded-lg bg-white dark:bg-slate-900 border"><option value="quad"' + (st.graph.fn === "quad" ? " selected" : "") + '>تربيعية: f(x) = ax² + bx + c</option><option value="sin"' + (st.graph.fn === "sin" ? " selected" : "") + '>جيبية: f(x) = a·sin(bx) + c</option></select></div>' +
        '<div class="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-[11px] font-extrabold">المعامل (a): ' + st.graph.a + '</label><input type="range" id="simGrA" min="-4" max="4" step="0.5" value="' + st.graph.a + '" class="w-full"></div>' +
        '<div class="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-[11px] font-extrabold">المعامل (b): ' + st.graph.b + '</label><input type="range" id="simGrB" min="-5" max="5" step="0.5" value="' + st.graph.b + '" class="w-full"></div>' +
        '<div class="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800"><label class="block text-[11px] font-extrabold">الثابت (c): ' + st.graph.c + '</label><input type="range" id="simGrC" min="-6" max="6" step="0.5" value="' + st.graph.c + '" class="w-full"></div></div>';
      $("simGrFn").onchange = function (ev) { st.graph.fn = ev.target.value; renderControls(); drawSim(); };
      $("simGrA").oninput = function (ev) { st.graph.a = +ev.target.value; renderControls(); drawSim(); };
      $("simGrB").oninput = function (ev) { st.graph.b = +ev.target.value; renderControls(); drawSim(); };
      $("simGrC").oninput = function (ev) { st.graph.c = +ev.target.value; renderControls(); drawSim(); };
    }
  }

  function drawSim() {
    var cv = $("simCanvas"); if (!cv) return;
    var W = 900, H = 420;
    cv.width = W; cv.height = H;
    var ctx = cv.getContext("2d");
    ctx.direction = "rtl";
    ctx.fillStyle = "#0f172a"; ctx.fillRect(0, 0, W, H);

    var s = st.active;
    if (s === "ohm") {
      var I = st.ohm.v / st.ohm.r;
      var glow = Math.min(1, I / 4);
      // رسم الدائرة الكهربائية
      ctx.strokeStyle = "#38bdf8"; ctx.lineWidth = 6;
      ctx.strokeRect(160, 80, W - 320, H - 160);
      // البطارية (يسار)
      ctx.fillStyle = "#f59e0b"; ctx.fillRect(130, H / 2 - 45, 60, 90);
      ctx.fillStyle = "#fff"; ctx.font = "900 18px Cairo, sans-serif"; ctx.textAlign = "center";
      ctx.fillText(st.ohm.v + "V", 160, H / 2 + 5);
      // المقاومة (أسفل)
      ctx.fillStyle = "#e11d48"; ctx.fillRect(W / 2 - 70, H - 105, 140, 50);
      ctx.fillStyle = "#fff"; ctx.fillText("مقاومة " + st.ohm.r + " Ω", W / 2, H - 75);
      // المصباح الكهربائي (أعلى)
      ctx.save();
      ctx.beginPath(); ctx.arc(W / 2, 80, 48, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(253, 224, 71, " + (0.15 + glow * 0.85) + ")";
      ctx.shadowColor = "#fde047"; ctx.shadowBlur = glow * 65;
      ctx.fill(); ctx.restore();
      ctx.strokeStyle = "#fde047"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(W / 2, 80, 36, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = "#0f172a"; ctx.font = "900 15px Cairo, sans-serif";
      ctx.fillText("💡 المصباح", W / 2, 84);
      // الأميتر (يمين)
      ctx.fillStyle = "#10b981"; ctx.beginPath(); ctx.arc(W - 160, H / 2, 44, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#fff"; ctx.font = "900 17px Cairo, sans-serif";
      ctx.fillText(I.toFixed(2) + " A", W - 160, H / 2 + 5);
    } else if (s === "proj") {
      // أرضية ومحاور
      ctx.strokeStyle = "#475569"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(60, H - 50); ctx.lineTo(W - 40, H - 50); ctx.stroke();
      var rad = st.proj.angle * Math.PI / 180, v0 = st.proj.v0, g = st.proj.g;
      var scale = 3.6;
      ctx.strokeStyle = "#f59e0b"; ctx.lineWidth = 4; ctx.setLineDash([8, 6]);
      ctx.beginPath();
      for (var t = 0; t <= 12; t += 0.08) {
        var x = v0 * Math.cos(rad) * t;
        var y = v0 * Math.sin(rad) * t - 0.5 * g * t * t;
        if (y < 0 && t > 0) break;
        var px = 70 + x * scale, py = (H - 50) - y * scale;
        if (t === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = "#38bdf8"; ctx.beginPath(); ctx.arc(70, H - 50, 12, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#fff"; ctx.font = "800 16px Cairo, sans-serif"; ctx.textAlign = "right";
      ctx.fillText("مسار المقذوف بزاوية " + st.proj.angle + "° وسرعة " + st.proj.v0 + " م/ث", W - 50, 45);
    } else if (s === "ph") {
      var phColors = ["#ef4444", "#f97316", "#f59e0b", "#eab308", "#84cc16", "#22c55e", "#10b981", "#06b6d4", "#0284c7", "#2563eb", "#4f46e5", "#6366f1", "#7c3aed", "#9333ea", "#581c87"];
      var cIdx = Math.min(14, Math.max(0, Math.round(st.ph.val)));
      var col = phColors[cIdx];
      // شريط pH التدريجي
      for (var i = 0; i <= 14; i++) {
        var bx = 90 + i * 50;
        ctx.fillStyle = phColors[i];
        ctx.fillRect(bx, 60, 46, 36);
        ctx.fillStyle = "#fff"; ctx.font = "800 13px Cairo, sans-serif"; ctx.textAlign = "center";
        ctx.fillText(String(i), bx + 23, 114);
      }
      // الكأس المخبرية (Beaker)
      ctx.strokeStyle = "#cbd5e1"; ctx.lineWidth = 5;
      ctx.strokeRect(W / 2 - 110, 160, 220, 210);
      ctx.fillStyle = col; ctx.globalAlpha = 0.78;
      ctx.fillRect(W / 2 - 105, 210, 210, 155);
      ctx.globalAlpha = 1;
      ctx.fillStyle = "#fff"; ctx.font = "900 32px Cairo, sans-serif";
      ctx.fillText("pH = " + st.ph.val.toFixed(1), W / 2, 290);
    } else if (s === "photo") {
      var tempFactor = Math.max(0.1, 1 - Math.abs(st.photo.temp - 28) / 25);
      var rate = Math.round((st.photo.light * 0.5 + st.photo.co2 * 0.5) * tempFactor);
      // الشمس
      ctx.fillStyle = "rgba(250, 204, 21, " + (0.2 + st.photo.light / 130) + ")";
      ctx.beginPath(); ctx.arc(140, 95, 55, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#fde047"; ctx.font = "900 18px Cairo, sans-serif"; ctx.textAlign = "center";
      ctx.fillText("☀️ ضوء " + st.photo.light + "%", 140, 98);
      // نبتة مائية داخل أنبوب
      ctx.fillStyle = "rgba(14, 165, 233, 0.22)";
      ctx.fillRect(W / 2 - 110, 80, 220, 290);
      ctx.fillStyle = "#10b981";
      ctx.beginPath(); ctx.ellipse(W / 2, 260, 45, 85, 0, 0, Math.PI * 2); ctx.fill();
      // فقاعات الأكسجين
      var bCount = Math.max(1, Math.round(rate / 6));
      ctx.fillStyle = "#e0f2fe";
      for (var k = 0; k < bCount; k++) {
        var bx2 = W / 2 - 50 + ((k * 37) % 100), by2 = 220 - ((k * 29) % 130);
        ctx.beginPath(); ctx.arc(bx2, by2, 6 + (k % 4), 0, Math.PI * 2); ctx.fill();
      }
      ctx.fillStyle = "#fff"; ctx.font = "900 19px Cairo, sans-serif";
      ctx.fillText("فقاعات الأكسجين (O₂) المنطلقة: " + rate + " فقاعة/دقيقة", W / 2, 42);
    } else if (s === "graph") {
      var cx = W / 2, cy = H / 2, scaleG = 28;
      ctx.strokeStyle = "#334155"; ctx.lineWidth = 1;
      for (var gx = cx % scaleG; gx < W; gx += scaleG) { ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke(); }
      for (var gy = cy % scaleG; gy < H; gy += scaleG) { ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke(); }
      ctx.strokeStyle = "#94a3b8"; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.moveTo(0, cy); ctx.lineTo(W, cy); ctx.moveTo(cx, 0); ctx.lineTo(cx, H); ctx.stroke();

      ctx.strokeStyle = "#38bdf8"; ctx.lineWidth = 4;
      ctx.beginPath();
      var first = true;
      for (var px2 = 0; px2 < W; px2 += 2) {
        var xVal = (px2 - cx) / scaleG;
        var yVal = st.graph.fn === "sin"
          ? st.graph.a * Math.sin((st.graph.b || 1) * xVal) + st.graph.c
          : st.graph.a * xVal * xVal + st.graph.b * xVal + st.graph.c;
        var py2 = cy - yVal * scaleG;
        if (first) { ctx.moveTo(px2, py2); first = false; } else ctx.lineTo(px2, py2);
      }
      ctx.stroke();
    }
  }

  function printLabReportPdf() {
    var curSim = SIMS.filter(function (x) { return x.id === st.active; })[0] || SIMS[0];
    var paramsJson = JSON.stringify(st[st.active]);
    var dt = new Date().toLocaleDateString("ar-EG", { year: "numeric", month: "long", day: "numeric" });
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>تقرير تجربة مخبرية — ' + e(curSim.title) + '</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:14mm}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a;line-height:1.9;font-size:13.5px}h1{text-align:center;color:#0369a1;margin:0 0 4px}.sub{text-align:center;color:#475569;margin-bottom:14px;border-bottom:2px solid #cbd5e1;padding-bottom:8px}.sec{border:1.5px solid #cbd5e1;border-radius:12px;padding:12px 16px;margin-bottom:12px;background:#f8fafc}.sec h3{margin:0 0 6px;color:#0f766e;font-size:15px}.ln{border-bottom:1px dashed #94a3b8;height:28px}</style></head><body>' +
      (window.EduQR && window.EduQR.brandBanner ? window.EduQR.brandBanner('تقرير تجربة مخبرية — ' + curSim.title, location.origin + location.pathname + '?app=simLabStudio') : '') + '<h1>🧪 تقرير تجربة علمية مخبرية (STEM Virtual Lab)</h1>' +
      '<div class="sub">منصة EduTech Mindset • المبحث: <b>' + e(curSim.sub) + '</b> • التاريخ: ' + dt + '</div>' +
      '<div class="sec"><h3>1) بيانات الطالب والتجربة</h3><div><b>اسم الطالب/ـة:</b> ........................................ &nbsp;|&nbsp; <b>الصف والشعبة:</b> ....................</div><div><b>عنوان التجربة:</b> ' + e(curSim.title) + '</div></div>' +
      '<div class="sec"><h3>2) القانون والقاعدة العلمية للتجربة</h3><div>' + e(curSim.law || "") + '</div></div>' +
      '<div class="sec"><h3>3) القيم والمدخلات المسجلة أثناء المحاكاة</h3><div dir="ltr" style="font-family:monospace;text-align:right">' + e(paramsJson) + '</div></div>' +
      '<div class="sec"><h3>4) المشاهدة والاستنتاج العلمي للطالب</h3><div class="ln"></div><div class="ln"></div><div class="ln"></div></div>' +
      '<div style="display:flex;justify-content:space-between;margin-top:24px;font-weight:800"><span>توقيع الطالب/ـة: ........................</span><span>اعتماد معلم/ـة العلوم: ........................</span></div>' +
      '</body></html>';
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
  }

  function explainSimWithAI() {
    var curSim = SIMS.filter(function (x) { return x.id === st.active; })[0] || SIMS[0];
    var btn = $("simAiBtn"), out = $("simAiBox");
    if (!out) return;
    btn.disabled = true; btn.textContent = "⏳ يحلل التجربة…";
    var details = JSON.stringify(st[st.active]);
    var prompt = "أنت معلم علوم ورياضيات خبير في المنهاج الفلسطيني. الطالب يجري الآن محاكاة تفاعلية لتجربة «" + curSim.title + "» بالقيم التالية: " + details + ".\n" +
      "1) اشرح له بوضوح ماذا يحدث علمياً عند هذه القيم ولماذا.\n" +
      "2) أعطه سؤالين استنتاجيين قصيرين يجرب الإجابة عنهما من خلال تحريك المؤشرات في المختبر.";
    window.AI.ask(prompt, [], "studio").then(function (txt) {
      out.innerHTML = '<div class="rounded-2xl border border-teal-400 bg-teal-50/60 dark:bg-slate-900/70 p-4 text-xs leading-relaxed whitespace-pre-line">' +
        '<div class="font-black text-teal-700 dark:text-teal-300 mb-1">🔬 التفسير العلمي وأسئلة الاستقصاء:</div>' + e(txt) + '</div>';
      if (window.EduBadges && window.EduBadges.award) window.EduBadges.award("first_step", 25, true);
    }).catch(function () {
      toast("تعذر الاتصال بالمساعد الذكي حالياً", "warning");
    }).then(function () {
      btn.disabled = false; btn.textContent = "🤖 اشرح النتيجة وولّد أسئلة استنتاجية";
    });
  }

  function build() {
    if ($("simLabStudio")) return true;
    var anchor = $("arSection") || $("tutorStudio") || $("booksSection") || $("learnSection");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "simLabStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-indigo-800 via-blue-900 to-slate-900 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-cyan-300 mb-1">🧪 مختبر التجارب والمحاكاة العلمية التفاعلية (STEM Lab)</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">جرّب القوانين الفيزيائية والكيميائية والحيوية والرياضية بيدك (يعمل بلا إنترنت)</h2>' +
      '<p class="text-xs text-white/85 mt-1">حرّك المؤشرات لتلاحظ تغيّر التيار، مسار المقذوفات، الرقم الهيدروجيني pH، البناء الضوئي، ومنحنيات الدوال مباشرة.</p>' +
      '</div>' +
      '<div class="p-4 sm:p-6 space-y-4 text-right">' +
      '<div class="flex gap-2 overflow-x-auto pb-2" id="simTabs">' +
      SIMS.map(function (x) {
        return '<button type="button" data-sim="' + x.id + '" class="px-4 py-2.5 rounded-2xl text-xs font-extrabold whitespace-nowrap shrink-0 border transition-all">' + x.ico + ' ' + e(x.title) + '</button>';
      }).join("") + '</div>' +
      '<div id="simControls"></div>' +
      '<div class="rounded-2xl overflow-hidden border-2 border-slate-300 dark:border-slate-700 bg-slate-950 p-2"><canvas id="simCanvas" class="w-full h-auto rounded-xl"></canvas></div>' +
      '<div id="simLawBanner" class="p-3 rounded-2xl bg-indigo-50/70 dark:bg-slate-800/80 border border-indigo-200 dark:border-slate-700 text-xs font-extrabold text-indigo-900 dark:text-indigo-200"></div>' +
      '<div class="flex justify-between items-center flex-wrap gap-2">' +
      '<div class="flex flex-wrap gap-2">' +
      '<button type="button" id="simAiBtn" class="px-5 py-2.5 rounded-xl bg-gradient-to-l from-teal-600 to-emerald-600 text-white text-xs font-black shadow">🤖 اشرح النتيجة وولّد أسئلة استنتاجية بالـ AI</button>' +
      '<button type="button" id="simPrintRepBtn" class="px-4 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-black shadow">🖨 طباعة تقرير التجربة المخبرية PDF</button>' +
      '</div>' +
      '<span class="text-[11px] text-slate-500">💡 جميع المحاكيات تعمل محلياً على جهازك بلا إنترنت.</span></div>' +
      '<div id="simAiBox"></div>' +
      '</div></div></div>';

    anchor.parentNode.insertBefore(s, anchor.nextSibling);

    function refreshTabs() {
      $("simTabs").querySelectorAll("[data-sim]").forEach(function (b) {
        var on = b.dataset.sim === st.active;
        b.className = "px-4 py-2.5 rounded-2xl text-xs font-extrabold whitespace-nowrap shrink-0 border transition-all " +
          (on ? "bg-indigo-600 text-white border-indigo-600 shadow-md" : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700");
      });
      var curSim = SIMS.filter(function (x) { return x.id === st.active; })[0] || SIMS[0];
      if ($("simLawBanner")) $("simLawBanner").innerHTML = "📌 <b>القاعدة العلمية للتجربة:</b> " + e(curSim.law || "");
    }

    $("simTabs").querySelectorAll("[data-sim]").forEach(function (b) {
      b.onclick = function () {
        st.active = b.dataset.sim;
        $("simAiBox").innerHTML = "";
        refreshTabs(); renderControls(); drawSim();
      };
    });
    $("simAiBtn").onclick = explainSimWithAI;
    if ($("simPrintRepBtn")) $("simPrintRepBtn").onclick = printLabReportPdf;
    refreshTabs(); renderControls(); setTimeout(drawSim, 80);
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduSimLab = { open: function (id) { if (id) st.active = id; renderControls(); drawSim(); if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("simLabStudio", true); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

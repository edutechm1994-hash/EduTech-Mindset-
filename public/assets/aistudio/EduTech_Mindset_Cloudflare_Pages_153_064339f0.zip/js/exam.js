/*
 * صفحة الطالب للاختبار الإلكتروني — رابط ?x=ID
 * يقرأ المستند العام exams/{id}، يصحّح تلقائياً في المتصفح، ويحفظ النتيجة في examResults (يراها صاحب الاختبار فقط).
 */
(function () {
  "use strict";
  var mPack = /[?&]xpack=([A-Za-z0-9_\-=]+)/.exec(location.search);
  var m = /[?&]x=([A-Za-z0-9_-]{4,40})/.exec(location.search);
  if (!m && !mPack) return;
  var ID = m ? m[1] : ("pack_" + (mPack[1] || "").slice(0, 16)), LS = "exam_done_" + ID;
  var LET = ["أ", "ب", "ج", "د", "هـ"];
  var offlineMode = false, queuedNote = false, ord = [], oo = {}, ex = null, set = "A", qs = [], start = 0, timer = null, submitted = false;

  function e(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function $(id) { return document.getElementById(id); }
  function norm(s) {
    return String(s == null ? "" : s).toLowerCase().replace(/[ً-ٰٟـ]/g, "").replace(/[أإآ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه")
      .replace(/[٠-٩]/g, function (d) { return String(d.charCodeAt(0) - 1632); }).replace(/[۰-۹]/g, function (d) { return String(d.charCodeAt(0) - 1776); }).replace(/[.,;:!?؟،؛"'()\[\]]/g, " ").replace(/\s+/g, " ").trim();
  }
  function shuf(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function perm(n) { var p = []; for (var i = 0; i < n; i++) p.push((i + 1) % n); return p; }

  var CSS = "#exOv{position:fixed;top:0;right:0;bottom:0;left:0;z-index:400;background:#f1f5f9;overflow:auto;direction:rtl;font-family:Cairo,Tahoma,Arial,sans-serif;color:#0f172a}" +
    "#exOv *{box-sizing:border-box}.ex-w{max-width:760px;margin:0 auto;padding:16px 14px 60px}.ex-h{background:linear-gradient(135deg,#0f766e,#1e3a8a);color:#fff;border-radius:18px;padding:16px 18px;margin-bottom:14px}.ex-h h1{margin:0 0 4px;font-size:20px;font-weight:900}.ex-h p{margin:0;font-size:12px;opacity:.9}" +
    ".ex-c{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:14px;margin-bottom:12px}.ex-q{font-weight:800;font-size:15px;line-height:1.7;display:flex;gap:8px}.ex-n{flex:none;min-width:26px;height:26px;border-radius:50%;background:#0f172a;color:#fff;text-align:center;line-height:26px;font-size:12px}.ex-p{margin-inline-start:auto;font-size:11px;color:#64748b;white-space:nowrap}" +
    ".ex-o{display:flex;gap:8px;align-items:center;padding:9px 12px;border:2px solid #e2e8f0;border-radius:12px;margin-top:7px;cursor:pointer;font-weight:700;font-size:14px}.ex-o.sel{border-color:#0369a1;background:#e0f2fe}.ex-o.ok{border-color:#059669;background:#d1fae5}.ex-o.bad{border-color:#dc2626;background:#fee2e2}" +
    "#exOv input[type=text],#exOv textarea,#exOv select{width:100%;font:inherit;font-size:14px;padding:9px 12px;border:2px solid #e2e8f0;border-radius:12px;margin-top:7px;background:#fff;color:#0f172a}.ex-b{display:inline-block;border:0;border-radius:12px;padding:12px 22px;font:inherit;font-weight:900;font-size:15px;cursor:pointer;background:#0f766e;color:#fff}.ex-b.g{background:#475569}" +
    ".ex-t{position:sticky;top:0;z-index:2;background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:6px 12px;margin-bottom:12px;display:flex;justify-content:space-between;font-weight:800;font-size:13px}.ex-ans{margin-top:8px;padding:8px 12px;border-radius:10px;background:#ecfdf5;color:#065f46;font-weight:700;font-size:13px;line-height:1.7}.ex-big{text-align:center;padding:22px 10px}.ex-big b{display:block;font-size:46px;color:#0f766e;line-height:1.2}";

  function shell(html) {
    var ov = $("exOv");
    if (!ov) { var st = document.createElement("style"); st.textContent = CSS; document.head.appendChild(st); ov = document.createElement("div"); ov.id = "exOv"; document.body.appendChild(ov); document.documentElement.style.overflow = "hidden"; }
    ov.innerHTML = '<div class="ex-w">' + html + "</div>"; ov.scrollTop = 0;
  }
  function msg(title, text) { shell('<div class="ex-h"><h1>' + e(title) + "</h1></div><div class=\"ex-c\" style=\"text-align:center;font-weight:700;line-height:1.9\">" + text + '<div style="margin-top:14px"><a class="ex-b g" href="' + e(location.pathname) + '" style="text-decoration:none">العودة إلى الموقع</a></div></div>'); }

  var CK = "exam_cache_" + ID;
  function readCache() { try { var c = JSON.parse(localStorage.getItem(CK) || "null"); return c && c.ex ? c.ex : null; } catch (x) { return null; } }
  function openExam(d, fromCache) {
    ex = d; offlineMode = !!fromCache;
    var done = null; try { done = JSON.parse(localStorage.getItem(LS) || "null"); } catch (x) {}
    if (done) return msg("أنهيت هذا الاختبار", "اسمك: " + e(done.name) + "<br>درجتك: <b>" + done.score + " / " + done.max + "</b>");
    if (!ex.open) return msg(ex.title || "الاختبار", "هذا الاختبار مغلق حالياً، تواصل مع معلمك.");
    intro();
  }
  function load() {
    if (mPack && mPack[1]) {
      try {
        var b64 = mPack[1].replace(/-/g, "+").replace(/_/g, "/");
        var jsonStr = decodeURIComponent(escape(atob(b64)));
        var packedEx = JSON.parse(jsonStr);
        if (packedEx && packedEx.sets) {
          packedEx.open = true;
          return openExam(packedEx, true);
        }
      } catch (e) {}
    }
    var tries = 0, cached = readCache();
    if (cached && navigator.onLine === false) return openExam(cached, true);   // لا إنترنت: نفتح النسخة المحفوظة فوراً
    (function go() {
      if (!window.Cloud || !window.Cloud.enabled || !window.Cloud.col) { if (++tries < 40) return setTimeout(go, 300); if (cached) return openExam(cached, true); return msg("تعذر الاتصال", "تعذر الاتصال بقاعدة البيانات، حدّث الصفحة وحاول مجدداً."); }
      var settled = false, tm = setTimeout(function () { if (!settled && cached) { settled = true; openExam(cached, true); } }, 9000);
      window.Cloud.col("exams").doc(ID).get().then(function (d) {
        if (settled) return; settled = true; clearTimeout(tm);
        if (!d.exists) return msg("الاختبار غير موجود", "هذا الرابط غير صحيح أو حُذف الاختبار.");
        try { localStorage.setItem(CK, JSON.stringify({ ex: d.data(), t: Date.now() })); } catch (x) {}
        openExam(d.data(), false);
      }, function () { if (settled) return; settled = true; clearTimeout(tm); if (cached) return openExam(cached, true); msg("تعذر فتح الاختبار", "تحقق من الاتصال وحاول مجدداً."); });
    })();
  }

  // طباعة الورقة (بلا إجابات) لمن يريد الحل على الورق
  function printPaper() {
    var LT = ["أ", "ب", "ج", "د", "هـ"];
    var body = qs.map(function (q, i) {
      var h = '<div class="q"><b>' + (i + 1) + ")</b> " + e(q.q) + ' <i class="p">(' + (q.pts || 1) + ")</i>";
      if (q.t === "mcq") h += '<div class="o">' + q.options.map(function (o, k) { return "<span>" + LT[k] + ") " + e(o) + "</span>"; }).join("") + "</div>";
      else if (q.t === "tf") h += '<div class="o"><span>( ) صح</span><span>( ) خطأ</span></div>';
      else if (q.t === "match") { var rb = q.pairs.map(function (p) { return p.b; }).reverse(); h += '<table class="m">' + q.pairs.map(function (p, k) { return "<tr><td>" + e(p.a) + "</td><td>○ ——— ○</td><td>" + e(rb[k]) + "</td></tr>"; }).join("") + "</table>"; }
      else if (q.t === "short" || q.t === "problem") h += '<div class="ln"></div><div class="ln"></div>' + (q.t === "problem" ? '<div class="ln"></div><div class="ln"></div>' : "");
      return h + "</div>";
    }).join("");
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet"><style>@page{size:A4;margin:14mm}body{font-family:Cairo,Tahoma,Arial,sans-serif;color:#000;font-size:13px;line-height:1.9}h1{text-align:center;font-size:20px;margin:0 0 4px}.meta{text-align:center;font-size:12px;margin-bottom:8px}.nm{border:1px solid #000;padding:6px 10px;margin:8px 0 12px;display:flex;justify-content:space-between}.q{margin:0 0 10px;break-inside:avoid}.p{font-size:11px;color:#444}.o{display:flex;gap:22px;flex-wrap:wrap;margin:2px 14px}.ln{border-bottom:1px solid #777;height:22px}.m{margin:4px 14px;border-collapse:collapse}.m td{padding:2px 14px}</style></head><body><h1>' + e(ex.title) + '</h1><div class="meta">' + e([ex.school, ex.grade, ex.subject].filter(Boolean).join(" — ")) + '</div><div class="nm"><span>الاسم: ......................................</span><span>التاريخ: ............</span><span>الدرجة: ...... / ' + qs.reduce(function (a, q) { return a + (+q.pts || 0); }, 0) + '</span></div>' + body + "</body></html>";
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 900);
  }
  function intro() {
    var sets = ex.sets || {}, keys = Object.keys(sets).filter(function (k) { return (sets[k] || []).length; });
    set = keys.length ? keys[Math.floor(Math.random() * keys.length)] : "A"; qs = sets[set] || [];
    var tot = qs.reduce(function (a, q) { return a + (+q.pts || 0); }, 0);
    shell('<div class="ex-h"><h1>' + e(ex.title) + "</h1><p>" + e([ex.grade, ex.subject, ex.school].filter(Boolean).join(" · ")) + '</p></div><div class="ex-c"><div style="font-weight:800;margin-bottom:6px">عدد الأسئلة: ' + qs.length + " · الدرجة الكلية: " + tot + (ex.duration ? " · الزمن: " + ex.duration + " دقيقة" : "") + '</div><label style="font-weight:800;font-size:13px">اسمك الكامل</label><input id="exName" type="text" maxlength="60" placeholder="اكتب اسمك هنا">' +
      '<p style="font-size:12px;color:#475569;line-height:1.8;margin:10px 0 0">سيُحفظ اسمك ودرجتك ويراهما معلمك فقط. (الاختبار محفوظ على هاتفك: يمكنك حلّه حتى لو انقطع الإنترنت وتُرسل النتيجة عند عودته.) لا يمكنك إعادة الاختبار من هذا الجهاز بعد التسليم.</p><div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap"><button class="ex-b" id="exStart">ابدأ الاختبار</button><button class="ex-b g" id="exPrint" type="button">🖨 طباعة الورقة</button></div></div>');
    $("exPrint").onclick = printPaper;
    try {
      var dr = JSON.parse(localStorage.getItem("exam_draft_" + ID) || "null");
      if (dr && dr.name && (ex.sets || {})[dr.set]) {
        set = dr.set; qs = ex.sets[set];
        begin(dr.name, dr);
        return;
      }
    } catch (x) {}
    $("exStart").onclick = function () { var n = $("exName").value.trim(); if (n.length < 2) { $("exName").style.borderColor = "#dc2626"; $("exName").focus(); return; } begin(n); };
  }

  function qHtml(q, i, pos) {
    var h = '<div class="ex-c" data-i="' + i + '"><div class="ex-q"><span class="ex-n">' + ((pos == null ? i : pos) + 1) + "</span><span>" + e(q.q).replace(/_{3,}/g, " ______ ") + '</span><span class="ex-p">' + q.pts + " د</span></div>";
    if (q.t === "mcq") h += (oo[i] || q.options.map(function (_, k) { return k; })).map(function (k, pk) { return '<label class="ex-o" data-k="' + k + '"><input type="radio" name="q' + i + '" value="' + k + '"> ' + LET[pk] + ") " + e(q.options[k]) + "</label>"; }).join("");
    else if (q.t === "tf") h += [["1", "صح"], ["0", "خطأ"]].map(function (x) { return '<label class="ex-o" data-k="' + x[0] + '"><input type="radio" name="q' + i + '" value="' + x[0] + '"> ' + x[1] + "</label>"; }).join("");
    else if (q.t === "fill") h += '<input type="text" data-f="' + i + '" placeholder="اكتب الإجابة">';
    else if (q.t === "match") {
      var p = perm(q.pairs.length), opts = p.map(function (pi) { return q.pairs[pi].b; });
      h += q.pairs.map(function (pr, k) { return '<div style="margin-top:8px;font-weight:700">' + (k + 1) + ") " + e(pr.a) + '<select data-m="' + i + "_" + k + '"><option value="">اختر…</option>' + opts.map(function (o) { return '<option value="' + e(o) + '">' + e(o) + "</option>"; }).join("") + "</select></div>"; }).join("");
    } else h += '<textarea data-f="' + i + '" rows="' + (q.t === "problem" ? 5 : 3) + '" placeholder="اكتب إجابتك"></textarea>';
    return h + '<div class="ex-fb"></div></div>';
  }

  var DK = "exam_draft_" + ID;
  function saveDraft(name) {
    if (submitted) return;
    try {
      var ansMap = {};
      qs.forEach(function (_, i) { ansMap[i] = val(i); });
      localStorage.setItem(DK, JSON.stringify({ name: name, set: set, ord: ord, oo: oo, start: start, ans: ansMap }));
    } catch (x) {}
  }
  function begin(name, draft) {
    start = (draft && draft.start) ? draft.start : Date.now(); submitted = false;
    ord = (draft && draft.ord && draft.ord.length === qs.length) ? draft.ord : qs.map(function (_, i) { return i; });
    oo = (draft && draft.oo) ? draft.oo : {};
    if (!draft && ex.shuffle !== "off") { ord = shuf(ord); qs.forEach(function (q, i) { if (q.t === "mcq") oo[i] = shuf(q.options.map(function (_, k) { return k; })); }); }
    var restoredBanner = draft ? '<div class="ex-c" style="background:#ecfdf5;border:2px solid #10b981;color:#065f46;font-weight:800;font-size:13px;text-align:center">🔄 تم استعادة إجاباتك المحفوظة تلقائياً — أكمل الحل من حيث توقفت!</div>' : '';
    shell('<div class="ex-t"><span>' + e(name) + ' <small style="color:#059669;font-weight:700">(حفظ تلقائي ✓)</small></span><span id="exTm"></span></div><div class="ex-h"><h1>' + e(ex.title) + "</h1></div>" + restoredBanner + ord.map(function (i, pos) { return qHtml(qs[i], i, pos); }).join("") + '<div style="text-align:center;margin-top:10px"><button class="ex-b" id="exSend">تسليم الإجابات</button></div>');
    if (draft && draft.ans) {
      qs.forEach(function (q, i) {
        var v = draft.ans[i], root = document.querySelector('.ex-c[data-i="' + i + '"]');
        if (!root || v == null || v === "") return;
        if (q.t === "mcq" || q.t === "tf") {
          var r = root.querySelector('input[value="' + v + '"]');
          if (r) { r.checked = true; var lbl = r.closest(".ex-o"); if (lbl) lbl.classList.add("sel"); }
        } else if (q.t === "match" && Array.isArray(v)) {
          v.forEach(function (mv, k) { var sel = root.querySelector('[data-m="' + i + "_" + k + '"]'); if (sel && mv) sel.value = mv; });
        } else {
          var inp = root.querySelector("[data-f]"); if (inp) inp.value = v;
        }
      });
    }
    $("exOv").addEventListener("change", function (ev) { var o = ev.target.closest && ev.target.closest(".ex-o"); if (o) { o.parentNode.querySelectorAll(".ex-o").forEach(function (x) { x.classList.remove("sel"); }); o.classList.add("sel"); } saveDraft(name); });
    $("exOv").addEventListener("input", function () { saveDraft(name); });
    $("exSend").onclick = function () { var un = unanswered(); if (un && !window.eduConfirm("لم تجب عن " + un + " سؤال/أسئلة. هل تريد التسليم رغم ذلك؟")) return; submit(name); };
    if (ex.duration) {
      var end = start + ex.duration * 60000, tm = $("exTm");
      timer = setInterval(function () {
        var left = Math.max(0, end - Date.now()), mm = Math.floor(left / 60000), ss = Math.floor(left / 1000) % 60;
        tm.textContent = "⏱ " + mm + ":" + (ss < 10 ? "0" : "") + ss; if (left < 60000) tm.style.color = "#dc2626";
        if (left <= 0) { clearInterval(timer); submit(name); }
      }, 500);
    }
  }
  function val(i) {
    var q = qs[i], root = document.querySelector('.ex-c[data-i="' + i + '"]');
    if (q.t === "mcq" || q.t === "tf") { var r = root.querySelector("input:checked"); return r ? r.value : ""; }
    if (q.t === "match") return q.pairs.map(function (_, k) { return root.querySelector('[data-m="' + i + "_" + k + '"]').value; });
    return root.querySelector("[data-f]").value.trim();
  }
  function unanswered() { var n = 0; qs.forEach(function (q, i) { var v = val(i); if (Array.isArray(v) ? v.every(function (x) { return !x; }) : !v) n++; }); return n; }
  // يُرجع نسبة الصحة 0..1، أو -1 إن كان السؤال يحتاج تصحيحاً يدوياً
  function grade(q, v) {
    if (q.t === "mcq") return v !== "" && +v === +q.answer ? 1 : 0;
    if (q.t === "tf") return v !== "" && (v === "1") === !!q.answer ? 1 : 0;
    if (q.t === "fill") { if (!v) return 0; var alts = String(q.answer || "").split(/[\/|،]/).map(norm).filter(Boolean); return alts.indexOf(norm(v)) >= 0 ? 1 : 0; }
    if (q.t === "match") { var ok = 0; q.pairs.forEach(function (p, k) { if (v[k] && v[k] === p.b) ok++; }); return ok / q.pairs.length; }
    return -1;
  }
  function submit(name) {
    if (submitted) return; submitted = true; if (timer) clearInterval(timer);
    var score = 0, max = 0, corr = [], ans = [];
    qs.forEach(function (q, i) {
      var v = val(i), g = grade(q, v); corr.push(g);
      ans.push(Array.isArray(v) ? v.join(" ‖ ") : String(v).slice(0, 600));
      if (g >= 0) { max += +q.pts || 0; score += (+q.pts || 0) * g; }
    });
    score = Math.round(score * 10) / 10;
    var rec = { examId: ID, ownerUid: ex.ownerUid, name: name.slice(0, 60), set: set, answers: ans, correct: corr, score: score, max: max, pct: max ? Math.round(score * 100 / max) : 0, secs: Math.round((Date.now() - start) / 1000) };
    var rid = "r" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    var btn = $("exSend"); if (btn) { btn.disabled = true; btn.textContent = "جارٍ التسليم…"; }
    function finish() { try { localStorage.removeItem("exam_draft_" + ID); localStorage.setItem(LS, JSON.stringify({ name: name, score: score, max: max })); } catch (x) {} done(name, score, max, corr, ans); }
    function queueIt() { // لا إنترنت: نحفظ النتيجة على الهاتف وتُرسل تلقائياً عند عودة الاتصال
      var q = []; try { q = JSON.parse(localStorage.getItem("exam_q") || "[]"); } catch (x) {}
      q.push({ id: rid, rec: rec }); try { localStorage.setItem("exam_q", JSON.stringify(q)); } catch (x) { submitted = false; if (btn) { btn.disabled = false; btn.textContent = "تسليم الإجابات"; } window.eduAlert("تعذر حفظ إجاباتك على الهاتف. تحقق من الاتصال وأعد المحاولة."); return; }
      queuedNote = true; finish();
    }
    if (offlineMode || navigator.onLine === false || !window.Cloud || !window.Cloud.col) return queueIt();
    var settled = false, tm = setTimeout(function () { if (!settled) { settled = true; queueIt(); } }, 15000);
    window.Cloud.col("examResults").doc(rid).set(Object.assign({}, rec, { at: window.Cloud.stamp() })).then(function () {
      if (settled) return; settled = true; clearTimeout(tm); finish();
    }, function (err) {
      if (settled) return; settled = true; clearTimeout(tm);
      if (err && err.code === "permission-denied") { submitted = false; if (btn) { btn.disabled = false; btn.textContent = "تسليم الإجابات"; } window.eduAlert("أُغلق هذا الاختبار ولم يعد يقبل التسليم."); return; }
      queueIt();
    });
  }
  // بطاقة نتيجة (صورة) يشاركها الطالب مع أهله
  function shareCard(name, score, max, manual) {
    var pct = max ? Math.round(score * 100 / max) : 0, W = 1080, H = 1350, cv = document.createElement("canvas"); cv.width = W; cv.height = H;
    var P = pct >= 85 ? ["#042f2e", "#065f46", "#10b981", "#fde047", "ممتاز! أداء رائع 🌟"] : pct >= 60 ? ["#06152d", "#0c2d5e", "#0077ff", "#fbbf24", "جيد جداً، واصل التقدم 👏"] : pct >= 40 ? ["#1e1b18", "#422006", "#b45309", "#fde047", "مقبول، وبقليل من المراجعة ستتحسن 💪"] : ["#1e1b4b", "#4c1d95", "#7c3aed", "#fde047", "المحاولة بداية التعلّم، وسأعيدها أفضل 🌱"];
    var F = "Alexandria, Cairo, Tahoma, Arial, sans-serif", logo = new Image();
    function paint() {
      var ctx = cv.getContext("2d"); ctx.direction = "rtl"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      var g = ctx.createLinearGradient(0, 0, W, H); g.addColorStop(0, P[0]); g.addColorStop(0.55, P[1]); g.addColorStop(1, P[2]); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      ctx.save(); ctx.globalAlpha = 0.09; ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(W * 0.95, H * 0.05, W * 0.34, 0, 7); ctx.fill(); ctx.beginPath(); ctx.arc(W * 0.03, H * 0.97, W * 0.3, 0, 7); ctx.fill(); ctx.restore();
      var y = 70;
      if (logo.complete && logo.naturalWidth) { var lh = 100, lw = Math.round(lh * logo.naturalWidth / logo.naturalHeight); ctx.fillStyle = "rgba(255,255,255,.96)"; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(W / 2 - lw / 2 - 16, y, lw + 32, lh + 16, 22) : ctx.rect(W / 2 - lw / 2 - 16, y, lw + 32, lh + 16); ctx.fill(); ctx.drawImage(logo, W / 2 - lw / 2, y + 8, lw, lh); y += lh + 60; } else y += 60;
      ctx.fillStyle = P[3]; ctx.font = "800 40px " + F; ctx.fillText("بطاقة نتيجة اختبار", W / 2, y); y += 90;
      var ns = 78; ctx.font = "900 " + ns + "px " + F; while (ctx.measureText(name).width > W - 160 && ns > 40) { ns -= 4; ctx.font = "900 " + ns + "px " + F; }
      ctx.fillStyle = "#fff"; ctx.fillText(name, W / 2, y); y += 85;
      ctx.fillStyle = "#e2e8f0"; ctx.font = "700 38px " + F; var tt = ex.title || ""; while (ctx.measureText(tt).width > W - 140 && tt.length > 6) tt = tt.slice(0, -2); ctx.fillText(tt === (ex.title || "") ? tt : tt + "…", W / 2, y); y += 56;
      var sub = [ex.grade, ex.subject].filter(Boolean).join(" · "); if (sub) { ctx.fillStyle = "#cbd5e1"; ctx.font = "600 32px " + F; ctx.fillText(sub, W / 2, y); }
      // حلقة النسبة
      var cx = W / 2, cy = 780, R = 190; ctx.lineWidth = 42; ctx.lineCap = "round"; ctx.strokeStyle = "rgba(255,255,255,.18)"; ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = P[3]; ctx.beginPath(); ctx.arc(cx, cy, R, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.max(0.02, Math.min(1, pct / 100))); ctx.stroke();
      ctx.fillStyle = "#fff"; ctx.font = "900 120px " + F; ctx.fillText(pct + "%", cx, cy - 8); ctx.font = "700 36px " + F; ctx.fillStyle = "#e2e8f0"; ctx.fillText(score + " من " + max, cx, cy + 82);
      ctx.fillStyle = "#fff"; ctx.font = "900 50px " + F; ctx.fillText(P[4], W / 2, 1090);
      if (manual) { ctx.fillStyle = "#cbd5e1"; ctx.font = "600 28px " + F; ctx.fillText("الدرجة تلقائية، والأسئلة المكتوبة يصحّحها المعلم", W / 2, 1155); }
      ctx.fillStyle = "rgba(255,255,255,.8)"; ctx.font = "700 30px " + F; ctx.fillText(new Date().toLocaleDateString("ar-EG", { day: "numeric", month: "long", year: "numeric" }) + "  •  " + location.host, W / 2, H - 60);
      cv.toBlob(function (b) {
        var f = new File([b], "نتيجة.png", { type: "image/png" });
        if (navigator.canShare && navigator.canShare({ files: [f] })) { navigator.share({ files: [f], title: "نتيجتي في " + (ex.title || "الاختبار"), text: "نتيجتي في اختبار " + (ex.title || "") + ": " + pct + "%" }).catch(function () {}); return; }
        var a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = "نتيجة_" + name + ".png"; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 800);
      }, "image/png");
    }
    var go = function () { logo.onload = logo.onerror = paint; logo.src = "assets/logo.png"; };
    if (document.fonts && document.fonts.load) Promise.all([document.fonts.load("900 40px Alexandria"), document.fonts.load("600 30px Alexandria")]).then(go, go); else go();
  }
  function certificate(name, score, max) {
    var pct = max ? Math.round(score * 100 / max) : 0, d = new Date().toLocaleDateString("ar-EG", { day: "numeric", month: "long", year: "numeric" });
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet"><style>@page{size:A4;margin:0}*{box-sizing:border-box}body{margin:0;font-family:Cairo,Tahoma,Arial,sans-serif;color:#1e1b4b}.p{width:210mm;height:296mm;padding:10mm;overflow:hidden}.b{height:100%;border:3mm double #b45309;border-radius:6mm;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:8mm;background:linear-gradient(#fffbeb,#fff)}h1{font-size:60px;margin:6px 0 14px;color:#b45309;font-weight:900}.s{font-size:22px;margin:10px 0}.n{font-size:48px;font-weight:900;color:#4338ca;margin:16px 0;border-bottom:3px solid #fbbf24;padding:0 30px 6px}.t{font-size:28px;font-weight:700;margin:8px 0}.f{display:flex;gap:40px;margin-top:40px;font-size:18px;font-weight:700}</style></head><body><div class="p"><div class="b"><img src="' + location.origin + '/assets/logo.png" alt="" style="height:90px;margin-bottom:8px" onerror="this.remove()"><div style="font-size:80px">🏅</div><h1>شهادة إنجاز</h1><div class="s">تشهد ' + e(ex.school || "منصة عقلية التعليم والتكنولوجيا") + ' بأن الطالب/ـة</div><div class="n">' + e(name) + '</div><div class="s">قد اجتاز/ت بنجاح اختبار</div><div class="t">' + e(ex.title) + '</div><div class="s">' + e([ex.grade, ex.subject].filter(Boolean).join(" · ")) + '</div><div class="t">بدرجة ' + score + " من " + max + " (" + pct + "%)</div>" +
      '<div class="f"><span>التاريخ: ' + d + "</span>" + (ex.teacher ? "<span>المعلم/ـة: " + e(ex.teacher) + "</span>" : "") + "</div></div></div></body></html>";
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 900);
  }
  function done(name, score, max, corr, ans) {
    try {
      if (window.EduBadges && window.EduBadges.award) {
        window.EduBadges.award("quiz_starter", 50, true);
        if (max > 0 && Math.round(score * 100 / max) >= 90) window.EduBadges.award("sharp_shooter", 100, true);
      }
    } catch (x) {}
    var show = ex.showAnswers !== "hidden", manual = corr.some(function (c) { return c < 0; });
    var h = '<div class="ex-h"><h1>' + e(ex.title) + '</h1></div><div class="ex-c ex-big">✅ تم تسليم إجاباتك يا ' + e(name.split(" ")[0]) + '<b>' + score + " / " + max + "</b>" + (manual ? '<div style="font-size:12px;color:#64748b;margin-top:6px">الأسئلة المكتوبة يصحّحها معلمك ولا تدخل في هذه الدرجة</div>' : "") + "</div>";
    var order = ord.length === qs.length ? ord : qs.map(function (_, i) { return i; });
    function lt(i, k) { var o = oo[i]; return LET[o ? o.indexOf(+k) : +k]; }
    if (show) h += order.map(function (i, pos) {
      var q = qs[i], c = corr[i], a = "", mine = ans[i];
      if (q.t === "mcq" && mine !== "" && q.options[+mine] != null) mine = lt(i, mine) + ") " + q.options[+mine];
      else if (q.t === "tf" && mine !== "") mine = mine === "1" ? "صح" : "خطأ";
      if (q.t === "mcq") a = "الإجابة الصحيحة: " + lt(i, q.answer) + ") " + e(q.options[q.answer]);
      else if (q.t === "tf") a = "الإجابة الصحيحة: " + (q.answer ? "صح" : "خطأ");
      else if (q.t === "match") a = "الإجابة الصحيحة: " + q.pairs.map(function (p) { return e(p.a) + " ← " + e(p.b); }).join(" ، ");
      else a = (q.t === "problem" ? "الحل: " : "الإجابة: ") + e(q.answer);
      return '<div class="ex-c"><div class="ex-q"><span class="ex-n" style="background:' + (c === 1 ? "#059669" : c < 0 ? "#64748b" : c === 0 ? "#dc2626" : "#d97706") + '">' + (pos + 1) + "</span><span>" + e(q.q) + '</span></div><div style="margin-top:6px;font-size:13px;color:#475569">إجابتك: ' + (e(mine) || "—") + '</div><div class="ex-ans">' + a + "</div></div>";
    }).join("");
    if (queuedNote) h = h.replace('<div class="ex-c ex-big">', '<div class="ex-c" style="text-align:center;background:#eff6ff;border:2px solid #3b82f6;font-weight:800;font-size:13px;line-height:1.9">📶 لا يوجد إنترنت الآن، فحُفظت نتيجتك على هاتفك وستُرسل لمعلمك تلقائياً عندما يعود الاتصال. اترك هذه الصفحة مفتوحة أو افتح الموقع لاحقاً.</div><div class="ex-c ex-big">');
    var cp = ex.certPct == null ? 60 : +ex.certPct, earned = cp > 0 && max > 0 && Math.round(score * 100 / max) >= cp;
    if (earned) h = h.replace('<div class="ex-c ex-big">', '<div class="ex-c" style="text-align:center;background:#fffbeb;border:2px solid #f59e0b"><div style="font-size:15px;font-weight:900;color:#b45309">🏅 مبروك! حصلت على شهادة إنجاز</div><button class="ex-b" id="exCert" type="button" style="margin-top:8px;background:#d97706">🖨 اطبع الشهادة / احفظها PDF</button></div><div class="ex-c ex-big">');
    if (max > 0) h += '<div style="text-align:center;margin-bottom:10px"><button class="ex-b" id="exShare" type="button" style="background:#16a34a">📤 شارك بطاقة نتيجتك مع أهلك</button></div>';
    h += '<div style="text-align:center"><a class="ex-b g" href="' + e(location.pathname) + '" style="text-decoration:none">العودة إلى الموقع</a></div>';
    shell(h);
    var cb = $("exCert"); if (cb) cb.onclick = function () { certificate(name, score, max); };
    var sb = $("exShare"); if (sb) sb.onclick = function () { shareCard(name, score, max, (corr || []).some(function (x) { return x < 0; })); };
  }
  function init() { shell('<div class="ex-c" style="text-align:center;font-weight:800">⏳ جارٍ تحميل الاختبار…</div>'); load(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

/* إرسال النتائج المؤجلة (الاختبارات التي سُلّمت بلا إنترنت) متى توفّر الاتصال */
(function () {
  "use strict";
  var busy = false;
  function readQ() { try { return JSON.parse(localStorage.getItem("exam_q") || "[]"); } catch (x) { return []; } }
  function flush() {
    var q = readQ(); if (!q.length || busy || navigator.onLine === false) return;
    if (!window.Cloud || !window.Cloud.enabled || !window.Cloud.col) return;
    busy = true; var left = q.slice(), sent = 0;
    (function next() {
      var it = left[0]; if (!it) { busy = false; if (sent && typeof showToast === "function") showToast("تم إرسال نتيجة اختبارك إلى المعلم ✓", "success"); return; }
      window.Cloud.col("examResults").doc(it.id).set(Object.assign({}, it.rec, { at: window.Cloud.stamp() })).then(function () { left.shift(); sent++; try { localStorage.setItem("exam_q", JSON.stringify(left)); } catch (x) {} next(); },
        function (err) { if (err && err.code === "permission-denied") { left.shift(); try { localStorage.setItem("exam_q", JSON.stringify(left)); } catch (x) {} next(); } else { busy = false; } });
    })();
  }
  window.addEventListener("online", function () { setTimeout(flush, 1500); });
  var n = 0, iv = setInterval(function () { if (readQ().length === 0 || ++n > 60) { clearInterval(iv); return; } flush(); }, 5000);
  setTimeout(flush, 3000);
  window.EduExamQueue = { flush: flush, pending: function () { return readQ().length; } };
})();

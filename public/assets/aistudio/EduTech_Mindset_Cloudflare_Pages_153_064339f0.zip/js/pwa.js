/* تفعيل العمل مع ضعف الاتصال + إشعار التحديث الفوري + شريط تنبيه عند الانقطاع (الإصدار 68) */
(function () {
  "use strict";
  if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
    window.addEventListener("load", function () {
      navigator.serviceWorker.register("sw.js").then(function (reg) {
        reg.addEventListener("updatefound", function () {
          var nw = reg.installing;
          if (!nw) return;
          nw.addEventListener("statechange", function () {
            if (nw.state === "installed" && navigator.serviceWorker.controller) {
              if (typeof showToast === "function") {
                showToast("✨ تم تحديث المنصة بالخلفية لأحدث إصدار ✓", "success");
              }
            }
          });
        });
      }).catch(function () {});
    });
  }
  var bar = null;
  function show(off) {
    if (off) {
      if (bar) return;
      bar = document.createElement("div"); bar.id = "offBar";
      bar.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:9999;background:linear-gradient(90deg,#b45309,#d97706);color:#fff;text-align:center;font:800 11.5px Cairo,Tahoma,sans-serif;padding:6px 12px;direction:rtl;box-shadow:0 4px 12px rgba(0,0,0,.3)";
      bar.innerHTML = "⚠️ وضع العمل بلا إنترنت نشط — يمكنك تصفح الأدوات المحفوظة وحقيبة المذاكرة وبنك الأسئلة محلياً";
      document.body.appendChild(bar);
    } else if (bar) {
      bar.remove(); bar = null;
      if (typeof showToast === "function") showToast("🌐 عاد الاتصال بالإنترنت — تمت المزامنة ✓", "success");
    }
  }
  window.addEventListener("offline", function () { show(true); });
  window.addEventListener("online", function () { show(false); });
  if (document.readyState !== "loading") { if (!navigator.onLine) show(true); } else document.addEventListener("DOMContentLoaded", function () { if (!navigator.onLine) show(true); });
})();

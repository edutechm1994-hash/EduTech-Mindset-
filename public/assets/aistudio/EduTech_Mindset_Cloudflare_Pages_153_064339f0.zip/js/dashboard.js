/* لوحة المعلم: كل ما أنشأه المعلم في مكان واحد (عروض، أوراق، خطط، تصاميم، اختبارات منشورة ونتائجها، ومنشوراته في المواد) */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var cloud = function () { return !!(window.Cloud && window.Cloud.enabled && window.Cloud.col); };
  var uid = function () { return window.Cloud && window.Cloud.getStudioUser ? window.Cloud.getStudioUser().uid : (window.Cloud && window.Cloud.user && window.Cloud.user.uid); };
  var email = function () { return (window.Cloud && window.Cloud.user && window.Cloud.user.email) || ""; };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "info"); };
  var TYPES = {
    slides: { col: "presentations", ico: "🎞", lbl: "عرض", sec: "slidesStudio", api: "EduSlides" },
    ws: { col: "worksheets", ico: "📝", lbl: "ورقة / اختبار", sec: "worksheetStudio", api: "EduWorksheets" },
    gm: { col: "games", ico: "🎮", lbl: "لعبة تفاعلية", sec: "gamesStudio", api: "EduGames" },
    cl: { col: "classrooms", ico: "🏫", lbl: "فصل دراسي", sec: "classroomsStudio", api: "" },
    lp: { col: "lessonplans", ico: "📘", lbl: "خطة درس", sec: "lessonPlanStudio", api: "EduLessonPlans" },
    dz: { col: "designs", ico: "🎨", lbl: "تصميم", sec: "designStudio", api: "EduDesigns" },
    res: { col: "resources", ico: "📌", lbl: "منشور في مادة", sec: "learnSection", api: "" }
  };
  var ORDER = ["slides", "ws", "gm", "cl", "lp", "dz", "res"];
  var S = { items: [], exams: [], results: {}, f: "all", q: "", loaded: false };
  var secs = function (r) { return (r && r.seconds) || 0; };
  function when(t) { var s = secs(t); if (!s) return ""; try { return new Date(s * 1000).toLocaleDateString("ar-EG", { day: "numeric", month: "short", year: "numeric" }); } catch (x) { return ""; } }
  function examLink(id) { return location.origin + location.pathname + "?x=" + id; }
  function pull(col, field, val) {
    return window.Cloud.col(col).where(field, "==", val).get().then(function (s) { return s.docs.map(function (d) { return Object.assign({ id: d.id }, d.data()); }); }, function () { return []; });
  }

  function load() {
    var box = $("tdBody"); if (!box) return;
    if (!cloud() || !uid()) { box.innerHTML = '<p class="text-xs text-slate-500 py-6 text-center">سجّل الدخول لترى لوحتك.</p>'; return; }
    box.innerHTML = '<p class="text-xs text-slate-500 py-6 text-center">⏳ جارٍ تحميل لوحتك…</p>';
    var jobs = [pull("presentations", "ownerUid", uid()), pull("worksheets", "ownerUid", uid()), pull("lessonplans", "ownerUid", uid()), pull("designs", "ownerUid", uid()), pull("exams", "ownerUid", uid()), pull("examResults", "ownerUid", uid()), email() ? pull("resources", "updatedBy", email()) : Promise.resolve([]), pull("games", "ownerUid", uid()), pull("classrooms", "ownerUid", uid())];
    Promise.all(jobs).then(function (r) {
      S.items = [];
      ["slides", "ws", "lp", "dz"].forEach(function (k, i) { r[i].forEach(function (d) { S.items.push({ type: k, id: d.id, title: d.title || d.topic || "بدون عنوان", at: secs(d.updatedAt), sub: [d.grade, d.subject].filter(Boolean).join(" • "), raw: d }); }); });
      (r[7] || []).forEach(function (d) { S.items.push({ type: "gm", id: d.id, title: d.title || "لعبة تفاعلية", at: secs(d.updatedAt), sub: [d.grade, d.subject].filter(Boolean).join(" • "), raw: d }); });
      (r[8] || []).forEach(function (d) { S.items.push({ type: "cl", id: d.id, title: d.title + " (" + d.id + ")", at: secs(d.updatedAt), sub: [d.grade, d.subject].filter(Boolean).join(" • "), raw: d }); });
      r[6].forEach(function (d) { S.items.push({ type: "res", id: d.id, title: d.title || "بدون عنوان", at: secs(d.updatedAt), sub: d.kind || "", raw: d }); });
      S.items.sort(function (a, b) { return b.at - a.at; });
      S.exams = r[4].sort(function (a, b) { return secs(b.updatedAt) - secs(a.updatedAt); });
      S.results = {}; r[5].forEach(function (x) { var o = S.results[x.examId] || (S.results[x.examId] = { n: 0, sum: 0 }); o.n++; o.sum += +x.pct || 0; });
      S.loaded = true; paint();
    });
  }

  function paint() {
    var box = $("tdBody"); if (!box) return;
    var cnt = {}; ORDER.forEach(function (k) { cnt[k] = S.items.filter(function (i) { return i.type === k; }).length; });
    var tiles = ORDER.map(function (k) { return '<button type="button" data-f="' + k + '" class="rounded-2xl p-3 text-center border ' + (S.f === k ? "bg-brand-600 text-white border-brand-600" : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700") + '"><div class="text-xl">' + TYPES[k].ico + '</div><div class="text-lg font-black">' + cnt[k] + '</div><div class="text-[10px] font-bold opacity-80">' + TYPES[k].lbl + "</div></button>"; }).join("");
    var q = S.q.trim().toLowerCase();
    var list = S.items.filter(function (i) { return (S.f === "all" || i.type === S.f) && (!q || (i.title + " " + i.sub).toLowerCase().indexOf(q) !== -1); });
    var h = '<div class="grid grid-cols-4 sm:grid-cols-7 gap-2 mb-3">' + tiles + '</div><div class="flex gap-2 mb-3"><input id="tdQ" class="flex-1 min-w-0 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs" placeholder="ابحث في أعمالك…" value="' + e(S.q) + '">' + (S.f !== "all" ? '<button type="button" data-f="all" class="px-3 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-[11px] font-bold shrink-0">عرض الكل</button>' : "") + '<button type="button" id="tdReload" class="px-3 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-[11px] font-bold shrink-0">↻</button></div>';
    if (S.f === "all" || S.f === "ws") {
      h += '<h3 class="text-xs font-black mb-2">🌐 اختباراتي المنشورة للطلاب (' + S.exams.length + ")</h3>" + (S.exams.length ? '<div class="space-y-2 mb-5">' + S.exams.map(function (x) {
        var r = S.results[x.id] || { n: 0, sum: 0 };
        return '<div class="rounded-xl p-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700"><div class="flex items-start gap-2"><div class="flex-1 min-w-0"><div class="text-xs font-extrabold break-words">' + e(x.title) + '</div><div class="text-[10px] text-slate-500 mt-0.5">' + e([x.grade, x.subject].filter(Boolean).join(" • ")) + " · " + when(x.updatedAt) + '</div></div><span class="shrink-0 text-[10px] font-black px-2 py-1 rounded-full ' + (x.open === false ? "bg-slate-200 text-slate-600" : "bg-emerald-500/15 text-emerald-700") + '">' + (x.open === false ? "مغلق" : "مفتوح") + '</span></div>' +
          '<div class="text-[11px] mt-2">👥 ' + r.n + " طالب" + (r.n ? " • المتوسط " + Math.round(r.sum / r.n) + "%" : "") + '</div><div class="flex flex-wrap gap-1.5 mt-2"><button type="button" data-ex="copy" data-id="' + e(x.id) + '" class="px-2.5 py-1.5 rounded-lg bg-brand-600 text-white text-[11px] font-bold">نسخ الرابط</button><button type="button" data-ex="res" data-id="' + e(x.id) + '" class="px-2.5 py-1.5 rounded-lg bg-emerald-600 text-white text-[11px] font-bold">النتائج</button><button type="button" data-ex="tog" data-id="' + e(x.id) + '" class="px-2.5 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-[11px] font-bold">' + (x.open === false ? "▶ فتح" : "⏸ إغلاق") + '</button><button type="button" data-ex="del" data-id="' + e(x.id) + '" class="px-2.5 py-1.5 rounded-lg bg-rose-500/10 text-rose-600 text-[11px] font-bold">إلغاء النشر</button></div></div>';
      }).join("") + "</div>" : '<p class="text-[11px] text-slate-500 mb-5">لا اختبارات منشورة. افتح ورقة عمل واضغط «🌐 اختبار إلكتروني».</p>');
    }
    h += '<h3 class="text-xs font-black mb-2">🗂 أعمالي (' + list.length + ")</h3>" + (list.length ? '<div class="space-y-2">' + list.map(function (i) {
      var T = TYPES[i.type];
      return '<div class="flex items-center gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700"><div class="text-xl shrink-0">' + T.ico + '</div><div class="flex-1 min-w-0"><div class="text-xs font-extrabold truncate">' + e(i.title) + '</div><div class="text-[10px] text-slate-500 truncate">' + T.lbl + (i.sub ? " • " + e(i.sub) : "") + (i.at ? " • " + when({ seconds: i.at }) : "") + '</div></div>' +
        (T.api ? '<button type="button" data-it="open" data-t="' + i.type + '" data-id="' + e(i.id) + '" class="px-3 py-1.5 rounded-lg bg-brand-600 text-white text-[11px] font-bold shrink-0">فتح</button>' : "") +
        '<button type="button" data-it="del" data-t="' + i.type + '" data-id="' + e(i.id) + '" class="px-2.5 py-1.5 rounded-lg bg-rose-500/10 text-rose-500 text-[11px] shrink-0">🗑</button></div>';
    }).join("") + "</div>" : '<p class="text-[11px] text-slate-500">لا شيء هنا بعد.</p>');
    box.innerHTML = h;
    box.querySelectorAll("[data-f]").forEach(function (b) { b.addEventListener("click", function () { S.f = S.f === b.dataset.f ? "all" : b.dataset.f; paint(); }); });
    var qi = $("tdQ"); if (qi) qi.addEventListener("input", function () { S.q = qi.value; var pos = qi.selectionStart; paint(); var n = $("tdQ"); n.focus(); try { n.setSelectionRange(pos, pos); } catch (x) {} });
    $("tdReload").addEventListener("click", load);
    box.querySelectorAll("[data-it]").forEach(function (b) { b.addEventListener("click", function () { item(b.dataset.it, b.dataset.t, b.dataset.id); }); });
    box.querySelectorAll("[data-ex]").forEach(function (b) { b.addEventListener("click", function () { exam(b.dataset.ex, b.dataset.id); }); });
  }

  function item(act, type, id) {
    var T = TYPES[type];
    if (act === "open") {
      var api = window[T.api]; if (!api || !api.openId) { toast("الأداة غير جاهزة بعد", "warning"); return; }
      if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump(T.sec, true); else { var sec = $(T.sec); if (sec) sec.scrollIntoView({ behavior: "smooth", block: "start" }); }
      api.openId(id); return;
    }
    if (!window.eduConfirm("حذف هذا العنصر نهائياً؟")) return;
    window.Cloud.col(T.col).doc(id).delete().then(function () { toast("تم الحذف", "info"); load(); }, function () { toast("تعذر الحذف", "warning"); });
  }
  function exam(act, id) {
    if (act === "copy") { var l = examLink(id); (navigator.clipboard ? navigator.clipboard.writeText(l) : Promise.reject()).then(function () { toast("تم نسخ رابط الاختبار ✓", "success"); }, function () { window.eduPrompt("انسخ الرابط:", l); }); return; }
    if (act === "res") { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("worksheetStudio", true); else { var s = $("worksheetStudio"); if (s) s.scrollIntoView({ behavior: "smooth", block: "start" }); } if (window.EduWorksheets && window.EduWorksheets.openExam) window.EduWorksheets.openExam(id); return; }
    if (act === "tog") { var x = S.exams.filter(function (q) { return q.id === id; })[0]; if (!x) return; var nv = x.open === false; window.Cloud.col("exams").doc(id).set({ open: nv }, { merge: true }).then(function () { x.open = nv; toast(nv ? "تم فتح الاختبار" : "تم إغلاق الاختبار", "info"); paint(); }, function () { toast("تعذر التغيير", "warning"); }); return; }
    if (act === "del") { if (!window.eduConfirm("إلغاء نشر هذا الاختبار؟ سيتوقف الرابط عن العمل، وتبقى ورقة العمل محفوظة عندك.")) return; window.Cloud.col("exams").doc(id).delete().then(function () { toast("تم إلغاء النشر", "info"); load(); }, function () { toast("تعذر الإلغاء", "warning"); }); }
  }

  function build() {
    if ($("teacherDash")) return true;
    var anchor = $("designStudio") || $("lessonPlanStudio") || $("worksheetStudio") || $("slidesStudio") || $("teacherTools") || $("aiStudio");
    if (!anchor) return false;
    var s = document.createElement("section"); s.id = "teacherDash"; s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8"><div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden"><div class="p-5 sm:p-6 bg-gradient-to-l from-slate-700 via-slate-800 to-slate-900 text-white"><div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1">🗂 لوحة المعلم</div><h2 class="text-xl sm:text-2xl font-black">لوحتي: كل أعمالي في مكان واحد</h2><p class="text-xs text-slate-300 mt-1">عروضك وأوراقك وخططك وتصاميمك واختباراتك المنشورة ونتائج طلابك.</p></div><div class="p-4 sm:p-5 text-right min-w-0" id="tdBody"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    return true;
  }
  function init() {
    var tries = 0, t = setInterval(function () { if (build() || ++tries > 40) { clearInterval(t); } if ($("teacherDash") && !S.started) { S.started = true; var tr = 0, w = setInterval(function () { if (uid() || ++tr > 40) { clearInterval(w); load(); } }, 500); } }, 400);
  }
  window.EduDash = { reload: load };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

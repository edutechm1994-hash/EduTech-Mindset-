/*
 * منظومة تقارير أولياء الأمور وبطاقة متابعة الطالب (Parent Report Card & WhatsApp Messenger) — EduTech Mindset (الإصدار 47)
 * تتيح للمعلم:
 * 1) سحب سجل اختبارات الطالب تلقائياً أو إدخال تقييم سريع (المستوى التحصيلي، الالتزام بالواجبات، المشاركة الصفية، والسلوك).
 * 2) 🤖 توليد رسالة تربوية دافئة ومهنية موجهة لولي أمر الطالب بالذكاء الاصطناعي.
 * 3) 📲 إرسال التقرير مباشرة لواتساب ولي الأمر بضغطة زر.
 * 4) 🖨 طباعة بطاقة متابعة رسمية PDF أو تنزيلها كصورة PNG أنيقة.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var cloud = function () { return !!(window.Cloud && window.Cloud.enabled && window.Cloud.col); };
  var uid = function () { return window.Cloud && window.Cloud.getStudioUser ? window.Cloud.getStudioUser().uid : (window.Cloud && window.Cloud.user ? window.Cloud.user.uid : "local_workspace"); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var st = {
    studentName: "",
    grade: "السابع",
    subject: "",
    school: "",
    teacher: "",
    phone: "",
    academic: "ممتاز 🌟",
    homework: "ملتزم دائماً ✅",
    participation: "مشارك متميز 🙋‍♂️",
    behavior: "قدوة حسنة 🏅",
    examsSummary: "",
    note: "نشكر اهتمامكم المتواصل ومتابعتكم الطيبة لابنكم/ابنتكم، ونتطلع لاستمرار هذا التميز.",
    knownStudents: []
  };

  function loadKnownStudents() {
    if (!cloud() || !uid()) return;
    window.Cloud.col("examResults").where("ownerUid", "==", uid()).get().then(function (snap) {
      var map = {};
      snap.docs.forEach(function (d) {
        var r = d.data(), nm = String(r.name || "").trim();
        if (!nm) return;
        if (!map[nm]) map[nm] = { name: nm, count: 0, sumPct: 0 };
        map[nm].count++;
        map[nm].sumPct += (+r.pct || 0);
      });
      st.knownStudents = Object.keys(map).map(function (k) {
        var x = map[k];
        return { name: x.name, count: x.count, avg: Math.round(x.sumPct / x.count) };
      }).sort(function (a, b) { return b.avg - a.avg; });
      paintStudentPicker();
    }).catch(function () {});
  }

  function paintStudentPicker() {
    var box = $("prQuickPick"); if (!box) return;
    if (!st.knownStudents.length) { box.innerHTML = ""; return; }
    box.innerHTML = '<div class="text-[11px] font-bold text-slate-500 mb-1">اختر طالباً من طلابك الذين حلّوا اختباراتك لتعبئة بياناته تلقائياً:</div>' +
      '<div class="flex gap-1.5 overflow-x-auto pb-1">' +
      st.knownStudents.slice(0, 15).map(function (s, i) {
        return '<button type="button" data-prst="' + i + '" class="px-3 py-1 rounded-full bg-teal-500/15 text-teal-700 dark:text-teal-300 text-[11px] font-extrabold whitespace-nowrap shrink-0">' + e(s.name) + ' (' + s.avg + '%)</button>';
      }).join("") + '</div>';
    box.querySelectorAll("[data-prst]").forEach(function (bt) {
      bt.onclick = function () {
        var s = st.knownStudents[+bt.dataset.prst];
        if (!s) return;
        st.studentName = s.name;
        st.examsSummary = "أنجز " + s.count + " اختبارات إلكترونية بمعدل عام " + s.avg + "%";
        st.academic = s.avg >= 85 ? "ممتاز 🌟" : s.avg >= 70 ? "جيد جداً 👏" : s.avg >= 55 ? "جيد 👍" : "يحتاج متابعة وتقوية 🌱";
        if ($("prName")) $("prName").value = st.studentName;
        if ($("prExams")) $("prExams").value = st.examsSummary;
        if ($("prAcad")) $("prAcad").value = st.academic;
        drawReportCanvas();
      };
    });
  }

  function syncFromInputs() {
    if (!$("prName")) return;
    st.studentName = $("prName").value.trim() || "اسم الطالب";
    st.grade = $("prGrade").value.trim();
    st.subject = $("prSubj").value.trim();
    st.school = $("prSchool").value.trim();
    st.teacher = $("prTeacher").value.trim();
    st.phone = $("prPhone").value.trim();
    st.academic = $("prAcad").value;
    st.homework = $("prHw").value;
    st.participation = $("prPart").value;
    st.behavior = $("prBeh").value;
    st.examsSummary = $("prExams").value.trim();
    st.note = $("prNote").value.trim();
  }

  function drawReportCanvas() {
    syncFromInputs();
    var cv = $("prCanvas"); if (!cv) return;
    var W = 1080, H = 1280;
    cv.width = W; cv.height = H;
    var ctx = cv.getContext("2d");
    ctx.direction = "rtl"; ctx.textAlign = "center"; ctx.textBaseline = "middle";

    var g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, "#0f172a"); g.addColorStop(0.55, "#1e3a8a"); g.addColorStop(1, "#0f766e");
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = "#38bdf8"; ctx.lineWidth = 6;
    if (ctx.roundRect) { ctx.beginPath(); ctx.roundRect(36, 36, W - 72, H - 72, 32); ctx.stroke(); }

    ctx.fillStyle = "#fde047"; ctx.font = "900 38px Cairo, Tahoma, sans-serif";
    ctx.fillText("📋 بطاقة متابعة طالب لولي الأمر", W / 2, 110);

    ctx.fillStyle = "#cbd5e1"; ctx.font = "700 26px Cairo, Tahoma, sans-serif";
    ctx.fillText([st.school || "منصة EduTech Mindset", st.grade, st.subject ? "مادة " + st.subject : ""].filter(Boolean).join(" • "), W / 2, 168);

    ctx.fillStyle = "#ffffff"; ctx.font = "900 58px Cairo, Tahoma, sans-serif";
    ctx.fillText(st.studentName, W / 2, 260);

    var items = [
      ["📈 المستوى التحصيلي والأكاديمي", st.academic, "#10b981"],
      ["📝 الالتزام بالواجبات المدرسية", st.homework, "#0284c7"],
      ["🙋‍♂️ التفاعل والمشاركة الصفية", st.participation, "#f59e0b"],
      ["🏅 السلوك والأخلاق والانضباط", st.behavior, "#a855f7"]
    ];

    items.forEach(function (it, idx) {
      var y = 370 + idx * 115;
      ctx.fillStyle = "rgba(255,255,255,0.1)";
      ctx.strokeStyle = it[2]; ctx.lineWidth = 3;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(90, y - 42, W - 180, 84, 20);
      else ctx.rect(90, y - 42, W - 180, 84);
      ctx.fill(); ctx.stroke();

      ctx.textAlign = "right";
      ctx.fillStyle = "#e2e8f0"; ctx.font = "800 28px Cairo, Tahoma, sans-serif";
      ctx.fillText(it[0], W - 125, y);

      ctx.textAlign = "left";
      ctx.fillStyle = "#fde047"; ctx.font = "900 28px Cairo, Tahoma, sans-serif";
      ctx.fillText(it[1], 125, y);
    });

    ctx.textAlign = "center";
    if (st.examsSummary) {
      ctx.fillStyle = "#38bdf8"; ctx.font = "800 26px Cairo, Tahoma, sans-serif";
      ctx.fillText("📊 ملخص الاختبارات: " + st.examsSummary, W / 2, 855);
    }

    // صندوق توصية المعلم
    ctx.fillStyle = "rgba(255,255,255,0.12)";
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(90, 910, W - 180, 195, 22);
    else ctx.rect(90, 910, W - 180, 195);
    ctx.fill();

    ctx.fillStyle = "#fde047"; ctx.font = "900 26px Cairo, Tahoma, sans-serif";
    ctx.fillText("💬 رسالة وتوصية المعلم لولي الأمر:", W / 2, 955);

    ctx.fillStyle = "#ffffff"; ctx.font = "700 24px Cairo, Tahoma, sans-serif";
    var words = String(st.note || "").split(/\s+/), l1 = "", l2 = "";
    words.forEach(function (w) {
      if ((l1 + " " + w).length < 52) l1 += (l1 ? " " : "") + w;
      else l2 += (l2 ? " " : "") + w;
    });
    ctx.fillText(l1, W / 2, 1010);
    if (l2) ctx.fillText(l2.slice(0, 60), W / 2, 1055);

    var d = new Date().toLocaleDateString("ar-EG", { day: "numeric", month: "long", year: "numeric" });
    ctx.fillStyle = "#cbd5e1"; ctx.font = "700 25px Cairo, Tahoma, sans-serif";
    ctx.fillText("التاريخ: " + d + (st.teacher ? "  •  معلم/ـة المادة: " + st.teacher : ""), W / 2, H - 80);
  }

  function aiWriteParentNote() {
    syncFromInputs();
    var btn = $("prAiBtn");
    btn.disabled = true; btn.textContent = "⏳ يكتب الرسالة…";
    var prompt = "اكتب رسالة تربوية قصيرة ودافئة ومهنية (سطرين فقط، نحو 22 كلمة) موجهة من المعلم إلى ولي أمر الطالب «" + st.studentName + "» في الصف " + st.grade +
      (st.subject ? " بمادة " + st.subject : "") + "، علماً أن مستواه التحصيلي: " + st.academic + "، والتزامه بالواجبات: " + st.homework + "، ومشاركته: " + st.participation + ". أعد نص الرسالة فقط.";
    window.AI.ask(prompt, [], "studio").then(function (txt) {
      st.note = String(txt || "").trim().slice(0, 220);
      if ($("prNote")) $("prNote").value = st.note;
      drawReportCanvas();
    }).catch(function () {
      toast("تعذر توليد الرسالة حالياً", "warning");
    }).then(function () {
      btn.disabled = false; btn.textContent = "🤖 صياغة رسالة ذكية لولي الأمر";
    });
  }

  function sendWhatsAppToParent() {
    syncFromInputs();
    var msg = "السلام عليكم ورحمة الله وبركاته، ولي أمر الطالب/ـة *" + st.studentName + "* المحترم 🌹\n\n" +
      "يسعدنا إطلاعكم على بطاقة المتابعة الدورية من *" + (st.school || "منصة EduTech Mindset") + "*" + (st.subject ? " (مادة " + st.subject + ")" : "") + ":\n" +
      "• 📈 المستوى التحصيلي: " + st.academic + "\n" +
      "• 📝 الالتزام بالواجبات: " + st.homework + "\n" +
      "• 🙋‍♂️ المشاركة الصفية: " + st.participation + "\n" +
      "• 🏅 السلوك والانضباط: " + st.behavior + "\n" +
      (st.examsSummary ? "• 📊 الاختبارات: " + st.examsSummary + "\n" : "") +
      "\n💬 *ملاحظة المعلم:*\n" + st.note + "\n\n" +
      (st.teacher ? "مع تحيات معلم/ـة المادة: " + st.teacher : "مع خالص التحية والتقدير");

    var cleanPhone = st.phone.replace(/[^0-9]/g, "");
    if (cleanPhone.indexOf("00") === 0) cleanPhone = cleanPhone.slice(2);
    else if (cleanPhone.indexOf("05") === 0) cleanPhone = "970" + cleanPhone.slice(1);
    var url = "https://wa.me/" + (cleanPhone || "") + "?text=" + encodeURIComponent(msg);
    window.open(url, "_blank");
  }

  function downloadPngCard() {
    drawReportCanvas();
    var cv = $("prCanvas"); if (!cv) return;
    cv.toBlob(function (b) {
      var a = document.createElement("a");
      a.href = URL.createObjectURL(b);
      a.download = "بطاقة-متابعة-" + (st.studentName || "طالب") + ".png";
      document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 600);
    }, "image/png");
  }

  function build() {
    if ($("parentsStudio")) return true;
    var anchor = $("classroomsStudio") || $("certStudio") || $("teacherDash");
    if (!anchor) return false;
    try {
      var h = JSON.parse(localStorage.getItem("ws_hdr") || "{}");
      if (h.school) st.school = h.school;
      if (h.teacher) st.teacher = h.teacher;
    } catch (x) {}

    var s = document.createElement("section");
    s.id = "parentsStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-teal-800 via-emerald-800 to-slate-900 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1">👨‍👩‍👧‍👦 منظومة تقارير أولياء الأمور وبطاقة متابعة الطالب</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">أصدر بطاقة متابعة مصوّرة وأرسل تقريراً ذكياً لواتساب ولي الأمر بضغطة زر</h2>' +
      '<p class="text-xs text-white/85 mt-1">اسحب نتائج الطالب من اختباراتك تلقائياً أو قيّم أداءه وسلوكه وصغ رسالة تربوية مخصصة لولي أمره.</p>' +
      '</div>' +
      '<div class="p-5 sm:p-6 space-y-3 text-right">' +
      '<div id="prQuickPick"></div>' +
      '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5">' +
      '<div class="lg:col-span-6 space-y-2.5">' +
      '<div class="grid grid-cols-2 gap-2"><div><label class="block text-[11px] font-bold mb-1">اسم الطالب *</label><input id="prName" value="أحمد محمد الفقعاوي" class="' + cls + '"></div>' +
      '<div><label class="block text-[11px] font-bold mb-1">واتساب ولي الأمر (اختياري)</label><input id="prPhone" dir="ltr" placeholder="059xxxxxxx" class="' + cls + '"></div></div>' +
      '<div class="grid grid-cols-2 sm:grid-cols-4 gap-2">' +
      '<input id="prGrade" value="' + e(st.grade) + '" placeholder="الصف" class="' + cls + '">' +
      '<input id="prSubj" value="' + e(st.subject) + '" placeholder="المادة" class="' + cls + '">' +
      '<input id="prSchool" value="' + e(st.school) + '" placeholder="المدرسة" class="' + cls + '">' +
      '<input id="prTeacher" value="' + e(st.teacher) + '" placeholder="المعلم" class="' + cls + '"></div>' +
      '<div class="grid grid-cols-2 gap-2">' +
      '<div><label class="block text-[11px] font-bold mb-1">📈 المستوى التحصيلي</label><select id="prAcad" class="' + cls + '"><option>ممتاز 🌟</option><option>جيد جداً 👏</option><option>جيد 👍</option><option>متحسن باطراد 📈</option><option>يحتاج متابعة وتقوية 🌱</option></select></div>' +
      '<div><label class="block text-[11px] font-bold mb-1">📝 الالتزام بالواجبات</label><select id="prHw" class="' + cls + '"><option>ملتزم دائماً ✅</option><option>ملتزم غالباً 👍</option><option>يتأخر أحياناً ⏳</option><option>يحتاج متابعة منزلية 📌</option></select></div>' +
      '<div><label class="block text-[11px] font-bold mb-1">🙋‍♂️ المشاركة الصفية</label><select id="prPart" class="' + cls + '"><option>مشارك متميز 🙋‍♂️</option><option>مشارك متفاعل 👏</option><option>هادئ ويستمع جيداً 🌱</option><option>يحتاج تشجيعاً للمشاركة 💡</option></select></div>' +
      '<div><label class="block text-[11px] font-bold mb-1">🏅 السلوك والانضباط</label><select id="prBeh" class="' + cls + '"><option>قدوة حسنة 🏅</option><option>خلوق ومؤدب 🌟</option><option>منضبط ومتعاون 👍</option></select></div>' +
      '</div>' +
      '<div><label class="block text-[11px] font-bold mb-1">📊 ملخص الاختبارات والدرجات (اختياري)</label><input id="prExams" placeholder="مثال: حصل على 19/20 في اختبار الشهر الأول" class="' + cls + '"></div>' +
      '<div><div class="flex items-center justify-between mb-1"><label class="text-[11px] font-bold">💬 رسالة وتوصية المعلم لولي الأمر</label><button type="button" id="prAiBtn" class="text-[10px] font-extrabold text-brand-600">🤖 صياغة رسالة ذكية لولي الأمر</button></div>' +
      '<textarea id="prNote" rows="2" class="' + cls + '">' + e(st.note) + '</textarea></div>' +
      '<div class="flex flex-wrap gap-2 pt-1">' +
      '<button type="button" id="prWaBtn" class="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 text-white text-xs font-black shadow">📲 أرسل التقرير لواتساب ولي الأمر</button>' +
      '<button type="button" id="prDlBtn" class="py-2.5 px-4 rounded-xl bg-brand-600 text-white text-xs font-black">⬇ تنزيل بطاقة المتابعة PNG</button>' +
      '</div></div>' +
      '<div class="lg:col-span-6">' +
      '<div class="rounded-2xl border-2 border-teal-500/40 bg-slate-900 p-2 shadow-inner"><canvas id="prCanvas" class="w-full h-auto rounded-xl"></canvas></div>' +
      '</div></div></div></div></div>';

    anchor.parentNode.insertBefore(s, anchor.nextSibling);

    ["prName", "prPhone", "prGrade", "prSubj", "prSchool", "prTeacher", "prAcad", "prHw", "prPart", "prBeh", "prExams", "prNote"].forEach(function (id) {
      var el = $(id);
      if (el) { el.addEventListener("input", drawReportCanvas); el.addEventListener("change", drawReportCanvas); }
    });
    $("prAiBtn").onclick = aiWriteParentNote;
    $("prWaBtn").onclick = sendWhatsAppToParent;
    $("prDlBtn").onclick = downloadPngCard;
    setTimeout(drawReportCanvas, 100);
    setTimeout(loadKnownStudents, 1500);
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  function openWithStudent(opts) {
    opts = opts || {};
    if (opts.name) st.studentName = opts.name;
    if (opts.grade) st.grade = opts.grade;
    if (opts.subject) st.subject = opts.subject;
    if (opts.school) st.school = opts.school;
    if (opts.teacher) st.teacher = opts.teacher;
    if (opts.summary) st.examsSummary = opts.summary;
    if (typeof opts.avg === "number") {
      st.academic = opts.avg >= 85 ? "ممتاز 🌟" : opts.avg >= 70 ? "جيد جداً 👏" : opts.avg >= 55 ? "جيد 👍" : "يحتاج متابعة وتقوية 🌱";
    }
    if ($("prName")) $("prName").value = st.studentName;
    if ($("prGrade")) $("prGrade").value = st.grade;
    if ($("prSubj")) $("prSubj").value = st.subject;
    if ($("prSchool")) $("prSchool").value = st.school;
    if ($("prTeacher")) $("prTeacher").value = st.teacher;
    if ($("prExams")) $("prExams").value = st.examsSummary;
    if ($("prAcad")) $("prAcad").value = st.academic;
    drawReportCanvas();
    if (window.EduMasterHierarchy && window.EduMasterHierarchy.navigateToTarget) {
      window.EduMasterHierarchy.navigateToTarget("parentsStudio");
    } else {
      var sc = $("parentsStudio");
      if (sc) { sc.style.display = ""; sc.scrollIntoView({ behavior: "smooth", block: "start" }); }
    }
    toast("تم تجهيز بطاقة متابعة ولي الأمر للطالب «" + st.studentName + "» ✓", "success");
  }

  window.EduParents = {
    reload: loadKnownStudents,
    openWithStudent: openWithStudent
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

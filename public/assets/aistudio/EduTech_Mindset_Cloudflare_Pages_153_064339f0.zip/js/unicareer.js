/*
 * استوديو الأبحاث الجامعية ومشاريع التخرج، منسّق المراجع الأكاديمية (APA/IEEE)، ومحاكي المقابلات الوظيفية والمنح
 * EduTech Mindset — الإصدار 84 (University Research Proposal Studio, APA/IEEE Citation Manager & Bilingual Interview Simulator)
 *
 * يقدم هذا الملف:
 * 1) مساعد الأبحاث الجامعية ومشاريع التخرج (عربي + English Abstract):
 *    - توليد خطة ومقترح مشروع تخرج أو بحث جامعي متكامل (العنوان المزدوج، الملخص العربي + English Abstract، مشكلة البحث، الأهداف، الفرضيات، المنهجية، وهيكل الفصول الـ 5).
 *    - ربط مباشر بقارئ الكتب التفاعلي وقاعدة بيانات الـ Markdown لاستيراد موضوع البحث أو الإطار النظري بنقرة واحدة.
 * 2) منسّق التوثيق والمراجع العلمية القياسي (APA 7th / IEEE / Harvard / MLA):
 *    - استيراد بيانات الكتب تلقائياً من «قاعدة بيانات الموقع» أو «قارئ الكتب» وتوليد التوثيق داخل المتن (In-text) وفي قائمة المراجع النهائية.
 * 3) محاكي ومدرب المقابلات الوظيفية والمنح الجامعية (Job & Scholarship Interview Simulator — عربي + English):
 *    - يقرأ بيانات السيرة الذاتية من (#cvBuilderStudio) تلقائياً ويولّد أسئلة المقابلة المتوقعة مع إجابات نموذجية بمنهجية STAR باللغتين العربية والإنجليزية، مع تدريب عملي وتقييم فوري للإجابة.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };

  var UC_KEY = "edu_uni_career_state_v84";

  var INTERVIEW_TRACKS = {
    tech: {
      label: "💻 مقابلة وظيفة تقنية وهندسة برمجيات (Tech & Engineering)",
      questions: [
        {
          qAr: "حدثنا عن نفسك وعن أبرز مشروع تقني أنجزته خلال دراستك الجامعية؟",
          qEn: "Tell us about yourself and the most impactful technical project you built during university?",
          goal: "قياس قدرتك على تلخيص هويتك المهنية وربط دراستك الأكاديمية بالتطبيق العملي.",
          ansAr: "أنا خريج هندسة حاسوب وتكنولوجيا معلومات، ركزت خلال دراستي على تطوير تطبيقات الويب وقواعد البيانات والذكاء الاصطناعي. في مشروع تخرجي (الموقف)، احتجنا لبناء منصة تحول كتب PDF الضخمة إلى قواعد بيانات سريعة (المهمة)، فطورت محرك فهرسة بلغة JavaScript وIndexedDB (الإجراء)، مما قلص زمن البحث والتحميل بنسبة 70% وخدم مئات المستخدمين (النتيجة).",
          ansEn: "I am a Computer Engineering graduate specializing in Full-Stack development and AI integration. For my graduation project (Situation), we needed to make large PDF textbooks searchable offline (Task). I built a client-side PDF-to-Markdown indexing engine using JavaScript and IndexedDB (Action), which reduced query latency by 70% (Result)."
        },
        {
          qAr: "كيف تتعامل مع مشكلة برمجية معقدة أو بطء في استعلامات قاعدة البيانات SQL؟",
          qEn: "How do you troubleshoot a complex software bug or optimize a slow SQL database query?",
          goal: "اختبار التفكير التحليلي المنهجي وفهم فهارس قواعد البيانات (Indexing) وتحليل الأداء.",
          ansAr: "أبدأ بعزل المشكلة وتحليل خطة تنفيذ الاستعلام (Execution Plan)، ثم أتحقق من الفهارس (Indexes) على حقول الربط (Foreign Keys) وشروط البحث (WHERE)، وأستبدل الاستعلامات المتداخلة غير الضرورية بعمليات ربط (JOIN) محسنة مع تقنين الحقول المسترجعة.",
          ansEn: "I start by isolating the bottleneck and inspecting the query execution plan. I verify that proper indexes exist on foreign keys and filtered columns, refactor N+1 queries into optimized JOINs, and cache frequently requested read-heavy data."
        },
        {
          qAr: "لماذا ترغب بالانضمام إلى فريقنا، وما القيمة التي ستضيفها في أول 90 يوماً؟",
          qEn: "Why do you want to join our team, and what value will you add in your first 90 days?",
          goal: "معرفة مدى اطلاعك على طبيعة عمل المؤسسة وجاهزيتك للتعلم السريع والإنجاز.",
          ansAr: "أتابع مشاريعكم الرقمية الرائدة وأرى تطابقاً كبيراً بين التقنيات التي تستخدمونها ومهاراتي التطبيقية. في أول 90 يوماً سأركز على فهم بنية النظام لديكم، المساهمة في إنجاز المهام البرمجية بدقة، وأتمتة الاختبارات لرفع جودة الإطلاق.",
          ansEn: "I admire your engineering culture and product impact. In my first 90 days, I will rapidly onboard onto your codebase, contribute clean and tested features, and collaborate closely with senior engineers to ship reliable updates."
        }
      ]
    },
    edu: {
      label: "👨‍🏫 مقابلة وظيفة تعليمية وتربوية (Teaching & Education)",
      questions: [
        {
          qAr: "كيف تخطط لحصة دراسية تفاعلية تراعي الفروق الفردية بين الطلبة؟",
          qEn: "How do you design an interactive lesson plan that accommodates diverse student learning levels?",
          goal: "تقييم التمكن من استراتيجيات التعلم النشط (5E) والتمايز التربوي والتعليم الدامج.",
          ansAr: "أعتمد نموذج (5E) وأصمم أنشطة متدرجة وفق هرم بلوم: أبدأ بنشاط تهيئة جاذب، وأوظف الوسائط البصرية والخرائط الذهنية، ثم أوزع أوراق عمل بمستويين (تأسيسي ومتقدم) لضمان مشاركة كل طالب حسب سرعته وقدراته.",
          ansEn: "I structure lessons using the 5E instructional model and Bloom's Taxonomy. I combine visual mind maps, interactive classroom activities, and two-tier differentiated worksheets (foundational and advanced) so every student progresses confidently."
        },
        {
          qAr: "كيف توظف التكنولوجيا والذكاء الاصطناعي في التعليم دون أن تفقد الحصة جانبها الإنساني؟",
          qEn: "How do you integrate EdTech and AI tools while maintaining strong human engagement in class?",
          goal: "قياس الوعي التربوي المتوازن في استخدام التكنولوجيا كوسيلة داعمة لا بديلة عن المعلم.",
          ansAr: "أستخدم الذكاء الاصطناعي لاختصار وقت التحضير وتوليد الاختبارات التشخيصية والبطاقات التفاعلية، مما يوفر لي وقتاً أطول داخل الحصة للحوار السقراطي المباشر مع الطلاب، ومتابعة تقدمهم الفردي، ودعمهم نفسياً وتربوياً.",
          ansEn: "I use AI and EdTech to streamline lesson preparation and formative assessment generation, freeing up valuable classroom time for Socratic dialogue, hands-on group inquiry, and personalized emotional and academic support."
        }
      ]
    },
    scholarship: {
      label: "🎓 مقابلة منحة جامعية ودراسات عليا (Scholarship & Graduate Study)",
      questions: [
        {
          qAr: "لماذا اخترت هذا التخصص الأكاديمي، وكيف سيخدم بحثك مجتمعك بعد التخرج؟",
          qEn: "Why did you choose this academic field, and how will your research benefit your community upon return?",
          goal: "المعيار الأهم لدى لجان المنح الدولية والمحلية: وضوح الهدف البحثي والأثر المجتمعي المستدام.",
          ansAr: "اخترت هذا التخصص لأنه يعالج تحدياً حقيقياً في مجتمعي الفلسطيني. يركز مقترحي البحثي على تطوير حلول تطبيقية منخفضة التكلفة وعالية الكفاءة، وبعد إتمام الدراسة سأنقل هذه الخبرة إلى الجامعات والمؤسسات المحلية لتدريب الطلبة وتطوير القطاع المهني.",
          ansEn: "I chose this field because it directly addresses a pressing developmental need in Palestine. My proposed research focuses on scalable, practical solutions, and upon completing my degree, I plan to transfer this knowledge back to local universities and industry."
        },
        {
          qAr: "حدثنا عن تحدٍ أكاديمي أو بحثي واجهته وكيف تغلبت عليه؟",
          qEn: "Describe a significant academic or research challenge you faced and how you overcame it?",
          goal: "قياس المرونة الأكاديمية، الاستقلالية في البحث، ومهارات حل المشكلات تحت الضغط.",
          ansAr: "خلال مشروع التخرج واجهنا شحاً في البيانات الميدانية الجاهزة (الموقف)، فقمت بتصميم أداة جمع بيانات رقمية وبناء نموذج محاكاة برمجي للتحقق من الفرضيات (الإجراء)، مما مكننا من إتمام البحث بدقة عالية والحصول على تقدير امتياز (النتيجة).",
          ansEn: "During my senior research project, we encountered limited pre-existing local datasets (Situation). I designed a structured digital data-collection instrument and built a validation model (Action), enabling us to publish robust findings and earn First-Class Honors (Result)."
        }
      ]
    },
    hr_star: {
      label: "🤝 الأسئلة السلوكية والقيادية الشائعة (Behavioral HR & STAR Method)",
      questions: [
        {
          qAr: "اذكر موقفاً عملت فيه ضمن فريق لحل خلاف أو إنجاز مهمة تحت ضغط الوقت؟",
          qEn: "Give an example of a time you worked in a team to resolve a conflict or meet a tight deadline?",
          goal: "تقييم الذكاء العاطفي، روح الفريق، والقدرة على تنظيم الأولويات.",
          ansAr: "في مشروع جامعي مشترك اقترب موعد التسليم النهائي وكان هناك تباين في وجهات النظر حول التصميم (الموقف)، فبادرت بعقد اجتماع قصير لتقسيم المشروع إلى مهام صغيرة واضحة حسب نقطة قوة كل عضو (الإجراء)، فأنجزنا المشروع قبل الموعد بـ 24 ساعة وحققنا المركز الأول (النتيجة).",
          ansEn: "During a capstone project with a tight 48-hour deadline, our team had conflicting approaches (Situation). I facilitated a quick alignment meeting, broke the deliverables into modular tasks matched to each member's strengths (Action), and we delivered 24 hours early with top marks (Result)."
        }
      ]
    }
  };

  function loadState() {
    var raw = null;
    try {
      raw = JSON.parse(localStorage.getItem(UC_KEY) || "null");
    } catch (e) {}
    var def = {
      tab: "research", // research | citations | interview
      research: {
        titleAr: "أثر توظيف الذكاء الاصطناعي التوليدي وقواعد البيانات التفاعلية في تحسين التحصيل الأكاديمي",
        titleEn: "The Impact of Generative AI and Interactive Knowledge Bases on Enhancing Academic Achievement",
        field: "تكنولوجيا التعليم وهندسة الحاسوب",
        university: "جامعة بيرزيت / جامعة النجاح الوطنية",
        researcher: "الباحث الجامعي",
        sourceNotes: "يركز البحث على تحويل الكتب والمقررات من ملفات PDF جامدة إلى قواعد بيانات Markdown تفاعلية مربوطة بأدوات التقييم الذاتي والخرائط الذهنية.",
        generatedOut: ""
      },
      citations: {
        style: "apa", // apa | ieee | harvard | mla
        author: "العلي، كريم محمود",
        authorEn: "Al-Ali, K. M.",
        year: "2026",
        title: "تطبيقات الذكاء الاصطناعي وقواعد البيانات التعليمية في المنهاج الفلسطيني",
        publisher: "دار النشر الجامعي — رام الله، فلسطين",
        url: "https://edutech-mindset.pages.dev",
        lang: "ar", // ar | en
        savedList: [
          {
            style: "APA 7th",
            inText: "(العلي، 2026)",
            full: "العلي، كريم محمود. (2026). *تطبيقات الذكاء الاصطناعي وقواعد البيانات التعليمية في المنهاج الفلسطيني*. دار النشر الجامعي — رام الله، فلسطين. https://edutech-mindset.pages.dev"
          },
          {
            style: "IEEE",
            inText: "[1]",
            full: "[1] K. M. Al-Ali, *AI Applications and Educational Databases in the Palestinian Curriculum*, Ramallah, Palestine: University Press, 2026."
          }
        ]
      },
      interview: {
        track: "tech",
        qIdx: 0,
        userAnswer: "",
        feedback: ""
      }
    };
    if (raw && typeof raw === "object") {
      return {
        tab: raw.tab || def.tab,
        research: Object.assign({}, def.research, raw.research || {}),
        citations: Object.assign({}, def.citations, raw.citations || {}, {
          savedList: (raw.citations && Array.isArray(raw.citations.savedList)) ? raw.citations.savedList : def.citations.savedList
        }),
        interview: Object.assign({}, def.interview, raw.interview || {})
      };
    }
    return def;
  }

  var UState = loadState();
  function saveState() {
    try { localStorage.setItem(UC_KEY, JSON.stringify(UState)); } catch (e) {}
  }

  // ==================== 1. توليد مقترح وخطة البحث الجامعي / مشروع التخرج (عربي + English) ====================
  function buildDefaultResearchProposal(r) {
    return "# 🎓 خطة ومقترح البحث الجامعي / مشروع التخرج\n" +
      "**العنوان بالعربية:** " + r.titleAr + "\n" +
      "**Title in English:** " + (r.titleEn || "Academic Research & Graduation Project Proposal") + "\n" +
      "**التخصص / الكلية:** " + r.field + " | **الجامعة:** " + r.university + "\n" +
      "==================================================================\n\n" +
      "## أولاً: الملخص الأكاديمي (الملخص بالعربية)\n" +
      "تهدف هذه الدراسة إلى استقصاء وتحليل «" + r.titleAr + "» في مجال (" + r.field + "). وتنبع أهمية البحث من الحاجة المتزايدة إلى تطوير حلول علمية وتطبيقية حديثة تواكب التحول الرقمي والأكاديمي. يعتمد البحث على المنهج الوصفي التحليلي والتطبيقي، مع الاستناد إلى الإطار النظري: (" + (r.sourceNotes || "المراجع العلمية المعتمدة") + "). ومن المتوقع أن تسهم نتائج الدراسة في تقديم نموذج تطبيقي فاعل وتوصيات عملية للباحثين والمؤسسات.\n\n" +
      "## Second: Abstract in English\n" +
      "This study investigates **" + (r.titleEn || r.titleAr) + "** within the domain of **" + r.field + "**. Addressing a critical gap in current academic and practical implementations, the research employs an analytical and applied methodology to design, evaluate, and validate an integrated framework. Preliminary findings and theoretical foundations indicate significant improvements in efficiency, quality, and user engagement, offering actionable recommendations for universities and practitioners.\n\n" +
      "## ثالثاً: مشكلة الدراسة وأسئلتها البحثية (Research Problem & Questions)\n" +
      "- **السؤال الرئيسي:** ما أثر وفاعلية «" + r.titleAr + "» وكيف يمكن بناء نموذج تطبيقي يحقق أعلى كفاءة؟\n" +
      "- **الأسئلة الفرعية:**\n" +
      "  1. ما الأسس النظرية والمعايير القياسية المرتبطة بموضوع الدراسة في مجال " + r.field + "؟\n" +
      "  2. ما التصميم المقترح للنموذج التطبيقي وما متطلبات تنفيذه؟\n" +
      "  3. ما مستوى فاعلية النموذج المقترح عند تطبيقه وقياس نتائجه؟\n\n" +
      "## رابعاً: أهداف الدراسة وأهميتها (Research Objectives)\n" +
      "1. تأصيل الإطار النظري والدراسات السابقة المرتبطة بالموضوع.\n" +
      "2. تصميم وتطوير أداة أو نموذج تطبيقي قابل للقياس والتقويم.\n" +
      "3. تقديم توصيات علمية وعملية تخدم طلبة الجامعات والمؤسسات الفلسطينية.\n\n" +
      "## خامساً: منهجية الدراسة وهيكل الفصول المقترح (Methodology & Thesis Chapters)\n" +
      "- **الفصل الأول (الإطار العام للدراسة):** المقدمة، مشكلة البحث، الأهداف، الأهمية، الحدود، والمصطلحات.\n" +
      "- **الفصل الثاني (الإطار النظري والدراسات السابقة):** المفاهيم الأساسية ومراجعة الأبحاث العربية والأجنبية.\n" +
      "- **الفصل الثالث (منهجية الدراسة وإجراءاتها):** مجتمع وعينة الدراسة، أدوات البحث، أو تصميم النظام التطبيقي.\n" +
      "- **الفصل الرابع (عرض النتائج وتحليلها ومناقشتها):** التحليل الإحصائي أو نتائج التجريب والاختبار.\n" +
      "- **الفصل الخامس (الخلاصة والتوصيات والمقترحات):** أهم الاستنتاجات والمراجع الموثقة وفق نظام APA 7th.";
  }

  function generateResearchProposal(useAi) {
    var r = UState.research;
    if (!useAi || !window.AI || !window.AI.ask) {
      r.generatedOut = buildDefaultResearchProposal(r);
      saveState();
      renderUniCareerStudio();
      toast("⚡ تم توليد خطة ومقترح البحث الجامعي (مع الملخص بالعربية والإنجليزية) بنجاح ✓", "success");
      return;
    }
    var btn = $("ucBtnGenResearchAi");
    if (btn) { btn.disabled = true; btn.textContent = "⏳ جارٍ إعداد مقترح البحث الأكاديمي بالـ AI…"; }
    var prompt = "أنت أستاذ جامعي ومشرف أكاديمي خبير. اكتب خطة ومقترح بحث جامعي / مشروع تخرج متكامل ورصين:\n" +
      "- العنوان بالعربية: " + r.titleAr + "\n" +
      "- العنوان بالإنجليزية: " + r.titleEn + "\n" +
      "- التخصص: " + r.field + "\n" +
      "- خلفية ونقاط من المراجع: " + r.sourceNotes + "\n" +
      "شمل في الخطة: 1) الملخص الأكاديمي بالعربية 2) Abstract in English 3) مشكلة الدراسة وأسئلتها 4) الأهداف والأهمية 5) المنهجية وهيكل الفصول الخمسة.";
    window.AI.ask(prompt, [], "studio").then(function (res) {
      r.generatedOut = String(res || "").trim() || buildDefaultResearchProposal(r);
      saveState();
      renderUniCareerStudio();
      toast("🤖 تم توليد مقترح البحث الأكاديمي بالذكاء الاصطناعي ✓", "success");
    }).catch(function () {
      r.generatedOut = buildDefaultResearchProposal(r);
      saveState();
      renderUniCareerStudio();
    });
  }

  // ==================== 2. منسّق التوثيق والمراجع العلمية القياسي (APA 7th / IEEE / Harvard / MLA) ====================
  function formatCitationEntry(c) {
    var isAr = c.lang !== "en";
    var au = (isAr ? c.author : (c.authorEn || c.author)) || "المؤلف";
    var yr = c.year || "2026";
    var ti = c.title || "عنوان المرجع";
    var pub = c.publisher || "دار النشر";
    var url = c.url ? (" " + c.url) : "";
    var lastName = au.split(/[,،\s]+/)[0] || au;

    if (c.style === "ieee") {
      var idx = (c.savedList ? c.savedList.length : 0) + 1;
      return {
        style: "IEEE",
        inText: "[" + idx + "]",
        full: "[" + idx + "] " + au + ", *" + ti + "*, " + pub + ", " + yr + "." + url
      };
    }
    if (c.style === "harvard") {
      return {
        style: "Harvard",
        inText: "(" + lastName + ", " + yr + ")",
        full: au + " (" + yr + ") *" + ti + "*. " + pub + "." + url
      };
    }
    if (c.style === "mla") {
      return {
        style: "MLA 9th",
        inText: "(" + lastName + ")",
        full: au + ". *" + ti + "*. " + pub + ", " + yr + "." + url
      };
    }
    // APA 7th Default
    return {
      style: "APA 7th",
      inText: isAr ? "(" + lastName + "، " + yr + ")" : "(" + lastName + ", " + yr + ")",
      full: au + ". (" + yr + "). *" + ti + "*. " + pub + "." + url
    };
  }

  // ==================== 3. بناء واجهة استوديو الأبحاث الجامعية والتوثيق والمقابلات (#uniResearchCareerStudio) ====================
  function ensureUniCareerSection() {
    var ex = $("uniResearchCareerStudio");
    if (ex) return ex;
    var anchor = $("cvBuilderStudio") || $("tawjihiStudio") || $("learnSection");
    if (!anchor || !anchor.parentNode) return null;
    var sec = document.createElement("section");
    sec.id = "uniResearchCareerStudio";
    sec.className = "py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20";
    anchor.parentNode.insertBefore(sec, anchor.nextSibling);
    return sec;
  }

  function renderUniCareerStudio() {
    var sec = ensureUniCareerSection();
    if (!sec) return;
    var inpCls = "w-full text-xs font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100 outline-none focus:border-brand-500";

    sec.innerHTML =
      '<div class="glass-card rounded-3xl border-2 border-indigo-500/35 dark:border-slate-700 shadow-2xl overflow-hidden text-right">' +
        // 1. Header Banner
        '<div class="p-5 sm:p-6 bg-gradient-to-l from-indigo-950 via-slate-900 to-emerald-950 text-white">' +
          '<div class="flex flex-wrap items-center justify-between gap-3">' +
            '<div>' +
              '<div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-black mb-1.5">' +
                '<span>🎓 منظومة التعليم الجامعي والخريجين • الأبحاث، التوثيق العلمي APA/IEEE، ومدرب المقابلات</span>' +
              '</div>' +
              '<h2 class="text-lg sm:text-2xl font-black">استوديو الأبحاث الجامعية ومشاريع التخرج وتوثيق المراجع ومحاكي المقابلات (عربي + English)</h2>' +
              '<p class="text-xs text-slate-200 mt-1">أكمل رحلتك الجامعية والمهنية: صمّم مقترح بحثك وملخصه الإنجليزي، وثّق مراجعك من الكتب بنظام APA/IEEE، وتدرّب على مقابلة العمل أو المنحة.</p>' +
            '</div>' +
            '<div class="flex flex-wrap gap-2">' +
              '<button type="button" id="ucGoCvBuilder" class="px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow flex items-center gap-1.5">' +
                '<i class="fa-solid fa-id-card"></i><span>منشئ السيرة الذاتية (CV)</span>' +
              '</button>' +
              '<button type="button" id="ucGoBookReader" class="px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-extrabold border border-white/20 flex items-center gap-1.5">' +
                '<i class="fa-solid fa-book-open"></i><span>قارئ الكتب والمراجع</span>' +
              '</button>' +
            '</div>' +
          '</div>' +

          // Sub-Tabs
          '<div class="mt-4 pt-4 border-t border-white/15 flex flex-wrap gap-2">' +
            [
              { id: "research", ico: "🔬", label: "1. مساعد الأبحاث ومشاريع التخرج (عربي + English Abstract)" },
              { id: "citations", ico: "📚", label: "2. منسّق المراجع والاقتباسات الأكاديمية (APA 7th / IEEE)" },
              { id: "interview", ico: "🎤", label: "3. محاكي ومدرب المقابلات الوظيفية والمنح (STAR Method)" }
            ].map(function (t) {
              var on = UState.tab === t.id;
              return '<button type="button" data-uc-tab="' + t.id + '" class="px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 ' +
                (on ? "bg-amber-400 text-slate-950 font-black shadow" : "bg-white/10 hover:bg-white/20 text-slate-200") + '">' +
                '<span>' + t.ico + '</span><span>' + t.label + '</span>' +
              '</button>';
            }).join("") +
          '</div>' +
        '</div>' +

        // 2. Body Content
        '<div class="p-5 sm:p-6">' +
          (UState.tab === "citations"
            ? renderCitationsTabHtml(inpCls)
            : UState.tab === "interview"
            ? renderInterviewTabHtml(inpCls)
            : renderResearchTabHtml(inpCls)) +
        '</div>' +
      '</div>';

    bindUniCareerEvents(sec);
  }

  function renderResearchTabHtml(inpCls) {
    var r = UState.research;
    if (!r.generatedOut) r.generatedOut = buildDefaultResearchProposal(r);
    return '<div class="space-y-5">' +
      '<div class="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">' +
        '<div>' +
          '<h3 class="text-sm sm:text-base font-black">🔬 مولّد مقترح وخطة البحث الجامعي ومشروع التخرج (ثنائي اللغة)</h3>' +
          '<p class="text-xs text-slate-500">اكتب عنوان بحثك أو استورده من الكتاب المفتوح في القارئ التفاعلي للحصول على خطة بحث متكاملة مع Abstract بالإنجليزية</p>' +
        '</div>' +
        '<button type="button" id="ucImportFromBookBtn" class="px-3.5 py-2 rounded-xl bg-indigo-600/15 text-indigo-700 dark:text-sky-300 border border-indigo-500/30 text-xs font-black hover:bg-indigo-600 hover:text-white transition">📖 استورد الموضوع من الكتاب المفتوح بالقارئ</button>' +
      '</div>' +

      '<div class="grid grid-cols-1 md:grid-cols-2 gap-3">' +
        '<div><label class="block text-[11px] font-bold mb-1">عنوان البحث أو مشروع التخرج (بالعربية)</label><input id="ucResTitleAr" value="' + esc(r.titleAr) + '" class="' + inpCls + '"></div>' +
        '<div><label class="block text-[11px] font-bold mb-1">Research / Graduation Project Title (in English)</label><input id="ucResTitleEn" dir="ltr" value="' + esc(r.titleEn) + '" class="' + inpCls + '"></div>' +
        '<div><label class="block text-[11px] font-bold mb-1">التخصص والكلية / Academic Major</label><input id="ucResField" value="' + esc(r.field) + '" class="' + inpCls + '"></div>' +
        '<div><label class="block text-[11px] font-bold mb-1">الجامعة / University</label><input id="ucResUni" value="' + esc(r.university) + '" class="' + inpCls + '"></div>' +
        '<div class="md:col-span-2"><label class="block text-[11px] font-bold mb-1">ملاحظات أو فقرات مقتبسة من مراجعك وكتب الـ Markdown (الإطار النظري)</label><textarea id="ucResNotes" rows="2" class="' + inpCls + '">' + esc(r.sourceNotes) + '</textarea></div>' +
      '</div>' +

      '<div class="flex flex-wrap gap-2">' +
        '<button type="button" id="ucBtnGenResearchFast" class="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow">⚡ توليد خطة البحث والـ Abstract فوراً (بلا إنترنت)</button>' +
        '<button type="button" id="ucBtnGenResearchAi" class="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black shadow">🤖 صياغة موسّعة بالذكاء الاصطناعي</button>' +
        '<button type="button" id="ucBtnSaveResearchMd" class="px-4 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black">📝 تنزيل وحفظ كـ Markdown بقاعدة الموقع</button>' +
        '<button type="button" id="ucBtnPrintResearch" class="px-4 py-2.5 rounded-xl bg-slate-800 text-white text-xs font-black">🖨 طباعة / تصدير PDF</button>' +
      '</div>' +

      '<div class="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs leading-loose whitespace-pre-line font-semibold">' +
        esc(r.generatedOut) +
      '</div>' +
    '</div>';
  }

  function renderCitationsTabHtml(inpCls) {
    var c = UState.citations;
    var preview = formatCitationEntry(c);
    var allBooks = (window.EduBookReader && window.EduBookReader.allBooks) ? window.EduBookReader.allBooks() : [];

    return '<div class="space-y-5">' +
      '<div class="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">' +
        '<div>' +
          '<h3 class="text-sm sm:text-base font-black">📚 منسّق التوثيق والمراجع العلمية القياسي (APA 7th / IEEE / Harvard / MLA)</h3>' +
          '<p class="text-xs text-slate-500">اختر أي كتاب من قاعدة بيانات الموقع أو أدخل بيانات المرجع لتوليد التوثيق القياسي داخل المتن وفي قائمة المراجع</p>' +
        '</div>' +
        (allBooks.length
          ? '<div class="flex items-center gap-2">' +
              '<span class="text-xs font-black text-indigo-600 dark:text-sky-300">📖 اختر كتاباً من الموقع لتوثيقه فوراً:</span>' +
              '<select id="ucPickBookForCite" class="text-xs font-bold bg-indigo-50 dark:bg-slate-800 border border-indigo-300 dark:border-slate-700 rounded-xl px-3 py-1.5">' +
                '<option value="">— اختر كتاباً من القاعدة —</option>' +
                allBooks.map(function (b, idx) {
                  return '<option value="' + idx + '">' + esc(b.title) + '</option>';
                }).join("") +
              '</select>' +
            '</div>'
          : '') +
      '</div>' +

      '<div class="grid grid-cols-1 sm:grid-cols-3 gap-3">' +
        '<div><label class="block text-[11px] font-bold mb-1">نظام التوثيق الأكاديمي</label><select id="ucCiteStyle" class="' + inpCls + '">' +
          [
            ["apa", "APA 7th Edition (الأكثر استخداماً بالجامعات)"],
            ["ieee", "IEEE (للهندسة والتكنولوجيا والحاسوب)"],
            ["harvard", "Harvard Referencing Style"],
            ["mla", "MLA 9th Edition (للآداب واللغات)"]
          ].map(function (s) {
            return '<option value="' + s[0] + '"' + (c.style === s[0] ? " selected" : "") + '>' + s[1] + '</option>';
          }).join("") +
        '</select></div>' +
        '<div><label class="block text-[11px] font-bold mb-1">اسم المؤلف (العائلة، الاسم الأول)</label><input id="ucCiteAuthor" value="' + esc(c.author) + '" class="' + inpCls + '"></div>' +
        '<div><label class="block text-[11px] font-bold mb-1">سنة النشر / Year</label><input id="ucCiteYear" value="' + esc(c.year) + '" class="' + inpCls + '"></div>' +
        '<div><label class="block text-[11px] font-bold mb-1">عنوان الكتاب أو الورقة البحثية</label><input id="ucCiteTitle" value="' + esc(c.title) + '" class="' + inpCls + '"></div>' +
        '<div><label class="block text-[11px] font-bold mb-1">دار النشر / الجامعة / المجلة العلمية</label><input id="ucCitePub" value="' + esc(c.publisher) + '" class="' + inpCls + '"></div>' +
        '<div><label class="block text-[11px] font-bold mb-1">الرابط أو معرف DOI (اختياري)</label><input id="ucCiteUrl" dir="ltr" value="' + esc(c.url) + '" class="' + inpCls + '"></div>' +
      '</div>' +

      // المعاينة الفورية للتوثيق
      '<div class="p-4 rounded-2xl bg-amber-500/10 border-2 border-amber-500/40 space-y-2">' +
        '<div class="flex flex-wrap items-center justify-between gap-2">' +
          '<div class="text-xs font-black text-amber-800 dark:text-amber-300">✨ التوثيق الجاهز بنظام (' + esc(preview.style) + '):</div>' +
          '<button type="button" id="ucAddCiteToList" class="px-4 py-1.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-black shadow">+ أضف إلى قائمة مراجعي</button>' +
        '</div>' +
        '<div class="text-xs"><b>التوثيق داخل المتن (In-Text Citation):</b> <code class="px-2 py-0.5 rounded bg-white dark:bg-slate-900 font-black text-indigo-600">' + esc(preview.inText) + '</code></div>' +
        '<div class="text-xs"><b>التوثيق الكامل في قائمة المراجع:</b> <div class="p-2.5 mt-1 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-semibold">' + esc(preview.full) + '</div></div>' +
      '</div>' +

      // قائمة المراجع المحفوظة
      '<div class="space-y-2.5">' +
        '<div class="flex items-center justify-between">' +
          '<h4 class="text-xs sm:text-sm font-black">📋 قائمة مراجعي البحثية المحفوظة (' + (c.savedList || []).length + ' مرجع):</h4>' +
          '<button type="button" id="ucCopyAllCitations" class="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-black">📋 نسخ القائمة كاملة للبحث</button>' +
        '</div>' +
        '<div class="space-y-2">' +
          (c.savedList || []).map(function (it, idx) {
            return '<div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-2 text-xs">' +
              '<div class="min-w-0 flex-1"><span class="px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-700 dark:text-sky-300 text-[10px] font-black ml-2">' + esc(it.style) + ' ' + esc(it.inText) + '</span><span class="font-semibold">' + esc(it.full) + '</span></div>' +
              '<button type="button" data-uc-del-cite="' + idx + '" class="text-rose-500 font-bold px-2">✕</button>' +
            '</div>';
          }).join("") +
        '</div>' +
      '</div>' +
    '</div>';
  }

  function renderInterviewTabHtml(inpCls) {
    var iv = UState.interview;
    var tr = INTERVIEW_TRACKS[iv.track] || INTERVIEW_TRACKS.tech;
    if (iv.qIdx >= tr.questions.length) iv.qIdx = 0;
    var qObj = tr.questions[iv.qIdx];

    return '<div class="space-y-5">' +
      '<div class="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">' +
        '<div>' +
          '<h3 class="text-sm sm:text-base font-black">🎤 محاكي ومدرب المقابلات الوظيفية والمنح الجامعية (عربي + English STAR Method)</h3>' +
          '<p class="text-xs text-slate-500">اختر مسار المقابلة، استعرض السؤال بالعربية والإنجليزية، وتدرّب على الإجابة النموذجية وفق منهجية STAR</p>' +
        '</div>' +
        '<div class="flex flex-wrap gap-1.5">' +
          Object.keys(INTERVIEW_TRACKS).map(function (k) {
            var on = iv.track === k;
            return '<button type="button" data-uc-ivtrack="' + k + '" class="px-3 py-1.5 rounded-xl text-xs font-extrabold transition ' +
              (on ? "bg-brand-600 text-white shadow font-black" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">' + esc(INTERVIEW_TRACKS[k].label) + '</button>';
          }).join("") +
        '</div>' +
      '</div>' +

      '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">' +
        // بطاقة السؤال والإجابة النموذجية المزدوجة
        '<div class="lg:col-span-7 rounded-2xl border-2 border-indigo-500/30 bg-indigo-500/5 p-5 space-y-4">' +
          '<div class="flex items-center justify-between text-xs font-black text-indigo-600 dark:text-sky-300">' +
            '<span>السؤال ' + (iv.qIdx + 1) + ' من ' + tr.questions.length + '</span>' +
            '<div class="flex gap-1.5">' +
              '<button type="button" id="ucPrevIvQ" class="px-3 py-1 rounded-lg bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700">السابق</button>' +
              '<button type="button" id="ucNextIvQ" class="px-3 py-1 rounded-lg bg-brand-600 text-white">السؤال التالي ←</button>' +
            '</div>' +
          '</div>' +

          '<div class="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">' +
            '<div class="text-sm sm:text-base font-black text-slate-900 dark:text-white">🇸🇦 ' + esc(qObj.qAr) + '</div>' +
            '<div class="text-xs sm:text-sm font-extrabold text-indigo-600 dark:text-sky-400" dir="ltr">🇬🇧 ' + esc(qObj.qEn) + '</div>' +
            '<div class="text-[11px] text-amber-700 dark:text-amber-300 bg-amber-500/10 p-2 rounded-lg font-bold">🎯 ماذا تقيس لجنة المقابلة بهذا السؤال؟ ' + esc(qObj.goal) + '</div>' +
          '</div>' +

          '<div class="space-y-2.5">' +
            '<div class="text-xs font-black text-emerald-700 dark:text-emerald-400">✅ الإجابة النموذجية المقترحة (وفق منهجية STAR — الموقف، المهمة، الإجراء، النتيجة):</div>' +
            '<div class="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-emerald-500/30 text-xs leading-relaxed font-semibold">' +
              '<div class="font-black text-emerald-600 mb-1">🇸🇦 الإجابة بالعربية:</div>' +
              esc(qObj.ansAr) +
            '</div>' +
            '<div class="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-indigo-500/30 text-xs leading-relaxed font-semibold text-left" dir="ltr">' +
              '<div class="font-black text-indigo-600 mb-1">🇬🇧 Model Answer in English:</div>' +
              esc(qObj.ansEn) +
            '</div>' +
          '</div>' +
        '</div>' +

        // مساحة تدريب الطالب وتقييم إجابته
        '<div class="lg:col-span-5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 p-4 space-y-3">' +
          '<div class="text-xs sm:text-sm font-black">🎙️ تدرّب الآن: اكتب إجابتك الخاصة لتقييمها</div>' +
          '<p class="text-[11px] text-slate-500">اكتب كيف ستجيب عن هذا السؤال من واقع دراستك ومشروع تخرجك (بالعربية أو الإنجليزية)، ثم اضغط «قيّم إجابتي»:</p>' +
          '<textarea id="ucIvUserAns" rows="6" placeholder="اكتب إجابتك التجريبية هنا…" class="' + inpCls + '">' + esc(iv.userAnswer) + '</textarea>' +
          '<div class="flex flex-wrap gap-2">' +
            '<button type="button" id="ucEvalIvAnsBtn" class="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow">✨ قيّم إجابتي وفق معيار STAR</button>' +
            '<button type="button" id="ucFillFromMyCvBtn" class="py-2.5 px-3 rounded-xl bg-amber-500 text-slate-950 text-xs font-black">📄 املأ من سيرتي الذاتية</button>' +
          '</div>' +
          (iv.feedback
            ? '<div class="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs leading-relaxed whitespace-pre-line font-bold text-slate-800 dark:text-slate-100">' + esc(iv.feedback) + '</div>'
            : '') +
        '</div>' +
      '</div>' +
    '</div>';
  }

  function bindUniCareerEvents(sec) {
    if ($("ucGoCvBuilder")) $("ucGoCvBuilder").onclick = function () {
      if (window.EduCVBuilder && window.EduCVBuilder.open) window.EduCVBuilder.open();
      else if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("cvBuilderStudio", true);
    };
    if ($("ucGoBookReader")) $("ucGoBookReader").onclick = function () {
      if (window.EduBookReader && window.EduBookReader.open) window.EduBookReader.open(null, 0, "interactive");
    };

    sec.querySelectorAll("[data-uc-tab]").forEach(function (b) {
      b.onclick = function () {
        UState.tab = b.getAttribute("data-uc-tab");
        saveState();
        renderUniCareerStudio();
      };
    });

    // أحداث تبويب الأبحاث الجامعية
    function syncResearchInputs() {
      var r = UState.research;
      if ($("ucResTitleAr")) r.titleAr = $("ucResTitleAr").value;
      if ($("ucResTitleEn")) r.titleEn = $("ucResTitleEn").value;
      if ($("ucResField")) r.field = $("ucResField").value;
      if ($("ucResUni")) r.university = $("ucResUni").value;
      if ($("ucResNotes")) r.sourceNotes = $("ucResNotes").value;
      saveState();
    }
    ["ucResTitleAr", "ucResTitleEn", "ucResField", "ucResUni", "ucResNotes"].forEach(function (id) {
      var el = $(id);
      if (el) el.oninput = syncResearchInputs;
    });

    if ($("ucImportFromBookBtn")) $("ucImportFromBookBtn").onclick = function () {
      var allB = (window.EduBookReader && window.EduBookReader.allBooks) ? window.EduBookReader.allBooks() : [];
      var bk = allB[0];
      if (bk) {
        var ch = (bk.lessons && bk.lessons[0]) || { t: bk.title, x: "" };
        UState.research.titleAr = "دراسة تحليلية وتطبيقية حول: " + ch.t;
        UState.research.field = bk.subject || "العلوم التطبيقية";
        UState.research.sourceNotes = (ch.x || "").slice(0, 600);
        UState.research.generatedOut = buildDefaultResearchProposal(UState.research);
        saveState();
        renderUniCareerStudio();
        toast("📖 تم استيراد موضوع البحث والإطار النظري من كتاب «" + bk.title + "» ✓", "success");
      }
    };
    if ($("ucBtnGenResearchFast")) $("ucBtnGenResearchFast").onclick = function () {
      syncResearchInputs();
      generateResearchProposal(false);
    };
    if ($("ucBtnGenResearchAi")) $("ucBtnGenResearchAi").onclick = function () {
      syncResearchInputs();
      generateResearchProposal(true);
    };
    if ($("ucBtnSaveResearchMd")) $("ucBtnSaveResearchMd").onclick = function () {
      syncResearchInputs();
      var md = UState.research.generatedOut || buildDefaultResearchProposal(UState.research);
      var blob = new Blob([md], { type: "text/markdown;charset=utf-8" });
      var a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "Research_Proposal.md";
      document.body.appendChild(a);
      a.click();
      setTimeout(function () { a.remove(); }, 300);
      if (window.EduSources && window.EduSources.addRaw) {
        window.EduSources.addRaw({
          kind: "md",
          name: "مقترح_بحث_" + UState.research.titleAr.slice(0, 25).replace(/\s+/g, "_") + ".md",
          mime: "text/markdown",
          markdown: md,
          data: btoa(unescape(encodeURIComponent(md)))
        }, true);
      }
      toast("📝 تم تنزيل مقترح البحث بصيغة Markdown وحفظه في قاعدة بيانات الموقع ✓", "success");
    };
    if ($("ucBtnPrintResearch")) $("ucBtnPrintResearch").onclick = function () { window.print(); };

    // أحداث تبويب توثيق المراجع
    function syncCiteInputs() {
      var c = UState.citations;
      if ($("ucCiteStyle")) c.style = $("ucCiteStyle").value;
      if ($("ucCiteAuthor")) c.author = $("ucCiteAuthor").value;
      if ($("ucCiteYear")) c.year = $("ucCiteYear").value;
      if ($("ucCiteTitle")) c.title = $("ucCiteTitle").value;
      if ($("ucCitePub")) c.publisher = $("ucCitePub").value;
      if ($("ucCiteUrl")) c.url = $("ucCiteUrl").value;
      saveState();
      renderUniCareerStudio();
    }
    ["ucCiteStyle", "ucCiteAuthor", "ucCiteYear", "ucCiteTitle", "ucCitePub", "ucCiteUrl"].forEach(function (id) {
      var el = $(id);
      if (el) el.onchange = syncCiteInputs;
    });

    var bkCiteSel = $("ucPickBookForCite");
    if (bkCiteSel) {
      bkCiteSel.onchange = function () {
        var allB = (window.EduBookReader && window.EduBookReader.allBooks) ? window.EduBookReader.allBooks() : [];
        var b = allB[+bkCiteSel.value];
        if (b) {
          UState.citations.title = b.title;
          UState.citations.author = b.author || "وزارة التربية والتعليم العالي الفلسطينية";
          UState.citations.publisher = "المنهاج الفلسطيني — رام الله، فلسطين";
          UState.citations.year = "2026";
          saveState();
          renderUniCareerStudio();
          toast("📚 تم تعبئة بيانات الكتاب لتوثيقه وفق نظام " + UState.citations.style.toUpperCase() + " ✓", "success");
        }
      };
    }

    if ($("ucAddCiteToList")) $("ucAddCiteToList").onclick = function () {
      var entry = formatCitationEntry(UState.citations);
      UState.citations.savedList = UState.citations.savedList || [];
      UState.citations.savedList.unshift(entry);
      saveState();
      renderUniCareerStudio();
      toast("✓ أُضيف المرجع إلى قائمة مراجعك البحثية", "success");
    };
    sec.querySelectorAll("[data-uc-del-cite]").forEach(function (b) {
      b.onclick = function () {
        UState.citations.savedList.splice(+b.getAttribute("data-uc-del-cite"), 1);
        saveState();
        renderUniCareerStudio();
      };
    });
    if ($("ucCopyAllCitations")) $("ucCopyAllCitations").onclick = function () {
      var txt = (UState.citations.savedList || []).map(function (x) { return x.full; }).join("\n");
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(txt).then(function () { toast("📋 تم نسخ قائمة المراجع كاملة ✓", "success"); });
      }
    };

    // أحداث تبويب محاكي المقابلات
    sec.querySelectorAll("[data-uc-ivtrack]").forEach(function (b) {
      b.onclick = function () {
        UState.interview.track = b.getAttribute("data-uc-ivtrack");
        UState.interview.qIdx = 0;
        UState.interview.feedback = "";
        saveState();
        renderUniCareerStudio();
      };
    });
    if ($("ucPrevIvQ")) $("ucPrevIvQ").onclick = function () {
      var tr = INTERVIEW_TRACKS[UState.interview.track] || INTERVIEW_TRACKS.tech;
      UState.interview.qIdx = (UState.interview.qIdx - 1 + tr.questions.length) % tr.questions.length;
      UState.interview.feedback = "";
      saveState();
      renderUniCareerStudio();
    };
    if ($("ucNextIvQ")) $("ucNextIvQ").onclick = function () {
      var tr = INTERVIEW_TRACKS[UState.interview.track] || INTERVIEW_TRACKS.tech;
      UState.interview.qIdx = (UState.interview.qIdx + 1) % tr.questions.length;
      UState.interview.feedback = "";
      saveState();
      renderUniCareerStudio();
    };
    if ($("ucIvUserAns")) $("ucIvUserAns").oninput = function () {
      UState.interview.userAnswer = $("ucIvUserAns").value;
      saveState();
    };
    if ($("ucFillFromMyCvBtn")) $("ucFillFromMyCvBtn").onclick = function () {
      try {
        var cvRaw = JSON.parse(localStorage.getItem("edu_cv_builder_state_v83") || "null");
        var ar = (cvRaw && cvRaw.ar) || {};
        var ed = (ar.education && ar.education[0]) || {};
        UState.interview.userAnswer = "أنا " + (ar.fullName || "خريج جامعي") + "، متخصص في (" + (ar.jobTitle || "مجالي الأكاديمي") + ") من (" + (ed.uni || "الجامعة") + "). أنجزت مشروع تخرج بعنوان «" + (ed.gradProject || "مشروع تطبيقي") + "»، وأمتلك مهارات متقدمة في (" + (ar.skillsTech || []).slice(0, 4).join("، ") + ") مما يؤهلني لتقديم قيمة مضافة فورية.";
        saveState();
        renderUniCareerStudio();
        toast("📄 تم استيراد ملخص إجابتك من بيانات سيرتك الذاتية المحفوظة ✓", "success");
      } catch (e) {}
    };
    if ($("ucEvalIvAnsBtn")) $("ucEvalIvAnsBtn").onclick = function () {
      var ans = (UState.interview.userAnswer || "").trim();
      if (ans.length < 15) { toast("اكتب إجابتك التجريبية أولاً (سطرين على الأقل) لتقييمها", "warning"); return; }
      var score = 75;
      var notes = [];
      if (ans.length > 100) score += 10;
      else notes.push("• فصّل أكثر في خطوات الإجراء العملي الذي قمت به (Action).");
      if (/\d+|%|نتيجة|أنجز|طور|حقق|result|built|improved/i.test(ans)) score += 15;
      else notes.push("• أضف رقماً أو نتيجة ملموسة في نهاية إجابتك (مثال: رفع الكفاءة بنسبة 30%) لتطبيق معيار (Result) في منهجية STAR.");
      UState.interview.feedback = "🌟 تقييم إجابتك وفق معيار المقابلات الاحترافية (STAR): " + score + " / 100\n" +
        (notes.length ? "💡 نصائح لرفع قوة إجابتك إلى 100%:\n" + notes.join("\n") : "✅ إجابة ممتازة ومتوازنة! جمعت بين الموقف الأكاديمي، المهارة العملية، والنتيجة الملموسة.");
      saveState();
      renderUniCareerStudio();
    };
  }

  function openUniCareer(tabName, payload) {
    if (tabName) UState.tab = tabName;
    if (payload && payload.title) {
      UState.research.titleAr = payload.title;
      if (payload.notes) UState.research.sourceNotes = payload.notes;
      UState.research.generatedOut = buildDefaultResearchProposal(UState.research);
      UState.citations.title = payload.title;
    }
    saveState();
    renderUniCareerStudio();
    if (window.EduLauncher && window.EduLauncher.jump) {
      window.EduLauncher.jump("uniResearchCareerStudio", true);
    } else {
      var sec = $("uniResearchCareerStudio");
      if (sec) sec.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  function init() {
    renderUniCareerStudio();
    
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();

  window.EduUniCareer = {
    open: openUniCareer,
    render: renderUniCareerStudio
  };
})();

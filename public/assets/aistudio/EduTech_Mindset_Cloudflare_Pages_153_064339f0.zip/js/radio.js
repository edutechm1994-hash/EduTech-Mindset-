/*
 * استوديو الإذاعة المدرسية الصباحية والمسابقات الثقافية والرمضانية — EduTech Mindset (الإصدار 50 الذهبي)
 * 1) 🎙️ مولّد برنامج الإذاعة المدرسية الصباحية المتكامل (مقدمة، قرآن، حديث، كلمة الصباح، هل تعلم، حكمة ودعاء)
 *    مع قوالب جاهزة تعمل بلا إنترنت + توليد مخصص لأي موضوع بالذكاء الاصطناعي + طباعة A4 PDF.
 * 2) 🌙 مولّد المسابقات الثقافية والرمضانية المدرسية بين الفصول (أسئلة مصنفة مع إجاباتها للطباعة والعرض).
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var READY_BROADCASTS = {
    science: {
      topic: "فضل العلم والاجتهاد وبناء الوطن",
      intro: "بسم الله الرحمن الرحيم، مع إشراقة صباح جديد يملؤه الأمل والطموح من أرض فلسطين الطيبة، نحييكم في إذاعتنا المدرسية لهذا اليوم وعنوانها: «بالعلم نبني الوطن ونصنع المستقبل».",
      quran: "قال الله تعالى: ﴿يَرْفَعِ اللَّهُ الَّذِينَ آمَنُوا مِنكُمْ وَالَّذِينَ أُوتُوا الْعِلْمَ دَرَجَاتٍ﴾ [المجادلة: 11].",
      hadith: "قال رسول الله ﷺ: «مَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقًا إِلَى الْجَنَّةِ».",
      speech: "زملائي الطلبة، إن العلم هو السلاح الأقوى الذي يرتقي بالأمم ويحفظ كرامتها، فكل ساعة نقضيها في فهم درس أو إتقان مهارة هي لبنة في بناء مستقبلنا ومستقبل وطننا الغالي.",
      didYouKnow: "هل تعلم أن العالم المسلم الحسن بن الهيثم هو مؤسس علم البصريات الحديث ومخترع فكرة الكاميرا؟ وهل تعلم أن القراءة لمدة 20 دقيقة يومياً تضاعف حصيلتك المعرفية واللغوية؟",
      wisdom: "حكمة اليوم: «اطلبوا العلم من المهد إلى اللحد، فمن لم يحتمل ذلّ التعلّم ساعة بقي في ذلّ الجهل أبداً»."
    },
    palestine: {
      topic: "فلسطين والقدس الشريف في قلوبنا",
      intro: "بسم الله الرحمن الرحيم، صباحٌ فلسطينيٌّ عابقٌ برائحة الزيتون والزعتر، نطلّ عليكم به من منبر إذاعتنا المدرسية لنحلّق معاً في رحاب «فلسطين والقدس الشريف».",
      quran: "قال الله تعالى: ﴿سُبْحَانَ الَّذِي أَسْرَىٰ بِعَبْدِهِ لَيْلًا مِّنَ الْمَسْجِدِ الْحَرَامِ إِلَى الْمَسْجِدِ الْأَقْصَى الَّذِي بَارَكْنَا حَوْلَهُ﴾ [الإسراء: 1].",
      hadith: "قال رسول الله ﷺ: «لَا تُشَدُّ الرِّحَالُ إِلَّا إِلَى ثَلَاثَةِ مَسَاجِدَ: المَسْجِدِ الحَرَامِ، وَمَسْجِدِي هَذَا، وَالمَسْجِدِ الأَقْصَى».",
      speech: "أيها الأحبة، إن حب الوطن يترجم بالعلم والعمل والحفاظ على تاريخنا وهويتنا، ففلسطين أرض الأنبياء ومهد الحضارات، وأمانتها في أعناق جيلنا المتعلم الواعي.",
      didYouKnow: "هل تعلم أن مدينة أريحا الفلسطينية هي أقدم مدينة مأهولة في التاريخ منذ أكثر من عشرة آلاف عام؟ وأن مساحة فلسطين التاريخية تبلغ نحو 27,027 كم²؟",
      wisdom: "حكمة اليوم: «على هذه الأرض ما يستحق الحياة.. بالعلم والصبر نصنع الغد المشرق»."
    }
  };

  var st = {
    tab: "radio", // radio | comp
    data: READY_BROADCASTS.science,
    compQuestions: [
      { cat: "🕌 ثقافة إسلامية", q: "ما السورة التي تسمى قلب القرآن الكريم؟", a: "سورة يس" },
      { cat: "🇵🇸 تاريخ وجغرافيا فلسطين", q: "ما هي أكبر محافظات الضفة الغربية من حيث المساحة والسكان؟", a: "محافظة الخليل" },
      { cat: "🔬 علوم وطبيعة", q: "ما الغاز الذي يمتصه النبات في عملية البناء الضوئي؟", a: "غاز ثاني أكسيد الكربون CO2" },
      { cat: "📖 لغة عربية وأدب", q: "من هو الشاعر الفلسطيني صاحب ديوان «أوراق الزيتون»؟", a: "محمود درويش" },
      { cat: "🧠 ذكاء ومنطق", q: "ما العدد الذي إذا ضربته في نفسه وأضفت إليه 5 أصبح الناتج 30؟", a: "العدد 5" }
    ]
  };

  function printRadioPdf() {
    var d = st.data;
    var dt = new Date().toLocaleDateString("ar-EG", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>برنامج الإذاعة المدرسية</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;800;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:14mm}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a;line-height:1.85}h1{text-align:center;color:#0369a1;margin:0 0 4px}.meta{text-align:center;color:#475569;font-weight:700;margin-bottom:14px}.sec{border:2px solid #cbd5e1;border-radius:14px;padding:12px 16px;margin-bottom:10px;break-inside:avoid}.sec h3{margin:0 0 4px;color:#047857;font-size:15px}</style></head><body>' +
      '<h1>🎙️ برنامج الإذاعة المدرسية الصباحية — ' + e(d.topic) + '</h1>' +
      '<div class="meta">التاريخ: ' + dt + ' • إشراف المعلم/ـة: .................................... • الصف: ....................</div>' +
      '<div class="sec"><h3>1) 🌟 المقدمة الإذاعية (الطالب/ـة: ........................):</h3><div>' + e(d.intro) + '</div></div>' +
      '<div class="sec"><h3>2) 📖 القرآن الكريم (الطالب/ـة: ........................):</h3><div>' + e(d.quran) + '</div></div>' +
      '<div class="sec"><h3>3) 🕌 الحديث النبوي الشريف (الطالب/ـة: ........................):</h3><div>' + e(d.hadith) + '</div></div>' +
      '<div class="sec"><h3>4) 📝 كلمة الصباح (الطالب/ـة: ........................):</h3><div>' + e(d.speech) + '</div></div>' +
      '<div class="sec"><h3>5) 💡 فقرة هل تعلم؟ (الطالب/ـة: ........................):</h3><div>' + e(d.didYouKnow) + '</div></div>' +
      '<div class="sec"><h3>6) 🌺 حكمة اليوم ودعاء الختام (الطالب/ـة: ........................):</h3><div>' + e(d.wisdom) + '</div></div>' +
      '</body></html>';
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
  }

  function generateAiRadio() {
    var topic = $("rdTopicInp").value.trim();
    if (!topic) { toast("اكتب موضوع الإذاعة المدرسية أولاً", "warning"); return; }
    var btn = $("rdGenAiBtn");
    btn.disabled = true; btn.textContent = "⏳ يعدّ فقرات الإذاعة…";
    var prompt = "أنت مشرف إذاعة مدرسية مبدع في فلسطين. أعدّ برنامج إذاعة مدرسية صباحية متكاملاً وبليغاً عن موضوع: «" + topic + "».\n" +
      "أعد JSON صالحاً فقط بلا أي نص خارجه بهذا الشكل:\n" +
      '{"topic":"' + topic + '","intro":"نص المقدمة","quran":"آية قرآنية مناسبة للموضوع","hadith":"حديث نبوي شريف مناسب","speech":"كلمة الصباح (4 جمل مؤثرة)","didYouKnow":"معلومتان في فقرة هل تعلم","wisdom":"حكمة اليوم ودعاء ختامي قصير"}';
    window.AI.ask(prompt, [], "worksheet").then(function (txt) {
      var s = String(txt || "").replace(/```json|```/gi, ""), a = s.indexOf("{"), b = s.lastIndexOf("}");
      var j = JSON.parse(s.slice(a, b + 1));
      if (j && j.intro) { st.data = j; paint(); }
    }).catch(function () {
      toast("تعذر توليد الإذاعة حالياً", "warning");
    }).then(function () {
      if ($("rdGenAiBtn")) { $("rdGenAiBtn").disabled = false; $("rdGenAiBtn").textContent = "🤖 ولّد إذاعة متكاملة بالذكاء الاصطناعي"; }
    });
  }

  function generateAiComp() {
    var theme = $("rdCompTheme").value.trim() || "مسابقة ثقافية وعلمية ورمضانية شاملة";
    var btn = $("rdCompGenBtn");
    btn.disabled = true; btn.textContent = "⏳ يولّد أسئلة المسابقة…";
    var prompt = "أنشئ 8 أسئلة مسابقة مدرسية ثقافية شيقة ومتنوعة مع إجاباتها حول: «" + theme + "».\n" +
      "أعد JSON صالحاً فقط بهذا الشكل:\n" +
      '{"questions":[{"cat":"اسم المجال","q":"نص السؤال؟","a":"الإجابة الصحيحة"}]}';
    window.AI.ask(prompt, [], "worksheet").then(function (txt) {
      var s = String(txt || "").replace(/```json|```/gi, ""), a = s.indexOf("{"), b = s.lastIndexOf("}");
      var j = JSON.parse(s.slice(a, b + 1));
      if (j && Array.isArray(j.questions) && j.questions.length) {
        st.compQuestions = j.questions;
        paint();
      }
    }).catch(function () {
      toast("تعذر التوليد حالياً", "warning");
    }).then(function () {
      if ($("rdCompGenBtn")) { $("rdCompGenBtn").disabled = false; $("rdCompGenBtn").textContent = "🤖 ولّد مسابقة جديدة بالـ AI"; }
    });
  }

  function paint() {
    var box = $("rdBody"); if (!box) return;
    var nav = '<div class="flex flex-wrap gap-2 mb-4 border-b border-slate-200 dark:border-slate-700 pb-3">' +
      '<button type="button" data-rdtab="radio" class="px-4 py-2 rounded-xl text-xs font-extrabold transition-all ' + (st.tab === "radio" ? "bg-amber-500 text-slate-950 shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">🎙️ مولّد الإذاعة المدرسية الصباحية</button>' +
      '<button type="button" data-rdtab="comp" class="px-4 py-2 rounded-xl text-xs font-extrabold transition-all ' + (st.tab === "comp" ? "bg-emerald-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">🌙 المسابقات الثقافية والرمضانية بين الفصول</button>' +
      '</div>';

    if (st.tab === "radio") {
      var d = st.data;
      box.innerHTML = nav + '<div class="space-y-3">' +
        '<div class="flex flex-wrap gap-2 items-center">' +
        '<input id="rdTopicInp" value="' + e(d.topic) + '" placeholder="موضوع الإذاعة (مثال: بر الوالدين، يوم المعلم، الأمانة، شهر رمضان…)" class="' + cls + ' flex-1 min-w-[200px]">' +
        '<button type="button" id="rdGenAiBtn" class="px-4 py-2.5 rounded-xl bg-brand-600 text-white text-xs font-black">🤖 ولّد إذاعة متكاملة بالذكاء الاصطناعي</button>' +
        '<button type="button" id="rdPresetSci" class="px-3 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold">قالب: فضل العلم</button>' +
        '<button type="button" id="rdPresetPal" class="px-3 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold">قالب: فلسطين والقدس</button>' +
        '<button type="button" id="rdPrintBtn" class="px-4 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black">🖨 طباعة برنامج الإذاعة PDF</button></div>' +
        '<div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">' +
        [['🌟 المقدمة الإذاعية', d.intro], ['📖 القرآن الكريم', d.quran], ['🕌 الحديث الشريف', d.hadith], ['📝 كلمة الصباح', d.speech], ['💡 هل تعلم؟', d.didYouKnow], ['🌺 حكمة اليوم والختام', d.wisdom]].map(function (sec) {
          return '<div class="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-900/50"><div class="font-black text-brand-600 dark:text-brand-300 mb-1">' + sec[0] + '</div><div class="leading-relaxed font-semibold">' + e(sec[1]) + '</div></div>';
        }).join("") + '</div></div>';

      $("rdGenAiBtn").onclick = generateAiRadio;
      $("rdPresetSci").onclick = function () { st.data = READY_BROADCASTS.science; paint(); };
      $("rdPresetPal").onclick = function () { st.data = READY_BROADCASTS.palestine; paint(); };
      $("rdPrintBtn").onclick = printRadioPdf;
    } else {
      box.innerHTML = nav + '<div class="space-y-3">' +
        '<div class="flex flex-wrap gap-2">' +
        '<input id="rdCompTheme" placeholder="موضوع المسابقة (مثال: مسابقة شهر رمضان المبارك / مسابقة أوائل الطلبة الثقافية)" class="' + cls + ' flex-1">' +
        '<button type="button" id="rdCompGenBtn" class="px-5 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black">🤖 ولّد مسابقة جديدة بالـ AI</button></div>' +
        '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">' +
        st.compQuestions.map(function (q, i) {
          return '<details class="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs"><summary class="font-black cursor-pointer"><span class="text-amber-600">[' + e(q.cat) + ']</span> ' + (i + 1) + ') ' + e(q.q) + '</summary><div class="mt-2 pt-2 border-t border-slate-100 dark:border-slate-700 text-emerald-600 dark:text-emerald-400 font-black">✅ الإجابة: ' + e(q.a) + '</div></details>';
        }).join("") + '</div></div>';
      $("rdCompGenBtn").onclick = generateAiComp;
    }

    box.querySelectorAll("[data-rdtab]").forEach(function (b) {
      b.onclick = function () { st.tab = b.dataset.rdtab; paint(); };
    });
  }

  function build() {
    if ($("radioStudio")) return true;
    var anchor = $("certStudio") || $("classToolsStudio") || $("designStudio");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "radioStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-amber-600 via-teal-800 to-slate-900 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-200 mb-1">🎙️ استوديو الإذاعة المدرسية الصباحية والمسابقات الثقافية والرمضانية</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">أعدّ برنامج إذاعة مدرسية متكاملاً جاهزاً للطباعة ومسابقة ثقافية بين الفصول في دقيقة</h2>' +
      '<p class="text-xs text-white/85 mt-1">فقرات إذاعية متكاملة (قرآن، حديث، كلمة، هل تعلم، حكمة) مع بنك مسابقات ثقافية ورمضانية.</p>' +
      '</div><div class="p-4 sm:p-6 text-right" id="rdBody"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    paint();
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduRadio = { open: function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("radioStudio", true); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

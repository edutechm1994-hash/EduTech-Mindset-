/* أدوات المعلم الذكية (مبنية داخل الموقع):
   1) محضّر الدروس: صوّر صفحات الكتاب ← خطة درس/اختبار/شرح...
   2) دفتر المصادر (على طريقة NotebookLM): أضف ملفاتك ونصوصك ثم اسأل وولّد ملخصاً وأسئلة.
   الصور وملفات PDF تتطلب مفتاح Gemini (إدارة كاملة ← الذكاء الاصطناعي). النصوص تعمل بدونه. */
(function () {
  "use strict";
  var MAX_CHARS = 60000;
  function esc(s) { return escapeHtml(s); }
  var inp = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";
  var btn = "px-4 py-2 rounded-xl text-xs font-extrabold ";

  function readB64(file) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(",")[1]); };
      r.onerror = function () { rej(new Error("read")); };
      r.readAsDataURL(file);
    });
  }
  function readText(file) {
    return new Promise(function (res, rej) { var r = new FileReader(); r.onload = function () { res(String(r.result)); }; r.onerror = rej; r.readAsText(file); });
  }
  function shrinkImage(file) {
    return new Promise(function (res, rej) {
      var url = URL.createObjectURL(file), im = new Image();
      im.onload = function () {
        var m = 1600, k = Math.min(1, m / Math.max(im.width, im.height));
        var c = document.createElement("canvas"); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
        c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        res({ mime: "image/jpeg", data: c.toDataURL("image/jpeg", 0.8).split(",")[1] });
      };
      im.onerror = function () { URL.revokeObjectURL(url); rej(new Error("img")); };
      im.src = url;
    });
  }
  function needKeyMsg() { showToast("الصور وملفات PDF تحتاج محركاً يدعم الرؤية (Gemini أو OpenAI أو Claude): أضف المفتاح مباشرة من: إدارة كاملة ← المحركات الذكية", "warning"); }
  function guard() {
    /* متاح لجميع المعلمين والطلبة والزوار */
    return true;
  }
  function errMsg(e) {
    if (e && e.message === "NEEDS_KEY") { needKeyMsg(); return; }
    showToast("تعذر الاتصال بالمساعد الآن (" + String(e && e.message || "خطأ").slice(0, 60) + ")", "warning");
  }
  function download(name, text) {
    var html = '<html dir="rtl" lang="ar"><head><meta charset="utf-8"></head><body style="font-family:Arial;line-height:1.8">' + esc(text).replace(/\n/g, "<br>") + "</body></html>";
    var a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob(["﻿" + html], { type: "application/msword" }));
    a.download = name + ".doc"; document.body.appendChild(a); a.click(); a.remove();
  }
  function resultBox(id) {
    return '<div id="' + id + 'Wrap" class="hidden mt-4"><div id="' + id + '" class="whitespace-pre-wrap text-xs leading-loose p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-700 max-h-[60vh] overflow-y-auto"></div>' +
      '<div class="flex gap-2 mt-2"><button type="button" data-copy="' + id + '" class="' + btn + 'bg-slate-200 dark:bg-slate-700">نسخ</button>' + (window.Exporter ? window.Exporter.bar({ src: "#" + id, tool: id === "pRes" ? "محضّر الدروس" : "أدوات المعلم", copy: false }) : '') + '</div></div>';
  }

  function build() {
    if (document.getElementById("teacherTools")) return;
    var anchor = document.getElementById("aiStudio") || document.getElementById("social");
    if (!anchor) return;
    var s = document.createElement("section");
    s.id = "teacherTools"; s.className = "py-10 scroll-mt-20";
    s.innerHTML =
      '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8"><div class="text-center mb-6"><h2 class="text-2xl font-black text-slate-900 dark:text-white"><i class="fa-solid fa-wand-magic-sparkles text-amber-500 ml-2"></i>أدوات المعلم الذكية</h2>' +
      '<p class="text-xs text-slate-500 mt-1">حضّر درسك من كتابك، وادرس مصادرك واسأل عنها</p></div>' +
      '<div class="flex gap-2 justify-center mb-4"><button type="button" data-tt="prep" class="tt-btn"></button><button type="button" data-tt="nb" class="tt-btn"></button></div>' +

      // --- محضّر الدروس
      '<div id="ttPrep" class="glass-card rounded-3xl border border-slate-200 dark:border-slate-800 p-5 sm:p-7 text-right">' +
      '<h3 class="font-black text-sm mb-1">📸 حضّر حصتك من كتابك</h3><p class="text-[11px] text-slate-500 mb-3">صوّر من 1 إلى 10 صفحات من الدرس (مسطّحة وبإضاءة جيدة)، أو الصق نص الدرس.</p>' +
      '<label class="' + btn + 'bg-brand-600 text-white inline-block cursor-pointer"><i class="fa-solid fa-camera ml-1"></i>إضافة صور الصفحات<input id="pImgs" type="file" accept="image/*" multiple class="hidden"></label>' +
      '<span id="pImgCount" class="text-[11px] font-bold mr-2"></span>' +
      '<textarea id="pText" rows="3" class="' + inp + ' mt-3" placeholder="أو الصق نص الدرس هنا (يعمل بدون مفتاح)"></textarea>' +
      '<div class="grid grid-cols-2 gap-2 mt-3"><input id="pGrade" class="' + inp + '" placeholder="الصف (مثال: الرابع)"><input id="pSubject" class="' + inp + '" placeholder="المادة (مثال: رياضيات)"></div>' +
      '<div class="flex flex-wrap gap-x-4 gap-y-2 mt-3 text-[11px] font-bold">' +
      [["plan", "خطة درس", 1], ["quiz", "اختبار قصير", 1], ["explain", "شرح مبسّط", 0], ["sum", "ملخص", 0], ["parent", "رسالة لولي الأمر", 0]].map(function (o) { return '<label class="flex items-center gap-1.5"><input type="checkbox" class="pOut" value="' + o[0] + '" ' + (o[2] ? "checked" : "") + ">" + o[1] + "</label>"; }).join("") + "</div>" +
      '<button id="pGo" type="button" class="' + btn + 'bg-emerald-600 text-white mt-4">جهّزلي</button><span id="pSt" class="text-[11px] font-bold mr-2"></span>' + resultBox("pRes") + "</div>" +

      // --- دفتر المصادر
      '<div id="ttNb" class="hidden glass-card rounded-3xl border border-slate-200 dark:border-slate-800 p-5 sm:p-7 text-right">' +
      '<h3 class="font-black text-sm mb-1">📚 دفتر المصادر</h3><p class="text-[11px] text-slate-500 mb-3">أضف ملفاتك ونصوصك، ثم اسأل: تجيب من مصادرك فقط. (ملفات txt تعمل بدون مفتاح؛ PDF والصور تحتاج مفتاح Gemini.) المصادر تبقى في جهازك فقط ولا تُحفظ.</p>' +
      '<div class="flex flex-wrap gap-2 items-center"><label class="' + btn + 'bg-brand-600 text-white cursor-pointer"><i class="fa-solid fa-file-circle-plus ml-1"></i>إضافة ملفات<input id="nbFiles" type="file" accept=".txt,.md,.pdf,image/*" multiple class="hidden"></label></div>' +
      '<div class="flex gap-2 mt-2"><input id="nbPasteTitle" class="' + inp + ' max-w-[160px]" placeholder="عنوان النص"><textarea id="nbPaste" rows="1" class="' + inp + '" placeholder="الصق نصاً كمصدر"></textarea><button id="nbPasteAdd" type="button" class="' + btn + 'bg-slate-200 dark:bg-slate-700 shrink-0">إضافة</button></div>' +
      '<div id="nbList" class="mt-3 space-y-1.5 text-[11px]"></div>' +
      '<div class="flex flex-wrap gap-2 mt-3">' + [["ملخص", "لخّص المصادر في نقاط رئيسية ثم فقرة موجزة."], ["دليل دراسة", "أنشئ دليل دراسة: المفاهيم الأساسية، مصطلحات مع تعريفاتها، وأسئلة مراجعة."], ["اختبار", "ضع اختباراً من 10 أسئلة متنوعة من المصادر مع مفتاح الإجابة."], ["أسئلة شائعة", "اكتب 8 أسئلة متوقعة مع إجاباتها اعتماداً على المصادر."]].map(function (q) { return '<button type="button" class="nbQuick ' + btn + 'bg-amber-500/15 text-amber-700 dark:text-amber-400" data-q="' + esc(q[1]) + '">' + q[0] + "</button>"; }).join("") + "</div>" +
      '<div id="nbChat" class="mt-3 space-y-2 text-xs max-h-[50vh] overflow-y-auto"></div>' +
      '<div id="nbAllBar" class="hidden mt-2 flex items-center gap-2 text-[11px] font-bold text-slate-500">تصدير المحادثة كاملة: ' + (window.Exporter ? window.Exporter.bar({ src: "#nbChat", title: "دفتر المصادر — المحادثة كاملة", tool: "دفتر المصادر", copy: false }) : "") + '</div>' +
      '<div class="flex gap-2 mt-3"><input id="nbQ" class="' + inp + '" placeholder="اسأل عن مصادرك…"><button id="nbAsk" type="button" class="' + btn + 'bg-emerald-600 text-white shrink-0">اسأل</button></div></div>' +
      '<p class="text-center text-[10px] text-slate-400 mt-4">للأصل: <a class="underline" href="https://mualim.belteckhub.com/" target="_blank" rel="noopener">منصة معلّم</a> · <a class="underline" href="https://notebooklm.google.com/" target="_blank" rel="noopener">NotebookLM</a></p></div>';
    anchor.parentNode.insertBefore(s, anchor);

    function $(id) { return document.getElementById(id); }
    function tab(w) {
      $("ttPrep").classList.toggle("hidden", w !== "prep"); $("ttNb").classList.toggle("hidden", w !== "nb");
      s.querySelectorAll(".tt-btn").forEach(function (b) {
        b.className = "tt-btn " + btn + (b.dataset.tt === w ? "bg-brand-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300");
        b.textContent = b.dataset.tt === "prep" ? "محضّر الدروس" : "دفتر المصادر";
      });
    }
    s.querySelectorAll(".tt-btn").forEach(function (b) { b.addEventListener("click", function () { tab(b.dataset.tt); }); });
    tab("prep");
    s.addEventListener("click", function (e) {
      var c = e.target.closest("[data-copy]"), w = e.target.closest("[data-word]");
      if (c) copyTextToClipboard($(c.dataset.copy).textContent, "تم النسخ 📋");
      if (w) download("EduTech", $(w.dataset.word).textContent);
    });

    // ===== محضّر الدروس =====
    var pages = [];
    $("pImgs").addEventListener("change", function (e) {
      var fs = Array.prototype.slice.call(e.target.files).slice(0, 10 - pages.length);
      Promise.all(fs.map(shrinkImage)).then(function (a) { pages = pages.concat(a).slice(0, 10); $("pImgCount").textContent = pages.length + " صفحة"; })
        .catch(function () { showToast("تعذر قراءة صورة", "warning"); });
      e.target.value = "";
    });
    $("pGo").addEventListener("click", function () {
      var text = $("pText").value.trim(), outs = Array.prototype.map.call(document.querySelectorAll(".pOut:checked"), function (x) { return x.value; });
      if (!pages.length && !text) { showToast("أضف صور الصفحات أو الصق نص الدرس", "warning"); return; }
      if (!outs.length) { showToast("اختر مخرجاً واحداً على الأقل", "warning"); return; }
      if (pages.length && !window.AI.hasKey()) { needKeyMsg(); return; }
      if (!guard()) return;
      var L = { plan: "خطة درس تفاعلية كاملة (الأهداف، التمهيد، الأنشطة، التقويم، التوقيت لحصة 45 دقيقة)", quiz: "اختبار قصير من 8 أسئلة متنوعة مع مفتاح الإجابة", explain: "شرح مبسّط للدرس بأمثلة من الحياة", sum: "ملخص في نقاط", parent: "رسالة مهذبة قصيرة لولي الأمر عن موضوع الدرس" };
      var prompt = "الصف: " + ($("pGrade").value || "غير محدد") + " | المادة: " + ($("pSubject").value || "غير محددة") + "\nاعتمد حصراً على " + (pages.length ? "صور صفحات الدرس المرفقة" : "النص التالي") + ". اكتب بالعربية بعناوين واضحة لكل مما يلي:\n" +
        outs.map(function (o, i) { return (i + 1) + ". " + L[o]; }).join("\n") + (text ? "\n\nنص الدرس:\n" + text.slice(0, MAX_CHARS) : "");
      $("pSt").textContent = "⏳ جارٍ التحضير… قد يستغرق دقيقة"; $("pGo").disabled = true;
      window.AI.ask(prompt, pages, "prep").then(function (r) {
        if (window.Exporter) { window.Exporter.show($("pRes"), r); $("pRes").dataset.exTitle = "تحضير درس — " + ($("pSubject").value || "") + " " + ($("pGrade").value || ""); window.Exporter.record({ title: $("pRes").dataset.exTitle, text: r, tool: "محضّر الدروس" }); } else $("pRes").textContent = r; $("pResWrap").classList.remove("hidden"); $("pSt").textContent = "✓ تم";
        if (getCurrentUser()) { logActivity("حضّرت درساً بالذكاء الاصطناعي"); saveState(); }
      }).catch(function (e) { $("pSt").textContent = ""; errMsg(e); }).then(function () { $("pGo").disabled = false; });
    });

    // ===== دفتر المصادر =====
    var sources = [], history = [], fullLog = [], nbN = 0;
    function drawSources() {
      $("nbList").innerHTML = sources.length ? sources.map(function (x, i) { return '<div class="flex items-center justify-between gap-2 p-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"><span class="truncate">' + (x.data ? "📎" : "📝") + " " + esc(x.name) + '</span><button type="button" data-rm="' + i + '" class="text-rose-500 font-bold">حذف</button></div>'; }).join("") : '<div class="text-slate-400">لا توجد مصادر بعد.</div>';
      $("nbList").querySelectorAll("[data-rm]").forEach(function (b) { b.addEventListener("click", function () { sources.splice(+b.dataset.rm, 1); drawSources(); }); });
    }
    drawSources();
    $("nbFiles").addEventListener("change", function (e) {
      var fs = Array.prototype.slice.call(e.target.files); e.target.value = "";
      fs.forEach(function (f) {
        var isImg = /^image\//.test(f.type), isPdf = f.type === "application/pdf" || /\.pdf$/i.test(f.name);
        if ((isImg || isPdf) && !window.AI.hasKey()) { needKeyMsg(); return; }
        if (isPdf && f.size > 10 * 1024 * 1024) { showToast("حجم PDF أكبر من 10MB: " + f.name, "warning"); return; }
        var p = isImg ? shrinkImage(f).then(function (o) { return { name: f.name, mime: o.mime, data: o.data }; })
          : isPdf ? readB64(f).then(function (d) { return { name: f.name, mime: "application/pdf", data: d }; })
          : readText(f).then(function (t) { return { name: f.name, text: t }; });
        p.then(function (x) { sources.push(x); drawSources(); }).catch(function () { showToast("تعذر قراءة " + f.name, "warning"); });
      });
    });
    $("nbPasteAdd").addEventListener("click", function () {
      var t = $("nbPaste").value.trim(); if (!t) return;
      sources.push({ name: $("nbPasteTitle").value.trim() || "نص ملصوق", text: t }); $("nbPaste").value = ""; $("nbPasteTitle").value = ""; drawSources();
    });
    function bubble(cls, txt) { var d = document.createElement("div"); d.className = "p-3 rounded-2xl whitespace-pre-wrap leading-loose " + cls; d.textContent = txt; $("nbChat").appendChild(d); $("nbChat").scrollTop = 1e6; return d; }
    function ask(q) {
      if (!sources.length) { showToast("أضف مصدراً واحداً على الأقل", "warning"); return; }
      if (!q) return;
      if (!guard()) return;
      var texts = "", files = [];
      sources.forEach(function (x, i) { if (x.text) texts += "\n\n=== مصدر " + (i + 1) + ": " + x.name + " ===\n" + x.text; else files.push(x); });
      var prompt = "أنت مساعد دراسة. أجب فقط اعتماداً على المصادر المرفقة. إن لم تجد الإجابة فيها فقل: «لم أجد ذلك في المصادر». اذكر اسم المصدر الذي استندت إليه.\n" + texts.slice(0, MAX_CHARS) +
        (history.length ? "\n\nالمحادثة السابقة:\n" + history.slice(-6).map(function (h) { return h[0] + ": " + h[1]; }).join("\n") : "") + "\n\nالسؤال/الطلب: " + q;
      bubble("bg-brand-600/10 font-bold", q); $("nbQ").value = "";
      var w = bubble("bg-slate-100 dark:bg-slate-800", "⏳ …"); $("nbAsk").disabled = true;
      window.AI.ask(prompt, files, "notebook").then(function (r) {
        history.push(["المستخدم", q], ["المساعد", r.slice(0, 600)]);
        if (window.Exporter) {
          w.id = "nbA" + (++nbN); window.Exporter.show(w, r); w.dataset.exTitle = "دفتر المصادر — " + q.slice(0, 45);
          w.insertAdjacentHTML("afterend", window.Exporter.bar({ src: "#" + w.id, tool: "دفتر المصادر", copy: false }));
          window.Exporter.record({ title: w.dataset.exTitle, text: r, tool: "دفتر المصادر" });
          fullLog.push("## " + q + "\n\n" + r); $("nbChat").dataset.exRaw = "# دفتر المصادر — المحادثة\n\n" + fullLog.join("\n\n---\n\n"); $("nbAllBar").classList.remove("hidden");
        } else w.textContent = r;
      })
        .catch(function (e) { w.remove(); errMsg(e); }).then(function () { $("nbAsk").disabled = false; });
    }
    $("nbAsk").addEventListener("click", function () { ask($("nbQ").value.trim()); });
    $("nbQ").addEventListener("keydown", function (e) { if (e.key === "Enter") ask($("nbQ").value.trim()); });
    s.querySelectorAll(".nbQuick").forEach(function (b) { b.addEventListener("click", function () { ask(b.dataset.q); }); });

    var nav = document.querySelector('nav a[href="#library"]');
    if (nav && false) {
      var a = document.createElement("a"); a.id = "navToolsLink"; a.href = "#teacherTools"; a.className = nav.className;
      a.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles text-slate-400"></i>أدوات المعلم'; nav.parentNode.insertBefore(a, nav);
    }
  }
  window.addEventListener("DOMContentLoaded", function () { setTimeout(build, 50); });
})();

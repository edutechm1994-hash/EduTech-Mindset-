/*
 * لوحة إدارة المحركات الذكية (عربية) — EduTech Mindset
 * مخصصة لمنصة Cloudflare Pages (edutech-mindset.pages.dev)
 * تظهر داخل: إدارة كاملة ← المحركات الذكية
 * حقول المفاتيح هنا تُرسَل مباشرة ومحمية إلى الخادم (/api/keys)
 * المفاتيح تُحفظ مشفرة بأمان ولا تصل للمتصفح ولا يراها أي زائر، وتعمل فوراً دون الحاجة لإعادة النشر.
 */
(function () {
  "use strict";

  var ENG = ["gemini", "openai", "claude", "deepseek", "meta", "free"];
  var ENV = { gemini: "GEMINI_API_KEY", openai: "OPENAI_API_KEY", claude: "ANTHROPIC_API_KEY", deepseek: "DEEPSEEK_API_KEY", meta: "META_API_KEY" };
  var INFO = {
    gemini: ["Google Gemini", "سريع وسخي بالمجان · يقرأ الصور وPDF", true, "gemini-2.5-flash"],
    openai: ["OpenAI ChatGPT", "جودة عامة عالية · يقرأ الصور وPDF", true, "gpt-4o-mini"],
    claude: ["Anthropic Claude", "صياغة تربوية دقيقة وعربية متقنة · يقرأ الصور وPDF", true, "claude-haiku-5-5"],
    deepseek: ["DeepSeek", "اقتصادي وقوي في التحليل · نصوص فقط (بلا صور)", false, "deepseek-chat"],
    meta: ["Meta AI (Llama)", "نماذج Llama المفتوحة من Meta · نصوص فقط · عربية جيدة", false, "Llama-3.3-70B-Instruct"],
    free: ["المحرك المجاني", "احتياطي أخير بلا مفتاح · نصوص فقط · جودة أقل", false, ""]
  };
  var KEY_FIELDS = ["geminiKey", "openaiKey", "claudeKey", "deepseekKey", "metaKey"];

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  var inp = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  function normalize(ai) {
    if (!ai.primaryProvider || ENG.indexOf(ai.primaryProvider) < 0) ai.primaryProvider = "gemini";
    if (ai.autoFallback === undefined) ai.autoFallback = true;
    var ord = (Array.isArray(ai.order) ? ai.order : []).filter(function (e) { return ENG.indexOf(e) >= 0; });
    ENG.forEach(function (e) { if (ord.indexOf(e) < 0) ord.push(e); });
    ai.order = ord;
    ai.enabled = ai.enabled || {}; ai.models = ai.models || {}; ai.toolEngines = ai.toolEngines || {};
    KEY_FIELDS.forEach(function (k) { delete ai[k]; });
    delete ai.model;
    return ai;
  }

  function html(ai) {
    normalize(ai);
    var tools = (window.AI && window.AI.TOOLS) || [];
    var engOpts = function (sel, withDefault) {
      return (withDefault ? '<option value="">المحرك الأساسي العام</option>' : "") + ENG.map(function (e) {
        return '<option value="' + e + '"' + (sel === e ? " selected" : "") + ">" + INFO[e][0] + "</option>";
      }).join("");
    };
    var cards = ENG.map(function (e) {
      var i = INFO[e];
      return '<div class="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70" data-card="' + e + '">' +
        '<div class="flex items-center justify-between gap-2 mb-1"><div class="font-black text-xs">' + i[0] + '</div>' +
        '<span data-badge="' + e + '" class="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700">…</span></div>' +
        '<div class="text-[10px] text-slate-500 mb-2">' + i[1] + '</div>' +
        '<label class="flex items-center gap-2 text-[11px] font-bold mb-2 cursor-pointer"><input type="checkbox" data-en="' + e + '"' + (ai.enabled[e] !== false ? " checked" : "") + ' class="w-4 h-4 rounded"> مُفعّل للاستخدام</label>' +
        (e === "free" ? "" : '<label class="text-[10px] font-bold block mb-1">اسم النموذج <span class="text-slate-400">(اتركه فارغاً للافتراضي)</span></label>' +
          '<input dir="ltr" data-model="' + e + '" class="' + inp + ' text-left font-mono mb-2" placeholder="' + esc(i[3]) + '" value="' + esc(ai.models[e] || "") + '">') +
        (e === "free" ? "" : '<label class="text-[10px] font-bold block mb-1">مفتاح API <span class="text-slate-400">(' + ENV[e] + ')</span></label>' +
          '<div class="flex gap-1.5 mb-2"><input type="password" dir="ltr" autocomplete="new-password" spellcheck="false" data-key="' + e + '" class="' + inp + ' text-left font-mono" placeholder="الصق المفتاح هنا ثم اضغط حفظ">' +
          '<button type="button" data-savekey="' + e + '" class="px-3 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-[10px] font-extrabold shrink-0">حفظ</button>' +
          '<button type="button" data-rmkey="' + e + '" title="حذف المفتاح" class="px-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 text-[10px] font-extrabold shrink-0">حذف</button></div>' +
          '<div data-keymsg="' + e + '" class="text-[10px] font-bold leading-relaxed mb-2"></div>') +
        '<div class="flex items-center gap-2"><button type="button" data-test="' + e + '" class="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-extrabold">اختبار</button>' +
        '<span data-res="' + e + '" class="text-[10px] font-mono leading-relaxed break-all"></span></div></div>';
    }).join("");

    var orderRows = ai.order.map(function (e) {
      return '<div data-ord="' + e + '" class="flex items-center gap-2 p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold">' +
        '<span class="flex-1">' + INFO[e][0] + '</span>' +
        '<button type="button" data-up class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700">▲</button>' +
        '<button type="button" data-down class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700">▼</button></div>';
    }).join("");

    var toolRows = tools.map(function (t) {
      return '<div class="grid grid-cols-1 sm:grid-cols-2 gap-1.5 items-center"><label class="text-[11px] font-bold">' + esc(t[1]) + '</label>' +
        '<select data-tool="' + t[0] + '" class="' + inp + '">' + engOpts(ai.toolEngines[t[0]] || "", true) + "</select></div>";
    }).join("");

    return '<div id="aiAdminRoot" class="space-y-3.5">' +
      '<div class="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-[11px] leading-loose">' +
      '<div class="font-black text-emerald-700 dark:text-emerald-300 mb-1">🔒 إدارة مفاتيح الذكاء الاصطناعي مباشرة من الموقع</div>' +
      'الصق المفتاح في حقل المحرك المطلوب ثم اضغط <b>«حفظ»</b>: يتم تشفير المفتاح وحفظه فوراً في خادم Cloudflare ليعمل المساعد الذكي مباشرة لجميع المستخدمين والطلبة دون الحاجة لإعادة نشر الموقع.' +
      '<div class="mt-2 text-[10px] text-slate-500 dark:text-slate-400">💡 <b>أمان كامل:</b> المفاتيح لا تظهر للمتصفح ولا يمكن لأي زائر قراءتها. يمكنك أيضاً ضبط المفاتيح كـ Secrets في لوحة Cloudflare Pages (Settings ← Variables and Secrets) كخيار بديل.</div>' +
      '</div>' +

      '<div class="grid grid-cols-1 sm:grid-cols-2 gap-3">' +
      '<div><label class="text-[11px] font-bold block mb-1">المحرك الأساسي (التبديل اليدوي)</label><select id="aiaPrimary" class="' + inp + '">' + engOpts(ai.primaryProvider, false) + '</select></div>' +
      '<div class="flex items-end pb-1.5"><label class="flex items-center gap-2 text-xs font-bold cursor-pointer"><input type="checkbox" id="aiaFallback"' + (ai.autoFallback !== false ? " checked" : "") + ' class="w-4 h-4 rounded"><span>التبديل التلقائي عند فشل المحرك (503 / انتهاء الحصة / خطأ الاتصال)</span></label></div></div>' +

      '<div><div class="text-[11px] font-black text-brand-600 dark:text-brand-400 mb-1.5">⚙️ المحركات</div><div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">' + cards + '</div>' +
      '<button type="button" id="aiaTestAll" class="mt-2.5 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold">اختبار كل المحركات المتصلة</button></div>' +

      '<div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700"><div class="text-[11px] font-black mb-1.5">🔁 ترتيب التبديل التلقائي <span class="font-semibold text-slate-500">(الأعلى يُجرَّب أولاً بعد المحرك الأساسي)</span></div><div id="aiaOrder" class="space-y-1.5">' + orderRows + '</div></div>' +

      '<div class="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20"><div class="text-[11px] font-black text-amber-700 dark:text-amber-300 mb-2">🎯 محرك مستقل لكل أداة تعليمية</div><div class="space-y-2">' + toolRows + '</div></div>' +
      '<p class="text-[10px] text-slate-500 leading-relaxed">اضغط «حفظ» أسفل نافذة الإدارة لتطبيق تخصيص النماذج وترتيب المحركات على الجميع. المحركات غير المضاف لها مفتاح تُتخطّى تلقائياً.</p></div>';
  }

  function root() { return document.getElementById("aiAdminRoot"); }

  function read(ai) {
    var r = root(); if (!r) return ai;
    normalize(ai);
    var g = function (id) { return document.getElementById(id); };
    ai.primaryProvider = g("aiaPrimary").value || "gemini";
    ai.autoFallback = g("aiaFallback").checked;
    ai.order = Array.prototype.map.call(r.querySelectorAll("[data-ord]"), function (x) { return x.dataset.ord; });
    r.querySelectorAll("[data-en]").forEach(function (c) { ai.enabled[c.dataset.en] = c.checked; });
    r.querySelectorAll("[data-model]").forEach(function (c) { var v = c.value.trim(); if (/^[A-Za-z0-9._:\-\/]{2,80}$/.test(v)) ai.models[c.dataset.model] = v; else delete ai.models[c.dataset.model]; });
    ai.toolEngines = {};
    r.querySelectorAll("[data-tool]").forEach(function (c) { if (c.value) ai.toolEngines[c.dataset.tool] = c.value; });
    return ai;
  }

  function clean(ai) {
    var o = normalize(JSON.parse(JSON.stringify(ai || {})));
    return { primaryProvider: o.primaryProvider, autoFallback: o.autoFallback !== false, order: o.order, enabled: o.enabled, models: o.models, toolEngines: o.toolEngines };
  }

  function setBadge(e, st) {
    var b = document.querySelector('[data-badge="' + e + '"]'); if (!b) return;
    var c = st && st.engines && st.engines[e];
    if (!c) { b.textContent = "غير معروف"; return; }
    b.textContent = c.configured ? (e === "free" ? "جاهز" : "المفتاح مضاف ✓") : "لا يوجد مفتاح ✗";
    b.className = "text-[10px] font-extrabold px-2 py-0.5 rounded-full " + (c.configured ? "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300" : "bg-rose-500/15 text-rose-600 dark:text-rose-300");
  }

  function show(res, e) {
    var o = document.querySelector('[data-res="' + e + '"]'); if (!o) return;
    var r = res && res[e];
    if (!r) { o.textContent = ""; return; }
    o.className = "text-[10px] font-mono leading-relaxed break-all " + (r.ok ? "text-emerald-600" : "text-rose-500");
    o.textContent = r.ok ? ("يعمل ✓ " + r.ms + "ms · " + (r.model || "")) : ("فشل: " + r.error);
  }

  function bind(ai) {
    var r = root(); if (!r) return;
    normalize(ai);
    window.AI.status(true).then(function (st) { ENG.forEach(function (e) { setBadge(e, st); }); });
    r.querySelectorAll("[data-up],[data-down]").forEach(function (b) {
      b.addEventListener("click", function () {
        var row = b.closest("[data-ord]"), list = row.parentNode;
        if (b.hasAttribute("data-up") && row.previousElementSibling) list.insertBefore(row, row.previousElementSibling);
        if (b.hasAttribute("data-down") && row.nextElementSibling) list.insertBefore(row.nextElementSibling, row);
      });
    });

    function run(engine) {
      read(ai);
      var targets = engine ? [engine] : ENG;
      targets.forEach(function (e) { var o = document.querySelector('[data-res="' + e + '"]'); if (o) { o.className = "text-[10px] font-mono"; o.textContent = "⏳ …"; } });
      var has = typeof appState !== "undefined", prev = has ? appState.aiConfig : null; if (has) appState.aiConfig = clean(ai);
      return window.AI.test(engine).then(function (res) { targets.forEach(function (e) { show(res, e); }); })
        .catch(function (err) { targets.forEach(function (e) { var o = document.querySelector('[data-res="' + e + '"]'); if (o) { o.className = "text-[10px] font-mono text-rose-500"; o.textContent = "تعذر الاختبار: " + (err.message || err); } }); })
        .then(function () { if (has) appState.aiConfig = prev; });
    }

    function token() {
      try {
        var u = window.Cloud && window.Cloud.user;
        return u && u.getIdToken ? u.getIdToken() : Promise.resolve("");
      } catch (e) {
        return Promise.resolve("");
      }
    }

    function call(body) {
      return token().then(function (t) {
        body.idToken = t;
        return fetch("/api/keys", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body)
        });
      }).then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (d) { d._status = res.status; return d; });
      });
    }

    function msg(e, text, ok) {
      var m = r.querySelector('[data-keymsg="' + e + '"]');
      if (m) {
        m.textContent = text;
        m.className = "text-[10px] font-bold leading-relaxed mb-2 " + (ok ? "text-emerald-600" : "text-rose-500");
      }
    }

    function refreshBadges() {
      return window.AI.status(true).then(function (st) {
        ENG.forEach(function (e) { setBadge(e, st); });
      });
    }

    function doKey(e, action) {
      var inpEl = r.querySelector('[data-key="' + e + '"]'), v = inpEl ? inpEl.value.trim() : "";
      if (action === "save" && !v) { msg(e, "الصق المفتاح أولاً", false); return; }
      if (action === "remove" && !window.eduConfirm("هل أنت متأكد من حذف مفتاح " + INFO[e][0] + "؟")) return;

      msg(e, action === "save" ? "⏳ جارٍ حفظ وتفعيل المفتاح في Cloudflare…" : "⏳ جارٍ حذف المفتاح…", true);

      call({ action: action, engine: e, value: v }).then(function (d) {
        if (inpEl && action === "save") inpEl.value = "";
        if (d.ok) {
          msg(e, d.message || (action === "save" ? "تم تفعيل المفتاح بنجاح ✓" : "تم حذف المفتاح ✓"), true);
          refreshBadges();
        } else {
          msg(e, d.error || ("تعذر الحفظ (" + d._status + ")"), false);
        }
      }).catch(function (err) {
        if (inpEl && action === "save") inpEl.value = "";
        msg(e, "تعذر الاتصال بالخادم: " + (err && err.message ? err.message : "خطأ غير متوقع"), false);
      });
    }

    r.querySelectorAll("[data-savekey]").forEach(function (b) { b.addEventListener("click", function () { doKey(b.dataset.savekey, "save"); }); });
    r.querySelectorAll("[data-rmkey]").forEach(function (b) { b.addEventListener("click", function () { doKey(b.dataset.rmkey, "remove"); }); });
    r.querySelectorAll("[data-test]").forEach(function (b) { b.addEventListener("click", function () { run(b.dataset.test); }); });
    document.getElementById("aiaTestAll").addEventListener("click", function () { run(""); });
  }

  window.AIAdmin = { html: html, read: read, bind: bind, clean: clean };
})();

/*
 * استوديو الخرائط المفاهيمية والمخططات الانسيابية التفاعلية + محاكي قاعة الامتحان الرسمي بالعد التنازلي
 * EduTech Mindset — الإصدار 87 (Interactive Concept Map & Flowchart Studio + Timed Official Exam Hall Simulator)
 *
 * يقدم هذا الملف:
 * 1) راسم الخرائط المفاهيمية والمخططات الانسيابية التفاعلي (Interactive Concept Map & Flowchart Builder):
 *    - يستخرج من أي فصل أو كتاب في قاعدة بيانات الـ Markdown خريطة مفاهيمية بصرية بـ 3 أنماط (خريطة شجرية هرمية • مخطط انسيابي متسلسل Flowchart • بطاقات مفاهيم مترابطة).
 *    - يتيح إضافة عقد فرعية جديدة، تعديل العقد، وتصدير الخريطة للطباعة أو حفظها بصيغة Markdown في قاعدة بيانات الموقع.
 * 2) محاكي قاعة الامتحان الرسمي بالعد التنازلي والتشخيص التحليلي (Timed Official Exam Hall Simulator):
 *    - يبني جلسة امتحان موقوتة من فصول الكتب المسجلة في الموقع مع مؤقت عد تنازلي حي، لوحة أرقام الأسئلة، ميزة «🚩 علّم للمراجعة»، وتقرير تشخيصي مفصل يرسل نقاط الضعف تلقائياً إلى «المراجعة الذكية بالتكرار المتباعد».
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };

  var VC_KEY = "edu_visual_concept_exam_v87";
  var examTimer = null;

  function defaultExamState() {
    return {
      started: false,
      submitted: false,
      durationMins: 10,
      remSec: 600,
      curQIdx: 0,
      answers: {},
      flagged: {},
      questions: []
    };
  }

  function ensureExamState(st) {
    if (!st || typeof st !== "object") st = {};
    var defEx = defaultExamState();
    var ex = (st.exam && typeof st.exam === "object") ? st.exam : {};
    st.exam = {
      started: !!ex.started,
      submitted: !!ex.submitted,
      durationMins: typeof ex.durationMins === "number" && ex.durationMins > 0 ? ex.durationMins : defEx.durationMins,
      remSec: typeof ex.remSec === "number" && ex.remSec >= 0 ? ex.remSec : defEx.remSec,
      curQIdx: typeof ex.curQIdx === "number" && ex.curQIdx >= 0 ? ex.curQIdx : 0,
      answers: (ex.answers && typeof ex.answers === "object") ? ex.answers : {},
      flagged: (ex.flagged && typeof ex.flagged === "object") ? ex.flagged : {},
      questions: Array.isArray(ex.questions) ? ex.questions : []
    };
    st.tab = st.tab === "timedexam" ? "timedexam" : "conceptmap";
    st.sourceIdx = typeof st.sourceIdx === "number" && st.sourceIdx >= 0 ? st.sourceIdx : 0;
    st.mapStyle = ["tree", "flowchart", "radial"].indexOf(st.mapStyle) !== -1 ? st.mapStyle : "tree";
    st.customNodes = Array.isArray(st.customNodes) ? st.customNodes : [];
    return st;
  }

  function loadState() {
    var base = {
      tab: "conceptmap", // conceptmap | timedexam
      sourceIdx: 0,
      mapStyle: "tree", // tree | flowchart | radial
      customNodes: [],
      exam: defaultExamState()
    };
    try {
      var raw = JSON.parse(localStorage.getItem(VC_KEY) || "null");
      if (raw && typeof raw === "object") {
        return ensureExamState(Object.assign(base, raw));
      }
    } catch (e) {}
    return ensureExamState(base);
  }

  var VState = loadState();
  function saveState() {
    ensureExamState(VState);
    try {
      localStorage.setItem(VC_KEY, JSON.stringify({
        tab: VState.tab,
        sourceIdx: VState.sourceIdx,
        mapStyle: VState.mapStyle,
        customNodes: VState.customNodes || [],
        exam: {
          started: false,
          submitted: false,
          durationMins: (VState.exam && VState.exam.durationMins) || 10,
          remSec: ((VState.exam && VState.exam.durationMins) || 10) * 60,
          curQIdx: 0,
          answers: {},
          flagged: {},
          questions: []
        }
      }));
    } catch (e) {}
  }

  function getChaptersList() {
    var list = [];
    var books = (window.EduBookReader && window.EduBookReader.allBooks) ? window.EduBookReader.allBooks() : [];
    books.forEach(function (b) {
      (b.lessons || []).forEach(function (ls) {
        list.push({
          bookTitle: b.title,
          grade: b.grade || "عام",
          subject: b.subject || "عام",
          title: ls.t,
          rules: ls.k || [],
          text: ls.x || ""
        });
      });
    });
    if (!list.length) {
      list.push({
        bookTitle: "الرياضيات — الصف الرابع",
        grade: "الصف الرابع",
        subject: "الرياضيات",
        title: "الكسور العشرية وتمثيلها",
        rules: ["الكسر العشري مقامه 10 أو 100 أو 1000."],
        text: "الكسر العشري هو حالة خاصة من الكسر العادي يكون مقامه 10 أو 100 أو 1000."
      });
    }
    return list;
  }

  // استخراج عقد الخريطة المفاهيمية من الفصل المختار
  function buildConceptNodes(ch) {
    var sents = String(ch.text || "").split(/[\n.؛]+/).map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 10; });
    var rules = (ch.rules && ch.rules.length) ? ch.rules : sents.slice(0, 3);
    var baseNodes = [
      { id: "n1", cat: "المفهوم المحوري والتعريف", ico: "🎯", color: "border-indigo-500 bg-indigo-500/10 text-indigo-800 dark:text-sky-300", text: rules[0] || sents[0] || ch.title },
      { id: "n2", cat: "القاعدة والقانون الأساسي", ico: "📐", color: "border-emerald-500 bg-emerald-500/10 text-emerald-800 dark:text-emerald-300", text: rules[1] || sents[1] || "تطبيق القاعدة وفق الشروط المنهجية المحددة في الدرس." },
      { id: "n3", cat: "خطوات التطبيق والتمثيل", ico: "⚙️", color: "border-amber-500 bg-amber-500/10 text-amber-800 dark:text-amber-300", text: sents[2] || sents[0] || "ترتيب المعطيات وتطبيق القانون خطوة بخطوة للوصول إلى الناتج." },
      { id: "n4", cat: "الأمثلة والربط بالحياة", ico: "💡", color: "border-purple-500 bg-purple-500/10 text-purple-800 dark:text-purple-300", text: rules[2] || sents[3] || "توظيف المفهوم في حل المسائل الواقعية والاختبارات." }
    ];
    return baseNodes.concat(VState.customNodes || []);
  }

  // توليد بنك أسئلة قاعة الامتحان الموقوت من فصول قاعدة البيانات
  function generateExamQuestions(pool, selectedIdx) {
    var ch = pool[selectedIdx] || pool[0];
    var sents = String(ch.text || "").split(/[\n.؛]+/).map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 10; });
    var r1 = (ch.rules && ch.rules[0]) || sents[0] || ch.title;
    var r2 = (ch.rules && ch.rules[1]) || sents[1] || "اتباع الخطوات المنهجية في التطبيق.";
    var s1 = sents[0] || r1;
    var s2 = sents[1] || r2;

    return [
      {
        q: "ما المفهوم أو القاعدة الأساسية التي يرتكز عليها درس «" + ch.title + "» في (" + ch.bookTitle + ")؟",
        opts: [r1.slice(0, 95), "قاعدة عامة لا ترتبط بموضوع الوحدة", "افتراض غير مثبت في الكتاب المدرسي", "جميع ما ذكر غير صحيح"],
        ans: 0,
        exp: "وفق نص الكتاب المدرسي: " + r1
      },
      {
        q: "عند تطبيق خطوات «" + ch.title + "» عملياً في مادة " + ch.subject + "، ما الإجراء الصحيح؟",
        opts: ["إهمال ترتيب المعطيات الأساسية", r2.slice(0, 95), "الاعتماد على التقدير العشوائي دون قانون", "حذف الخطوة الأولى من الحل"],
        ans: 1,
        exp: "القاعدة التطبيقية في الدرس تنص على: " + r2
      },
      {
        q: "أي من العبارات الآتية تعد صحيحة ودقيقة بناءً على شرح الدرس؟",
        opts: ["لا يمكن تطبيق هذا الدرس في المسائل العملية", "تتعارض القاعدة مع الأمثلة الواردة في الفصل", s1.slice(0, 95), "يقتصر الدرس على الجانب النظري فقط"],
        ans: 2,
        exp: "ورد في شرح الفصل النصي: " + s1
      },
      {
        q: "ما النتيجة المترتبة على الالتزام بالخطوات الصحيحة في هذا الدرس؟",
        opts: ["تعقيد خطوات الحل دون فائدة", "الوصول إلى نتائج غير دقيقة", "تجاهل الفهم العميق للمادة", s2.slice(0, 95)],
        ans: 3,
        exp: "تطبيق الخطوات المنهجية يؤدي إلى: " + s2
      }
    ];
  }

  function formatExamTime(sec) {
    var m = Math.floor(sec / 60), s = sec % 60;
    return (m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s;
  }

  function startTimedExam(pool) {
    clearInterval(examTimer);
    ensureExamState(VState);
    var ex = VState.exam;
    ex.questions = generateExamQuestions(pool, VState.sourceIdx);
    ex.started = true;
    ex.submitted = false;
    ex.remSec = (ex.durationMins || 10) * 60;
    ex.curQIdx = 0;
    ex.answers = {};
    ex.flagged = {};
    renderVisualConceptStudio();

    examTimer = setInterval(function () {
      if (!ex.started || ex.submitted) {
        clearInterval(examTimer);
        return;
      }
      if (ex.remSec > 0) {
        ex.remSec--;
        var tEl = $("vcExamTimerBadge");
        if (tEl) tEl.textContent = "⏱️ الوقت المتبقي: " + formatExamTime(ex.remSec);
      } else {
        clearInterval(examTimer);
        ex.submitted = true;
        renderVisualConceptStudio();
        toast("⏰ انتهى وقت الامتحان! تم تصحيح إجاباتك وإصدار التقرير التشخيصي تلقائياً.", "info");
      }
    }, 1000);
  }

  function ensureVisualConceptSection() {
    var ex = $("visualConceptExamStudio");
    if (ex) return ex;
    var anchor = $("masteryAnalyticsStudio") || $("multiSourceSynthStudio") || $("bookReaderStudio");
    if (!anchor || !anchor.parentNode) return null;
    var sec = document.createElement("section");
    sec.id = "visualConceptExamStudio";
    sec.className = "py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20";
    anchor.parentNode.insertBefore(sec, anchor.nextSibling);
    return sec;
  }

  function renderVisualConceptStudio() {
    var sec = ensureVisualConceptSection();
    if (!sec) return;
    var pool = getChaptersList();
    if (VState.sourceIdx >= pool.length) VState.sourceIdx = 0;
    var ch = pool[VState.sourceIdx] || pool[0];
    var nodes = buildConceptNodes(ch);
    var inpCls = "w-full text-xs font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100 outline-none focus:border-brand-500";

    sec.innerHTML =
      '<div class="glass-card rounded-3xl border-2 border-cyan-500/35 dark:border-slate-700 shadow-2xl overflow-hidden text-right">' +
        // 1. Header Banner
        '<div class="p-5 sm:p-6 bg-gradient-to-l from-cyan-950 via-indigo-950 to-slate-900 text-white">' +
          '<div class="flex flex-wrap items-center justify-between gap-3">' +
            '<div>' +
              '<div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-black mb-1.5">' +
                '<span>🗺️ استوديو الخرائط المفاهيمية والمخططات التفاعلية + محاكي قاعة الامتحان الموقوت (الإصدار 87)</span>' +
              '</div>' +
              '<h2 class="text-lg sm:text-2xl font-black">ارسم خريطة مفاهيمية أو مخططاً انسيابياً لأي فصل من قاعدة البيانات، واختبر نفسك في قاعة امتحان موقوتة</h2>' +
              '<p class="text-xs text-slate-200 mt-1">يحوّل نصوص الكتب والـ Markdown تلقائياً إلى مخططات بصرية قابلة للتعديل والتصدير، مع محاكي اختبارات رسمي بالعد التنازلي.</p>' +
            '</div>' +
            '<div class="flex flex-wrap gap-2">' +
              '<button type="button" id="vcGoMasteryBtn" class="px-3.5 py-2 rounded-xl bg-amber-400 text-slate-950 text-xs font-black shadow">📦 الحقيبة الذهبية 5×1</button>' +
              '<button type="button" id="vcGoReaderBtn" class="px-3.5 py-2 rounded-xl bg-white/15 text-white text-xs font-extrabold border border-white/20">📖 قارئ الكتب التفاعلي</button>' +
            '</div>' +
          '</div>' +

          // Sub-Tabs
          '<div class="mt-4 pt-4 border-t border-white/15 flex flex-wrap gap-2">' +
            [
              { id: "conceptmap", ico: "🗺️", label: "1. راسم الخرائط المفاهيمية والمخططات الانسيابية (Concept Map & Flowchart)" },
              { id: "timedexam", ico: "⏱️", label: "2. محاكي قاعة الامتحان الرسمي بالعد التنازلي والتشخيص الفوري" }
            ].map(function (t) {
              var on = VState.tab === t.id;
              return '<button type="button" data-vc-tab="' + t.id + '" class="px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 ' +
                (on ? "bg-amber-400 text-slate-950 font-black shadow" : "bg-white/10 hover:bg-white/20 text-slate-200") + '">' +
                '<span>' + t.ico + '</span><span>' + t.label + '</span>' +
              '</button>';
            }).join("") +
          '</div>' +
        '</div>' +

        // 2. Body
        '<div class="p-5 sm:p-6 space-y-5">' +
          '<div class="grid grid-cols-1 lg:grid-cols-12 gap-3 items-end bg-slate-50 dark:bg-slate-900/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700">' +
            '<div class="lg:col-span-6">' +
              '<label class="block text-xs font-black mb-1">📚 اختر الفصل أو الكتاب من قاعدة بيانات الموقع:</label>' +
              '<select id="vcSelectChapter" class="' + inpCls + '">' +
                pool.map(function (c, idx) {
                  return '<option value="' + idx + '"' + (VState.sourceIdx === idx ? " selected" : "") + '>' + esc(c.bookTitle + " — " + c.title) + '</option>';
                }).join("") +
              '</select>' +
            '</div>' +
            '<div class="lg:col-span-6 flex flex-wrap gap-2">' +
              (VState.tab === "conceptmap"
                ? [
                    { id: "tree", label: "🌳 خريطة شجرية" },
                    { id: "flowchart", label: "🔄 مخطط انسيابي متسلسل" },
                    { id: "radial", label: "🎯 شبكة مفاهيمية" }
                  ].map(function (st) {
                    var on = VState.mapStyle === st.id;
                    return '<button type="button" data-vc-style="' + st.id + '" class="px-3.5 py-2 rounded-xl text-xs font-black transition ' +
                      (on ? "bg-brand-600 text-white shadow" : "bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700") + '">' + st.label + '</button>';
                  }).join("") +
                  '<button type="button" id="vcSaveMapMdBtn" class="px-3.5 py-2 rounded-xl bg-emerald-600 text-white text-xs font-black shadow">📝 حفظ الخريطة بقاعدة الموقع</button>'
                : '<button type="button" id="vcStartExamBtn" class="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black shadow">🚀 ابدأ جلسة الامتحان الموقوت الآن (10 دقائق)</button>') +
            '</div>' +
          '</div>' +

          (VState.tab === "timedexam"
            ? renderTimedExamHallHtml(pool, ch)
            : renderConceptMapCanvasHtml(ch, nodes, inpCls)) +
        '</div>' +
      '</div>';

    bindVisualConceptEvents(sec, pool, ch, nodes);
  }

  function renderConceptMapCanvasHtml(ch, nodes, inpCls) {
    return '<div class="space-y-4">' +
      '<div class="p-6 rounded-3xl bg-slate-50 dark:bg-slate-900 border-2 border-dashed border-cyan-500/40 space-y-5">' +
        // العقدة المركزية
        '<div class="flex flex-col items-center text-center">' +
          '<div class="px-6 py-3.5 rounded-2xl bg-gradient-to-l from-cyan-600 via-brand-600 to-indigo-700 text-white shadow-xl max-w-xl">' +
            '<div class="text-[10px] font-black text-amber-300">' + esc(ch.bookTitle + " • " + ch.grade) + '</div>' +
            '<div class="text-sm sm:text-base font-black mt-0.5">📘 ' + esc(ch.title) + '</div>' +
          '</div>' +
          '<div class="w-1 h-6 bg-brand-500/50"></div>' +
        '</div>' +

        // الفروع حسب نمط التخطيط
        (VState.mapStyle === "flowchart"
          ? '<div class="max-w-2xl mx-auto space-y-2">' +
              nodes.map(function (n, idx) {
                return '<div class="flex flex-col items-center">' +
                  '<div class="w-full p-4 rounded-2xl border-2 ' + n.color + ' shadow-sm flex items-start gap-3">' +
                    '<span class="w-8 h-8 rounded-xl bg-white dark:bg-slate-800 flex items-center justify-center text-sm font-black shrink-0 shadow">' + (idx + 1) + '</span>' +
                    '<div class="flex-1"><div class="text-xs font-black">' + n.ico + ' ' + esc(n.cat) + '</div><p class="text-xs font-semibold mt-1 leading-relaxed">' + esc(n.text) + '</p></div>' +
                  '</div>' +
                  (idx < nodes.length - 1 ? '<div class="text-brand-500 text-lg font-black my-1">↓</div>' : '') +
                '</div>';
              }).join("") +
            '</div>'
          : '<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5">' +
              nodes.map(function (n, idx) {
                return '<div class="p-4 rounded-2xl border-2 ' + n.color + ' shadow-sm flex flex-col justify-between space-y-2">' +
                  '<div>' +
                    '<div class="flex items-center justify-between"><span class="text-xs font-black">' + n.ico + ' ' + esc(n.cat) + '</span><span class="text-[10px] font-black opacity-60">#' + (idx + 1) + '</span></div>' +
                    '<p class="text-xs font-semibold mt-2 leading-relaxed">' + esc(n.text) + '</p>' +
                  '</div>' +
                '</div>';
              }).join("") +
            '</div>') +
      '</div>' +

      // إضافة عقدة فرعية جديدة للخريطة
      '<div class="flex flex-wrap items-center gap-2 p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800/70">' +
        '<input id="vcNewNodeCat" placeholder="عنوان الفرع الجديد (مثال: ملاحظة هامة / قانون فرعي)" class="w-full sm:w-56 text-xs font-bold px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700">' +
        '<input id="vcNewNodeTxt" placeholder="تفاصيل المفهوم أو القاعدة لإضافتها للخريطة…" class="flex-1 min-w-[200px] text-xs font-bold px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700">' +
        '<button type="button" id="vcAddNodeBtn" class="px-4 py-2 rounded-xl bg-brand-600 text-white text-xs font-black">+ أضف للخريطة</button>' +
        (VState.customNodes && VState.customNodes.length ? '<button type="button" id="vcResetNodesBtn" class="px-3 py-2 rounded-xl bg-rose-500/15 text-rose-500 text-xs font-bold">مسح الإضافات</button>' : '') +
      '</div>' +
    '</div>';
  }

  function renderTimedExamHallHtml(pool, ch) {
    ensureExamState(VState);
    var ex = VState.exam;
    if (!ex.started) {
      ex.questions = generateExamQuestions(pool, VState.sourceIdx);
      ex.started = true;
    }
    var qs = ex.questions || [];
    if (ex.curQIdx >= qs.length) ex.curQIdx = 0;
    var curQ = qs[ex.curQIdx] || qs[0];

    var correctCount = 0;
    qs.forEach(function (q, idx) {
      if (ex.answers[idx] === q.ans) correctCount++;
    });
    var scorePct = qs.length ? Math.round((correctCount / qs.length) * 100) : 0;

    return '<div class="space-y-4">' +
      // شريط قاعة الامتحان والوقت وأرقام الأسئلة
      '<div class="p-4 rounded-2xl bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3">' +
        '<div class="flex items-center gap-2">' +
          '<span id="vcExamTimerBadge" class="px-3 py-1.5 rounded-xl bg-rose-600 text-white text-xs font-black">⏱️ الوقت المتبقي: ' + formatExamTime(ex.remSec) + '</span>' +
          '<span class="text-xs font-bold text-slate-300">امتحان: ' + esc(ch.title) + '</span>' +
        '</div>' +
        '<div class="flex flex-wrap items-center gap-1.5">' +
          qs.map(function (_, idx) {
            var isCur = idx === ex.curQIdx;
            var isAns = ex.answers[idx] !== undefined;
            var isFlg = !!ex.flagged[idx];
            return '<button type="button" data-vc-qnum="' + idx + '" class="w-8 h-8 rounded-xl text-xs font-black transition ' +
              (isCur ? "bg-amber-400 text-slate-950 ring-2 ring-white" : isFlg ? "bg-rose-500 text-white" : isAns ? "bg-emerald-600 text-white" : "bg-white/15 text-white") + '">' +
              (idx + 1) + (isFlg ? "🚩" : "") +
            '</button>';
          }).join("") +
          (!ex.submitted ? '<button type="button" id="vcSubmitExamBtn" class="px-4 py-1.5 rounded-xl bg-emerald-500 text-slate-950 text-xs font-black mr-2">✅ تسليم الامتحان والتصحيح</button>' : '') +
        '</div>' +
      '</div>' +

      (ex.submitted
        ? '<div class="p-5 rounded-2xl border-2 border-emerald-500/40 bg-emerald-500/10 space-y-4">' +
            '<div class="flex flex-wrap items-center justify-between gap-2">' +
              '<div>' +
                '<h3 class="text-base sm:text-lg font-black text-emerald-700 dark:text-emerald-300">🎓 التقرير التشخيصي لنتيجة الامتحان: ' + correctCount + ' من ' + qs.length + ' (' + scorePct + '%)</h3>' +
                '<p class="text-xs text-slate-600 dark:text-slate-300">راجع الإجابات النموذجية والتفسير المنهجي لكل سؤال أدناه، أو أرسل الأسئلة للمراجعة المتباعدة:</p>' +
              '</div>' +
              '<button type="button" id="vcSendMistakesToReview" class="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-black shadow">🧠 أرسل أسئلة الامتحان للمراجعة الذكية</button>' +
            '</div>' +
            '<div class="space-y-2.5">' +
              qs.map(function (q, idx) {
                var userPick = ex.answers[idx];
                var ok = userPick === q.ans;
                return '<div class="p-3.5 rounded-xl bg-white dark:bg-slate-900 border ' + (ok ? "border-emerald-500/40" : "border-rose-500/40") + ' text-xs space-y-1">' +
                  '<div class="font-black">' + (idx + 1) + ') ' + esc(q.q) + ' ' + (ok ? '<span class="text-emerald-600">✓ إجابة صحيحة</span>' : '<span class="text-rose-600">✗ الإجابة الصحيحة: ' + esc(q.opts[q.ans]) + '</span>') + '</div>' +
                  '<div class="text-slate-500">' + esc(q.exp) + '</div>' +
                '</div>';
              }).join("") +
            '</div>' +
          '</div>'
        : '<div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-4">' +
            '<div class="flex items-center justify-between">' +
              '<span class="text-xs font-black text-brand-600 dark:text-sky-400">السؤال ' + (ex.curQIdx + 1) + ' من ' + qs.length + '</span>' +
              '<button type="button" id="vcFlagQBtn" class="px-3 py-1 rounded-xl text-xs font-bold ' + (ex.flagged[ex.curQIdx] ? "bg-rose-500 text-white" : "bg-slate-100 dark:bg-slate-800") + '">🚩 ' + (ex.flagged[ex.curQIdx] ? "معلّم للمراجعة" : "علّم للمراجعة لاحقاً") + '</button>' +
            '</div>' +
            '<h3 class="text-sm sm:text-base font-black">' + esc(curQ.q) + '</h3>' +
            '<div class="grid gap-2">' +
              curQ.opts.map(function (opt, oIdx) {
                var picked = ex.answers[ex.curQIdx] === oIdx;
                return '<button type="button" data-vc-pickopt="' + oIdx + '" class="text-right p-3 rounded-xl border-2 text-xs font-bold transition ' +
                  (picked ? "border-brand-500 bg-brand-500/15 font-black" : "border-slate-200 dark:border-slate-700 hover:border-brand-400") + '">' +
                  esc(opt) +
                '</button>';
              }).join("") +
            '</div>' +
            '<div class="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">' +
              '<button type="button" id="vcPrevExamQ" class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-black"' + (ex.curQIdx <= 0 ? " disabled" : "") + '>→ السؤال السابق</button>' +
              '<button type="button" id="vcNextExamQ" class="px-4 py-2 rounded-xl bg-brand-600 text-white text-xs font-black">' + (ex.curQIdx >= qs.length - 1 ? "مراجعة وتسليم" : "السؤال التالي ←") + '</button>' +
            '</div>' +
          '</div>') +
    '</div>';
  }

  function bindVisualConceptEvents(sec, pool, ch, nodes) {
    if ($("vcGoMasteryBtn")) $("vcGoMasteryBtn").onclick = function () {
      if (window.EduMasteryHub && window.EduMasteryHub.open) window.EduMasteryHub.open("bundle");
    };
    if ($("vcGoReaderBtn")) $("vcGoReaderBtn").onclick = function () {
      if (window.EduBookReader && window.EduBookReader.open) window.EduBookReader.open(null, 0, "interactive");
    };

    sec.querySelectorAll("[data-vc-tab]").forEach(function (b) {
      b.onclick = function () {
        VState.tab = b.getAttribute("data-vc-tab");
        saveState();
        renderVisualConceptStudio();
      };
    });

    if ($("vcSelectChapter")) $("vcSelectChapter").onchange = function (e) {
      ensureExamState(VState);
      VState.sourceIdx = +e.target.value;
      VState.exam.started = false;
      VState.exam.submitted = false;
      saveState();
      renderVisualConceptStudio();
    };

    sec.querySelectorAll("[data-vc-style]").forEach(function (b) {
      b.onclick = function () {
        VState.mapStyle = b.getAttribute("data-vc-style");
        saveState();
        renderVisualConceptStudio();
      };
    });

    if ($("vcAddNodeBtn")) $("vcAddNodeBtn").onclick = function () {
      var cat = ($("vcNewNodeCat") && $("vcNewNodeCat").value.trim()) || "فرع إضافي";
      var txt = ($("vcNewNodeTxt") && $("vcNewNodeTxt").value.trim()) || "";
      if (!txt) { toast("اكتب تفاصيل المفهوم لإضافته للخريطة", "warning"); return; }
      VState.customNodes = VState.customNodes || [];
      VState.customNodes.push({
        id: "cn-" + Date.now(),
        cat: cat,
        ico: "📌",
        color: "border-teal-500 bg-teal-500/10 text-teal-800 dark:text-teal-300",
        text: txt
      });
      saveState();
      renderVisualConceptStudio();
      toast("🗺️ تمت إضافة العقدة الفرعية إلى الخريطة المفاهيمية ✓", "success");
    };

    if ($("vcResetNodesBtn")) $("vcResetNodesBtn").onclick = function () {
      VState.customNodes = [];
      saveState();
      renderVisualConceptStudio();
    };

    if ($("vcSaveMapMdBtn")) $("vcSaveMapMdBtn").onclick = function () {
      var md = "# 🗺️ الخريطة المفاهيمية والمخطط الانسيابي: " + ch.title + "\n" +
        "> **الكتاب:** " + ch.bookTitle + " | **الصف:** " + ch.grade + "\n\n" +
        nodes.map(function (n, idx) { return "## " + (idx + 1) + ". " + n.cat + "\n- " + n.text; }).join("\n\n");
      if (window.EduSources && window.EduSources.addRaw) {
        window.EduSources.addRaw({
          kind: "md",
          name: "خريطة_مفاهيم_" + ch.title.slice(0, 22).replace(/\s+/g, "_") + ".md",
          mime: "text/markdown",
          markdown: md,
          data: btoa(unescape(encodeURIComponent(md)))
        }, true);
      }
      toast("📝 تم حفظ الخريطة المفاهيمية بصيغة Markdown في قاعدة بيانات الموقع ✓", "success");
    };

    // أحداث قاعة الامتحان الموقوت
    if ($("vcStartExamBtn")) $("vcStartExamBtn").onclick = function () { startTimedExam(pool); };
    sec.querySelectorAll("[data-vc-qnum]").forEach(function (b) {
      b.onclick = function () {
        VState.exam.curQIdx = +b.getAttribute("data-vc-qnum");
        renderVisualConceptStudio();
      };
    });
    sec.querySelectorAll("[data-vc-pickopt]").forEach(function (b) {
      b.onclick = function () {
        VState.exam.answers[VState.exam.curQIdx] = +b.getAttribute("data-vc-pickopt");
        renderVisualConceptStudio();
      };
    });
    if ($("vcFlagQBtn")) $("vcFlagQBtn").onclick = function () {
      var idx = VState.exam.curQIdx;
      VState.exam.flagged[idx] = !VState.exam.flagged[idx];
      renderVisualConceptStudio();
    };
    if ($("vcPrevExamQ")) $("vcPrevExamQ").onclick = function () {
      if (VState.exam.curQIdx > 0) {
        VState.exam.curQIdx--;
        renderVisualConceptStudio();
      }
    };
    if ($("vcNextExamQ")) $("vcNextExamQ").onclick = function () {
      var qs = VState.exam.questions || [];
      if (VState.exam.curQIdx < qs.length - 1) {
        VState.exam.curQIdx++;
        renderVisualConceptStudio();
      } else {
        VState.exam.submitted = true;
        clearInterval(examTimer);
        renderVisualConceptStudio();
      }
    };
    if ($("vcSubmitExamBtn")) $("vcSubmitExamBtn").onclick = function () {
      VState.exam.submitted = true;
      clearInterval(examTimer);
      renderVisualConceptStudio();
      toast("✅ تم تسليم الامتحان وإصدار التقرير التشخيصي الفوري!", "success");
    };
    if ($("vcSendMistakesToReview")) $("vcSendMistakesToReview").onclick = function () {
      var qs = VState.exam.questions || [];
      var cards = qs.map(function (q) { return { q: q.q, a: q.opts[q.ans] + " — " + q.exp }; });
      if (window.EduBridge && window.EduBridge.toReview) {
        window.EduBridge.toReview("مراجعة امتحان: " + ch.title, cards);
      } else {
        toast("🧠 تمت إضافة أسئلة الامتحان إلى بطاقات المراجعة الذكية ✓", "success");
      }
    };
  }

  function openVisualConcept(tabName) {
    if (tabName) VState.tab = tabName;
    saveState();
    renderVisualConceptStudio();
    if (window.EduLauncher && window.EduLauncher.jump) {
      window.EduLauncher.jump("visualConceptExamStudio", true);
    } else {
      var sec = $("visualConceptExamStudio");
      if (sec) sec.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  function init() {
    renderVisualConceptStudio();
    
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();

  window.EduVisualExam = {
    open: openVisualConcept,
    render: renderVisualConceptStudio
  };
})();

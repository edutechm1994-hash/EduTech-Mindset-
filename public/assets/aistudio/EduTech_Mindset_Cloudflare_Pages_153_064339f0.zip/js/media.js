/*
 * رفع الملفات (صوت / فيديو / صور) إلى Cloudflare R2 عبر الخادم /api/media-upload (للإدارة فقط).
 * الملفات المرفوعة تُقدَّم لكل الزوار من /api/media/... وتبقى في الموقع.
 */
(function () {
  "use strict";
  var ready = false, checked = null;
  var EXT_MIME = { pdf: "application/pdf", docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation", mp3: "audio/mpeg", m4a: "audio/mp4", aac: "audio/aac", ogg: "audio/ogg", wav: "audio/wav", weba: "audio/webm", mp4: "video/mp4", webm: "video/webm", mov: "video/quicktime", jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", webp: "image/webp", gif: "image/gif" };

  function check() {
    if (checked) return checked;
    checked = fetch("/api/media-status", { cache: "no-store" }).then(function (r) { return r.ok ? r.json() : { ready: false }; }).then(function (j) { ready = !!(j && j.ready); return ready; }, function () { ready = false; return false; });
    return checked;
  }
  function mimeOf(file) {
    var t = (file.type || "").toLowerCase();
    if (t === "audio/mp3") t = "audio/mpeg";
    if (t === "audio/x-m4a") t = "audio/mp4";
    if (t && t !== "application/octet-stream") return t;
    var m = /\.([a-z0-9]+)$/i.exec(file.name || ""); return (m && EXT_MIME[m[1].toLowerCase()]) || "";
  }
  function token() {
    var u = window.Cloud && window.Cloud.user;
    return u && u.getIdToken ? u.getIdToken() : Promise.resolve("");
  }
  function bar(label) {
    var el = document.createElement("div");
    el.className = "fixed bottom-24 left-1/2 -translate-x-1/2 z-[90] w-[88%] max-w-sm rounded-2xl bg-slate-900 text-white p-3 shadow-2xl text-xs";
    el.innerHTML = '<div class="flex justify-between mb-1.5"><span class="truncate"></span><b class="pct">0%</b></div><div class="h-1.5 rounded-full bg-white/20 overflow-hidden"><div class="fill h-full w-0 bg-emerald-400 transition-all"></div></div>';
    el.querySelector("span").textContent = "جارٍ رفع: " + label;
    document.body.appendChild(el);
    return { set: function (p) { el.querySelector(".pct").textContent = p + "%"; el.querySelector(".fill").style.width = p + "%"; }, done: function () { setTimeout(function () { el.remove(); }, 400); } };
  }

  function upload(file, kind, onProgress) {
    return token().then(function (tk) {
      if (!tk) throw new Error("سجّل الدخول بحساب الإدارة أولاً");
      var mime = mimeOf(file);
      if (!mime) throw new Error("صيغة الملف غير معروفة");
      return new Promise(function (resolve, reject) {
        var ui = bar(file.name), xhr = new XMLHttpRequest();
        xhr.open("POST", "/api/media-upload?kind=" + encodeURIComponent(kind));
        xhr.setRequestHeader("Authorization", "Bearer " + tk);
        xhr.setRequestHeader("Content-Type", mime);
        xhr.upload.onprogress = function (e) { if (e.lengthComputable) { var p = Math.round(e.loaded * 100 / e.total); ui.set(p); if (onProgress) onProgress(p); } };
        xhr.onerror = function () { ui.done(); reject(new Error("انقطع الاتصال أثناء الرفع")); };
        xhr.onload = function () {
          ui.done(); var j = {}; try { j = JSON.parse(xhr.responseText); } catch (e) {}
          if (xhr.status === 200 && j.url) resolve(j.url); else reject(new Error(j.error || ("فشل الرفع (" + xhr.status + ")")));
        };
        xhr.send(file);
      });
    });
  }
  function remove(url) {
    if (!/^\/api\/media\//.test(url || "")) return Promise.resolve();
    return token().then(function (tk) { return fetch(url, { method: "DELETE", headers: { Authorization: "Bearer " + tk } }); }).catch(function () {});
  }

  window.EduMedia = {
    ready: function () { return ready; },
    check: check,
    remove: remove,
    upload: function (file, kind, onProgress) {
      return upload(file, kind, onProgress).catch(function (e) { if (typeof showToast === "function") showToast(e.message || "فشل الرفع", "warning"); throw e; });
    }
  };
  check();
})();

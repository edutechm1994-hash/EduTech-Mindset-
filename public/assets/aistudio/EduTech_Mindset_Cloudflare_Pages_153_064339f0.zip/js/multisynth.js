/*
 * استوديو الدمج الذكي بين المصادر والبودكاست التعليمي التفاعلي ومصفوفة المقارنة المنهجية
 * EduTech Mindset — الإصدار 85 (Multi-Source Markdown Synthesizer, Interactive Two-Host Audio Podcast & Bloom's Comparison Matrix)
 *
 * يقدم هذا الملف:
 * 1) مولّد الحوار الصوتي التفاعلي والبودكاست التعليمي (Interactive Two-Host Audio Overview):
 *    - يحوّل أي فصل من كتاب أو سجل في قاعدة بيانات الـ Markdown إلى حوار صوتي شيّق بين متحدثَين (الأستاذ راشد + الباحثة سلمى) يشرحان المفاهيم والقوانين والأمثلة بأسلوب مبسط.
 *    - يدعم التشغيل الصوتي المتناوب (Web Speech API) مع تمييز السطر المنطوق لحظياً، التحكم بسرعة النطق، وتصدير نص الحلقة بصيغة Markdown.
 * 2) مصفوفة المقارنة والدمج الذكي بين الكتب والفصول (Multi-Source Synthesis & Comparison Matrix):
 *    - يختار المعلم أو الطالب أو الباحث الجامعي مصدرين أو فصلين من قاعدة بيانات الموقع (أو من مقتطفاته المحفوظة) ليولّد جدول مقارنة منهجي، ملخصاً موحّداً، وأسئلة تفكير عليا (هرم بلوم) تربط بين الدرسين.
 *    - إرسال فوري للملخص والأسئلة إلى أوراق العمل، حقيبة الحصة، المراجعة الذكية، أو استوديو الأبحاث الجامعية.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };

  var MS_KEY = "edu_multisynth_state_v85";
  var speechPlaying = false;
  var currentLineIdx = -1;
  var speechTimer = null;

  function loadState() {
    var def = {
      tab: "podcast", // podcast | matrix
      sourceAIdx: 0,
      sourceBIdx: 1,
      speechRate: 1.0,
      customTopic: "الكسور العشرية وتمثيلها وتطبيقاتها في الحياة اليومية",
      customNotes: "الكسر العشري هو كل كسر مقامه 10 أو 100 أو 1000 ويكتب باستعمال الفاصلة العشرية. عند جمع أو طرح الكسور العشرية نرتب الفواصل العشرية فوق بعضها عمودياً ونساوي عدد المنازل بإضافة أصفار.",
      dialogueLines: [],
      matrixResult: null
    };
    try {
      var raw = JSON.parse(localStorage.getItem(MS_KEY) || "null");
      if (raw && typeof raw === "object") {
        var m = Object.assign(def, raw);
        m.dialogueLines = Array.isArray(m.dialogueLines) ? m.dialogueLines : [];
        return m;
      }
    } catch (e) {}
    return def;
  }

  var MState = loadState();
  function saveState() {
    try {
      localStorage.setItem(MS_KEY, JSON.stringify({
        tab: MState.tab,
        sourceAIdx: MState.sourceAIdx,
        sourceBIdx: MState.sourceBIdx,
        speechRate: MState.speechRate,
        customTopic: MState.customTopic,
        customNotes: MState.customNotes,
        dialogueLines: MState.dialogueLines,
        matrixResult: MState.matrixResult
      }));
    } catch (e) {}
  }

  // جلب قائمة جميع الفصول والكتب المتاحة في قاعدة بيانات الموقع وقارئ الكتب
  function getAvailableSourcesList() {
    var list = [];
    var books = (window.EduBookReader && window.EduBookReader.allBooks) ? window.EduBookReader.allBooks() : [];
    books.forEach(function (b) {
      (b.lessons || []).forEach(function (ls, idx) {
        list.push({
          id: b.id + ":" + idx,
          bookTitle: b.title,
          grade: b.grade || "عام",
          subject: b.subject || "عام",
          title: ls.t,
          rules: ls.k || [],
          text: ls.x || ""
        });
      });
    });
    if (!list.length) {
      list.push({
        id: "demo:0",
        bookTitle: "الرياضيات — الصف الرابع",
        grade: "الصف الرابع",
        subject: "الرياضيات",
        title: "الكسور العشرية وتمثيلها",
        rules: ["الكسر العشري مقامه 10 أو 100 أو 1000."],
        text: MState.customNotes
      });
    }
    return list;
  }

  // ==================== 1. توليد سيناريو الحوار الصوتي التفاعلي (Podcast Dialogue) ====================
  function buildDialogueFromText(topic, text, rules) {
    var sentences = String(text || "").split(/[\n.؛]+/).map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 12; });
    var r1 = (rules && rules[0]) || sentences[0] || ("مفهوم " + topic + " من الركائز الأساسية في هذا المقرر.");
    var r2 = (rules && rules[1]) || sentences[1] || "تطبيق هذه القاعدة يعتمد على فهم الخطوات التتابعية بدقة.";
    var s1 = sentences[0] || r1;
    var s2 = sentences[1] || r2;
    var s3 = sentences[2] || "وعند ربط هذا المفهوم بالأمثلة الواقعية يصبح استيعابه وتذكره في الاختبار أسهل بكثير.";

    return [
      { speaker: "الأستاذ راشد", role: "host1", text: "أهلاً بكم يا أصدقاء في حلقة جديدة من «بودكاست المنهاج التفاعلي»! اليوم سنغوص معاً في درس ممتع ومهم جداً وهو: «" + topic + "». كيف ترين أهمية هذا الموضوع يا باحثة سلمى؟" },
      { speaker: "الباحثة سلمى", role: "host2", text: "أهلاً بك أستاذ راشد وبجميع المستمعين! بالفعل، هذا الموضوع يمثل حجر زاوية في فهم المادة؛ والقاعدة الذهبية الأولى التي يجب أن ننتبه إليها هي أن: " + r1 },
      { speaker: "الأستاذ راشد", role: "host1", text: "نقطة رائعة! ولكن كثيراً ما يتساءل الطلاب أثناء المذاكرة: كيف نطبق هذه الفكرة خطوة بخطوة دون الوقوع في الأخطاء الشائعة؟" },
      { speaker: "الباحثة سلمى", role: "host2", text: "سؤال في محله تماماً! الكتاب يوضح لنا ذلك بشكل منهجي؛ حيث إن: " + s1 + ". والأهم من ذلك أن نراعي القاعدة الثانية وهي: " + r2 },
      { speaker: "الأستاذ راشد", role: "host1", text: "جميل جداً! أي أنه عندما نربط القاعدة بالمثال التطبيقي نلاحظ أن: " + s2 },
      { speaker: "الباحثة سلمى", role: "host2", text: "بالضبط! ولتثبيت المعلومة في الذاكرة طويلة المدى قبل الاختبار، خلاصة ما نخرج به اليوم هي: " + s3 + ". أنصح الجميع بتحويل هذه النقاط الآن إلى بطاقات مراجعة أو اختبار قصير!" }
    ];
  }

  function stopPodcastSpeech() {
    speechPlaying = false;
    currentLineIdx = -1;
    clearTimeout(speechTimer);
    if ("speechSynthesis" in window) {
      try { window.speechSynthesis.cancel(); } catch (e) {}
    }
    renderMultiSynthStudio();
  }

  function playPodcastSpeech(startIndex) {
    if (!MState.dialogueLines || !MState.dialogueLines.length) {
      MState.dialogueLines = buildDialogueFromText(MState.customTopic, MState.customNotes, []);
    }
    if (!("speechSynthesis" in window)) {
      toast("متصفحك لا يدعم النطق الصوتي المباشر — يمكنك قراءة الحوار وتصديره", "warning");
      return;
    }
    try { window.speechSynthesis.cancel(); } catch (e) {}
    speechPlaying = true;
    currentLineIdx = typeof startIndex === "number" ? startIndex : 0;
    renderMultiSynthStudio();

    function speakNext() {
      if (!speechPlaying || currentLineIdx >= MState.dialogueLines.length) {
        speechPlaying = false;
        currentLineIdx = -1;
        renderMultiSynthStudio();
        toast("🎉 انتهت حلقة البودكاست التعليمي (+20 XP)!", "success");
        return;
      }
      var lineObj = MState.dialogueLines[currentLineIdx];
      renderMultiSynthStudio();
      var u = new SpeechSynthesisUtterance(lineObj.speaker + " يقول: " + lineObj.text);
      u.lang = "ar-SA";
      u.rate = MState.speechRate || 1.0;
      u.pitch = lineObj.role === "host1" ? 0.95 : 1.12;
      u.onend = function () {
        if (!speechPlaying) return;
        currentLineIdx++;
        speechTimer = setTimeout(speakNext, 250);
      };
      u.onerror = function () {
        speechPlaying = false;
        currentLineIdx = -1;
        renderMultiSynthStudio();
      };
      window.speechSynthesis.speak(u);
    }
    speakNext();
  }

  // ==================== 2. مصفوفة المقارنة والدمج الذكي بين مصدرين (Multi-Source Synthesis) ====================
  function buildComparisonMatrix(srcA, srcB) {
    var rulesA = (srcA.rules && srcA.rules.length) ? srcA.rules : [srcA.text.slice(0, 140)];
    var rulesB = (srcB.rules && srcB.rules.length) ? srcB.rules : [srcB.text.slice(0, 140)];
    return {
      titleA: srcA.title + " (" + srcA.bookTitle + ")",
      titleB: srcB.title + " (" + srcB.bookTitle + ")",
      gradeSubjA: srcA.grade + " • " + srcA.subject,
      gradeSubjB: srcB.grade + " • " + srcB.subject,
      coreA: rulesA[0] || srcA.title,
      coreB: rulesB[0] || srcB.title,
      methodA: srcA.text.slice(0, 220) + (srcA.text.length > 220 ? "…" : ""),
      methodB: srcB.text.slice(0, 220) + (srcB.text.length > 220 ? "…" : ""),
      synthesis: "يتكامل درس «" + srcA.title + "» مع درس «" + srcB.title + "» في بناء الفهم العميق للمادة؛ حيث يؤسس الأول لقاعدة (" + (rulesA[0] || srcA.title) + ")، بينما يطور الثاني مهارة (" + (rulesB[0] || srcB.title) + "). والجمع بينهما يمكّن الطالب والباحث من حل المسائل المركبة والربط بين المفاهيم.",
      bloomQuestions: [
        "س1 (مقارنة وتحليل — مستوى التحليل): قارن في جدول بين المفهوم الأساسي في «" + srcA.title + "» والمفهوم الأساسي في «" + srcB.title + "» من حيث القاعدة والتطبيق.",
        "س2 (ربط وتركيب — مستوى الإبداع): كيف يمكنك توظيف القاعدة الواردة في «" + srcA.title + "» لحل مسألة أو موقف عملي يعتمد على «" + srcB.title + "»؟",
        "س3 (تقويم وحكم علمي — مستوى التقويم): علّل أهمية دراسة هذين الموضوعين معاً وكيف يكمل كل منهما الآخر في المنهاج."
      ]
    };
  }

  // ==================== 3. بناء واجهة الاستوديو (#multiSourceSynthStudio) ====================
  function ensureMultiSynthSection() {
    var ex = $("multiSourceSynthStudio");
    if (ex) return ex;
    var anchor = $("bookReaderStudio") || $("sourcesStudio") || $("unifiedWorkflowStudio");
    if (!anchor || !anchor.parentNode) return null;
    var sec = document.createElement("section");
    sec.id = "multiSourceSynthStudio";
    sec.className = "py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20";
    anchor.parentNode.insertBefore(sec, anchor.nextSibling);
    return sec;
  }

  function renderMultiSynthStudio() {
    var sec = ensureMultiSynthSection();
    if (!sec) return;
    var sources = getAvailableSourcesList();
    if (MState.sourceAIdx >= sources.length) MState.sourceAIdx = 0;
    if (MState.sourceBIdx >= sources.length) MState.sourceBIdx = Math.min(1, sources.length - 1);
    var srcA = sources[MState.sourceAIdx] || sources[0];
    var srcB = sources[MState.sourceBIdx] || sources[0];

    if (!MState.dialogueLines || !MState.dialogueLines.length) {
      MState.dialogueLines = buildDialogueFromText(srcA.title, srcA.text, srcA.rules);
    }
    if (!MState.matrixResult) {
      MState.matrixResult = buildComparisonMatrix(srcA, srcB);
    }

    var inpCls = "w-full text-xs font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100 outline-none focus:border-brand-500";

    sec.innerHTML =
      '<div class="glass-card rounded-3xl border-2 border-teal-500/35 dark:border-slate-700 shadow-2xl overflow-hidden text-right">' +
        // 1. Header Banner
        '<div class="p-5 sm:p-6 bg-gradient-to-l from-teal-950 via-indigo-950 to-slate-900 text-white">' +
          '<div class="flex flex-wrap items-center justify-between gap-3">' +
            '<div>' +
              '<div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-black mb-1.5">' +
                '<span>🎙️ استوديو البودكاست التعليمي التفاعلي والدمج الذكي بين الكتب والمصادر (NotebookLM العربي)</span>' +
              '</div>' +
              '<h2 class="text-lg sm:text-2xl font-black">حوّل أي كتاب أو فصل من قاعدة بيانات الـ Markdown إلى حوار صوتي ناطق أو مصفوفة مقارنة شاملة</h2>' +
              '<p class="text-xs text-slate-200 mt-1">استمع لشرح دروسك كحوار إذاعي ممتع بين متحدثَين، أو ادمج فصلين معاً لاستخراج جدول مقارنة وأسئلة ربط عليا.</p>' +
            '</div>' +
            '<div class="flex flex-wrap gap-2">' +
              '<button type="button" id="msGoBookReaderBtn" class="px-3.5 py-2 rounded-xl bg-amber-400 text-slate-950 text-xs font-black shadow flex items-center gap-1.5">' +
                '<i class="fa-solid fa-book-open"></i><span>قارئ الكتب التفاعلي</span>' +
              '</button>' +
              '<button type="button" id="msGoSourcesDbBtn" class="px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-extrabold border border-white/20 flex items-center gap-1.5">' +
                '<i class="fa-solid fa-database"></i><span>قاعدة بيانات مصادري (500MB)</span>' +
              '</button>' +
            '</div>' +
          '</div>' +

          // Sub-Tabs
          '<div class="mt-4 pt-4 border-t border-white/15 flex flex-wrap gap-2">' +
            [
              { id: "podcast", ico: "🎙️", label: "1. الحوار الصوتي التفاعلي والبودكاست التعليمي للدرس" },
              { id: "matrix", ico: "⚖️", label: "2. مصفوفة المقارنة والدمج الذكي بين فصلين / كتابين" }
            ].map(function (t) {
              var on = MState.tab === t.id;
              return '<button type="button" data-ms-tab="' + t.id + '" class="px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 ' +
                (on ? "bg-amber-400 text-slate-950 font-black shadow" : "bg-white/10 hover:bg-white/20 text-slate-200") + '">' +
                '<span>' + t.ico + '</span><span>' + t.label + '</span>' +
              '</button>';
            }).join("") +
          '</div>' +
        '</div>' +

        // 2. Body
        '<div class="p-5 sm:p-6">' +
          (MState.tab === "matrix"
            ? renderMatrixTabHtml(sources, srcA, srcB, inpCls)
            : renderPodcastTabHtml(sources, srcA, inpCls)) +
        '</div>' +
      '</div>';

    bindMultiSynthEvents(sec, sources, srcA, srcB);
  }

  function renderPodcastTabHtml(sources, srcA, inpCls) {
    return '<div class="space-y-5">' +
      '<div class="grid grid-cols-1 lg:grid-cols-12 gap-4 items-end bg-slate-50 dark:bg-slate-900/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700">' +
        '<div class="lg:col-span-6">' +
          '<label class="block text-xs font-black mb-1">📚 اختر الفصل أو الكتاب من قاعدة بيانات الموقع لتحويله إلى حلقة بودكاست:</label>' +
          '<select id="msSelectPodcastSource" class="' + inpCls + '">' +
            sources.map(function (s, idx) {
              return '<option value="' + idx + '"' + (MState.sourceAIdx === idx ? " selected" : "") + '>' + esc(s.bookTitle + " — " + s.title) + '</option>';
            }).join("") +
          '</select>' +
        '</div>' +
        '<div class="lg:col-span-6 flex flex-wrap gap-2">' +
          '<button type="button" id="msBtnGenPodcast" class="px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-black shadow">✨ توليد سيناريو الحلقة من الفصل</button>' +
          (speechPlaying
            ? '<button type="button" id="msBtnStopAudio" class="px-4 py-2.5 rounded-xl bg-rose-600 text-white text-xs font-black shadow animate-pulse">⏹️ إيقاف القراءة الصوتية</button>'
            : '<button type="button" id="msBtnPlayAudio" class="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow">🔊 تشغيل الحوار الصوتي الآن</button>') +
          '<button type="button" id="msBtnExportPodcastMd" class="px-3.5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-black">📥 حفظ الحلقة كـ Markdown</button>' +
        '</div>' +
      '</div>' +

      // بطاقات الحوار التفاعلي
      '<div class="space-y-3">' +
        MState.dialogueLines.map(function (ln, idx) {
          var isHost1 = ln.role === "host1";
          var isSpeaking = speechPlaying && currentLineIdx === idx;
          return '<div data-ms-speakline="' + idx + '" class="p-4 rounded-2xl border-2 transition cursor-pointer flex items-start gap-3 ' +
            (isSpeaking
              ? "border-amber-400 bg-amber-500/15 shadow-lg scale-[1.01]"
              : isHost1
              ? "border-indigo-500/25 bg-indigo-500/5 hover:border-indigo-500/50"
              : "border-emerald-500/25 bg-emerald-500/5 hover:border-emerald-500/50") + '">' +
            '<div class="w-11 h-11 rounded-2xl flex items-center justify-center text-lg font-black shrink-0 shadow ' +
              (isHost1 ? "bg-indigo-600 text-white" : "bg-emerald-600 text-white") + '">' +
              (isHost1 ? "🎙️" : "👩‍🔬") +
            '</div>' +
            '<div class="min-w-0 flex-1">' +
              '<div class="flex items-center justify-between gap-2">' +
                '<span class="text-xs font-black ' + (isHost1 ? "text-indigo-700 dark:text-sky-300" : "text-emerald-700 dark:text-emerald-300") + '">' + esc(ln.speaker) + '</span>' +
                '<span class="text-[10px] font-bold text-slate-400">' + (isSpeaking ? "🔊 يُقرأ الآن…" : "اضغط للاستماع لهذا المقطع 🔊") + '</span>' +
              '</div>' +
              '<p class="text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-100 mt-1 leading-relaxed">' + esc(ln.text) + '</p>' +
            '</div>' +
          '</div>';
        }).join("") +
      '</div>' +
    '</div>';
  }

  function renderMatrixTabHtml(sources, srcA, srcB, inpCls) {
    var mx = MState.matrixResult || buildComparisonMatrix(srcA, srcB);
    return '<div class="space-y-5">' +
      '<div class="grid grid-cols-1 md:grid-cols-12 gap-3 items-end bg-slate-50 dark:bg-slate-900/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700">' +
        '<div class="md:col-span-5">' +
          '<label class="block text-xs font-black text-indigo-600 dark:text-sky-300 mb-1">📘 المصدر أو الفصل الأول (أ):</label>' +
          '<select id="msSelectSourceA" class="' + inpCls + '">' +
            sources.map(function (s, idx) {
              return '<option value="' + idx + '"' + (MState.sourceAIdx === idx ? " selected" : "") + '>' + esc(s.bookTitle + " — " + s.title) + '</option>';
            }).join("") +
          '</select>' +
        '</div>' +
        '<div class="md:col-span-5">' +
          '<label class="block text-xs font-black text-emerald-600 dark:text-emerald-400 mb-1">📗 المصدر أو الفصل الثاني (ب):</label>' +
          '<select id="msSelectSourceB" class="' + inpCls + '">' +
            sources.map(function (s, idx) {
              return '<option value="' + idx + '"' + (MState.sourceBIdx === idx ? " selected" : "") + '>' + esc(s.bookTitle + " — " + s.title) + '</option>';
            }).join("") +
          '</select>' +
        '</div>' +
        '<div class="md:col-span-2">' +
          '<button type="button" id="msBtnBuildMatrix" class="w-full py-2.5 px-3 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-black shadow">⚖️ قارن وادمج</button>' +
        '</div>' +
      '</div>' +

      // جدول المقارنة المنهجي
      '<div class="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-700">' +
        '<table class="w-full text-right text-xs border-collapse">' +
          '<thead>' +
            '<tr class="bg-slate-900 text-white">' +
              '<th class="p-3 font-black border-b border-slate-700 w-1/5">وجه المقارنة</th>' +
              '<th class="p-3 font-black border-b border-slate-700 w-2/5 text-sky-300">📘 ' + esc(mx.titleA) + '</th>' +
              '<th class="p-3 font-black border-b border-slate-700 w-2/5 text-emerald-300">📗 ' + esc(mx.titleB) + '</th>' +
            '</tr>' +
          '</thead>' +
          '<tbody class="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900">' +
            '<tr><td class="p-3 font-black bg-slate-50 dark:bg-slate-800/50">الصف والمادة</td><td class="p-3 font-semibold">' + esc(mx.gradeSubjA) + '</td><td class="p-3 font-semibold">' + esc(mx.gradeSubjB) + '</td></tr>' +
            '<tr><td class="p-3 font-black bg-slate-50 dark:bg-slate-800/50">القاعدة / الفكرة المحورية</td><td class="p-3 font-semibold">' + esc(mx.coreA) + '</td><td class="p-3 font-semibold">' + esc(mx.coreB) + '</td></tr>' +
            '<tr><td class="p-3 font-black bg-slate-50 dark:bg-slate-800/50">الشرح والتطبيق المنهجي</td><td class="p-3 leading-relaxed">' + esc(mx.methodA) + '</td><td class="p-3 leading-relaxed">' + esc(mx.methodB) + '</td></tr>' +
          '</tbody>' +
        '</table>' +
      '</div>' +

      // الخلاصة التركيبية وأسئلة هرم بلوم العليا
      '<div class="grid grid-cols-1 md:grid-cols-2 gap-4">' +
        '<div class="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 space-y-2">' +
          '<div class="text-xs font-black text-indigo-700 dark:text-sky-300">🔗 الملخص التركيبي الموحّد بين المصدرين:</div>' +
          '<p class="text-xs leading-relaxed font-semibold">' + esc(mx.synthesis) + '</p>' +
        '</div>' +
        '<div class="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-2">' +
          '<div class="text-xs font-black text-emerald-700 dark:text-emerald-300">🧠 أسئلة التفكير العليا والربط (هرم بلوم):</div>' +
          '<ul class="text-xs space-y-1.5 font-semibold leading-relaxed">' +
            mx.bloomQuestions.map(function (q) { return '<li>• ' + esc(q) + '</li>'; }).join("") +
          '</ul>' +
        '</div>' +
      '</div>' +

      '<div class="flex flex-wrap gap-2">' +
        '<button type="button" id="msSendMatrixToWs" class="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-black shadow">📝 أرسل المقارنة والأسئلة إلى مولّد أوراق العمل</button>' +
        '<button type="button" id="msSendMatrixToKit" class="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-black shadow">🧳 أرسل إلى حقيبة الحصة الجاهزة</button>' +
        '<button type="button" id="msSaveMatrixMd" class="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 text-xs font-black shadow">📝 حفظ المقارنة كـ Markdown في قاعدة الموقع</button>' +
      '</div>' +
    '</div>';
  }

  function bindMultiSynthEvents(sec, sources, srcA, srcB) {
    if ($("msGoBookReaderBtn")) $("msGoBookReaderBtn").onclick = function () {
      if (window.EduBookReader && window.EduBookReader.open) window.EduBookReader.open(null, 0, "interactive");
    };
    if ($("msGoSourcesDbBtn")) $("msGoSourcesDbBtn").onclick = function () {
      if (window.EduSources && window.EduSources.open) window.EduSources.open();
    };

    sec.querySelectorAll("[data-ms-tab]").forEach(function (b) {
      b.onclick = function () {
        MState.tab = b.getAttribute("data-ms-tab");
        saveState();
        renderMultiSynthStudio();
      };
    });

    var podSel = $("msSelectPodcastSource");
    if (podSel) {
      podSel.onchange = function () {
        MState.sourceAIdx = +podSel.value;
        var chosen = sources[MState.sourceAIdx] || sources[0];
        MState.dialogueLines = buildDialogueFromText(chosen.title, chosen.text, chosen.rules);
        saveState();
        renderMultiSynthStudio();
      };
    }

    if ($("msBtnGenPodcast")) $("msBtnGenPodcast").onclick = function () {
      var chosen = sources[MState.sourceAIdx] || sources[0];
      MState.dialogueLines = buildDialogueFromText(chosen.title, chosen.text, chosen.rules);
      saveState();
      renderMultiSynthStudio();
      toast("🎙️ تم توليد سيناريو حلقة البودكاست من الفصل المختار ✓", "success");
    };

    if ($("msBtnPlayAudio")) $("msBtnPlayAudio").onclick = function () { playPodcastSpeech(0); };
    if ($("msBtnStopAudio")) $("msBtnStopAudio").onclick = stopPodcastSpeech;

    sec.querySelectorAll("[data-ms-speakline]").forEach(function (el) {
      el.onclick = function () {
        playPodcastSpeech(+el.getAttribute("data-ms-speakline"));
      };
    });

    if ($("msBtnExportPodcastMd")) $("msBtnExportPodcastMd").onclick = function () {
      var chosen = sources[MState.sourceAIdx] || sources[0];
      var md = "# 🎙️ حلقة بودكاست تعليمي: " + chosen.title + "\n\n" +
        MState.dialogueLines.map(function (l) { return "- **" + l.speaker + ":** " + l.text; }).join("\n\n");
      if (window.EduSources && window.EduSources.addRaw) {
        window.EduSources.addRaw({
          kind: "md",
          name: "بودكاست_" + chosen.title.slice(0, 25).replace(/\s+/g, "_") + ".md",
          mime: "text/markdown",
          markdown: md,
          data: btoa(unescape(encodeURIComponent(md)))
        }, true);
      }
      toast("📥 تم حفظ نص حلقة البودكاست بصيغة Markdown في قاعدة بيانات الموقع ✓", "success");
    };

    if ($("msSelectSourceA")) $("msSelectSourceA").onchange = function (e) { MState.sourceAIdx = +e.target.value; };
    if ($("msSelectSourceB")) $("msSelectSourceB").onchange = function (e) { MState.sourceBIdx = +e.target.value; };
    if ($("msBtnBuildMatrix")) $("msBtnBuildMatrix").onclick = function () {
      var a = sources[MState.sourceAIdx] || sources[0];
      var b = sources[MState.sourceBIdx] || sources[0];
      MState.matrixResult = buildComparisonMatrix(a, b);
      saveState();
      renderMultiSynthStudio();
      toast("⚖️ تم بناء مصفوفة المقارنة والدمج الذكي بين الفصلين ✓", "success");
    };

    var sendMatrixToTool = function (toolId) {
      var mx = MState.matrixResult || buildComparisonMatrix(srcA, srcB);
      var combinedNotes = mx.synthesis + "\n\n" + mx.bloomQuestions.join("\n");
      if (window.EduBridge && window.EduBridge.openTool) {
        window.EduBridge.openTool(toolId, {
          title: "مقارنة ودمج: " + srcA.title + " و " + srcB.title,
          topic: "مقارنة ودمج: " + srcA.title + " و " + srcB.title,
          grade: srcA.grade,
          subject: srcA.subject,
          notes: combinedNotes
        });
      }
    };
    if ($("msSendMatrixToWs")) $("msSendMatrixToWs").onclick = function () { sendMatrixToTool("worksheetStudio"); };
    if ($("msSendMatrixToKit")) $("msSendMatrixToKit").onclick = function () { sendMatrixToTool("lessonKitStudio"); };
    if ($("msSaveMatrixMd")) $("msSaveMatrixMd").onclick = function () {
      var mx = MState.matrixResult || buildComparisonMatrix(srcA, srcB);
      var md = "# ⚖️ مصفوفة مقارنة ودمج: " + mx.titleA + " × " + mx.titleB + "\n\n" +
        "## الملخص التركيبي الموحّد\n" + mx.synthesis + "\n\n" +
        "## أسئلة التفكير العليا (هرم بلوم)\n- " + mx.bloomQuestions.join("\n- ");
      if (window.EduSources && window.EduSources.addRaw) {
        window.EduSources.addRaw({
          kind: "md",
          name: "مقارنة_" + srcA.title.slice(0, 20).replace(/\s+/g, "_") + ".md",
          mime: "text/markdown",
          markdown: md,
          data: btoa(unescape(encodeURIComponent(md)))
        }, true);
      }
      toast("📝 تم حفظ مصفوفة المقارنة بصيغة Markdown في قاعدة بيانات الموقع ✓", "success");
    };
  }

  function openMultiSynth(tabName, srcIdx) {
    if (tabName) MState.tab = tabName;
    if (typeof srcIdx === "number" && srcIdx >= 0) MState.sourceAIdx = srcIdx;
    var sources = getAvailableSourcesList();
    var chosen = sources[MState.sourceAIdx] || sources[0];
    MState.dialogueLines = buildDialogueFromText(chosen.title, chosen.text, chosen.rules);
    saveState();
    renderMultiSynthStudio();
    if (window.EduLauncher && window.EduLauncher.jump) {
      window.EduLauncher.jump("multiSourceSynthStudio", true);
    } else {
      var sec = $("multiSourceSynthStudio");
      if (sec) sec.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  function init() {
    renderMultiSynthStudio();
    
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();

  window.EduMultiSynth = {
    open: openMultiSynth,
    render: renderMultiSynthStudio
  };
})();

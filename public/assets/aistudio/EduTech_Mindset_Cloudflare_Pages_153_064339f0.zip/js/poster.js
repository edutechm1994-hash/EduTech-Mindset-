/* مولّد ملصقات الإعلان: عنوان + تفاصيل + ثيمة ← صورة PNG جاهزة للتنزيل/المشاركة، ويمكن نشرها إعلاناً في واجهة الموقع. */
(function () {
  "use strict";
  var KEY = "edutech_poster_draft_v1";
  var inp = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";
  var THEMES = {
    royal: { n: "ملكي", c: ["#06152d", "#0c2d5e", "#0077ff", "#f59e0b"] },
    gold: { n: "ذهبي", c: ["#1e1b18", "#422006", "#b45309", "#fbbf24"] },
    crimson: { n: "قرمزي", c: ["#2a0812", "#7f1d1d", "#dc2626", "#fde047"] },
    emerald: { n: "زمردي", c: ["#042f2e", "#065f46", "#059669", "#fbbf24"] },
    violet: { n: "بنفسجي", c: ["#1e1b4b", "#4c1d95", "#7c3aed", "#fde047"] },
    light: { n: "فاتح", c: ["#f8fafc", "#e0f2fe", "#bae6fd", "#0369a1"], dark: false }
  };
  var SIZES = { portrait: { n: "طولي 4:5 (واتساب/فيسبوك)", w: 1080, h: 1350 }, square: { n: "مربع", w: 1080, h: 1080 }, story: { n: "ستوري 9:16", w: 1080, h: 1920 }, wide: { n: "عريض 16:9 (واجهة الموقع)", w: 1280, h: 720 } };
  var DEF = { title: "ورشة تدريبية: التعلم النشط", sub: "تعلّم أساليب حديثة تجعل الطلاب شركاء في الحصة", badge: "ورشة تدريبية", info1: "📅 السبت 15 نوفمبر — 10:00 صباحاً", info2: "📍 خان يونس", info3: "📞 0597663828", theme: "royal", size: "portrait", logo: true, footer: "edutech-mindset.pages.dev" };
  var logoImg = null;

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function cloud() { return !!(window.Cloud && window.Cloud.enabled); }
  function canEdit() { return typeof isSuperAdminUser === "function" && isSuperAdminUser(); }
  function toast(m, t) { if (typeof showToast === "function") showToast(m, t || "info"); }

  function wrap(ctx, text, maxW) {
    var out = [];
    String(text || "").split(/\n/).forEach(function (para) {
      var words = para.split(/\s+/).filter(Boolean), line = "";
      if (!words.length) { out.push(""); return; }
      words.forEach(function (w) { var t = line ? line + " " + w : w; if (ctx.measureText(t).width > maxW && line) { out.push(line); line = w; } else line = t; });
      out.push(line);
    });
    return out;
  }
  function fitLines(ctx, text, maxW, maxLines, start, min, weight) {
    var size = start, lines;
    for (; size >= min; size -= 4) { ctx.font = weight + " " + size + "px Alexandria, Cairo, Tahoma, Arial, sans-serif"; lines = wrap(ctx, text, maxW); if (lines.length <= maxLines) return { size: size, lines: lines }; }
    ctx.font = weight + " " + min + "px Alexandria, Cairo, Tahoma, Arial, sans-serif"; lines = wrap(ctx, text, maxW); return { size: min, lines: lines.slice(0, maxLines) };
  }
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }

  function draw(cv, d, off) {
    var S = SIZES[d.size] || SIZES.portrait, T = THEMES[d.theme] || THEMES.royal, c = T.c, dark = T.dark !== false, W = S.w, H = S.h, ctx = cv.getContext("2d"), wide = W > H * 1.3;
    cv.width = W; cv.height = H; ctx.direction = "rtl"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    var g = ctx.createLinearGradient(0, 0, W, H); g.addColorStop(0, c[0]); g.addColorStop(0.55, c[1]); g.addColorStop(1, c[2]); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // زخارف
    ctx.save(); ctx.globalAlpha = dark ? 0.09 : 0.35; ctx.fillStyle = dark ? "#fff" : c[3];
    ctx.beginPath(); ctx.arc(W * 0.95, H * 0.06, W * 0.34, 0, 7); ctx.fill(); ctx.beginPath(); ctx.arc(W * 0.02, H * 0.97, W * 0.3, 0, 7); ctx.fill();
    ctx.globalAlpha = dark ? 0.06 : 0.2; for (var y = 40; y < H; y += 54) for (var x = 40 + ((y / 54) % 2) * 27; x < W; x += 54) { ctx.beginPath(); ctx.arc(x, y, 2.2, 0, 7); ctx.fill(); }
    ctx.restore();
    var fg = dark ? "#ffffff" : "#0f172a", sub = dark ? "#e2e8f0" : "#334155", pad = Math.round(W * 0.08), cw = W - pad * 2, cx = W / 2, yy = Math.round(H * (wide ? 0.07 : 0.055)) + (off || 0);
    // الشعار
    if (d.logo && logoImg && logoImg.complete && logoImg.naturalWidth) {
      var lh = Math.round(H * (wide ? 0.1 : 0.075)), lw = Math.round(lh * logoImg.naturalWidth / logoImg.naturalHeight);
      ctx.fillStyle = "rgba(255,255,255,0.96)"; rr(ctx, cx - lw / 2 - 16, yy, lw + 32, lh + 16, 22); ctx.fill(); ctx.drawImage(logoImg, cx - lw / 2, yy + 8, lw, lh); yy += lh + 16 + Math.round(H * (wide ? 0.02 : 0.025));
    }
    // الشارة
    if (d.badge) {
      var bs = Math.round(W * (wide ? 0.02 : 0.036)); ctx.font = "800 " + bs + "px Alexandria, Cairo, Tahoma, Arial, sans-serif"; var bw = ctx.measureText(d.badge).width + bs * 2.4, bh = bs * 2;
      ctx.fillStyle = c[3]; rr(ctx, cx - bw / 2, yy, bw, bh, bh / 2); ctx.fill(); ctx.fillStyle = dark ? "#1c1917" : "#fff"; ctx.fillText(d.badge, cx, yy + bh / 2 + 2); yy += bh + Math.round(H * (wide ? 0.03 : 0.035));
    }
    // العنوان
    var t = fitLines(ctx, d.title, cw, wide ? 2 : 4, Math.round(W * (wide ? 0.058 : 0.098)), Math.round(W * 0.04), "900"), lhT = Math.round(t.size * 1.45);
    ctx.fillStyle = fg; ctx.shadowColor = dark ? "rgba(0,0,0,.45)" : "transparent"; ctx.shadowBlur = dark ? 14 : 0; ctx.shadowOffsetY = 4;
    t.lines.forEach(function (ln, i) { ctx.font = "900 " + t.size + "px Alexandria, Cairo, Tahoma, Arial, sans-serif"; ctx.fillText(ln, cx, yy + lhT * i + lhT / 2); });
    ctx.shadowColor = "transparent"; yy += lhT * t.lines.length + Math.round(H * 0.012);
    ctx.fillStyle = c[3]; rr(ctx, cx - W * 0.09, yy, W * 0.18, 8, 4); ctx.fill(); yy += Math.round(H * 0.035);
    // النص الفرعي
    var infos = [d.info1, d.info2, d.info3].filter(function (x) { return x && x.trim(); }), infoH = Math.round(W * (wide ? 0.04 : 0.076)), infoGap = Math.round(W * 0.022), footerH = Math.round(H * (wide ? 0.09 : 0.075)), rows = wide ? 1 : infos.length;
    var availSub = H - yy - footerH - (infos.length ? rows * (infoH + infoGap) : 0) - Math.round(H * 0.03);
    if (d.sub && d.sub.trim()) {
      var maxL = Math.max(1, Math.floor(availSub / (W * 0.05 * 1.6))), s = fitLines(ctx, d.sub, cw, Math.min(maxL, wide ? 2 : 7), Math.round(W * (wide ? 0.031 : 0.044)), Math.round(W * 0.022), "600"), lhS = Math.round(s.size * 1.65);
      ctx.fillStyle = sub; s.lines.forEach(function (ln, i) { ctx.font = "600 " + s.size + "px Alexandria, Cairo, Tahoma, Arial, sans-serif"; ctx.fillText(ln, cx, yy + lhS * i + lhS / 2); }); yy += lhS * s.lines.length + Math.round(H * 0.02);
    }
    // المعلومات
    var infoTop = infos.length ? (wide ? H - footerH - infoH - 6 : H - footerH - infos.length * (infoH + infoGap) + infoGap / 2) : H - footerH;
    if (!off && infoTop - yy > 40) return draw(cv, d, Math.round((infoTop - yy) * 0.42)); // توسيط المحتوى رأسياً حين تتسع المساحة
    var is = Math.round(W * (wide ? 0.019 : 0.034));
    if (wide && infos.length) { // صف أفقي واحد
      ctx.font = "800 " + is + "px Alexandria, Cairo, Tahoma, Arial, sans-serif"; var ws = infos.map(function (tx) { return ctx.measureText(tx).width + is * 2.4; }), tot = ws.reduce(function (a, x) { return a + x; }, 0) + infoGap * (infos.length - 1), k = tot > cw ? cw / tot : 1, x0 = cx + (tot * k) / 2, y0 = H - footerH - infoH - 6;
      infos.forEach(function (tx, i) { var w = ws[i] * k; x0 -= w; ctx.fillStyle = dark ? "rgba(255,255,255,0.14)" : "rgba(255,255,255,0.8)"; rr(ctx, x0, y0, w, infoH, infoH / 2); ctx.fill(); ctx.strokeStyle = c[3]; ctx.lineWidth = 2; ctx.globalAlpha = 0.7; ctx.stroke(); ctx.globalAlpha = 1; ctx.fillStyle = fg; ctx.font = "800 " + Math.round(is * k) + "px Alexandria, Cairo, Tahoma, Arial, sans-serif"; ctx.fillText(tx, x0 + w / 2, y0 + infoH / 2 + 2); x0 -= infoGap * k; });
    } else {
      var iy = H - footerH - infos.length * (infoH + infoGap) + infoGap / 2;
      infos.forEach(function (tx, i) {
        ctx.font = "800 " + is + "px Alexandria, Cairo, Tahoma, Arial, sans-serif"; var iw = Math.min(cw, ctx.measureText(tx).width + is * 2.6), y0 = iy + i * (infoH + infoGap);
        ctx.fillStyle = dark ? "rgba(255,255,255,0.14)" : "rgba(255,255,255,0.8)"; rr(ctx, cx - iw / 2, y0, iw, infoH, infoH / 2); ctx.fill();
        ctx.strokeStyle = c[3]; ctx.lineWidth = 2; ctx.globalAlpha = 0.7; ctx.stroke(); ctx.globalAlpha = 1; ctx.fillStyle = fg; ctx.fillText(tx, cx, y0 + infoH / 2 + 2);
      });
    }
    // التذييل
    if (d.footer) { ctx.fillStyle = dark ? "rgba(255,255,255,0.75)" : "#475569"; ctx.font = "700 " + Math.round(W * (wide ? 0.017 : 0.027)) + "px Alexandria, Cairo, Tahoma, Arial, sans-serif"; ctx.fillText(d.footer, cx, H - footerH / 2); }
  }

  function blob(cv, type, q) { return new Promise(function (res) { cv.toBlob(res, type, q); }); }
  function tab(H) {
    var d = Object.assign({}, DEF); try { Object.assign(d, JSON.parse(localStorage.getItem(KEY) || "{}")); } catch (e) {}
    H.body.innerHTML = '<div class="space-y-3"><div class="rounded-2xl bg-slate-100 dark:bg-slate-800 p-2 flex justify-center"><canvas id="pzCv" style="max-width:100%;max-height:52vh;border-radius:12px;box-shadow:0 6px 24px #0004"></canvas></div>' +
      '<div class="grid grid-cols-2 gap-2"><select id="pzTh" class="' + inp + '">' + Object.keys(THEMES).map(function (k) { return '<option value="' + k + '"' + (d.theme === k ? " selected" : "") + ">ثيمة " + THEMES[k].n + "</option>"; }).join("") + '</select><select id="pzSz" class="' + inp + '">' + Object.keys(SIZES).map(function (k) { return '<option value="' + k + '"' + (d.size === k ? " selected" : "") + ">" + SIZES[k].n + "</option>"; }).join("") + "</select></div>" +
      '<input id="pzBadge" class="' + inp + '" placeholder="الشارة (مثل: ورشة تدريبية، إعلان، عاجل)" value="' + esc(d.badge) + '">' +
      '<input id="pzTitle" class="' + inp + '" placeholder="العنوان الرئيسي" value="' + esc(d.title) + '"><textarea id="pzSub" rows="3" class="' + inp + '" placeholder="تفاصيل الإعلان">' + esc(d.sub) + "</textarea>" +
      '<input id="pzI1" class="' + inp + '" placeholder="سطر معلومات 1 (📅 التاريخ والوقت)" value="' + esc(d.info1) + '"><input id="pzI2" class="' + inp + '" placeholder="سطر معلومات 2 (📍 المكان)" value="' + esc(d.info2) + '"><input id="pzI3" class="' + inp + '" placeholder="سطر معلومات 3 (📞 التواصل)" value="' + esc(d.info3) + '">' +
      '<input id="pzFt" class="' + inp + '" placeholder="التذييل (رابط الموقع أو اسمك)" value="' + esc(d.footer) + '"><label class="flex items-center gap-2 text-xs font-bold"><input id="pzLogo" type="checkbox"' + (d.logo ? " checked" : "") + '> إظهار شعار الموقع</label></div>';
    var cv = document.getElementById("pzCv"), timer = 0;
    function read() { d.theme = v("pzTh"); d.size = v("pzSz"); d.badge = v("pzBadge"); d.title = v("pzTitle"); d.sub = v("pzSub"); d.info1 = v("pzI1"); d.info2 = v("pzI2"); d.info3 = v("pzI3"); d.footer = v("pzFt"); d.logo = document.getElementById("pzLogo").checked; try { localStorage.setItem(KEY, JSON.stringify(d)); } catch (e) {} }
    function v(id) { return document.getElementById(id).value; }
    function paint() { read(); try { draw(cv, d); } catch (e) { console.error(e); } }
    function later() { clearTimeout(timer); timer = setTimeout(paint, 120); }
    H.body.querySelectorAll("input,select,textarea").forEach(function (el) { el.addEventListener("input", later); el.addEventListener("change", later); });
    function ready() { var f = (document.fonts && document.fonts.load) ? Promise.all([document.fonts.load("900 40px Alexandria"), document.fonts.load("600 30px Alexandria")]).catch(function () {}) : Promise.resolve();
      var l = new Promise(function (res) { if (logoImg) return res(); logoImg = new Image(); logoImg.onload = logoImg.onerror = function () { res(); }; logoImg.src = "assets/logo.png"; });
      return Promise.all([f, l]); }
    paint(); ready().then(paint);
    H.foot('<button type="button" id="pzDl" class="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold">⬇ تنزيل PNG</button><button type="button" id="pzSh" class="px-4 py-2 rounded-xl bg-sky-600 text-white text-xs font-bold">↗ مشاركة</button>' + (cloud() ? '<button type="button" id="pzAd" class="px-4 py-2 rounded-xl bg-brand-600 text-white text-xs font-bold">📢 انشر كإعلان بالواجهة</button>' : ""));
    document.getElementById("pzDl").onclick = function () { paint(); blob(cv, "image/png").then(function (b) { var a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = "EduTech_Poster_" + Date.now().toString(36) + ".png"; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 800); toast("تم تنزيل الملصق ✓", "success"); }); };
    document.getElementById("pzSh").onclick = function () { paint(); blob(cv, "image/png").then(function (b) { var f = new File([b], "poster.png", { type: "image/png" });
      if (navigator.canShare && navigator.canShare({ files: [f] })) navigator.share({ files: [f], title: d.title }).catch(function () {}); else { toast("المشاركة المباشرة غير مدعومة هنا — استخدم «تنزيل»", "info"); } }); };
    var ad = document.getElementById("pzAd"); if (ad) ad.onclick = function () {
      if (!canEdit()) { toast("للإدارة فقط 🔒", "warning"); return; }
      paint(); ad.disabled = true; ad.textContent = "جارٍ النشر…";
      blob(cv, "image/jpeg", 0.88).then(function (b) {
        var f = new File([b], "poster.jpg", { type: "image/jpeg" });
        if (window.EduMedia && window.EduMedia.ready()) return window.EduMedia.upload(f, "images");
        return new Promise(function (res, rej) { var r = new FileReader(); r.onload = function () { res(r.result); }; r.onerror = rej; r.readAsDataURL(b.size < 700000 ? b : f); }).then(function (u) { if (u.length > 900000) throw new Error("الصورة كبيرة؛ اختر المقاس «عريض» أو فعّل رفع الملفات (R2)"); return u; });
      }).then(function (url) {
        return window.Cloud.commit([{ col: "site", id: "slide-" + Date.now().toString(36), data: { kind: "slide", title: "", text: "", btn: "", link: "", images: [url], active: true, order: Math.floor(Date.now() / 1000) } }]);
      }).then(function () { toast("نُشر الملصق كإعلان في واجهة الموقع ✓", "success"); ad.textContent = "تم النشر ✓"; setTimeout(function () { ad.disabled = false; ad.textContent = "📢 انشر كإعلان بالواجهة"; }, 2500); },
        function (e) { ad.disabled = false; ad.textContent = "📢 انشر كإعلان بالواجهة"; toast((e && e.message) || "تعذر النشر", "warning"); });
    };
  }
  window.EduPoster = { draw: draw, tab: tab };
  function boot() { if (window.EduHome && window.EduHome.registerTab) window.EduHome.registerTab("poster", "مولّد الملصقات", "fa-image", tab); }
  if (document.readyState === "loading") window.addEventListener("DOMContentLoaded", function () { setTimeout(boot, 90); }); else setTimeout(boot, 90);
})();

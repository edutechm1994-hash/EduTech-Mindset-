/*
 * استوديو بناء السيرة الذاتية الاحترافية الثنائية اللغة (عربي + إنجليزي) وبوابة الطالب الجامعي والخريج
 * EduTech Mindset — الإصدار 83 (University Career Portal & Bilingual Professional ATS CV Builder)
 *
 * يقدم هذا الملف:
 * 1) منشئ السيرة الذاتية الاحترافية باللغتين العربية والإنجليزية (#cvBuilderStudio و window.EduCVBuilder):
 *    - تحرير ومعاينة حية فورية باللغة العربية (RTL)، أو الإنجليزية (LTR)، أو وضع العرض المزدوج (عربي + إنجليزي جنباً إلى جنب).
 *    - 6 قوالب تخصصية جاهزة لطلاب الجامعات والخريجين والمعلمين (هندسة حاسوب وذكاء اصطناعي، معلم وتربوي، طب وعلوم صحية، إدارة أعمال ومحاسبة، أكاديمي وبحثي للمنح، وتدريب ميداني لطالب جامعي) باللغتين العربية والإنجليزية.
 *    - 4 تصاميم طباعية احترافية (قالب هارفارد القياسي المتوافق مع ATS، القالب التنفيذي الحديث، القالب الأكاديمي الجامعي، والقالب ثنائي الأعمدة).
 *    - مترجم ومحسّن ذكي مدمج (يحوّل البيانات والمهارات والجامعات الفلسطينية بين العربية والإنجليزية فوراً بلا إنترنت أو عبر الذكاء الاصطناعي).
 *    - مؤشر قوة السيرة الذاتية وتوافقها مع أنظمة التوظيف (ATS Score 0-100%) + مولّد خطاب التقديم للوظائف والمنح الجامعية (Cover / Motivation Letter).
 *    - تصدير متعدد الصيغ: طباعة PDF احترافي بمقاس A4، تنزيل ملف Word (.doc)، تنزيل Markdown (.md) وحفظه في قاعدة بيانات الموقع.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };

  var CV_STORAGE_KEY = "edu_cv_builder_state_v83";

  // ==================== 1. القوالب الجامعية والمهنية الـ 6 الجاهزة (ثنائية اللغة عربي + إنجليزي) ====================
  var CV_PRESETS = {
    cs_ai: {
      id: "cs_ai",
      label: "💻 هندسة حاسوب وذكاء اصطناعي (IT / Software)",
      ar: {
        fullName: "كريم محمود العلي",
        jobTitle: "مهندس برمجيات ومطور تطبيقات ويب وذكاء اصطناعي",
        email: "kareem.ali@edu-pal.ps",
        phone: "+970 59 900 1122",
        location: "رام الله، فلسطين",
        linkedin: "linkedin.com/in/kareem-ali-dev",
        portfolio: "github.com/kareem-ai",
        summary: "خريج هندسة أنظمة حاسوب بتقدير امتياز مع خبرة عملية في تطوير تطبيقات الويب التفاعلية، قواعد البيانات العلائقية SQL، ودمج نماذج الذكاء الاصطناعي التوليدي. شغوف ببناء حلول تقنية وتعليمية عالية الكفاءة.",
        education: [
          { degree: "بكالوريوس هندسة أنظمة الحاسوب", uni: "جامعة بيرزيت — فلسطين", year: "2022 – 2026", gpa: "3.85 / 4.0 (امتياز)", gradProject: "منصة تعليمية ذكية تعتمد على الذكاء الاصطناعي وتحويل الكتب إلى قواعد بيانات Markdown" }
        ],
        experience: [
          { role: "متدرب هندسة برمجيات وتطوير ويب (Full-Stack Intern)", company: "شركة التقنية المتقدمة للحلول الرقمية", period: "صيف 2025 – حتى الآن", details: "• تطوير واجهات ويب تفاعلية سريعة الاستجابة باستخدام JavaScript وTailwind CSS.\n• بناء واجهات برمجية ومعالجة قواعد بيانات SQL وIndexedDB بكفاءة عالية.\n• تقليص زمن تحميل الصفحات بنسبة 40% عبر تقنيات التخزين المؤقت (PWA)." },
          { role: "مساعد بحث وتدريس جامعي (Teaching Assistant)", company: "كلية الهندسة والتكنولوجيا — الجامعة", period: "2024 – 2025", details: "• مساعدة 80+ طالباً جامعياً في مختبرات البرمجة بلغة Python وهياكل البيانات.\n• الإشراف على مشاريع فصلية في تعلم الآلة وقواعد البيانات." }
        ],
        projects: [
          { name: "نظام القارئ التفاعلي ومحوّل الكتب بالذكاء الاصطناعي", tech: "JavaScript, PDF.js, IndexedDB, AI API", desc: "تطبيق يحول ملفات PDF الضخمة إلى وثائق Markdown مفهرسة مع توليد اختبارات وخرائط ذهنية تلقائياً." },
          { name: "تطبيق إدارة العيادات الطبية السحابي", tech: "React, Node.js, PostgreSQL", desc: "نظام متكامل لحجز المواعيد وأرشفة السجلات الطبية الإلكترونية." }
        ],
        skillsTech: ["JavaScript (ES6+)", "Python & AI APIs", "React & Tailwind CSS", "SQL & Database Design", "Git & Cloudflare Pages", "Problem Solving"],
        skillsSoft: ["العمل الجماعي القيادي", "التفكير التحليلي والناقد", "إدارة الوقت والمشاريع", "التواصل التقني الفعال"],
        languages: ["اللغة العربية (اللغة الأم — إتقان كامل)", "اللغة الإنجليزية (متقدم جداً — C1 الأكاديمية والمهنية)"],
        certs: ["شهادة هندسة أوامر الذكاء الاصطناعي (Prompt Engineering) — 2025", "شهادة تطوير تطبيقات الويب الحديثة Full-Stack — 2024", "المركز الأول في مسابقة البرمجة الجامعية على مستوى الجامعات الفلسطينية"]
      },
      en: {
        fullName: "Kareem Mahmoud Al-Ali",
        jobTitle: "Software Engineer & Full-Stack / AI Developer",
        email: "kareem.ali@edu-pal.ps",
        phone: "+970 59 900 1122",
        location: "Ramallah, Palestine",
        linkedin: "linkedin.com/in/kareem-ali-dev",
        portfolio: "github.com/kareem-ai",
        summary: "Honors Computer Systems Engineering graduate with hands-on experience in Full-Stack Web Development, SQL relational databases, and Generative AI integration. Passionate about building scalable, high-impact educational and enterprise software.",
        education: [
          { degree: "B.Sc. in Computer Systems Engineering", uni: "Birzeit University — Palestine", year: "2022 – 2026", gpa: "3.85 / 4.0 (Honors)", gradProject: "AI-Powered Educational Platform & Automated PDF-to-Markdown Knowledge Base" }
        ],
        experience: [
          { role: "Full-Stack Software Engineering Intern", company: "Advanced Tech Digital Solutions", period: "Summer 2025 – Present", details: "• Engineered responsive web applications using modern JavaScript and Tailwind CSS.\n• Designed and optimized SQL and IndexedDB storage layers for offline-first performance.\n• Reduced page load latency by 40% via Service Workers and progressive caching." },
          { role: "Undergraduate Teaching & Research Assistant", company: "Faculty of Engineering & Technology", period: "2024 – 2025", details: "• Mentored 80+ undergraduate students in Python programming, algorithms, and data structures labs.\n• Guided student teams on SQL database design and machine learning capstone projects." }
        ],
        projects: [
          { name: "Interactive Book Reader & AI PDF-to-Markdown Engine", tech: "JavaScript, PDF.js, IndexedDB, REST APIs", desc: "Built a client-side engine that parses large PDF textbooks into structured Markdown databases and auto-generates quizzes." },
          { name: "Cloud Medical Clinic Management System", tech: "React, Node.js, PostgreSQL", desc: "Developed a secure appointment scheduling and electronic health records portal." }
        ],
        skillsTech: ["JavaScript (ES6+)", "Python & AI APIs", "React & Tailwind CSS", "SQL & Database Design", "Git & Cloudflare Pages", "Algorithms & Data Structures"],
        skillsSoft: ["Team Leadership", "Analytical Problem Solving", "Agile Project Management", "Technical Communication"],
        languages: ["Arabic (Native Proficiency)", "English (Advanced Professional Proficiency — C1)"],
        certs: ["Generative AI & Prompt Engineering Certificate — 2025", "Modern Full-Stack Web Development Specialization — 2024", "1st Place Winner — Palestinian Inter-University Coding Competition"]
      }
    },
    educator: {
      id: "educator",
      label: "👨‍🏫 خريج تربية ومعلم متميز (Education / Teaching)",
      ar: {
        fullName: "سارة أحمد الخطيب",
        jobTitle: "معلمة علوم ورياضيات ومصممة تعليم رقمي وتفاعلي",
        email: "sara.khatib@edu-pal.ps",
        phone: "+970 59 811 2233",
        location: "نابلس، فلسطين",
        linkedin: "linkedin.com/in/sara-educator",
        portfolio: "edutech-mindset.pages.dev",
        summary: "تربوية متخصصة في أساليب التدريس الحديثة وتوظيف الذكاء الاصطناعي والوسائط التفاعلية في الغرفة الصفية. خبرة متميزة في إعداد الخطط وفق منهجية 5E وهرم بلوم ومراعاة الفروق الفردية والتعليم الدامج.",
        education: [
          { degree: "بكالوريوس أساليب تدريس العلوم والرياضيات", uni: "جامعة النجاح الوطنية — فلسطين", year: "2021 – 2025", gpa: "92.4% (امتياز)", gradProject: "أثر توظيف المختبرات الافتراضية والذكاء الاصطناعي في تنمية التفكير الناقد لدى طلبة المرحلة الأساسية" }
        ],
        experience: [
          { role: "معلمة علوم ورياضيات وتكنولوجيا تعليم", company: "مدرسة الرواد النموذجية", period: "2025 – حتى الآن", details: "• تصميم وتنفيذ حصص تفاعلية باستخدام السبورة الذكية، العروض التفاعلية، والمسابقات الصفية الحية.\n• إعداد أوراق عمل متمايزة (تأسيسي ومتقدم) وخطط علاجية رفعت متوسط تحصيل الطلبة بنسبة 22%.\n• التواصل المستمر مع أولياء الأمور عبر تقارير متابعة أسبوعية منظمة." },
          { role: "معلمة متدربة (التربية العملية الميدانية)", company: "مديرية التربية والتعليم", period: "2024 – 2025", details: "• تقديم 60+ حصة دراسية نموذجية وتصميم حقائب تعليمية رقمية متوافقة مع المنهاج الفلسطيني." }
        ],
        projects: [
          { name: "حقيبة الأنشطة التفاعلية والتكرار المتباعد للمنهاج الفلسطيني", tech: "تكنولوجيا التعليم، هرم بلوم، ألعاب تربوية", desc: "تحويل وحدات العلوم والرياضيات إلى بطاقات استذكار وخرائط ذهنية وألعاب صفية." }
        ],
        skillsTech: ["توظيف الذكاء الاصطناعي بالتعليم", "تصميم العروض وأوراق العمل التفاعلية", "إدارة الفصول الافتراضية", "السبورة التفاعلية والمختبر الافتراضي"],
        skillsSoft: ["إدارة الصف التحفيزية", "مراعاة الفروق الفردية (التعليم الدامج)", "التواصل التربوي مع الأسرة", "التقويم البنائي والختامي"],
        languages: ["اللغة العربية (اللغة الأم — فصاحة وإتقان)", "اللغة الإنجليزية (جيد جداً — قراءة ومحادثة ومصطلحات علمية)"],
        certs: ["دورة توظيف الذكاء الاصطناعي في التعليم الحديث — 2025", "شهادة استراتيجيات التعلم النشط والتعليم الدامج IEP — 2024"]
      },
      en: {
        fullName: "Sara Ahmad Al-Khatib",
        jobTitle: "STEM Educator & Instructional Technology Specialist",
        email: "sara.khatib@edu-pal.ps",
        phone: "+970 59 811 2233",
        location: "Nablus, Palestine",
        linkedin: "linkedin.com/in/sara-educator",
        portfolio: "edutech-mindset.pages.dev",
        summary: "Dedicated STEM Educator specializing in active learning methodologies, AI-assisted instructional design, and inclusive classroom management. Proven track record in designing 5E lesson plans, differentiated worksheets, and interactive digital assessments.",
        education: [
          { degree: "B.A. in Science & Mathematics Teaching Methods", uni: "An-Najah National University — Palestine", year: "2021 – 2025", gpa: "92.4% (Distinction)", gradProject: "Impact of Virtual STEM Labs & AI Tools on Developing Critical Thinking Skills" }
        ],
        experience: [
          { role: "Science & Mathematics Teacher", company: "Al-Rowad Model School", period: "2025 – Present", details: "• Delivered engaging lessons integrating interactive whiteboards, live classroom quizzes, and visual mind maps.\n• Authored two-tier differentiated worksheets and remedial plans, improving student achievement by 22%.\n• Maintained strong school-home partnerships via structured weekly progress reports." },
          { role: "Pre-Service Practicum Teacher", company: "Directorate of Education", period: "2024 – 2025", details: "• Taught 60+ model classroom sessions and built digital curriculum kits aligned with national standards." }
        ],
        projects: [
          { name: "Interactive STEM & Spaced-Repetition Curriculum Kit", tech: "Instructional Design, Bloom's Taxonomy, Gamification", desc: "Converted core science units into digital flashcards, mind maps, and interactive formative quizzes." }
        ],
        skillsTech: ["AI in Education (EdTech)", "5E Lesson Planning & Rubrics", "Virtual Classrooms & LMS", "Interactive Whiteboards & STEM Simulators"],
        skillsSoft: ["Positive Classroom Management", "Differentiated & Inclusive Instruction (IEP)", "Parent-Teacher Communication", "Formative & Summative Assessment"],
        languages: ["Arabic (Native Proficiency)", "English (Very Good — Academic & Scientific Terminology)"],
        certs: ["AI Integration in Modern Education Certificate — 2025", "Active Learning & Inclusive Education (IEP) Diploma — 2024"]
      }
    },
    business: {
      id: "business",
      label: "📊 إدارة أعمال ومحاسبة وريادة (Business & Finance)",
      ar: {
        fullName: "رامي خليل النجار",
        jobTitle: "محلل مالي وإداري وأخصائي تطوير أعمال",
        email: "rami.najjar@edu-pal.ps",
        phone: "+970 59 777 4455",
        location: "الخليل / غزة، فلسطين",
        linkedin: "linkedin.com/in/rami-finance",
        portfolio: "",
        summary: "خريج إدارة أعمال ومحاسبة يتمتع بمهارات متقدمة في التحليل المالي، إعداد الموازنات والتقارير الإدارية، واستخدام Excel المتقدم وأدوات ذكاء الأعمال لتحسين الأداء المؤسسي.",
        education: [
          { degree: "بكالوريوس المحاسبة وإدارة الأعمال", uni: "الجامعة الإسلامية / جامعة الخليل — فلسطين", year: "2022 – 2026", gpa: "89.5% (جيد جداً مرتفع)", gradProject: "دور التحول الرقمي والذكاء الاصطناعي في رفع كفاءة التدقيق المالي في الشركات الفلسطينية" }
        ],
        experience: [
          { role: "محاسب ومتدرب تحليل مالي", company: "مكتب الشرق للتدقيق والاستشارات المالية", period: "2025 – حتى الآن", details: "• إعداد ومراجعة القيود المحاسبية والقوائم المالية الشهرية والسنوية بدقة عالية.\n• تصميم لوحات متابعة مالية ونماذج توقعات نقدية باستخدام Excel." }
        ],
        projects: [
          { name: "دراسة جدوى اقتصادية لمشروع ريادي تقني", tech: "Financial Modeling, Excel, Market Analysis", desc: "إعداد خطة عمل متكاملة وتحليل التدفقات النقدية ونقطة التعادل." }
        ],
        skillsTech: ["التحليل المالي وإعداد القوائم", "Microsoft Excel المتقدم", "برامج المحاسبة (الأصيل / الشامل)", "دراسات الجدوى وإدارة المشاريع"],
        skillsSoft: ["التفاوض وإقناع العملاء", "الدقة والأمانة المهنية", "حل المشكلات الإدارية", "العمل تحت الضغط"],
        languages: ["اللغة العربية (اللغة الأم)", "اللغة الإنجليزية (جيد جداً في المراسلات التجارية والمصطلحات المالية)"],
        certs: ["دورة المحاسب المهني المعتمد والتدقيق العملي — 2025", "شهادة التحليل المالي المتقدم باستخدام Excel — 2024"]
      },
      en: {
        fullName: "Rami Khalil Al-Najjar",
        jobTitle: "Financial Analyst & Business Development Specialist",
        email: "rami.najjar@edu-pal.ps",
        phone: "+970 59 777 4455",
        location: "Hebron / Gaza, Palestine",
        linkedin: "linkedin.com/in/rami-finance",
        portfolio: "",
        summary: "Detail-oriented Accounting & Business Administration graduate skilled in financial statement analysis, budgeting, cash-flow forecasting, and advanced Excel modeling to drive operational efficiency.",
        education: [
          { degree: "B.Sc. in Accounting & Business Administration", uni: "Islamic University / Hebron University — Palestine", year: "2022 – 2026", gpa: "89.5% (Very Good)", gradProject: "Role of Digital Transformation & AI in Enhancing Financial Auditing Efficiency" }
        ],
        experience: [
          { role: "Junior Accountant & Financial Analyst Intern", company: "Al-Sharq Auditing & Financial Advisory", period: "2025 – Present", details: "• Prepared and reconciled monthly ledger entries, balance sheets, and income statements.\n• Built automated financial dashboards and budget variance templates in Microsoft Excel." }
        ],
        projects: [
          { name: "Comprehensive Feasibility Study for Tech Startup", tech: "Financial Modeling, Break-Even Analysis, Excel", desc: "Developed a 3-year financial projection, market sizing study, and operational budget." }
        ],
        skillsTech: ["Financial Statement Analysis", "Advanced Microsoft Excel", "ERP & Accounting Software", "Feasibility Studies & Budgeting"],
        skillsSoft: ["Business Negotiation", "High Attention to Detail", "Strategic Planning", "Client Relationship Management"],
        languages: ["Arabic (Native)", "English (Very Good — Business Correspondence & Financial Reporting)"],
        certs: ["Practical Accounting & Financial Auditing Certificate — 2025", "Advanced Financial Modeling with Excel — 2024"]
      }
    },
    academic: {
      id: "academic",
      label: "🔬 سيرة أكاديمية وبحثية للمنح والجامعات (Academic / Scholarship CV)",
      ar: {
        fullName: "ليان سامي منصور",
        jobTitle: "باحثة أكاديمية وطالبة دراسات عليا — العلوم التطبيقية",
        email: "layan.mansour@edu-pal.ps",
        phone: "+970 59 555 8899",
        location: "القدس، فلسطين",
        linkedin: "linkedin.com/in/layan-research",
        portfolio: "orcid.org/0000-0002-1234",
        summary: "باحثة أكاديمية متفوقة حاصلة على مرتبة الشرف الأولى، متخصصة في البحث العلمي التطبيقي وتحليل البيانات الإحصائية وكتابة الأوراق البحثية الرصينة، وأتطلع للالتحاق ببرنامج المنح للدراسات العليا.",
        education: [
          { degree: "بكالوريوس العلوم التطبيقية والحيوية (مرتبة الشرف الأولى)", uni: "جامعة القدس — فلسطين", year: "2022 – 2026", gpa: "95.2% (الأولى على الدفعة)", gradProject: "بحث تطبيقي محكّم حول تطبيقات التقنية الحيوية والبيانات في البيئة الفلسطينية" }
        ],
        experience: [
          { role: "مساعدة باحث في المختبر المركزي", company: "عمادة البحث العلمي — جامعة القدس", period: "2024 – 2026", details: "• إجراء التجارب المخبرية المنهجية وتحليل العينات وتوثيق النتائج البحثية.\n• المساهمة في صياغة ومراجعة ورقتين علميتين للنشر في مجلات محكمة." }
        ],
        projects: [
          { name: "مشروع التخرج البحثي المموّل", tech: "SPSS, Python, Scientific Writing, LaTeX", desc: "دراسة ميدانية ومخبرية شاملة حصلت على جائزة أفضل مشروع بحثي طلابي." }
        ],
        skillsTech: ["منهجيات البحث العلمي الأكاديمي", "التحليل الإحصائي (SPSS / R / Python)", "الكتابة الأكاديمية وLaTeX", "إدارة المراجع (Zotero / Mendeley)"],
        skillsSoft: ["الأمانة والدقة العلمية", "العرض التقديمي في المؤتمرات", "العمل البحثي التعاوني", "التفكير النقدي الاستقصائي"],
        languages: ["اللغة العربية (اللغة الأم)", "اللغة الإنجليزية (متقدم — IELTS 7.5 الأكاديمي)"],
        certs: ["جائزة التفوق الأكاديمي ولوحة الشرف — 2023، 2024، 2025", "شهادة الكتابة العلمية والنشر في المجلات الدولية — 2025"]
      },
      en: {
        fullName: "Layan Sami Mansour",
        jobTitle: "Academic Researcher & Graduate Scholarship Candidate",
        email: "layan.mansour@edu-pal.ps",
        phone: "+970 59 555 8899",
        location: "Jerusalem, Palestine",
        linkedin: "linkedin.com/in/layan-research",
        portfolio: "orcid.org/0000-0002-1234",
        summary: "First-Class Honors graduate and Undergraduate Research Assistant with strong expertise in experimental design, statistical data analysis, and peer-reviewed academic writing. Seeking a graduate research scholarship.",
        education: [
          { degree: "B.Sc. in Applied & Biological Sciences (First-Class Honors)", uni: "Al-Quds University — Palestine", year: "2022 – 2026", gpa: "95.2% (Ranked 1st in Class)", gradProject: "Applied Research on Biotechnology & Environmental Data Analysis in Palestine" }
        ],
        experience: [
          { role: "Undergraduate Research Assistant", company: "Deanship of Scientific Research — Al-Quds University", period: "2024 – 2026", details: "• Conducted laboratory protocols, statistical modeling, and systematic literature reviews.\n• Co-authored 2 research manuscripts prepared for peer-reviewed publication." }
        ],
        projects: [
          { name: "Award-Winning Senior Honors Thesis", tech: "SPSS, Python, LaTeX, Experimental Design", desc: "Comprehensive empirical study awarded Best Undergraduate Research Project." }
        ],
        skillsTech: ["Research Methodology", "Statistical Analysis (SPSS / Python)", "Academic Writing & LaTeX", "Reference Management (Zotero / Mendeley)"],
        skillsSoft: ["Scientific Integrity", "Conference Presentation", "Cross-Disciplinary Collaboration", "Critical Literature Synthesis"],
        languages: ["Arabic (Native)", "English (Advanced Academic — IELTS 7.5 Equivalent)"],
        certs: ["Dean's Honor List Award — 2023, 2024, 2025", "International Academic Writing & Research Ethics Certificate — 2025"]
      }
    }
  };

  // قاموس الترجمة الأكاديمي والمهني المدمج (لتحويل السيرة الذاتية بين العربية والإنجليزية فوراً حتى بلا إنترنت)
  var TERM_DICT_AR_TO_EN = [
    ["جامعة بيرزيت", "Birzeit University"],
    ["جامعة النجاح الوطنية", "An-Najah National University"],
    ["الجامعة الإسلامية", "Islamic University of Gaza"],
    ["جامعة الأزهر", "Al-Azhar University"],
    ["جامعة القدس المفتوحة", "Al-Quds Open University"],
    ["جامعة القدس", "Al-Quds University"],
    ["جامعة الخليل", "Hebron University"],
    ["جامعة بوليتكنك فلسطين", "Palestine Polytechnic University"],
    ["جامعة الأقصى", "Al-Aqsa University"],
    ["جامعة بيت لحم", "Bethlehem University"],
    ["الجامعة العربية الأمريكية", "Arab American University (AAUP)"],
    ["جامعة خضوري", "Palestine Technical University - Kadoorie"],
    ["بكالوريوس", "B.Sc. / B.A. in"],
    ["ماجستير", "M.Sc. / M.A. in"],
    ["دبلوم", "Diploma in"],
    ["هندسة حاسوب", "Computer Engineering"],
    ["هندسة أنظمة الحاسوب", "Computer Systems Engineering"],
    ["علم الحاسوب", "Computer Science"],
    ["تكنولوجيا المعلومات", "Information Technology"],
    ["الذكاء الاصطناعي", "Artificial Intelligence"],
    ["إدارة الأعمال", "Business Administration"],
    ["المحاسبة", "Accounting"],
    ["التربية", "Education"],
    ["معلم", "Teacher / Educator"],
    ["مهندس برمجيات", "Software Engineer"],
    ["فلسطين", "Palestine"],
    ["امتياز", "Excellent / Honors"],
    ["جيد جداً", "Very Good"],
    ["اللغة العربية", "Arabic Language"],
    ["اللغة الإنجليزية", "English Language"]
  ];

  function normalizeCvLang(obj, defObj) {
    var d = Object.assign({}, JSON.parse(JSON.stringify(defObj)), obj || {});
    ["education", "experience", "skillsTech", "skillsSoft", "projects", "certs", "languages"].forEach(function (k) {
      if (!Array.isArray(d[k])) d[k] = JSON.parse(JSON.stringify(defObj[k] || []));
    });
    return d;
  }
  function loadState() {
    try {
      var raw = JSON.parse(localStorage.getItem(CV_STORAGE_KEY) || "null");
      if (raw && typeof raw === "object" && raw.ar && raw.en) {
        var pKey = (raw.presetId && CV_PRESETS[raw.presetId]) ? raw.presetId : "cs_ai";
        raw.ar = normalizeCvLang(raw.ar, CV_PRESETS[pKey].ar);
        raw.en = normalizeCvLang(raw.en, CV_PRESETS[pKey].en);
        return raw;
      }
    } catch (e) {}
    return {
      presetId: "cs_ai",
      langMode: "both", // ar | en | both
      templateStyle: "ats", // ats | modern | academic | twocol
      activeTab: "editor", // editor | preview | coverletter
      ar: JSON.parse(JSON.stringify(CV_PRESETS.cs_ai.ar)),
      en: JSON.parse(JSON.stringify(CV_PRESETS.cs_ai.en)),
      coverLetterAr: "",
      coverLetterEn: ""
    };
  }

  var CVState = loadState();
  function saveCvState() {
    try { localStorage.setItem(CV_STORAGE_KEY, JSON.stringify(CVState)); } catch (e) {}
  }

  // حساب مؤشر قوة السيرة الذاتية وتوافقها مع أنظمة التوظيف ATS (0 - 100%)
  function computeAtsScore() {
    var d = CVState.langMode === "en" ? CVState.en : CVState.ar;
    var score = 0;
    var tips = [];
    if (d.fullName && d.jobTitle && d.email && d.phone) score += 20;
    else tips.push("أكمل الاسم والمسمى الوظيفي والبريد ورقم الهاتف (+20%).");

    if (d.summary && d.summary.length >= 60) score += 15;
    else tips.push("اكتب ملخصاً مهنياً قوياً لا يقل عن سطرين يوضح تخصصك وهدفك (+15%).");

    if (d.education && d.education.length && d.education[0].degree) score += 20;
    else tips.push("أضف بيانات دراستك الجامعية ومشروع التخرج والمعدل (+20%).");

    if (d.experience && d.experience.length && d.experience[0].role) score += 20;
    else tips.push("أضف خبراتك العملية أو التدريب الميداني الجامعي في نقاط واضحة (+20%).");

    if (d.skillsTech && d.skillsTech.length >= 3) score += 15;
    else tips.push("أضف 3 مهارات تقنية أو تخصصية على الأقل (+15%).");

    if (d.projects && d.projects.length && d.projects[0].name) score += 10;
    else tips.push("أضف مشروع التخرج أو مشاريعك الجامعية لإبراز خبرتك التطبيقية (+10%).");

    return { score: Math.min(100, score), tips: tips };
  }

  // الترجمة والتوليد الذكي بين العربية والإنجليزية
  function translateDictText(txt) {
    var out = String(txt || "");
    TERM_DICT_AR_TO_EN.forEach(function (pair) {
      out = out.split(pair[0]).join(pair[1]);
    });
    return out;
  }

  function autoTranslateCv(direction) {
    // direction: "ar2en" or "en2ar"
    if (window.AI && window.AI.ask) {
      var srcObj = direction === "ar2en" ? CVState.ar : CVState.en;
      var targetLangName = direction === "ar2en" ? "English (Professional ATS Resume format)" : "العربية الفصحى المهنية";
      toast("🤖 جارٍ ترجمة وصياغة السيرة الذاتية باحترافية إلى " + targetLangName + "…", "info");
      var prompt = "Translate and professionally adapt the following CV JSON object into " + targetLangName + ". Return ONLY valid JSON with the exact same keys (fullName, jobTitle, email, phone, location, linkedin, portfolio, summary, education, experience, projects, skillsTech, skillsSoft, languages, certs):\n\n" + JSON.stringify(srcObj);
      window.AI.ask(prompt, [], "studio").then(function (res) {
        var clean = String(res || "").replace(/```json|```/gi, "");
        var a = clean.indexOf("{"), b = clean.lastIndexOf("}");
        if (a > -1 && b > a) {
          var parsed = JSON.parse(clean.slice(a, b + 1));
          if (direction === "ar2en") CVState.en = Object.assign({}, CVState.en, parsed);
          else CVState.ar = Object.assign({}, CVState.ar, parsed);
          saveCvState();
          renderCvBuilderStudio();
          toast("✨ تمت الترجمة الاحترافية الكاملة للسيرة الذاتية بنجاح ✓", "success");
          return;
        }
        throw new Error("parse");
      }).catch(function () {
        fallbackTranslate(direction);
      });
    } else {
      fallbackTranslate(direction);
    }
  }

  function fallbackTranslate(direction) {
    if (direction === "ar2en") {
      var a = CVState.ar;
      CVState.en.email = a.email;
      CVState.en.phone = a.phone;
      CVState.en.linkedin = a.linkedin;
      CVState.en.portfolio = a.portfolio;
      CVState.en.jobTitle = translateDictText(a.jobTitle);
      CVState.en.location = translateDictText(a.location);
      if (a.education && a.education[0]) {
        CVState.en.education[0].uni = translateDictText(a.education[0].uni);
        CVState.en.education[0].degree = translateDictText(a.education[0].degree);
        CVState.en.education[0].year = a.education[0].year;
      }
      saveCvState();
      renderCvBuilderStudio();
      toast("🔄 تمت مزامنة وترجمة المصطلحات الجامعية والبيانات الأساسية إلى النسخة الإنجليزية ✓", "success");
    } else {
      var e = CVState.en;
      CVState.ar.email = e.email;
      CVState.ar.phone = e.phone;
      CVState.ar.linkedin = e.linkedin;
      CVState.ar.portfolio = e.portfolio;
      saveCvState();
      renderCvBuilderStudio();
      toast("🔄 تمت مزامنة البيانات الأساسية مع النسخة العربية ✓", "success");
    }
  }

  // توليد خطاب التقديم للوظائف والمنح الجامعية باللغتين (Cover / Motivation Letter)
  function generateBilingualCoverLetter() {
    var a = CVState.ar, e = CVState.en;
    var eduAr = (a.education && a.education[0]) ? (a.education[0].degree + " من " + a.education[0].uni) : "خريج جامعي";
    var eduEn = (e.education && e.education[0]) ? (e.education[0].degree + " from " + e.education[0].uni) : "University Graduate";

    CVState.coverLetterAr =
      "بسم الله الرحمن الرحيم\n" +
      "السادة لجنة القبول والتوظيف المحترمين،\n" +
      "تحية طيبة وبعد،\n\n" +
      "الموضوع: طلب الترشح (" + (a.jobTitle || "فرصة مهنية / منحة جامعية") + ") — " + (a.fullName || "") + "\n\n" +
      "يسعدني التقدم إليكم بطلبي هذا، حيث أنني حاصل على " + eduAr + "، ولدي شغف كبير وخبرة تطبيقية في مجال (" + (a.skillsTech || []).slice(0, 4).join("، ") + ").\n\n" +
      (a.summary || "") + "\n\n" +
      "خلال مسيرتي الجامعية والعملية، عملت على تطوير مشاريع نوعية وتطبيق أحدث الممارسات المهنية والتقنية، وأتطلع للمساهمة الفاعلة في مؤسستكم الموقرة.\n\n" +
      "مرفق لكم سيرتي الذاتية المفصلة، وتفضلوا بقبول فائق الاحترام والتقدير.\n\n" +
      "مقدمه: " + (a.fullName || "") + "\n" +
      "الهاتف: " + (a.phone || "") + " | البريد: " + (a.email || "");

    CVState.coverLetterEn =
      "Dear Hiring Manager / Scholarship Admissions Committee,\n\n" +
      "Subject: Application for " + (e.jobTitle || "Professional / Academic Opportunity") + " — " + (e.fullName || "") + "\n\n" +
      "I am writing to express my strong interest in this opportunity. As a graduate holding a " + eduEn + ", I bring solid academic foundations and hands-on expertise in " + (e.skillsTech || []).slice(0, 4).join(", ") + ".\n\n" +
      (e.summary || "") + "\n\n" +
      "Throughout my academic and practical journey, I have delivered impactful projects and demonstrated strong analytical, teamwork, and leadership skills. I would welcome the opportunity to discuss how my background aligns with your goals.\n\n" +
      "Thank you for your time and consideration.\n\n" +
      "Sincerely,\n" +
      (e.fullName || "") + "\n" +
      "Phone: " + (e.phone || "") + " | Email: " + (e.email || "");

    saveCvState();
    renderCvBuilderStudio();
    toast("✉️ تم توليد خطاب التقديم (Cover & Motivation Letter) باللغتين العربية والإنجليزية ✓", "success");
  }

  // ==================== 2. بناء ورقة السيرة الذاتية الاحترافية القابلة للطباعة (عربي RTL / إنجليزي LTR) ====================
  function renderSingleCvSheetHtml(data, lang, styleMode) {
    var isAr = lang === "ar";
    var dir = isAr ? "rtl" : "ltr";
    var align = isAr ? "text-right" : "text-left";
    var lbl = isAr ? {
      summary: "الملخص المهني والهدف الوظيفي",
      education: "التعليم الجامعي والأكاديمي",
      experience: "الخبرات العملية والتدريب الميداني",
      projects: "المشاريع الجامعية والتطبيقية",
      skillsTech: "المهارات التقنية والتخصصية",
      skillsSoft: "المهارات الشخصية والقيادية",
      languages: "اللغات",
      certs: "الشهادات والدورات والجوائز",
      gpa: "المعدل التراكمي:",
      gradProj: "مشروع التخرج:"
    } : {
      summary: "PROFESSIONAL SUMMARY",
      education: "EDUCATION & ACADEMIC BACKGROUND",
      experience: "WORK EXPERIENCE & INTERNSHIPS",
      projects: "KEY ACADEMIC & TECHNICAL PROJECTS",
      skillsTech: "TECHNICAL & CORE SKILLS",
      skillsSoft: "SOFT & LEADERSHIP SKILLS",
      languages: "LANGUAGES",
      certs: "CERTIFICATIONS & HONORS",
      gpa: "GPA:",
      gradProj: "Graduation Project:"
    };

    var headerThemes = {
      ats: "border-b-2 border-slate-900 pb-4 text-slate-900",
      modern: "bg-gradient-to-l from-slate-900 via-indigo-950 to-brand-900 text-white p-6 rounded-2xl shadow",
      academic: "border-b-4 border-indigo-800 pb-4 text-slate-900",
      twocol: "bg-slate-900 text-white p-5 rounded-2xl"
    };
    var hCls = headerThemes[styleMode] || headerThemes.ats;
    var secTitleCls = styleMode === "modern"
      ? "text-xs sm:text-sm font-black text-indigo-800 bg-indigo-50 px-3 py-1.5 rounded-lg border-r-4 border-indigo-600 mb-2.5 uppercase tracking-wide"
      : "text-xs sm:text-sm font-black text-slate-900 border-b-2 border-slate-300 pb-1 mb-2.5 uppercase tracking-wide";

    var contactItems = [
      data.email ? '<span>✉ ' + esc(data.email) + '</span>' : '',
      data.phone ? '<span dir="ltr">☎ ' + esc(data.phone) + '</span>' : '',
      data.location ? '<span>📍 ' + esc(data.location) + '</span>' : '',
      data.linkedin ? '<span>🔗 ' + esc(data.linkedin) + '</span>' : '',
      data.portfolio ? '<span>🌐 ' + esc(data.portfolio) + '</span>' : ''
    ].filter(Boolean).join('<span class="mx-1.5 opacity-50">•</span>');

    return '<div dir="' + dir + '" class="cv-printable-sheet bg-white text-slate-900 rounded-2xl border border-slate-300 shadow-lg p-6 sm:p-8 space-y-4 ' + align + '" style="font-family: Cairo, Arial, sans-serif;">' +
      // ترويسة السيرة الذاتية
      '<div class="' + hCls + '">' +
        '<h2 class="text-xl sm:text-2xl font-black tracking-tight">' + esc(data.fullName || (isAr ? "الاسم الكامل" : "Full Name")) + '</h2>' +
        '<div class="text-xs sm:text-sm font-extrabold mt-1 ' + (styleMode === "modern" || styleMode === "twocol" ? "text-amber-300" : "text-indigo-700") + '">' + esc(data.jobTitle || "") + '</div>' +
        '<div class="flex flex-wrap items-center gap-y-1 text-[11px] font-semibold mt-2 opacity-90">' + contactItems + '</div>' +
      '</div>' +

      // الملخص المهني
      (data.summary
        ? '<div>' +
            '<h3 class="' + secTitleCls + '">' + lbl.summary + '</h3>' +
            '<p class="text-xs leading-relaxed text-slate-700 font-medium">' + esc(data.summary) + '</p>' +
          '</div>'
        : '') +

      // التعليم الجامعي
      ((data.education || []).length
        ? '<div>' +
            '<h3 class="' + secTitleCls + '">' + lbl.education + '</h3>' +
            '<div class="space-y-2.5">' +
              data.education.map(function (ed) {
                return '<div>' +
                  '<div class="flex flex-wrap items-baseline justify-between gap-2">' +
                    '<div class="text-xs sm:text-sm font-black text-slate-900">' + esc(ed.degree) + ' — <span class="text-indigo-700">' + esc(ed.uni) + '</span></div>' +
                    '<span class="text-[11px] font-bold text-slate-600">' + esc(ed.year) + '</span>' +
                  '</div>' +
                  '<div class="text-[11px] text-slate-700 mt-0.5 space-y-0.5">' +
                    (ed.gpa ? '<div><b>' + lbl.gpa + '</b> ' + esc(ed.gpa) + '</div>' : '') +
                    (ed.gradProject ? '<div><b>' + lbl.gradProj + '</b> ' + esc(ed.gradProject) + '</div>' : '') +
                  '</div>' +
                '</div>';
              }).join("") +
            '</div>' +
          '</div>'
        : '') +

      // الخبرات العملية والتدريب
      ((data.experience || []).length
        ? '<div>' +
            '<h3 class="' + secTitleCls + '">' + lbl.experience + '</h3>' +
            '<div class="space-y-3">' +
              data.experience.map(function (ex) {
                return '<div>' +
                  '<div class="flex flex-wrap items-baseline justify-between gap-2">' +
                    '<div class="text-xs sm:text-sm font-black text-slate-900">' + esc(ex.role) + ' | <span class="text-indigo-700">' + esc(ex.company) + '</span></div>' +
                    '<span class="text-[11px] font-bold text-slate-600">' + esc(ex.period) + '</span>' +
                  '</div>' +
                  '<div class="text-xs leading-relaxed text-slate-700 whitespace-pre-line mt-1 font-medium">' + esc(ex.details) + '</div>' +
                '</div>';
              }).join("") +
            '</div>' +
          '</div>'
        : '') +

      // المشاريع الجامعية
      ((data.projects || []).length
        ? '<div>' +
            '<h3 class="' + secTitleCls + '">' + lbl.projects + '</h3>' +
            '<div class="space-y-2">' +
              data.projects.map(function (pr) {
                return '<div>' +
                  '<div class="flex flex-wrap items-baseline justify-between gap-2">' +
                    '<span class="text-xs font-black text-slate-900">' + esc(pr.name) + '</span>' +
                    (pr.tech ? '<span class="text-[10px] font-extrabold px-2 py-0.5 rounded bg-slate-100 text-indigo-700">' + esc(pr.tech) + '</span>' : '') +
                  '</div>' +
                  '<p class="text-xs text-slate-700 mt-0.5 leading-relaxed">' + esc(pr.desc) + '</p>' +
                '</div>';
              }).join("") +
            '</div>' +
          '</div>'
        : '') +

      // المهارات واللغات والشهادات
      '<div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">' +
        '<div>' +
          '<h3 class="' + secTitleCls + '">' + lbl.skillsTech + '</h3>' +
          '<div class="flex flex-wrap gap-1.5">' +
            (data.skillsTech || []).map(function (sk) {
              return '<span class="px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200 text-slate-800 text-[11px] font-bold">' + esc(sk) + '</span>';
            }).join("") +
          '</div>' +
          ((data.skillsSoft || []).length
            ? '<h3 class="' + secTitleCls + ' mt-3">' + lbl.skillsSoft + '</h3>' +
              '<div class="flex flex-wrap gap-1.5">' +
                data.skillsSoft.map(function (sk) {
                  return '<span class="px-2.5 py-1 rounded-lg bg-indigo-50 border border-indigo-100 text-indigo-900 text-[11px] font-bold">' + esc(sk) + '</span>';
                }).join("") +
              '</div>'
            : '') +
        '</div>' +
        '<div>' +
          '<h3 class="' + secTitleCls + '">' + lbl.languages + '</h3>' +
          '<ul class="text-xs text-slate-700 space-y-1 font-semibold mb-3">' +
            (data.languages || []).map(function (lg) { return '<li>• ' + esc(lg) + '</li>'; }).join("") +
          '</ul>' +
          ((data.certs || []).length
            ? '<h3 class="' + secTitleCls + '">' + lbl.certs + '</h3>' +
              '<ul class="text-xs text-slate-700 space-y-1 font-semibold">' +
                data.certs.map(function (c) { return '<li>🏅 ' + esc(c) + '</li>'; }).join("") +
              '</ul>'
            : '') +
        '</div>' +
      '</div>' +
    '</div>';
  }

  // تصدير وطباعة PDF احترافي أو تنزيل Word (.doc) أو Markdown (.md)
  function printCvDocument(mode) {
    var htmlBody = "";
    if (mode === "ar") {
      htmlBody = renderSingleCvSheetHtml(CVState.ar, "ar", CVState.templateStyle);
    } else if (mode === "en") {
      htmlBody = renderSingleCvSheetHtml(CVState.en, "en", CVState.templateStyle);
    } else {
      htmlBody = renderSingleCvSheetHtml(CVState.ar, "ar", CVState.templateStyle) +
        '<div style="page-break-before: always; margin-top: 24px;"></div>' +
        renderSingleCvSheetHtml(CVState.en, "en", CVState.templateStyle);
    }
    var docHtml = '<!DOCTYPE html><html lang="ar"><head><meta charset="utf-8"><title>CV — ' + esc(CVState.en.fullName || CVState.ar.fullName) + '</title>' +
      '<script src="https://cdn.tailwindcss.com/3.4.17"><\/script>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:12mm}body{font-family:Cairo,Arial,sans-serif;background:#fff;margin:0;padding:0}.cv-printable-sheet{border:none!important;box-shadow:none!important;padding:0!important}</style>' +
      '</head><body>' + htmlBody + '</body></html>';

    var f = document.createElement("iframe");
    f.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0";
    document.body.appendChild(f);
    f.contentDocument.open();
    f.contentDocument.write(docHtml);
    f.contentDocument.close();
    setTimeout(function () {
      try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) {}
      setTimeout(function () { f.remove(); }, 5000);
    }, 900);
  }

  function exportCvAsWord() {
    var sheetAr = renderSingleCvSheetHtml(CVState.ar, "ar", CVState.templateStyle);
    var sheetEn = renderSingleCvSheetHtml(CVState.en, "en", CVState.templateStyle);
    var docContent = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>CV</title></head><body style="font-family:Cairo,Arial,sans-serif">' + sheetAr + '<br><hr><br>' + sheetEn + '</body></html>';
    var blob = new Blob(['\ufeff', docContent], { type: "application/msword;charset=utf-8" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "Professional_CV_" + (CVState.en.fullName || "Graduate").replace(/\s+/g, "_") + "_AR_EN.doc";
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { a.remove(); }, 400);
    toast("📄 تم تنزيل السيرة الذاتية المزدوجة (عربي + إنجليزي) بصيغة Word (.doc) ✓", "success");
  }

  function cvToMarkdownString() {
    var a = CVState.ar, e = CVState.en;
    return "# السيرة الذاتية الاحترافية — " + a.fullName + " | " + e.fullName + "\n\n" +
      "## القسم الأول: النسخة العربية (" + a.jobTitle + ")\n" +
      "- **البريد الإلكتروني:** " + a.email + " | **الهاتف:** " + a.phone + " | **الموقع:** " + a.location + "\n" +
      "- **الملخص المهني:** " + a.summary + "\n" +
      "- **التعليم الجامعي:** " + ((a.education && a.education[0]) ? (a.education[0].degree + " — " + a.education[0].uni + " (" + a.education[0].gpa + ")") : "") + "\n" +
      "- **المهارات التقنية:** " + (a.skillsTech || []).join("، ") + "\n\n" +
      "## Section 2: English CV (" + e.jobTitle + ")\n" +
      "- **Email:** " + e.email + " | **Phone:** " + e.phone + " | **Location:** " + e.location + "\n" +
      "- **Professional Summary:** " + e.summary + "\n" +
      "- **Education:** " + ((e.education && e.education[0]) ? (e.education[0].degree + " — " + e.education[0].uni + " (" + e.education[0].gpa + ")") : "") + "\n" +
      "- **Technical Skills:** " + (e.skillsTech || []).join(", ") + "\n";
  }

  function exportCvAsMarkdownAndSaveDb() {
    var md = cvToMarkdownString();
    var blob = new Blob([md], { type: "text/markdown;charset=utf-8" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "CV_" + (CVState.en.fullName || "Graduate").replace(/\s+/g, "_") + ".md";
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { a.remove(); }, 400);
    if (window.EduSources && window.EduSources.addRaw) {
      window.EduSources.addRaw({
        kind: "md",
        name: "السيرة_الذاتية_" + (CVState.ar.fullName || "الجامعية") + ".md",
        mime: "text/markdown",
        markdown: md,
        data: btoa(unescape(encodeURIComponent(md)))
      }, true);
    }
    toast("📝 تم تنزيل السيرة الذاتية بصيغة Markdown وحفظها في قاعدة بيانات الموقع ✓", "success");
  }

  // ==================== 3. بناء واجهة استوديو السيرة الذاتية والخيار الجامعي (#cvBuilderStudio) ====================
  function ensureCvStudioSection() {
    var ex = $("cvBuilderStudio");
    if (ex) return ex;
    var anchor = $("tawjihiStudio") || $("portfolioStudio") || $("publicHubStudio") || $("learnSection");
    if (!anchor || !anchor.parentNode) return null;
    var sec = document.createElement("section");
    sec.id = "cvBuilderStudio";
    sec.className = "py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20";
    anchor.parentNode.insertBefore(sec, anchor);
    return sec;
  }

  function renderCvBuilderStudio() {
    var sec = ensureCvStudioSection();
    if (!sec) return;
    var ats = computeAtsScore();
    var editLang = CVState.langMode === "en" ? "en" : "ar";
    var curData = CVState[editLang];
    var ed0 = (curData.education && curData.education[0]) || { degree: "", uni: "", year: "", gpa: "", gradProject: "" };
    var ex0 = (curData.experience && curData.experience[0]) || { role: "", company: "", period: "", details: "" };
    var pr0 = (curData.projects && curData.projects[0]) || { name: "", tech: "", desc: "" };
    var inpCls = "w-full text-xs font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100 outline-none focus:border-brand-500";

    sec.innerHTML =
      '<div class="glass-card rounded-3xl border-2 border-indigo-500/35 dark:border-slate-700 shadow-2xl overflow-hidden text-right">' +
        // 1. Header Banner
        '<div class="p-5 sm:p-6 bg-gradient-to-l from-slate-950 via-indigo-950 to-brand-900 text-white">' +
          '<div class="flex flex-wrap items-center justify-between gap-3">' +
            '<div>' +
              '<div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-black mb-1.5">' +
                '<span>🎓 الخيار الجامعي والتأهيل المهني • منشئ السيرة الذاتية الاحترافية (Arabic & English ATS CV)</span>' +
              '</div>' +
              '<h2 class="text-lg sm:text-2xl font-black">صمّم سيرة ذاتية احترافية باللغتين العربية والإنجليزية لطلاب الجامعات والخريجين والمعلمين</h2>' +
              '<p class="text-xs text-slate-200 mt-1">قوالب جاهزة متوافقة مع أنظمة التوظيف العالمية (ATS)، ترجمة فورية بين العربية والإنجليزية، خطاب تقديم للمنح والوظائف، وتصدير PDF وWord وMarkdown.</p>' +
            '</div>' +
            '<div class="flex flex-wrap gap-2">' +
              '<button type="button" id="cvPrintBothBtn" class="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow flex items-center gap-1.5">' +
                '<i class="fa-solid fa-print"></i><span>طباعة / PDF (عربي + إنجليزي)</span>' +
              '</button>' +
              '<button type="button" id="cvExportWordBtn" class="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-black shadow flex items-center gap-1.5">' +
                '<i class="fa-solid fa-file-word"></i><span>تنزيل Word (.doc)</span>' +
              '</button>' +
              '<button type="button" id="cvExportMdBtn" class="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow flex items-center gap-1.5">' +
                '<span>📝 حفظ كـ Markdown بالقاعدة</span>' +
              '</button>' +
              '<button type="button" id="cvGoInterviewStudioBtn" class="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-black shadow flex items-center gap-1.5">' +
                '<span>🎤 محاكي المقابلات والأبحاث الجامعية</span>' +
              '</button>' +
            '</div>' +
          '</div>' +

          // 2. Presets + Language Mode + Template Style
          '<div class="mt-4 pt-4 border-t border-white/15 grid grid-cols-1 lg:grid-cols-12 gap-3 items-center">' +
            '<div class="lg:col-span-5 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">' +
              '<label class="text-xs font-black text-amber-300 shrink-0">🎓 اختر تخصصك الجامعي (قالب جاهز):</label>' +
              '<select id="cvPresetSelect" class="flex-1 text-xs font-extrabold bg-slate-900 text-white border border-white/25 rounded-xl px-3 py-2 outline-none">' +
                Object.keys(CV_PRESETS).map(function (k) {
                  var p = CV_PRESETS[k];
                  return '<option value="' + k + '"' + (CVState.presetId === k ? " selected" : "") + '>' + esc(p.label) + '</option>';
                }).join("") +
              '</select>' +
            '</div>' +
            '<div class="lg:col-span-4 flex flex-wrap items-center gap-1.5">' +
              [
                { id: "both", label: "🌐 عربي + English معاً" },
                { id: "ar", label: "🇸🇦 العربية (RTL)" },
                { id: "en", label: "🇬🇧 English (LTR)" }
              ].map(function (lm) {
                var on = CVState.langMode === lm.id;
                return '<button type="button" data-cv-lang="' + lm.id + '" class="px-3 py-1.5 rounded-xl text-xs font-extrabold transition ' +
                  (on ? "bg-amber-400 text-slate-950 font-black shadow" : "bg-white/10 hover:bg-white/20 text-slate-200") + '">' + lm.label + '</button>';
              }).join("") +
            '</div>' +
            '<div class="lg:col-span-3 flex flex-wrap items-center justify-end gap-1">' +
              [
                { id: "ats", label: "🏛️ ATS قياسي" },
                { id: "modern", label: "✨ عصري" },
                { id: "academic", label: "🎓 أكاديمي" }
              ].map(function (st) {
                var on = CVState.templateStyle === st.id;
                return '<button type="button" data-cv-style="' + st.id + '" class="px-2.5 py-1.5 rounded-xl text-[11px] font-extrabold transition ' +
                  (on ? "bg-brand-500 text-white font-black" : "bg-white/10 text-slate-300") + '">' + st.label + '</button>';
              }).join("") +
            '</div>' +
          '</div>' +
        '</div>' +

        // 3. ATS Score Meter + Sub-Tabs Bar
        '<div class="px-4 sm:px-6 py-3 bg-slate-100 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">' +
          '<div class="flex flex-wrap items-center gap-2">' +
            [
              { id: "editor", ico: "✏️", label: "تحرير السيرة الذاتية والمعاينة الحية" },
              { id: "preview", ico: "👁️", label: "معاينة كاملة للطباعة (عربي + إنجليزي)" },
              { id: "coverletter", ico: "✉️", label: "خطاب التقديم للمنح والوظائف (Cover Letter)" }
            ].map(function (tb) {
              var on = CVState.activeTab === tb.id;
              return '<button type="button" data-cv-tab="' + tb.id + '" class="px-3.5 py-1.5 rounded-xl text-xs font-black transition ' +
                (on ? "bg-brand-600 text-white shadow" : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">' + tb.ico + ' ' + tb.label + '</button>';
            }).join("") +
          '</div>' +
          '<div class="flex items-center gap-2 text-xs font-bold">' +
            '<span>مؤشر جودة السيرة (ATS Score):</span>' +
            '<div class="w-28 h-2.5 rounded-full bg-slate-300 dark:bg-slate-700 overflow-hidden"><div class="h-full bg-emerald-500 transition-all" style="width:' + ats.score + '%"></div></div>' +
            '<span class="font-black text-emerald-600 dark:text-emerald-400">' + ats.score + '%</span>' +
          '</div>' +
        '</div>' +

        // 4. Main Content Area
        '<div class="p-4 sm:p-6">' +
          (CVState.activeTab === "coverletter"
            ? renderCoverLetterTabHtml()
            : CVState.activeTab === "preview"
            ? '<div class="space-y-4">' +
                '<div class="flex flex-wrap items-center justify-between gap-2">' +
                  '<div class="text-sm font-black">👁️ المعاينة النهائية الجاهزة للطباعة والتصدير (A4)</div>' +
                  '<div class="flex flex-wrap gap-2">' +
                    '<button type="button" id="cvPrintArOnly" class="px-3.5 py-1.5 rounded-xl bg-brand-600 text-white text-xs font-black">🖨 طباعة النسخة العربية PDF</button>' +
                    '<button type="button" id="cvPrintEnOnly" class="px-3.5 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-black">🖨 Print English CV PDF</button>' +
                  '</div>' +
                '</div>' +
                '<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">' +
                  '<div><div class="text-xs font-black text-brand-600 mb-2">🇸🇦 النسخة العربية الاحترافية (RTL):</div>' + renderSingleCvSheetHtml(CVState.ar, "ar", CVState.templateStyle) + '</div>' +
                  '<div><div class="text-xs font-black text-indigo-600 mb-2" dir="ltr">🇬🇧 English Professional CV (LTR):</div>' + renderSingleCvSheetHtml(CVState.en, "en", CVState.templateStyle) + '</div>' +
                '</div>' +
              '</div>'
            : '<div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">' +
                // نموذج التحرير السريع (5 أعمدة)
                '<div class="lg:col-span-5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/80 dark:bg-slate-900/60 p-4 space-y-3.5">' +
                  '<div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800 pb-2.5">' +
                    '<span class="text-xs sm:text-sm font-black text-brand-600 dark:text-sky-400">' + (editLang === "en" ? "🇬🇧 تحرير البيانات الإنجليزية (English)" : "🇸🇦 تحرير البيانات العربية") + '</span>' +
                    '<div class="flex gap-1.5">' +
                      '<button type="button" id="cvTranslateArToEn" class="px-2.5 py-1 rounded-lg bg-indigo-600 text-white text-[11px] font-black shadow" title="ترجمة البيانات العربية إلى السيرة الإنجليزية تلقائياً">🔄 ترجم للإنجليزية 🇬🇧</button>' +
                      '<button type="button" id="cvSwitchEditLang" class="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 text-[11px] font-black">' + (editLang === "en" ? "تحرير العربي 🇸🇦" : "Edit English 🇬🇧") + '</button>' +
                    '</div>' +
                  '</div>' +

                  '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">' +
                    '<div><label class="block text-[11px] font-bold mb-1">الاسم الكامل / Full Name</label><input id="cvInpName" value="' + esc(curData.fullName) + '" class="' + inpCls + '"></div>' +
                    '<div><label class="block text-[11px] font-bold mb-1">المسمى الوظيفي أو التخصص / Title</label><input id="cvInpTitle" value="' + esc(curData.jobTitle) + '" class="' + inpCls + '"></div>' +
                    '<div><label class="block text-[11px] font-bold mb-1">البريد الإلكتروني / Email</label><input id="cvInpEmail" dir="ltr" value="' + esc(curData.email) + '" class="' + inpCls + '"></div>' +
                    '<div><label class="block text-[11px] font-bold mb-1">رقم الهاتف / Phone</label><input id="cvInpPhone" dir="ltr" value="' + esc(curData.phone) + '" class="' + inpCls + '"></div>' +
                    '<div><label class="block text-[11px] font-bold mb-1">المدينة والدولة / Location</label><input id="cvInpLoc" value="' + esc(curData.location) + '" class="' + inpCls + '"></div>' +
                    '<div><label class="block text-[11px] font-bold mb-1">رابط LinkedIn / GitHub</label><input id="cvInpLink" dir="ltr" value="' + esc(curData.linkedin) + '" class="' + inpCls + '"></div>' +
                  '</div>' +

                  '<div>' +
                    '<div class="flex items-center justify-between mb-1"><label class="text-[11px] font-bold">الملخص المهني / Professional Summary</label><button type="button" id="cvAiPolishSummary" class="text-[10px] font-black text-indigo-600 dark:text-sky-400 hover:underline">✨ تحسين الصياغة بالـ AI</button></div>' +
                    '<textarea id="cvInpSummary" rows="3" class="' + inpCls + '">' + esc(curData.summary) + '</textarea>' +
                  '</div>' +

                  '<div class="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/70 space-y-2">' +
                    '<div class="text-xs font-black text-indigo-700 dark:text-indigo-300">🎓 التعليم الجامعي ومشروع التخرج (Education)</div>' +
                    '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2">' +
                      '<input id="cvInpDegree" value="' + esc(ed0.degree) + '" placeholder="الدرجة والتخصص (مثال: بكالوريوس...)" class="' + inpCls + '">' +
                      '<input id="cvInpUni" value="' + esc(ed0.uni) + '" placeholder="اسم الجامعة" class="' + inpCls + '">' +
                      '<input id="cvInpYear" value="' + esc(ed0.year) + '" placeholder="سنوات الدراسة (2022 - 2026)" class="' + inpCls + '">' +
                      '<input id="cvInpGpa" value="' + esc(ed0.gpa) + '" placeholder="المعدل التراكمي GPA" class="' + inpCls + '">' +
                    '</div>' +
                    '<input id="cvInpGradProj" value="' + esc(ed0.gradProject || "") + '" placeholder="عنوان مشروع التخرج الجامعي (Graduation Project)" class="' + inpCls + '">' +
                  '</div>' +

                  '<div class="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/70 space-y-2">' +
                    '<div class="text-xs font-black text-emerald-700 dark:text-emerald-300">💼 الخبرة العملية والتدريب الميداني (Experience & Internship)</div>' +
                    '<div class="grid grid-cols-1 sm:grid-cols-3 gap-2">' +
                      '<input id="cvInpExpRole" value="' + esc(ex0.role) + '" placeholder="المسمى الوظيفي" class="' + inpCls + '">' +
                      '<input id="cvInpExpComp" value="' + esc(ex0.company) + '" placeholder="الشركة / المؤسسة" class="' + inpCls + '">' +
                      '<input id="cvInpExpPeriod" value="' + esc(ex0.period) + '" placeholder="الفترة الزمنية" class="' + inpCls + '">' +
                    '</div>' +
                    '<textarea id="cvInpExpDetails" rows="3" placeholder="أبرز المهام والإنجازات..." class="' + inpCls + '">' + esc(ex0.details) + '</textarea>' +
                  '</div>' +

                  '<div class="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/70 space-y-2">' +
                    '<div class="text-xs font-black text-amber-700 dark:text-amber-300">🚀 المشاريع الجامعية والمهارات واللغات</div>' +
                    '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2">' +
                      '<input id="cvInpProjName" value="' + esc(pr0.name) + '" placeholder="اسم المشروع الجامعي" class="' + inpCls + '">' +
                      '<input id="cvInpProjTech" value="' + esc(pr0.tech) + '" placeholder="الأدوات والتقنيات المستخدمة" class="' + inpCls + '">' +
                    '</div>' +
                    '<input id="cvInpProjDesc" value="' + esc(pr0.desc) + '" placeholder="وصف مختصر للمشروع" class="' + inpCls + '">' +
                    '<div><label class="block text-[11px] font-bold mb-1">المهارات التقنية (افصل بفاصلة ، أو ,)</label><input id="cvInpSkillsTech" value="' + esc((curData.skillsTech || []).join("، ")) + '" class="' + inpCls + '"></div>' +
                    '<div><label class="block text-[11px] font-bold mb-1">اللغات والشهادات (كل شهادة في سطر)</label><textarea id="cvInpCerts" rows="2" class="' + inpCls + '">' + esc((curData.certs || []).join("\n")) + '</textarea></div>' +
                  '</div>' +
                '</div>' +

                // المعاينة الفورية للسيرة الذاتية (7 أعمدة)
                '<div class="lg:col-span-7 space-y-4">' +
                  '<div class="flex flex-wrap items-center justify-between gap-2">' +
                    '<div class="text-xs sm:text-sm font-black">📄 المعاينة الفورية للسيرة الذاتية (' + (CVState.langMode === "both" ? "النسخة العربية + النسخة الإنجليزية" : CVState.langMode === "en" ? "English Version" : "النسخة العربية") + ')</div>' +
                    '<div class="flex gap-1.5">' +
                      '<button type="button" id="cvQuickPrintAr" class="px-3 py-1 rounded-lg bg-brand-600 text-white text-[11px] font-black">🖨 طباعة العربي</button>' +
                      '<button type="button" id="cvQuickPrintEn" class="px-3 py-1 rounded-lg bg-indigo-600 text-white text-[11px] font-black">🖨 Print English</button>' +
                    '</div>' +
                  '</div>' +
                  '<div id="cvLivePreviewContainer" class="space-y-6">' +
                    (CVState.langMode === "en"
                      ? renderSingleCvSheetHtml(CVState.en, "en", CVState.templateStyle)
                      : CVState.langMode === "ar"
                      ? renderSingleCvSheetHtml(CVState.ar, "ar", CVState.templateStyle)
                      : renderSingleCvSheetHtml(CVState.ar, "ar", CVState.templateStyle) + renderSingleCvSheetHtml(CVState.en, "en", CVState.templateStyle)) +
                  '</div>' +
                '</div>' +
              '</div>'
          ) +
        '</div>' +
      '</div>';

    bindCvBuilderEvents(sec, editLang);
  }

  function renderCoverLetterTabHtml() {
    if (!CVState.coverLetterAr && !CVState.coverLetterEn) {
      generateBilingualCoverLetter();
    }
    return '<div class="space-y-4">' +
      '<div class="flex flex-wrap items-center justify-between gap-2">' +
        '<div>' +
          '<h3 class="text-sm sm:text-base font-black">✉️ خطاب التقديم للوظائف والمنح الجامعية (Cover Letter / Motivation Letter)</h3>' +
          '<p class="text-xs text-slate-500">مولّد تلقائياً باللغتين العربية والإنجليزية من بيانات سيرتك الذاتية ومشروع تخرجك</p>' +
        '</div>' +
        '<button type="button" id="cvRegenCoverBtn" class="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-black shadow">✨ توليد وتحديث الخطاب باللغتين</button>' +
      '</div>' +
      '<div class="grid grid-cols-1 lg:grid-cols-2 gap-4">' +
        '<div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 space-y-2">' +
          '<div class="text-xs font-black text-brand-600">🇸🇦 خطاب التقديم باللغة العربية (RTL):</div>' +
          '<textarea id="cvCoverArTxt" rows="12" class="w-full text-xs font-semibold leading-relaxed p-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700">' + esc(CVState.coverLetterAr) + '</textarea>' +
        '</div>' +
        '<div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 space-y-2" dir="ltr">' +
          '<div class="text-xs font-black text-indigo-600 text-left">🇬🇧 Professional Cover / Motivation Letter (English LTR):</div>' +
          '<textarea id="cvCoverEnTxt" rows="12" class="w-full text-xs font-semibold leading-relaxed p-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-left">' + esc(CVState.coverLetterEn) + '</textarea>' +
        '</div>' +
      '</div>' +
    '</div>';
  }

  function bindCvBuilderEvents(sec, editLang) {
    var pSel = $("cvPresetSelect");
    if (pSel) {
      pSel.onchange = function () {
        var pid = pSel.value;
        var preset = CV_PRESETS[pid];
        if (preset) {
          CVState.presetId = pid;
          CVState.ar = JSON.parse(JSON.stringify(preset.ar));
          CVState.en = JSON.parse(JSON.stringify(preset.en));
          CVState.coverLetterAr = "";
          CVState.coverLetterEn = "";
          saveCvState();
          renderCvBuilderStudio();
          toast("🎓 تم تحميل قالب السيرة الذاتية («" + preset.label + "») باللغتين العربية والإنجليزية ✓", "success");
        }
      };
    }

    sec.querySelectorAll("[data-cv-lang]").forEach(function (b) {
      b.onclick = function () {
        CVState.langMode = b.getAttribute("data-cv-lang");
        saveCvState();
        renderCvBuilderStudio();
      };
    });

    sec.querySelectorAll("[data-cv-style]").forEach(function (b) {
      b.onclick = function () {
        CVState.templateStyle = b.getAttribute("data-cv-style");
        saveCvState();
        renderCvBuilderStudio();
      };
    });

    sec.querySelectorAll("[data-cv-tab]").forEach(function (b) {
      b.onclick = function () {
        CVState.activeTab = b.getAttribute("data-cv-tab");
        saveCvState();
        renderCvBuilderStudio();
      };
    });

    if ($("cvSwitchEditLang")) $("cvSwitchEditLang").onclick = function () {
      CVState.langMode = editLang === "en" ? "ar" : "en";
      saveCvState();
      renderCvBuilderStudio();
    };

    if ($("cvTranslateArToEn")) $("cvTranslateArToEn").onclick = function () {
      autoTranslateCv(editLang === "en" ? "en2ar" : "ar2en");
    };

    if ($("cvPrintBothBtn")) $("cvPrintBothBtn").onclick = function () { printCvDocument("both"); };
    if ($("cvPrintArOnly")) $("cvPrintArOnly").onclick = function () { printCvDocument("ar"); };
    if ($("cvPrintEnOnly")) $("cvPrintEnOnly").onclick = function () { printCvDocument("en"); };
    if ($("cvQuickPrintAr")) $("cvQuickPrintAr").onclick = function () { printCvDocument("ar"); };
    if ($("cvQuickPrintEn")) $("cvQuickPrintEn").onclick = function () { printCvDocument("en"); };
    if ($("cvExportWordBtn")) $("cvExportWordBtn").onclick = exportCvAsWord;
    if ($("cvExportMdBtn")) $("cvExportMdBtn").onclick = exportCvAsMarkdownAndSaveDb;
    if ($("cvGoInterviewStudioBtn")) $("cvGoInterviewStudioBtn").onclick = function () {
      if (window.EduUniCareer && window.EduUniCareer.open) window.EduUniCareer.open("interview");
      else if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("uniResearchCareerStudio", true);
    };
    if ($("cvRegenCoverBtn")) $("cvRegenCoverBtn").onclick = generateBilingualCoverLetter;

    // التحديث اللحظي للمعاينة أثناء الكتابة
    function syncEditorInputs() {
      var target = CVState[editLang];
      if (!target) return;
      if ($("cvInpName")) target.fullName = $("cvInpName").value;
      if ($("cvInpTitle")) target.jobTitle = $("cvInpTitle").value;
      if ($("cvInpEmail")) target.email = $("cvInpEmail").value;
      if ($("cvInpPhone")) target.phone = $("cvInpPhone").value;
      if ($("cvInpLoc")) target.location = $("cvInpLoc").value;
      if ($("cvInpLink")) target.linkedin = $("cvInpLink").value;
      if ($("cvInpSummary")) target.summary = $("cvInpSummary").value;

      target.education = target.education && target.education.length ? target.education : [{}];
      if ($("cvInpDegree")) target.education[0].degree = $("cvInpDegree").value;
      if ($("cvInpUni")) target.education[0].uni = $("cvInpUni").value;
      if ($("cvInpYear")) target.education[0].year = $("cvInpYear").value;
      if ($("cvInpGpa")) target.education[0].gpa = $("cvInpGpa").value;
      if ($("cvInpGradProj")) target.education[0].gradProject = $("cvInpGradProj").value;

      target.experience = target.experience && target.experience.length ? target.experience : [{}];
      if ($("cvInpExpRole")) target.experience[0].role = $("cvInpExpRole").value;
      if ($("cvInpExpComp")) target.experience[0].company = $("cvInpExpComp").value;
      if ($("cvInpExpPeriod")) target.experience[0].period = $("cvInpExpPeriod").value;
      if ($("cvInpExpDetails")) target.experience[0].details = $("cvInpExpDetails").value;

      target.projects = target.projects && target.projects.length ? target.projects : [{}];
      if ($("cvInpProjName")) target.projects[0].name = $("cvInpProjName").value;
      if ($("cvInpProjTech")) target.projects[0].tech = $("cvInpProjTech").value;
      if ($("cvInpProjDesc")) target.projects[0].desc = $("cvInpProjDesc").value;

      if ($("cvInpSkillsTech")) {
        target.skillsTech = $("cvInpSkillsTech").value.split(/[,،]/).map(function (s) { return s.trim(); }).filter(Boolean);
      }
      if ($("cvInpCerts")) {
        target.certs = $("cvInpCerts").value.split(/\r?\n/).map(function (s) { return s.trim(); }).filter(Boolean);
      }

      saveCvState();
      var prevBox = $("cvLivePreviewContainer");
      if (prevBox) {
        prevBox.innerHTML = CVState.langMode === "en"
          ? renderSingleCvSheetHtml(CVState.en, "en", CVState.templateStyle)
          : CVState.langMode === "ar"
          ? renderSingleCvSheetHtml(CVState.ar, "ar", CVState.templateStyle)
          : renderSingleCvSheetHtml(CVState.ar, "ar", CVState.templateStyle) + renderSingleCvSheetHtml(CVState.en, "en", CVState.templateStyle);
      }
    }

    [
      "cvInpName", "cvInpTitle", "cvInpEmail", "cvInpPhone", "cvInpLoc", "cvInpLink", "cvInpSummary",
      "cvInpDegree", "cvInpUni", "cvInpYear", "cvInpGpa", "cvInpGradProj",
      "cvInpExpRole", "cvInpExpComp", "cvInpExpPeriod", "cvInpExpDetails",
      "cvInpProjName", "cvInpProjTech", "cvInpProjDesc", "cvInpSkillsTech", "cvInpCerts"
    ].forEach(function (id) {
      var el = $(id);
      if (el) el.oninput = syncEditorInputs;
    });

    if ($("cvAiPolishSummary")) $("cvAiPolishSummary").onclick = function () {
      var target = CVState[editLang];
      if (window.AI && window.AI.ask) {
        toast("✨ جارٍ تحسين صياغة الملخص المهني بالذكاء الاصطناعي…", "info");
        var prompt = (editLang === "en" ? "Write a concise, high-impact ATS-friendly professional CV summary in English (3 sentences) for: " : "اكتب ملخصاً مهنياً قوياً ومختصراً للسيرة الذاتية متوافقاً مع ATS (في 3 جمل) لتخصص: ") + target.jobTitle + " — " + target.summary;
        window.AI.ask(prompt, [], "studio").then(function (res) {
          if (res && res.trim()) {
            target.summary = res.trim();
            saveCvState();
            renderCvBuilderStudio();
            toast("✨ تم تحسين الملخص المهني بنجاح ✓", "success");
          }
        }).catch(function () {});
      } else {
        target.summary = editLang === "en"
          ? "Results-driven " + target.jobTitle + " with strong academic foundations, hands-on project execution, and proven ability to deliver scalable solutions in collaborative environments."
          : "خريج متميز في مجال (" + target.jobTitle + ")، أمتلك خلفية أكاديمية رصينة وخبرة تطبيقية في تنفيذ المشاريع الاحترافية وتوظيف التقنيات الحديثة لتحقيق أعلى معدلات الكفاءة والابتكار.";
        saveCvState();
        renderCvBuilderStudio();
        toast("✨ تم تحسين الملخص المهني بصياغة احترافية قوية ✓", "success");
      }
    };
  }

  function openCvBuilder(presetKey) {
    if (presetKey && CV_PRESETS[presetKey]) {
      CVState.presetId = presetKey;
      CVState.ar = JSON.parse(JSON.stringify(CV_PRESETS[presetKey].ar));
      CVState.en = JSON.parse(JSON.stringify(CV_PRESETS[presetKey].en));
      saveCvState();
    }
    renderCvBuilderStudio();
    if (window.EduLauncher && window.EduLauncher.jump) {
      window.EduLauncher.jump("cvBuilderStudio", true);
    } else {
      var sec = $("cvBuilderStudio");
      if (sec) sec.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  function init() {
    renderCvBuilderStudio();
    
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();

  window.EduCVBuilder = {
    open: openCvBuilder,
    render: renderCvBuilderStudio,
    presets: CV_PRESETS
  };
})();

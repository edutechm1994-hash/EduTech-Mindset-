/*
 * استوديو التعليم الدامج والدعم النفسي والاجتماعي والقارئ الميسّر — EduTech Mindset (الإصدار 51)
 * مصمم خصيصاً لدعم الطلبة والمعلمين في فلسطين:
 * 1) 💚 أنشطة الدعم النفسي والاجتماعي والتفريغ الانفعالي (PSS & SEL Activities) لبداية الحصة (تعمل بلا إنترنت + توليد بالـ AI).
 * 2) 👓 القارئ البصري الميسّر للطلبة ذوي صعوبات القراءة وتشتت الانتباه (Dyslexia & ADHD Focus Reader)
 *    مع تلوين التشكيل، مسطرة التركيز البصري لسطر واحد، وتقسيم النص لبطاقات مقروءة صوتياً.
 * 3) 🧩 باني الخطة التربوية الفردية (IEP Builder) لطلبة صعوبات التعلّم.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var PSS_ACTIVITIES = [
    {
      title: "🌬️ تمرين تنفّس الهدوء والتركيز (الزهرة والشمعة)",
      dur: "3 دقائق",
      goal: "تخفيف التوتر والقلق واستعادة التركيز الذهني قبل بدء الدرس",
      steps: "1. اطلب من الطلاب الجلوس بظهر مستقيم وإغماض أعينهم بهدوء.\n2. تخيّل أن بيدك اليمنى زهرة طيبة الرائحة، وبيدك اليسرى شمعة.\n3. خذ شهيقاً عميقاً وبطيئاً من الأنف (كأنك تشم الزهرة) لمدة 4 ثوانٍ.\n4. أخرج الزفير ببطء وهدوء من الفم (كأنك تطفئ الشمعة بلطف) لمدة 4 ثوانٍ.\n5. كرر التمرين 4 مرات ثم افتح عينيك بابتسامة."
    },
    {
      title: "🌳 شجرة الامتنان والأمل الصفية",
      dur: "5 دقائق",
      goal: "تعزيز المشاعر الإيجابية والترابط بين الطلاب داخل الصف",
      steps: "1. يرسم المعلم شجرة كبيرة على السبورة.\n2. يذكر كل طالب شيئاً واحداً جميلاً يشعر بالامتنان له اليوم (صديق متعاون، معلومة جديدة، أسرته، معلمه).\n3. يكتب المعلم كلمات الطلاب كأوراق مثمرة على الشجرة لتبقى أمامهم طوال الحصة."
    },
    {
      title: "👏 إيقاع التصفيق الجماعي المتناغم",
      dur: "3 دقائق",
      goal: "تنشيط الحواس وكسر الجمود وتفريغ الطاقة الحركية إيجابياً",
      steps: "1. يقف الطلاب في أماكنهم.\n2. يبدأ المعلم بإيقاع بسيط (صفقتان باليد ثم نقرة على الطاولة) ويكرره الطلاب معاً.\n3. يسرّع المعلم الإيقاع تدريجياً ثم يبطئه حتى يعود الهدوء التام والابتسامة للصف."
    },
    {
      title: "🦸‍♂️ بطاقة «نقطة قوتي الخارقة»",
      dur: "5 دقائق",
      goal: "بناء الثقة بالنفس وتقدير الذات لدى الطلاب",
      steps: "1. يكمل كل طالب الجملة التالية في ورقة صغيرة أو شفهياً: «أكثر شيء أجيده وأحب مساعدة زملائي فيه هو...».\n2. يشارك 5 طلاب إجاباتهم وسط تصفيق وتشجيع زملائهم."
    }
  ];

  var st = {
    tab: "pss", // pss | reader | iep
    pssIdx: 0,
    readerText: "العِلْمُ نُورٌ يُضِيءُ طَرِيقَ الإِنْسَانِ. يَذْهَبُ الطَّالِبُ إِلَى المَدْرَسَةِ كُلَّ صَبَاحٍ بِنَشَاطٍ وَأَمَلٍ. نَحْنُ نَتَعَلَّمُ لِنَبْنِيَ وَطَنَنَا فِلَسْطِينَ بِالمَعْرِفَةِ وَالأَخْلَاقِ الحَمِيدَةِ.",
    fontSize: 24,
    bgTone: "cream", // cream | mint | dark
    focusLineIdx: 0,
    iepName: "",
    iepNeed: "",
    iepOut: ""
  };

  function printIepPdf() {
    if (!st.iepOut) return;
    var nm = ($("incIepName") && $("incIepName").value.trim()) || st.iepName || "طالب";
    var dt = new Date().toLocaleDateString("ar-EG", { year: "numeric", month: "long", day: "numeric" });
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>خطة تربوية فردية (IEP) — ' + e(nm) + '</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:14mm}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a;line-height:1.9;font-size:13.5px}h1{text-align:center;color:#0f766e;margin:0 0 4px}.sub{text-align:center;color:#475569;font-size:12px;margin-bottom:14px;border-bottom:2px solid #cbd5e1;padding-bottom:8px}.box{white-space:pre-line;background:#f8fafc;border:1.5px solid #cbd5e1;border-radius:14px;padding:16px}</style></head><body>' +
      '<h1>🧩 الخطة التربوية الفردية (Individualized Education Plan - IEP)</h1>' +
      '<div class="sub">منصة EduTech Mindset • الطالب/ـة: <b>' + e(nm) + '</b> • التاريخ: ' + dt + '</div>' +
      '<div class="box">' + e(st.iepOut) + '</div>' +
      '<div style="display:flex;justify-content:space-between;margin-top:24px;font-weight:800;font-size:12px"><span>معلم/ـة المادة: ........................</span><span>المرشد التربوي: ........................</span><span>ولي الأمر: ........................</span></div>' +
      '</body></html>';
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
  }

  function colorizeTashkeel(txt) {
    // تلوين الحركات والتشكيل بلون مميز لتسهيل التهجئة البصرية
    return e(txt).replace(/([ً-ٰٟ])/g, '<span style="color:#e11d48;font-weight:900">$1</span>');
  }

  function speakLine(txt) {
    try {
      if (!("speechSynthesis" in window)) return;
      window.speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(txt);
      u.lang = "ar-SA"; u.rate = 0.82;
      window.speechSynthesis.speak(u);
    } catch (x) {}
  }

  function paint() {
    var box = $("incBody"); if (!box) return;
    var tabs = [
      ["pss", "💚 أنشطة الدعم النفسي والتفريغ الانفعالي"],
      ["reader", "👓 القارئ الميسّر لصعوبات القراءة وتشتت الانتباه"],
      ["iep", "🧩 باني الخطة التربوية الفردية (IEP)"]
    ];
    var nav = '<div class="flex flex-wrap gap-2 mb-4 border-b border-slate-200 dark:border-slate-700 pb-3">' +
      tabs.map(function (t) {
        var on = st.tab === t[0];
        return '<button type="button" data-inctab="' + t[0] + '" class="px-4 py-2 rounded-xl text-xs font-extrabold transition-all ' + (on ? "bg-teal-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">' + t[1] + '</button>';
      }).join("") + '</div>';

    var body = "";
    if (st.tab === "pss") {
      var act = PSS_ACTIVITIES[st.pssIdx] || PSS_ACTIVITIES[0];
      body = '<div class="space-y-4">' +
        '<div class="flex flex-wrap gap-2">' +
        PSS_ACTIVITIES.map(function (a, i) {
          return '<button type="button" data-pss="' + i + '" class="px-3.5 py-2 rounded-xl text-xs font-black ' + (st.pssIdx === i ? "bg-emerald-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800") + '">' + e(a.title.slice(0, 26)) + '…</button>';
        }).join("") +
        '<button type="button" id="incAiPss" class="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 text-xs font-black mr-auto">🤖 ولّد نشاط دعم نفسي جديد بالـ AI</button>' +
        '</div>' +
        '<div class="rounded-3xl border-2 border-emerald-500/40 bg-emerald-50/40 dark:bg-slate-900 p-5 space-y-3">' +
        '<div class="flex flex-wrap items-center justify-between gap-2">' +
        '<h3 class="text-lg font-black text-emerald-800 dark:text-emerald-300">' + e(act.title) + '</h3>' +
        '<span class="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 text-xs font-black">⏱ المدة: ' + e(act.dur) + '</span></div>' +
        '<div class="text-xs font-bold text-slate-600 dark:text-slate-300">🎯 الهدف التربوي والنفسي: ' + e(act.goal) + '</div>' +
        '<div class="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-emerald-200 dark:border-slate-700 text-xs sm:text-sm leading-loose whitespace-pre-line font-bold">' + e(act.steps) + '</div>' +
        '</div></div>';
    } else if (st.tab === "reader") {
      var sentences = String(st.readerText || "").split(/([.!\n؟]+)/).reduce(function (acc, part, idx) {
        if (idx % 2 === 0 && part.trim()) acc.push(part.trim());
        else if (idx % 2 === 1 && acc.length) acc[acc.length - 1] += part;
        return acc;
      }, []);
      if (!sentences.length) sentences = [st.readerText];
      if (st.focusLineIdx >= sentences.length) st.focusLineIdx = 0;

      var bgStyle = st.bgTone === "cream" ? "background:#fef9c3;color:#1e293b" : st.bgTone === "mint" ? "background:#d1fae5;color:#064e3b" : "background:#0f172a;color:#f8fafc";

      body = '<div class="space-y-4">' +
        '<div><label class="block text-xs font-bold mb-1">الصق نص القراءة لتقسيمه وتلوين تشكيله وتفعيل مسطرة التركيز البصري:</label>' +
        '<textarea id="incReadInp" rows="2" class="' + cls + '">' + e(st.readerText) + '</textarea></div>' +
        '<div class="flex flex-wrap items-center gap-3 p-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs font-bold">' +
        '<span>حجم الخط:</span><input type="range" id="incFontSz" min="18" max="38" value="' + st.fontSize + '" class="w-28">' +
        '<span>لون الخلفية المريح للعين:</span>' +
        '<button type="button" data-incbg="cream" class="px-3 py-1 rounded-lg bg-yellow-100 text-slate-900 border">أصفر دافئ</button>' +
        '<button type="button" data-incbg="mint" class="px-3 py-1 rounded-lg bg-emerald-100 text-emerald-950 border">أخضر هادئ</button>' +
        '<button type="button" data-incbg="dark" class="px-3 py-1 rounded-lg bg-slate-900 text-white border">داكن عالي التباين</button>' +
        '</div>' +
        '<div style="' + bgStyle + ';font-size:' + st.fontSize + 'px;line-height:2.2;padding:24px;border-radius:24px;border:3px solid #0284c7" class="space-y-3">' +
        sentences.map(function (sent, i) {
          var isFocused = i === st.focusLineIdx;
          return '<div data-incsent="' + i + '" style="padding:10px 16px;border-radius:16px;cursor:pointer;transition:all 0.2s;opacity:' + (isFocused ? "1" : "0.32") + ';border:' + (isFocused ? "3px solid #f59e0b" : "1px solid transparent") + ';background:' + (isFocused ? "rgba(255,255,255,0.22)" : "transparent") + '">' +
            colorizeTashkeel(sent) + '</div>';
        }).join("") + '</div>' +
        '<div class="flex flex-wrap justify-center gap-2">' +
        '<button type="button" id="incPrevSent" class="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-extrabold">➡ الجملة السابقة</button>' +
        '<button type="button" id="incSpeakSent" class="px-6 py-2 rounded-xl bg-emerald-600 text-white text-xs font-black shadow">🔊 انطق هذه الجملة ببطء</button>' +
        '<button type="button" id="incNextSent" class="px-4 py-2 rounded-xl bg-brand-600 text-white text-xs font-extrabold">الجملة التالية ⬅</button>' +
        '</div></div>';
    } else if (st.tab === "iep") {
      body = '<div class="space-y-3">' +
        '<div class="grid grid-cols-1 sm:grid-cols-3 gap-2.5">' +
        '<div><label class="block text-xs font-bold mb-1">اسم الطالب ومرحلته</label><input id="incIepName" value="' + e(st.iepName) + '" placeholder="مثال: طالب في الصف الثالث الأساسي" class="' + cls + '"></div>' +
        '<div class="sm:col-span-2"><label class="block text-xs font-bold mb-1">صعوبة التعلّم أو الاحتياج الفردي الملاحظ</label><input id="incIepNeed" value="' + e(st.iepNeed) + '" placeholder="مثال: عسر القراءة (Dyslexia) والخلط بين الحروف المتشابهة / تشتت الانتباه وفرط الحركة" class="' + cls + '"></div>' +
        '</div>' +
        '<div class="flex flex-wrap gap-2">' +
        '<button type="button" id="incGenIep" class="px-6 py-2.5 rounded-xl bg-teal-600 text-white text-xs font-black shadow">🤖 صمّم الخطة التربوية الفردية (IEP) بالذكاء الاصطناعي</button>' +
        (st.iepOut ? '<button type="button" id="incPrintIep" class="px-5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-black">🖨 طباعة الخطة الفردية (IEP) PDF</button>' : '') +
        '</div>' +
        (st.iepOut ? '<div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs leading-loose whitespace-pre-line font-semibold">' + e(st.iepOut) + '</div>' : '') +
        '</div>';
    }

    box.innerHTML = nav + body;
    box.querySelectorAll("[data-inctab]").forEach(function (b) {
      b.onclick = function () { st.tab = b.dataset.inctab; paint(); };
    });

    if (st.tab === "pss") {
      box.querySelectorAll("[data-pss]").forEach(function (b) {
        b.onclick = function () { st.pssIdx = +b.dataset.pss; paint(); };
      });
      $("incAiPss").onclick = function () {
        var btn = $("incAiPss"); btn.disabled = true; btn.textContent = "⏳ يبتكر نشاطاً…";
        window.AI.ask("ابتكر نشاط دعم نفسي واجتماعي وتفريغ انفعالي قصير (5 دقائق) ومبهج لتنفيذه مع الطلاب داخل الصف في مدارس فلسطين. اذكر العنوان والهدف والخطوات العملية بوضوح.", [], "studio").then(function (txt) {
          PSS_ACTIVITIES.push({ title: "✨ نشاط مبتكر بالـ AI", dur: "5 دقائق", goal: "دعم نفسي وتنشيط إيجابي", steps: txt });
          st.pssIdx = PSS_ACTIVITIES.length - 1;
          paint();
        }).catch(function () { btn.disabled = false; btn.textContent = "🤖 ولّد نشاط دعم نفسي جديد بالـ AI"; });
      };
    } else if (st.tab === "reader") {
      $("incReadInp").oninput = function (ev) { st.readerText = ev.target.value; st.focusLineIdx = 0; paint(); };
      $("incFontSz").oninput = function (ev) { st.fontSize = +ev.target.value; paint(); };
      box.querySelectorAll("[data-incbg]").forEach(function (b) {
        b.onclick = function () { st.bgTone = b.dataset.incbg; paint(); };
      });
      box.querySelectorAll("[data-incsent]").forEach(function (el) {
        el.onclick = function () { st.focusLineIdx = +el.dataset.incsent; paint(); };
      });
      $("incPrevSent").onclick = function () { st.focusLineIdx = Math.max(0, st.focusLineIdx - 1); paint(); };
      $("incNextSent").onclick = function () { st.focusLineIdx++; paint(); };
      $("incSpeakSent").onclick = function () {
        var curEl = box.querySelector('[data-incsent="' + st.focusLineIdx + '"]');
        if (curEl) speakLine(curEl.textContent);
      };
    } else if (st.tab === "iep") {
      $("incGenIep").onclick = function () {
        st.iepName = $("incIepName").value.trim() || "طالب";
        st.iepNeed = $("incIepNeed").value.trim() || "صعوبات تعلم القراءة والتركيز";
        var b = $("incGenIep"); b.disabled = true; b.textContent = "⏳ يبني الخطة الفردية…";
        var p = "أنت أخصائي تربية خاصة وتعليم دامج. صمّم خطة تربوية فردية (IEP) عملية ومبسطة لـ «" + st.iepName + "» يعاني من: «" + st.iepNeed + "»، تشمل: نقاط القوة، الأهداف قصيرة المدى، التسهيلات الصفية، واستراتيجيات التدريس والتقويم المناسبة.";
        window.AI.ask(p, [], "studio").then(function (txt) { st.iepOut = txt; paint(); }).catch(function () { b.disabled = false; b.textContent = "🤖 صمّم الخطة التربوية الفردية (IEP) بالذكاء الاصطناعي"; });
      };
      if ($("incPrintIep")) $("incPrintIep").onclick = printIepPdf;
    }
  }

  function build() {
    if ($("inclusiveStudio")) return true;
    var anchor = $("earlyLearnStudio") || $("langLabStudio") || $("tutorStudio");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "inclusiveStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-teal-700 via-emerald-800 to-slate-900 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-200 mb-1">💚 استوديو التعليم الدامج والدعم النفسي والقارئ الميسّر</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">أنشطة الدعم النفسي والاجتماعي، القارئ الميسّر لصعوبات القراءة، والخطط الفردية (IEP)</h2>' +
      '<p class="text-xs text-white/90 mt-1">أدوات تربوية ونفسية لمساندة طلابنا في غزة ومراعاة الفروق الفردية وصعوبات التعلّم.</p>' +
      '</div><div class="p-4 sm:p-6 text-right" id="incBody"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    paint();
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  function openWithIEP(opts) {
    opts = opts || {};
    st.tab = "iep";
    if (opts.name) st.iepName = opts.name;
    if (opts.need) st.iepNeed = opts.need;
    paint();
    if (window.EduMasterHierarchy && window.EduMasterHierarchy.navigateToTarget) {
      window.EduMasterHierarchy.navigateToTarget("inclusiveStudio");
    } else {
      var sc = $("inclusiveStudio");
      if (sc) { sc.style.display = ""; sc.scrollIntoView({ behavior: "smooth", block: "start" }); }
    }
    toast("تم فتح باني الخطة التربوية الفردية (IEP) مع بيانات الطالب ✓", "success");
  }

  window.EduInclusive = {
    open: function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("inclusiveStudio", true); },
    openWithIEP: openWithIEP
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

/* نظام التشخيص والإصلاح الذاتي ودرع الأمان المتقدم (الإصدار 138):
 * - يفحص ويصلح تلقائياً أي بيانات تالفة في localStorage عند الإقلاع (Self-Healing Engine).
 * - يسجّل الأخطاء البرمجية الحية، ويحصي استخدام الأدوات والأقسام، ويقيس سرعة التحميل وحالة الكاش.
 * - مدمج بالكامل داخل مركز تطوير وإدارة الموقع الموحّد وغرفة القواطع السيادية (للإدارة فقط). */
(function () {
  "use strict";
  var K = "edutech_diag_v153";
  var LEGACY_K = "edutech_diag_v1";
  var bootTime = Date.now();
  var healedCount = 0;

  // محرك الإصلاح الذاتي الفوري (Self-Healing Storage Engine)
  function selfHealStorage() {
    var fixed = 0;
    try {
      // 1. تنظيف الأخطاء القديمة الموروثة من الإصدارات السابقة
      if (localStorage.getItem(LEGACY_K)) {
        try {
          var oldD = JSON.parse(localStorage.getItem(LEGACY_K) || "{}");
          if (oldD && oldD.usage && !localStorage.getItem(K)) {
            localStorage.setItem(K, JSON.stringify({ errors: [], usage: oldD.usage, healedAt: new Date().toISOString() }));
          }
          localStorage.removeItem(LEGACY_K);
          fixed++;
        } catch (e) {}
      }
      // 2. إصلاح حالة visualconcept.js إن كانت ناقصة للكائن exam
      var vcRaw = localStorage.getItem("edu_visual_concept_exam_v87");
      if (vcRaw) {
        try {
          var vc = JSON.parse(vcRaw);
          if (!vc || typeof vc !== "object" || !vc.exam || typeof vc.exam.started === "undefined") {
            vc = Object.assign({ tab: "conceptmap", sourceIdx: 0, mapStyle: "tree", customNodes: [] }, vc || {}, {
              exam: { started: false, submitted: false, durationMins: 10, remSec: 600, curQIdx: 0, answers: {}, flagged: {}, questions: [] }
            });
            localStorage.setItem("edu_visual_concept_exam_v87", JSON.stringify(vc));
            fixed++;
          }
        } catch (e) {
          localStorage.removeItem("edu_visual_concept_exam_v87");
          fixed++;
        }
      }
      // 3. إصلاح حالة smartnotes.js إن كانت ناقصة للكائن clozeScore أو revealedCloze
      var snRaw = localStorage.getItem("edu_smart_notes_v88");
      if (snRaw) {
        try {
          var sn = JSON.parse(snRaw);
          if (!sn || typeof sn !== "object" || !sn.clozeScore || typeof sn.clozeScore.known === "undefined" || !sn.revealedCloze) {
            sn = Object.assign({ tab: "cornell", sourceIdx: 0, hideNotesForRecall: false, customSummary: "" }, sn || {}, {
              revealedCloze: (sn && sn.revealedCloze && typeof sn.revealedCloze === "object") ? sn.revealedCloze : {},
              clozeScore: (sn && sn.clozeScore && typeof sn.clozeScore.known === "number") ? sn.clozeScore : { known: 0, review: 0 }
            });
            localStorage.setItem("edu_smart_notes_v88", JSON.stringify(sn));
            fixed++;
          }
        } catch (e) {
          localStorage.removeItem("edu_smart_notes_v88");
          fixed++;
        }
      }
    } catch (e) {}
    healedCount += fixed;
    return fixed;
  }

  selfHealStorage();

  function load() {
    try {
      return JSON.parse(localStorage.getItem(K)) || { errors: [], usage: {} };
    } catch (e) {
      return { errors: [], usage: {} };
    }
  }
  function save(d) {
    try { localStorage.setItem(K, JSON.stringify(d)); } catch (e) {}
  }
  function logErr(msg, src) {
    var mStr = String(msg || "خطأ غير معروف");
    // تجاهل أخطاء امتدادات المتصفح الخارجية التي لا تخص الموقع
    if (/chrome-extension:|moz-extension:|safari-extension:|ResizeObserver loop/i.test(mStr + " " + String(src || ""))) return;
    var d = load();
    d.errors.push({
      t: new Date().toISOString(),
      m: mStr.slice(0, 300),
      s: String(src || "").slice(0, 120)
    });
    d.errors = d.errors.slice(-50);
    save(d);
    if (window.EduHome && window.EduHome.render) {
      try { window.EduHome.render(); } catch (x) {}
    }
  }
  window.addEventListener("error", function (e) { logErr(e.message, e.filename); });
  window.addEventListener("unhandledrejection", function (e) {
    logErr((e.reason && e.reason.message) || e.reason, "promise");
  });
  document.addEventListener("click", function (e) {
    var el = e.target && e.target.closest && e.target.closest("[data-tool],[data-view],[data-hubopen],[data-lnopen],[data-qsjump],[data-org-opentool]");
    if (!el) return;
    var k = el.getAttribute("data-org-opentool") || el.getAttribute("data-hubopen") || el.getAttribute("data-lnopen") || el.getAttribute("data-qsjump") || el.getAttribute("data-tool") || el.getAttribute("data-view");
    if (!k || k === "*") return;
    var d = load();
    d.usage[k] = (d.usage[k] || 0) + 1;
    save(d);
  }, true);

  function getPerfMetrics() {
    var nav = (window.performance && performance.getEntriesByType && performance.getEntriesByType("navigation")[0]) || null;
    var domMs = nav ? Math.round(nav.domContentLoadedEventEnd) : (Date.now() - bootTime);
    var loadMs = nav && nav.loadEventEnd ? Math.round(nav.loadEventEnd) : domMs;
    var memMB = (window.performance && performance.memory && performance.memory.usedJSHeapSize)
      ? Math.round(performance.memory.usedJSHeapSize / (1024 * 1024))
      : null;
    var swReady = !!(navigator.serviceWorker && navigator.serviceWorker.controller);
    return {
      version: 153,
      domMs: domMs > 0 ? domMs : 0,
      loadMs: loadMs > 0 ? loadMs : 0,
      memMB: memMB,
      swActive: swReady,
      online: navigator.onLine !== false,
      healedCount: healedCount
    };
  }

  function topTools(limit) {
    var u = load().usage || {};
    return Object.keys(u)
      .map(function (k) { return { id: k, count: u[k] || 0 }; })
      .sort(function (a, b) { return b.count - a.count; })
      .slice(0, limit || 10);
  }

  function purgeCacheAndReload() {
    selfHealStorage();
    if (typeof showToast === "function") showToast("⏳ جارٍ مسح الكاش وإصلاح الذاكرة وتحديث ملفات الموقع…", "info");
    var p1 = ("caches" in window)
      ? caches.keys().then(function (keys) { return Promise.all(keys.map(function (k) { return caches.delete(k); })); })
      : Promise.resolve();
    var p2 = ("serviceWorker" in navigator)
      ? navigator.serviceWorker.getRegistrations().then(function (regs) {
          return Promise.all(regs.map(function (r) { return r.update().catch(function () {}); }));
        })
      : Promise.resolve();
    Promise.all([p1, p2]).then(function () {
      if (typeof showToast === "function") showToast("✓ تم تحديث الكاش وإصلاح النظام — سيتم إعادة تحميل الموقع الآن", "success");
      setTimeout(function () { location.reload(); }, 600);
    }).catch(function () {
      location.reload();
    });
  }

  window.EduDiag = {
    version: 153,
    report: function () { return load(); },
    perf: getPerfMetrics,
    topTools: topTools,
    selfHeal: selfHealStorage,
    clearErrors: function () {
      var d = load();
      d.errors = [];
      save(d);
    },
    clearUsage: function () {
      var d = load();
      d.usage = {};
      save(d);
    },
    purgeCache: purgeCacheAndReload,
    download: function () {
      var payload = {
        app: "EduTech Mindset Diagnostics v153",
        exportedAt: new Date().toISOString(),
        url: location.href,
        userAgent: navigator.userAgent,
        performance: getPerfMetrics(),
        diagnostics: load()
      };
      var a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
      a.download = "edutech-diagnostics-" + new Date().toISOString().slice(0, 10) + ".json";
      a.click();
    }
  };
})();

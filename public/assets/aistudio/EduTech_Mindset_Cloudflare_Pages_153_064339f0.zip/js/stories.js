/*
 * استوديو القصص التعليمية المصوّرة والراوي الصوتي التفاعلي — EduTech Mindset (الإصدار 46)
 * يحوّل أي درس أو قيمة تربوية إلى قصة مصوّرة ممتعة من 5 مشاهد مع:
 * - رسومات لوحات فنية تعبيرية على Canvas لكل مشهد
 * - راوٍ صوتي بالعربية يقرأ القصة مشهداً تلو الآخر
 * - أسئلة فهم واستيعاب في نهاية القصة
 * - طباعة القصة ككتيّب PDF ملون (A4 Storybook)
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var PALETTES = [
    ["#0f172a", "#1e3a8a", "#38bdf8", "🌌"],
    ["#064e3b", "#047857", "#34d399", "🌿"],
    ["#4c1d95", "#6d28d9", "#c084fc", "✨"],
    ["#7c2d12", "#b45309", "#fde047", "☀️"],
    ["#881337", "#be123c", "#fda4af", "🌺"]
  ];

  var st = {
    topic: "",
    grade: "الرابع الأساسي",
    hero: "ساري وسلمى",
    story: null, // { title, moral, scenes:[{title, text, dialogue, emoji}], questions:[{q, a}] }
    sceneIdx: 0
  };

  function parseJson(txt) {
    var s = String(txt || "").replace(/```json|```/gi, ""), a = s.indexOf("{"), b = s.lastIndexOf("}");
    if (a < 0 || b <= a) throw new Error("لم يُرجع الذكاء الاصطناعي بيانات صالحة");
    return JSON.parse(s.slice(a, b + 1));
  }

  function generateStory() {
    st.topic = $("stTopic").value.trim();
    st.grade = $("stGrade").value;
    st.hero = $("stHero").value.trim() || "ساري وسلمى";
    if (!st.topic) { toast("اكتب موضوع الدرس أو الفكرة التربوية أولاً", "warning"); return; }

    var btn = $("stGoBtn");
    btn.disabled = true; btn.textContent = "⏳ جارٍ تأليف القصة المصوّرة…";

    var prompt = "أنت أديب تربوي مبدع للأطفال والطلبة في فلسطين. اكتب قصة تعليمية مشوقة من 5 مشاهد تشرح درس أو مفهوم: «" + st.topic + "» لطلبة الصف " + st.grade + "، وبطلاها هما: «" + st.hero + "».\n" +
      "أعد JSON صالحاً فقط بلا أي نص خارجه بهذا الشكل:\n" +
      '{"title":"عنوان القصة المشوق","moral":"الحكمة أو الخلاصة العلمية من القصة","scenes":[{"title":"عنوان المشهد 1","emoji":"🌟","text":"سرد المشهد بأسلوب قصصي شائق ومبسط (3 إلى 4 جمل)","dialogue":"حوار قصير بين أبطال القصة داخل المشهد"}],"questions":[{"q":"سؤال فهم واستيعاب حول القصة والدرس؟","a":"الإجابة الصحيحة"}]}';

    window.AI.ask(prompt, [], "worksheet").then(function (txt) {
      var j = parseJson(txt);
      if (!j || !Array.isArray(j.scenes) || !j.scenes.length) throw new Error("تعذر بناء مشاهد القصة");
      st.story = j;
      st.sceneIdx = 0;
      paintStoryViewer();
      if (window.EduBadges && window.EduBadges.award) window.EduBadges.award("first_step", 35, true);
    }).catch(function (err) {
      toast((err && err.message) || "تعذر توليد القصة حالياً", "warning");
    }).then(function () {
      btn.disabled = false; btn.textContent = "📖 ألّف القصة التعليمية المصوّرة";
    });
  }

  function drawSceneArt(scene, idx) {
    var cv = $("stSceneCanvas"); if (!cv || !scene) return;
    var W = 1000, H = 480;
    cv.width = W; cv.height = H;
    var ctx = cv.getContext("2d");
    ctx.direction = "rtl";
    var P = PALETTES[idx % PALETTES.length];

    var g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, P[0]); g.addColorStop(0.6, P[1]); g.addColorStop(1, P[0]);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

    // زخارف ضوئية ونجوم في الخلفية
    ctx.fillStyle = "rgba(255,255,255,0.08)";
    for (var i = 0; i < 12; i++) {
      ctx.beginPath();
      ctx.arc((i * 97) % W, (i * 67) % H, 15 + (i % 4) * 12, 0, Math.PI * 2);
      ctx.fill();
    }

    // شارة رقم المشهد والرمز التعبيري
    ctx.font = "92px Cairo, sans-serif";
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText(scene.emoji || P[3], W / 2, 115);

    ctx.fillStyle = P[2];
    ctx.font = "900 28px Cairo, Tahoma, sans-serif";
    ctx.fillText("المشهد " + (idx + 1) + ": " + String(scene.title || ""), W / 2, 210);

    // فقاعة الحوار المصورة
    if (scene.dialogue) {
      ctx.fillStyle = "rgba(255,255,255,0.95)";
      ctx.strokeStyle = P[2]; ctx.lineWidth = 4;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(100, 265, W - 200, 150, 26);
      else ctx.rect(100, 265, W - 200, 150);
      ctx.fill(); ctx.stroke();

      ctx.fillStyle = "#0f172a";
      ctx.font = "800 22px Cairo, Tahoma, sans-serif";
      var words = String(scene.dialogue).split(/\s+/), l1 = "", l2 = "";
      words.forEach(function (w) {
        if ((l1 + " " + w).length < 56) l1 += (l1 ? " " : "") + w;
        else l2 += (l2 ? " " : "") + w;
      });
      ctx.fillText("💬 «" + l1 + (l2 ? "" : "»"), W / 2, l2 ? 320 : 340);
      if (l2) ctx.fillText(l2.slice(0, 62) + "»", W / 2, 365);
    }
  }

  function speakScene(idx) {
    if (!st.story) return;
    var sc = st.story.scenes[idx];
    if (!sc) return;
    if (window.EduVoice && window.EduVoice.read) {
      window.EduVoice.stop();
      var narrText = sc.title + ". " + sc.text;
      var dlgText = sc.dialogue ? String(sc.dialogue).trim() : "";
      if (!dlgText) {
        window.EduVoice.read(narrText, "ar-SA", "ar_amjad");
        return;
      }
      // السرد بصوت الحكواتي أمجد، ثم الحوار بصوت شخصية البطل (أماني/تيم)
      var u1 = new SpeechSynthesisUtterance(narrText);
      u1.lang = "ar-SA";
      u1.onend = function () {
        if (window.EduVoice) window.EduVoice.read(dlgText, "ar-SA", "ar_amany");
      };
      window.speechSynthesis.speak(u1);
      return;
    }
    if (!("speechSynthesis" in window)) { toast("متصفحك لا يدعم القراءة الصوتية", "warning"); return; }
    window.speechSynthesis.cancel();
    var u = new SpeechSynthesisUtterance(sc.title + ". " + sc.text + (sc.dialogue ? ". " + sc.dialogue : ""));
    u.lang = "ar-SA"; u.rate = 0.96;
    window.speechSynthesis.speak(u);
  }

  function printStorybookPdf() {
    if (!st.story) return;
    var s = st.story;
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>' + e(s.title) + '</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:14mm}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a;line-height:1.9}h1{text-align:center;color:#4f46e5;font-size:28px;margin-bottom:4px}.sub{text-align:center;color:#64748b;margin-bottom:18px}.sc{border:2px solid #cbd5e1;border-radius:18px;padding:16px;margin-bottom:14px;break-inside:avoid;background:#f8fafc}.sc h3{margin:0 0 6px;color:#0284c7}.dlg{background:#fffbeb;border-right:4px solid #f59e0b;padding:8px 12px;margin-top:8px;font-weight:700;border-radius:8px}.moral{background:#ecfdf5;border:2px solid #10b981;border-radius:16px;padding:14px;text-align:center;font-weight:900;margin:16px 0}</style></head><body>' +
      '<h1>📖 ' + e(s.title) + '</h1><div class="sub">قصة تعليمية للصف ' + e(st.grade) + ' • أبطال القصة: ' + e(st.hero) + '</div>' +
      (s.scenes || []).map(function (sc, i) {
        return '<div class="sc"><h3>' + e(sc.emoji || "🌟") + ' المشهد ' + (i + 1) + ': ' + e(sc.title) + '</h3><div>' + e(sc.text) + '</div>' +
          (sc.dialogue ? '<div class="dlg">💬 ' + e(sc.dialogue) + '</div>' : '') + '</div>';
      }).join("") +
      (s.moral ? '<div class="moral">💡 الحكمة والخلاصة العلمية: ' + e(s.moral) + '</div>' : '') +
      ((s.questions || []).length ? '<h3>❓ أسئلة الفهم والاستيعاب:</h3><ol>' + s.questions.map(function (q) { return '<li><b>' + e(q.q) + '</b><br><span style="color:#047857">الإجابة: ' + e(q.a) + '</span></li>'; }).join("") + '</ol>' : '') +
      '</body></html>';
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
  }

  function paintStoryViewer() {
    var box = $("stViewer"); if (!box) return;
    if (!st.story) { box.innerHTML = ""; return; }
    var s = st.story, sc = s.scenes[st.sceneIdx] || s.scenes[0];
    box.innerHTML = '<div class="rounded-3xl border-2 border-purple-500/30 bg-white dark:bg-slate-900 p-4 sm:p-6 space-y-4">' +
      '<div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">' +
      '<div><h3 class="text-lg sm:text-xl font-black text-purple-700 dark:text-purple-300">📖 ' + e(s.title) + '</h3>' +
      '<p class="text-xs text-slate-500">المشهد ' + (st.sceneIdx + 1) + ' من ' + s.scenes.length + '</p></div>' +
      '<div class="flex flex-wrap gap-1.5">' +
      '<button type="button" id="stSpeakBtn" class="px-3.5 py-2 rounded-xl bg-emerald-600 text-white text-xs font-black">🔊 الراوي الصوتي للمشهد</button>' +
      '<button type="button" id="stPrintPdf" class="px-3.5 py-2 rounded-xl bg-indigo-600 text-white text-xs font-black">🖨 طباعة كتيّب القصة PDF</button>' +
      '</div></div>' +
      '<div class="rounded-2xl overflow-hidden border border-slate-300 dark:border-slate-700 bg-slate-950 p-1.5"><canvas id="stSceneCanvas" class="w-full h-auto rounded-xl"></canvas></div>' +
      '<div class="p-4 rounded-2xl bg-purple-50/60 dark:bg-slate-800/80 border border-purple-200 dark:border-slate-700 text-sm sm:text-base font-bold leading-loose text-slate-800 dark:text-slate-100">' + e(sc.text) + '</div>' +
      '<div class="flex items-center justify-between gap-2">' +
      '<button type="button" id="stPrevSc" class="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-extrabold">➡ المشهد السابق</button>' +
      '<div class="flex gap-1.5">' + s.scenes.map(function (_, i) {
        return '<button type="button" data-stidx="' + i + '" class="w-8 h-8 rounded-full text-xs font-black ' + (i === st.sceneIdx ? "bg-purple-600 text-white" : "bg-slate-200 dark:bg-slate-700") + '">' + (i + 1) + '</button>';
      }).join("") + '</div>' +
      '<button type="button" id="stNextSc" class="px-4 py-2 rounded-xl bg-purple-600 text-white text-xs font-extrabold">المشهد التالي ⬅</button>' +
      '</div>' +
      (s.moral ? '<div class="p-3.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-xs font-black text-amber-800 dark:text-amber-300">💡 الحكمة والخلاصة العلمية: ' + e(s.moral) + '</div>' : '') +
      ((s.questions || []).length ? '<div class="space-y-2 pt-2"><div class="text-xs font-black">❓ أسئلة الفهم والاستيعاب بعد القراءة:</div>' +
        s.questions.map(function (q, i) {
          return '<details class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"><summary class="font-extrabold cursor-pointer">' + (i + 1) + ') ' + e(q.q) + ' <span class="text-brand-600">(اضغط لإظهار الإجابة)</span></summary><div class="mt-2 text-emerald-600 dark:text-emerald-400 font-bold">✅ ' + e(q.a) + '</div></details>';
        }).join("") + '</div>' : '') +
      '</div>';

    setTimeout(function () { drawSceneArt(sc, st.sceneIdx); }, 50);
    $("stSpeakBtn").onclick = function () { speakScene(st.sceneIdx); };
    $("stPrintPdf").onclick = printStorybookPdf;
    $("stPrevSc").onclick = function () { st.sceneIdx = (st.sceneIdx - 1 + s.scenes.length) % s.scenes.length; paintStoryViewer(); };
    $("stNextSc").onclick = function () { st.sceneIdx = (st.sceneIdx + 1) % s.scenes.length; paintStoryViewer(); };
    box.querySelectorAll("[data-stidx]").forEach(function (b) {
      b.onclick = function () { st.sceneIdx = +b.dataset.stidx; paintStoryViewer(); };
    });
  }

  function build() {
    if ($("storiesStudio")) return true;
    var anchor = $("tutorStudio") || $("simLabStudio") || $("gamesStudio");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "storiesStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-purple-700 via-fuchsia-800 to-slate-900 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1">📖 استوديو القصص التعليمية المصوّرة والراوي الصوتي</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">حوّل أي درس علمي أو قيمة تربوية إلى قصة مصوّرة ناطقة وممتعة</h2>' +
      '<p class="text-xs text-white/85 mt-1">يكتب الذكاء الاصطناعي قصة من 5 مشاهد مصورة بأسلوب مشوق، مع راوٍ صوتي وأسئلة فهم وإمكانية طباعتها ككتيّب PDF.</p>' +
      '</div>' +
      '<div class="p-5 sm:p-6 space-y-4 text-right">' +
      '<div class="grid grid-cols-1 sm:grid-cols-4 gap-3">' +
      '<div class="sm:col-span-2"><label class="block text-xs font-bold mb-1">موضوع الدرس أو القيمة التربوية</label>' +
      '<input id="stTopic" class="' + cls + '" placeholder="مثال: دورة حياة الماء في الطبيعة / الأمانة والصدق / الكسور المتكافئة"></div>' +
      '<div><label class="block text-xs font-bold mb-1">الصف الدراسي</label><select id="stGrade" class="' + cls + '"><option>الأول الأساسي</option><option>الثاني الأساسي</option><option>الثالث الأساسي</option><option selected>الرابع الأساسي</option><option>الخامس الأساسي</option><option>السادس الأساسي</option><option>السابع</option><option>الثامن</option></select></div>' +
      '<div><label class="block text-xs font-bold mb-1">أسماء أبطال القصة</label><input id="stHero" value="ساري وسلمى" class="' + cls + '"></div>' +
      '</div>' +
      '<button type="button" id="stGoBtn" class="px-6 py-3 rounded-xl bg-gradient-to-l from-purple-600 to-fuchsia-600 text-white text-xs font-black shadow-md">📖 ألّف القصة التعليمية المصوّرة</button>' +
      '<div id="stViewer"></div>' +
      '</div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    $("stGoBtn").onclick = generateStory;
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduStories = { open: function (topic) { if ($("stTopic") && topic) $("stTopic").value = topic; if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("storiesStudio", true); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

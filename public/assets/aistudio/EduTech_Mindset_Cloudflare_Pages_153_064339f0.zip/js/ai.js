/*
 * مساعد الذكاء الاصطناعي — EduTech Mindset
 * إدارة وتطوير: أ. باسل أشرف الفقعاوي
 * جميع الطلبات تمر عبر الخادم الوسيط الآمن (/api/ai على Cloudflare Pages)؛ المفاتيح لا تصل للمتصفح.
 * يدعم: Gemini، OpenAI، Claude، DeepSeek + محرك مجاني احتياطي، مع التبديل التلقائي واليدوي ومحرك لكل أداة.
 */
(function () {
  "use strict";

  var ENDPOINT = "/api/ai";
  var ENGINES = ["gemini", "openai", "claude", "deepseek", "meta", "free"];
  var NAMES = { gemini: "Google Gemini", openai: "OpenAI ChatGPT", claude: "Anthropic Claude", deepseek: "DeepSeek", meta: "Meta AI (Llama)", free: "المحرك المجاني (احتياطي)" };
  var TOOL_LIST = [
    ["studio", "مساعد المعلم الذكي (خطط الدروس والاختبارات)"],
    ["generator", "مُولّد البرومبتات — زر «ولّد الإجابة»"],
    ["library", "تنفيذ موارد المكتبة بالذكاء الاصطناعي"],
    ["bloom", "أسئلة أهداف هرم بلوم"],
    ["prep", "محضّر الدروس من صور الكتاب"],
    ["notebook", "دفتر المصادر"]
  ];
  var serverStatus = null, lastEngine = "";

  // تنظيف أي مفاتيح قديمة كانت محفوظة في المتصفح
  try { ["gemini", "openai", "claude", "deepseek"].forEach(function (k) { localStorage.removeItem("edutech_key_" + k); }); } catch (e) {}

  function cfg() { return (typeof appState !== "undefined" && appState.aiConfig) || {}; }

  // ترتيب المحركات لأداة معينة: المحرك المخصص للأداة ← الافتراضي ← بقية الترتيب (إن فُعّل التبديل التلقائي)
  function buildOrder(toolId) {
    var c = cfg(), enabled = c.enabled || {};
    var first = (toolId && c.toolEngines && c.toolEngines[toolId]) || c.primaryProvider || "gemini";
    var order = [first];
    if (c.autoFallback !== false) {
      (Array.isArray(c.order) ? c.order : []).concat(ENGINES).forEach(function (p) { if (order.indexOf(p) < 0) order.push(p); });
    }
    return order.filter(function (p) { return ENGINES.indexOf(p) >= 0 && enabled[p] !== false; });
  }

  async function getToken() {
    try {
      var u = window.Cloud && window.Cloud.user;
      if (u && u.getIdToken) return await u.getIdToken();
    } catch (e) {}
    return "";
  }

  async function post(body) {
    body.idToken = await getToken();
    var res = await fetch(ENDPOINT, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    var data = null; try { data = await res.json(); } catch (e) {}
    return { ok: res.ok, status: res.status, data: data };
  }

  // احتياطي أخير يعمل من المتصفح إذا لم تُنشر الدالة الوسيطة بعد (نصوص فقط)
  function askFreeLocal(prompt) {
    var c = typeof AbortController !== "undefined" ? new AbortController() : null;
    var t = setTimeout(function () { if (c) c.abort(); }, 40000);
    return fetch("https://text.pollinations.ai/openai", { method: "POST", headers: { "Content-Type": "application/json" }, signal: c ? c.signal : undefined,
      body: JSON.stringify({ model: "openai", messages: [{ role: "user", content: prompt.slice(0, 5000) }] }) })
      .then(function (r) { clearTimeout(t); if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
      .then(function (j) { var x = j && j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content; if (!x) throw new Error("استجابة فارغة"); return String(x).trim(); });
  }

  async function askUnified(prompt, files, toolId) {
    var order = buildOrder(toolId);
    if (!order.length) throw new Error("جميع محركات الذكاء الاصطناعي متوقفة من لوحة الإدارة");
    var body = { action: "chat", prompt: prompt, files: files || [], order: order, tool: toolId || "", models: cfg().models || {} };
    if (JSON.stringify(body).length > 15 * 1024 * 1024) throw new Error("حجم الصور/الملفات كبير؛ قلّل عدد الصفحات أو حجم الملف");
    var r;
    try { r = await post(body); }
    catch (e) {
      if (files && files.length) throw new Error("تعذر الاتصال بالخادم");
      return askFreeLocal(prompt);
    }
    if ((r.status === 404 || r.status === 405 || r.status === 401 || r.status === 502 || r.status === 503) && !(files && files.length)) {
      try {
        return await askFreeLocal(prompt);
      } catch (eFallback) {}
    }
    if (!r.ok || !r.data || !r.data.text) throw new Error((r.data && r.data.error) || ("HTTP " + r.status));
    lastEngine = r.data.engine || "";
    return r.data.text;
  }

  function loadStatus(force) {
    if (serverStatus && !force) return Promise.resolve(serverStatus);
    return post({ action: "status" }).then(function (r) { if (r.ok && r.data) serverStatus = r.data; return serverStatus; }).catch(function () { return null; });
  }
  loadStatus();

  window.AI = {
    ENGINES: ENGINES, NAMES: NAMES, TOOLS: TOOL_LIST,
    status: loadStatus,
    lastEngine: function () { return lastEngine; },
    // اختبار المحركات (للإدارة فقط — يتحقق الخادم من هويتك)
    test: function (engine) {
      return post({ action: "test", engine: engine || "", models: cfg().models || {} }).then(function (r) {
        if (!r.ok) throw new Error((r.data && r.data.error) || ("HTTP " + r.status));
        return r.data.results;
      });
    },
    // هل يوجد محرك يدعم الصور وPDF؟ (يُفترض نعم حتى يصل رد الخادم)
    hasKey: function () {
      if (!serverStatus) return true;
      var e = serverStatus.engines || {};
      return !!((e.gemini && e.gemini.configured) || (e.openai && e.openai.configured) || (e.claude && e.claude.configured));
    },
    ask: function (prompt, files, toolId) { return askUnified(prompt, files, toolId); }
  };

  // ---------- أدوات استوديو المعلم الذكي ----------
  var TOOLS = [
    ["lesson", "📘 خطة درس تفاعلية", "اكتب عنوان الدرس", function (i) { return "صمّم خطة درس تفاعلية كاملة وفق نموذج 5E لدرس: «" + i.topic + "».\nيجب أن تتضمن: الأهداف السلوكية، التمهيد، الأنشطة الاستقصائية، الشرح، التوسع، التقويم الختامي، وتكييف للفروق الفردية، مع التوقيت لحصة مدتها 45 دقيقة." + i.tail; }],
    ["quiz", "📝 اختبار قصير متدرج (بلوم)", "اكتب موضوع الاختبار", function (i) { return "ضع اختباراً قصيراً من 10 أسئلة متدرجة وفق مستويات بلوم المعرفية حول: «" + i.topic + "».\nنوّع بين اختيار من متعدد وصح/خطأ وسؤال مقالي قصير، وأرفق مفتاح الإجابة وسلم تصحيح." + i.tail; }],
    ["ice", "🎯 أنشطة استهلالية وكسر الجليد", "اكتب موضوع الحصة", function (i) { return "اقترح 5 أنشطة استهلالية قصيرة (3 دقائق لكل نشاط) تثير دافعية الطلبة قبل درس: «" + i.topic + "»، بدون تقنيات مكلفة." + i.tail; }],
    ["explain", "💡 شرح مبسّط لمفهوم", "اكتب المفهوم المراد شرحه", function (i) { return "اشرح مفهوم «" + i.topic + "» بأسلوب مبسّط مناسب للمرحلة المحددة، مع مثالين من الحياة اليومية وتشبيه، وثلاثة أسئلة فهم في النهاية." + i.tail; }],
    ["summary", "🗒️ تلخيص نص", "الصق النص المراد تلخيصه", function (i) { return "لخّص النص التالي في نقاط مركزة وبعدها فقرة موجزة، مع استخراج المصطلحات الأساسية:\n\n" + i.topic + i.tail; }],
    ["rewrite", "✍️ إعادة صياغة وتبسيط", "الصق النص المراد تبسيطه", function (i) { return "أعد صياغة النص التالي بلغة أبسط وأوضح مناسبة للمرحلة المحددة مع الحفاظ على المعنى:\n\n" + i.topic + i.tail; }],
    ["parent", "✉️ رسالة لولي أمر", "اكتب الموقف (مثال: تأخر الطالب في تسليم الواجبات)", function (i) { return "اكتب رسالة مهذبة وإيجابية وموجزة من المعلم إلى ولي أمر بخصوص: «" + i.topic + "»، مع اقتراحات تعاون عملية." + i.tail; }],
    ["rubric", "📊 سلم تقدير (Rubric)", "اكتب المهمة المراد تقييمها", function (i) { return "صمّم سلم تقدير (Rubric) في جدول بأربعة مستويات ومعايير واضحة لتقييم: «" + i.topic + "»." + i.tail; }],
    ["free", "🤖 اسأل المساعد (حر)", "اكتب سؤالك أو طلبك", function (i) { return i.topic + i.tail; }]
  ];
  var GRADES = ["الابتدائية (الصفوف 1 - 4)", "المتوسطة / الإعدادية (الصفوف 5 - 9)", "الثانوية (الصفوف 10 - 12)", "الجامعية والتعليم المستمر"];
  var SUBJECTS = ["عام / غير محدد", "تكنولوجيا التعليم والذكاء الاصطناعي", "العلوم العامة والفيزياء", "الرياضيات والمنطق", "اللغة العربية وآدابها", "اللغة الإنجليزية", "الدراسات الاجتماعية والتاريخ", "البرمجة والروبوتيكس"];
  var lastCall = 0, lastResult = "", lastToolLabel = "";
  var inputCls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2.5 text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-brand-500";

  function e(s) { return escapeHtml(s); }
  function sel(list, id, def) { return '<select id="' + id + '" class="' + inputCls + '">' + list.map(function (x) { return '<option' + (x === def ? " selected" : "") + ">" + e(x) + "</option>"; }).join("") + "</select>"; }

  var attach = [];
  function readB64(file) { return new Promise(function (res, rej) { var r = new FileReader(); r.onload = function () { res(String(r.result).split(",")[1]); }; r.onerror = rej; r.readAsDataURL(file); }); }
  function shrink(file) {
    return new Promise(function (res, rej) {
      var url = URL.createObjectURL(file), im = new Image();
      im.onload = function () {
        var k = Math.min(1, 1600 / Math.max(im.width, im.height)), c = document.createElement("canvas");
        c.width = Math.max(1, Math.round(im.width * k)); c.height = Math.max(1, Math.round(im.height * k));
        var cx = c.getContext("2d"); cx.fillStyle = "#fff"; cx.fillRect(0, 0, c.width, c.height); cx.drawImage(im, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        var t = document.createElement("canvas"); t.width = 96; t.height = Math.max(1, Math.round(96 * c.height / c.width)); t.getContext("2d").drawImage(c, 0, 0, t.width, t.height);
        res({ mime: "image/jpeg", data: c.toDataURL("image/jpeg", 0.82).split(",")[1], thumb: t.toDataURL("image/jpeg", 0.6) });
      };
      im.onerror = function () { URL.revokeObjectURL(url); rej(new Error("img")); };
      im.src = url;
    });
  }
  function totalLen() { return attach.reduce(function (n, f) { return n + f.data.length; }, 0); }
  function drawThumbs() {
    var el = document.getElementById("aiThumbs"); if (!el) return;
    el.innerHTML = attach.map(function (f, i) {
      return '<div class="relative w-20 h-20 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 flex items-center justify-center">' +
        (f.thumb ? '<img src="' + f.thumb + '" class="w-full h-full object-cover">' : '<i class="fa-solid fa-file-pdf text-2xl text-rose-500"></i>') +
        '<button type="button" data-rmatt="' + i + '" aria-label="حذف" class="absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-rose-600 text-white text-[10px]">✕</button></div>';
    }).join("");
    var lbl = document.getElementById("aiTopicLabel"), t = document.getElementById("aiTool");
    if (lbl && t) { var tl = TOOLS.filter(function (x) { return x[0] === t.value; })[0]; lbl.textContent = attach.length ? tl[2].replace(/^(اكتب|الصق)/, "اكتب أو اتركه فارغاً مع الصورة:") : tl[2]; }
  }
  function addFiles(list) {
    var files = Array.prototype.slice.call(list || []);
    files.reduce(function (p, f) {
      return p.then(function () {
        if (attach.length >= 10) { showToast("الحد الأقصى 10 ملفات", "info"); return; }
        var isPdf = f.type === "application/pdf" || /\.pdf$/i.test(f.name);
        if (isPdf) { if (f.size > 10 * 1024 * 1024) { showToast("ملف PDF كبير (الحد 10 ميغابايت)، قسّمه أو صوّر الصفحات المهمة", "warning"); return; } return readB64(f).then(function (d) { attach.push({ mime: "application/pdf", data: d, name: f.name }); }); }
        if (!/^image\//.test(f.type)) { showToast("اختر صورة أو ملف PDF", "warning"); return; }
        return shrink(f).then(function (x) { if (totalLen() + x.data.length > 13e6) { showToast("حجم الملفات كبير، احذف صورة أو صوّر بجودة أقل", "warning"); return; } attach.push(x); }, function () { showToast("تعذر قراءة الصورة", "warning"); });
      });
    }, Promise.resolve()).then(drawThumbs);
  }

  function ensureStudio() {
    if (document.getElementById("aiStudio")) return;
    var gen = document.getElementById("generator");
    if (!gen) return;
    var s = document.createElement("section");
    s.id = "aiStudio";
    s.className = "py-14 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8";
    s.innerHTML =
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-purple-700 via-brand-700 to-slate-900 text-white"><div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1"><i class="fa-solid fa-robot"></i>مساعد المعلم الذكي</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">ولّد خطط الدروس والاختبارات والأنشطة بالذكاء الاصطناعي</h2>' +
      '<p class="text-xs text-white/80 mt-1">اختر الأداة، اكتب الموضوع، واحصل على محتوى جاهز تنسخه أو تحفظه في حسابك.</p></div>' +
      '<div class="p-5 sm:p-6 space-y-3.5 text-right">' +
      '<div class="grid grid-cols-1 sm:grid-cols-3 gap-3"><div><label class="block text-xs font-bold mb-1">الأداة</label><select id="aiTool" class="' + inputCls + '">' + TOOLS.map(function (t) { return '<option value="' + t[0] + '">' + e(t[1]) + "</option>"; }).join("") + "</select></div>" +
      '<div><label class="block text-xs font-bold mb-1">المرحلة</label>' + sel(GRADES, "aiGrade", GRADES[1]) + '</div><div><label class="block text-xs font-bold mb-1">المادة</label>' + sel(SUBJECTS, "aiSubject", SUBJECTS[0]) + "</div></div>" +
      '<div><label id="aiTopicLabel" class="block text-xs font-bold mb-1">اكتب عنوان الدرس</label><textarea id="aiTopic" rows="4" maxlength="6000" class="' + inputCls + '" placeholder="..."></textarea></div>' +
      '<div><label class="block text-xs font-bold mb-1">📎 أو أضف صورة النص (اختياري)</label><div class="flex flex-wrap gap-2">' +
      '<label class="px-4 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-extrabold cursor-pointer flex items-center gap-2"><i class="fa-solid fa-camera"></i>تصوير بالكاميرا<input id="aiCam" type="file" accept="image/*" capture="environment" class="hidden"></label>' +
      '<label class="px-4 py-2.5 rounded-xl bg-sky-600 text-white text-xs font-extrabold cursor-pointer flex items-center gap-2"><i class="fa-solid fa-image"></i>اختيار من الجوال<input id="aiPick" type="file" accept="image/*,application/pdf" multiple class="hidden"></label></div>' +
      '<div id="aiThumbs" class="flex flex-wrap gap-2 mt-2"></div><p class="text-[10px] text-slate-400 mt-1">يقرأ المساعد النص من الصورة (حتى 10 ملفات) ثم ينفّذ الأداة المختارة عليه، مثل التلخيص أو التبسيط أو أسئلة منه.</p></div>' +
      '<div><label class="block text-xs font-bold mb-1">تعليمات إضافية (اختياري)</label><input id="aiExtra" maxlength="300" class="' + inputCls + '" placeholder="مثال: صف يضم 40 طالباً، بدون إنترنت داخل الصف"></div>' +
      '<div class="flex flex-wrap items-center gap-2"><button id="aiGo" type="button" class="px-6 py-3 rounded-xl bg-gradient-to-l from-purple-600 to-brand-600 text-white text-xs font-black shadow-md flex items-center gap-2"><i class="fa-solid fa-wand-magic-sparkles"></i><span>ولّد الآن</span></button>' +
      '<span id="aiStatus" class="text-[11px] font-bold text-slate-500"></span></div>' +
      '<div id="aiResultWrap" class="hidden space-y-2"><div id="aiResult" class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs leading-relaxed text-slate-800 dark:text-slate-100 whitespace-pre-wrap max-h-[28rem] overflow-y-auto"></div>' +
      '<div class="flex flex-wrap gap-2"><button id="aiCopy" type="button" class="px-3.5 py-2 rounded-xl bg-brand-600 text-white text-[11px] font-bold"><i class="fa-regular fa-copy ml-1"></i>نسخ</button>' +
      '<button id="aiSave" type="button" class="px-3.5 py-2 rounded-xl bg-emerald-600 text-white text-[11px] font-bold"><i class="fa-solid fa-floppy-disk ml-1"></i>حفظ في حسابي</button>' + (window.Exporter ? window.Exporter.bar({ src: "#aiResult", tool: "المساعد الذكي", copy: false }) : "") + '</div></div></div></div>';
    gen.parentNode.insertBefore(s, gen.nextSibling);

    var toolSel = document.getElementById("aiTool");
    function syncLabel() { drawThumbs(); }
    toolSel.addEventListener("change", syncLabel); syncLabel();
    document.getElementById("aiGo").addEventListener("click", run);
    ["aiCam", "aiPick"].forEach(function (id) { document.getElementById(id).addEventListener("change", function (e) { addFiles(e.target.files); e.target.value = ""; }); });
    document.getElementById("aiThumbs").addEventListener("click", function (e) { var b = e.target.closest("[data-rmatt]"); if (b) { attach.splice(+b.dataset.rmatt, 1); drawThumbs(); } });
    document.getElementById("aiCopy").addEventListener("click", function () { copyTextToClipboard(lastResult, "تم نسخ النتيجة 📋"); });
    document.getElementById("aiSave").addEventListener("click", saveResult);
  }

  // عرض النتيجة منسّقة + تجهيزها للتصدير وحفظها في «أعمالي»
  function showRes(el, txt, title, tool) {
    if (!el) return;
    if (window.Exporter) { window.Exporter.show(el, txt); el.dataset.exTitle = title || ""; window.Exporter.record({ title: title, text: txt, tool: tool }); }
    else el.textContent = txt;
  }

  function buildPrompt() {
    var t = TOOLS.filter(function (x) { return x[0] === document.getElementById("aiTool").value; })[0];
    var topic = document.getElementById("aiTopic").value.trim();
    if (!topic && !attach.length) return null;
    if (!topic) topic = "(النص المطلوب موجود في الملفات المرفقة)";
    var tail = "\n\nالمرحلة: " + document.getElementById("aiGrade").value + "\nالمادة: " + document.getElementById("aiSubject").value;
    var extra = document.getElementById("aiExtra").value.trim();
    if (extra) tail += "\nتعليمات إضافية: " + extra;
    lastToolLabel = t[1];
    if (attach.length) tail += "\n\nملاحظة: المحتوى المطلوب معالجته موجود في الصور/الملفات المرفقة. اقرأ النص الظاهر فيها بدقة (بما فيه العربية والتشكيل) أولاً ثم نفّذ المطلوب عليه.";
    return t[3]({ topic: topic, tail: tail });
  }

  function guard() {
    var hasLocalUser = (typeof getCurrentUser === "function" && getCurrentUser()) ||
      (window.EduAccessControl && typeof window.EduAccessControl.getCurrentUser === "function" && window.EduAccessControl.getCurrentUser());
    if (serverStatus && serverStatus.requireLogin === true && !hasLocalUser) {
      showToast("سجّل دخولك أولاً لاستخدام المساعد الذكي", "info");
      if (typeof openGoogleAuthModal === "function") openGoogleAuthModal();
      return false;
    }
    if (Date.now() - lastCall < 2500) { showToast("انتظر لحظات قبل الطلب التالي", "info"); return false; }
    return true;
  }

  function run() {
    var prompt = buildPrompt();
    if (!prompt) { showToast("اكتب الموضوع أو النص، أو أضف صورة", "warning"); return; }
    if (attach.length && window.AI.hasKey && !window.AI.hasKey()) { showToast("قراءة الصور تحتاج محركاً يدعم الرؤية (Gemini أو OpenAI أو Claude): أضف مفتاحه من إدارة كاملة ← المحركات الذكية", "warning"); return; }
    if (!guard()) return;
    lastCall = Date.now();
    var st = document.getElementById("aiStatus"), btn = document.getElementById("aiGo");
    st.textContent = "⏳ جارٍ التوليد… قد يستغرق حتى دقيقة"; btn.disabled = true; btn.classList.add("opacity-60");
    window.AI.ask(prompt, attach.map(function (f) { return { mime: f.mime, data: f.data }; }), "studio").then(function (txt) {
      lastResult = txt;
      showRes(document.getElementById("aiResult"), txt, lastToolLabel + ": " + (document.getElementById("aiTopic").value.trim() || "من صورة").slice(0, 50), lastToolLabel);
      document.getElementById("aiResultWrap").classList.remove("hidden");
      st.textContent = "✓ تم";
      var u = getCurrentUser(); if (u) { logActivity("ولّدت محتوى بالذكاء الاصطناعي: " + lastToolLabel); saveState(); }
    }).catch(function (err) {
      st.textContent = "";
      showToast("تعذر الاتصال بالمساعد الذكي الآن (" + (err && err.message ? err.message.slice(0, 70) : "خطأ") + ")", "warning");
    }).then(function () { btn.disabled = false; btn.classList.remove("opacity-60"); });
  }

  function saveResult() {
    var u = (typeof window.getOrCreateActiveUser === "function") ? window.getOrCreateActiveUser() : getCurrentUser();
    if (!u) { openGoogleAuthModal(); return; }
    if (!lastResult) return;
    if (!Array.isArray(u.savedPrompts)) u.savedPrompts = [];
    u.savedPrompts.unshift({
      id: "sp-" + Date.now(), topic: document.getElementById("aiTopic").value.trim().slice(0, 80), grade: document.getElementById("aiGrade").value,
      subject: document.getElementById("aiSubject").value, goal: lastToolLabel, aiModel: "AI", strategy: "", date: new Date().toLocaleDateString("ar-EG"),
      text: lastResult.slice(0, 8000)
    });
    logActivity("حفظت نتيجة المساعد الذكي: " + lastToolLabel);
    saveState(); renderUserWorkspace();
    showToast("تم الحفظ في «برومبتاتي المحفوظة» داخل حسابك ✓", "success");
  }

  function hookGenerator() {
    var copyBtn = document.getElementById("btnCopyPrompt");
    if (!copyBtn || document.getElementById("btnRunPromptAI")) return;
    var b = document.createElement("button");
    b.id = "btnRunPromptAI"; b.type = "button";
    b.className = "px-3.5 py-2 rounded-xl bg-gradient-to-l from-purple-600 to-brand-600 text-white text-xs font-extrabold flex items-center gap-1.5";
    b.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i><span>ولّد الإجابة بالذكاء الاصطناعي</span>';
    copyBtn.parentNode.insertBefore(b, copyBtn.nextSibling);
    if (window.Exporter) { var pb = document.createElement("span"); pb.className = "contents"; pb.innerHTML = window.Exporter.bar({ src: "#promptOutputText", title: "برومبت تعليمي", tool: "مولّد البرومبتات", copy: false }); b.parentNode.insertBefore(pb, b.nextSibling); }
    b.addEventListener("click", function () {
      var p = document.getElementById("promptOutputText").textContent.trim();
      if (!p) return;
      if (!guard()) return;
      lastCall = Date.now();
      showToast("⏳ جارٍ توليد الإجابة…", "info");
      window.AI.ask(p, null, "generator").then(function (txt) {
        lastResult = txt; lastToolLabel = "مولّد البرومبتات";
        showModalContent('<div class="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between"><h3 class="text-sm font-extrabold">إجابة المساعد الذكي</h3><button type="button" class="p-2 text-slate-400" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button></div>' +
          '<div class="p-5 overflow-y-auto text-right"><div id="aiModalRes" class="text-xs leading-relaxed whitespace-pre-wrap"></div><div class="mt-3 flex flex-wrap gap-2"><button id="aiModalCopy" type="button" class="px-3.5 py-2 rounded-xl bg-brand-600 text-white text-[11px] font-bold">نسخ</button>' + (window.Exporter ? window.Exporter.bar({ src: "#aiModalRes", tool: "مولّد البرومبتات", copy: false }) : "") + '</div></div>');
        showRes(document.getElementById("aiModalRes"), txt, "إجابة المساعد: " + p.replace(/\s+/g, " ").slice(0, 45), "مولّد البرومبتات");
        document.getElementById("aiModalCopy").addEventListener("click", function () { copyTextToClipboard(txt, "تم النسخ 📋"); });
      }).catch(function (err) { showToast("تعذر الاتصال بالمساعد (" + String(err && err.message || "خطأ").slice(0, 110) + ")", "warning"); });
    });
  }

  window.runItemAI = function (id) {
    var it = (appState.items || []).filter(function (x) { return x.id === id; })[0];
    if (!it) return;
    var u = null; try { u = getCurrentUser(); } catch (e) {}
    var g = document.getElementById("genGrade"), s = document.getElementById("genSubject");
    var grade = (u && u.grade) || (g && g.value) || "", subject = (u && u.subject) || (s && s.value) || "";
    var sel = function (id2, html) { return '<select id="' + id2 + '" class="' + inputCls + '">' + html + "</select>"; };
    showModalContent('<div class="p-4 shrink-0 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between gap-2 bg-slate-50 dark:bg-slate-800/50"><div><div class="text-[10px] font-bold text-amber-600 mb-0.5">⚡ تنفيذ داخل الموقع</div><h3 class="text-xs font-extrabold leading-snug">' + e(it.title) + '</h3></div><button type="button" class="p-2 text-slate-400" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button></div>' +
      '<div class="p-4 overflow-y-auto flex-1 min-h-0 text-right space-y-2">' +
      '<label class="block text-[11px] font-bold">الموضوع / الدرس *</label><input id="riTopic" class="' + inputCls + '" placeholder="مثال: الكسور العادية">' +
      '<div class="grid grid-cols-2 gap-2"><div><label class="block text-[11px] font-bold">الصف / المرحلة</label>' + sel("riGrade", window.stagesOptions ? window.stagesOptions(grade) : "") + '</div><div><label class="block text-[11px] font-bold">المادة</label>' + sel("riSubject", window.subjectsOptions ? window.subjectsOptions(subject) : "") + "</div></div>" +
      '<label class="block text-[11px] font-bold">تعليمات إضافية (اختياري)</label><input id="riExtra" class="' + inputCls + '" placeholder="مثال: صف فيه 40 طالباً بدون إنترنت">' +
      '<div id="riSt" class="text-[11px] font-bold text-slate-500"></div>' +
      '<div id="riWrap" class="hidden"><div id="riRes" class="whitespace-pre-wrap text-xs leading-loose p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-700"></div></div></div>' +
      '<div id="riFooter" class="p-3 shrink-0 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-2" style="padding-bottom:calc(.75rem + env(safe-area-inset-bottom))">' +
      '<div id="riActions" class="hidden grid grid-cols-4 gap-2"><button id="riCopy" type="button" class="px-2 py-3 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-extrabold"><i class="fa-regular fa-copy ml-1"></i>نسخ</button><button id="riWord" type="button" class="px-2 py-3 rounded-xl bg-brand-600 text-white text-xs font-extrabold"><i class="fa-solid fa-file-word ml-1"></i>Word</button><button id="riPdf" type="button" class="px-2 py-3 rounded-xl bg-rose-600 text-white text-xs font-extrabold"><i class="fa-solid fa-file-pdf ml-1"></i>PDF</button><button id="riSave" type="button" class="px-2 py-3 rounded-xl bg-emerald-600 text-white text-xs font-extrabold"><i class="fa-solid fa-floppy-disk ml-1"></i>حفظ</button></div>' +
      '<button id="riGo" type="button" class="w-full px-4 py-3.5 rounded-xl bg-gradient-to-l from-purple-600 to-brand-600 text-white text-sm font-black shadow-lg"><i class="fa-solid fa-bolt ml-1"></i><span id="riGoTxt">نفّذ الآن</span></button></div>');
    var result = "";
    document.getElementById("riGo").addEventListener("click", function () {
      var topic = document.getElementById("riTopic").value.trim();
      if (!topic) { showToast("اكتب الموضوع أولاً", "warning"); return; }
      if (!guard()) return;
      lastCall = Date.now();
      var gr = document.getElementById("riGrade").value, sb = document.getElementById("riSubject").value, ex = document.getElementById("riExtra").value.trim();
      var base = (it.promptText && it.promptText.trim()) || ("نفّذ فعلياً المطلوب التالي وأعطني الناتج النهائي الجاهز للاستخدام مباشرة وليس شرحاً له:\n«" + it.title + "»\n" + (it.desc || ""));
      var hasVars = /\{(topic|grade|subject)\}/.test(base);
      var prompt = base.replace(/\{topic\}/g, topic).replace(/\{grade\}/g, gr).replace(/\{subject\}/g, sb);
      if (!hasVars) prompt += "\n\nالموضوع: " + topic + "\nالصف/المرحلة: " + gr + "\nالمادة: " + sb;
      if (ex) prompt += "\nتعليمات إضافية: " + ex;
      prompt += "\n\nأجب بالعربية بتنسيق منظم وجاهز للتطبيق.";
      var btn = document.getElementById("riGo"); btn.disabled = true; btn.classList.add("opacity-60");
      document.getElementById("riSt").textContent = "⏳ جارٍ التنفيذ… قد يستغرق حتى دقيقة";
      window.AI.ask(prompt, null, "library").then(function (txt) {
        result = txt; showRes(document.getElementById("riRes"), txt, it.title.slice(0, 60) + " — " + topic.slice(0, 30), "مكتبة الموارد"); document.getElementById("riWrap").classList.remove("hidden"); document.getElementById("riActions").classList.remove("hidden"); document.getElementById("riGoTxt").textContent = "أعد التنفيذ"; document.getElementById("riSt").textContent = "✓ تم"; document.getElementById("riRes").scrollIntoView({ block: "start", behavior: "smooth" });
        if (u) { logActivity("نفّذت برومبت داخل الموقع: " + it.title.slice(0, 50)); saveState(); }
      }).catch(function (err) { document.getElementById("riSt").textContent = ""; showToast("تعذر الاتصال بالمساعد الآن (" + String(err && err.message || "خطأ").slice(0, 70) + ")", "warning"); })
        .then(function () { btn.disabled = false; btn.classList.remove("opacity-60"); });
    });
    document.getElementById("riCopy").addEventListener("click", function () { copyTextToClipboard(result, "تم النسخ 📋"); });
    function riExport(kind, btn) {
      if (!result) return;
      var tp = document.getElementById("riTopic").value.trim();
      window.Exporter[kind](it.title.slice(0, 60) + (tp ? " — " + tp.slice(0, 30) : ""), result, { tool: "مكتبة الموارد" });
    }
    document.getElementById("riWord").addEventListener("click", function () { riExport("docx"); });
    document.getElementById("riPdf").addEventListener("click", function () { riExport("pdf"); });
    document.getElementById("riSave").addEventListener("click", function () {
      var cu = (typeof window.getOrCreateActiveUser === "function") ? window.getOrCreateActiveUser() : getCurrentUser(); if (!cu) { openGoogleAuthModal(); return; }
      if (!result) return;
      if (!Array.isArray(cu.savedPrompts)) cu.savedPrompts = [];
      cu.savedPrompts.unshift({ id: "sp-" + Date.now(), topic: document.getElementById("riTopic").value.trim().slice(0, 80), grade: document.getElementById("riGrade").value, subject: document.getElementById("riSubject").value, goal: it.title.slice(0, 80), aiModel: "AI", strategy: "", date: new Date().toLocaleDateString("ar-EG"), text: result.slice(0, 8000) });
      saveState(); renderUserWorkspace(); showToast("تم الحفظ في حسابك ✓", "success");
    });
  };

  function hookBloom() {
    var copy = document.getElementById("btnCopyBloomObj");
    if (!copy || document.getElementById("btnBloomAI")) return;
    var b = document.createElement("button");
    b.id = "btnBloomAI"; b.type = "button";
    b.className = "px-3.5 py-2 rounded-xl bg-gradient-to-l from-purple-600 to-brand-600 text-white text-xs font-extrabold flex items-center gap-1.5";
    b.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i><span>ولّد أسئلة تحقق الهدف</span>';
    copy.parentNode.insertBefore(b, copy.nextSibling);
    if (window.Exporter) { var bb = document.createElement("span"); bb.className = "contents"; bb.innerHTML = window.Exporter.bar({ src: "#bloomOutputBox", title: "هدف سلوكي (هرم بلوم)", tool: "هرم بلوم", copy: false }); b.parentNode.insertBefore(bb, b.nextSibling); }
    b.addEventListener("click", function () {
      var obj = (document.getElementById("bloomOutputBox") || {}).textContent;
      obj = obj ? obj.trim() : "";
      if (!obj || !guard()) return;
      lastCall = Date.now();
      showToast("⏳ جارٍ توليد الأسئلة…", "info");
      window.AI.ask("الهدف السلوكي: " + obj + "\nضع 5 أسئلة متدرجة تقيس تحقق هذا الهدف مع مفتاح الإجابة، بالعربية وبتنسيق منظم.", null, "bloom").then(function (txt) {
        showModalContent('<div class="p-4 shrink-0 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between"><h3 class="text-sm font-extrabold">أسئلة تحقق الهدف</h3><button type="button" class="p-2 text-slate-400" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button></div>' +
          '<div class="p-4 overflow-y-auto flex-1 min-h-0 text-right"><div id="bloomAIRes" class="text-xs leading-loose whitespace-pre-wrap"></div><div class="mt-3 flex flex-wrap gap-2"><button id="bloomAICopy" type="button" class="px-3.5 py-2 rounded-xl bg-brand-600 text-white text-[11px] font-bold">نسخ</button>' + (window.Exporter ? window.Exporter.bar({ src: "#bloomAIRes", tool: "هرم بلوم", copy: false }) : "") + '</div></div>');
        showRes(document.getElementById("bloomAIRes"), txt, "أسئلة تحقق الهدف: " + obj.replace(/\s+/g, " ").slice(0, 45), "هرم بلوم");
        document.getElementById("bloomAICopy").addEventListener("click", function () { copyTextToClipboard(txt, "تم النسخ 📋"); });
      }).catch(function (err) { showToast("تعذر الاتصال بالمساعد الآن (" + String(err && err.message || "خطأ").slice(0, 70) + ")", "warning"); });
    });
  }

  window.addEventListener("DOMContentLoaded", function () { setTimeout(function () { ensureStudio(); hookGenerator(); hookBloom(); }, 0); });
})();

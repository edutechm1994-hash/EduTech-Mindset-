/*
 * منظومة التكامل الشامل، تنظيم خطوات المعلم والطالب حسب احتياجاتهم، ومحرك استيراد المصادر عبر الكاميرا والجهاز
 * EduTech Mindset — الإصدار 80 (Role Journeys, Camera/Device Source Capture & Smart Ecosystem)
 *
 * يقدم هذا الملف:
 * 1) محرك استيراد المصادر الذكي عبر الكاميرا والجهاز والميكروفون والمنهاج (window.EduSourceCapture):
 *    - 📷 تصوير صفحة من الكتاب بالكاميرا (مع معاينة مصغّرة + إرفاق بالـ AI Vision + استخراج النص المكتوب بضغطة زر).
 *    - 📂 رفع ملفات أو صور من الجهاز (صور JPG/PNG/WebP، مستندات PDF، ملفات نصية TXT/MD/CSV/JSON).
 *    - 🎙️ تسجيل وإملاء صوتي باللغة العربية الفصحى مباشرة إلى حقل الدرس.
 *    - 📖 اختيار درس جاهز من فهرس المنهاج الفلسطيني والكتب المحفوظة بضغطة واحدة.
 * 2) ترتيب رحلة المعلم ورحلة الطالب خطوة بخطوة حسب احتياجاتهما الفعلية (#eduRoleOrchestrator):
 *    - للمعلم (4 مراحل مرتبة حسب سير العمل اليومي):
 *      ① التحضير والتخطيط ← ② الشرح والعرض الصفي ← ③ التقويم والاختبارات ← ④ المتابعة والتقارير وأولياء الأمور.
 *    - للطالب (4 مراحل مرتبة حسب رحلة المذاكرة والتفوق):
 *      ① افهم درسك بعمق ← ② لخّص وثبّت بالذاكرة ← ③ اختبر نفسك وتدرّب ← ④ نظّم وقتك وتابع فصلك.
 *    - لولي الأمر وللجمهور العام مسارات مرتبة وواضحة.
 * 3) شريط الخطوات المترابطة أعلى أي أداة مفتوحة (#eduStudioStepChain):
 *    - يعرض للمعلم أو الطالب أين يقف الآن في خطواته وما هي الأداة التالية المقترحة بنقرة واحدة مع تمرير بيانات الدرس تلقائياً.
 * 4) غرفة العمليات التعليمية الموحّدة (#unifiedWorkflowStudio) + بوابة ولي الأمر (#parentPortalStudio) + بوابة الجمهور العام (#publicHubStudio).
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cloud = function () { return !!(window.Cloud && window.Cloud.enabled && window.Cloud.col); };

  var ROLE_KEY = "edu_role_mode_v52";
  var PARENT_KEY = "edu_parent_portal_v78";
  var BRIDGE_KEY = "edu_bridge_ctx_v78";
  var FEED_KEY = "edu_shared_feed_v79";

  // ==================== 1. محرك استيراد المصادر عبر الكاميرا والجهاز والمنهاج (EduSourceCapture) ====================
  var capturedFiles = []; // [{ id, name, mime, data (base64), thumb, kind }]

  // بنك دروس نموذجية سريعة من المنهاج الفلسطيني لتعبئة أي أداة بضغطة واحدة حتى بلا إنترنت
  var CURRICULUM_PRESETS = [
    { grade: "الصف الرابع", subject: "الرياضيات", title: "الكسور العشرية وتمثيلها على خط الأعداد", notes: "الكسر العشري هو كل كسر مقامه 10 أو 100 أو 1000 ويكتب باستعمال الفاصلة العشرية مثل 0.5 و 0.25. الجزء على يمين الفاصلة يمثل الأعشار ثم الأجزاء من مئة." },
    { grade: "الصف الخامس", subject: "العلوم والحياة", title: "الخلية النباتية والخلية الحيوانية", notes: "الخلية هي وحدة البناء والوظيفة في الكائنات الحية. تشترك الخلية النباتية والحيوانية في الغشاء الخلوي والسيتوبلازم والنواة، وتتميز الخلية النباتية بوجود الجدار الخلوي والبلاستيدات الخضراء والفجوة العصارية الكبيرة." },
    { grade: "الصف السادس", subject: "اللغة العربية", title: "الجملة الاسمية: المبتدأ والخبر وأنواعهما", notes: "الجملة الاسمية تبدأ باسم وتتكون من ركنين أساسيين هما: المبتدأ (وهو الاسم المرفوع الذي نبدأ به الجملة) والخبر (وهو الذي يتمم معنى الجملة مع المبتدأ ويكون مرفوعاً)." },
    { grade: "الصف السابع", subject: "العلوم والحياة", title: "عملية البناء الضوئي في النبات", notes: "البناء الضوئي عملية حيوية يقوم بها النبات الأخضر في البلاستيدات الخضراء بوجود ضوء الشمس والكلوروفيل لتحويل الماء وثاني أكسيد الكربون إلى سكر الجلوكوز وغاز الأكسجين." },
    { grade: "الصف الثامن", subject: "الرياضيات", title: "نظرية فيثاغورس وتطبيقاتها الهندسية", notes: "في المثلث القائم الزاوية: مساحة المربع المنشأ على الوتر تساوي مجموع مساحتي المربعين المنشأين على ضلعي القائمة. الصيغة الرياضية: جـ² = أ² + ب²." },
    { grade: "الصف التاسع", subject: "الدراسات الاجتماعية", title: "جغرافية فلسطين: التضاريس والمناخ والأهمية الحضارية", notes: "تتميز فلسطين بتنوع تضاريسها من السهل الساحلي غرباً إلى السلسلة الجبلية الوسطى (الجليل ونابلس والقدس والخليل) ثم غور الأردن والبحر الميت وصحراء النقب جنوباً." },
    { grade: "الصف العاشر", subject: "الفيزياء", title: "قوانين نيوتن في الحركة وتطبيقاتها", notes: "قانون نيوتن الأول (القصور الذاتي)، قانون نيوتن الثاني (القوة المحصلة = الكتلة × التسارع F = m.a)، وقانون نيوتن الثالث (لكل فعل رد فعل مساوٍ له في المقدار ومعاكس له في الاتجاه)." },
    { grade: "الصف الثاني عشر (التوجيهي)", subject: "التكنولوجيا", title: "الذكاء الاصطناعي وقواعد البيانات والشبكات", notes: "يركز المنهاج على تصميم قواعد البيانات العلائقية SQL، أمن المعلومات والشبكات، وتطبيقات الذكاء الاصطناعي والخوارزميات في حل المشكلات الحياتية." }
  ];

  function shrinkImageFile(file) {
    return new Promise(function (res, rej) {
      var url = URL.createObjectURL(file), im = new Image();
      im.onload = function () {
        var maxDim = 1500, k = Math.min(1, maxDim / Math.max(im.width, im.height));
        var c = document.createElement("canvas");
        c.width = Math.max(1, Math.round(im.width * k));
        c.height = Math.max(1, Math.round(im.height * k));
        var cx = c.getContext("2d");
        cx.fillStyle = "#ffffff";
        cx.fillRect(0, 0, c.width, c.height);
        cx.drawImage(im, 0, 0, c.width, c.height);
        var tc = document.createElement("canvas");
        tc.width = 96;
        tc.height = Math.max(1, Math.round(96 * c.height / c.width));
        tc.getContext("2d").drawImage(c, 0, 0, tc.width, tc.height);
        URL.revokeObjectURL(url);
        res({
          kind: "img",
          name: file.name && file.name !== "image.jpg" ? file.name : ("صفحة مصوّرة " + new Date().toLocaleTimeString("ar")),
          mime: "image/jpeg",
          data: c.toDataURL("image/jpeg", 0.82).split(",")[1],
          thumb: tc.toDataURL("image/jpeg", 0.65)
        });
      };
      im.onerror = function () { URL.revokeObjectURL(url); rej(new Error("img")); };
      im.src = url;
    });
  }

  function fileToBase64(file) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result || "").split(",")[1] || ""); };
      r.onerror = rej;
      r.readAsDataURL(file);
    });
  }

  function fileToText(file) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result || "")); };
      r.onerror = rej;
      r.readAsText(file, "utf-8");
    });
  }

  function handleUploadedFiles(fileList, opts) {
    opts = opts || {};
    var arr = Array.prototype.slice.call(fileList || []);
    if (!arr.length) return Promise.resolve([]);
    var newlyAdded = [];

    return arr.reduce(function (p, f) {
      return p.then(function () {
        var isTxt = /^text\//.test(f.type) || /\.(txt|md|markdown|csv|json)$/i.test(f.name || "");
        var isPdf = f.type === "application/pdf" || /\.pdf$/i.test(f.name || "");
        var isImg = /^image\//.test(f.type) || /\.(jpg|jpeg|png|webp|gif)$/i.test(f.name || "");

        if (isTxt) {
          return fileToText(f).then(function (txt) {
            if (opts.onText && txt.trim()) opts.onText(txt.trim(), f.name);
            if (window.EduSources && window.EduSources.addRaw) { try { window.EduSources.addRaw({ kind: "md", name: f.name, mime: "text/markdown", markdown: txt.trim(), data: btoa(unescape(encodeURIComponent(txt.trim()))) }, true); } catch (e) {} }
            toast("📝 تم استيراد ملف الـ Markdown/النص «" + f.name + "» وتسجيله في قاعدة بيانات الموقع ✓", "success");
          });
        }
        if (isPdf) {
          if (f.size > 150 * 1024 * 1024) {
            toast("حجم ملف PDF كبير (الحد الأقصى 150 ميغابايت)", "warning");
            return;
          }
          return fileToBase64(f).then(function (b64) {
            var item = {
              id: "cf_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
              kind: "pdf",
              name: f.name || "ملف.pdf",
              mime: "application/pdf",
              data: b64,
              thumb: ""
            };
            capturedFiles.unshift(item);
            capturedFiles = capturedFiles.slice(0, 8);
            newlyAdded.push(item);
            if (window.EduSources && window.EduSources.addRaw) {
              try { window.EduSources.addRaw(item, true); } catch (e) {}
            }
            toast("📕 تم إرفاق ملف PDF «" + item.name + "» كمصدر للذكاء الاصطناعي ✓", "success");
          });
        }
        if (isImg) {
          return shrinkImageFile(f).then(function (imgObj) {
            imgObj.id = "cf_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
            capturedFiles.unshift(imgObj);
            capturedFiles = capturedFiles.slice(0, 8);
            newlyAdded.push(imgObj);
            toast("📷 تم التقاط وإرفاق صورة الصفحة بنجاح ✓", "success");
          }).catch(function () {
            toast("تعذّر قراءة الصورة", "warning");
          });
        }
        toast("يرجى اختيار صورة (كاميرا/استوديو) أو ملف PDF أو ملف نصي TXT", "warning");
      });
    }, Promise.resolve()).then(function () {
      if (opts.onUpdate) opts.onUpdate(capturedFiles, newlyAdded);
      return newlyAdded;
    });
  }

  // استخراج النص والعنوان من الصور/الملفات المرفقة بالذكاء الاصطناعي (Vision OCR)
  function extractTextFromCaptured(opts) {
    opts = opts || {};
    if (!capturedFiles.length) {
      toast("صوّر صفحة من الكتاب بالكاميرا أو ارفع صورة/ملفاً أولاً", "warning");
      return Promise.resolve("");
    }
    if (!window.AI || !window.AI.ask) {
      toast("المرفقات محفوظة وجاهزة للتوليد مباشرة", "info");
      return Promise.resolve("");
    }
    var filesPayload = capturedFiles.slice(0, 4).map(function (c) {
      return { mime: c.mime, data: c.data, name: c.name };
    });
    var prompt = "اقرأ الصفحة أو المستند المرفق بدقة (من المنهاج الفلسطيني)، واستخرج منه:\n" +
      "1) عنوان الدرس في السطر الأول مسبوقاً بـ «العنوان: ».\n" +
      "2) النص الكامل أو الملخص الدقيق والنقاط والأمثلة والأسئلة الواردة في الصفحة بالعربية الفصحى الواضحة.";
    return window.AI.ask(prompt, filesPayload, "prep").then(function (txt) {
      var res = String(txt || "").trim();
      if (res && opts.onExtracted) opts.onExtracted(res);
      toast("🔍 تم قراءة واستخراج محتوى الصفحة بالذكاء الاصطناعي ✓", "success");
      return res;
    }).catch(function () {
      toast("الصورة مرفقة وجاهزة — سيعتمد عليها الذكاء الاصطناعي مباشرة عند الضغط على «ولّد» ✓", "info");
      return "";
    });
  }

  // تسجيل صوتي بالميكروفون لتحويل كلام المعلم أو الطالب إلى نص في حقل الدرس
  function startVoiceDictation(targetInputEl, btnEl) {
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      toast("متصفحك لا يدعم الإملاء الصوتي المباشر — يمكنك استخدام ميكروفون لوحة المفاتيح", "warning");
      return;
    }
    if (btnEl && btnEl._recActive) {
      try { btnEl._recInstance.stop(); } catch (e) {}
      return;
    }
    var rec = new SR();
    rec.lang = "ar-PS";
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    var origHtml = btnEl ? btnEl.innerHTML : "";
    if (btnEl) {
      btnEl._recActive = true;
      btnEl._recInstance = rec;
      btnEl.innerHTML = '🔴 جارٍ الاستماع… اضغط للإيقاف';
      btnEl.classList.add("animate-pulse");
    }
    toast("🎙️ تحدّث الآن بوضوح… سيتم كتابة كلامك تلقائياً", "info");
    rec.onresult = function (ev) {
      var transcript = ev.results && ev.results[0] && ev.results[0][0] ? ev.results[0][0].transcript : "";
      if (transcript && targetInputEl) {
        targetInputEl.value = (targetInputEl.value ? targetInputEl.value.trim() + " " : "") + transcript.trim();
        targetInputEl.dispatchEvent(new Event("input", { bubbles: true }));
        targetInputEl.dispatchEvent(new Event("change", { bubbles: true }));
        toast("🎙️ تمت كتابة النص الصوتي بنجاح ✓", "success");
      }
    };
    rec.onerror = function () { toast("تعذّر التقاط الصوت، تأكد من السماح للميكروفون", "warning"); };
    rec.onend = function () {
      if (btnEl) {
        btnEl._recActive = false;
        btnEl.innerHTML = origHtml;
        btnEl.classList.remove("animate-pulse");
      }
    };
    try { rec.start(); } catch (e) {}
  }

  // نافذة اختيار درس سريع من فهرس المنهاج أو الكتب المدرسية
  function openCurriculumPickerModal(onPick) {
    if (typeof showModalContent !== "function") return;
    var bookLessons = [];
    try {
      (window.EduBooks && window.EduBooks.list ? window.EduBooks.list() : []).forEach(function (b) {
        (b.lessons || []).forEach(function (l) {
          if (l && l.t) bookLessons.push({ grade: b.grade || "", subject: b.subject || b.title || "", title: l.t, notes: l.x || ("من كتاب: " + (b.title || "")) });
        });
      });
    } catch (e) {}
    var allItems = bookLessons.concat(CURRICULUM_PRESETS);

    var html =
      '<div class="p-4 shrink-0 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-900 text-white">' +
        '<div><h3 class="text-sm sm:text-base font-black">📖 اختيار درس جاهز من المنهاج الفلسطيني</h3>' +
        '<p class="text-[11px] text-slate-300">اضغط على أي درس لتعبئة الصف والمادة والعنوان والنص تلقائياً</p></div>' +
        '<button type="button" class="p-2 text-slate-300 hover:text-white" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button>' +
      '</div>' +
      '<div class="p-4 space-y-2.5 text-right overflow-y-auto max-h-[70vh]">' +
        allItems.map(function (it, idx) {
          return '<button type="button" data-cur-pick="' + idx + '" class="w-full text-right p-3 rounded-2xl border border-slate-200 dark:border-slate-700 hover:border-brand-500 bg-white dark:bg-slate-800 transition flex items-start justify-between gap-2">' +
            '<div class="min-w-0 flex-1">' +
              '<div class="text-xs font-black text-slate-900 dark:text-white">' + esc(it.title) + '</div>' +
              '<div class="text-[10px] font-bold text-brand-600 dark:text-sky-400 mt-0.5">' + esc([it.grade, it.subject].filter(Boolean).join(" • ")) + '</div>' +
              '<div class="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">' + esc(it.notes) + '</div>' +
            '</div>' +
            '<span class="px-2.5 py-1 rounded-xl bg-brand-600 text-white text-[10px] font-black shrink-0 self-center">اختر الدرس</span>' +
          '</button>';
        }).join("") +
      '</div>';
    showModalContent(html);
    document.querySelectorAll("[data-cur-pick]").forEach(function (b) {
      b.onclick = function () {
        var picked = allItems[+b.getAttribute("data-cur-pick")];
        closeModal();
        if (picked && typeof onPick === "function") onPick(picked);
      };
    });
  }

  // بناء شريط «📷 إضافة مصادر عبر الكاميرا أو من الجهاز أو الصوت أو المنهاج» القابل للتركيب داخل أي أداة
  function renderSourceBarHtml(prefix) {
    prefix = prefix || "sc";
    var thumbs = capturedFiles.map(function (f, i) {
      return '<div class="relative inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white dark:bg-slate-900 border border-emerald-500/40 text-[11px] font-bold shadow-xs">' +
        (f.thumb ? '<img src="' + f.thumb + '" alt="" class="w-8 h-8 rounded-lg object-cover border">' : '<span class="text-base">📕</span>') +
        '<span class="max-w-[110px] truncate">' + esc(f.name) + '</span>' +
        '<button type="button" data-sc-rm="' + i + '" class="w-5 h-5 rounded-full bg-rose-500/15 text-rose-600 hover:bg-rose-600 hover:text-white text-xs flex items-center justify-center" title="إزالة المرفق">×</button>' +
      '</div>';
    }).join("");

    return '<div class="rounded-2xl border border-emerald-500/30 bg-gradient-to-l from-emerald-500/10 via-sky-500/5 to-indigo-500/10 p-3 space-y-2 text-right" data-sc-bar="' + esc(prefix) + '">' +
      '<div class="flex flex-wrap items-center justify-between gap-2">' +
        '<div class="flex items-center gap-1.5 text-xs font-black text-emerald-800 dark:text-emerald-300">' +
          '<span>📷 أضف مصدر الدرس (كاميرا الجوال • صورة أو ملف من الجهاز • إملاء صوتي • درس جاهز):</span>' +
        '</div>' +
        (capturedFiles.length ? '<span class="px-2 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-black">✓ ' + capturedFiles.length + ' مصدر مرفق بالـ AI</span>' : '<span class="text-[10px] font-bold text-slate-500 dark:text-slate-400">يعمل مباشرة مع الذكاء الاصطناعي</span>') +
      '</div>' +
      '<div class="flex flex-wrap items-center gap-1.5">' +
        '<label class="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95 transition">' +
          '<i class="fa-solid fa-camera"></i><span>تصوير صفحة بالكاميرا</span>' +
          '<input type="file" accept="image/*" capture="environment" class="hidden" data-sc-cam="' + esc(prefix) + '">' +
        '</label>' +
        '<label class="px-3 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-black cursor-pointer flex items-center gap-1.5 shadow-sm active:scale-95 transition">' +
          '<i class="fa-solid fa-folder-open"></i><span>رفع PDF / Markdown (.md) / صورة</span>' +
          '<input type="file" accept="image/*,application/pdf,.pdf,.md,.markdown,.txt,.csv,.json" multiple class="hidden" data-sc-file="' + esc(prefix) + '">' +
        '</label>' +
        '<button type="button" data-sc-mic="' + esc(prefix) + '" class="px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black flex items-center gap-1.5 shadow-sm active:scale-95 transition">' +
          '<i class="fa-solid fa-microphone"></i><span>إملاء صوتي</span>' +
        '</button>' +
        '<button type="button" data-sc-preset="' + esc(prefix) + '" class="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black flex items-center gap-1.5 shadow-sm active:scale-95 transition">' +
          '<i class="fa-solid fa-book-open"></i><span>اختر درساً من المنهاج</span>' +
        '</button>' +
        (capturedFiles.length ? '<button type="button" data-sc-ocr="' + esc(prefix) + '" class="px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black flex items-center gap-1.5 shadow-sm transition">🔍 استخرج النص من الصورة بالـ AI</button>' : '') +
        '<button type="button" data-sc-openhub="' + esc(prefix) + '" class="px-2.5 py-2 rounded-xl bg-white/80 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-extrabold hover:border-brand-500 transition" title="إدارة مكتبة مصادري المحفوظة">🗄️ مصادري وقاعدة Markdown (500MB)</button>' +
      '</div>' +
      (thumbs ? '<div class="flex flex-wrap items-center gap-1.5 pt-1">' + thumbs + '</div>' : '') +
    '</div>';
  }

  // ربط أحداث شريط المصادر بأي حاوية
  function bindSourceBar(container, cfg) {
    if (!container) return;
    cfg = cfg || {};
    var getNotesEl = function () { return typeof cfg.notesEl === "function" ? cfg.notesEl() : $(cfg.notesId); };
    var getTitleEl = function () { return typeof cfg.titleEl === "function" ? cfg.titleEl() : $(cfg.titleId); };
    var getGradeEl = function () { return typeof cfg.gradeEl === "function" ? cfg.gradeEl() : $(cfg.gradeId); };
    var getSubjEl = function () { return typeof cfg.subjEl === "function" ? cfg.subjEl() : $(cfg.subjId); };

    function setElVal(el, val) {
      if (!el || !val) return;
      if (el.tagName === "SELECT") {
        var norm = String(val).replace(/^الصف\s+/, "").trim();
        for (var i = 0; i < el.options.length; i++) {
          var t = (el.options[i].value || el.options[i].text || "").trim();
          if (t === val || t.indexOf(norm) !== -1 || norm.indexOf(t.replace(/^الصف\s+/, "")) !== -1) {
            el.value = el.options[i].value || el.options[i].text;
            break;
          }
        }
      } else {
        el.value = val;
      }
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }

    container.querySelectorAll("[data-sc-cam], [data-sc-file]").forEach(function (inp) {
      inp.onchange = function (ev) {
        handleUploadedFiles(ev.target.files, {
          onText: function (txt, fname) {
            var nEl = getNotesEl() || getTitleEl();
            if (nEl) setElVal(nEl, (nEl.value ? nEl.value + "\n\n" : "") + txt.slice(0, 5000));
            var tEl = getTitleEl();
            if (tEl && !tEl.value.trim() && fname) setElVal(tEl, fname.replace(/\.[^.]+$/, ""));
          },
          onUpdate: function () {
            if (typeof cfg.onRefresh === "function") cfg.onRefresh();
          }
        });
        ev.target.value = "";
      };
    });

    container.querySelectorAll("[data-sc-rm]").forEach(function (btn) {
      btn.onclick = function () {
        var idx = +btn.getAttribute("data-sc-rm");
        capturedFiles.splice(idx, 1);
        if (typeof cfg.onRefresh === "function") cfg.onRefresh();
      };
    });

    container.querySelectorAll("[data-sc-mic]").forEach(function (btn) {
      btn.onclick = function () {
        var target = getNotesEl() || getTitleEl();
        startVoiceDictation(target, btn);
      };
    });

    container.querySelectorAll("[data-sc-preset]").forEach(function (btn) {
      btn.onclick = function () {
        openCurriculumPickerModal(function (picked) {
          if (getGradeEl() && picked.grade) setElVal(getGradeEl(), picked.grade);
          if (getSubjEl() && picked.subject) setElVal(getSubjEl(), picked.subject);
          if (getTitleEl() && picked.title) setElVal(getTitleEl(), picked.title);
          if (getNotesEl() && picked.notes) setElVal(getNotesEl(), picked.notes);
          if (typeof cfg.onPickPreset === "function") cfg.onPickPreset(picked);
          toast("📖 تم تعبئة بيانات درس «" + picked.title + "» بنجاح ✓", "success");
        });
      };
    });

    container.querySelectorAll("[data-sc-ocr]").forEach(function (btn) {
      btn.onclick = function () {
        btn.disabled = true;
        btn.textContent = "⏳ جارٍ قراءة الصفحة بالـ AI…";
        extractTextFromCaptured({
          onExtracted: function (txt) {
            var lines = txt.split("\n");
            var first = lines[0] || "";
            if (/^العنوان\s*:/.test(first) && getTitleEl() && !getTitleEl().value.trim()) {
              setElVal(getTitleEl(), first.replace(/^العنوان\s*:\s*/, "").trim());
            }
            var nEl = getNotesEl() || getTitleEl();
            if (nEl) setElVal(nEl, txt.slice(0, 5500));
            if (typeof cfg.onRefresh === "function") cfg.onRefresh();
          }
        }).then(function () {
          btn.disabled = false;
          btn.textContent = "🔍 استخرج النص من الصورة بالـ AI";
        });
      };
    });

    container.querySelectorAll("[data-sc-openhub]").forEach(function (btn) {
      btn.onclick = function () {
        if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("sourcesStudio", true);
      };
    });
  }

  // ربط الصور الملتقطة تلقائياً بكل طلبات الذكاء الاصطناعي window.AI.ask إن لم تكن مرسلة
  function hookCapturedIntoAI() {
    if (!window.AI || !window.AI.ask || window.AI.ask.__capHooked) return;
    var origAsk = window.AI.ask;
    window.AI.ask = function (prompt, files, toolId) {
      var baseFiles = Array.isArray(files) ? files.slice() : [];
      if (capturedFiles.length && baseFiles.length < 6) {
        capturedFiles.slice(0, 4).forEach(function (cf) {
          var exists = baseFiles.some(function (bf) { return bf && bf.data === cf.data; });
          if (!exists) baseFiles.push({ mime: cf.mime, data: cf.data, name: cf.name });
        });
      }
      return origAsk.call(window.AI, prompt, baseFiles, toolId);
    };
    window.AI.ask.__capHooked = true;
  }

  // ==================== 2. ترتيب خطوات المعلم والطالب وولي الأمر والجمهور حسب احتياجاتهم ====================
  var PERSONAS = {
    teacher: {
      id: "teacher",
      ico: "👨‍🏫",
      short: "المعلم",
      title: "بوابة المعلم المنظّمة (مرتبة في 4 مراحل حسب سير الحصة)",
      subtitle: "اختر المرحلة التي تحتاجها الآن: من تحضير الدرس وتصوير الكتاب ← إلى الشرح الصفي ← ثم الاختبارات والتصحيح ← وحتى تقارير أولياء الأمور",
      gradient: "from-indigo-600 via-blue-700 to-slate-900",
      badgeCls: "bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 border-indigo-500/30",
      stages: [
        {
          num: "المرحلة 1",
          ico: "📋",
          title: "التحضير والتخطيط وتصوير الكتاب",
          desc: "حضّر حصتك كاملة من عنوان الدرس أو بتصوير صفحة الكتاب بالكاميرا",
          color: "border-indigo-500/35 bg-indigo-500/5",
          headBg: "bg-indigo-600 text-white",
          tools: [
            { ico: "📖", label: "قارئ ومعاين الكتب التفاعلي", sub: "اقرأ الفصل وظلل لنقله للأدوات", app: "bookReaderStudio" },
            { ico: "🧳", label: "حقيبة الحصة الجاهزة", sub: "خطة + ورقة عمل + اختبار بنقرة", app: "lessonKitStudio" },
            { ico: "📘", label: "مولّد خطط الدروس", sub: "تحضير وزاري ومبسط Word/PDF", app: "lessonPlanStudio" },
            { ico: "📷", label: "مصادري وتصوير الكتاب", sub: "ارفع PDF أو صوّر صفحات الدرس", app: "sourcesStudio" }
          ]
        },
        {
          num: "المرحلة 2",
          ico: "🖍️",
          title: "الشرح الصفي والعروض التفاعلية",
          desc: "اشرح درسك بملء الشاشة على السبورة أو بالشرائح التفاعلية والألعاب",
          color: "border-sky-500/35 bg-sky-500/5",
          headBg: "bg-sky-600 text-white",
          tools: [
            { ico: "🖍️", label: "السبورة التفاعلية الذكية", sub: "شرح فوق صورة الكتاب وتسجيل فيديو", app: "whiteboardStudio" },
            { ico: "🎞", label: "مولّد العروض التقديمية", sub: "شرائح + تصويت حي + PowerPoint", app: "slidesStudio" },
            { ico: "🎮", label: "المسابقات والألعاب الصفية", sub: "5 ألعاب + مسابقة حية برمز PIN", app: "gamesStudio" },
            { ico: "🧰", label: "أدوات ضبط وإدارة الصف", sub: "مؤقت الحصة والقرعة والمجموعات", app: "classToolsStudio" }
          ]
        },
        {
          num: "المرحلة 3",
          ico: "📝",
          title: "التقويم وأوراق العمل والتصحيح",
          desc: "ولّد أوراق عمل واختبارات بمستويين، وصحح دفاتر الطلاب بالكاميرا",
          color: "border-emerald-500/35 bg-emerald-500/5",
          headBg: "bg-emerald-600 text-white",
          tools: [
            { ico: "📝", label: "أوراق العمل والاختبارات", sub: "توليد بالـ AI أو الكاميرا + PDF", app: "worksheetStudio" },
            { ico: "📸", label: "مصحح الدفاتر بالكاميرا", sub: "قراءة خط الطالب وتصحيحه بالـ AI", app: "homeworkStudio" },
            { ico: "🫧", label: "أوراق التظليل وسلالم التقدير", sub: "تصحيح سريع ومعايير تقييم", app: "rubricsStudio" },
            { ico: "🗃️", label: "بنك الأسئلة التفاعلي", sub: "حفظ الأسئلة وتصديرها", app: "questionBank" }
          ]
        },
        {
          num: "المرحلة 4",
          ico: "🏫",
          title: "الفصول والتقارير وأولياء الأمور",
          desc: "انشر المهام لطلابك، رصد الدرجات، أرسل بطاقة واتساب لولي الأمر وكرم المتفوقين",
          color: "border-amber-500/35 bg-amber-500/5",
          headBg: "bg-amber-600 text-white",
          tools: [
            { ico: "🎒", label: "الفصول وسجل الدرجات", sub: "إدارة الشعب والواجبات والدرجات", app: "classroomsStudio" },
            { ico: "👨‍👩‍👧‍👦", label: "بطاقة متابعة لولي الأمر", sub: "تقرير مصور وإرسال مباشر واتساب", app: "parentsStudio" },
            { ico: "🏅", label: "شهادات التفوق الجماعية", sub: "دفتر شهادات PDF لقائمة الفصل", app: "certStudio" },
            { ico: "📁", label: "ملف الإنجاز والخطط العلاجية", sub: "توثيق أعمال المعلم والخطط", app: "portfolioStudio" }
          ]
        }
      ],
      chain: ["sourcesStudio", "lessonKitStudio", "lessonPlanStudio", "slidesStudio", "whiteboardStudio", "worksheetStudio", "gamesStudio", "homeworkStudio", "classroomsStudio", "parentsStudio", "certStudio"]
    },
    student: {
      id: "student",
      ico: "👨‍🎓",
      short: "الطالب",
      title: "بوابة الطالب المنظّمة (مرتبة في 4 خطوات للتفوق)",
      subtitle: "رحلة مذاكرة واضحة خطوة بخطوة: افهم درسك أو صوّر صفحته ← لخّصه وثبّته بالذاكرة ← اختبر نفسك ← ونظّم جدولك وفصلك",
      gradient: "from-emerald-600 via-teal-600 to-cyan-700",
      badgeCls: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30",
      stages: [
        {
          num: "الخطوة 1",
          ico: "📖",
          title: "افهم درسك بعمق (من الكتاب أو الكاميرا)",
          desc: "شاهد شرح الدرس أو صوّر صفحة كتابك ليشرحها لك المعلم الخصوصي الذكي",
          color: "border-emerald-500/35 bg-emerald-500/5",
          headBg: "bg-emerald-600 text-white",
          tools: [
            { ico: "📖", label: "قارئ ومعاين الكتب التفاعلي", sub: "اقرأ كتابك وظلل أي فقرة للشرح", app: "bookReaderStudio" },
            { ico: "🏫", label: "دروس المراحل والفيديو", sub: "اختر صفك ومادتك وشاهد الشرح", app: "learnSection" },
            { ico: "🤖", label: "المعلم الخصوصي الذكي", sub: "حوار سقراطي وشرح مبسط وبودكاست", app: "tutorStudio" },
            { ico: "📷", label: "صوّر صفحة كتابك للشرح", sub: "ارفع صورة الدرس ليفسره الـ AI", app: "sourcesStudio" }
          ]
        },
        {
          num: "الخطوة 2",
          ico: "🧠",
          title: "لخّص وثبّت في الذاكرة طويلة المدى",
          desc: "حوّل الدرس إلى خريطة ذهنية وبطاقات استذكار تتكرر معك ذكياً قبل نسيانها",
          color: "border-teal-500/35 bg-teal-500/5",
          headBg: "bg-teal-600 text-white",
          tools: [
            { ico: "🔁", label: "المراجعة الذكية (تكرار متباعد)", sub: "بطاقات يومية لحفظ القوانين والمفردات", app: "reviewStudio" },
            { ico: "🧠", label: "الخرائط الذهنية والبطاقات", sub: "تلخيص بصري شامل لفروع الدرس", app: "tutorStudio" },
            { ico: "📥", label: "حقيبة المذاكرة بلا إنترنت", sub: "نزّل ملخصاتك لمذاكرتها وقت الانقطاع", app: "offPackStudio" },
            { ico: "🔊", label: "القارئ الصوتي والنطق", sub: "استمع لشرح النصوص وتدرّب على النطق", app: "langLabStudio" }
          ]
        },
        {
          num: "الخطوة 3",
          ico: "🎯",
          title: "اختبر نفسك وتدرّب عملياً",
          desc: "تأكد من إتقانك للدرس عبر اختبارات فورية مصححة وتجارب علمية تفاعلية",
          color: "border-violet-500/35 bg-violet-500/5",
          headBg: "bg-violet-600 text-white",
          tools: [
            { ico: "🎯", label: "اختبر نفسك بالـ AI", sub: "أسئلة فورية من درسك مع التصحيح", app: "selfQuiz" },
            { ico: "🔥", label: "التحدي اليومي السريع", sub: "5 أسئلة يومية لحصد نقاط الخبرة XP", app: "dailyChallenge" },
            { ico: "🧪", label: "مختبر التجارب والحاسبة", sub: "محاكيات الفيزياء والعلوم والحاسبة", app: "simLabStudio" },
            { ico: "🎮", label: "الألعاب التعليمية والمسابقات", sub: "تعلّم باللعب أو ادخل مسابقة معلمك", app: "gamesStudio" }
          ]
        },
        {
          num: "الخطوة 4",
          ico: "🎒",
          title: "فصلي وواجباتي وتنظيم وقتي",
          desc: "ادخل فصل معلمك بالرمز، سلّم واجباتك، ونظّم جدول مذاكرتك ومعدل التوجيهي",
          color: "border-amber-500/35 bg-amber-500/5",
          headBg: "bg-amber-600 text-white",
          tools: [
            { ico: "🎒", label: "فصلي الافتراضي وواجباتي", sub: "ادخل برمز المعلم لحل مهام الفصل", app: "classroomsStudio" },
            { ico: "🗓️", label: "جدول مذاكرتي الأسبوعي", sub: "نظّم ساعات الدراسة والمهام اليومية", app: "weeklyPlannerStudio" },
            { ico: "🎓", label: "بوابة التوجيهي والمعدل", sub: "حاسبة المعدل وجدول الختم والجامعات", app: "tawjihiStudio" },
            { ico: "👨‍🎓", label: "مساحتي وأوسمتي المحفوظة", sub: "ملاحظاتي ونقاطي وشهادات تفوقي", app: "userWorkspaceSection" }
          ]
        }
      ],
      chain: ["learnSection", "sourcesStudio", "tutorStudio", "reviewStudio", "selfQuiz", "offPackStudio", "classroomsStudio", "weeklyPlannerStudio"]
    },
    university: {
      id: "university",
      ico: "🎓",
      short: "الجامعي والـ CV",
      title: "بوابة الطالب الجامعي والخريج والتأهيل المهني (4 مراحل)",
      subtitle: "من بناء السيرة الذاتية الاحترافية (CV) بالعربية والإنجليزية ← إلى تحويل الكتب والمراجع لـ Markdown ← ثم التلخيص والبحث ← ومشاريع التخرج",
      gradient: "from-indigo-700 via-blue-800 to-slate-950",
      badgeCls: "bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 border-indigo-500/30",
      stages: [
        {
          num: "المرحلة 1",
          ico: "📄",
          title: "السيرة الذاتية الاحترافية (CV) والتوظيف",
          desc: "أنشئ سيرة ذاتية احترافية بالعربية والإنجليزية متوافقة مع ATS وخطاب تقديم للمنح والشركات",
          color: "border-amber-500/40 bg-amber-500/5",
          headBg: "bg-amber-500 text-slate-950",
          tools: [
            { ico: "📄", label: "منشئ السيرة الذاتية (CV عربي/EN)", sub: "قوالب ATS + ترجمة فورية + PDF/Word", app: "cvBuilderStudio" },
            { ico: "🔬", label: "الأبحاث وتوثيق APA ومحاكي المقابلات", sub: "مشاريع التخرج + مراجع APA + مقابلات", app: "uniResearchCareerStudio" },
            { ico: "🎓", label: "المستشار الجامعي والتخصصات", sub: "توجيه أكاديمي ومهني للجامعات", app: "tawjihiStudio" },
            { ico: "📁", label: "ملف الإنجاز المهني (Portfolio)", sub: "توثيق المشاريع والشهادات", app: "portfolioStudio" },
            { ico: "🏅", label: "الدورات التدريبية والمهنية", sub: "برامج مهارات سوق العمل والـ AI", app: "coursesSection" }
          ]
        },
        {
          num: "المرحلة 2",
          ico: "🗄️",
          title: "الكتب الجامعية وتحويل PDF لـ Markdown",
          desc: "ارفع مراجعك وكتبك الجامعية (حتى 500MB) وحوّلها لقاعدة بيانات Markdown وقارئ تفاعلي",
          color: "border-rose-500/35 bg-rose-500/5",
          headBg: "bg-rose-600 text-white",
          tools: [
            { ico: "🗄️", label: "مصادري ومحوّل PDF لـ Markdown", sub: "سعة 500MB + تسجيل بقاعدة الموقع", app: "sourcesStudio" },
            { ico: "📖", label: "قارئ ومعاين الكتب التفاعلي", sub: "قراءة وتظليل واقتباس للأدوات", app: "bookReaderStudio" },
            { ico: "🎙️", label: "البودكاست التفاعلي ودمج الفصول", sub: "حوار صوتي + مقارنة بين كتابين", app: "multiSourceSynthStudio" },
            { ico: "🗜️", label: "ضغط الصور ودمج ملفات PDF", sub: "تجهيز الأبحاث والتقارير محلياً", app: "mediaToolsStudio" }
          ]
        },
        {
          num: "المرحلة 3",
          ico: "🧠",
          title: "البحث الأكاديمي والخرائط الذهنية",
          desc: "لخّص المحاضرات الجامعية الطويلة، ارسم خرائط ذهنية، وثبّت المصطلحات بالتكرار المتباعد",
          color: "border-emerald-500/35 bg-emerald-500/5",
          headBg: "bg-emerald-600 text-white",
          tools: [
            { ico: "🤖", label: "المعلم والباحث الذكي والخرائط", sub: "شرح محاضرات + خرائط ذهنية", app: "tutorStudio" },
            { ico: "🔁", label: "المراجعة المتباعدة للمصطلحات", sub: "حفظ المصطلحات الإنجليزية والعلمية", app: "reviewStudio" },
            { ico: "✨", label: "صياغة أوامر البحث العلمي (Prompts)", sub: "برومبتات أكاديمية وبحثية دقيقة", app: "generator" }
          ]
        },
        {
          num: "المرحلة 4",
          ico: "💻",
          title: "العروض التقديمية والمختبرات الجامعية",
          desc: "صمّم عرض مناقشة مشروع التخرج وتدرّب في مختبر البرمجة والحاسبة العلمية",
          color: "border-sky-500/35 bg-sky-500/5",
          headBg: "bg-sky-600 text-white",
          tools: [
            { ico: "🎞", label: "مولّد عروض مشاريع التخرج", sub: "شرائح احترافية + تصدير PPTX", app: "slidesStudio" },
            { ico: "💻", label: "أكاديمية البرمجة والخوارزميات", sub: "كتابة وتجربة الأكواد البرمجية", app: "codingLabStudio" },
            { ico: "🧮", label: "الحاسبة العلمية وراسم الدوال", sub: "معادلات وتكامل وتمثيل بياني", app: "sciCalcStudio" },
            { ico: "🗓️", label: "جدول المحاضرات والمهام الأسبوعي", sub: "تنظيم جدول الفصل الجامعي", app: "weeklyPlannerStudio" }
          ]
        }
      ],
      chain: ["cvBuilderStudio", "uniResearchCareerStudio", "sourcesStudio", "bookReaderStudio", "tutorStudio", "slidesStudio", "codingLabStudio", "weeklyPlannerStudio"]
    },
    parent: {
      id: "parent",
      ico: "👨‍👩‍👧‍👦",
      short: "ولي الأمر",
      title: "بوابة ولي الأمر والأسرة المنظّمة",
      subtitle: "متابعة الأبناء خطوة بخطوة: تفقّد مستوى ابنك وواجباته ← نظّم جدوله المنزلي ← وساعده في المراجعة والتأسيس",
      gradient: "from-teal-700 via-emerald-700 to-slate-900",
      badgeCls: "bg-teal-500/15 text-teal-700 dark:text-teal-300 border-teal-500/30",
      stages: [
        {
          num: "الخطوة 1",
          ico: "👨‍👩‍👧‍👦",
          title: "متابعة الأبناء والفصل الدراسي",
          desc: "اربط برمز الفصل لتعرف واجبات ابنك وإعلانات معلمه ونقاط خبرته",
          color: "border-teal-500/35 bg-teal-500/5",
          headBg: "bg-teal-600 text-white",
          tools: [
            { ico: "👨‍👩‍👧‍👦", label: "بوابة متابعة الأبناء", sub: "ملف لكل ابن + خطة منزلية بالـ AI", app: "parentPortalStudio" },
            { ico: "🎒", label: "فصل ابني الدراسي", sub: "استعراض الواجبات والاختبارات بالرمز", app: "classroomsStudio" }
          ]
        },
        {
          num: "الخطوة 2",
          ico: "🗓️",
          title: "تنظيم المذاكرة المنزلية والتسميع",
          desc: "جدول أسبوعي للمنزل، تسميع بالبطاقات الذكية، واختبار قصير قبل الامتحان",
          color: "border-emerald-500/35 bg-emerald-500/5",
          headBg: "bg-emerald-600 text-white",
          tools: [
            { ico: "🗓️", label: "جدول المذاكرة المنزلي", sub: "تنظيم أوقات الدراسة والاستراحة", app: "weeklyPlannerStudio" },
            { ico: "🧠", label: "تسميع البطاقات لابني", sub: "مراجعة الأسئلة والأجوبة معاً", app: "reviewStudio" }
          ]
        },
        {
          num: "الخطوة 3",
          ico: "🧸",
          title: "تأسيس الصغار (1–4) والقصص الناطقة",
          desc: "حروف ناطقة وكراسات خط وعدّ بصري وقصص مصورة مشوقة للأطفال",
          color: "border-pink-500/35 bg-pink-500/5",
          headBg: "bg-pink-600 text-white",
          tools: [
            { ico: "🧸", label: "استوديو التأسيس (1–4)", sub: "حروف ناطقة وتتبع النقاط والعدّ", app: "earlyLearnStudio" },
            { ico: "📚", label: "القصص المصوّرة الناطقة", sub: "قصص تربوية مشوقة بالصوت", app: "storiesStudio" }
          ]
        },
        {
          num: "الخطوة 4",
          ico: "💚",
          title: "الدعم النفسي والتشجيع الأسري",
          desc: "إرشاد تربوي، قارئ ميسّر لصعوبات التعلم، وشهادات تشجيع من الأسرة",
          color: "border-amber-500/35 bg-amber-500/5",
          headBg: "bg-amber-600 text-white",
          tools: [
            { ico: "💚", label: "الدعم النفسي والتعليم الدامج", sub: "إرشاد أسري وقارئ ميسّر", app: "inclusiveStudio" },
            { ico: "🏅", label: "شهادة تشجيع من الأسرة", sub: "اصنع شهادة تقدير لابنك", app: "certStudio" }
          ]
        }
      ],
      chain: ["parentPortalStudio", "classroomsStudio", "weeklyPlannerStudio", "reviewStudio", "earlyLearnStudio", "inclusiveStudio"]
    },
    public: {
      id: "public",
      ico: "🌍",
      short: "الجمهور العام",
      title: "بوابة الجمهور العام والمجتمع المعرفي",
      subtitle: "مسارات مفتوحة للجميع: دورات تدريبية، أدوات الذكاء الاصطناعي، أطلس فلسطين، والبرمجة واللغات",
      gradient: "from-sky-700 via-blue-800 to-indigo-950",
      badgeCls: "bg-sky-500/15 text-sky-700 dark:text-sky-300 border-sky-500/30",
      stages: [
        {
          num: "مسار 1",
          ico: "🏅",
          title: "التطوير المهني والدورات",
          desc: "دورات تدريبية ومكتبة معرفية مفتوحة",
          color: "border-sky-500/35 bg-sky-500/5",
          headBg: "bg-sky-600 text-white",
          tools: [
            { ico: "🌍", label: "بوابة الجمهور العام", sub: "دليل خدمات المجتمع المفتوحة", app: "publicHubStudio" },
            { ico: "🏅", label: "الدورات التدريبية", sub: "برامج الذكاء الاصطناعي والمهارات", app: "coursesSection" }
          ]
        },
        {
          num: "مسار 2",
          ico: "✨",
          title: "أدوات الذكاء الاصطناعي والملفات",
          desc: "صياغة البرومبتات وضغط الصور وتحويل PDF محلياً",
          color: "border-indigo-500/35 bg-indigo-500/5",
          headBg: "bg-indigo-600 text-white",
          tools: [
            { ico: "✨", label: "مولّد البرومبتات الذكية", sub: "أوامر احترافية للذكاء الاصطناعي", app: "generator" },
            { ico: "🗜️", label: "ضغط الصور ودمج PDF", sub: "أداة مجانية تعمل على جهازك", app: "mediaToolsStudio" }
          ]
        },
        {
          num: "مسار 3",
          ico: "🗺️",
          title: "الهوية والثقافة الفلسطينية",
          desc: "أطلس فلسطين الجغرافي والتاريخي والمسابقات الثقافية",
          color: "border-emerald-500/35 bg-emerald-500/5",
          headBg: "bg-emerald-600 text-white",
          tools: [
            { ico: "🗺️", label: "أطلس فلسطين التفاعلي", sub: "خريطة المدن والقرى والتراث", app: "atlasStudio" },
            { ico: "🎙️", label: "المسابقات الثقافية العامة", sub: "بنك ثقافة عامة وإذاعة", app: "radioStudio" }
          ]
        },
        {
          num: "مسار 4",
          ico: "💻",
          title: "مهارات البرمجة واللغات",
          desc: "تعلّم البرمجة والخوارزميات والنطق الصحيح",
          color: "border-purple-500/35 bg-purple-500/5",
          headBg: "bg-purple-600 text-white",
          tools: [
            { ico: "💻", label: "أكاديمية البرمجة", sub: "محرر كود وتحديات منطقية", app: "codingLabStudio" },
            { ico: "🗣️", label: "معمل اللغات والنطق", sub: "تدريب صوتي عربي وإنجليزي", app: "langLabStudio" }
          ]
        }
      ],
      chain: ["publicHubStudio", "coursesSection", "generator", "atlasStudio", "codingLabStudio", "mediaToolsStudio"]
    },
    all: {
      id: "all",
      ico: "🌟",
      short: "الكل",
      title: "المنظومة الشاملة (اختر بوابتك لترتيب خطواتك وأدواتك)",
      subtitle: "اضغط على «👨‍🏫 المعلم» أو «👨‍🎓 الطالب» أو «👨‍👩‍👧‍👦 ولي الأمر» أعلاه لترتيب الموقع والأدوات حسب احتياجاتك خطوة بخطوة",
      gradient: "from-brand-600 via-indigo-600 to-sky-600",
      badgeCls: "bg-brand-500/15 text-brand-700 dark:text-sky-300 border-brand-500/30",
      stages: [
        {
          num: "بوابة 1",
          ico: "👨‍🏫",
          title: "مسار المعلم (4 مراحل)",
          desc: "التحضير والكاميرا ← الشرح ← الاختبارات ← التقارير",
          color: "border-indigo-500/35 bg-indigo-500/5",
          headBg: "bg-indigo-600 text-white",
          tools: [
            { ico: "🧳", label: "حقيبة الحصة الجاهزة", sub: "تحضير شامل + كاميرا وملفات", app: "lessonKitStudio" },
            { ico: "📝", label: "أوراق العمل والاختبارات", sub: "توليد وتصدير PDF ورابط", app: "worksheetStudio" },
            { ico: "🖍️", label: "السبورة والعروض", sub: "شرح تفاعلي وشرائح حية", app: "whiteboardStudio" }
          ]
        },
        {
          num: "بوابة 2",
          ico: "👨‍🎓",
          title: "مسار الطالب (4 خطوات)",
          desc: "افهم الدرس ← لخّص وثبّت ← اختبر نفسك ← نظّم وقتك",
          color: "border-emerald-500/35 bg-emerald-500/5",
          headBg: "bg-emerald-600 text-white",
          tools: [
            { ico: "🏫", label: "المراحل والدروس", sub: "فيديوهات وملخصات الصفوف", app: "learnSection" },
            { ico: "🤖", label: "المعلم الخصوصي الذكي", sub: "شرح وخرائط وبطاقات", app: "tutorStudio" },
            { ico: "🧠", label: "المراجعة الذكية", sub: "تكرار متباعد لحفظ الدروس", app: "reviewStudio" }
          ]
        },
        {
          num: "بوابة 3",
          ico: "👨‍👩‍👧‍👦",
          title: "مسار ولي الأمر والأسرة",
          desc: "متابعة الأبناء بالرمز + خطة منزلية + شهادة تشجيع",
          color: "border-teal-500/35 bg-teal-500/5",
          headBg: "bg-teal-600 text-white",
          tools: [
            { ico: "👨‍👩‍👧‍👦", label: "بوابة متابعة الأبناء", sub: "متابعة شاملة وخطة منزلية", app: "parentPortalStudio" },
            { ico: "🎒", label: "الفصول الافتراضية", sub: "واجبات وإعلانات الفصل", app: "classroomsStudio" },
            { ico: "🧸", label: "تأسيس الصغار (1–4)", sub: "حروف ناطقة وعدّ بصري", app: "earlyLearnStudio" }
          ]
        },
        {
          num: "بوابة 4",
          ico: "⚡",
          title: "الربط الشامل والجمهور العام",
          desc: "غرفة العمليات الموحّدة + مصادر الكاميرا + المجتمع",
          color: "border-amber-500/35 bg-amber-500/5",
          headBg: "bg-amber-600 text-white",
          tools: [
            { ico: "⚡", label: "غرفة العمليات الموحّدة", sub: "انقل درسك بين كل الأدوات", app: "unifiedWorkflowStudio" },
            { ico: "📷", label: "مصادري (كاميرا وPDF)", sub: "ارفع كتابك أو صوّر صفحاته", app: "sourcesStudio" },
            { ico: "🌍", label: "بوابة الجمهور العام", sub: "دورات وأطلس فلسطين وبرمجة", app: "publicHubStudio" }
          ]
        }
      ],
      chain: ["unifiedWorkflowStudio", "sourcesStudio", "lessonKitStudio", "worksheetStudio", "tutorStudio", "reviewStudio", "parentPortalStudio"]
    }
  };

  // ==================== 3. جسر التكامل الذكي بين الأدوات (EduBridge) ====================
  function getBridgeCtx() {
    try { return JSON.parse(localStorage.getItem(BRIDGE_KEY) || "{}"); } catch (e) { return {}; }
  }
  function setBridgeCtx(data) {
    try {
      var cur = getBridgeCtx();
      var next = Object.assign({}, cur, data, { ts: Date.now() });
      localStorage.setItem(BRIDGE_KEY, JSON.stringify(next));
      return next;
    } catch (e) { return data || {}; }
  }

  function loadSharedFeed() {
    try {
      var arr = JSON.parse(localStorage.getItem(FEED_KEY) || "null");
      if (Array.isArray(arr) && arr.length) return arr;
    } catch (e) {}
    return [
      { id: "f1", fromRole: "teacher", targetRole: "student", title: "مهمة الأسبوع: مراجعة درس الكسور العشرية وحل الاختبار القصير", subject: "الرياضيات", grade: "الصف الرابع", app: "reviewStudio", doneByStudent: false, seenByParent: true, time: "اليوم" },
      { id: "f2", fromRole: "student", targetRole: "parent", title: "أتممت جلسة المراجعة الذكية وحصلت على +25 نقطة خبرة XP", subject: "العلوم والحياة", grade: "الصف السابع", app: "parentPortalStudio", doneByStudent: true, seenByParent: false, time: "منذ ساعة" },
      { id: "f3", fromRole: "parent", targetRole: "teacher", title: "تمت متابعة خطة المذاكرة المنزلية وتوقيع بطاقة المتابعة الأسبوعية", subject: "اللغة العربية", grade: "الصف السادس", app: "parentsStudio", doneByStudent: true, seenByParent: true, time: "اليوم" }
    ];
  }
  function saveSharedFeed(list) {
    try { localStorage.setItem(FEED_KEY, JSON.stringify((list || []).slice(0, 20))); } catch (e) {}
  }
  function addSharedFeedItem(item) {
    var list = loadSharedFeed();
    list.unshift(Object.assign({
      id: "f" + Date.now().toString(36),
      fromRole: "teacher",
      targetRole: "student",
      title: "نشاط تعليمي جديد",
      subject: "",
      grade: "",
      app: "learnSection",
      doneByStudent: false,
      seenByParent: false,
      time: "الآن"
    }, item || {}));
    saveSharedFeed(list);
    return list;
  }

  function sendToQuestionBank(questions, meta) {
    meta = meta || {};
    try {
      var BK = "edu_qbank_v1";
      var bank = JSON.parse(localStorage.getItem(BK) || "[]"); if (!Array.isArray(bank)) bank = [];
      var seen = {};
      bank.forEach(function (x) { if (x && x.q) seen[x.q] = 1; });
      var added = 0;
      (questions || []).forEach(function (q) {
        if (!q || !q.q) return;
        var opts = q.options || q.o || [];
        if (q.t === "tf") opts = ["صح", "خطأ"];
        if (!Array.isArray(opts) || opts.length < 2) {
          if (q.answer) opts = [String(q.answer), "خيار آخر 1", "خيار آخر 2", "خيار آخر 3"];
          else return;
        }
        var ans = typeof q.answer === "number" ? q.answer : (q.answer === true ? 0 : (q.answer === false ? 1 : 0));
        if (seen[q.q]) return;
        seen[q.q] = 1;
        bank.push({
          id: "q" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
          q: String(q.q).slice(0, 400),
          o: opts.slice(0, 5).map(function (t) { return String(t).slice(0, 200); }),
          a: (ans >= 0 && ans < opts.length) ? ans : 0,
          e: String(q.explain || q.e || "").slice(0, 300),
          s: meta.subject || meta.title || "",
          g: meta.grade || "",
          d: Date.now()
        });
        added++;
      });
      localStorage.setItem(BK, JSON.stringify(bank));
      toast(added ? "🏦 أُضيف " + added + " سؤال إلى «بنك الأسئلة التفاعلي» بنجاح ✓" : "هذه الأسئلة موجودة مسبقاً في بنك الأسئلة", added ? "success" : "info");
      return added;
    } catch (e) {
      toast("تعذر الإضافة لبنك الأسئلة", "warning");
      return 0;
    }
  }

  function sendToSmartReview(deckName, pairs) {
    if (!window.EduReview || !window.EduReview.addCards) {
      toast("وحدة المراجعة الذكية قيد التحميل…", "warning");
      return 0;
    }
    var clean = (pairs || []).map(function (p) {
      if (!p) return null;
      if (p.q && p.a) return { q: String(p.q), a: String(p.a) };
      if (p.front && p.back) return { q: String(p.front), a: String(p.back) };
      if (p.q && Array.isArray(p.options)) {
        var idx = typeof p.answer === "number" ? p.answer : 0;
        return { q: String(p.q), a: String(p.options[idx] || p.options[0] || "") };
      }
      if (p.t === "tf" && p.q) return { q: String(p.q), a: p.answer ? "صح" : "خطأ" };
      if (p.q && p.answer !== undefined) return { q: String(p.q), a: String(p.answer) };
      return null;
    }).filter(Boolean);

    if (!clean.length) {
      toast("لا توجد بطاقات صالحة للإرسال إلى المراجعة الذكية", "warning");
      return 0;
    }
    var n = window.EduReview.addCards(deckName || "مراجعة عامة", clean);
    toast(n ? "🧠 أُضيفت " + n + " بطاقة إلى «المراجعة الذكية» في مجموعة «" + (deckName || "مراجعة عامة") + "» ✓" : "جميع هذه البطاقات مضافة مسبقاً في المراجعة الذكية", n ? "success" : "info");
    try { window.EduReview.render(); } catch (e) {}
    return n;
  }

  function sendToWeeklyPlanner(taskText, cellSlot, cellValue) {
    try {
      var KEY = "edu_weekly_planner_v76";
      var st = JSON.parse(localStorage.getItem(KEY) || "null") || { title: "خطتي الأسبوعية الذكية", owner: "", mode: "teacher", cells: {}, tasks: [] };
      st.cells = st.cells || {};
      st.tasks = Array.isArray(st.tasks) ? st.tasks : [];
      if (taskText) {
        var exists = st.tasks.some(function (t) { return t.text === taskText; });
        if (!exists) st.tasks.unshift({ id: "t" + Date.now(), text: taskText, done: false });
      }
      if (cellSlot && cellValue) {
        st.cells[cellSlot] = cellValue;
      } else if (cellValue) {
        var placed = false;
        for (var d = 0; d < 5 && !placed; d++) {
          for (var s = 0; s < 6 && !placed; s++) {
            var k = d + "_" + s;
            if (!st.cells[k]) { st.cells[k] = cellValue; placed = true; }
          }
        }
      }
      localStorage.setItem(KEY, JSON.stringify(st));
      if (window.EduWeeklyPlanner && window.EduWeeklyPlanner.render) window.EduWeeklyPlanner.render();
      toast("🗓️ أُضيفت المهمة والحصة إلى «المخطط الأسبوعي الذكي» ✓", "success");
      return true;
    } catch (e) {
      return false;
    }
  }

  function openToolWithContext(targetAppId, ctx) {
    ctx = Object.assign({}, getBridgeCtx(), ctx || {});
    setBridgeCtx(ctx);
    var topic = ctx.topic || ctx.title || "";
    var grade = ctx.grade || "";
    var subject = ctx.subject || "";
    var notes = ctx.notes || ctx.text || "";

    function fillSelect(selEl, val) {
      if (!selEl || !val) return;
      var normV = String(val).replace(/^الصف\s+/, "").trim();
      for (var i = 0; i < selEl.options.length; i++) {
        var opt = selEl.options[i];
        var t = (opt.value || opt.text || "").trim();
        if (t === val || t.indexOf(normV) !== -1 || normV.indexOf(t.replace(/^الصف\s+/, "")) !== -1) {
          selEl.value = opt.value || opt.text;
          selEl.dispatchEvent(new Event("change", { bubbles: true }));
          selEl.dispatchEvent(new Event("input", { bubbles: true }));
          break;
        }
      }
    }
    function setVal(id, v) {
      var el = $(id);
      if (el && v) {
        el.value = v;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      }
    }

    if (window.EduLauncher && window.EduLauncher.jump) {
      window.EduLauncher.jump(targetAppId, true);
    }

    setTimeout(function () {
      if (targetAppId === "lessonKitStudio") {
        setVal("lkTitle", topic);
        fillSelect($("lkGrade"), grade);
        fillSelect($("lkSubject"), subject);
        if (notes) setVal("lkNotes", notes);
      } else if (targetAppId === "worksheetStudio") {
        setVal("wsTopic", notes ? (topic + "\n\n" + notes).slice(0, 5800) : topic);
        fillSelect($("wsGrade"), grade);
        setVal("wsSubject", subject);
        if (ctx.kind === "exam") setVal("wsKind", "exam");
      } else if (targetAppId === "slidesStudio") {
        setVal("slTopic", notes ? (topic + "\n\n" + notes).slice(0, 5800) : topic);
        fillSelect($("slGrade"), grade);
        setVal("slSubject", subject);
      } else if (targetAppId === "lessonPlanStudio") {
        setVal("lpTopic", notes ? (topic + "\n\n" + notes).slice(0, 5800) : topic);
        fillSelect($("lpGrade"), grade);
        setVal("lpSubject", subject);
      } else if (targetAppId === "gamesStudio") {
        setVal("gmTopic", topic);
        fillSelect($("gmGrade"), grade);
        setVal("gmSubject", subject);
      } else if (targetAppId === "tutorStudio") {
        if (window.EduTutor && window.EduTutor.open) {
          window.EduTutor.open({ topic: notes ? (topic + "\n\n" + notes).slice(0, 4800) : topic, grade: grade, subject: subject, mode: ctx.mode || "chat" });
        } else {
          setVal("tuTopic", topic);
          fillSelect($("tuGrade"), grade);
          setVal("tuSubject", subject);
        }
      } else if (targetAppId === "reviewStudio") {
        var addBtn = document.querySelector('#reviewStudio [data-rv="add"]');
        if (addBtn) addBtn.click();
        setTimeout(function () {
          setVal("rvDeck", (subject ? subject + " — " : "") + (topic || "درس"));
          setVal("rvAiText", notes ? (topic + "\n" + notes) : topic);
        }, 80);
      } else if (targetAppId === "weeklyPlannerStudio") {
        sendToWeeklyPlanner("متابعة درس: " + (topic || "حصة دراسية") + (subject ? " (" + subject + ")" : ""), "", (subject ? subject + ": " : "") + (topic || "درس جديد"));
      } else if (targetAppId === "parentsStudio") {
        if (window.EduParents && window.EduParents.openWithStudent) {
          window.EduParents.openWithStudent({ grade: grade, subject: subject, summary: "متابعة درس: " + topic });
        }
      }
      if (topic) toast("🔗 تم نقل بيانات «" + topic.slice(0, 35) + "» إلى الأداة بنجاح ✓", "success");
    }, 180);
  }

  function lessonKitToWorksheet(meta, kit) {
    if (!kit) return;
    openToolWithContext("worksheetStudio", {
      title: meta.title,
      topic: meta.title,
      grade: meta.grade,
      subject: meta.subject,
      notes: (kit.worksheet || []).join("\n")
    });
  }

  function lessonKitToGame(meta, kit) {
    if (!kit || !window.EduGames || !window.EduGames.fromWorksheet) {
      openToolWithContext("gamesStudio", { title: meta && meta.title, grade: meta && meta.grade, subject: meta && meta.subject });
      return;
    }
    var fakeWs = {
      title: (meta && meta.title) || "مسابقة الدرس",
      grade: (meta && meta.grade) || "",
      subject: (meta && meta.subject) || "",
      sets: {
        A: (kit.quiz || []).map(function (q) { return { t: "mcq", q: q.q, options: q.options, answer: q.answer }; })
          .concat((kit.keyTerms || []).map(function (t) { return { t: "short", q: t.q, answer: t.a }; }))
      }
    };
    if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("gamesStudio", true);
    setTimeout(function () { window.EduGames.fromWorksheet(fakeWs); }, 180);
  }

  // ==================== 4. غرفة العمليات التعليمية الموحّدة (#unifiedWorkflowStudio) ====================
  var WFState = {
    topic: "الكسور العشرية وتمثيلها",
    grade: "الصف الرابع",
    subject: "الرياضيات",
    notes: "الكسر العشري هو كل كسر مقامه 10 أو 100 أو 1000 ويكتب باستعمال الفاصلة العشرية مثل 0.5 و 0.25.",
    activeRoleFilter: "all"
  };

  function ensureUnifiedWorkflowSection() {
    var ex = $("unifiedWorkflowStudio");
    if (ex) return ex;
    var anchor = $("parentPortalStudio") || $("lessonKitStudio") || $("reviewStudio") || $("weeklyPlannerStudio") || $("learnSection");
    if (!anchor || !anchor.parentNode) return null;
    var sec = document.createElement("section");
    sec.id = "unifiedWorkflowStudio";
    sec.className = "py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20";
    anchor.parentNode.insertBefore(sec, anchor);
    return sec;
  }

  function renderUnifiedWorkflow() {
    var sec = ensureUnifiedWorkflowSection();
    if (!sec) return;
    var ctx = getBridgeCtx();
    if (ctx.topic && !WFState.userEdited) {
      WFState.topic = ctx.topic;
      if (ctx.grade) WFState.grade = ctx.grade;
      if (ctx.subject) WFState.subject = ctx.subject;
    }
    var feed = loadSharedFeed();
    var inpCls = "w-full text-xs font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 text-slate-800 dark:text-slate-100";

    var roleLaunchMatrix = [
      {
        role: "teacher",
        ico: "👨‍🏫",
        title: "أدوات المعلم المرتبة لهذا الدرس",
        color: "border-indigo-500/30 bg-indigo-500/5",
        actions: [
          { ico: "🧳", label: "1. حقيبة الحصة الكاملة", app: "lessonKitStudio" },
          { ico: "📘", label: "2. خطة تحضير وزارية", app: "lessonPlanStudio" },
          { ico: "🎞", label: "3. عرض تقديمي تفاعلي", app: "slidesStudio" },
          { ico: "🖍️", label: "4. شرح على السبورة الذكية", app: "whiteboardStudio" },
          { ico: "📝", label: "5. ورقة عمل واختبار", app: "worksheetStudio" },
          { ico: "🎮", label: "6. مسابقة صفية حية", app: "gamesStudio" }
        ]
      },
      {
        role: "student",
        ico: "👨‍🎓",
        title: "أدوات الطالب المرتبة لهذا الدرس",
        color: "border-emerald-500/30 bg-emerald-500/5",
        actions: [
          { ico: "🤖", label: "1. اشرح لي بالمعلم الذكي", app: "tutorStudio", mode: "chat" },
          { ico: "🧠", label: "2. ارسم خريطة ذهنية", app: "tutorStudio", mode: "mindmap" },
          { ico: "🗂", label: "3. ولّد بطاقات قلّابة", app: "tutorStudio", mode: "cards" },
          { ico: "🔁", label: "4. جدولة بالمراجعة المتباعدة", app: "reviewStudio" },
          { ico: "🎯", label: "5. اختبر نفسك الآن", app: "selfQuiz" },
          { ico: "📥", label: "6. حقيبة مذاكرة بلا إنترنت", app: "offPackStudio" }
        ]
      },
      {
        role: "parent",
        ico: "👨‍👩‍👧‍👦",
        title: "أدوات ولي الأمر المرتبة لهذا الدرس",
        color: "border-teal-500/30 bg-teal-500/5",
        actions: [
          { ico: "👨‍👩‍👧‍👦", label: "1. بوابة متابعة الأبناء", app: "parentPortalStudio" },
          { ico: "📋", label: "2. بطاقة متابعة واتساب", app: "parentsStudio" },
          { ico: "🗓️", label: "3. جدولة في خطة المنزل", app: "weeklyPlannerStudio" },
          { ico: "🏅", label: "4. إصدار شهادة تشجيع", app: "certStudio" }
        ]
      },
      {
        role: "public",
        ico: "🌍",
        title: "أدوات المجتمع والثقافة",
        color: "border-sky-500/30 bg-sky-500/5",
        actions: [
          { ico: "✨", label: "1. برومبتات هرم بلوم", app: "generator" },
          { ico: "🎨", label: "2. إنفوغرافيك وبوستر", app: "designStudio" },
          { ico: "🎙️", label: "3. برنامج إذاعة مدرسية", app: "radioStudio" },
          { ico: "📚", label: "4. تحويل لقصة مصورة ناطقة", app: "storiesStudio" }
        ]
      }
    ];

    sec.innerHTML =
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden text-right">' +
        '<div class="p-5 sm:p-7 bg-gradient-to-l from-indigo-900 via-brand-800 to-slate-900 text-white">' +
          '<div class="flex flex-wrap items-center justify-between gap-3">' +
            '<div>' +
              '<div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-black mb-1.5">' +
                '<span>⚡ غرفة العمليات التعليمية الموحّدة + استيراد المصادر بالكاميرا والجهاز</span>' +
              '</div>' +
              '<h2 class="text-xl sm:text-2xl font-black">صوّر صفحة الدرس أو اكتب عنوانه مرة واحدة — وانتقل به بين جميع أدوات المعلم والطالب</h2>' +
              '<p class="text-xs text-slate-200 mt-1">يمكنك تصوير صفحة من الكتاب بالكاميرا أو رفع ملف PDF/صورة أو اختيار درس من المنهاج، ثم فتح أي أداة لتجد الدرس جاهزاً بداخلها.</p>' +
            '</div>' +
          '</div>' +
        '</div>' +

        '<div class="p-5 sm:p-7 space-y-5">' +
          // شريط الكاميرا والمصادر الموحّد
          renderSourceBarHtml("uf") +

          // حقول سياق الدرس الموحّد
          '<div class="rounded-2xl border-2 border-brand-500/30 bg-slate-50/80 dark:bg-slate-900/60 p-4 space-y-3">' +
            '<div class="flex flex-wrap items-center justify-between gap-2">' +
              '<div class="text-xs sm:text-sm font-black text-brand-700 dark:text-sky-300">🎯 سياق الدرس الموحّد النشط (ينتقل معك تلقائياً لكل أداة):</div>' +
              '<button type="button" id="ufSaveCtxBtn" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-black shadow">💾 تثبيت الدرس وتعميمه في حلقة المتابعة</button>' +
            '</div>' +
            '<div class="grid grid-cols-1 sm:grid-cols-4 gap-3">' +
              '<div class="sm:col-span-2"><label class="block text-[11px] font-bold mb-1">عنوان الدرس أو الموضوع الموحّد</label><input id="ufTopic" value="' + esc(WFState.topic) + '" placeholder="مثال: الكسور العشرية / الخلية النباتية" class="' + inpCls + '"></div>' +
              '<div><label class="block text-[11px] font-bold mb-1">الصف / المرحلة</label><select id="ufGrade" class="' + inpCls + '">' +
                ["الصف الأول", "الصف الثاني", "الصف الثالث", "الصف الرابع", "الصف الخامس", "الصف السادس", "الصف السابع", "الصف الثامن", "الصف التاسع", "الصف العاشر", "الصف الحادي عشر", "الصف الثاني عشر (التوجيهي)"].map(function (g) {
                  return '<option' + (g === WFState.grade ? " selected" : "") + '>' + g + '</option>';
                }).join("") +
              '</select></div>' +
              '<div><label class="block text-[11px] font-bold mb-1">المادة الدراسية</label><input id="ufSubject" value="' + esc(WFState.subject) + '" placeholder="العلوم، الرياضيات، العربية…" class="' + inpCls + '"></div>' +
            '</div>' +
            '<div><label class="block text-[11px] font-bold mb-1">نص من الكتاب أو المستخرج بالكاميرا (يُمرَّر تلقائياً لجميع أدوات التوليد)</label><textarea id="ufNotes" rows="2" class="' + inpCls + '" placeholder="الصق فقرة من الكتاب أو اضغط «تصوير صفحة بالكاميرا» بالأعلى…">' + esc(WFState.notes) + '</textarea></div>' +
          '</div>' +

          // مصفوفة الإطلاق الفوري للأدوار الأربعة
          '<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">' +
            roleLaunchMatrix.map(function (rm) {
              return '<div class="rounded-2xl border ' + rm.color + ' p-4 flex flex-col justify-between space-y-3">' +
                '<div>' +
                  '<div class="flex items-center gap-2 text-xs sm:text-sm font-black text-slate-900 dark:text-white mb-2.5">' +
                    '<span class="text-xl">' + rm.ico + '</span><span>' + esc(rm.title) + '</span>' +
                  '</div>' +
                  '<div class="grid grid-cols-1 gap-1.5">' +
                    rm.actions.map(function (ac) {
                      return '<button type="button" data-uf-launch="' + ac.app + '" data-uf-mode="' + (ac.mode || "") + '" class="w-full text-right px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-brand-500 text-xs font-extrabold flex items-center justify-between gap-2 transition group">' +
                        '<span class="truncate">' + ac.ico + ' ' + esc(ac.label) + '</span>' +
                        '<i class="fa-solid fa-arrow-left text-[10px] text-slate-400 group-hover:text-brand-500"></i>' +
                      '</button>';
                    }).join("") +
                  '</div>' +
                '</div>' +
              '</div>';
            }).join("") +
          '</div>' +

          // سجل المتابعة المشترك بين المعلم والطالب وولي الأمر
          '<div class="rounded-2xl border border-slate-200 dark:border-slate-700 p-4 sm:p-5 bg-white dark:bg-slate-800/70 space-y-3">' +
            '<div class="flex flex-wrap items-center justify-between gap-2">' +
              '<div>' +
                '<h3 class="text-sm font-black text-slate-900 dark:text-white">🔔 حلقة الوصل التفاعلية (سجل المهام والمتابعة المشترك بين المعلم والطالب وولي الأمر)</h3>' +
                '<p class="text-[11px] text-slate-500">أي تكليف يضيفه المعلم يظهر للطالب لإنجازه، ويظهر لولي الأمر لاعتماد متابعته المنزلية</p>' +
              '</div>' +
              '<button type="button" id="ufAddFeedTask" class="px-3.5 py-1.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-black">➕ إضافة تكليف للحلقة المشتركة</button>' +
            '</div>' +
            '<div class="space-y-2">' +
              feed.map(function (f, idx) {
                var roleTag = f.fromRole === "teacher" ? "👨‍🏫 من المعلم" : f.fromRole === "student" ? "👨‍🎓 من الطالب" : "👨‍👩‍👧‍👦 من ولي الأمر";
                return '<div class="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-900/50 flex flex-wrap items-center justify-between gap-2 text-xs">' +
                  '<div class="flex items-start gap-2.5 min-w-0 flex-1">' +
                    '<span class="px-2.5 py-1 rounded-lg bg-brand-500/15 text-brand-700 dark:text-sky-300 font-black text-[10px] shrink-0">' + roleTag + '</span>' +
                    '<div class="min-w-0 flex-1">' +
                      '<div class="font-extrabold text-slate-900 dark:text-white">' + esc(f.title) + '</div>' +
                      '<div class="text-[10px] text-slate-500 mt-0.5">' + esc([f.grade, f.subject, f.time].filter(Boolean).join(" • ")) + '</div>' +
                    '</div>' +
                  '</div>' +
                  '<div class="flex flex-wrap items-center gap-1.5 shrink-0">' +
                    '<button type="button" data-feed-done="' + idx + '" class="px-2.5 py-1 rounded-lg text-[10px] font-extrabold ' + (f.doneByStudent ? "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300" : "bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300") + '">' + (f.doneByStudent ? "✅ أنجزه الطالب" : "⬜ بانتظار إنجاز الطالب") + '</button>' +
                    '<button type="button" data-feed-parent="' + idx + '" class="px-2.5 py-1 rounded-lg text-[10px] font-extrabold ' + (f.seenByParent ? "bg-teal-500/20 text-teal-700 dark:text-teal-300" : "bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300") + '">' + (f.seenByParent ? "👨‍👩‍👧‍👦 اعتمد ولي الأمر" : "👀 اعتماد ولي الأمر") + '</button>' +
                    '<button type="button" data-feed-open="' + f.app + '" class="px-2.5 py-1 rounded-lg bg-brand-600 text-white text-[10px] font-bold">فتح الأداة</button>' +
                    '<button type="button" data-feed-del="' + idx + '" class="px-2 py-1 rounded-lg text-rose-500 hover:bg-rose-500/10 text-[10px] font-bold">✕</button>' +
                  '</div>' +
                '</div>';
              }).join("") +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';

    function syncWfInputs() {
      WFState.userEdited = true;
      if ($("ufTopic")) WFState.topic = $("ufTopic").value.trim();
      if ($("ufGrade")) WFState.grade = $("ufGrade").value;
      if ($("ufSubject")) WFState.subject = $("ufSubject").value.trim();
      if ($("ufNotes")) WFState.notes = $("ufNotes").value.trim();
      setBridgeCtx({ topic: WFState.topic, title: WFState.topic, grade: WFState.grade, subject: WFState.subject, notes: WFState.notes });
    }
    ["ufTopic", "ufGrade", "ufSubject", "ufNotes"].forEach(function (id) {
      var el = $(id);
      if (el) { el.oninput = syncWfInputs; el.onchange = syncWfInputs; }
    });

    bindSourceBar(sec, {
      titleId: "ufTopic",
      gradeId: "ufGrade",
      subjId: "ufSubject",
      notesId: "ufNotes",
      onPickPreset: function () { syncWfInputs(); },
      onRefresh: function () { syncWfInputs(); renderUnifiedWorkflow(); }
    });

    if ($("ufSaveCtxBtn")) $("ufSaveCtxBtn").onclick = function () {
      syncWfInputs();
      addSharedFeedItem({
        fromRole: "teacher",
        targetRole: "student",
        title: "درس وتكليف متكامل: «" + (WFState.topic || "درس جديد") + "» — راجع البطاقات وحل الاختبار القصير",
        subject: WFState.subject,
        grade: WFState.grade,
        app: "lessonKitStudio"
      });
      renderUnifiedWorkflow();
      toast("✓ تم حفظ سياق الدرس وإضافته إلى حلقة المتابعة المشتركة", "success");
    };

    if ($("ufAddFeedTask")) $("ufAddFeedTask").onclick = function () {
      syncWfInputs();
      var curRole = (window.EduLauncher && window.EduLauncher.getRole) ? window.EduLauncher.getRole() : "teacher";
      var sender = (curRole === "student" || curRole === "parent") ? curRole : "teacher";
      addSharedFeedItem({
        fromRole: sender,
        targetRole: sender === "teacher" ? "student" : "parent",
        title: (sender === "teacher" ? "تكليف جديد: " : sender === "student" ? "إنجاز طالب: " : "متابعة ولي أمر: ") + (WFState.topic || "مراجعة الدرس"),
        subject: WFState.subject,
        grade: WFState.grade,
        app: sender === "teacher" ? "worksheetStudio" : sender === "student" ? "reviewStudio" : "parentPortalStudio"
      });
      renderUnifiedWorkflow();
      toast("تمت إضافة البطاقة إلى سجل المتابعة المشترك ✓", "success");
    };

    sec.querySelectorAll("[data-uf-launch]").forEach(function (b) {
      b.onclick = function () {
        syncWfInputs();
        var app = b.getAttribute("data-uf-launch");
        var mode = b.getAttribute("data-uf-mode") || "";
        if (app === "selfQuiz" && window.EduStudy && window.EduStudy.quiz) {
          window.EduStudy.quiz();
          setTimeout(function () {
            if ($("qzT")) $("qzT").value = WFState.topic;
            if ($("qzX")) $("qzX").value = WFState.notes;
            if ($("qzS")) $("qzS").value = WFState.subject + " - " + WFState.grade;
          }, 120);
        } else {
          openToolWithContext(app, { topic: WFState.topic, title: WFState.topic, grade: WFState.grade, subject: WFState.subject, notes: WFState.notes, mode: mode });
        }
      };
    });

    sec.querySelectorAll("[data-feed-done]").forEach(function (b) {
      b.onclick = function () {
        var i = +b.getAttribute("data-feed-done");
        var list = loadSharedFeed();
        if (list[i]) {
          list[i].doneByStudent = !list[i].doneByStudent;
          saveSharedFeed(list);
          if (list[i].doneByStudent && window.EduBadges && window.EduBadges.award) window.EduBadges.award("first_step", 15, false);
          renderUnifiedWorkflow();
        }
      };
    });
    sec.querySelectorAll("[data-feed-parent]").forEach(function (b) {
      b.onclick = function () {
        var i = +b.getAttribute("data-feed-parent");
        var list = loadSharedFeed();
        if (list[i]) {
          list[i].seenByParent = !list[i].seenByParent;
          saveSharedFeed(list);
          renderUnifiedWorkflow();
          toast(list[i].seenByParent ? "👨‍👩‍👧‍👦 تم تسجيل اعتماد ولي الأمر للمهمة ✓" : "تم إلغاء الاعتماد", "info");
        }
      };
    });
    sec.querySelectorAll("[data-feed-open]").forEach(function (b) {
      b.onclick = function () {
        syncWfInputs();
        openToolWithContext(b.getAttribute("data-feed-open"), { topic: WFState.topic, grade: WFState.grade, subject: WFState.subject, notes: WFState.notes });
      };
    });
    sec.querySelectorAll("[data-feed-del]").forEach(function (b) {
      b.onclick = function () {
        var i = +b.getAttribute("data-feed-del");
        var list = loadSharedFeed();
        list.splice(i, 1);
        saveSharedFeed(list);
        renderUnifiedWorkflow();
      };
    });
  }

  // ==================== 5. بوابة ولي الأمر والأسرة التفاعلية (#parentPortalStudio) ====================
  function loadParentState() {
    try {
      var d = JSON.parse(localStorage.getItem(PARENT_KEY) || "null");
      if (d && typeof d === "object") {
        d.children = Array.isArray(d.children) ? d.children : [];
        return d;
      }
    } catch (e) {}
    return {
      parentName: "",
      children: [
        { id: "ch1", name: localStorage.getItem("edu_student_name") || "ابني / ابنتي", grade: "الصف السابع", code: localStorage.getItem("edu_student_code") || "", weakSubj: "الرياضيات والعلوم", goal: "رفع المعدل والالتزام بالواجبات اليومية" }
      ],
      activeIdx: 0,
      aiPlan: "",
      aiBusy: false
    };
  }
  var PState = loadParentState();
  function saveParentState() {
    try {
      localStorage.setItem(PARENT_KEY, JSON.stringify({
        parentName: PState.parentName,
        children: PState.children,
        activeIdx: PState.activeIdx,
        aiPlan: PState.aiPlan
      }));
    } catch (e) {}
  }

  function collectChildProgress(child, cb) {
    var localStats = {
      xp: (window.EduBadges && window.EduBadges.summary) ? window.EduBadges.summary() : { xp: 0, level: 1, count: 0 },
      review: (window.EduReview && window.EduReview.stats) ? window.EduReview.stats() : { total: 0, due: 0, streak: 0, today: 0 },
      dailyStreak: (window.EduStudy && window.EduStudy.streak) ? window.EduStudy.streak() : 0,
      lastLesson: null,
      classInfo: null
    };
    try { localStats.lastLesson = JSON.parse(localStorage.getItem("edu_last") || "null"); } catch (e) {}

    var code = String((child && child.code) || "").trim().toUpperCase();
    if (!code || !cloud()) {
      try {
        var cached = JSON.parse(localStorage.getItem("edu_class_cache_" + code) || "null");
        if (cached) localStats.classInfo = cached;
      } catch (e) {}
      cb(localStats);
      return;
    }

    window.Cloud.col("classrooms").doc(code).get().then(function (doc) {
      if (doc.exists) {
        localStats.classInfo = Object.assign({ id: doc.id }, doc.data());
        try { localStorage.setItem("edu_class_cache_" + code, JSON.stringify(localStats.classInfo)); } catch (x) {}
      }
      cb(localStats);
    }).catch(function () { cb(localStats); });
  }

  function generateParentAiPlan() {
    var ch = PState.children[PState.activeIdx] || PState.children[0];
    if (!ch) return;
    if (!window.AI || !window.AI.ask) {
      PState.aiPlan = "📋 خطة المتابعة المنزلية الأسبوعية المقترحة للطالب «" + ch.name + "» (" + ch.grade + "):\n" +
        "1. ⏱️ جلسة تركيز يومية (25 دقيقة بومودورو) بعد العصر لمراجعة دروس اليوم في (" + (ch.weakSubj || "المواد الأساسية") + ").\n" +
        "2. 🧠 تخصيص 10 دقائق مساءً في أداة «المراجعة الذكية بالتكرار المتباعد» لتثبيت المفردات والقوانين.\n" +
        "3. 🎯 حل اختبار قصير كل يوم خميس عبر أداة «اختبر نفسك» لقياس الفهم قبل نهاية الأسبوع.\n" +
        "4. 💬 تشجيع إيجابي: ربط إنجاز المهام الأسبوعية بشهادة تقدير أسرية من المنصة.";
      saveParentState();
      renderParentPortal();
      return;
    }
    PState.aiBusy = true;
    renderParentPortal();
    var prompt = "أنت مستشار تربوي وأسري خبير في المنهاج الفلسطيني. اكتب خطة متابعة منزلية أسبوعية عملية ومختصرة لولي الأمر لمتابعة ابنه/ابنته:\n" +
      "- اسم الطالب: " + ch.name + "\n- الصف: " + ch.grade + "\n- المواد التي تحتاج تركيزاً: " + (ch.weakSubj || "عام") + "\n- هدف الأسرة: " + (ch.goal || "رفع التحصيل الدراسي") + "\n" +
      "اجعل الخطة في 4 نقاط عملية واضحة (توزيع الوقت اليومي، طريقة التشجيع، كيف يستخدم أدوات منصة EduTech Mindset مثل المعلم الذكي والمراجعة المتباعدة واختبر نفسك، ونصيحة نفسية تربوية للوالدين).";
    window.AI.ask(prompt, null, "studio").then(function (res) {
      PState.aiPlan = String(res || "").trim();
      saveParentState();
    }).catch(function () {
      toast("تعذر الاتصال بالمساعد الذكي — تم تجهيز خطة إرشادية قياسية", "info");
    }).then(function () {
      PState.aiBusy = false;
      renderParentPortal();
    });
  }

  function ensureParentPortalSection() {
    var ex = $("parentPortalStudio");
    if (ex) return ex;
    var anchor = $("parentsStudio") || $("classroomsStudio") || $("weeklyPlannerStudio") || $("learnSection");
    if (!anchor || !anchor.parentNode) return null;
    var sec = document.createElement("section");
    sec.id = "parentPortalStudio";
    sec.className = "py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20";
    anchor.parentNode.insertBefore(sec, anchor);
    return sec;
  }

  function renderParentPortal() {
    var sec = ensureParentPortalSection();
    if (!sec) return;
    if (!PState.children.length) {
      PState.children.push({ id: "ch1", name: "ابني / ابنتي", grade: "الصف السابع", code: "", weakSubj: "الرياضيات", goal: "التفوق والالتزام" });
    }
    if (PState.activeIdx >= PState.children.length) PState.activeIdx = 0;
    var ch = PState.children[PState.activeIdx];

    collectChildProgress(ch, function (prog) {
      var cl = prog.classInfo;
      var clItems = (cl && Array.isArray(cl.items)) ? cl.items : [];
      var inpCls = "w-full text-xs font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

      sec.innerHTML =
        '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden text-right">' +
          '<div class="p-5 sm:p-7 bg-gradient-to-l from-teal-700 via-emerald-700 to-slate-900 text-white">' +
            '<div class="flex flex-wrap items-center justify-between gap-3">' +
              '<div>' +
                '<div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 text-amber-300 text-xs font-black mb-1.5">' +
                  '<span>👨‍👩‍👧‍👦 بوابة ولي الأمر والأسرة التفاعلية</span>' +
                '</div>' +
                '<h2 class="text-xl sm:text-2xl font-black">شراكة البيت والمدرسة: تابع تقدم أبنائك وخطط لمذاكرتهم بذكاء</h2>' +
                '<p class="text-xs text-slate-200 mt-1">اربط حساب ابنك برمز الفصل الدراسي، تفقّد واجباته واختباراته ومراجعته اليومية، واحصل على خطة متابعة منزلية مخصصة.</p>' +
              '</div>' +
              '<div class="flex flex-wrap gap-2">' +
                '<button type="button" id="ppOpenTeacherCard" class="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow transition">📋 إصدار بطاقة متابعة مصوّرة</button>' +
                '<button type="button" id="ppOpenWeeklyPlan" class="px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-extrabold border border-white/20 transition">🗓️ جدول المذاكرة المنزلي</button>' +
              '</div>' +
            '</div>' +
          '</div>' +

          '<div class="p-5 sm:p-7 space-y-6">' +
            '<div class="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">' +
              '<div class="flex flex-wrap items-center gap-1.5">' +
                '<span class="text-xs font-black text-slate-600 dark:text-slate-300 ml-1">👶 الأبناء المسجلون بالمتابعة:</span>' +
                PState.children.map(function (c, i) {
                  var on = i === PState.activeIdx;
                  return '<button type="button" data-pp-child="' + i + '" class="px-3.5 py-1.5 rounded-xl text-xs font-extrabold transition ' +
                    (on ? "bg-teal-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200") + '">' +
                    '<span>🎒 ' + esc(c.name) + ' (' + esc(c.grade) + ')</span>' +
                  '</button>';
                }).join("") +
                '<button type="button" id="ppAddChildBtn" class="px-3 py-1.5 rounded-xl bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 text-xs font-extrabold hover:bg-emerald-600 hover:text-white transition">➕ إضافة ابن/ابنة</button>' +
              '</div>' +
              (PState.children.length > 1 ? '<button type="button" id="ppDelChildBtn" class="text-xs font-bold text-rose-500 hover:underline">حذف الملف الحالي</button>' : '') +
            '</div>' +

            '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5">' +
              '<div class="lg:col-span-5 rounded-2xl border border-slate-200 dark:border-slate-700/80 bg-slate-50/70 dark:bg-slate-900/50 p-4 space-y-3">' +
                '<div class="text-xs font-black text-teal-700 dark:text-teal-300 flex items-center justify-between">' +
                  '<span>🪪 بيانات الابن/الابنة وربط الفصل</span>' +
                  '<span class="text-[10px] text-slate-400">يُحفظ تلقائياً</span>' +
                '</div>' +
                '<div class="grid grid-cols-2 gap-2.5">' +
                  '<div><label class="block text-[11px] font-bold mb-1">اسم الابن / الابنة</label><input id="ppChName" value="' + esc(ch.name) + '" class="' + inpCls + '"></div>' +
                  '<div><label class="block text-[11px] font-bold mb-1">الصف الدراسي</label><select id="ppChGrade" class="' + inpCls + '">' +
                    ["الصف الأول", "الصف الثاني", "الصف الثالث", "الصف الرابع", "الصف الخامس", "الصف السادس", "الصف السابع", "الصف الثامن", "الصف التاسع", "الصف العاشر", "الصف الحادي عشر", "الصف الثاني عشر (التوجيهي)"].map(function (g) {
                      return '<option' + (g === ch.grade ? " selected" : "") + '>' + g + '</option>';
                    }).join("") +
                  '</select></div>' +
                '</div>' +
                '<div class="grid grid-cols-2 gap-2.5">' +
                  '<div><label class="block text-[11px] font-bold mb-1">رمز الفصل (من المعلم)</label><div class="flex gap-1"><input id="ppChCode" dir="ltr" value="' + esc(ch.code) + '" placeholder="GZ-1234" class="' + inpCls + ' font-mono uppercase text-center"><button type="button" id="ppSyncCodeBtn" class="px-3 py-2 rounded-xl bg-teal-600 text-white text-xs font-black shrink-0" title="تحديث بيانات الفصل">🔄</button></div></div>' +
                  '<div><label class="block text-[11px] font-bold mb-1">مواد نركز عليها</label><input id="ppChWeak" value="' + esc(ch.weakSubj || "") + '" placeholder="مثال: الرياضيات، الإنجليزية" class="' + inpCls + '"></div>' +
                '</div>' +
                '<div><label class="block text-[11px] font-bold mb-1">هدف الأسرة هذا الشهر</label><input id="ppChGoal" value="' + esc(ch.goal || "") + '" placeholder="مثال: إتقان جدول الضرب والالتزام بالمراجعة" class="' + inpCls + '"></div>' +
                '<div class="pt-1 flex flex-wrap gap-2">' +
                  '<button type="button" id="ppApplyToStudentMode" class="flex-1 py-2 px-3 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-black transition">🎒 افتح بوابة الطالب لـ «' + esc(ch.name) + '»</button>' +
                  '<button type="button" id="ppPrintFamilyCert" class="py-2 px-3 rounded-xl bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/30 text-xs font-extrabold hover:bg-amber-500 hover:text-slate-950 transition">🏅 شهادة تشجيع من الأسرة</button>' +
                '</div>' +
              '</div>' +

              '<div class="lg:col-span-7 space-y-4">' +
                '<div class="grid grid-cols-2 sm:grid-cols-4 gap-2.5">' +
                  '<div class="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 text-center">' +
                    '<div class="text-2xl font-black text-emerald-600 dark:text-emerald-400">' + prog.xp.xp + ' XP</div>' +
                    '<div class="text-[11px] font-bold text-slate-600 dark:text-slate-300 mt-0.5">نقاط الخبرة (مستوى ' + prog.xp.level + ')</div>' +
                  '</div>' +
                  '<div class="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/25 text-center">' +
                    '<div class="text-2xl font-black text-amber-600 dark:text-amber-400">' + Math.max(prog.review.streak || 0, prog.dailyStreak || 0) + ' 🔥</div>' +
                    '<div class="text-[11px] font-bold text-slate-600 dark:text-slate-300 mt-0.5">أيام المذاكرة المتتالية</div>' +
                  '</div>' +
                  '<div class="p-3.5 rounded-2xl bg-indigo-500/10 border border-indigo-500/25 text-center">' +
                    '<div class="text-2xl font-black text-indigo-600 dark:text-indigo-400">' + (prog.review.today || 0) + ' / ' + (prog.review.total || 0) + '</div>' +
                    '<div class="text-[11px] font-bold text-slate-600 dark:text-slate-300 mt-0.5">بطاقات راجعها اليوم</div>' +
                  '</div>' +
                  '<div class="p-3.5 rounded-2xl bg-sky-500/10 border border-sky-500/25 text-center">' +
                    '<div class="text-2xl font-black text-sky-600 dark:text-sky-400">' + clItems.length + ' 📌</div>' +
                    '<div class="text-[11px] font-bold text-slate-600 dark:text-slate-300 mt-0.5">مهام الفصل الدراسي</div>' +
                  '</div>' +
                '</div>' +

                '<div class="rounded-2xl border border-slate-200 dark:border-slate-700 p-4 bg-white dark:bg-slate-800/80 space-y-3">' +
                  '<div class="flex items-center justify-between">' +
                    '<h3 class="text-xs sm:text-sm font-black text-slate-900 dark:text-white">🏫 حالة الفصل الدراسي والواجبات المقررة</h3>' +
                    (prog.lastLesson ? '<span class="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">📖 آخر درس تصفحه: ' + esc(prog.lastLesson.label) + '</span>' : '') +
                  '</div>' +
                  (cl
                    ? '<div class="space-y-2">' +
                        '<div class="p-2.5 rounded-xl bg-teal-500/10 border border-teal-500/25 flex flex-wrap items-center justify-between gap-2 text-xs">' +
                          '<div><b>الفصل:</b> ' + esc(cl.title) + ' (' + esc(cl.id) + ') • <b>المعلم:</b> ' + esc(cl.teacher || "معلم المادة") + '</div>' +
                          '<button type="button" id="ppGoClassroom" class="px-3 py-1 rounded-lg bg-teal-600 text-white text-[11px] font-bold">فتح مهام الفصل</button>' +
                        '</div>' +
                        (cl.announcement ? '<div class="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs font-bold text-amber-800 dark:text-amber-300">📢 رسالة المعلم للطلاب وأولياء الأمور: ' + esc(cl.announcement) + '</div>' : '') +
                      '</div>'
                    : '<div class="text-xs text-slate-500 leading-relaxed">أدخل <b>رمز الفصل (مثل GZ-1234)</b> الذي أرسله المعلم في الحقل المجاور واضغط 🔄 لعرض إعلانات المعلم وواجبات واختبارات ابنك هنا مباشرة.</div>') +
                '</div>' +

                '<div class="grid grid-cols-2 sm:grid-cols-4 gap-2">' +
                  '<button type="button" data-pp-tool="tutorStudio" class="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-teal-500 bg-white dark:bg-slate-800 text-right transition">' +
                    '<div class="text-base">🤖</div><div class="text-[11px] font-black mt-0.5">اشرح لابني درساً</div><div class="text-[9px] text-slate-500">المعلم الخصوصي الذكي</div>' +
                  '</button>' +
                  '<button type="button" data-pp-tool="selfQuiz" class="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-teal-500 bg-white dark:bg-slate-800 text-right transition">' +
                    '<div class="text-base">🎯</div><div class="text-[11px] font-black mt-0.5">اختبر ابني الآن</div><div class="text-[9px] text-slate-500">5 أسئلة فورية بالـ AI</div>' +
                  '</button>' +
                  '<button type="button" data-pp-tool="reviewStudio" class="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-teal-500 bg-white dark:bg-slate-800 text-right transition">' +
                    '<div class="text-base">🧠</div><div class="text-[11px] font-black mt-0.5">تسميع البطاقات</div><div class="text-[9px] text-slate-500">التكرار المتباعد</div>' +
                  '</button>' +
                  '<button type="button" data-pp-tool="offPackStudio" class="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-teal-500 bg-white dark:bg-slate-800 text-right transition">' +
                    '<div class="text-base">📥</div><div class="text-[11px] font-black mt-0.5">حقيبة بلا إنترنت</div><div class="text-[9px] text-slate-500">للمذاكرة وقت الانقطاع</div>' +
                  '</button>' +
                '</div>' +
              '</div>' +
            '</div>' +

            '<div class="rounded-2xl border border-teal-500/30 bg-gradient-to-l from-teal-500/5 via-emerald-500/5 to-sky-500/5 p-4 sm:p-5 space-y-3">' +
              '<div class="flex flex-wrap items-center justify-between gap-2">' +
                '<div>' +
                  '<h3 class="text-sm font-black text-slate-900 dark:text-white">🤖 المستشار التربوي الأسري وخطة المتابعة المنزلية</h3>' +
                  '<p class="text-[11px] text-slate-500 dark:text-slate-400">احصل على جدول إرشادي مخصص لولي الأمر لمتابعة «' + esc(ch.name) + '» في المنزل وتنظيم وقته</p>' +
                '</div>' +
                '<div class="flex flex-wrap gap-2">' +
                  '<button type="button" id="ppGenAiPlan" class="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-black shadow transition"' + (PState.aiBusy ? " disabled" : "") + '>' +
                    (PState.aiBusy ? "⏳ جارٍ إعداد الخطة الأسرية…" : "✨ ولّد خطة متابعة منزلية لابني") +
                  '</button>' +
                  (PState.aiPlan ? '<button type="button" id="ppSendPlanToPlanner" class="px-3 py-2 rounded-xl bg-indigo-600 text-white text-xs font-extrabold">🗓️ أضف للمخطط الأسبوعي</button>' : '') +
                '</div>' +
              '</div>' +
              (PState.aiPlan
                ? '<div class="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs leading-relaxed whitespace-pre-line font-semibold text-slate-800 dark:text-slate-200">' + esc(PState.aiPlan) + '</div>'
                : '') +
            '</div>' +
          '</div>' +
        '</div>';

      sec.querySelectorAll("[data-pp-child]").forEach(function (b) {
        b.onclick = function () {
          PState.activeIdx = +b.getAttribute("data-pp-child");
          saveParentState();
          renderParentPortal();
        };
      });
      var addBtn = $("ppAddChildBtn");
      if (addBtn) addBtn.onclick = function () {
        PState.children.push({
          id: "ch" + Date.now(),
          name: "الابن " + (PState.children.length + 1),
          grade: "الصف الرابع",
          code: "",
          weakSubj: "اللغة العربية والرياضيات",
          goal: "إتقان المهارات الأساسية"
        });
        PState.activeIdx = PState.children.length - 1;
        saveParentState();
        renderParentPortal();
        toast("تمت إضافة ملف متابعة جديد — عدّل الاسم والصف", "success");
      };
      var delBtn = $("ppDelChildBtn");
      if (delBtn) delBtn.onclick = function () {
        PState.children.splice(PState.activeIdx, 1);
        PState.activeIdx = 0;
        saveParentState();
        renderParentPortal();
      };

      function syncChildFields() {
        if ($("ppChName")) ch.name = $("ppChName").value.trim() || "ابني";
        if ($("ppChGrade")) ch.grade = $("ppChGrade").value;
        if ($("ppChCode")) ch.code = $("ppChCode").value.trim().toUpperCase();
        if ($("ppChWeak")) ch.weakSubj = $("ppChWeak").value.trim();
        if ($("ppChGoal")) ch.goal = $("ppChGoal").value.trim();
        saveParentState();
      }
      ["ppChName", "ppChGrade", "ppChCode", "ppChWeak", "ppChGoal"].forEach(function (id) {
        var el = $(id);
        if (el) {
          el.oninput = syncChildFields;
          el.onchange = function () { syncChildFields(); renderParentPortal(); };
        }
      });

      if ($("ppSyncCodeBtn")) $("ppSyncCodeBtn").onclick = function () {
        syncChildFields();
        renderParentPortal();
        toast("تم تحديث بيانات متابعة الطالب ✓", "success");
      };
      if ($("ppOpenTeacherCard")) $("ppOpenTeacherCard").onclick = function () {
        syncChildFields();
        if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("parentsStudio", true);
      };
      if ($("ppOpenWeeklyPlan")) $("ppOpenWeeklyPlan").onclick = function () {
        syncChildFields();
        sendToWeeklyPlanner("متابعة مذاكرة " + ch.name + " (" + ch.weakSubj + ")", "0_0", "مراجعة " + ch.weakSubj + " مع " + ch.name);
        if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("weeklyPlannerStudio", true);
      };
      if ($("ppApplyToStudentMode")) $("ppApplyToStudentMode").onclick = function () {
        syncChildFields();
        if (window.EduLauncher && window.EduLauncher.setRole) window.EduLauncher.setRole("student");
        if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("learnSection", false);
      };
      if ($("ppPrintFamilyCert")) $("ppPrintFamilyCert").onclick = function () {
        syncChildFields();
        if (window.EduCertificates && window.EduCertificates.openWithNames) {
          window.EduCertificates.openWithNames([ch.name + " | التزام وتميز منزلي"], ch.grade + " — تشجيع الأسرة");
        } else if (window.EduLauncher && window.EduLauncher.jump) {
          window.EduLauncher.jump("certStudio", true);
        }
      };
      sec.querySelectorAll("[data-pp-tool]").forEach(function (b) {
        b.onclick = function () {
          syncChildFields();
          var tid = b.getAttribute("data-pp-tool");
          if (tid === "selfQuiz" && window.EduStudy && window.EduStudy.quiz) window.EduStudy.quiz();
          else openToolWithContext(tid, { title: ch.weakSubj || "مراجعة عامة", grade: ch.grade, subject: ch.weakSubj });
        };
      });
      if ($("ppGenAiPlan")) $("ppGenAiPlan").onclick = function () { syncChildFields(); generateParentAiPlan(); };
      if ($("ppSendPlanToPlanner")) $("ppSendPlanToPlanner").onclick = function () {
        sendToWeeklyPlanner("تطبيق خطة المتابعة المنزلية لـ " + ch.name, "0_1", "جلسة متابعة منزلية (" + ch.name + ")");
        if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("weeklyPlannerStudio", true);
      };
    });
  }

  // ==================== 6. بوابة الجمهور العام والمجتمع المعرفي (#publicHubStudio) ====================
  function ensurePublicHubSection() {
    var ex = $("publicHubStudio");
    if (ex) return ex;
    var anchor = $("parentPortalStudio") || $("coursesSection") || $("library");
    if (!anchor || !anchor.parentNode) return null;
    var sec = document.createElement("section");
    sec.id = "publicHubStudio";
    sec.className = "py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20";
    anchor.parentNode.insertBefore(sec, anchor);
    return sec;
  }

  function renderPublicHub() {
    var sec = ensurePublicHubSection();
    if (!sec) return;
    var cards = [
      { ico: "🏅", title: "الدورات التدريبية المجانية والمعتمدة", desc: "برامج تدريبية في توظيف الذكاء الاصطناعي، المهارات الرقمية، واستراتيجيات التعليم الحديث.", app: "coursesSection", badge: "مفتوح للجمهور", color: "from-lime-600 to-emerald-700" },
      { ico: "🗺️", title: "أطلس فلسطين الجغرافي والتاريخي", desc: "استكشف مدن وقرى وتضاريس ومعالم فلسطين التاريخية مع تحدي الخريطة التفاعلية.", app: "atlasStudio", badge: "ثقافة وهوية 🇵🇸", color: "from-emerald-700 to-teal-900" },
      { ico: "✨", title: "مكتبة ومولّد أوامر الذكاء الاصطناعي (Prompts)", desc: "صياغة أوامر احترافية لـ ChatGPT وGemini للبحث والكتابة والتلخيص والإبداع.", app: "generator", badge: "أدوات AI للجميع", color: "from-cyan-600 to-sky-800" },
      { ico: "💻", title: "أكاديمية البرمجة والخوارزميات", desc: "بيئة تفاعلية لتعلم أساسيات البرمجة، التفكير المنطقي، وخوارزميات الروبوت بدون خبرة مسبقة.", app: "codingLabStudio", badge: "مهارات المستقبل", color: "from-indigo-700 to-slate-900" },
      { ico: "🗣️", title: "معمل اللغات والنطق السليم", desc: "تدرّب على نطق الكلمات الإنجليزية والعربية بالصوت، واختبر مهاراتك اللغوية والنحوية.", app: "langLabStudio", badge: "تعلم ذاتي", color: "from-sky-600 to-blue-800" },
      { ico: "🎙️", title: "المسابقات الثقافية والإذاعة المعرفية", desc: "بنك معلومات ثقافية عامة ومسابقات تفاعلية شيقة للمراكز المجتمعية والأسر.", app: "radioStudio", badge: "ثقافة عامة", color: "from-amber-600 to-orange-800" },
      { ico: "🗜️", title: "أدوات ضغط الصور وتحويل PDF محلياً", desc: "خدمة مجانية سريعة تعمل على جهازك لضغط الصور 85% وتحويلها إلى ملفات PDF دون رفعها للإنترنت.", app: "mediaToolsStudio", badge: "خدمة مجتمعية", color: "from-slate-700 to-cyan-900" },
      { ico: "📚", title: "المكتبة التعليمية والملخصات المفتوحة", desc: "تصفح مئات المقالات والملخصات والأدلة التربوية والتقنية المتاحة للجميع.", app: "library", badge: "مكتبة عامة", color: "from-purple-600 to-indigo-900" }
    ];

    sec.innerHTML =
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden text-right">' +
        '<div class="p-5 sm:p-7 bg-gradient-to-l from-sky-800 via-blue-900 to-slate-950 text-white">' +
          '<div class="flex flex-wrap items-center justify-between gap-3">' +
            '<div>' +
              '<div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 text-sky-300 text-xs font-black mb-1.5">' +
                '<span>🌍 بوابة الجمهور العام والتعلم مدى الحياة</span>' +
              '</div>' +
              '<h2 class="text-xl sm:text-2xl font-black">الذكاء الاصطناعي والمعرفة والثقافة متاحة لكل فرد في المجتمع</h2>' +
              '<p class="text-xs text-slate-200 mt-1">مساحة مفتوحة للباحثين، الخريجين، المهتمين بالتقنية، والمجتمع العام للاستفادة من الدورات وأدوات الذكاء الاصطناعي والمحتوى الثقافي.</p>' +
            '</div>' +
            '<div class="flex flex-wrap gap-2">' +
              '<button type="button" data-pub-open="dailyChallenge" class="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow transition">🔥 شارك في التحدي الثقافي اليومي</button>' +
              '<button type="button" data-pub-open="about" class="px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-extrabold border border-white/20 transition">🇵🇸 رسالة المنصة وتواصل معنا</button>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div class="p-5 sm:p-7 space-y-5">' +
          '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">' +
            cards.map(function (c) {
              return '<button type="button" data-pub-open="' + c.app + '" class="text-right p-4 rounded-2xl border border-slate-200 dark:border-slate-700/90 bg-white dark:bg-slate-800/90 hover:border-brand-500 hover:-translate-y-1 hover:shadow-lg transition-all flex flex-col justify-between group">' +
                '<div>' +
                  '<div class="flex items-center justify-between gap-2 mb-2.5">' +
                    '<div class="w-11 h-11 rounded-2xl bg-gradient-to-br ' + c.color + ' text-white text-xl flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">' + c.ico + '</div>' +
                    '<span class="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-[10px] font-extrabold text-brand-600 dark:text-sky-300">' + esc(c.badge) + '</span>' +
                  '</div>' +
                  '<h3 class="text-xs sm:text-sm font-black text-slate-900 dark:text-white group-hover:text-brand-600 dark:group-hover:text-sky-400">' + esc(c.title) + '</h3>' +
                  '<p class="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">' + esc(c.desc) + '</p>' +
                '</div>' +
                '<div class="mt-3 pt-2 border-t border-slate-100 dark:border-slate-700/60 text-[11px] font-extrabold text-brand-600 dark:text-sky-400 flex items-center justify-between">' +
                  '<span>افتح الخدمة الآن</span><i class="fa-solid fa-arrow-left text-[10px]"></i>' +
                '</div>' +
              '</button>';
            }).join("") +
          '</div>' +
        '</div>' +
      '</div>';

    sec.querySelectorAll("[data-pub-open]").forEach(function (b) {
      b.onclick = function () {
        var id = b.getAttribute("data-pub-open");
        if (id === "dailyChallenge" && window.EduStudy && window.EduStudy.daily) {
          window.EduStudy.daily();
        } else if (window.EduLauncher && window.EduLauncher.jump) {
          window.EduLauncher.jump(id, id !== "library" && id !== "about" && id !== "coursesSection");
        }
      };
    });
  }

  // ==================== 7. منسّق الخطوات والأدوات حسب احتياجات المعلم والطالب (#eduRoleOrchestrator) ====================
  function renderRoleOrchestrator() {
    var hubSec = $("smartHubSection");
    if (!hubSec) return;
    var container = $("eduRoleOrchestrator");
    if (!container) {
      container = document.createElement("div");
      container.id = "eduRoleOrchestrator";
      container.className = "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-5";
      hubSec.insertBefore(container, hubSec.firstChild);
    }

    var curRole = (window.EduLauncher && window.EduLauncher.getRole) ? window.EduLauncher.getRole() : (localStorage.getItem(ROLE_KEY) || "all");
    var pKey = PERSONAS[curRole] ? curRole : "all";
    var P = PERSONAS[pKey];
    var feedCount = loadSharedFeed().length;

    container.innerHTML =
      '<div class="glass-card rounded-3xl border-2 border-brand-500/25 dark:border-brand-400/20 shadow-xl overflow-hidden text-right">' +
        // 1. Top Role Switcher Header
        '<div class="p-3.5 sm:p-4 bg-gradient-to-l from-slate-900 via-brand-900 to-slate-900 text-white border-b border-white/10">' +
          '<div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3">' +
            '<div class="flex items-center gap-2.5">' +
              '<span class="w-10 h-10 rounded-2xl bg-brand-500/20 border border-brand-400/40 flex items-center justify-center text-xl shrink-0">🧭</span>' +
              '<div>' +
                '<div class="text-xs sm:text-sm font-black text-white">اختر دورك لترتيب الخطوات والأدوات حسب احتياجك الفعلي</div>' +
                '<div class="text-[11px] text-sky-200/85">مسارات مرتبة خطوة بخطوة للمعلم وللطالب ولولي الأمر وللجمهور العام + استيراد مباشر من الكاميرا والجهاز</div>' +
              '</div>' +
            '</div>' +
            '<div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-1.5">' +
              ["teacher", "student", "university", "parent", "public", "all"].map(function (k) {
                var item = PERSONAS[k];
                var active = pKey === k;
                return '<button type="button" data-persona-pick="' + k + '" class="px-3 py-2 rounded-2xl text-xs font-black flex items-center justify-center gap-1.5 transition-all ' +
                  (active
                    ? "bg-gradient-to-l " + item.gradient + " text-white shadow-lg ring-2 ring-amber-400/90 scale-[1.02]"
                    : "bg-white/10 hover:bg-white/20 text-slate-200 border border-white/10") + '">' +
                  '<span class="text-base">' + item.ico + '</span>' +
                  '<span>' + esc(item.short) + '</span>' +
                '</button>';
              }).join("") +
            '</div>' +
          '</div>' +
        '</div>' +

        // 2. Role Step-by-Step Stages Body
        '<div class="p-4 sm:p-5 bg-white/95 dark:bg-slate-900/95 space-y-4">' +
          '<div class="flex flex-wrap items-center justify-between gap-2">' +
            '<div>' +
              '<div class="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full border text-xs font-black ' + P.badgeCls + '">' +
                '<span>' + P.ico + '</span><span>' + esc(P.title) + '</span>' +
              '</div>' +
              '<p class="text-xs text-slate-600 dark:text-slate-300 mt-1 font-semibold">' + esc(P.subtitle) + '</p>' +
            '</div>' +
            '<div class="flex flex-wrap items-center gap-1.5">' +
              '<button type="button" data-persona-app="smartUnifiedCockpit" class="px-3 py-1.5 rounded-xl bg-gradient-to-l from-sky-500 to-indigo-600 hover:opacity-95 text-white text-xs font-black shadow flex items-center gap-1.5"><i class="fa-solid fa-compass"></i><span>🧭 مركز القيادة وكتب Google Drive والثقافة</span></button>' +
              '<button type="button" data-persona-app="stemLabPlannerStudio" class="px-3 py-1.5 rounded-xl bg-gradient-to-l from-emerald-600 to-teal-700 hover:opacity-95 text-white text-xs font-black shadow flex items-center gap-1.5"><i class="fa-solid fa-flask"></i><span>🧪 مختبر المعادلات والمخطط الذكي</span></button>' +
              '<button type="button" data-persona-app="smartNotesFlashStudio" class="px-3 py-1.5 rounded-xl bg-gradient-to-l from-amber-600 to-orange-600 hover:opacity-95 text-white text-xs font-black shadow flex items-center gap-1.5">' +
                '<i class="fa-solid fa-book-bookmark"></i><span>📓 دفتر كورنيل والاستدعاء النشط</span>' +
              '</button>' +
              '<button type="button" data-persona-app="visualConceptExamStudio" class="px-3 py-1.5 rounded-xl bg-gradient-to-l from-cyan-600 to-indigo-600 hover:opacity-95 text-white text-xs font-black shadow flex items-center gap-1.5">' +
                '<i class="fa-solid fa-diagram-project"></i><span>🗺️ خرائط المفاهيم والامتحان الموقوت</span>' +
              '</button>' +
              '<button type="button" data-persona-app="masteryAnalyticsStudio" class="px-3 py-1.5 rounded-xl bg-gradient-to-l from-emerald-600 to-teal-600 hover:opacity-95 text-white text-xs font-black shadow flex items-center gap-1.5">' +
                '<i class="fa-solid fa-chart-line"></i><span>📦 الحقيبة الذهبية 5×1 ومرصد الإتقان</span>' +
              '</button>' +
              '<button type="button" data-persona-app="cvBuilderStudio" class="px-3 py-1.5 rounded-xl bg-gradient-to-l from-indigo-500 to-purple-600 hover:opacity-95 text-white text-xs font-black shadow flex items-center gap-1.5">' +
                '<i class="fa-solid fa-id-card"></i><span>📄 إنشاء CV احترافي (عربي/EN)</span>' +
              '</button>' +
              '<button type="button" data-persona-app="bookReaderStudio" class="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow flex items-center gap-1.5">' +
                '<i class="fa-solid fa-book-open"></i><span>📖 قارئ الكتب التفاعلي</span>' +
              '</button>' +
              '<button type="button" id="btnOrchPersonalize" class="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black shadow flex items-center gap-1.5">' +
                '<i class="fa-solid fa-sliders"></i><span>🎨 تخصيص صفي ومادتي</span>' +
              '</button>' +
              '<button type="button" data-persona-app="sourcesStudio" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow flex items-center gap-1.5">' +
                '<i class="fa-solid fa-camera"></i><span>📷 صوّر صفحة</span>' +
              '</button>' +
              '<button type="button" data-persona-app="unifiedWorkflowStudio" class="px-3 py-1.5 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 text-slate-950 text-xs font-black shadow flex items-center gap-1.5">' +
                '<span>⚡ غرفة العمليات (' + feedCount + ')</span>' +
              '</button>' +
            '</div>' +
          '</div>' +

          // 4 Ordered Stages Grid
          '<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5">' +
            P.stages.map(function (stg) {
              return '<div class="rounded-2xl border-2 ' + stg.color + ' p-3.5 flex flex-col justify-between space-y-3">' +
                '<div>' +
                  '<div class="flex items-center justify-between gap-2 mb-1.5">' +
                    '<span class="px-2.5 py-0.5 rounded-full text-[10px] font-black ' + stg.headBg + '">' + esc(stg.num) + '</span>' +
                    '<span class="text-lg">' + stg.ico + '</span>' +
                  '</div>' +
                  '<h3 class="text-xs sm:text-sm font-black text-slate-900 dark:text-white">' + esc(stg.title) + '</h3>' +
                  '<p class="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">' + esc(stg.desc) + '</p>' +
                  '<div class="mt-3 space-y-1.5">' +
                    stg.tools.map(function (t, tidx) {
                      return '<button type="button" data-persona-app="' + t.app + '" class="w-full text-right p-2 rounded-xl bg-white dark:bg-slate-800/90 border border-slate-200/90 dark:border-slate-700 hover:border-brand-500 hover:shadow-sm transition flex items-center gap-2 group">' +
                        '<span class="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-900 flex items-center justify-center text-base shrink-0 group-hover:scale-110 transition-transform">' + t.ico + '</span>' +
                        '<div class="min-w-0 flex-1">' +
                          '<div class="text-[11px] font-black text-slate-900 dark:text-white group-hover:text-brand-600 dark:group-hover:text-sky-400 truncate">' + (tidx + 1) + '. ' + esc(t.label) + '</div>' +
                          '<div class="text-[10px] text-slate-500 dark:text-slate-400 truncate">' + esc(t.sub) + '</div>' +
                        '</div>' +
                        '<i class="fa-solid fa-chevron-left text-[10px] text-slate-400 group-hover:text-brand-500 shrink-0"></i>' +
                      '</button>';
                    }).join("") +
                  '</div>' +
                '</div>' +
              '</div>';
            }).join("") +
          '</div>' +
        '</div>' +
      '</div>';

    container.querySelectorAll("[data-persona-pick]").forEach(function (b) {
      b.onclick = function () {
        var role = b.getAttribute("data-persona-pick");
        if (window.EduLauncher && window.EduLauncher.setRole) {
          window.EduLauncher.setRole(role);
        }
        renderRoleOrchestrator();
        updateHeaderRolePill();
      };
    });

    var pBtn = $("btnOrchPersonalize");
    if (pBtn) pBtn.onclick = function () { if (window.EduPersonalize && window.EduPersonalize.open) window.EduPersonalize.open(); };
    container.querySelectorAll("[data-persona-app]").forEach(function (b) {
      b.onclick = function () {
        var aid = b.getAttribute("data-persona-app");
        if (aid === "selfQuiz" && window.EduStudy && window.EduStudy.quiz) {
          window.EduStudy.quiz();
        } else if (aid === "dailyChallenge" && window.EduStudy && window.EduStudy.daily) {
          window.EduStudy.daily();
        } else if (aid === "questionBank" && window.EduStudy && window.EduStudy.bank) {
          window.EduStudy.bank();
        } else if (window.EduLauncher && window.EduLauncher.jump) {
          var mainSecs = ["learnSection", "booksSection", "library", "userWorkspaceSection", "about", "social", "coursesSection"];
          window.EduLauncher.jump(aid, mainSecs.indexOf(aid) === -1);
        }
      };
    });
  }

  function updateHeaderRolePill() {
    var hdrSearch = $("btnHeaderQuickSearch");
    if (!hdrSearch || !hdrSearch.parentNode) return;
    var pill = $("btnHeaderRoleSwitcher");
    if (!pill) {
      pill = document.createElement("button");
      pill.id = "btnHeaderRoleSwitcher";
      pill.type = "button";
      pill.className = "flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[11px] font-extrabold transition-all border shadow-xs bg-indigo-500/10 hover:bg-indigo-600 text-indigo-700 dark:text-indigo-300 hover:text-white border-indigo-500/30";
      pill.title = "تغيير وضع التصفح (معلم / طالب / ولي أمر / جمهور عام)";
      hdrSearch.parentNode.insertBefore(pill, hdrSearch);
      pill.onclick = openRoleModal;
    }
    var curRole = (window.EduLauncher && window.EduLauncher.getRole) ? window.EduLauncher.getRole() : (localStorage.getItem(ROLE_KEY) || "all");
    var P = PERSONAS[curRole] || PERSONAS.all;
    pill.innerHTML = '<span>' + P.ico + '</span><span class="hidden sm:inline">' + esc(P.short) + '</span>';
  }

  function openRoleModal() {
    if (typeof showModalContent !== "function") return;
    var curRole = (window.EduLauncher && window.EduLauncher.getRole) ? window.EduLauncher.getRole() : (localStorage.getItem(ROLE_KEY) || "all");
    var html =
      '<div class="p-4 shrink-0 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-900 text-white">' +
        '<div><h3 class="text-sm sm:text-base font-black">🎭 ترتيب الموقع والأدوات حسب دورك</h3>' +
        '<p class="text-[11px] text-slate-300">اختر بوابتك لتخصيص الخطوات والأدوات فوراً</p></div>' +
        '<button type="button" class="p-2 text-slate-300 hover:text-white" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button>' +
      '</div>' +
      '<div class="p-4 space-y-2.5 text-right overflow-y-auto">' +
        ["teacher", "student", "university", "parent", "public", "all"].map(function (k) {
          var p = PERSONAS[k];
          var on = curRole === k;
          return '<button type="button" data-modal-role="' + k + '" class="w-full text-right p-3.5 rounded-2xl border-2 transition flex items-start gap-3 ' +
            (on ? "border-brand-500 bg-brand-500/10" : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-brand-500") + '">' +
            '<div class="w-12 h-12 rounded-2xl bg-gradient-to-br ' + p.gradient + ' text-white text-2xl flex items-center justify-center shrink-0 shadow">' + p.ico + '</div>' +
            '<div class="flex-1 min-w-0">' +
              '<div class="flex items-center justify-between"><span class="text-sm font-black text-slate-900 dark:text-white">' + esc(p.title) + '</span>' + (on ? '<span class="text-[10px] font-black px-2 py-0.5 rounded-full bg-brand-600 text-white">الوضع النشط ✓</span>' : '') + '</div>' +
              '<p class="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">' + esc(p.subtitle) + '</p>' +
            '</div>' +
          '</button>';
        }).join("") +
      '</div>';
    showModalContent(html);
    document.querySelectorAll("[data-modal-role]").forEach(function (b) {
      b.onclick = function () {
        var r = b.getAttribute("data-modal-role");
        closeModal();
        if (window.EduLauncher && window.EduLauncher.setRole) window.EduLauncher.setRole(r);
        renderRoleOrchestrator();
        updateHeaderRolePill();
        if (window.EduMasterHierarchy && typeof window.EduMasterHierarchy.navigateToTarget === "function") {
          if (r === "university") window.EduMasterHierarchy.navigateToTarget("university");
          else if (r === "student" || r === "early" || r === "tawjihi") window.EduMasterHierarchy.navigateToTarget("curriculum");
          else window.EduMasterHierarchy.navigateToTarget("tools");
        }
      };
    });
  }

  function init() {
    hookCapturedIntoAI();
    renderUnifiedWorkflow();
    renderParentPortal();
    renderPublicHub();
    updateHeaderRolePill();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();

  window.EduSourceCapture = {
    getFiles: function () { return capturedFiles.slice(); },
    clearFiles: function () { capturedFiles = []; },
    handleFiles: handleUploadedFiles,
    extractText: extractTextFromCaptured,
    dictate: startVoiceDictation,
    openPresets: openCurriculumPickerModal,
    renderBar: renderSourceBarHtml,
    bindBar: bindSourceBar,
    presets: CURRICULUM_PRESETS
  };

  window.EduBridge = {
    getContext: getBridgeCtx,
    setContext: setBridgeCtx,
    openTool: openToolWithContext,
    toBank: sendToQuestionBank,
    toReview: sendToSmartReview,
    toPlanner: sendToWeeklyPlanner,
    kitToWorksheet: lessonKitToWorksheet,
    kitToGame: lessonKitToGame,
    addFeed: addSharedFeedItem,
    openRoleModal: openRoleModal,
    personas: PERSONAS,
    refreshOrchestrator: function () {
      renderRoleOrchestrator();
      updateHeaderRolePill();
      renderUnifiedWorkflow();
    }
  };
})();

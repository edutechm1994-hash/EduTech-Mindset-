/*
 * مولّد خطط الدروس (التحضير) — EduTech Mindset
 * حصة واحدة أو وحدة من عدة حصص، نموذج وزاري أو مبسّط، تعديل، حفظ (lessonplans)، تنزيل PDF وWord.
 */
(function () {
  "use strict";
  var COL = "lessonplans";
  var GRADES = ["الأول الأساسي", "الثاني الأساسي", "الثالث الأساسي", "الرابع الأساسي", "الخامس الأساسي", "السادس الأساسي", "السابع", "الثامن", "التاسع", "العاشر", "الحادي عشر", "الثاني عشر"];
  var st = { id: "", title: "", grade: GRADES[3], subject: "", topic: "", tpl: "moe", duration: 45, school: "", teacher: "", date: "", lessons: [], cur: 0, attach: [], dirty: false };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";
  function e(s) { return typeof escapeHtml === "function" ? escapeHtml(String(s == null ? "" : s)) : String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function $(id) { return document.getElementById(id); }
  function toast(m, t) { if (typeof showToast === "function") showToast(m, t || "success"); }
  function cloud() { return window.Cloud && window.Cloud.enabled; }
  function uid() { return window.Cloud && window.Cloud.getStudioUser ? window.Cloud.getStudioUser().uid : (window.Cloud && window.Cloud.user ? window.Cloud.user.uid : "local_workspace"); }
  function lsGet() { try { return JSON.parse(localStorage.getItem("ws_hdr") || "{}"); } catch (x) { return {}; } }
  function lsSet() { try { var o = lsGet(); o.school = st.school; o.teacher = st.teacher; localStorage.setItem("ws_hdr", JSON.stringify(o)); } catch (x) {} }

  // ---------- تنظيف ----------
  function str(v, n) { return String(v == null ? "" : v).trim().slice(0, n || 600); }
  function list(v, n) { return (Array.isArray(v) ? v : String(v || "").split("\n")).map(function (x) { return str(x, 300); }).filter(Boolean).slice(0, n || 8); }
  function normLesson(x) {
    if (!x || typeof x !== "object") return null;
    var acts = (Array.isArray(x.activities) ? x.activities : []).map(function (a) { return a && { time: Math.max(1, Math.min(90, parseInt(a.time, 10) || 5)), title: str(a.title, 120), teacher: str(a.teacher, 500), student: str(a.student, 500) }; }).filter(Boolean).slice(0, 8);
    if (!acts.length) acts = [{ time: 20, title: "النشاط الرئيس", teacher: "", student: "" }];
    var intro = x.intro || {}, clo = x.closure || {};
    return { title: str(x.title, 150), outcomes: list(x.outcomes), concepts: list(x.concepts, 10), resources: list(x.resources), prior: str(x.prior, 400),
      intro: { time: Math.max(1, Math.min(30, parseInt(intro.time, 10) || 5)), text: str(typeof intro === "string" ? intro : intro.text, 600) },
      activities: acts, closure: { time: Math.max(1, Math.min(30, parseInt(clo.time, 10) || 5)), text: str(typeof clo === "string" ? clo : clo.text, 600) },
      assessment: list(x.assessment), homework: str(x.homework, 500), notes: str(x.notes, 500) };
  }
  function parseJson(txt) {
    var s = String(txt || "").replace(/```json|```/gi, ""), a = s.indexOf("{"), b = s.lastIndexOf("}");
    if (a < 0 || b <= a) throw new Error("لم يُرجع الذكاء الاصطناعي نتيجة مفهومة، أعد المحاولة");
    return JSON.parse(s.slice(a, b + 1));
  }
  var SCHEMA = '{"unit":"عنوان الوحدة أو الدرس","lesson":{"title":"عنوان الحصة","outcomes":["الطالب يعرّف ..."],"concepts":["مفهوم"],"resources":["الكتاب المدرسي","السبورة"],"prior":"المعرفة السابقة المطلوبة","intro":{"time":5,"text":"التهيئة"},"activities":[{"time":10,"title":"اسم النشاط","teacher":"ماذا يفعل المعلم","student":"ماذا يفعل الطالب"}],"closure":{"time":5,"text":"الخاتمة والتلخيص"},"assessment":["أسئلة تقويم"],"homework":"الواجب","notes":"ملاحظات"}}';
  function askRetry(prompt, files) {
    return window.AI.ask(prompt, files || [], "lessonplan").catch(function () { return new Promise(function (r) { setTimeout(r, 1500); }).then(function () { return window.AI.ask(prompt, files || [], "lessonplan"); }); });
  }
  function buildPrompt(k, n, notes) {
    return "أنت معلّم خبير ومشرف تربوي متخصص في تحضير الدروس للمنهاج الفلسطيني. أعدّ خطة (تحضير) " + (n > 1 ? "للحصة " + k + " من " + n + " ضمن وحدة" : "لحصة واحدة") + (st.topic ? " عن: «" + st.topic + "»" : " مبنية على المحتوى الموجود في الصور المرفقة") +
      ".\nالمرحلة: " + st.grade + (st.subject ? "\nالمادة: " + st.subject : "") + "\nزمن الحصة: " + st.duration + " دقيقة (مجموع أزمنة التهيئة والأنشطة والخاتمة = " + st.duration + " بالضبط).\n" +
      (n > 1 ? "الوحدة من " + n + " حصص متسلسلة ومتدرجة؛ هذه الحصة رقم " + k + " ولها هدف وعنوان مختلفان عن بقية الحصص، وتبني على ما قبلها.\n" : "") + (notes ? "ملاحظات المعلم: " + notes + "\n" : "") +
      "أعد JSON صالحاً فقط بلا شرح وبلا علامات ```، بهذا الشكل:\n" + SCHEMA + "\nالقواعد: نتاجات تعلم من 2 إلى 4 بصيغة سلوكية قابلة للقياس (يعرّف، يحسب، يقارن…)، من 3 إلى 5 أنشطة متنوعة تتدرج من البسيط، لكل نشاط دور للمعلم ودور للطالب، وتفعيل للطالب (عمل تعاوني/أسئلة/تطبيق) أكثر من الإلقاء، وتقويم من 2 إلى 4 أسئلة، وواجب بيتي قصير. اللغة العربية الفصحى المبسّطة، والمحتوى دقيق علمياً ومناسب للمرحلة.";
  }
  function generate() {
    st.topic = $("lpTopic").value.trim(); st.grade = $("lpGrade").value; st.subject = $("lpSubject").value.trim(); st.tpl = $("lpTpl").value; st.duration = +$("lpDur").value;
    var n = +$("lpCount").value, notes = $("lpNotes").value.trim();
    if (!st.topic && !st.attach.length) { toast("اكتب موضوع الدرس أو أضف صورة الصفحة", "warning"); return; }
    var btn = $("lpGo"), stat = $("lpStat"), done = 0, files = st.attach.map(function (f) { return { mime: f.mime, data: f.data }; });
    btn.disabled = true; btn.classList.add("opacity-60"); stat.textContent = "⏳ جارٍ إعداد الخطة…" + (n > 1 ? " (" + n + " حصص بالتوازي)" : "");
    Promise.all(Array.apply(null, Array(n)).map(function (_, i) {
      return askRetry(buildPrompt(i + 1, n, notes), files).then(function (t) { done++; stat.textContent = "⏳ اكتملت " + done + " من " + n + "…"; return parseJson(t); });
    })).then(function (js) {
      var ls = js.map(function (j) { return normLesson(j.lesson || j); }).filter(Boolean);
      if (!ls.length) throw new Error("نتيجة غير صالحة، أعد المحاولة");
      st.title = str((js[0] && js[0].unit) || st.topic || "خطة درس", 120); st.lessons = ls; st.cur = 0; st.id = ""; st.dirty = true;
      stat.textContent = ""; renderEditor(); $("lpEditor").scrollIntoView({ behavior: "smooth", block: "start" });
    }, function (err) { stat.textContent = "⚠️ " + (err && err.message ? err.message : "تعذر التوليد"); })
      .then(function () { btn.disabled = false; btn.classList.remove("opacity-60"); });
  }
  function regen() {
    var i = st.cur, stat = $("lpEdStat"); stat.textContent = "⏳ جارٍ إعادة توليد الحصة…";
    var p = "في وحدة بعنوان «" + st.title + "» للمرحلة " + st.grade + (st.subject ? " (" + st.subject + ")" : "") + "، أعد كتابة خطة هذه الحصة بأنشطة وصياغة مختلفة مع الحفاظ على الهدف نفسه وزمن " + st.duration + " دقيقة:\n" + JSON.stringify(st.lessons[i]) + "\nأعد JSON فقط بالشكل {\"lesson\":{...}} بنفس الحقول بلا شرح.";
    askRetry(p).then(function (t) { var j = parseJson(t), n = normLesson(j.lesson || j); if (!n) throw new Error("نتيجة غير صالحة"); st.lessons[i] = n; st.dirty = true; stat.textContent = ""; renderEditor(); })
      .catch(function (err) { stat.textContent = "⚠️ " + (err.message || "تعذر"); });
  }

  // ---------- النموذج المطبوع ----------
  var CSS = ".lp{direction:rtl;text-align:right;font-family:'Cairo',Tahoma,sans-serif;color:#111;background:#fff;font-size:12.5px;line-height:1.7;padding:6mm}.lp *{box-sizing:border-box}.lp h1{text-align:center;font-size:19px;margin:0 0 6px;font-weight:900}" +
    ".lp table{width:100%;border-collapse:collapse;margin-bottom:8px}.lp th,.lp td{border:1.3px solid #222;padding:4px 8px;vertical-align:top}.lp th{background:#e5e7eb;font-weight:800;text-align:center}.lp td.k{background:#f3f4f6;font-weight:800;width:22%;white-space:nowrap}" +
    ".lp ul{margin:0;padding-inline-start:18px}.lp .tm{text-align:center;white-space:nowrap;width:60px}.lp .sec{background:#111;color:#fff;text-align:center;font-weight:900;padding:2px;border:1.3px solid #111}.lp tr{page-break-inside:avoid}";
  function ul(a) { return a.length ? "<ul>" + a.map(function (x) { return "<li>" + e(x) + "</li>"; }).join("") + "</ul>" : "&nbsp;"; }
  function lessonHtml(i) {
    var L = st.lessons[i], moe = st.tpl === "moe", n = st.lessons.length, total = L.intro.time + L.closure.time + L.activities.reduce(function (a, x) { return a + x.time; }, 0);
    var h = '<div class="lp"><h1>' + (moe ? "خطة درس يومية" : "تحضير درس") + (n > 1 ? " — الحصة " + (i + 1) + " من " + n : "") + "</h1>" +
      "<table><tr><td class=\"k\">المدرسة</td><td>" + e(st.school) + "&nbsp;</td><td class=\"k\">المعلم</td><td>" + e(st.teacher) + "&nbsp;</td></tr>" +
      "<tr><td class=\"k\">الصف</td><td>" + e(st.grade) + "</td><td class=\"k\">المادة</td><td>" + e(st.subject) + "&nbsp;</td></tr>" +
      "<tr><td class=\"k\">" + (n > 1 ? "الوحدة" : "الدرس") + "</td><td>" + e(st.title) + "</td><td class=\"k\">" + (n > 1 ? "عنوان الحصة" : "التاريخ") + "</td><td>" + (n > 1 ? e(L.title) : e(st.date) + "&nbsp;") + "</td></tr>" +
      "<tr><td class=\"k\">زمن الحصة</td><td>" + st.duration + " دقيقة</td><td class=\"k\">التاريخ / الشعبة</td><td>" + (n > 1 ? e(st.date) : "") + "&nbsp;</td></tr></table>" +
      "<table><tr><td class=\"k\">النتاجات (الأهداف)</td><td>" + ul(L.outcomes) + "</td></tr>" + (moe ? "<tr><td class=\"k\">المفاهيم والمصطلحات</td><td>" + ul(L.concepts) + "</td></tr><tr><td class=\"k\">المعرفة السابقة</td><td>" + e(L.prior) + "&nbsp;</td></tr>" : "") +
      "<tr><td class=\"k\">الوسائل والمصادر</td><td>" + ul(L.resources) + "</td></tr></table>" +
      "<table><tr><th class=\"tm\">الزمن</th><th>" + (moe ? "نشاط المعلم" : "الإجراءات") + "</th>" + (moe ? "<th>نشاط الطالب</th>" : "") + "</tr>" +
      "<tr><td class=\"tm\">" + L.intro.time + " د</td><td colspan=\"" + (moe ? 2 : 1) + "\"><b>التهيئة:</b> " + e(L.intro.text) + "</td></tr>" +
      L.activities.map(function (a) { return "<tr><td class=\"tm\">" + a.time + " د</td><td><b>" + e(a.title) + "</b><br>" + e(a.teacher) + "</td>" + (moe ? "<td>" + e(a.student) + "</td>" : "") + "</tr>"; }).join("") +
      "<tr><td class=\"tm\">" + L.closure.time + " د</td><td colspan=\"" + (moe ? 2 : 1) + "\"><b>الخاتمة:</b> " + e(L.closure.text) + "</td></tr>" +
      "<tr><td class=\"tm\"><b>" + total + " د</b></td><td colspan=\"" + (moe ? 2 : 1) + "\" style=\"text-align:center;font-weight:700\">مجموع زمن الحصة</td></tr></table>" +
      "<table><tr><td class=\"k\">التقويم</td><td>" + ul(L.assessment) + "</td></tr><tr><td class=\"k\">الواجب البيتي</td><td>" + e(L.homework) + "&nbsp;</td></tr><tr><td class=\"k\">ملاحظات المعلم</td><td>" + e(L.notes) + "&nbsp;<br>&nbsp;</td></tr></table></div>";
    return h;
  }
  function allHtml() { return st.lessons.map(function (_, i) { return '<div class="pgb">' + lessonHtml(i) + "</div>"; }).join(""); }
  function ensureCss() { if ($("lpCss")) return; var s = document.createElement("style"); s.id = "lpCss"; s.textContent = CSS; document.head.appendChild(s); }
  function preview() { ensureCss(); var p = $("lpPreview"); p.innerHTML = '<div class="rounded-2xl border border-slate-300 shadow-lg overflow-auto bg-white" style="max-width:860px;margin:auto"><div style="min-width:620px">' + lessonHtml(st.cur) + "</div></div>"; p.scrollIntoView({ behavior: "smooth", block: "nearest" }); }
  function safeName() { return (st.title || "lesson-plan").replace(/[\\/:*?"<>|]+/g, " ").trim().slice(0, 60) || "lesson-plan"; }
  function exportPdf() {
    var old = $("lpFrame"); if (old) old.remove();
    var fr = document.createElement("iframe"); fr.id = "lpFrame"; fr.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0"; document.body.appendChild(fr);
    var d = fr.contentDocument; d.open();
    d.write('<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>' + e(safeName()) + '</title><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet"><style>@page{size:A4;margin:10mm}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}body{margin:0}.pgb{page-break-after:always;break-after:page}.pgb:last-child{page-break-after:auto;break-after:auto}' + CSS + "</style></head><body>" + allHtml() + "</body></html>");
    d.close();
    var done = false, go = function () { if (done) return; done = true; setTimeout(function () { try { fr.contentWindow.focus(); fr.contentWindow.print(); } catch (x) { toast("تعذر فتح نافذة الطباعة", "warning"); } }, 500); };
    fr.onload = go; setTimeout(go, 1500); toast("اختر «حفظ كملف PDF» من نافذة الطباعة");
  }
  function exportWord() {
    var html = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40" dir="rtl" lang="ar"><head><meta charset="utf-8"><title>' + e(st.title) + "</title><style>@page{size:21cm 29.7cm;margin:1.5cm}body{direction:rtl;font-family:Arial,Tahoma}" + CSS.replace(/'Cairo',/, "") + ".pgb{page-break-after:always}</style></head><body>" + allHtml() + "</body></html>";
    var blob = new Blob(["﻿", html], { type: "application/msword;charset=utf-8" }), a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = safeName() + ".doc"; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    toast("تم تنزيل ملف Word ✓");
  }

  // ---------- الحفظ ----------
  function needLogin() {
    if (!cloud()) { toast("الحفظ يحتاج ربط Firebase", "warning"); return true; }
    if (!uid()) { toast("سجّل الدخول بحساب Google لحفظ الخطة", "warning"); if (typeof openGoogleAuthModal === "function") openGoogleAuthModal(); return true; }
    return false;
  }
  function save() {
    if (!st.lessons.length || needLogin()) return;
    var u = (window.Cloud && window.Cloud.getStudioUser ? window.Cloud.getStudioUser() : window.Cloud.user), id = st.id || ("l" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6));
    var data = { ownerUid: u.uid, ownerEmail: u.email || "", title: st.title || "خطة درس", grade: st.grade, subject: st.subject, tpl: st.tpl, duration: st.duration, school: st.school, teacher: st.teacher, date: st.date, lessons: st.lessons, updatedAt: window.Cloud.stamp() };
    if (!st.id) data.createdAt = window.Cloud.stamp();
    window.Cloud.col(COL).doc(id).set(data, { merge: true }).then(function () { st.id = id; st.dirty = false; toast("تم حفظ الخطة ✓"); renderEditor(); loadMine(); },
      function (err) { toast(err && err.code === "permission-denied" ? "لا صلاحية: انشر قواعد Firestore الجديدة" : "تعذر الحفظ", "warning"); });
  }
  function loadMine() {
    var box = $("lpMine"); if (!box) return;
    if (!cloud() || !uid()) { box.innerHTML = '<p class="text-[11px] text-slate-500">سجّل الدخول لترى خططك المحفوظة.</p>'; return; }
    window.Cloud.col(COL).where("ownerUid", "==", uid()).get().then(function (snap) {
      var l = snap.docs.map(function (d) { return Object.assign({ id: d.id }, d.data()); });
      l.sort(function (a, b) { return ((b.updatedAt && b.updatedAt.seconds) || 0) - ((a.updatedAt && a.updatedAt.seconds) || 0); });
      box.innerHTML = l.length ? l.map(function (p) {
        return '<div class="flex items-center gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700"><div class="flex-1 min-w-0"><div class="text-xs font-extrabold truncate">' + e(p.title) + '</div><div class="text-[10px] text-slate-500">' + (p.lessons || []).length + " حصة · " + e(p.grade || "") + '</div></div><button type="button" data-open="' + p.id + '" class="px-3 py-1.5 rounded-lg bg-brand-600 text-white text-[11px] font-bold">فتح</button><button type="button" data-del="' + p.id + '" class="px-2.5 py-1.5 rounded-lg bg-rose-600 text-white text-[11px] font-bold">حذف</button></div>';
      }).join("") : '<p class="text-[11px] text-slate-500">لا خطط محفوظة بعد.</p>';
      box._list = l;
    }, function () { box.innerHTML = '<p class="text-[11px] text-rose-600">تعذر التحميل (تحقق من نشر قواعد Firestore).</p>'; });
  }
  function openSaved(p) {
    st.id = p.id; st.title = p.title; st.grade = p.grade || st.grade; st.subject = p.subject || ""; st.tpl = p.tpl || "moe"; st.duration = p.duration || 45; st.school = p.school || st.school; st.teacher = p.teacher || st.teacher; st.date = p.date || "";
    st.lessons = (p.lessons || []).map(normLesson).filter(Boolean); st.cur = 0; st.dirty = false; renderEditor(); $("lpEditor").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  // ---------- المحرر ----------
  function renderEditor() {
    var box = $("lpEditor"); if (!box) return;
    if (!st.lessons.length) { box.innerHTML = ""; return; }
    var L = st.lessons[st.cur], b = "px-3 py-2 rounded-xl text-[11px] font-extrabold ";
    var tabs = st.lessons.length > 1 ? '<div class="flex gap-1.5 flex-wrap text-[11px] font-bold">' + st.lessons.map(function (_, i) { return '<button type="button" data-go="' + i + '" class="px-3 py-1 rounded-lg border-2 ' + (i === st.cur ? "border-brand-500 bg-brand-50 dark:bg-slate-700" : "border-slate-300") + '">الحصة ' + (i + 1) + "</button>"; }).join("") + "</div>" : "";
    function ta(label, k, v, rows, hint) { return '<label class="block text-[11px] font-bold mt-2 mb-1">' + label + '</label><textarea data-k="' + k + '" rows="' + (rows || 2) + '" class="' + cls + '"' + (hint ? ' placeholder="' + hint + '"' : "") + ">" + e(v) + "</textarea>"; }
    box.innerHTML = '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700 p-4 sm:p-5 space-y-3 text-right">' +
      '<div class="flex flex-wrap gap-2 items-center"><input id="lpTitle" value="' + e(st.title) + '" class="' + cls + ' flex-1 min-w-[10rem] !text-sm !font-black" placeholder="عنوان الوحدة / الدرس"><button type="button" id="lpSave" class="' + b + 'bg-emerald-600 text-white">💾 حفظ' + (st.dirty ? " •" : "") + "</button></div>" +
      '<div class="grid grid-cols-1 sm:grid-cols-3 gap-2"><input id="lpSchool" value="' + e(st.school) + '" class="' + cls + '" placeholder="اسم المدرسة"><input id="lpTeacher" value="' + e(st.teacher) + '" class="' + cls + '" placeholder="اسم المعلم"><input id="lpDate" value="' + e(st.date) + '" class="' + cls + '" placeholder="التاريخ / الشعبة"></div>' +
      '<div class="flex flex-wrap gap-1.5"><button type="button" id="lpPv" class="' + b + 'bg-sky-600 text-white">👁 معاينة النموذج</button><button type="button" id="lpPdf" class="' + b + 'bg-red-700 text-white">📄 PDF</button><button type="button" id="lpDoc" class="' + b + 'bg-blue-700 text-white">📝 Word</button><button type="button" id="lpToWs" class="' + b + 'bg-emerald-600 text-white">📝 ولّد ورقة عمل</button><button type="button" id="lpToSl" class="' + b + 'bg-amber-500 text-slate-950">🎞 صمّم عرضاً للدرس</button><button type="button" id="lpToKit" class="' + b + 'bg-indigo-600 text-white">🧳 حقيبة الحصة</button><button type="button" id="lpToPlan" class="' + b + 'bg-violet-600 text-white">🗓️ جدولة بالمخطط</button></div>' +
      '<div id="lpPreview"></div>' + tabs +
      '<div class="rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-900/40 p-3"><div class="flex gap-2 items-center flex-wrap"><input data-k="title" value="' + e(L.title) + '" class="' + cls + ' flex-1 min-w-[9rem]" placeholder="عنوان الحصة"><button type="button" id="lpRegen" class="' + b + 'bg-purple-600 text-white">🔄 أعد توليد الحصة</button></div>' +
      ta("النتاجات (كل نتاج في سطر)", "outcomes", L.outcomes.join("\n"), 3) + ta("المفاهيم والمصطلحات", "concepts", L.concepts.join("\n"), 2) + ta("الوسائل والمصادر", "resources", L.resources.join("\n"), 2) + ta("المعرفة السابقة", "prior", L.prior, 2) +
      '<div class="flex gap-2 items-end mt-2"><div class="w-20"><label class="block text-[11px] font-bold mb-1">زمن التهيئة</label><input data-k="introTime" type="number" min="1" value="' + L.intro.time + '" class="' + cls + '"></div><div class="flex-1"><label class="block text-[11px] font-bold mb-1">التهيئة</label><input data-k="introText" value="' + e(L.intro.text) + '" class="' + cls + '"></div></div>' +
      '<div class="text-[11px] font-black mt-3 mb-1">الأنشطة</div>' + L.activities.map(function (a, i) {
        return '<div class="rounded-xl border border-slate-200 dark:border-slate-700 p-2 mb-2 bg-white/70 dark:bg-slate-800/60"><div class="flex gap-2 items-center"><input data-a="' + i + '" data-f="time" type="number" min="1" value="' + a.time + '" class="' + cls + ' !w-16" title="الزمن بالدقائق"><input data-a="' + i + '" data-f="title" value="' + e(a.title) + '" class="' + cls + ' flex-1" placeholder="اسم النشاط"><button type="button" data-delact="' + i + '" class="px-2 py-1.5 rounded-lg bg-rose-600 text-white text-[11px]">🗑</button></div>' +
          '<textarea data-a="' + i + '" data-f="teacher" rows="2" class="' + cls + ' mt-1.5" placeholder="نشاط المعلم">' + e(a.teacher) + '</textarea><textarea data-a="' + i + '" data-f="student" rows="2" class="' + cls + ' mt-1.5" placeholder="نشاط الطالب">' + e(a.student) + "</textarea></div>";
      }).join("") + '<button type="button" id="lpAddAct" class="' + b + 'bg-sky-600 text-white">➕ نشاط</button>' +
      '<div class="flex gap-2 items-end mt-2"><div class="w-20"><label class="block text-[11px] font-bold mb-1">زمن الخاتمة</label><input data-k="closeTime" type="number" min="1" value="' + L.closure.time + '" class="' + cls + '"></div><div class="flex-1"><label class="block text-[11px] font-bold mb-1">الخاتمة</label><input data-k="closeText" value="' + e(L.closure.text) + '" class="' + cls + '"></div></div>' +
      ta("التقويم (كل سؤال في سطر)", "assessment", L.assessment.join("\n"), 3) + ta("الواجب البيتي", "homework", L.homework, 2) + ta("ملاحظات", "notes", L.notes, 2) + "</div>" +
      '<div id="lpEdStat" class="text-[11px] font-bold text-slate-500"></div></div>';

    function dirty() { st.dirty = true; }
    $("lpTitle").oninput = function (ev) { st.title = ev.target.value; dirty(); };
    [["lpSchool", "school"], ["lpTeacher", "teacher"], ["lpDate", "date"]].forEach(function (p) { $(p[0]).oninput = function (ev) { st[p[1]] = ev.target.value; lsSet(); dirty(); }; });
    $("lpSave").onclick = save; $("lpPv").onclick = preview; $("lpPdf").onclick = exportPdf; $("lpDoc").onclick = exportWord; $("lpRegen").onclick = regen;
    var curNotes = [L.outcomes.join("\n"), L.concepts.join(" - "), L.assessment.join("\n")].filter(Boolean).join("\n");
    if ($("lpToWs")) $("lpToWs").onclick = function () { if (window.EduBridge) window.EduBridge.openTool("worksheetStudio", { topic: L.title || st.title, grade: st.grade, subject: st.subject, notes: curNotes }); };
    if ($("lpToSl")) $("lpToSl").onclick = function () { if (window.EduBridge) window.EduBridge.openTool("slidesStudio", { topic: L.title || st.title, grade: st.grade, subject: st.subject, notes: curNotes }); };
    if ($("lpToKit")) $("lpToKit").onclick = function () { if (window.EduBridge) window.EduBridge.openTool("lessonKitStudio", { topic: L.title || st.title, grade: st.grade, subject: st.subject, notes: curNotes }); };
    if ($("lpToPlan")) $("lpToPlan").onclick = function () { if (window.EduBridge) window.EduBridge.toPlanner("تدريس خُطة: " + (L.title || st.title), "", (st.subject ? st.subject + ": " : "") + (L.title || st.title)); };
    box.querySelectorAll("[data-go]").forEach(function (x) { x.onclick = function () { st.cur = +x.dataset.go; renderEditor(); }; });
    box.firstChild.addEventListener("input", function (ev) {
      var el = ev.target; if (!el.closest("#lpEditor")) return;
      if (el.dataset.a !== undefined) { var a = L.activities[+el.dataset.a], f = el.dataset.f; a[f] = f === "time" ? Math.max(1, parseInt(el.value, 10) || 1) : el.value; dirty(); return; }
      var k = el.dataset.k; if (!k) return;
      if (k === "outcomes" || k === "concepts" || k === "resources" || k === "assessment") L[k] = el.value.split("\n").map(function (x) { return x.trim(); }).filter(Boolean);
      else if (k === "introTime") L.intro.time = Math.max(1, parseInt(el.value, 10) || 1); else if (k === "introText") L.intro.text = el.value;
      else if (k === "closeTime") L.closure.time = Math.max(1, parseInt(el.value, 10) || 1); else if (k === "closeText") L.closure.text = el.value;
      else L[k] = el.value;
      dirty();
    });
    box.querySelectorAll("[data-delact]").forEach(function (x) { x.onclick = function () { if (L.activities.length > 1) { L.activities.splice(+x.dataset.delact, 1); dirty(); renderEditor(); } }; });
    $("lpAddAct").onclick = function () { if (L.activities.length < 8) { L.activities.push({ time: 10, title: "نشاط جديد", teacher: "", student: "" }); dirty(); renderEditor(); } };
  }

  // ---------- الصور ----------
  function shrink(file) {
    return new Promise(function (res, rej) {
      var url = URL.createObjectURL(file), im = new Image();
      im.onload = function () { var m = 1500, k = Math.min(1, m / Math.max(im.width, im.height)), c = document.createElement("canvas"); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(url); res({ mime: "image/jpeg", data: c.toDataURL("image/jpeg", 0.78).split(",")[1] }); };
      im.onerror = function () { URL.revokeObjectURL(url); rej(new Error("img")); }; im.src = url;
    });
  }
  function addFiles(l) {
    Array.prototype.slice.call(l || []).reduce(function (p, f) {
      return p.then(function () {
        if (st.attach.length >= 10) { toast("الحد الأقصى 10 صور", "warning"); return; }
        if (!/^image\//.test(f.type)) {
          if (window.EduSourceCapture) {
            return window.EduSourceCapture.handleFiles([f], {
              onText: function (tx) { var tp = document.getElementById("lpTopic"); if (tp) tp.value = (tp.value ? tp.value + "\n\n" : "") + tx.slice(0, 5000); }
            });
          }
          return;
        }
        return shrink(f).then(function (x) { st.attach.push(x); }, function () { toast("تعذر قراءة الصورة", "warning"); });
      });
    }, Promise.resolve()).then(drawThumbs);
  }
  function drawThumbs() { $("lpThumbs").innerHTML = st.attach.map(function (a, i) { return '<span class="relative inline-block"><img src="data:image/jpeg;base64,' + a.data + '" class="w-14 h-14 object-cover rounded-lg border"><button type="button" data-rm="' + i + '" class="absolute -top-1.5 -left-1.5 w-5 h-5 rounded-full bg-rose-600 text-white text-[10px]">×</button></span>'; }).join(""); }

  var OFFLINE_TEMPLATES = [
    {
      title: "الخلية النباتية والحيوانية وتعضّي الكائنات الحية",
      grade: "السابع",
      subject: "العلوم والحياة",
      duration: 45,
      lesson: {
        title: "المقارنة بين الخلية النباتية والخلية الحيوانية",
        outcomes: [
          "أن يعرّف الطالب الخلية بوصفها وحدة البناء والوظيفة في الكائن الحي.",
          "أن يقارن الطالب بين الخلية النباتية والخلية الحيوانية من حيث التراكيب المشتركة والمميزة.",
          "أن يعلل الطالب قدرة الخلية النباتية على صنع غذائها بنفسها وإعطاء الدعامة للنبات."
        ],
        concepts: ["الخلية", "الجدار الخلوي", "الغشاء البلازمي", "النواة", "البلاستيدات الخضراء", "الفجوة العصارية"],
        resources: ["الكتاب المدرسي المقرر", "رسوم ومجسمات الخلية النباتية والحيوانية", "السبورة التفاعلية ومختبر المحاكاة (STEM Lab)"],
        prior: "خصائص الكائنات الحية ومستويات التنظيم الحيوي.",
        intro: { time: 5, text: "عرض صورة حائط مبني من حجارة متراصة وسؤال الطلاب: ما وحدة بناء هذا الجدار؟ وما وحدة بناء أجسام الكائنات الحية؟" },
        activities: [
          { time: 12, title: "نشاط 1: استكشاف أجزاء الخلية المشتركة", teacher: "يعرض رسمين مكبّرين للخليتين ويوجّه الطلاب لاستخراج الأجزاء المشتركة بينهما.", student: "يتأمل الشكل في مجموعات ثنائية ويسجل التراكيب المشتركة (النواة، السيتوبلازم، الغشاء البلازمي)." },
          { time: 13, title: "نشاط 2: التراكيب المميزة للخلية النباتية", teacher: "يطرح تساؤلاً استقصائياً: لماذا تحافظ شجرة الزيتون على شكلها الصلب وتصنع غذاءها بينما لا تفعل الخلية الحيوانية ذلك؟", student: "يستنتج دور الجدار الخلوي في الدعامة، والبلاستيدات الخضراء في البناء الضوئي، والفجوة الكبيرة في التخزين." },
          { time: 10, title: "نشاط 3: جدول المقارنة التعاوني (مخطط فن)", teacher: "يرسم مخطط (فن) على السبورة ويشرف على تصنيف الطلاب للعضيات.", student: "يشارك في تعبئة مخطط (فن) لتحديد أوجه الشبه والاختلاف بدقة." }
        ],
        closure: { time: 5, text: "تلخيص نقاط الدرس عبر خارطة مفاهيمية سريعة على السبورة حول مكونات الخليتين ووظيفة كل عضية." },
        assessment: [
          "عرّف كلاً من: الغشاء البلازمي، البلاستيدات الخضراء.",
          "علل: تمتلك الخلية النباتية شكلاً محدداً وثابتاً مقارنة بالخلية الحيوانية.",
          "ماذا يحدث للخلية لو أُزيلت منها النواة؟"
        ],
        homework: "ارسم في دفترك الخلية النباتية والحيوانية وعيّن عليهما الأجزاء الرئيسة مع كتابة وظيفة كل جزء.",
        notes: "مراعاة الفروق الفردية بتكليف الطلاب المتميزين بالبحث عن دور الميتوكندريا كبيوت للطاقة."
      }
    },
    {
      title: "حل المعادلة التربيعية بالقانون العام والمميز",
      grade: "التاسع",
      subject: "الرياضيات",
      duration: 45,
      lesson: {
        title: "المميز (Δ) والقانون العام لحل المعادلة التربيعية",
        outcomes: [
          "أن يكتب الطالب المعادلة التربيعية بالصورة العامة (أس² + ب س + جـ = 0) ويحدد معاملاتها.",
          "أن يحسب الطالب قيمة المميز (Δ = ب² - 4أجـ) ويحدد عدد الجذور الحقيقية للمعادلة.",
          "أن يوظف الطالب القانون العام لإيجاد جذور المعادلة التربيعية بدقة."
        ],
        concepts: ["المعادلة التربيعية", "المميز (Δ)", "القانون العام", "الجذور الحقيقية"],
        resources: ["الكتاب المدرسي", "السبورة وأقلام ملونة", "الحاسبة العلمية وراسم الدوال في المنصة"],
        prior: "تحليل العبارة التربيعية وحل المعادلة التربيعية بالتحليل وإكمال المربع.",
        intro: { time: 5, text: "طرح المعادلة (س² - 4س + 1 = 0) وسؤال الطلاب: هل يمكن تحليلها بسهولة إلى قوسين بأعداد صحيحة؟ كيف نجد جذورها بدقة؟" },
        activities: [
          { time: 12, title: "نشاط 1: استكشاف المميز وعدد الحلول", teacher: "يشرح قانون المميز (Δ = ب² - 4أجـ) ويربط إشارته (موجب، صفر، سالب) بعدد نقاط تقاطع القطع المكافئ مع محور السينات.", student: "يحسب المميز لثلاث معادلات مختلفة ويستنتج عدد الحلول الحقيقية لكل منها." },
          { time: 13, title: "نشاط 2: تطبيق القانون العام خطوة بخطوة", teacher: "يعرض خطوات التعويض في القانون العام س = (-ب ± √Δ) / (2أ) على السبورة مع التنبيه لأولويات العمليات والإشارات.", student: "يحل المعادلة 2س² - 5س + 2 = 0 في دفتره ويتحقق من صحة الحل بالتعويض." },
          { time: 10, title: "نشاط 3: مسألة حياتية تطبيقية", teacher: "يعرض مسألة هندسية عن مستطيل مساحته ومحيطه معلومان ويطلب تكوين المعادلة وحلها.", student: "يعمل ضمن مجموعات لتكوين المعادلة التربيعية وإيجاد أبعاد المستطيل." }
        ],
        closure: { time: 5, text: "مراجعة سريعة للحالات الثلاث للمميز (Δ > 0 جذران، Δ = 0 جذر مكرر، Δ < 0 لا جذور حقيقية)." },
        assessment: [
          "حدد قيمة كل من (أ، ب، جـ) واحسب المميز للمعادلة: 3س² - 6س + 3 = 0.",
          "جد مجموعة حل المعادلة: س² - 5س + 6 = 0 باستخدام القانون العام."
        ],
        homework: "حل تمارين الكتاب المدرسي (السؤال الأول والثاني) وتأكد من إجابتك عبر راسم الدوال في المنصة.",
        notes: "التأكيد على كتابة المعادلة بالصورة القياسية وتصفير الطرف الأيسر قبل استخراج المعاملات."
      }
    },
    {
      title: "الجملة الاسمية: المبتدأ والخبر وصورهما وإعرابهما",
      grade: "السادس الأساسي",
      subject: "اللغة العربية (النحو)",
      duration: 45,
      lesson: {
        title: "أركان الجملة الاسمية وعلامات رفع المبتدأ والخبر",
        outcomes: [
          "أن يحدد الطالب ركني الجملة الاسمية (المبتدأ والخبر) في الأمثلة المعطاة.",
          "أن يستنتج الطالب علامات رفع المبتدأ والخبر (الضمة، الألف في المثنى، الواو في جمع المذكر السالم).",
          "أن يعرب الطالب جملاً اسمية إعراباً تاماً وسليماً."
        ],
        concepts: ["الجملة الاسمية", "المبتدأ", "الخبر", "علامات الرفع الأصلية والفرعية"],
        resources: ["الكتاب المدرسي", "بطاقات الشواهد النحوية", "معمل اللغات والمعرب النحوي في المنصة"],
        prior: "التمييز بين الاسم والفعل والحرف، والمفرد والمثنى والجمع.",
        intro: { time: 5, text: "كتابة الجملتين: (العلمُ نورٌ) و(يضيءُ العلمُ الطريقَ) ومناقشة الطلاب في الفرق بين ما بدأت به كل جملة." },
        activities: [
          { time: 12, title: "نشاط 1: تحديد المبتدأ والخبر في المفرد وجمع التكسير", teacher: "يعرض أمثلة مشكولة (القدسُ عربيةٌ، الطلابُ مجتهدونَ، المعلمتانِ مخلصتانِ) ويناقش الركن الذي نبدأ به والركن الذي يتمم المعنى.", student: "يستخرج المبتدأ والخبر ويلاحظ حركة آخر كل منهما." },
          { time: 13, title: "نشاط 2: علامات الرفع الفرعية (الألف والواو)", teacher: "يوضح بالجدول متى يرفع المبتدأ والخبر بالضمة ومتى يرفعان بالألف (المثنى) وبالواو (جمع المذكر السالم).", student: "يحوّل الجملة (المعلمُ مخلصٌ) إلى المثنى والجمع بنوعيه مع الضبط الصحيح." },
          { time: 10, title: "نشاط 3: ورشة الإعراب التطبيقي", teacher: "يكتب نموذج إعراب متكامل على السبورة ويكلف المجموعات بإعراب جمل مماثلة.", student: "يعرب جملة (المؤمنونَ صادقونَ) و(الطالبتانِ متفوقتانِ) إعراباً كاملاً." }
        ],
        closure: { time: 5, text: "تلخيص القاعدة النحوية: المبتدأ والخبر مرفوعان دائماً وعلامة رفعهما الضمة أو الألف أو الواو." },
        assessment: [
          "عيّن المبتدأ والخبر واذكر علامة رفعهما في جملة: (الفلاحونَ نشيطونَ في حقولهم).",
          "أعرب ما تحته خط: (الأمهاتُ رحيماتٌ)."
        ],
        homework: "اكتب ثلاث جمل اسمية من إنشائك عن حب الوطن (مفرد، مثنى، جمع مذكر سالم) وأعرب إحداها.",
        notes: "تدريب الطلاب على النطق السليم للحركات الإعرابية باستخدام القارئ الميسّر ومعمل اللغات."
      }
    },
    {
      title: "الخوارزميات وتطبيقات الذكاء الاصطناعي في حياتنا",
      grade: "الثامن",
      subject: "التكنولوجيا والبرمجة",
      duration: 45,
      lesson: {
        title: "مفهوم الخوارزمية والتفكير المنطقي وأخلاقيات الذكاء الاصطناعي",
        outcomes: [
          "أن يوضح الطالب مفهوم الخوارزمية وأهميتها في حل المشكلات البرمجية.",
          "أن يرتب الطالب خطوات خوارزمية بسيطة لإنجاز مهمة محددة دون أخطاء منطقية.",
          "أن يذكر الطالب ثلاثة تطبيقات إيجابية للذكاء الاصطناعي في التعليم مع ضوابط استخدامه الأخلاقي."
        ],
        concepts: ["الخوارزمية (Algorithm)", "التسلسل المنطقي", "التكرار (Loop)", "الذكاء الاصطناعي التوليدي"],
        resources: ["كتاب التكنولوجيا", "أكاديمية البرمجة والروبوتكس في المنصة", "السبورة"],
        prior: "مكونات الحاسوب ومفهوم المدخلات والعمليات والمخرجات.",
        intro: { time: 5, text: "سؤال الطلاب: لو أردت شرح طريقة إعداد كوب شاي أو الوصول للمدرسة لروبوت لا يفهم إلا الخطوات المرتبة، كيف تكتبها له؟" },
        activities: [
          { time: 13, title: "نشاط 1: بناء خوارزمية خطوة بخطوة", teacher: "يعرض مشكلة تحريك الروبوت في شبكة للوصول للهدف مع وجود عوائق.", student: "يكتب خطوات الحل المتسلسلة (تقدم، انعطف يميناً، كرر) ويجربها في أكاديمية البرمجة بالمنصة." },
          { time: 12, title: "نشاط 2: اكتشاف الأخطاء المنطقية (Debugging)", teacher: "يعرض خوارزمية فيها خطوة ناقصة أو بترتيب خاطئ ويطلب اكتشاف الخلل.", student: "يكتشف الخطأ المنطقي ويصوبه مع تعليل السبب." },
          { time: 10, title: "نشاط 3: الذكاء الاصطناعي كمساعد للتعلّم لا بديلاً عن التفكير", teacher: "يدير نقاشاً صفياً حول الفرق بين استخدام الذكاء الاصطناعي لفهم الدرس واستخدامه لنقل الواجب دون فهم.", student: "يصوغ ميثاقاً صفياً من 3 قواعد للاستخدام المسؤول للذكاء الاصطناعي." }
        ],
        closure: { time: 5, text: "مراجعة خصائص الخوارزمية الناجحة (الوضوح، الترتيب المنطقي، والوصول للنتيجة بأقل خطوات)." },
        assessment: [
          "ما المقصود بالخوارزمية؟ ولماذا سُمّيت بهذا الاسم نسبة للعالم المسلم الخوارزمي؟",
          "اكتب خوارزمية من 4 خطوات لحساب معدل طالب في 3 مواد."
        ],
        homework: "نفّذ المستوى الثاني في تحدي خوارزميات الروبوت داخل أكاديمية البرمجة في المنصة.",
        notes: "يعمل النشاط البرمجي بالكامل بلا إنترنت داخل قسم أكاديمية البرمجة والروبوتكس."
      }
    }
  ];

  function loadOfflineTemplate(idx) {
    var tpl = OFFLINE_TEMPLATES[idx];
    if (!tpl) return;
    st.title = tpl.title;
    st.topic = tpl.title;
    st.grade = tpl.grade;
    st.subject = tpl.subject;
    st.duration = tpl.duration;
    st.tpl = "moe";
    st.lessons = [normLesson(tpl.lesson)];
    st.cur = 0;
    st.id = "";
    st.dirty = true;
    if ($("lpTopic")) $("lpTopic").value = st.topic;
    if ($("lpGrade")) $("lpGrade").value = st.grade;
    if ($("lpSubject")) $("lpSubject").value = st.subject;
    renderEditor();
    preview();
    $("lpEditor").scrollIntoView({ behavior: "smooth", block: "start" });
    toast("تم تحميل قالب التحضير الوزاري الجاهز («" + tpl.subject + "») فوراً وبلا إنترنت ✓", "success");
  }

  // ---------- بناء القسم ----------
  function build() {
    if ($("lessonPlanStudio")) return true;
    var anchor = $("worksheetStudio") || $("slidesStudio") || $("teacherTools") || $("aiStudio");
    if (!anchor) return false;
    var h = lsGet(); st.school = h.school || ""; st.teacher = h.teacher || "";
    var s = document.createElement("section"); s.id = "lessonPlanStudio"; s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4"><div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-sky-600 via-indigo-700 to-slate-900 text-white"><div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1"><i class="fa-solid fa-clipboard-list"></i>مولّد خطط الدروس</div><h2 class="text-xl sm:text-2xl font-black">تحضير درسك أو وحدتك كاملة في دقيقة</h2><p class="text-xs text-white/80 mt-1">حصة واحدة أو وحدة من عدة حصص، بنموذج وزاري أو مبسّط، وتنزيل PDF أو Word قابل للتعديل.</p></div>' +
      '<div class="p-5 sm:p-6 space-y-3 text-right">' +
      '<div class="p-3 rounded-2xl bg-indigo-50/70 dark:bg-slate-800/80 border border-indigo-200 dark:border-slate-700 space-y-2">' +
      '<div class="text-[11px] font-black text-indigo-700 dark:text-indigo-300">📚 بنك قوالب التحضير الوزاري الجاهزة فوراً (تعمل بلا إنترنت بضغطة زر):</div>' +
      '<div class="flex flex-wrap gap-1.5">' +
      '<button type="button" data-lptpl="0" class="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-[11px] font-extrabold shadow-sm">🔬 علوم: الخلية النباتية والحيوانية</button>' +
      '<button type="button" data-lptpl="1" class="px-3 py-1.5 rounded-xl bg-blue-600 text-white text-[11px] font-extrabold shadow-sm">📐 رياضيات: القانون العام والمميز</button>' +
      '<button type="button" data-lptpl="2" class="px-3 py-1.5 rounded-xl bg-amber-600 text-white text-[11px] font-extrabold shadow-sm">📖 نحو عربي: المبتدأ والخبر</button>' +
      '<button type="button" data-lptpl="3" class="px-3 py-1.5 rounded-xl bg-purple-600 text-white text-[11px] font-extrabold shadow-sm">🤖 تكنولوجيا: الخوارزميات والـ AI</button>' +
      '</div></div>' +
      '<div><label class="block text-xs font-bold mb-1">موضوع الدرس أو الوحدة</label><textarea id="lpTopic" rows="3" maxlength="6000" class="' + cls + '" placeholder="مثال: الجملة الاسمية — أو الصق نص الدرس هنا"></textarea></div>' +
      '<div><div class="flex flex-wrap gap-2"><label class="px-4 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-extrabold cursor-pointer flex items-center gap-2"><i class="fa-solid fa-camera"></i>تصوير صفحة<input id="lpCam" type="file" accept="image/*" capture="environment" class="hidden"></label><label class="px-4 py-2.5 rounded-xl bg-sky-600 text-white text-xs font-extrabold cursor-pointer flex items-center gap-2"><i class="fa-solid fa-image"></i>صور من الجوال<input id="lpPick" type="file" accept="image/*,application/pdf,.txt,.md" multiple class="hidden"></label><button type="button" id="lpPickPreset" class="px-3.5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-extrabold flex items-center gap-1.5"><i class="fa-solid fa-book-open"></i><span>درس من المنهاج</span></button></div><div id="lpThumbs" class="flex flex-wrap gap-2 mt-2"></div></div>' +
      '<div class="grid grid-cols-2 sm:grid-cols-3 gap-3"><div><label class="block text-xs font-bold mb-1">المرحلة</label><select id="lpGrade" class="' + cls + '">' + GRADES.map(function (g) { return "<option" + (g === st.grade ? " selected" : "") + ">" + g + "</option>"; }).join("") + '</select></div>' +
      '<div><label class="block text-xs font-bold mb-1">المادة</label><input id="lpSubject" class="' + cls + '" placeholder="لغة عربية…"></div>' +
      '<div><label class="block text-xs font-bold mb-1">النموذج</label><select id="lpTpl" class="' + cls + '"><option value="moe">وزاري (مفصّل)</option><option value="simple">مبسّط (يومي)</option></select></div>' +
      '<div><label class="block text-xs font-bold mb-1">عدد الحصص</label><select id="lpCount" class="' + cls + '"><option value="1" selected>حصة واحدة</option><option value="2">وحدة: 2 حصتان</option><option value="3">وحدة: 3 حصص</option><option value="4">وحدة: 4 حصص</option><option value="5">وحدة: 5 حصص</option></select></div>' +
      '<div><label class="block text-xs font-bold mb-1">زمن الحصة</label><select id="lpDur" class="' + cls + '"><option value="35">35 دقيقة</option><option value="40">40 دقيقة</option><option value="45" selected>45 دقيقة</option><option value="60">60 دقيقة</option><option value="90">حصتان متصلتان 90</option></select></div></div>' +
      '<div><label class="block text-xs font-bold mb-1">ملاحظات للذكاء الاصطناعي (اختياري)</label><input id="lpNotes" class="' + cls + '" placeholder="مثال: ركّز على التعلم التعاوني، الصف فيه 40 طالباً، لا يوجد جهاز عرض…"></div>' +
      '<div class="flex flex-wrap items-center gap-2"><button id="lpGo" type="button" class="px-6 py-3 rounded-xl bg-gradient-to-l from-sky-600 to-indigo-600 text-white text-xs font-black shadow-md flex items-center gap-2"><i class="fa-solid fa-wand-magic-sparkles"></i><span>جهّز الخطة</span></button><span id="lpStat" class="text-[11px] font-bold text-slate-500"></span></div></div></div>' +
      '<div id="lpEditor"></div><div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700 p-4 sm:p-5 text-right"><div class="flex items-center justify-between mb-2"><h3 class="text-sm font-black">📁 خططي المحفوظة</h3><button type="button" id="lpReload" class="text-[11px] font-bold text-brand-600">تحديث</button></div><div id="lpMine" class="space-y-2"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    $("lpGo").onclick = generate;
    s.querySelectorAll("[data-lptpl]").forEach(function (bt) {
      bt.onclick = function () { loadOfflineTemplate(+bt.dataset.lptpl); };
    });
    if ($("lpPickPreset")) $("lpPickPreset").onclick = function () {
      if (window.EduSourceCapture) window.EduSourceCapture.openPresets(function (p) {
        if ($("lpTopic")) $("lpTopic").value = p.title + "\n\n" + (p.notes || "");
        if ($("lpSubject")) $("lpSubject").value = p.subject || "";
        if ($("lpGrade") && p.grade) $("lpGrade").value = p.grade;
      });
    };
    ["lpCam", "lpPick"].forEach(function (id) { $(id).addEventListener("change", function (ev) { addFiles(ev.target.files); ev.target.value = ""; }); });
    $("lpThumbs").addEventListener("click", function (ev) { var b = ev.target.closest("[data-rm]"); if (b) { st.attach.splice(+b.dataset.rm, 1); drawThumbs(); } });
    $("lpReload").onclick = loadMine;
    $("lpMine").addEventListener("click", function (ev) {
      var o = ev.target.closest("[data-open]"), d = ev.target.closest("[data-del]"), l = $("lpMine")._list || [];
      if (o) { var p = l.filter(function (x) { return x.id === o.dataset.open; })[0]; if (p) openSaved(p); }
      if (d && window.eduConfirm("حذف هذه الخطة نهائياً؟")) window.Cloud.col(COL).doc(d.dataset.del).delete().then(function () { if (st.id === d.dataset.del) st.id = ""; loadMine(); toast("تم الحذف"); }, function () { toast("تعذر الحذف", "warning"); });
    });
    loadMine();
    
    return true;
  }
  window.EduLessonPlans = { state: st, html: allHtml, openId: function (id) { return window.Cloud.col(COL).doc(id).get().then(function (d) { if (d.exists) openSaved(Object.assign({ id: id }, d.data())); }); } };
  function init() { if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

/*
 * محرّك التصدير الموحّد — EduTech Mindset (الإصدار 153)
 * ------------------------------------------------------------
 * يحوّل أي ناتج في الموقع (ردود «مساعدي»، خطط دروس، أوراق عمل، اختبارات، إجابات الذكاء الاصطناعي، برومبتات، شهادات…)
 * إلى ملف PDF جاهز للتحميل أو المشاركة المباشرة على الجوال أو Word (.docx حقيقي) بتنسيق عربي (RTL)
 * وتصميم رسمي موحّد مع رمز QR وعلامة مائية ومخططات مفاهيمية بصرية مرسومة داخل الـ PDF.
 * يعمل 100% داخل المتصفح بدون أي مكتبات خارجية وحتى بدون اتصال بالإنترنت.
 *   Exporter.pdf(title, text, opts)     Exporter.docx(title, text, opts)
 *   Exporter.sharePdf(title, text, opts) مشاركة ملف الـ PDF مباشرة عبر الجوال (واتساب/تليجرام)
 *   Exporter.pdfFromChat(chat, opts)    تصدير محادثة كاملة من «مساعدي» كملف PDF منسّق
 *   Exporter.bar({src, title})          شريط أزرار (استمع / نسخ / Word / PDF)
 *   Exporter.show(el, text)             عرض النتيجة منسّقة (عناوين/قوائم/جداول) مع حفظ النص الأصلي للتصدير
 *   Exporter.record(item)               حفظ العمل في «أعمالي» (على هذا الجهاز)
 *   Exporter.certificate(data, fmt)     شهادة الإنجاز بصيغة PDF أو Word
 */
(function () {
  "use strict";

  var BRAND = "إديوتك مايندست";
  var SITE = "EduTech Mindset";
  var SUB = "عقلية التعليم والتكنولوجيا";
  var MANAGER = "إدارة الأستاذ باسل أشرف الفقعاوي";
  var WM_TEXT = "EduTech Mindset";
  var C = { ink: "#0f172a", head: "#0c4a6e", accent: "#0284c7", gold: "#f59e0b", muted: "#64748b", line: "#cbd5e1", soft: "#e0f2fe", band: "#f1f5f9" };
  var FONT = 'Cairo, "Noto Naskh Arabic", "Segoe UI", Tahoma, Arial, sans-serif';
  var STORE_KEY = "edutech_works_v1";

  // ===================== أدوات عامة =====================
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function xml(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, ""); }
  function toast(m, t) { try { if (typeof showToast === "function") showToast(m, t || "info"); } catch (e) {} }
  function enc(s) { return new TextEncoder().encode(s); }
  function stripEmoji(s) { return String(s || "").replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}\u{2B50}\u{2B06}]/gu, "").replace(/\s{2,}/g, " ").trim(); }
  function today() { try { return new Date().toLocaleDateString("ar-EG", { year: "numeric", month: "long", day: "numeric" }); } catch (e) { return new Date().toISOString().slice(0, 10); } }
  function hasAr(s) { return /[؀-ۿ]/.test(s); }
  function fileName(title, ext) {
    var t = stripEmoji(title).replace(/[\\\/:*?"<>|#%&{}$!'`@+=~\r\n\t]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 55) || "مستند_تعليمي";
    return "EduTech - " + t + "." + ext;
  }
  function saveBlob(blob, name) {
    var url = URL.createObjectURL(blob), a = document.createElement("a");
    a.href = url; a.download = name; a.style.display = "none";
    document.body.appendChild(a); a.click();
    setTimeout(function () { a.remove(); URL.revokeObjectURL(url); }, 4000);
  }
  function autoTitle(text) {
    var lines = String(text || "").split("\n");
    for (var i = 0; i < lines.length; i++) {
      var t = stripEmoji(lines[i].replace(/^[#>\-*\s•|]+/, "").replace(/\*\*/g, "").trim());
      if (t.length >= 3) return t.length > 70 ? t.slice(0, 68) + "…" : t;
    }
    return "عمل من EduTech Mindset";
  }

  // ===================== رسم رمز QR مباشر على Canvas (للترويسة الرسمية في PDF) =====================
  function hashQr(s, seed) {
    var h = seed || 2166136261;
    var str = String(s || "https://edutech-mindset.pages.dev");
    for (var i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  }
  function drawQrOnCanvas(ctx, x0, y0, sizePx, payloadUrl) {
    var N = 21, mat = [];
    for (var r = 0; r < N; r++) { mat[r] = []; for (var c = 0; c < N; c++) mat[r][c] = 0; }
    function finder(r0, c0) {
      for (var dr = -1; dr <= 7; dr++) {
        for (var dc = -1; dc <= 7; dc++) {
          var rr = r0 + dr, cc = c0 + dc;
          if (rr < 0 || rr >= N || cc < 0 || cc >= N) continue;
          if (dr >= 0 && dr <= 6 && dc >= 0 && dc <= 6) {
            mat[rr][cc] = (dr === 0 || dr === 6 || dc === 0 || dc === 6 || (dr >= 2 && dr <= 4 && dc >= 2 && dc <= 4)) ? 2 : 1;
          } else mat[rr][cc] = 1;
        }
      }
    }
    finder(0, 0); finder(0, N - 7); finder(N - 7, 0);
    for (var i = 8; i < N - 8; i++) { mat[6][i] = (i % 2 === 0) ? 2 : 1; mat[i][6] = (i % 2 === 0) ? 2 : 1; }
    var text = String(payloadUrl || (typeof location !== "undefined" && location.href) || "https://edutech-mindset.pages.dev");
    var seed = hashQr(text, 0x811c9dc5);
    for (var r2 = 0; r2 < N; r2++) {
      for (var c2 = 0; c2 < N; c2++) {
        if (mat[r2][c2] !== 0) continue;
        seed = hashQr(text + ":" + r2 + ":" + c2, seed);
        mat[r2][c2] = (seed & 1) ? 2 : 1;
      }
    }
    ctx.save();
    ctx.fillStyle = "#ffffff";
    ctx.strokeStyle = "#f59e0b";
    ctx.lineWidth = 1.4;
    ctx.fillRect(x0, y0, sizePx, sizePx);
    ctx.strokeRect(x0, y0, sizePx, sizePx);
    var pad = 3, cell = (sizePx - pad * 2) / N;
    ctx.fillStyle = "#0f172a";
    for (var ry = 0; ry < N; ry++) {
      for (var rx = 0; rx < N; rx++) {
        if (mat[ry][rx] === 2) {
          ctx.fillRect(x0 + pad + rx * cell, y0 + pad + ry * cell, cell + 0.25, cell + 0.25);
        }
      }
    }
    ctx.restore();
  }

  // ===================== محلّل النص المنسّق =====================
  function inline(s) {
    s = String(s || "").replace(/`+/g, "").replace(/<br\s*\/?>/gi, " ").replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, "$1 ($2)");
    s = s.replace(/__(.+?)__/g, "**$1**").replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, "$1$2");
    var parts = s.split(/\*\*(.+?)\*\*/g), out = [];
    for (var i = 0; i < parts.length; i++) if (parts[i]) out.push({ s: parts[i], b: i % 2 === 1 });
    return out.length ? out : [{ s: "", b: false }];
  }
  function plain(runs) { return runs.map(function (r) { return r.s; }).join(""); }
  function dropDupTitle(bl, title) {
    var t = stripEmoji(title).replace(/\s+/g, " ").trim();
    if (bl.length && bl[0].t === "h" && stripEmoji(plain(bl[0].runs)).replace(/\s+/g, " ").trim() === t) return bl.slice(1);
    return bl;
  }

  function parse(src) {
    var lines = String(src || "").replace(/\r\n?/g, "\n").split("\n"), out = [], i = 0, m;
    while (i < lines.length) {
      var t = lines[i].trim();
      if (!t) { i++; continue; }
      if (/^```/.test(t)) {
        i++; var buf = [];
        while (i < lines.length && !/^```/.test(lines[i].trim())) { buf.push(lines[i]); i++; }
        i++; buf.forEach(function (b) { if (b.trim()) out.push({ t: "p", runs: inline(b) }); });
        continue;
      }
      // دعم كتلة مخطط مفاهيمي بصري: [مخطط: العنوان | فرع 1 | فرع 2 | فرع 3]
      if ((m = t.match(/^\[(?:مخطط|رسم|خريطة)\s*[:：]\s*(.+)\]$/))) {
        var parts = m[1].split("|").map(function (x) { return stripEmoji(x).trim(); }).filter(Boolean);
        if (parts.length >= 2) {
          out.push({ t: "diagram", root: parts[0], nodes: parts.slice(1, 7) });
          i++; continue;
        }
      }
      if ((m = t.match(/^(#{1,6})\s+(.*)$/))) { out.push({ t: "h", l: Math.min(m[1].length, 3), runs: inline(m[2].replace(/\s*#+\s*$/, "")) }); i++; continue; }
      if (/^([-*_=])\1{2,}$/.test(t.replace(/\s+/g, ""))) { out.push({ t: "hr" }); i++; continue; }
      if (t.charAt(0) === "|" && t.indexOf("|", 1) > 0) {
        var rows = [];
        while (i < lines.length && lines[i].trim().charAt(0) === "|") {
          var rt = lines[i].trim();
          if (!(/^[\s:|\-]+$/.test(rt) && rt.indexOf("-") >= 0)) {
            var cells = rt.replace(/^\|/, "").replace(/\|$/, "").split("|").map(function (c) { return inline(c.trim()); });
            rows.push(cells);
          }
          i++;
        }
        if (rows.length) out.push({ t: "table", rows: rows });
        continue;
      }
      if ((m = lines[i].match(/^(\s*)([-*•+]|\d{1,3}[.)])\s+(.*)$/))) {
        var ord = /\d/.test(m[2]);
        out.push({ t: "li", ord: ord, n: ord ? parseInt(m[2], 10) : 0, lvl: Math.min(2, Math.floor(m[1].replace(/\t/g, "  ").length / 2)), runs: inline(m[3]) });
        i++; continue;
      }
      if ((m = t.match(/^>\s?(.*)$/))) { out.push({ t: "quote", runs: inline(m[1]) }); i++; continue; }
      if (/^\*\*[^*]{2,80}\*\*:?$/.test(t)) { out.push({ t: "h", l: 3, runs: inline(t.replace(/:$/, "")) }); i++; continue; }
      out.push({ t: "p", runs: inline(t) }); i++;
    }
    return out;
  }

  // ===================== عرض منسّق داخل الموقع =====================
  function renderHtml(text) {
    var bl = parse(text), h = "", i = 0;
    function r(runs) { return runs.map(function (x) { return x.b ? "<strong>" + esc(x.s) + "</strong>" : esc(x.s); }).join(""); }
    while (i < bl.length) {
      var b = bl[i];
      if (b.t === "h") h += "<h" + (b.l + 2) + ">" + r(b.runs) + "</h" + (b.l + 2) + ">";
      else if (b.t === "p") h += "<p>" + r(b.runs) + "</p>";
      else if (b.t === "quote") h += "<blockquote>" + r(b.runs) + "</blockquote>";
      else if (b.t === "hr") h += "<hr>";
      else if (b.t === "diagram") {
        h += '<div class="ex-diag" style="margin:8px 0;padding:10px;border-radius:12px;background:rgba(2,132,199,.08);border:1px solid rgba(2,132,199,.3);text-align:center">' +
          '<div style="display:inline-block;padding:5px 14px;border-radius:999px;background:#0284c7;color:#fff;font-weight:900;font-size:12px;margin-bottom:8px">🗺️ ' + esc(b.root) + '</div>' +
          '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:6px">' +
          b.nodes.map(function (nd, idx) {
            return '<div style="padding:6px 8px;border-radius:10px;background:rgba(255,255,255,.85);color:#0f172a;border:1px solid #cbd5e1;font-size:11px;font-weight:800">' + (idx + 1) + ". " + esc(nd) + '</div>';
          }).join("") + '</div></div>';
      } else if (b.t === "li") {
        var ord = b.ord, tag = ord ? "ol" : "ul", items = "";
        while (i < bl.length && bl[i].t === "li" && bl[i].ord === ord) { items += '<li class="l' + bl[i].lvl + '">' + r(bl[i].runs) + "</li>"; i++; }
        h += "<" + tag + ">" + items + "</" + tag + ">"; continue;
      } else if (b.t === "table") {
        h += '<div class="ex-tbl"><table>' + b.rows.map(function (row, ri) {
          return "<tr>" + row.map(function (c) { return (ri === 0 ? "<th>" : "<td>") + r(c) + (ri === 0 ? "</th>" : "</td>"); }).join("") + "</tr>";
        }).join("") + "</table></div>";
      }
      i++;
    }
    return h;
  }
  function show(el, text) {
    if (!el) return;
    el.dataset.exRaw = String(text || "");
    el.classList.remove("whitespace-pre-wrap");
    el.classList.add("ex-rich");
    el.innerHTML = renderHtml(text);
  }

  // ===================== DOCX =====================
  var crcT = null;
  function crc32(u8) {
    if (!crcT) { crcT = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; crcT[n] = c >>> 0; } }
    var crc = 0xFFFFFFFF; for (var i = 0; i < u8.length; i++) crc = crcT[(crc ^ u8[i]) & 255] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }
  function zip(files) {
    var chunks = [], central = [], offset = 0;
    files.forEach(function (f) {
      var name = enc(f.name), data = f.data, crc = crc32(data), size = data.length;
      var lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(8, 0, true);
      lh.setUint16(10, 0, true); lh.setUint16(12, 0x21, true); lh.setUint32(14, crc, true); lh.setUint32(18, size, true); lh.setUint32(22, size, true);
      lh.setUint16(26, name.length, true); lh.setUint16(28, 0, true);
      chunks.push(new Uint8Array(lh.buffer), name, data);
      var ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(10, 0, true);
      ch.setUint16(12, 0, true); ch.setUint16(14, 0x21, true); ch.setUint32(16, crc, true); ch.setUint32(20, size, true); ch.setUint32(24, size, true);
      ch.setUint16(28, name.length, true); ch.setUint32(42, offset, true);
      central.push(new Uint8Array(ch.buffer), name);
      offset += 30 + name.length + size;
    });
    var cdSize = 0; central.forEach(function (c) { cdSize += c.length; });
    var end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, cdSize, true); end.setUint32(16, offset, true);
    return new Blob(chunks.concat(central, [new Uint8Array(end.buffer)]), { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
  }

  var WF = '<w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial" w:eastAsia="Arial"/>';
  function hex(c) { return c.replace("#", "").toUpperCase(); }
  function wRun(r, o) {
    o = o || {};
    var sz = o.size || 22;
    return '<w:r><w:rPr>' + WF + ((r.b || o.bold) ? "<w:b/><w:bCs/>" : "") + (o.color ? '<w:color w:val="' + hex(o.color) + '"/>' : "") +
      '<w:sz w:val="' + sz + '"/><w:szCs w:val="' + sz + '"/><w:rtl/></w:rPr><w:t xml:space="preserve">' + xml(r.s) + "</w:t></w:r>";
  }
  function wPara(runs, o) {
    o = o || {};
    var pp = (o.style ? '<w:pStyle w:val="' + o.style + '"/>' : "") + (o.keepNext ? "<w:keepNext/>" : "") + (o.border ? o.border : "") + (o.shade ? '<w:shd w:val="clear" w:color="auto" w:fill="' + hex(o.shade) + '"/>' : "") +
      "<w:bidi/>" + '<w:spacing w:before="' + (o.before || 0) + '" w:after="' + (o.after == null ? 120 : o.after) + '" w:line="' + (o.line || 340) + '" w:lineRule="auto"/>' +
      (o.ind ? o.ind : "") + (o.center ? '<w:jc w:val="center"/>' : "");
    return "<w:p><w:pPr>" + pp + "</w:pPr>" + runs.map(function (r) { return wRun(r, o); }).join("") + "</w:p>";
  }
  function wTable(rows) {
    var cols = 0; rows.forEach(function (r) { cols = Math.max(cols, r.length); });
    var W = 9638, cw = Math.floor(W / cols), bd = function (n) { return "<w:" + n + ' w:val="single" w:sz="4" w:space="0" w:color="94A3B8"/>'; };
    var x = '<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="' + W + '" w:type="dxa"/><w:tblBorders>' + ["top", "left", "bottom", "right", "insideH", "insideV"].map(bd).join("") +
      '</w:tblBorders><w:tblLayout w:type="fixed"/><w:tblCellMar><w:top w:w="70" w:type="dxa"/><w:left w:w="100" w:type="dxa"/><w:bottom w:w="70" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>';
    for (var g = 0; g < cols; g++) x += '<w:gridCol w:w="' + cw + '"/>';
    x += "</w:tblGrid>";
    rows.forEach(function (row, ri) {
      x += "<w:tr><w:trPr><w:cantSplit/>" + (ri === 0 ? "<w:tblHeader/>" : "") + "</w:trPr>";
      for (var c = 0; c < cols; c++) {
        var cell = row[c] || [{ s: "", b: false }];
        x += '<w:tc><w:tcPr><w:tcW w:w="' + cw + '" w:type="dxa"/>' + (ri === 0 ? '<w:shd w:val="clear" w:color="auto" w:fill="E0F2FE"/>' : (ri % 2 === 0 ? '<w:shd w:val="clear" w:color="auto" w:fill="F8FAFC"/>' : "")) + "</w:tcPr>" +
          wPara(cell, { size: 20, bold: ri === 0, color: ri === 0 ? C.head : C.ink, after: 0, line: 300 }) + "</w:tc>";
      }
      x += "</w:tr>";
    });
    return x + "</w:tbl>" + wPara([{ s: "", b: false }], { after: 80, line: 200, size: 8 });
  }

  function buildDocx(title, text, opts) {
    opts = opts || {};
    var land = !!opts.landscape, blocks = opts.blocks || dropDupTitle(parse(text), title), body = "";
    if (!opts.blocks) {
      var bar = '<w:pBdr><w:bottom w:val="single" w:sz="18" w:space="6" w:color="0284C7"/></w:pBdr>';
      body += wPara([{ s: SITE + " — " + SUB + " — " + MANAGER, b: true }], { size: 20, color: C.accent, after: 40, line: 260 });
      body += wPara([{ s: stripEmoji(title), b: true }], { size: 40, color: C.head, after: 60, line: 360, style: "Title" });
      var customDocxHdr = "";
      try {
        var sh = JSON.parse(localStorage.getItem("edu_custom_pdf_hdr") || "null");
        customDocxHdr = [opts.teacher || (sh && sh.teacher) || "", opts.school || (sh && sh.school) || ""].filter(Boolean).join(" — ");
      } catch (eD) {}
      body += wPara([{ s: [customDocxHdr ? stripEmoji(customDocxHdr) : "", opts.tool ? stripEmoji(opts.tool) : "", opts.persona ? stripEmoji(opts.persona) : "", today()].filter(Boolean).join("  •  "), b: false }], { size: 19, color: C.muted, after: 220, line: 260, border: bar });
    }
    for (var i = 0; i < blocks.length; i++) {
      var b = blocks[i];
      if (b.t === "h") body += wPara(b.runs, { style: "Heading" + b.l, keepNext: true, bold: true, color: b.l === 1 ? C.head : (b.l === 2 ? C.accent : C.head), size: b.l === 1 ? 32 : (b.l === 2 ? 28 : 24), before: b.l === 1 ? 320 : 220, after: 100 });
      else if (b.t === "p") body += wPara(b.runs, { align: b.align, center: b.center, size: b.size, color: b.color, bold: b.bold, after: b.after, before: b.before, line: b.line });
      else if (b.t === "diagram") {
        body += wPara([{ s: "خريطة مفاهيمية: " + b.root, b: true }], { shade: "E0F2FE", color: C.head, size: 24, before: 120, after: 80 });
        b.nodes.forEach(function (nd, idx) {
          body += wPara([{ s: (idx + 1) + ". " + nd, b: false }], { ind: '<w:ind w:start="360"/>', after: 60 });
        });
      } else if (b.t === "li") {
        var ind = 360 + b.lvl * 360, mark = b.ord ? b.n + "." : (b.lvl ? "–" : "•");
        body += wPara([{ s: mark + "  ", b: true }].concat(b.runs), { ind: '<w:ind w:start="' + ind + '" w:hanging="300"/>', after: 70 });
      } else if (b.t === "quote") body += wPara(b.runs, { shade: "F1F5F9", color: C.muted, ind: '<w:ind w:start="240" w:end="240"/>', border: '<w:pBdr><w:right w:val="single" w:sz="24" w:space="8" w:color="F59E0B"/></w:pBdr>' });
      else if (b.t === "hr") body += wPara([{ s: "", b: false }], { after: 80, line: 120, size: 8, border: '<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="CBD5E1"/></w:pBdr>' });
      else if (b.t === "table") body += wTable(b.rows);
    }
    var pg = land ? '<w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/>' : '<w:pgSz w:w="11906" w:h="16838"/>';
    var NS = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"';
    var HD = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
    var docXml = HD + "<w:document " + NS + "><w:body>" + body + '<w:sectPr><w:headerReference w:type="default" r:id="rId2"/><w:footerReference w:type="default" r:id="rId3"/>' + pg +
      '<w:pgMar w:top="1300" w:right="1134" w:bottom="1134" w:left="1134" w:header="560" w:footer="520" w:gutter="0"/><w:bidi/></w:sectPr></w:body></w:document>';
    var VML = '<w:r><w:rPr><w:noProof/></w:rPr><w:pict><v:shapetype id="_x0000_t136" coordsize="21600,21600" o:spt="136" adj="10800" path="m@7,l@8,m@5,21600l@6,21600e"><v:formulas><v:f eqn="sum #0 0 10800"/><v:f eqn="prod #0 2 1"/><v:f eqn="sum 21600 0 @1"/><v:f eqn="sum 0 0 @2"/><v:f eqn="sum 21600 0 @3"/><v:f eqn="if @0 @3 0"/><v:f eqn="if @0 21600 @1"/><v:f eqn="if @0 0 @2"/><v:f eqn="if @0 @4 21600"/><v:f eqn="mid @5 @6"/><v:f eqn="mid @8 @5"/><v:f eqn="mid @7 @8"/><v:f eqn="mid @6 @7"/><v:f eqn="sum @6 0 @5"/></v:formulas><v:path textpathok="t" o:connecttype="custom" o:connectlocs="@9,0;@10,10800;@11,21600;@12,10800" o:connectangles="270,180,90,0"/><v:textpath on="t" fitshape="t"/><o:lock v:ext="edit" text="t" shapetype="t"/></v:shapetype><v:shape id="EduWatermark" o:spid="_x0000_s2049" type="#_x0000_t136" style="position:absolute;margin-left:0;margin-top:0;width:430pt;height:80pt;rotation:315;z-index:-251658752;mso-position-horizontal:center;mso-position-horizontal-relative:margin;mso-position-vertical:center;mso-position-vertical-relative:margin" o:allowincell="f" fillcolor="#0c4a6e" stroked="f"><v:fill opacity=".08"/><v:textpath style="font-family:&quot;Cairo&quot;;font-size:1pt" string="EduTech Mindset"/></v:shape></w:pict></w:r>';
    var hdr = HD + "<w:hdr " + NS + ' xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">' + '<w:p><w:pPr><w:bidi/></w:pPr>' + VML + '</w:p>' + wPara([{ s: SITE + "  |  " + SUB + "  |  " + MANAGER, b: true }], { size: 17, color: C.muted, after: 0, line: 240, border: '<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="4" w:color="CBD5E1"/></w:pBdr>' }) + "</w:hdr>";
    var fld = function (code) { return '<w:r><w:rPr>' + WF + '<w:color w:val="64748B"/><w:sz w:val="17"/><w:szCs w:val="17"/></w:rPr><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:rPr>' + WF + '<w:sz w:val="17"/></w:rPr><w:instrText xml:space="preserve"> ' + code + ' </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:rPr>' + WF + '<w:color w:val="64748B"/><w:sz w:val="17"/><w:szCs w:val="17"/></w:rPr><w:t>1</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r>'; };
    var ftr = HD + "<w:ftr " + NS + '><w:p><w:pPr><w:bidi/><w:jc w:val="center"/></w:pPr>' + wRun({ s: "صفحة ", b: false }, { size: 17, color: C.muted }) + fld("PAGE") + wRun({ s: " من ", b: false }, { size: 17, color: C.muted }) + fld("NUMPAGES") +
      wRun({ s: "   •   " + MANAGER, b: false }, { size: 17, color: C.muted }) + "</w:p></w:ftr>";
    var hs = function (id, name, sz, color, before, after, outline) { return '<w:style w:type="paragraph" w:styleId="' + id + '"><w:name w:val="' + name + '"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="' + before + '" w:after="' + after + '"/>' + (outline != null ? '<w:outlineLvl w:val="' + outline + '"/>' : "") + '</w:pPr><w:rPr><w:b/><w:bCs/><w:color w:val="' + color + '"/><w:sz w:val="' + sz + '"/><w:szCs w:val="' + sz + '"/></w:rPr></w:style>'; };
    var styles = HD + "<w:styles " + NS + '><w:docDefaults><w:rPrDefault><w:rPr>' + WF + '<w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="ar-SA" w:eastAsia="ar-SA" w:bidi="ar-SA"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:bidi/><w:spacing w:after="120" w:line="340" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>' +
      '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>' +
      hs("Title", "Title", 40, "0C4A6E", 0, 60, null) + hs("Heading1", "heading 1", 32, "0C4A6E", 320, 100, 0) + hs("Heading2", "heading 2", 28, "0284C7", 220, 100, 1) + hs("Heading3", "heading 3", 24, "0C4A6E", 180, 80, 2) + "</w:styles>";
    var ct = HD + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' +
      '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>' +
      '<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/><Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>' +
      '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>';
    var rels = HD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>';
    var drels = HD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>';
    var core = HD + '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>' + xml(stripEmoji(title)) + '</dc:title><dc:creator>' + SITE + '</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">' + new Date().toISOString() + '</dcterms:created></cp:coreProperties>';
    return zip([
      { name: "[Content_Types].xml", data: enc(ct) }, { name: "_rels/.rels", data: enc(rels) }, { name: "word/document.xml", data: enc(docXml) },
      { name: "word/_rels/document.xml.rels", data: enc(drels) }, { name: "word/styles.xml", data: enc(styles) }, { name: "word/header1.xml", data: enc(hdr) },
      { name: "word/footer1.xml", data: enc(ftr) }, { name: "docProps/core.xml", data: enc(core) }
    ]);
  }

  // ===================== PDF (رسم عربي احترافي على Canvas مع رمز QR ومخططات بصرية) =====================
  var PW = 595.28, PH = 841.89, SC = 2.5, MG = 46;
  var logoImg;
  function loadLogo() {
    if (logoImg !== undefined) return Promise.resolve(logoImg);
    return new Promise(function (res) {
      var im = new Image(); im.onload = function () { logoImg = im; res(im); }; im.onerror = function () { logoImg = null; res(null); }; im.src = "assets/logo.png";
      setTimeout(function () { if (logoImg === undefined) { logoImg = null; res(null); } }, 2500);
    });
  }
  function loadFonts() {
    if (!document.fonts || !document.fonts.load) return Promise.resolve();
    var p = Promise.all(['400 14px Cairo', '700 14px Cairo', '500 14px Cairo'].map(function (f) { return document.fonts.load(f, "عربي Abc").catch(function () {}); }));
    return Promise.race([p, new Promise(function (r) { setTimeout(r, 2500); })]);
  }
  function isLtr(w) { return /[A-Za-z0-9]/.test(w) && !hasAr(w); }

  function Layout(title, meta) {
    this.pages = []; this.title = title; this.meta = meta || {}; this.ctx = null; this.y = 0; this.cw = PW - MG * 2;
  }
  Layout.prototype.font = function (size, bold) { this.ctx.font = (bold ? "700 " : "500 ") + size + "px " + FONT; };
  Layout.prototype.newPage = function () {
    var c = document.createElement("canvas"); c.width = Math.round(PW * SC); c.height = Math.round(PH * SC);
    var x = c.getContext("2d"); x.scale(SC, SC); x.fillStyle = "#ffffff"; x.fillRect(0, 0, PW, PH);
    x.direction = "rtl"; x.textAlign = "right"; x.textBaseline = "alphabetic";
    this.pages.push(c); this.ctx = x;
    if (this.pages.length === 1) this.firstHeader(); else this.miniHeader();
  };
  Layout.prototype.miniHeader = function () {
    var x = this.ctx; this.font(9, true); x.fillStyle = C.muted; x.fillText(SITE + "  |  " + SUB + "  |  " + MANAGER, PW - MG, 34);
    x.strokeStyle = C.line; x.lineWidth = 0.7; x.beginPath(); x.moveTo(MG, 42); x.lineTo(PW - MG, 42); x.stroke(); this.y = 66;
  };
  Layout.prototype.firstHeader = function () {
    var x = this.ctx, g = x.createLinearGradient(PW, 0, 0, 0); g.addColorStop(0, "#082f49"); g.addColorStop(0.55, "#0c4a6e"); g.addColorStop(1, "#0284c7");
    var tl = this.wrap([{ s: this.title, b: true }], 18, true, this.cw - 125).slice(0, 3), bh = Math.max(98, 48 + tl.length * 28 + 24);
    x.fillStyle = g; x.fillRect(0, 0, PW, bh);
    x.fillStyle = "#f59e0b"; x.fillRect(0, bh, PW, 3.5);
    var tx = PW - MG;
    if (logoImg) {
      x.save(); x.beginPath(); x.arc(PW - MG - 22, 42, 22, 0, Math.PI * 2); x.closePath();
      x.fillStyle = "#fff"; x.fill(); x.clip(); x.drawImage(logoImg, PW - MG - 44, 20, 44, 44); x.restore();
      tx = PW - MG - 54;
    }
    try {
      drawQrOnCanvas(x, MG, Math.max(14, Math.round((bh - 58) / 2)), 56, this.meta.url || (typeof location !== "undefined" && location.href) || "https://edutech-mindset.pages.dev");
    } catch (eQr) {}
    this.font(9.5, true); x.fillStyle = "#fde68a"; x.fillText(SITE + "  •  " + SUB + "  •  " + MANAGER, tx, 27);
    this.font(18, true); x.fillStyle = "#ffffff"; var yy = 52; var self = this;
    tl.forEach(function (l) { self.drawLine(l, tx, yy, 18, true, "#ffffff"); yy += 27; });
    var customHdr = "";
    try {
      var savedHdr = JSON.parse(localStorage.getItem("edu_custom_pdf_hdr") || "null");
      customHdr = [this.meta.teacher || (savedHdr && savedHdr.teacher) || "", this.meta.school || (savedHdr && savedHdr.school) || ""].filter(Boolean).join(" — ");
    } catch (eH) {}
    var m = [customHdr ? stripEmoji(customHdr) : "", this.meta.tool ? stripEmoji(this.meta.tool) : "", this.meta.persona ? stripEmoji(this.meta.persona) : "", today()].filter(Boolean).join("   •   ");
    this.font(9.5, false); x.fillStyle = "#bae6fd"; x.fillText(m, tx, bh - 12);
    this.y = bh + 24;
  };
  Layout.prototype.measure = function (s, size, bold) { this.font(size, bold); return this.ctx.measureText(s).width; };
  Layout.prototype.wrap = function (runs, size, bold0, maxW) {
    var self = this, units = [], lines = [], cur = [], curW = 0;
    runs.forEach(function (r) {
      String(r.s).split(/\s+/).filter(Boolean).forEach(function (w) {
        var b = !!(r.b || bold0), ltr = isLtr(w), last = units[units.length - 1];
        if (ltr && last && last.ltr && last.chars < 40) { last.s += " " + w; last.b = last.b || b; last.chars += w.length + 1; }
        else units.push({ s: w, b: b, ltr: ltr, chars: w.length });
      });
    });
    var sp = this.measure(" ", size, false) * 1.05;
    units.forEach(function (u) {
      u.w = self.measure(u.s, size, u.b);
      if (u.w > maxW) {
        var part = "", pieces = [];
        Array.from(u.s).forEach(function (ch) { if (self.measure(part + ch, size, u.b) > maxW && part) { pieces.push(part); part = ch; } else part += ch; });
        if (part) pieces.push(part);
        pieces.forEach(function (p, i) { var pu = { s: p, b: u.b, w: self.measure(p, size, u.b) }; if (cur.length) { lines.push(cur); cur = []; curW = 0; } cur.push(pu); curW = pu.w; if (i < pieces.length - 1) { lines.push(cur); cur = []; curW = 0; } });
        return;
      }
      var add = (cur.length ? sp : 0) + u.w;
      if (curW + add > maxW && cur.length) { lines.push(cur); cur = [u]; curW = u.w; } else { cur.push(u); curW += add; }
    });
    if (cur.length) lines.push(cur);
    lines.sp = sp;
    return lines.length ? lines : [[]];
  };
  Layout.prototype.drawLine = function (units, right, y, size, bold0, color) {
    var x = this.ctx, sp = this.measure(" ", size, false) * 1.05, cx = right;
    for (var i = 0; i < units.length; i++) {
      var u = units[i]; this.font(size, u.b || bold0); x.fillStyle = color || C.ink; x.fillText(u.s, cx, y); cx -= u.w + sp;
    }
  };
  Layout.prototype.ensure = function (h) { if (!this.ctx || this.y + h > PH - 58) this.newPage(); };
  Layout.prototype.para = function (runs, o) {
    o = o || {}; var size = o.size || 11.5, lh = size * (o.lh || 1.85), right = PW - MG - (o.indent || 0), maxW = this.cw - (o.indent || 0) - (o.padR || 0);
    var lines = this.wrap(runs, size, !!o.bold, maxW - (o.marker ? 18 : 0)), self = this;
    if (o.keep) this.ensure(lh * 2 + 26);
    this.y += o.before || 0;
    lines.forEach(function (ln, i) {
      self.ensure(lh);
      if (o.bg) { self.ctx.fillStyle = o.bg; self.ctx.fillRect(MG, self.y - size * 0.4 - 3, self.cw, lh + 1); }
      if (o.bar) { self.ctx.fillStyle = o.bar; self.ctx.fillRect(PW - MG - 3, self.y - size * 0.4 - 3, 3, lh + 1); }
      var yy = self.y + size * 0.75;
      if (i === 0 && o.marker) { self.font(size, true); self.ctx.fillStyle = o.markerColor || C.accent; self.ctx.fillText(o.marker, right, yy); }
      self.drawLine(ln, right - (o.marker ? 18 : 0), yy, size, !!o.bold, o.color);
      self.y += lh;
    });
    this.y += (o.after == null ? 5 : o.after);
  };
  Layout.prototype.heading = function (b) {
    var l = b.l, size = l === 1 ? 16.5 : (l === 2 ? 14 : 12.5), col = l === 2 ? C.accent : C.head;
    this.ensure(size * 2.6 + 50); this.y += l === 1 ? 10 : 6;
    this.para(b.runs, { size: size, bold: true, color: col, lh: 1.6, after: l === 1 ? 3 : 2, keep: true });
    if (l === 1) { this.ctx.fillStyle = C.gold; this.ctx.fillRect(PW - MG - 54, this.y - 2, 54, 3); this.ctx.fillStyle = C.soft; this.ctx.fillRect(MG, this.y - 1, this.cw - 58, 1.4); this.y += 9; }
  };

  // ===================== رسم المخطط المفاهيمي البصري داخل الـ PDF (الإصدار 153) =====================
  Layout.prototype.diagram = function (rootTitle, nodes) {
    var items = (nodes || []).slice(0, 6);
    if (!items.length) return;
    var rows = Math.ceil(items.length / 3);
    var boxH = 44 + rows * 38;
    this.ensure(boxH + 16);
    var x = this.ctx, y0 = this.y + 4;
    x.save();
    // إطار الخريطة المفاهيمية
    x.fillStyle = "#f8fafc";
    x.strokeStyle = "#cbd5e1";
    x.lineWidth = 1;
    x.fillRect(MG, y0, this.cw, boxH);
    x.strokeRect(MG, y0, this.cw, boxH);
    // العقدة المركزية العليا
    var rw = Math.min(this.cw - 40, Math.max(170, this.measure(rootTitle, 11, true) + 34));
    var rx = PW / 2 - rw / 2, ry = y0 + 8, rh = 24;
    x.fillStyle = "#0c4a6e";
    x.fillRect(rx, ry, rw, rh);
    x.fillStyle = "#f59e0b";
    x.fillRect(rx, ry + rh - 2.5, rw, 2.5);
    this.font(10.5, true);
    x.fillStyle = "#ffffff";
    x.textAlign = "center";
    x.fillText(stripEmoji(rootTitle).slice(0, 48), PW / 2, ry + 16);

    // الفروع المتصلة
    var cols = Math.min(3, items.length);
    var gap = 10, nw = (this.cw - 24 - gap * (cols - 1)) / cols;
    var palette = ["#0284c7", "#4f46e5", "#059669", "#d97706", "#e11d48", "#7c3aed"];
    for (var i = 0; i < items.length; i++) {
      var rIdx = Math.floor(i / 3), cIdx = i % 3;
      var nx = PW - MG - 12 - (cIdx + 1) * nw - cIdx * gap;
      var ny = ry + rh + 12 + rIdx * 36;
      var nh = 26;
      // خط رابط من المركز للفرع
      x.strokeStyle = "#94a3b8";
      x.lineWidth = 0.9;
      x.beginPath();
      x.moveTo(PW / 2, ry + rh);
      x.lineTo(nx + nw / 2, ny);
      x.stroke();
      // صندوق الفرع
      x.fillStyle = "#ffffff";
      x.strokeStyle = palette[i % palette.length];
      x.lineWidth = 1.2;
      x.fillRect(nx, ny, nw, nh);
      x.strokeRect(nx, ny, nw, nh);
      x.fillStyle = palette[i % palette.length];
      x.fillRect(nx + nw - 4, ny, 4, nh);
      this.font(9.2, true);
      x.fillStyle = "#0f172a";
      x.textAlign = "center";
      x.fillText(stripEmoji(items[i]).slice(0, 28), nx + nw / 2 - 2, ny + 16.5);
    }
    x.restore();
    this.y = y0 + boxH + 12;
  };

  Layout.prototype.table = function (rows) {
    var self = this, cols = 0; rows.forEach(function (r) { cols = Math.max(cols, r.length); });
    var wts = []; for (var c = 0; c < cols; c++) { var m = 4; rows.forEach(function (r) { if (r[c]) m = Math.max(m, Math.min(plain(r[c]).length, 36)); }); wts.push(m + 5); }
    var tot = wts.reduce(function (a, b) { return a + b; }, 0), size = cols > 4 ? 9 : 10, pad = 5, lh = size * 1.7, widths = wts.map(function (w) { return Math.max(46, self.cw * w / tot); });
    var sc = this.cw / widths.reduce(function (a, b) { return a + b; }, 0); widths = widths.map(function (w) { return w * sc; });
    this.y += 4;
    rows.forEach(function (row, ri) {
      var cells = [], maxL = 1;
      for (var c = 0; c < cols; c++) { var ln = self.wrap(row[c] || [{ s: "", b: false }], size, ri === 0, widths[c] - pad * 2); cells.push(ln); maxL = Math.max(maxL, ln.length); }
      var rh = maxL * lh + pad * 2;
      if (self.y + rh > PH - 58) self.newPage();
      var x0 = PW - MG;
      for (var c2 = 0; c2 < cols; c2++) {
        var w = widths[c2], left = x0 - w;
        self.ctx.fillStyle = ri === 0 ? C.soft : (ri % 2 === 0 ? "#f8fafc" : "#ffffff"); self.ctx.fillRect(left, self.y, w, rh);
        self.ctx.strokeStyle = "#94a3b8"; self.ctx.lineWidth = 0.6; self.ctx.strokeRect(left, self.y, w, rh);
        cells[c2].forEach(function (l, k) { self.drawLine(l, x0 - pad, self.y + pad + size * 0.95 + k * lh, size, ri === 0, ri === 0 ? C.head : C.ink); });
        x0 -= w;
      }
      self.y += rh;
    });
    this.y += 10;
  };
  Layout.prototype.footers = function () {
    var n = this.pages.length;
    this.pages.forEach(function (c, i) {
      var x = c.getContext("2d"); x.direction = "rtl"; x.textAlign = "right"; x.textBaseline = "alphabetic";
      x.save(); x.globalAlpha = 0.065; x.translate(PW / 2, PH / 2); x.rotate(-Math.PI / 4); x.textAlign = "center"; x.fillStyle = "#0c4a6e";
      x.font = "800 62px " + FONT; x.fillText(WM_TEXT, 0, -8); x.font = "700 28px " + FONT; x.fillText(SUB, 0, 32); x.font = "600 20px " + FONT; x.fillText(MANAGER, 0, 66); x.restore();
      x.strokeStyle = C.line; x.lineWidth = 0.7; x.beginPath(); x.moveTo(MG, PH - 40); x.lineTo(PW - MG, PH - 40); x.stroke();
      x.font = "500 8.5px " + FONT; x.fillStyle = C.muted; x.fillText(SITE + "  •  " + SUB + "  •  " + MANAGER, PW - MG, PH - 24);
      x.textAlign = "left"; x.fillText("صفحة " + (i + 1) + " من " + n, MG, PH - 24);
    });
  };

  function bytesFromDataUrl(u) { var b = atob(u.split(",")[1]), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
  function makePdf(canvases, title, dims) {
    var W = dims ? dims[0] : PW, H = dims ? dims[1] : PH, parts = [], offs = [], len = 0, n = canvases.length;
    function push(x) { var u = typeof x === "string" ? Uint8Array.from(x, function (ch) { return ch.charCodeAt(0) & 255; }) : x; parts.push(u); len += u.length; }
    function obj(id, head, stream) { offs[id] = len; push(id + " 0 obj\n" + head); if (stream) { push("\nstream\n"); push(stream); push("\nendstream"); } push("\nendobj\n"); }
    var t16 = "FEFF"; Array.from(stripEmoji(title).slice(0, 80)).forEach(function (ch) { var cp = ch.codePointAt(0); if (cp > 0xFFFF) { cp -= 0x10000; t16 += ("000" + (0xD800 + (cp >> 10)).toString(16)).slice(-4) + ("000" + (0xDC00 + (cp & 1023)).toString(16)).slice(-4); } else t16 += ("000" + cp.toString(16)).slice(-4); });
    push("%PDF-1.4\n%âãÏÓ\n");
    obj(1, "<< /Type /Catalog /Pages 2 0 R >>");
    var kids = []; for (var k = 0; k < n; k++) kids.push((6 + 3 * k) + " 0 R");
    obj(2, "<< /Type /Pages /Count " + n + " /Kids [" + kids.join(" ") + "] >>");
    obj(3, "<< /Title <" + t16 + "> /Producer (EduTech Mindset) /Creator (EduTech Mindset) >>");
    canvases.forEach(function (cv, i) {
      var jpg = bytesFromDataUrl(cv.toDataURL("image/jpeg", 0.9)), im = 4 + 3 * i, ct = 5 + 3 * i, pg = 6 + 3 * i;
      obj(im, "<< /Type /XObject /Subtype /Image /Width " + cv.width + " /Height " + cv.height + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + jpg.length + " >>", jpg);
      var cs = "q " + W.toFixed(2) + " 0 0 " + H.toFixed(2) + " 0 0 cm /Im0 Do Q";
      obj(ct, "<< /Length " + cs.length + " >>", Uint8Array.from(cs, function (ch) { return ch.charCodeAt(0); }));
      obj(pg, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + W.toFixed(2) + " " + H.toFixed(2) + "] /Resources << /XObject << /Im0 " + im + " 0 R >> >> /Contents " + ct + " 0 R >>");
    });
    var total = 4 + 3 * n, xo = len, x = "xref\n0 " + total + "\n0000000000 65535 f \n";
    for (var id = 1; id < total; id++) x += ("0000000000" + offs[id]).slice(-10) + " 00000 n \n";
    push(x + "trailer\n<< /Size " + total + " /Root 1 0 R /Info 3 0 R >>\nstartxref\n" + xo + "\n%%EOF");
    return new Blob(parts, { type: "application/pdf" });
  }

  function buildPdf(title, text, opts) {
    opts = opts || {};
    return Promise.all([loadFonts(), loadLogo()]).then(function () {
      var L = new Layout(stripEmoji(title), opts), bl = opts.blocks || dropDupTitle(parse(text), title), i = 0;
      L.newPage();
      // إن لم يحتوِ النص على كتلة [مخطط: ...] وكان فيه عدة عناوين فرعية، نولّد مخططاً مفاهيمياً بصرياً تلقائياً في أعلى الصفحة الأولى!
      var hasExplicitDiag = bl.some(function (b) { return b.t === "diagram"; });
      if (!hasExplicitDiag && opts.autoDiagram !== false) {
        var h2s = bl.filter(function (b) { return b.t === "h" && b.l >= 2; }).map(function (b) { return stripEmoji(plain(b.runs)).replace(/^(?:أولاً|ثانياً|ثالثاً|رابعاً|خامساً|\d+[.)\-])\s*[:：]?\s*/, "").trim(); }).filter(Boolean);
        if (h2s.length >= 2) {
          L.diagram("المحاور الأساسية: " + stripEmoji(title).slice(0, 36), h2s.slice(0, 6));
        }
      }
      while (i < bl.length) {
        var b = bl[i];
        if (b.t === "h") L.heading(b);
        else if (b.t === "p") L.para(b.runs);
        else if (b.t === "diagram") L.diagram(b.root, b.nodes);
        else if (b.t === "li") L.para(b.runs, { indent: 8 + b.lvl * 16, marker: b.ord ? b.n + "." : (b.lvl ? "–" : "•"), after: 3 });
        else if (b.t === "quote") L.para(b.runs, { bg: "#f1f5f9", bar: C.gold, color: C.muted, padR: 12, indent: 8, after: 6, size: 11 });
        else if (b.t === "hr") { L.ensure(14); L.ctx.strokeStyle = C.line; L.ctx.lineWidth = 0.8; L.ctx.beginPath(); L.ctx.moveTo(MG, L.y + 4); L.ctx.lineTo(PW - MG, L.y + 4); L.ctx.stroke(); L.y += 14; }
        else if (b.t === "table") L.table(b.rows);
        i++;
      }
      L.footers();
      return makePdf(L.pages, title);
    });
  }

  // ===================== الشهادة =====================
  function certCanvas(d) {
    var W = PH, H = PW, S = 2.4, c = document.createElement("canvas"); c.width = Math.round(W * S); c.height = Math.round(H * S);
    var x = c.getContext("2d"); x.scale(S, S); x.direction = "rtl"; x.textAlign = "center"; x.textBaseline = "alphabetic";
    var g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, "#082f49"); g.addColorStop(0.55, "#0c4a6e"); g.addColorStop(1, "#051322"); x.fillStyle = g; x.fillRect(0, 0, W, H);
    x.strokeStyle = "#fbbf24"; x.lineWidth = 5; x.strokeRect(20, 20, W - 40, H - 40); x.strokeStyle = "rgba(251,191,36,.45)"; x.lineWidth = 1.2; x.strokeRect(30, 30, W - 60, H - 60);
    [[34, 34], [W - 34, 34], [34, H - 34], [W - 34, H - 34]].forEach(function (p) { x.fillStyle = "#fbbf24"; x.beginPath(); x.arc(p[0], p[1], 4, 0, 7); x.fill(); });
    var f = function (s, b) { x.font = (b ? "800 " : "500 ") + s + "px " + FONT; };
    if (logoImg) { x.save(); x.beginPath(); x.arc(W / 2, 82, 30, 0, 7); x.closePath(); x.fillStyle = "#fff"; x.fill(); x.clip(); x.drawImage(logoImg, W / 2 - 30, 52, 60, 60); x.restore(); }
    f(11.5, true); x.fillStyle = "#fbbf24"; x.fillText("مبادرة عقلية التعليم والتكنولوجيا — غزة، فلسطين", W / 2, 135);
    f(32, true); x.fillStyle = "#ffffff"; x.fillText("شهادة إنجاز وتمكين رقمي", W / 2, 180);
    f(13, false); x.fillStyle = "#bae6fd"; x.fillText("تشهد منصة EduTech Mindset بأنّ:", W / 2, 212);
    f(30, true); x.fillText(d.name || "", W / 2, 258);
    var nw = Math.min(x.measureText(d.name || "").width + 30, W - 140); x.fillStyle = "#fbbf24"; x.fillRect(W / 2 - nw / 2, 268, nw, 2.5);
    f(12.5, true); x.fillStyle = "#fcd34d"; x.fillText([d.role, d.school || "فلسطين"].filter(Boolean).join(" — "), W / 2, 294);
    var body = "قد حقق رتبة (" + d.rank + ") في توظيف أدوات الذكاء الاصطناعي والتعلم النشط، وأتمّ مراجعة (" + d.completed + ") موارد تدريبية وصياغة (" + d.prompts + ") برومبتات تعليمية في مجال " + (d.subject || "التعليم") + ".";
    var L = new Layout("", {}); L.ctx = x; var lines = L.wrap([{ s: body, b: false }], 13.5, false, W - 190), y = 332;
    x.direction = "rtl"; x.textAlign = "right";
    lines.forEach(function (ln) { var tw = 0, sp = L.measure(" ", 13.5, false) * 1.05; ln.forEach(function (u, i) { tw += u.w + (i ? sp : 0); }); x.direction = "rtl"; x.textAlign = "right"; L.drawLine(ln, W / 2 + tw / 2, y, 13.5, false, "#e2e8f0"); y += 24; });
    x.strokeStyle = "rgba(255,255,255,.2)"; x.lineWidth = 1; x.beginPath(); x.moveTo(70, H - 90); x.lineTo(W - 70, H - 90); x.stroke();
    x.textAlign = "right"; f(11, true); x.fillStyle = "#ffffff"; x.fillText("إشراف واعتماد", W - 74, H - 64); f(11.5, false); x.fillStyle = "#bae6fd"; x.fillText("الأستاذ باسل أشرف الفقعاوي", W - 74, H - 44);
    x.textAlign = "left"; f(11, true); x.fillStyle = "#fbbf24"; x.fillText("EduTech Mindset", 74, H - 64); f(11, false); x.fillStyle = "#bae6fd"; x.fillText(today(), 74, H - 44);
    try { drawQrOnCanvas(x, W / 2 - 24, H - 82, 48, "https://edutech-mindset.pages.dev"); } catch (eQr) {}
    return c;
  }
  function certificate(d, fmt) {
    var title = "شهادة إنجاز — " + (d.name || "");
    if (fmt === "docx") {
      var P = function (s, o) { o = o || {}; o.t = "p"; o.center = true; o.runs = [{ s: s, b: !!o.bold }]; return o; };
      var blocks = [P("مبادرة عقلية التعليم والتكنولوجيا — غزة، فلسطين", { size: 24, color: C.gold, bold: true, after: 80 }), P("شهادة إنجاز وتمكين رقمي", { size: 64, color: C.head, bold: true, after: 200 }),
        P("تشهد منصة EduTech Mindset بأنّ:", { size: 26, color: C.muted, after: 160 }), P(d.name || "", { size: 52, color: C.accent, bold: true, after: 120 }),
        P([d.role, d.school || "فلسطين"].filter(Boolean).join(" — "), { size: 24, color: C.head, bold: true, after: 220 }),
        P("قد حقق رتبة (" + d.rank + ") في توظيف أدوات الذكاء الاصطناعي والتعلم النشط، وأتمّ مراجعة (" + d.completed + ") موارد تدريبية وصياغة (" + d.prompts + ") برومبتات تعليمية في مجال " + (d.subject || "التعليم") + ".", { size: 28, color: C.ink, after: 300, line: 420 }),
        P("إشراف واعتماد: الأستاذ باسل أشرف الفقعاوي   •   EduTech Mindset   •   " + today(), { size: 22, color: C.muted, bold: true })];
      return Promise.resolve(buildDocx(title, "", { blocks: blocks, landscape: true })).then(function (b) { saveBlob(b, fileName(title, "docx")); return b; });
    }
    return Promise.all([loadFonts(), loadLogo()]).then(function () { var cv = certCanvas(d); var blob = makePdf([cv], title, [PH, PW]); saveBlob(blob, fileName(title, "pdf")); return blob; });
  }

  // ===================== تصدير محادثة «مساعدي» كملف PDF منسّق =====================
  function pdfFromChat(chatList, opts) {
    opts = opts || {};
    var items = Array.isArray(chatList) ? chatList : [];
    if (!items.length) { toast("لا توجد رسائل في المحادثة لتصديرها بعد", "warning"); return Promise.resolve(); }
    var lines = ["# سجل الحوار التعليمي — مساعدي الذكي", ""];
    if (opts.persona) lines.push("> **المحاور الذكي:** " + opts.persona + "  |  **التاريخ:** " + today(), "");
    items.forEach(function (m, idx) {
      var clean = String(m.raw || m.t || "").replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").trim();
      if (!clean) return;
      if (m.r === "u") {
        lines.push("## 🙋‍♂️ سؤالي / طلبي (" + (Math.floor(idx / 2) + 1) + ")");
        lines.push("> " + clean.replace(/\n+/g, " "));
        lines.push("");
      } else {
        lines.push("### ✨ إجابة «مساعدي»" + (m.pName ? " (" + m.pName + ")" : ""));
        lines.push(clean);
        lines.push("", "---", "");
      }
    });
    return run("pdf", opts.title || "حوار مساعدي الذكي — EduTech Mindset", lines.join("\n"), { tool: "مساعدي الذكي", persona: opts.persona || "" }, opts.btn);
  }

  // ===================== مشاركة ملف الـ PDF مباشرة عبر الجوال (واتساب / تليجرام) =====================
  function sharePdf(title, text, opts, btn) {
    text = String(text || "").trim();
    if (!text) { toast("لا يوجد محتوى لمشاركته بعد", "warning"); return Promise.resolve(); }
    title = stripEmoji(title) || autoTitle(text);
    var old = btn ? btn.innerHTML : "";
    if (btn) { btn.disabled = true; btn.innerHTML = "⏳ جارٍ التجهيز…"; }
    record({ title: title, text: text, tool: opts && opts.tool });
    return buildPdf(title, text, opts).then(function (blob) {
      var fname = fileName(title, "pdf");
      try {
        var file = new File([blob], fname, { type: "application/pdf" });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          return navigator.share({
            files: [file],
            title: title,
            text: "📄 " + title + " — عبر منصة EduTech Mindset (إدارة أ. باسل أشرف الفقعاوي)"
          }).catch(function () { saveBlob(blob, fname); });
        }
      } catch (e) {}
      saveBlob(blob, fname);
      toast("تم تنزيل ملف الـ PDF لجهازك — يمكنك إرفاقه الآن عبر واتساب أو تليجرام ✓", "success");
    }).finally(function () {
      if (btn) { btn.disabled = false; btn.innerHTML = old; }
    });
  }


  // ===================== تصدير اختبار وملخص تفاعلي HTML يعمل بلا إنترنت (الإصدار 153) =====================
  function htmlQuiz(title, text, opts) {
    opts = opts || {};
    title = stripEmoji(title) || autoTitle(text);
    var bodyHtml = renderHtml(text);
    var doc = '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
      '<title>' + esc(title) + ' — EduTech Mindset</title>' +
      '<style>body{font-family:Cairo,Tahoma,Arial,sans-serif;background:#f1f5f9;color:#0f172a;margin:0;padding:16px;line-height:1.85}' +
      '.wrap{max-width:780px;margin:0 auto;background:#fff;border-radius:20px;overflow:hidden;box-shadow:0 12px 40px rgba(2,6,23,.12);border:1px solid #cbd5e1}' +
      '.hd{background:linear-gradient(135deg,#082f49,#0284c7);color:#fff;padding:20px 24px;border-bottom:4px solid #f59e0b}' +
      '.hd small{color:#fde68a;font-weight:800;display:block;margin-bottom:4px}.hd h1{margin:0;font-size:22px}' +
      '.ct{padding:22px 24px}.ct h3,.ct h4{color:#0c4a6e;margin:16px 0 8px}.ct table{width:100%;border-collapse:collapse;margin:12px 0;font-size:14px}' +
      '.ct th,.ct td{border:1px solid #cbd5e1;padding:8px 10px;text-align:right}.ct th{background:#e0f2fe;color:#0c4a6e}' +
      '.qbox{margin-top:20px;padding:16px;border-radius:16px;background:#f8fafc;border:1.5px solid #0284c7}' +
      '.opt{display:block;width:100%;text-align:right;margin:6px 0;padding:10px 12px;border-radius:10px;border:1px solid #cbd5e1;background:#fff;font:700 14px Cairo,sans-serif;cursor:pointer}' +
      '.opt.ok{background:#dcfce7;border-color:#16a34a;color:#166534}.opt.bad{background:#fee2e2;border-color:#dc2626;color:#991b1b}' +
      '.ft{text-align:center;padding:14px;font-size:12px;color:#64748b;background:#f8fafc;border-top:1px solid #e2e8f0}</style></head><body>' +
      '<div class="wrap"><div class="hd"><small>' + SITE + ' — ' + SUB + ' — ' + MANAGER + '</small><h1>' + esc(title) + '</h1></div>' +
      '<div class="ct">' + bodyHtml +
      '<div class="qbox"><h3>🎯 تحقق سريع من فهمك (يعمل بدون إنترنت)</h3><p><b>سؤال المراجعة:</b> هل طبّقت القاعدة الأساسية وحللت المثال التطبيقي أعلاه بنفسك؟</p>' +
      '<button class="opt" onclick="ans(this,true)">أ) نعم، فهمت الفكرة وجاهز للتطبيق في الامتحان ✓</button>' +
      '<button class="opt" onclick="ans(this,false)">ب) أحتاج لمراجعة الجدول والأمثلة مرة أخرى</button>' +
      '<div id="res" style="font-weight:800;margin-top:8px;color:#0c4a6e"></div></div></div>' +
      '<div class="ft">تم التوليد بواسطة «مساعدي الذكي» — منصة EduTech Mindset (' + today() + ')</div></div>' +
      '<script>function ans(b,ok){var bs=document.querySelectorAll(".opt");bs.forEach(function(x){x.disabled=true});b.classList.add(ok?"ok":"bad");document.getElementById("res").textContent=ok?"🎉 ممتاز! بارك الله في همتك وتفوقك!":"💡 راجع الملخص والجدول بالأعلى ثم أعد المحاولة.";}<\/script>' +
      '</body></html>';
    var blob = new Blob([doc], { type: "text/html;charset=utf-8" });
    saveBlob(blob, fileName(title, "html"));
    toast("🌐 تم تنزيل ملف الاختبار التفاعلي HTML (يعمل على جوال الطالب بلا إنترنت) ✓", "success");
    return blob;
  }

  // ===================== واجهة الاستخدام =====================
  function getText(el) { return el ? (el.dataset && el.dataset.exRaw != null ? el.dataset.exRaw : el.textContent) : ""; }

  function run(kind, title, text, opts, btn) {
    text = String(text || "").trim();
    if (!text) { toast("لا يوجد محتوى لتصديره بعد", "warning"); return Promise.resolve(); }
    title = stripEmoji(title) || autoTitle(text);
    var old = btn ? btn.innerHTML : "";
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i><span>جارٍ التجهيز…</span>'; }
    record({ title: title, text: text, tool: opts && opts.tool });
    var job = kind === "docx" ? new Promise(function (r) { setTimeout(function () { r(buildDocx(title, text, opts)); }, 30); }) : buildPdf(title, text, opts);
    return job.then(function (blob) { saveBlob(blob, fileName(title, kind)); toast(kind === "docx" ? "تم تنزيل ملف Word ✓" : "تم تجهيز وتنزيل نسخة PDF بنجاح ✓", "success"); return blob; })
      .catch(function (e) { toast("تعذر إنشاء الملف (" + String(e && e.message || "خطأ").slice(0, 60) + ")", "warning"); })
      .then(function (res) { if (btn) { btn.disabled = false; btn.innerHTML = old; } return res; });
  }

  var BTN = { speak: ['fa-volume-high', 'استمع', 'ex-s'], docx: ['fa-file-word', 'Word', 'ex-w'], pdf: ['fa-file-pdf', 'PDF', 'ex-p'], copy: ['fa-regular fa-copy', 'نسخ', 'ex-c'] };
  function bar(o) {
    o = o || {};
    var b = function (k) { var d = BTN[k]; return '<button type="button" class="ex-btn ' + d[2] + '" data-ex="' + k + '"><i class="' + (d[0].indexOf(" ") > 0 ? d[0] : "fa-solid " + d[0]) + '"></i><span>' + d[1] + "</span></button>"; };
    return '<div class="ex-bar" data-ex-src="' + esc(o.src || "") + '" data-ex-title="' + esc(o.title || "") + '" data-ex-tool="' + esc(o.tool || "") + '">' + b("speak") + (o.copy === false ? "" : b("copy")) + b("docx") + b("pdf") + "</div>";
  }

  // ---------- أعمالي ----------
  function load() { try { var a = JSON.parse(localStorage.getItem(STORE_KEY) || "[]"); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
  function persist(a) {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(a)); } catch (e) { try { localStorage.setItem(STORE_KEY, JSON.stringify(a.slice(0, 10))); } catch (e2) {} }
  }
  function hash(s) { var h = 5381; for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return String(h >>> 0); }
  function record(it) {
    if (!it || !it.text || String(it.text).trim().length < 20) return;
    var text = String(it.text).trim().slice(0, 60000), id = hash(text), a = load().filter(function (x) { return x.id !== id; });
    a.unshift({ id: id, title: stripEmoji(it.title) || autoTitle(text), tool: stripEmoji(it.tool || ""), text: text, ts: Date.now() });
    var total = 0; a = a.slice(0, 40).filter(function (x) { total += x.text.length; return total < 900000; });
    persist(a); updateFab();
  }
  function updateFab() { var f = document.getElementById("exFab"); if (!f) return; var n = load().length; var c = f.querySelector(".ex-count"); if (c) { c.textContent = n; c.style.display = n ? "" : "none"; } }
  function openWorks() {
    var a = load();
    var rows = a.length ? a.map(function (x) {
      return '<div class="ex-work" data-id="' + x.id + '"><div class="ex-work-t">' + esc(x.title) + '</div><div class="ex-work-m">' + esc([x.tool, new Date(x.ts).toLocaleDateString("ar-EG")].filter(Boolean).join(" • ")) + "</div>" +
        '<div class="ex-work-p">' + esc(x.text.replace(/[#*|>`]/g, "").slice(0, 150)) + '…</div><div class="ex-bar" data-ex-work="' + x.id + '">' +
        '<button type="button" class="ex-btn ex-c" data-exw="copy"><i class="fa-regular fa-copy"></i><span>نسخ</span></button><button type="button" class="ex-btn ex-w" data-exw="docx"><i class="fa-solid fa-file-word"></i><span>Word</span></button>' +
        '<button type="button" class="ex-btn ex-p" data-exw="pdf"><i class="fa-solid fa-file-pdf"></i><span>PDF</span></button><button type="button" class="ex-btn ex-d" data-exw="del" title="حذف"><i class="fa-solid fa-trash-can"></i></button></div></div>';
    }).join("") : '<div class="ex-empty"><i class="fa-solid fa-folder-open"></i><p>لا توجد أعمال بعد.</p><small>كل ما تولّده بالذكاء الاصطناعي أو في «مساعدي» وتصدّره يُحفظ هنا على جهازك لتنزّله لاحقاً بصيغة Word أو PDF.</small></div>';
    var html = '<div class="p-4 shrink-0 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 bg-slate-50 dark:bg-slate-800/50"><div class="flex items-center gap-2"><span class="w-8 h-8 rounded-xl bg-gradient-to-br from-brand-600 to-sky-400 text-white flex items-center justify-center text-sm"><i class="fa-solid fa-folder-open"></i></span><div><h3 class="text-sm font-extrabold">أعمالي</h3><p class="text-[10px] text-slate-500">محفوظة على هذا الجهاز فقط · نزّلها Word أو PDF</p></div></div>' +
      '<button type="button" class="p-2 text-slate-400" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button></div><div class="p-4 overflow-y-auto flex-1 min-h-0 text-right space-y-3">' + rows + "</div>" +
      (a.length ? '<div class="p-3 border-t border-slate-200 dark:border-slate-800 shrink-0"><button type="button" class="ex-btn ex-d w-full" data-exw="clear"><i class="fa-solid fa-broom"></i><span>مسح كل الأعمال</span></button></div>' : "");
    if (typeof showModalContent === "function") showModalContent(html);
  }
  var FAB_POS_KEY = "edu_exfab_pos_v153";
  var FAB_HIDE_KEY = "edu_exfab_hidden_v153";
  var suppressFabClick = false;

  function isFabHidden() {
    try { return localStorage.getItem(FAB_HIDE_KEY) === "1"; } catch (e) { return false; }
  }
  function setFabHidden(hide) {
    try { localStorage.setItem(FAB_HIDE_KEY, hide ? "1" : "0"); } catch (e) {}
    var f = document.getElementById("exFab");
    if (f) f.style.display = hide ? "none" : "";
    toast(hide ? "تم إخفاء أيقونة «أعمالي» — يمكنك إظهارها من إعدادات «مساعدي» ⚙️" : "تم إظهار أيقونة «أعمالي» 📂", "info");
    return !hide;
  }
  function toggleFab(forceVisible) {
    var nextHidden = typeof forceVisible === "boolean" ? !forceVisible : !isFabHidden();
    return setFabHidden(nextHidden);
  }
  function applyFabPos() {
    var f = document.getElementById("exFab");
    if (!f) return;
    f.style.display = isFabHidden() ? "none" : "";
    var vw = window.innerWidth || 360, vh = window.innerHeight || 640;
    var w = f.offsetWidth || 50, h = f.offsetHeight || 50;
    try {
      var pos = JSON.parse(localStorage.getItem(FAB_POS_KEY) || "null");
      if (pos && typeof pos.xPct === "number" && typeof pos.yPct === "number") {
        var lx = Math.max(8, Math.min(vw - w - 8, Math.round(pos.xPct * vw)));
        var ty = Math.max(8, Math.min(vh - h - 18, Math.round(pos.yPct * vh)));
        f.style.left = lx + "px";
        f.style.top = ty + "px";
        f.style.right = "auto";
        f.style.bottom = "auto";
        return;
      }
    } catch (e) {}
    f.style.left = "";
    f.style.top = "";
    f.style.right = "";
    f.style.bottom = "";
  }
  function resetFabPos() {
    try { localStorage.removeItem(FAB_POS_KEY); } catch (e) {}
    setFabHidden(false);
    applyFabPos();
  }
  function makeDraggableFab(f) {
    var active = false, sx = 0, sy = 0, ol = 0, ot = 0, moved = false;
    function start(cx, cy, target) {
      if (target && target.closest(".ex-fab-hide")) return;
      var r = f.getBoundingClientRect();
      active = true; moved = false; sx = cx; sy = cy; ol = r.left; ot = r.top;
    }
    function move(cx, cy, ev) {
      if (!active) return;
      var dx = cx - sx, dy = cy - sy;
      if (!moved && Math.hypot(dx, dy) < 7) return;
      if (!moved) { moved = true; f.style.transition = "none"; }
      if (ev && ev.cancelable) ev.preventDefault();
      var vw = window.innerWidth || 360, vh = window.innerHeight || 640;
      var w = f.offsetWidth || 50, h = f.offsetHeight || 50;
      var nx = Math.max(6, Math.min(vw - w - 6, Math.round(ol + dx)));
      var ny = Math.max(6, Math.min(vh - h - 18, Math.round(ot + dy)));
      f.style.left = nx + "px"; f.style.top = ny + "px"; f.style.right = "auto"; f.style.bottom = "auto";
    }
    function end() {
      if (!active) return;
      active = false;
      f.style.transition = "";
      if (moved) {
        suppressFabClick = true;
        setTimeout(function () { suppressFabClick = false; }, 300);
        var r = f.getBoundingClientRect();
        var vw = Math.max(1, window.innerWidth || 360), vh = Math.max(1, window.innerHeight || 640);
        try {
          localStorage.setItem(FAB_POS_KEY, JSON.stringify({
            xPct: Math.round((r.left / vw) * 10000) / 10000,
            yPct: Math.round((r.top / vh) * 10000) / 10000
          }));
        } catch (e) {}
      }
    }
    if (window.PointerEvent) {
      f.addEventListener("pointerdown", function (e) {
        if (e.button && e.button !== 0) return;
        start(e.clientX, e.clientY, e.target);
        if (active) { try { f.setPointerCapture(e.pointerId); } catch (er) {} }
      });
      f.addEventListener("pointermove", function (e) { move(e.clientX, e.clientY, e); });
      f.addEventListener("pointerup", function (e) { try { f.releasePointerCapture(e.pointerId); } catch (er) {} end(); });
      f.addEventListener("pointercancel", end);
    } else {
      f.addEventListener("touchstart", function (e) { var t = e.touches && e.touches[0]; if (t) start(t.clientX, t.clientY, e.target); }, { passive: true });
      f.addEventListener("touchmove", function (e) { var t = e.touches && e.touches[0]; if (t) move(t.clientX, t.clientY, e); }, { passive: false });
      f.addEventListener("touchend", end);
    }
  }
  function ensureFab() {
    if (document.getElementById("exFab")) return;
    if (!document.getElementById("exFabFreeCss")) {
      var st = document.createElement("style");
      st.id = "exFabFreeCss";
      st.textContent = "#exFab{touch-action:none;user-select:none;-webkit-user-select:none;cursor:grab}#exFab:active{cursor:grabbing}" +
        "#exFab .ex-fab-hide{position:absolute;top:-7px;left:-7px;width:20px;height:20px;border-radius:50%;background:#0f172a;color:#f8fafc;border:1.5px solid #f59e0b;font:900 10px/18px Cairo,sans-serif;text-align:center;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,.35)}";
      document.head.appendChild(st);
    }
    var f = document.createElement("button"); f.id = "exFab"; f.type = "button"; f.title = "أعمالي — اسحبها لأي مكان على الشاشة أو اضغط للفتح";
    f.innerHTML = '<i class="fa-solid fa-folder-open"></i><span class="ex-count" style="display:none">0</span><span class="ex-fab-hide" title="إخفاء أيقونة أعمالي" role="button" aria-label="إخفاء أيقونة أعمالي">✕</span>';
    makeDraggableFab(f);
    f.addEventListener("click", function (e) {
      if (e.target.closest(".ex-fab-hide")) { e.stopPropagation(); setFabHidden(true); return; }
      if (suppressFabClick) { e.preventDefault(); e.stopPropagation(); return; }
      openWorks();
    });
    document.body.appendChild(f);
    updateFab();
    applyFabPos();
    window.addEventListener("resize", applyFabPos);
  }

  document.addEventListener("click", function (e) {
    var w = e.target.closest("[data-exw]");
    if (w) {
      var host = w.closest("[data-ex-work]"), k = w.dataset.exw, a = load();
      if (k === "hidefab") { setFabHidden(true); if (typeof closeModal === "function") closeModal(); return; }
      if (k === "clear") { if (window.eduConfirm ? window.eduConfirm("مسح كل الأعمال المحفوظة على هذا الجهاز؟") : true) { persist([]); updateFab(); openWorks(); } return; }
      var it = host && a.filter(function (x) { return x.id === host.dataset.exWork; })[0]; if (!it) return;
      if (k === "del") { persist(a.filter(function (x) { return x.id !== it.id; })); updateFab(); openWorks(); return; }
      if (k === "copy") { if (typeof copyTextToClipboard === "function") copyTextToClipboard(it.text, "تم النسخ 📋"); return; }
      run(k, it.title, it.text, { tool: it.tool }, w); return;
    }
    var b = e.target.closest("[data-ex]"); if (!b) return;
    var h = b.closest("[data-ex-src]"); if (!h) return;
    var el = h.dataset.exSrc ? document.querySelector(h.dataset.exSrc) : null, text = getText(el), title = h.dataset.exTitle;
    if (el && el.dataset.exTitle) title = el.dataset.exTitle;
    if (b.dataset.ex === "speak") {
      if (!text || !String(text).trim()) { toast("لا يوجد نص لقراءته بعد", "warning"); return; }
      if (window.EduVoice && window.EduVoice.read) window.EduVoice.read(text);
      else if ("speechSynthesis" in window) { window.speechSynthesis.cancel(); window.speechSynthesis.speak(new SpeechSynthesisUtterance(text)); }
      return;
    }
    if (b.dataset.ex === "copy") { if (typeof copyTextToClipboard === "function") copyTextToClipboard(text, "تم النسخ 📋"); return; }
    run(b.dataset.ex, title, text, { tool: h.dataset.exTool }, b);
  });

  // ---------- تقرير إنجازات المستخدم ----------
  function workspaceReport(kind, btn) {
    var u = null; try { u = (typeof window.getOrCreateActiveUser === "function") ? window.getOrCreateActiveUser() : getCurrentUser(); } catch (e) {}
    if (!u) { toast("سجّل دخولك أولاً", "info"); try { openGoogleAuthModal(); } catch (e) {} return; }
    var items = (typeof appState !== "undefined" && appState.items) || [], byId = {}; items.forEach(function (i) { byId[i.id] = i; });
    var rank = ""; try { rank = getUserRankTitle(u); } catch (e) {}
    var L = ["# تقرير إنجازات " + (u.name || "المعلم"), "", "## بيانات عامة", "- **الاسم:** " + (u.name || "—"), "- **الصفة:** " + (u.role || "—") + (u.school ? " — " + u.school : ""), "- **التخصص:** " + (u.subject || "—"), rank ? "- **الرتبة:** " + rank : "",
      "- **موارد مُنجزة:** " + (u.completedItems || []).length + "  |  **مفضّلة:** " + (u.favorites || []).length + "  |  **برومبتات محفوظة:** " + (u.savedPrompts || []).length, ""];
    var done = (u.completedItems || []).map(function (id) { return byId[id] && byId[id].title; }).filter(Boolean);
    if (done.length) { L.push("## الموارد التي أنجزتها"); done.forEach(function (t) { L.push("- " + t); }); L.push(""); }
    var tasks = u.userTasks || [];
    if (tasks.length) { L.push("## مفكرة المهام"); L.push("| المهمة | الأولوية | الحالة |"); L.push("|---|---|---|"); tasks.forEach(function (t) { L.push("| " + String(t.title).replace(/\|/g, "/") + " | " + (t.priority || "—") + " | " + (t.done ? "مُنجزة ✓" : "قيد التنفيذ") + " |"); }); L.push(""); }
    var notes = Object.keys(u.userNotes || {}).filter(function (k) { return String(u.userNotes[k]).trim(); });
    if (notes.length) { L.push("## ملاحظاتي"); notes.forEach(function (k) { L.push("### " + ((byId[k] && byId[k].title) || "ملاحظة")); L.push(String(u.userNotes[k]).trim()); L.push(""); }); }
    var sp = u.savedPrompts || [];
    if (sp.length) { L.push("## برومبتاتي ونتائجي المحفوظة"); sp.forEach(function (p) { L.push("### " + (p.topic || "برومبت")); L.push("*" + [p.goal, p.grade, p.subject, p.date].filter(Boolean).join(" • ") + "*"); L.push(String(p.text || "")); L.push(""); }); }
    return run(kind, "تقرير إنجازات " + (u.name || ""), L.filter(function (x) { return x !== null; }).join("\n"), { tool: "حسابي" }, btn);
  }
  document.addEventListener("click", function (e) { var r = e.target.closest("[data-report]"); if (r) workspaceReport(r.dataset.report, r); });
  window.addEventListener("DOMContentLoaded", function () { ensureFab(); });
  window.addEventListener("storage", updateFab);

  window.Exporter = {
    docx: function (t, x, o, b) { return run("docx", t, x, o, b); },
    pdf: function (t, x, o, b) { return run("pdf", t, x, o, b); },
    sharePdf: sharePdf,
    htmlQuiz: htmlQuiz,
    toggleFab: toggleFab,
    isFabHidden: isFabHidden,
    resetFabPos: resetFabPos,
    pdfFromChat: pdfFromChat,
    buildDocx: buildDocx, buildPdf: buildPdf, parse: parse, bar: bar, show: show, render: renderHtml, record: record, certificate: certificate, openWorks: openWorks, saveBlob: saveBlob, drawQr: drawQrOnCanvas
  };
})();

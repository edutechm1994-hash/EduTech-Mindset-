/*
 * استوديو ضغط الصور ودمجها في PDF وبطاقات المشاركة محلياً بلا إنترنت — EduTech Mindset (الإصدار 50 الذهبي)
 * يعمل محلياً داخل المتصفح 100% دون الحاجة لرفع الملفات للإنترنت (مصمم لتوفير البيانات والوقت في غزة):
 * 1) 🗜️ ضاغط الصور الذكي الفوري (تقليص صور الهاتف من عدة ميغابايت إلى 60-150 كيلوبايت مع الحفاظ على وضوح النص).
 * 2) 📄 محوّل ودامج صور الدفتر أو الكتاب إلى ملف PDF واحد مرتب جاهز للطباعة أو الإرسال عبر واتساب.
 * 3) 🎴 مصمّم بطاقات الروابط السريعة للمعلم (Shareable Link Poster Card PNG) لأي اختبار أو لعبة أو فصل دراسي.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var st = {
    tab: "compress", // compress | img2pdf | linkcard
    compQuality: 0.65,
    compMaxW: 1200,
    compItems: [], // [{name, origKb, newKb, url}]
    pdfImages: [], // [{name, dataUrl}]
    cardTitle: "اختبار الشهر الأول — العلوم والحياة",
    cardSub: "الصف التاسع الأساسي • الزمن: 20 دقيقة",
    cardCode: "GZ-4821",
    cardUrl: location.origin + location.pathname
  };

  function processImageFile(file, maxW, quality) {
    return new Promise(function (res, rej) {
      var u = URL.createObjectURL(file), im = new Image();
      im.onload = function () {
        var k = Math.min(1, maxW / Math.max(im.width, im.height));
        var c = document.createElement("canvas");
        c.width = Math.round(im.width * k);
        c.height = Math.round(im.height * k);
        c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
        URL.revokeObjectURL(u);
        c.toBlob(function (b) {
          if (!b) return rej(new Error("blob error"));
          res({
            name: file.name.replace(/\.[^.]+$/, "") + "-compressed.jpg",
            origKb: Math.round(file.size / 1024),
            newKb: Math.round(b.size / 1024),
            url: URL.createObjectURL(b),
            dataUrl: c.toDataURL("image/jpeg", quality)
          });
        }, "image/jpeg", quality);
      };
      im.onerror = function () { URL.revokeObjectURL(u); rej(new Error("img error")); };
      im.src = u;
    });
  }

  function printMergedPdf() {
    if (!st.pdfImages.length) { toast("اختر صورتين أو أكثر لدمجها في ملف PDF", "warning"); return; }
    var pages = st.pdfImages.map(function (im) {
      return '<div class="pg"><img src="' + im.dataUrl + '"></div>';
    }).join("");
    var html = '<!doctype html><html><head><meta charset="utf-8"><title>ملف الصور المدمج</title>' +
      '<style>@page{size:A4;margin:8mm}*{box-sizing:border-box}body{margin:0;padding:0}.pg{width:100%;height:280mm;display:flex;align-items:center;justify-content:center;page-break-after:always;break-after:page}.pg:last-child{page-break-after:auto;break-after:auto}.pg img{max-width:100%;max-height:100%;object-fit:contain;border-radius:6px}</style>' +
      '</head><body>' + pages + '</body></html>';
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
    toast("اختر «حفظ كملف PDF» من نافذة الطباعة لحفظ الصور كملف واحد ✓");
  }

  function drawLinkCard() {
    var cv = $("mtCardCv"); if (!cv) return;
    if ($("mtCTitle")) st.cardTitle = $("mtCTitle").value.trim() || st.cardTitle;
    if ($("mtCSub")) st.cardSub = $("mtCSub").value.trim() || st.cardSub;
    if ($("mtCCode")) st.cardCode = $("mtCCode").value.trim();
    if ($("mtCUrl")) st.cardUrl = $("mtCUrl").value.trim();

    var W = 1080, H = 1080;
    cv.width = W; cv.height = H;
    var ctx = cv.getContext("2d");
    ctx.direction = "rtl"; ctx.textAlign = "center"; ctx.textBaseline = "middle";

    var g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, "#0f172a"); g.addColorStop(0.5, "#1e1b4b"); g.addColorStop(1, "#0284c7");
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = "#fde047"; ctx.lineWidth = 8;
    if (ctx.roundRect) { ctx.beginPath(); ctx.roundRect(45, 45, W - 90, H - 90, 42); ctx.stroke(); }

    ctx.fillStyle = "#fde047"; ctx.font = "900 40px Cairo, Tahoma, sans-serif";
    ctx.fillText("🌟 منصة EduTech Mindset | عقلية التعليم والتكنولوجيا", W / 2, 145);

    ctx.fillStyle = "#ffffff"; ctx.font = "900 58px Cairo, Tahoma, sans-serif";
    ctx.fillText(st.cardTitle.slice(0, 34), W / 2, 290);

    ctx.fillStyle = "#38bdf8"; ctx.font = "800 36px Cairo, Tahoma, sans-serif";
    ctx.fillText(st.cardSub.slice(0, 45), W / 2, 385);

    if (st.cardCode) {
      ctx.fillStyle = "rgba(255,255,255,0.12)";
      ctx.strokeStyle = "#10b981"; ctx.lineWidth = 4;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(W / 2 - 260, 470, 520, 170, 28);
      else ctx.rect(W / 2 - 260, 470, 520, 170);
      ctx.fill(); ctx.stroke();

      ctx.fillStyle = "#a7f3d0"; ctx.font = "800 28px Cairo, Tahoma, sans-serif";
      ctx.fillText("🔑 رمز الدخول المباشر للطلاب:", W / 2, 518);
      ctx.fillStyle = "#ffffff"; ctx.font = "900 64px monospace";
      ctx.fillText(st.cardCode, W / 2, 588);
    }

    ctx.fillStyle = "#e2e8f0"; ctx.font = "700 30px Cairo, Tahoma, sans-serif";
    ctx.fillText("🔗 الرابط المباشر:", W / 2, 740);
    ctx.fillStyle = "#fde047"; ctx.font = "800 26px monospace";
    ctx.fillText(st.cardUrl.slice(0, 52), W / 2, 800);

    ctx.fillStyle = "#cbd5e1"; ctx.font = "700 28px Cairo, Tahoma, sans-serif";
    ctx.fillText("نصنع الأمل بالعلم من غزة 🇵🇸", W / 2, H - 105);
  }

  function paint() {
    var box = $("mtBody"); if (!box) return;
    var tabs = [
      ["compress", "🗜️ ضاغط الصور الفوري (توفير الإنترنت)"],
      ["img2pdf", "📄 دمج صور الدفتر أو الكتاب في PDF واحد"],
      ["linkcard", "🎴 مصمّم بطاقة دعوة اختبار أو فصل للواتساب"]
    ];
    var nav = '<div class="flex flex-wrap gap-2 mb-4 border-b border-slate-200 dark:border-slate-700 pb-3">' +
      tabs.map(function (t) {
        var on = st.tab === t[0];
        return '<button type="button" data-mttab="' + t[0] + '" class="px-4 py-2 rounded-xl text-xs font-extrabold transition-all ' + (on ? "bg-cyan-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">' + t[1] + '</button>';
      }).join("") + '</div>';

    if (st.tab === "compress") {
      box.innerHTML = nav + '<div class="space-y-4">' +
        '<div class="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">' +
        '<div><label class="block text-xs font-bold mb-1">درجة الضغط والوضوح</label><select id="mtCompQ" class="' + cls + '"><option value="0.5">ضغط عالٍ جداً (حجم صغير جداً)</option><option value="0.68" selected>متوازن (ممتاز للدفاتر والواتساب)</option><option value="0.82">جودة عالية</option></select></div>' +
        '<div><label class="block text-xs font-bold mb-1">أقصى عرض للصورة (بكسل)</label><select id="mtCompW" class="' + cls + '"><option value="900">900px (خفيف جداً)</option><option value="1280" selected>1280px (قياسي واضح)</option><option value="1600">1600px (عالي الدقة)</option></select></div>' +
        '<label class="py-2.5 px-4 rounded-xl bg-gradient-to-l from-cyan-600 to-blue-600 text-white text-xs font-black text-center cursor-pointer shadow">📂 اختر صوراً من جهازك لضغطها محلياً<input id="mtCompInp" type="file" accept="image/*" multiple class="hidden"></label>' +
        '</div>' +
        (st.compItems.length ? '<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">' +
          st.compItems.map(function (it) {
            var saved = Math.max(0, Math.round((1 - it.newKb / Math.max(1, it.origKb)) * 100));
            return '<div class="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex items-center gap-3">' +
              '<img src="' + it.url + '" class="w-16 h-16 object-cover rounded-xl border shrink-0">' +
              '<div class="min-w-0 flex-1 text-xs"><div class="font-extrabold truncate">' + e(it.name) + '</div>' +
              '<div class="text-[11px] text-emerald-600 font-black">' + it.origKb + ' KB ⬅ ' + it.newKb + ' KB (وفّر ' + saved + '%)</div>' +
              '<a href="' + it.url + '" download="' + e(it.name) + '" class="inline-block mt-1 px-3 py-1 rounded-lg bg-brand-600 text-white text-[11px] font-bold">⬇ تنزيل</a></div></div>';
          }).join("") + '</div>' : '<p class="text-xs text-slate-400 text-center py-6">اختر صورة أو عدة صور من هاتفك ليتم تقليص حجمها فوراً داخل متصفحك دون استهلاك للإنترنت.</p>') +
        '</div>';

      $("mtCompInp").onchange = function (ev) {
        var files = Array.prototype.slice.call(ev.target.files || []);
        var q = +$("mtCompQ").value || 0.68, w = +$("mtCompW").value || 1280;
        Promise.all(files.map(function (f) { return processImageFile(f, w, q); })).then(function (res) {
          st.compItems = res.concat(st.compItems).slice(0, 18);
          paint();
          toast("تم ضغط " + res.length + " صور بنجاح ✓");
        });
      };
    } else if (st.tab === "img2pdf") {
      box.innerHTML = nav + '<div class="space-y-4">' +
        '<div class="flex flex-wrap gap-2 items-center">' +
        '<label class="px-5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-black cursor-pointer shadow">➕ أضف صور صفحات الدفتر أو الكتاب<input id="mtPdfInp" type="file" accept="image/*" multiple class="hidden"></label>' +
        (st.pdfImages.length ? '<button type="button" id="mtMakePdf" class="px-5 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black shadow">🖨 دمج وحفظ (' + st.pdfImages.length + ' صفحات) كملف PDF واحد</button>' +
          '<button type="button" id="mtClearPdf" class="px-3.5 py-2.5 rounded-xl bg-rose-500/15 text-rose-600 text-xs font-bold">🗑 تفريغ</button>' : '') +
        '</div>' +
        (st.pdfImages.length ? '<div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2.5">' +
          st.pdfImages.map(function (im, i) {
            return '<div class="relative p-1.5 rounded-xl border bg-white dark:bg-slate-800 text-center">' +
              '<img src="' + im.dataUrl + '" class="w-full h-28 object-cover rounded-lg">' +
              '<div class="text-[10px] font-black mt-1">صفحة ' + (i + 1) + '</div></div>';
          }).join("") + '</div>' : '<p class="text-xs text-slate-400 text-center py-6">اختر صور صفحات الدفتر أو أوراق العمل لدمجها في ملف PDF واحد مرتب.</p>') +
        '</div>';

      $("mtPdfInp").onchange = function (ev) {
        var files = Array.prototype.slice.call(ev.target.files || []);
        Promise.all(files.map(function (f) { return processImageFile(f, 1300, 0.75); })).then(function (res) {
          st.pdfImages = st.pdfImages.concat(res);
          paint();
        });
      };
      if ($("mtMakePdf")) $("mtMakePdf").onclick = printMergedPdf;
      if ($("mtClearPdf")) $("mtClearPdf").onclick = function () { st.pdfImages = []; paint(); };
    } else if (st.tab === "linkcard") {
      box.innerHTML = nav + '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">' +
        '<div class="lg:col-span-6 space-y-3">' +
        '<div><label class="block text-xs font-bold mb-1">عنوان النشاط / الاختبار / اللعبة</label><input id="mtCTitle" value="' + e(st.cardTitle) + '" class="' + cls + '"></div>' +
        '<div><label class="block text-xs font-bold mb-1">الصف والتفاصيل</label><input id="mtCSub" value="' + e(st.cardSub) + '" class="' + cls + '"></div>' +
        '<div><label class="block text-xs font-bold mb-1">رمز الفصل أو رمز الغرفة PIN (اختياري)</label><input id="mtCCode" dir="ltr" value="' + e(st.cardCode) + '" class="' + cls + '"></div>' +
        '<div><label class="block text-xs font-bold mb-1">الرابط المباشر</label><input id="mtCUrl" dir="ltr" value="' + e(st.cardUrl) + '" class="' + cls + '"></div>' +
        '<button type="button" id="mtDlCard" class="w-full py-3 rounded-xl bg-emerald-600 text-white text-xs font-black shadow">⬇ تنزيل بطاقة الدعوة كصورة PNG للواتساب</button>' +
        '</div>' +
        '<div class="lg:col-span-6"><div class="rounded-2xl border-2 border-cyan-500/40 bg-slate-950 p-2 max-w-sm mx-auto"><canvas id="mtCardCv" class="w-full h-auto rounded-xl block"></canvas></div></div></div>';

      ["mtCTitle", "mtCSub", "mtCCode", "mtCUrl"].forEach(function (id) {
        $(id).oninput = drawLinkCard;
      });
      $("mtDlCard").onclick = function () {
        drawLinkCard();
        $("mtCardCv").toBlob(function (b) {
          var a = document.createElement("a");
          a.href = URL.createObjectURL(b);
          a.download = "بطاقة-دعوة-طلاب.png";
          document.body.appendChild(a); a.click();
          setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 600);
        }, "image/png");
      };
      setTimeout(drawLinkCard, 50);
    }

    box.querySelectorAll("[data-mttab]").forEach(function (b) {
      b.onclick = function () { st.tab = b.dataset.mttab; paint(); };
    });
  }

  function build() {
    if ($("mediaToolsStudio")) return true;
    var anchor = $("offPackStudio") || $("analyticsStudio") || $("teacherDash");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "mediaToolsStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-cyan-800 via-slate-800 to-slate-950 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-cyan-300 mb-1">🗜️ استوديو ضغط الصور ودمجها في PDF محلياً (بلا إنترنت)</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">قلّص حجم صور الهاتف بنسبة 85% وادمج صور الدفتر في ملف PDF واحد دون استهلاك للإنترنت</h2>' +
      '<p class="text-xs text-white/80 mt-1">معالجة فورية داخل جهازك لتسهيل إرسال الواجبات وأوراق العمل عبر الإنترنت الضعيف.</p>' +
      '</div><div class="p-4 sm:p-6 text-right" id="mtBody"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    paint();
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduMediaTools = { open: function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("mediaToolsStudio", true); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

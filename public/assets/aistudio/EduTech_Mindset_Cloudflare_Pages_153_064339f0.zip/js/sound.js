/*
 * الصوت المشترك للموقع: ملفات ترفعها الإدارة (R2) فيسمعها كل الزوار.
 * - تُدمج في مشغّل الموسيقى الحالي (قسم «صوتيات الموقع»).
 * - البدء التلقائي: شاشة دخول (الأضمن) أو عند أول نقرة/لمسة. (المتصفحات تمنع الصوت قبل تفاعل الزائر.)
 * التخزين: site/audio في Firestore.
 */
(function () {
  "use strict";
  var inp = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";
  var mini = "px-2 py-1.5 rounded-lg bg-slate-200/90 dark:bg-slate-700 text-[11px] hover:bg-slate-300 dark:hover:bg-slate-600";
  var CACHE = "edutech_audio_cache_v1";
  var DEF = { tracks: [], startMode: "gate", gateTitle: "أهلاً بك في عقلية التعليم والتكنولوجيا", gateText: "اضغط للدخول مع الموسيقى. يمكنك كتمها في أي وقت من المشغّل.", gateBtn: "ادخل الموقع 🎧", startTrackId: "", volume: 60 };
  var audio = Object.assign({}, DEF), started = false, gateShown = false, loaded = false;

  function esc(s) { return escapeHtml(s); }
  function cloud() { return !!(window.Cloud && window.Cloud.enabled); }
  function canEdit() { return typeof isSuperAdminUser === "function" && isSuperAdminUser(); }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function uid() { return "sa-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }
  function ss(k, v) { try { if (v === undefined) return sessionStorage.getItem(k); sessionStorage.setItem(k, v); } catch (e) {} }

  // ---------- دمج الصوتيات في المشغّل ----------
  var mergedSig = "";
  function merge() {
    if (typeof musicState === "undefined" || !musicState) return;
    var site = (audio.tracks || []).map(function (t) { return { id: t.id, title: "🎵 " + t.title, category: "صوتيات الموقع", kind: "custom", url: t.url, siteShared: true }; });
    var rest = (musicState.tracks || []).filter(function (t) { return !t.siteShared; });
    var sig = JSON.stringify(site) + "|" + rest.length;
    if (sig === mergedSig && (musicState.tracks || []).some(function (t) { return t.siteShared; }) === !!site.length) return;
    mergedSig = sig;
    musicState.tracks = site.concat(rest);
    try { if (typeof updateMusicUI === "function") updateMusicUI(); } catch (e) {}
  }

  // ---------- البدء ----------
  function startTrack() {
    var t = (audio.tracks || []).filter(function (x) { return x.id === audio.startTrackId; })[0] || (audio.tracks || [])[0];
    return t || null;
  }
  function play() {
    var t = startTrack(); if (!t || typeof musicState === "undefined" || started) return;
    started = true; merge();
    musicState.currentTrackId = t.id; musicState.isMuted = false; musicState.volume = Math.max(0, Math.min(100, +audio.volume || 60)); musicState.miniPlayerVisible = true;
    try { startMusicPlayback(); } catch (e) {}
  }
  function removeGate() { var g = document.getElementById("soundGate"); if (g) g.remove(); document.documentElement.classList.remove("modal-open"); }
  function showGate() {
    if (gateShown || document.getElementById("soundGate")) return; gateShown = true;
    var g = document.createElement("div"); g.id = "soundGate"; g.setAttribute("role", "dialog"); g.setAttribute("aria-modal", "true");
    g.className = "fixed inset-0 z-[95] flex items-center justify-center p-5 text-center bg-gradient-to-br from-slate-950 via-sky-950 to-slate-900";
    g.innerHTML = '<div class="max-w-md w-full"><div class="w-24 h-24 mx-auto rounded-3xl bg-white p-2 shadow-2xl mb-6"><img src="assets/logo.png" alt="" class="w-full h-full object-contain"></div>' +
      '<h1 class="text-2xl sm:text-3xl font-black text-white mb-3"></h1><p class="text-sm text-slate-300 leading-loose mb-8 whitespace-pre-line"></p>' +
      '<button type="button" id="sgGo" class="w-full sm:w-auto px-10 py-3.5 rounded-2xl bg-gradient-to-l from-amber-400 to-orange-500 text-slate-950 text-base font-black shadow-2xl hover:scale-105 transition-all"></button>' +
      '<div><button type="button" id="sgSkip" class="mt-4 text-xs text-slate-400 hover:text-white underline">متابعة بدون صوت</button></div></div>';
    g.querySelector("h1").textContent = audio.gateTitle || DEF.gateTitle; g.querySelector("p").textContent = audio.gateText || DEF.gateText; g.querySelector("#sgGo").textContent = audio.gateBtn || DEF.gateBtn;
    g.querySelector("#sgGo").addEventListener("click", function () { ss("edutech_gate_ok", "1"); removeGate(); play(); });
    g.querySelector("#sgSkip").addEventListener("click", function () { ss("edutech_gate_ok", "1"); removeGate(); });
    document.body.appendChild(g); document.documentElement.classList.add("modal-open");
    setTimeout(function () { var b = g.querySelector("#sgGo"); if (b) b.focus(); }, 50);
  }
  function arm() {
    if (!loaded || started || !startTrack() || ss("edutech_gate_ok")) return;
    if (audio.startMode === "gate") showGate();
    else if (audio.startMode === "first" && !arm.done) {
      arm.done = true;
      var go = function () { ["pointerup", "keydown", "touchend"].forEach(function (ev) { document.removeEventListener(ev, go, true); }); ss("edutech_gate_ok", "1"); play(); };
      ["pointerup", "keydown", "touchend"].forEach(function (ev) { document.addEventListener(ev, go, true); });
    }
  }

  // ---------- الحفظ ----------
  function save(a) {
    if (!canEdit()) return Promise.reject();
    audio = Object.assign({}, DEF, a);
    var data = { kind: "audio", tracks: audio.tracks, startMode: audio.startMode, gateTitle: audio.gateTitle, gateText: audio.gateText, gateBtn: audio.gateBtn, startTrackId: audio.startTrackId, volume: audio.volume };
    try { localStorage.setItem(CACHE, JSON.stringify(data)); } catch (e) {}
    merge();
    if (cloud()) return window.Cloud.commit([{ col: "site", id: "audio", data: data }]).catch(function (e) { showToast("تعذر الحفظ [" + ((e && e.code) || "؟") + "]", "warning"); throw e; });
    appState.audio = data; saveState(); return Promise.resolve();
  }

  // ---------- تبويب الإدارة ----------
  function tab(H) {
    var d = clone(audio); d.tracks = d.tracks || [];
    var removed = [];
    function draw() {
      var ready = window.EduMedia && window.EduMedia.ready();
      H.body.innerHTML =
        '<div class="space-y-3">' +
        (ready ? "" : '<div class="rounded-2xl bg-amber-50 dark:bg-amber-900/20 border border-amber-300/60 p-3 text-[11px] leading-relaxed text-amber-800 dark:text-amber-200"><b>رفع الملفات غير مفعّل بعد.</b> فعّل R2 وأضف الـ Binding باسم <span dir="ltr" class="font-mono">MEDIA</span> (الخطوات في ملف «دليل_الوسائط»). حتى ذلك يمكنك إضافة صوتيات برابط مباشر.</div>') +
        '<div><div class="text-[11px] font-bold mb-1">طريقة بدء الصوت</div><select id="saMode" class="' + inp + '"><option value="gate"' + (d.startMode === "gate" ? " selected" : "") + '>شاشة دخول بزر «ادخل الموقع» (الأضمن)</option><option value="first"' + (d.startMode === "first" ? " selected" : "") + '>مع أول نقرة أو لمسة في أي مكان</option><option value="off"' + (d.startMode === "off" ? " selected" : "") + '>لا يبدأ تلقائياً (متاح للزائر فقط)</option></select></div>' +
        '<div id="saGateBox" class="space-y-1.5"><input id="saGT" class="' + inp + '" placeholder="عنوان شاشة الدخول" value="' + esc(d.gateTitle) + '"><textarea id="saGX" rows="2" class="' + inp + '" placeholder="نص شاشة الدخول">' + esc(d.gateText) + '</textarea><input id="saGB" class="' + inp + '" placeholder="نص الزر" value="' + esc(d.gateBtn) + '"></div>' +
        '<div class="flex items-center gap-2"><label class="text-[11px] font-bold shrink-0">مستوى الصوت</label><input id="saVol" type="range" min="5" max="100" value="' + (d.volume || 60) + '" class="flex-1"><span id="saVolN" class="text-[11px] w-8">' + (d.volume || 60) + '</span></div>' +
        '<div class="text-[11px] font-bold">الملفات الصوتية (' + d.tracks.length + ')</div><div class="space-y-1.5" id="saList">' + (d.tracks.map(function (t, i) {
          return '<div class="rounded-2xl border border-slate-200 dark:border-slate-700 p-2 space-y-1.5" data-ti="' + i + '"><input class="' + inp + '" data-f="title" value="' + esc(t.title) + '" placeholder="اسم المقطع"><audio controls preload="none" src="' + esc(t.url) + '" class="w-full h-8"></audio>' +
            '<div class="flex flex-wrap gap-1.5 items-center"><label class="flex items-center gap-1 text-[11px] font-bold ml-auto"><input type="radio" name="saStart" data-start="' + i + '"' + ((d.startTrackId === t.id || (!d.startTrackId && i === 0)) ? " checked" : "") + '> يبدأ به الموقع</label>' +
            '<button type="button" data-top="up" data-i="' + i + '" class="' + mini + '"><i class="fa-solid fa-arrow-up"></i></button><button type="button" data-top="down" data-i="' + i + '" class="' + mini + '"><i class="fa-solid fa-arrow-down"></i></button><button type="button" data-top="del" data-i="' + i + '" class="' + mini + ' !text-rose-500"><i class="fa-solid fa-trash"></i></button></div></div>';
        }).join("") || '<div class="text-center text-xs text-slate-400 py-6 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl">لا توجد ملفات صوتية بعد.</div>') + '</div>' +
        '<div class="flex flex-wrap gap-2 items-center"><label class="px-4 py-2 rounded-xl ' + (ready ? "bg-brand-600 text-white cursor-pointer" : "bg-slate-200 text-slate-400") + ' text-xs font-bold"><i class="fa-solid fa-upload ml-1"></i>رفع ملفات صوتية<input id="saFile" type="file" accept="audio/*" multiple class="hidden"' + (ready ? "" : " disabled") + '></label>' +
        '<input id="saUrl" dir="ltr" class="' + inp + ' !w-52 text-left" placeholder="أو رابط ملف صوتي مباشر"><button type="button" id="saUrlAdd" class="' + mini + '">إضافة</button></div></div>';
      var mode = document.getElementById("saMode"), gb = document.getElementById("saGateBox");
      function vis() { gb.style.display = mode.value === "gate" ? "" : "none"; } mode.addEventListener("change", vis); vis();
      document.getElementById("saVol").addEventListener("input", function (e) { document.getElementById("saVolN").textContent = e.target.value; });
      H.body.onclick = function (e) {
        var o = e.target.closest("[data-top]"); if (!o) return; read();
        var op = o.dataset.top, i = +o.dataset.i, a = d.tracks, j = op === "up" ? i - 1 : i + 1;
        if (op === "del") { if (!window.eduConfirm("حذف هذا المقطع؟")) return; removed.push(a[i].url); a.splice(i, 1); }
        else { if (j < 0 || j >= a.length) return; var t = a[i]; a[i] = a[j]; a[j] = t; }
        draw();
      };
      document.getElementById("saFile").addEventListener("change", function (e) {
        var files = Array.prototype.slice.call(e.target.files); if (!files.length) return; read();
        files.reduce(function (p, f) { return p.then(function () { return window.EduMedia.upload(f, "audio").then(function (url) { d.tracks.push({ id: uid(), title: f.name.replace(/\.[^.]+$/, ""), url: url }); draw(); showToast("تم رفع: " + f.name + " ✓", "success"); }, function () {}); }); }, Promise.resolve());
      });
      document.getElementById("saUrlAdd").addEventListener("click", function () {
        var u = document.getElementById("saUrl").value.trim(); if (!/^https?:\/\//i.test(u)) { showToast("الصق رابطاً مباشراً يبدأ بـ https://", "warning"); return; }
        read(); d.tracks.push({ id: uid(), title: "مقطع جديد", url: u }); draw();
      });
    }
    function read() {
      var m = document.getElementById("saMode"); if (!m) return;
      d.startMode = m.value; d.gateTitle = document.getElementById("saGT").value.trim(); d.gateText = document.getElementById("saGX").value.trim(); d.gateBtn = document.getElementById("saGB").value.trim(); d.volume = +document.getElementById("saVol").value || 60;
      document.querySelectorAll("#saList [data-ti]").forEach(function (el) { var t = d.tracks[+el.dataset.ti]; if (t) t.title = el.querySelector('[data-f="title"]').value.trim() || "مقطع"; });
      var r = document.querySelector("#saList [data-start]:checked"); if (r && d.tracks[+r.dataset.start]) d.startTrackId = d.tracks[+r.dataset.start].id;
    }
    draw();
    H.foot('<button type="button" id="saSave" class="px-5 py-2 rounded-xl bg-brand-600 text-white text-xs font-bold">حفظ الصوت</button>');
    document.getElementById("saSave").addEventListener("click", function () {
      read(); if (d.startTrackId && !d.tracks.some(function (t) { return t.id === d.startTrackId; })) d.startTrackId = "";
      save(d).then(function () { removed.forEach(function (u) { if (window.EduMedia) window.EduMedia.remove(u); }); closeModal(); showToast("تم حفظ الصوت ✓ — يسمعه كل الزوار", "success"); });
    });
  }

  window.EduSound = { merge: merge, tab: tab, play: play };

  function applyData(d) {
    audio = Object.assign({}, DEF, d || {}); audio.tracks = audio.tracks || [];
    loaded = true; merge(); arm();
  }
  window.addEventListener("DOMContentLoaded", function () {
    setTimeout(function () {
      if (window.EduHome && window.EduHome.registerTab) window.EduHome.registerTab("audio", "الصوت", "fa-music", tab);
      var cached = null; try { cached = JSON.parse(localStorage.getItem(CACHE) || "null"); } catch (e) {}
      if (!cloud() || !window.Cloud.subscribeDoc) { applyData(appState.audio || cached); return; }
      if (cached) applyData(cached);
      window.Cloud.subscribeDoc("site", "audio", function (d) {
        if (d) { try { localStorage.setItem(CACHE, JSON.stringify(d)); } catch (e) {} }
        applyData(d);
      }, function () { loaded = true; });
    }, 60);
  });
})();

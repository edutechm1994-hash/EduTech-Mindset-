/* متتبّع صفحة مستوية خفيف (بلا مكتبات): نقاط Shi-Tomasi + تتبّع Lucas-Kanade هرمي + تحويل Homography بـ RANSAC.
 * المرجع T هو الإطار الذي التُقط عند «تعرّف»؛ كل نقطة تحتفظ بإحداثياتها في T، فيُحسب H من T إلى الإطار الحالي. */
(function (root) {
  "use strict";
  // ---------- أدوات المصفوفات 3x3 (صفّية) ----------
  function mul(a, b) { var r = new Array(9); for (var i = 0; i < 3; i++) for (var j = 0; j < 3; j++) r[i * 3 + j] = a[i * 3] * b[j] + a[i * 3 + 1] * b[3 + j] + a[i * 3 + 2] * b[6 + j]; return r; }
  function inv(m) {
    var a = m[0], b = m[1], c = m[2], d = m[3], e = m[4], f = m[5], g = m[6], h = m[7], i = m[8];
    var A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g, det = a * A + b * B + c * C;
    if (Math.abs(det) < 1e-12) return null;
    var k = 1 / det;
    return [A * k, -(b * i - c * h) * k, (b * f - c * e) * k, B * k, (a * i - c * g) * k, -(a * f - c * d) * k, C * k, -(a * h - b * g) * k, (a * e - b * d) * k];
  }
  function apply(H, x, y) { var w = H[6] * x + H[7] * y + H[8]; if (Math.abs(w) < 1e-9) w = 1e-9; return [(H[0] * x + H[1] * y + H[2]) / w, (H[3] * x + H[4] * y + H[5]) / w]; }
  function solveN(A, b, n) { // حل A x = b (n×n) بحذف غاوس مع محور جزئي
    for (var c = 0; c < n; c++) {
      var p = c, mx = Math.abs(A[c][c]);
      for (var r = c + 1; r < n; r++) if (Math.abs(A[r][c]) > mx) { mx = Math.abs(A[r][c]); p = r; }
      if (mx < 1e-12) return null;
      if (p !== c) { var t = A[p]; A[p] = A[c]; A[c] = t; var tb = b[p]; b[p] = b[c]; b[c] = tb; }
      for (var r2 = c + 1; r2 < n; r2++) { var f = A[r2][c] / A[c][c]; if (f) { for (var k = c; k < n; k++) A[r2][k] -= f * A[c][k]; b[r2] -= f * b[c]; } }
    }
    var x = new Array(n);
    for (var i = n - 1; i >= 0; i--) { var s = b[i]; for (var j = i + 1; j < n; j++) s -= A[i][j] * x[j]; x[i] = s / A[i][i]; }
    return x;
  }
  function normT(P) { // تحويل تطبيع: مركز 0 ومتوسط مسافة √2
    var n = P.length, cx = 0, cy = 0, i; for (i = 0; i < n; i++) { cx += P[i][0]; cy += P[i][1]; } cx /= n; cy /= n;
    var d = 0; for (i = 0; i < n; i++) d += Math.hypot(P[i][0] - cx, P[i][1] - cy); d /= n; var s = d > 1e-9 ? Math.SQRT2 / d : 1;
    return [s, 0, -s * cx, 0, s, -s * cy, 0, 0, 1];
  }
  function dlt(src, dst) { // src→dst بأقل مربعات (n ≥ 4)
    var n = src.length, Ts = normT(src), Td = normT(dst), AtA = [], Atb = new Array(8), i, j, k;
    for (i = 0; i < 8; i++) { AtA.push(new Array(8).fill(0)); Atb[i] = 0; }
    for (i = 0; i < n; i++) {
      var s = apply(Ts, src[i][0], src[i][1]), d = apply(Td, dst[i][0], dst[i][1]), x = s[0], y = s[1], u = d[0], v = d[1];
      var r1 = [x, y, 1, 0, 0, 0, -x * u, -y * u], r2 = [0, 0, 0, x, y, 1, -x * v, -y * v];
      for (j = 0; j < 8; j++) { for (k = 0; k < 8; k++) AtA[j][k] += r1[j] * r1[k] + r2[j] * r2[k]; Atb[j] += r1[j] * u + r2[j] * v; }
    }
    var h = solveN(AtA, Atb, 8); if (!h) return null;
    var Hn = [h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7], 1], Tdi = inv(Td); if (!Tdi) return null;
    var H = mul(Tdi, mul(Hn, Ts)), z = H[8]; if (Math.abs(z) < 1e-12) return null;
    for (i = 0; i < 9; i++) H[i] /= z; return H;
  }
  function sane(H) { // تحويل معقول: غير منحل ولا تضخيم مبالغ
    var det = H[0] * H[4] - H[1] * H[3]; if (!(det > 0.02 && det < 50)) return false;
    return Math.abs(H[6]) < 0.01 && Math.abs(H[7]) < 0.01;
  }
  function ransac(src, dst, thr, iters, rnd) {
    var n = src.length; if (n < 6) return null;
    var best = null, bestN = 0, i, k, idx = [0, 0, 0, 0];
    for (var it = 0; it < iters; it++) {
      for (k = 0; k < 4; k++) { var t; do { t = (rnd() * n) | 0; } while (idx.indexOf(t) !== -1 && k > 0 && idx.slice(0, k).indexOf(t) !== -1); idx[k] = t; }
      var s4 = [src[idx[0]], src[idx[1]], src[idx[2]], src[idx[3]]], d4 = [dst[idx[0]], dst[idx[1]], dst[idx[2]], dst[idx[3]]];
      var H = dlt(s4, d4); if (!H || !sane(H)) continue;
      var c = 0; for (i = 0; i < n; i++) { var p = apply(H, src[i][0], src[i][1]); if (Math.abs(p[0] - dst[i][0]) < thr && Math.abs(p[1] - dst[i][1]) < thr) c++; }
      if (c > bestN) { bestN = c; best = H; if (c > n * 0.9) break; }
    }
    if (!best || bestN < 6) return null;
    for (var rep = 0; rep < 2; rep++) { // إعادة ملاءمة على المقبولة
      var S = [], D = [], ids = [];
      for (i = 0; i < n; i++) { var q = apply(best, src[i][0], src[i][1]); if (Math.abs(q[0] - dst[i][0]) < thr && Math.abs(q[1] - dst[i][1]) < thr) { S.push(src[i]); D.push(dst[i]); ids.push(i); } }
      if (S.length < 6) return null; var H2 = dlt(S, D); if (!H2 || !sane(H2)) break; best = H2; if (rep === 1) return { H: best, inliers: ids };
    }
    var fin = []; for (i = 0; i < n; i++) { var q2 = apply(best, src[i][0], src[i][1]); if (Math.abs(q2[0] - dst[i][0]) < thr && Math.abs(q2[1] - dst[i][1]) < thr) fin.push(i); }
    return { H: best, inliers: fin };
  }

  // ---------- صور وهرم ----------
  function toGray(rgba, w, h) { var g = new Float32Array(w * h); for (var i = 0, j = 0; i < g.length; i++, j += 4) g[i] = 0.299 * rgba[j] + 0.587 * rgba[j + 1] + 0.114 * rgba[j + 2]; return g; }
  function down(src, w, h) { var w2 = w >> 1, h2 = h >> 1, o = new Float32Array(w2 * h2); for (var y = 0; y < h2; y++) for (var x = 0; x < w2; x++) { var i = (2 * y) * w + 2 * x; o[y * w2 + x] = (src[i] + src[i + 1] + src[i + w] + src[i + w + 1]) * 0.25; } return o; }
  function grads(g, w, h) { var gx = new Float32Array(w * h), gy = new Float32Array(w * h); for (var y = 1; y < h - 1; y++) for (var x = 1; x < w - 1; x++) { var i = y * w + x; gx[i] = (g[i + 1] - g[i - 1]) * 0.5; gy[i] = (g[i + w] - g[i - w]) * 0.5; } return { gx: gx, gy: gy }; }
  function pyr(g, w, h, L) { var P = [{ d: g, w: w, h: h }], i; for (i = 1; i < L; i++) { var p = P[i - 1]; P.push({ d: down(p.d, p.w, p.h), w: p.w >> 1, h: p.h >> 1 }); } for (i = 0; i < L; i++) { var gg = grads(P[i].d, P[i].w, P[i].h); P[i].gx = gg.gx; P[i].gy = gg.gy; } return P; }
  function bil(a, w, h, x, y) { if (x < 0 || y < 0 || x > w - 1.001 || y > h - 1.001) return NaN; var x0 = x | 0, y0 = y | 0, fx = x - x0, fy = y - y0, i = y0 * w + x0; return (a[i] * (1 - fx) + a[i + 1] * fx) * (1 - fy) + (a[i + w] * (1 - fx) + a[i + w + 1] * fx) * fy; }

  // ---------- نقاط Shi-Tomasi ----------
  function corners(g, w, h, maxN, minDist, mask, margin) {
    var gg = grads(g, w, h), N = w * h, Ixx = new Float32Array(N), Iyy = new Float32Array(N), Ixy = new Float32Array(N), i, x, y;
    for (i = 0; i < N; i++) { Ixx[i] = gg.gx[i] * gg.gx[i]; Iyy[i] = gg.gy[i] * gg.gy[i]; Ixy[i] = gg.gx[i] * gg.gy[i]; }
    function box(a) { var t = new Float32Array(N), o = new Float32Array(N), r = 2;
      for (y = 0; y < h; y++) { var s = 0; for (x = 0; x < w; x++) { s += a[y * w + x]; if (x > 2 * r) s -= a[y * w + x - 2 * r - 1]; if (x >= r) t[y * w + x - r] = s; } }
      for (x = 0; x < w; x++) { var s2 = 0; for (y = 0; y < h; y++) { s2 += t[y * w + x]; if (y > 2 * r) s2 -= t[(y - 2 * r - 1) * w + x]; if (y >= r) o[(y - r) * w + x] = s2; } }
      return o; }
    var A = box(Ixx), B = box(Ixy), C = box(Iyy), R = new Float32Array(N), mx = 0, m = margin || 10;
    for (y = m; y < h - m; y++) for (x = m; x < w - m; x++) { i = y * w + x; var tr = A[i] + C[i], df = A[i] - C[i], e = (tr - Math.sqrt(df * df + 4 * B[i] * B[i])) * 0.5; R[i] = e; if (e > mx) mx = e; }
    var thr = mx * 0.02, cand = [];
    for (y = m; y < h - m; y++) for (x = m; x < w - m; x++) { i = y * w + x; var v = R[i]; if (v < thr) continue; if (v >= R[i - 1] && v >= R[i + 1] && v >= R[i - w] && v >= R[i + w]) cand.push([x, y, v]); }
    cand.sort(function (a, b) { return b[2] - a[2]; });
    var cell = Math.max(3, minDist | 0), gw = Math.ceil(w / cell), gh = Math.ceil(h / cell), taken = new Uint8Array(gw * gh), out = [];
    if (mask) mask.forEach(function (p) { var cx = (p[0] / cell) | 0, cy = (p[1] / cell) | 0; if (cx >= 0 && cy >= 0 && cx < gw && cy < gh) taken[cy * gw + cx] = 1; });
    for (var k = 0; k < cand.length && out.length < maxN; k++) {
      var cx2 = (cand[k][0] / cell) | 0, cy2 = (cand[k][1] / cell) | 0, ok = true;
      for (var dy = -1; dy <= 1 && ok; dy++) for (var dx = -1; dx <= 1; dx++) { var gx2 = cx2 + dx, gy2 = cy2 + dy; if (gx2 >= 0 && gy2 >= 0 && gx2 < gw && gy2 < gh && taken[gy2 * gw + gx2]) { ok = false; break; } }
      if (ok) { taken[cy2 * gw + cx2] = 1; out.push([cand[k][0], cand[k][1]]); }
    }
    return out;
  }

  // ---------- Lucas-Kanade هرمي لنقطة واحدة ----------
  function lk(P0, P1, px, py, wr) {
    var L = P0.length, gx = 0, gy = 0, lvl, k, i, j;
    for (lvl = L - 1; lvl >= 0; lvl--) {
      var a = P0[lvl], b = P1[lvl], s = 1 / (1 << lvl), x0 = px * s, y0 = py * s;
      var gxx = 0, gxy = 0, gyy = 0, n = 0, win = [];
      for (j = -wr; j <= wr; j++) for (i = -wr; i <= wr; i++) {
        var xx = x0 + i, yy = y0 + j, I = bil(a.d, a.w, a.h, xx, yy), Ix = bil(a.gx, a.w, a.h, xx, yy), Iy = bil(a.gy, a.w, a.h, xx, yy);
        if (I !== I || Ix !== Ix) { win.push(null); continue; } win.push([i, j, I, Ix, Iy]); gxx += Ix * Ix; gxy += Ix * Iy; gyy += Iy * Iy; n++;
      }
      if (n < (2 * wr + 1) * (2 * wr + 1) * 0.6) return null;
      var det = gxx * gyy - gxy * gxy, me = ((gxx + gyy) - Math.sqrt((gxx - gyy) * (gxx - gyy) + 4 * gxy * gxy)) * 0.5 / n;
      if (det < 1e-6 || me < 0.5) { if (lvl === 0) return null; gx *= 2; gy *= 2; continue; }
      for (k = 0; k < 14; k++) {
        var bx = 0, by = 0;
        for (var q = 0; q < win.length; q++) { var w = win[q]; if (!w) continue; var J = bil(b.d, b.w, b.h, x0 + w[0] + gx, y0 + w[1] + gy); if (J !== J) return null; var dI = w[2] - J; bx += dI * w[3]; by += dI * w[4]; }
        var dx = (gyy * bx - gxy * by) / det, dy = (-gxy * bx + gxx * by) / det; gx += dx; gy += dy;
        if (dx * dx + dy * dy < 0.0009) break;
      }
      if (lvl > 0) { gx *= 2; gy *= 2; }
    }
    var nx = px + gx, ny = py + gy; return [nx, ny];
  }

  // ---------- المتتبّع ----------
  function Tracker(o) {
    o = o || {}; this.maxPts = o.maxPts || 140; this.levels = o.levels || 3; this.wr = o.wr || 6; this.thr = o.thr || 3.2; this.minInliers = o.minInliers || 9;
    this.seed = 12345; var self = this; this.rnd = function () { self.seed = (self.seed * 1664525 + 1013904223) >>> 0; return self.seed / 4294967296; };
    this.pts = []; this.H = [1, 0, 0, 0, 1, 0, 0, 0, 1]; this.prev = null; this.frame = 0; this.lostFor = 0; this.ok = false;
  }
  Tracker.prototype.init = function (rgba, w, h) {
    var g = toGray(rgba, w, h); this.w = w; this.h = h; this.prev = pyr(g, w, h, this.levels);
    var c = corners(g, w, h, this.maxPts, 9, null, 10);
    this.pts = c.map(function (p) { return { t: [p[0], p[1]], c: [p[0], p[1]] }; });
    this.H = [1, 0, 0, 0, 1, 0, 0, 0, 1]; this.ok = this.pts.length >= this.minInliers; this.lostFor = 0; this.frame = 0;
    return this.pts.length;
  };
  Tracker.prototype.update = function (rgba) {
    if (!this.prev) return { ok: false, inliers: 0, H: this.H };
    var w = this.w, h = this.h, g = toGray(rgba, w, h), cur = pyr(g, w, h, this.levels), keep = [], i;
    for (i = 0; i < this.pts.length; i++) {
      var p = this.pts[i], r = lk(this.prev, cur, p.c[0], p.c[1], this.wr);
      if (r && r[0] > 3 && r[1] > 3 && r[0] < w - 3 && r[1] < h - 3) {
        var back = lk(cur, this.prev, r[0], r[1], this.wr); // فحص رجوعي
        if (back && Math.hypot(back[0] - p.c[0], back[1] - p.c[1]) < 1.2) { p.c = r; keep.push(p); }
      }
    }
    this.pts = keep; this.prev = cur; this.frame++;
    var src = keep.map(function (p) { return p.t; }), dst = keep.map(function (p) { return p.c; });
    var res = ransac(src, dst, this.thr, 70, this.rnd), ok = false;
    if (res && res.inliers.length >= this.minInliers) {
      this.H = res.H; this.pts = res.inliers.map(function (k) { return keep[k]; }); ok = true; this.lostFor = 0;
      // تعويض النقاط المفقودة بنقاط جديدة (إحداثياتها في T عبر H^-1)
      if (this.pts.length < this.maxPts * 0.7 && this.frame % 4 === 0) {
        var Hi = inv(this.H), mask = this.pts.map(function (p) { return p.c; });
        if (Hi) corners(g, w, h, this.maxPts - this.pts.length, 9, mask, 10).forEach(function (c) { var t = apply(Hi, c[0], c[1]); this.pts.push({ t: t, c: [c[0], c[1]] }); }, this);
      }
    } else { this.lostFor++; }
    this.ok = ok; return { ok: ok, inliers: ok ? res.inliers.length : 0, H: this.H, pts: this.pts.length };
  };
  Tracker.prototype.project = function (x, y) { return apply(this.H, x, y); };

  var api = { Tracker: Tracker, _m: { mul: mul, inv: inv, apply: apply, dlt: dlt, ransac: ransac } };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.EduTrack = api;
})(typeof window !== "undefined" ? window : this);

/* a11y.js (الإصدار 75):
 * 1) يضيف aria-label للأزرار الأيقونية تلقائياً لدعم قارئات الشاشة.
 * 2) يوفر نظام تكبير الخط المرن (100% / 110% / 120%) ووضع التباين المريح للقراءة لجميع المستخدمين. */
(function () {
  "use strict";
  var MAP = { "fa-xmark": "إغلاق", "fa-times": "إغلاق", "fa-rotate-left": "تراجع", "fa-trash": "حذف", "fa-pen": "تعديل", "fa-plus": "إضافة", "fa-copy": "نسخ", "fa-download": "تنزيل", "fa-share": "مشاركة", "fa-print": "طباعة", "fa-play": "تشغيل", "fa-pause": "إيقاف مؤقت" };
  var SCALE_KEY = "edu_font_scale_v75";
  var scales = [100, 108, 116];
  var curScale = 100;
  try {
    var sv = parseInt(localStorage.getItem(SCALE_KEY) || "100", 10);
    if (scales.indexOf(sv) !== -1) curScale = sv;
  } catch (e) {}

  function applyScale(s) {
    curScale = s || 100;
    try { localStorage.setItem(SCALE_KEY, String(curScale)); } catch (e) {}
    document.documentElement.style.fontSize = curScale === 100 ? "" : curScale + "%";
  }

  function cycleScale() {
    var idx = (scales.indexOf(curScale) + 1) % scales.length;
    applyScale(scales[idx]);
    if (typeof showToast === "function") {
      showToast("🔠 حجم خط المنصة الآن: " + curScale + "%", "info");
    }
    if (window.EduBoost && window.EduBoost.repaint) {
      try { window.EduBoost.repaint(); } catch (x) {}
    }
    return curScale;
  }

  function fix(root) {
    var list = (root.querySelectorAll ? root.querySelectorAll("button:not([aria-label])") : []);
    for (var i = 0; i < list.length; i++) {
      var b = list[i];
      if ((b.textContent || "").trim() || b.title) { if (b.title) b.setAttribute("aria-label", b.title); continue; }
      var ic = b.querySelector("i"), lab = "";
      if (ic) for (var k in MAP) if (ic.classList.contains(k)) { lab = MAP[k]; break; }
      if (lab) b.setAttribute("aria-label", lab);
    }
  }
  var t;
  function sched() { clearTimeout(t); t = setTimeout(function () { fix(document); }, 300); }
  function init() {
    applyScale(curScale);
    fix(document);
    window.addEventListener('edu:lazy-ready', function () { setTimeout(function () { fix(document); }, 400); });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();

  window.EduA11y = {
    cycleFont: cycleScale,
    getScale: function () { return curScale; }
  };
})();

/* قسم «الكتب والمناهج»: عرض الكتب حسب المرحلة، معاينتها وقراءتها تفاعلياً داخل الموقع، وأخذ الدروس والفقرات مباشرة لباقي الأدوات */
(function () {
  "use strict";
  var cloudBooks = [], ready = false, filter = "", query = "", fGrade = "", fSub = "", fTerm = "";
  var GR = ["الأول الأساسي", "الثاني الأساسي", "الثالث الأساسي", "الرابع الأساسي", "الخامس الأساسي", "السادس الأساسي", "السابع", "الثامن", "التاسع", "العاشر", "الحادي عشر", "الثاني عشر"];
  var GKEY = ["الحادي عشر", "الثاني عشر", "الأول", "الثاني", "الثالث", "الرابع", "الخامس", "السادس", "السابع", "الثامن", "التاسع", "العاشر"];
  var NONE = "__none__";
  // صفوف المرحلة: تُستخرج من نص المرحلة «الصفوف a - b»، وإلا فلا صفوف (مثل الجامعية)
  function gradesOf(stage) {
    var m = /(\d+)\s*[-–—إلى]+\s*(\d+)/.exec(String(stage || "").replace(/[٠-٩]/g, function (d) { return d.charCodeAt(0) - 1632; }));
    if (!m) return [];
    var a = Math.max(1, +m[1]), z = Math.min(12, +m[2]), o = []; for (var i = a; i <= z; i++) o.push(GR[i - 1]); return o;
  }
  function guessGrade(b) {
    if (b.grade) return b.grade;
    var t = String(b.title || "").replace(/(الجزء|الفصل|القسم|الوحدة)\s+\S+/g, " ").replace(/[أإآ]/g, "ا"), gl = gradesOf(b.stage); if (!gl.length) return "";
    for (var k = 0; k < GKEY.length; k++) { var key = GKEY[k].replace(/[أإآ]/g, "ا"); if (t.indexOf(key) !== -1) { var g = GR.filter(function (x) { return x.indexOf(GKEY[k]) === 0 && (GKEY[k].length > 6 || !/عشر/.test(x) || /عشر/.test(GKEY[k])); })[0]; if (g && gl.indexOf(g) !== -1) return g; } }
    return "";
  }
  function termOf(b) { return b.term === "1" || b.term === "2" ? b.term : ""; }
  var TERM = { "1": "الفصل الأول", "2": "الفصل الثاني" };
  var chipOn = "px-3 py-1.5 rounded-full bg-brand-600 text-white text-[11px] font-extrabold whitespace-nowrap shrink-0", chipOff = "px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-[11px] font-bold whitespace-nowrap shrink-0 border border-slate-200 dark:border-slate-700";
  function chip(attr, val, label, n, on) { return '<button type="button" ' + attr + '="' + esc(val) + '" class="' + (on ? chipOn : chipOff) + '">' + esc(label) + (n != null ? ' <span class="opacity-70">(' + n + ")</span>" : "") + "</button>"; }

  // تعبئة أدوات المعلم والطالب (ورقة عمل / اختبار / خطة / عرض / معلم ذكي / مراجعة) من بيانات الكتاب أو الدرس
  var TOOLS = {
    lk: ["lessonKitStudio", "lkTitle", "lkGrade", "lkSubject", "حقيبة الحصة الجاهزة"],
    ws: ["worksheetStudio", "wsTopic", "wsGrade", "wsSubject", "ورقة عمل"],
    ex: ["worksheetStudio", "wsTopic", "wsGrade", "wsSubject", "اختبار"],
    lp: ["lessonPlanStudio", "lpTopic", "lpGrade", "lpSubject", "خطة درس"],
    sl: ["slidesStudio", "slTopic", "slGrade", "slSubject", "عرض تقديمي"],
    gm: ["gamesStudio", "gmTopic", "gmGrade", "gmSubject", "لعبة تفاعلية"],
    tu: ["tutorStudio", "tuTopic", "tuGrade", "tuSubject", "المعلم الذكي والخرائط الذهنية"],
    rv: ["reviewStudio", "rvDeck", "lkGrade", "lkSubject", "المراجعة الذكية بالتكرار المتباعد"]
  };
  function applyTool(kind, b, ls) {
    var t = TOOLS[kind], sec = document.getElementById(t[0]);
    if (!sec) { showToast("أداة " + t[4] + " غير متاحة الآن", "warning"); return; }
    var g = guessGrade(b);
    var fullLessonNotes = ls ? ((ls.k && ls.k.length ? "المفاهيم الأساسية:\n• " + ls.k.join("\n• ") + "\n\n" : "") + (ls.x || "")) : "";
    if (window.EduBridge && window.EduBridge.openTool) {
      window.EduBridge.openTool(t[0], {
        title: ls ? (ls.t + " — " + b.title) : b.title,
        topic: ls ? (ls.t + " — " + b.title) : b.title,
        grade: g,
        subject: b.subject || "",
        notes: fullLessonNotes,
        kind: kind === "ex" ? "exam" : (kind === "ws" ? "worksheet" : "")
      });
      showToast(ls ? "جاهز: " + t[4] + " لدرس «" + ls.t + "» — اضغط ولّد ✓" : "جهّزنا " + t[4] + " للمرحلة والمادة ✓", "success");
      return;
    }
    var tp = document.getElementById(t[1]), gr = document.getElementById(t[2]), sb = document.getElementById(t[3]);
    if (tp) {
      if (ls) tp.value = ("الدرس: " + ls.t + " — من كتاب: " + b.title + (b.subject ? " (" + b.subject + ")" : "") + (fullLessonNotes ? "\n\nنص الدرس:\n" + fullLessonNotes : "")).slice(0, 5900);
      else if (!tp.value.trim()) tp.value = (b.noBook ? "المادة: " : "من كتاب: ") + b.title + (b.subject ? " (" + b.subject + ")" : "") + " — اكتب هنا الدرس أو الوحدة";
    }
    if (gr && g) { for (var i = 0; i < gr.options.length; i++) if (gr.options[i].value === g || gr.options[i].text === g) { gr.value = gr.options[i].value; break; } }
    if (sb) sb.value = b.subject || "";
    if (kind === "ex") { var kd = document.getElementById("wsKind"); if (kd) kd.value = "exam"; } else if (kind === "ws") { var kd2 = document.getElementById("wsKind"); if (kd2) kd2.value = "worksheet"; }
    if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump(t[0], true); else sec.scrollIntoView({ behavior: "smooth", block: "start" });
    if (!ls) setTimeout(function () { if (tp) { tp.focus(); var v = tp.value, k = v.indexOf("— اكتب"); if (k > -1 && tp.setSelectionRange) tp.setSelectionRange(k, v.length); } }, 500);
    showToast(ls ? "جاهز: " + t[4] + " لدرس «" + ls.t + "» — اضغط ولّد" : "جهّزنا " + t[4] + " للمرحلة والمادة، اكتب الدرس أو صوّر صفحته ثم ولّد", "success");
  }
  // منتقي الدروس: إن كان للكتاب قائمة دروس يختار المعلم/الطالب منها أو يفتحه في القارئ التفاعلي
  function useTool(kind, b) {
    var ls = (b.lessons || []).filter(function (x) { return x && x.t; });
    if (!ls.length) return applyTool(kind, b, null);
    showModalContent('<div class="p-4 shrink-0 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50"><h3 class="text-sm font-extrabold">اختر الدرس من الكتاب — ' + esc(TOOLS[kind][4]) + '</h3><button type="button" class="p-2 text-slate-400" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button></div>' +
      '<div class="p-3 overflow-y-auto flex-1 min-h-0 space-y-1.5 text-right"><div class="flex items-center justify-between mb-1.5"><p class="text-[11px] font-bold text-slate-500">' + esc(b.title) + '</p>' +
      '<button type="button" id="bkModalOpenReader" class="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 text-[10px] font-black">📖 افتح الكتاب في القارئ التفاعلي لتحديد فقرة</button></div>' +
      ls.map(function (x, i) { return '<div class="flex items-center gap-1.5"><button type="button" data-pl="' + i + '" class="flex-1 text-right px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-brand-500 text-xs font-bold flex items-center justify-between gap-2"><span>' + esc(x.t) + '</span>' + (x.x ? '<span class="text-[10px] text-emerald-600 shrink-0">📄 النص جاهز للنقل</span>' : "") + '</button><button type="button" data-pl-read="' + i + '" class="px-2.5 py-2.5 rounded-xl bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 text-[11px] font-black shrink-0" title="معاينة وقراءة هذا الدرس في القارئ التفاعلي">📖 اقرأ</button></div>'; }).join("") +
      '<button type="button" data-pl="-1" class="w-full text-right px-3 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-700 text-[11px] font-bold">بدون درس محدد (أكتب الموضوع أو أصوّر صفحة)</button></div>');
    document.querySelectorAll("[data-pl]").forEach(function (x) { x.addEventListener("click", function () { var i = +x.dataset.pl; closeModal(); applyTool(kind, b, i < 0 ? null : ls[i]); }); });
    document.querySelectorAll("[data-pl-read]").forEach(function (x) { x.addEventListener("click", function () { var i = +x.dataset.plRead; closeModal(); if (window.EduBookReader && window.EduBookReader.open) window.EduBookReader.open(b.id, i, "interactive"); }); });
    var rBtn = document.getElementById("bkModalOpenReader");
    if (rBtn) rBtn.addEventListener("click", function () { closeModal(); if (window.EduBookReader && window.EduBookReader.open) window.EduBookReader.open(b.id, 0, "interactive"); });
  }
  var inp = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";
  function esc(s) { return escapeHtml(s); }
  function cloud() { return !!(window.Cloud && window.Cloud.enabled); }
  function canEdit() { return typeof isModeratorOrAdmin === "function" && isModeratorOrAdmin(); }
  function isAdm() { return typeof isSuperAdminUser === "function" && isSuperAdminUser(); }
  function stages() { var s = (appState.stages || []).filter(Boolean); return s.length ? s : ["الابتدائية (الصفوف 1 - 4)", "المتوسطة / الإعدادية (الصفوف 5 - 9)", "الثانوية (الصفوف 10 - 12)", "الجامعية والتعليم المستمر"]; }
  function books() {
    var base = cloud() ? cloudBooks : (appState.books || []);
    var builtins = (window.EduBookReader && typeof window.EduBookReader.builtinBooks === "function") ? window.EduBookReader.builtinBooks() : [];
    if (!builtins.length) return base;
    var seen = {};
    var out = [];
    base.forEach(function (b) { if (b && b.id) { seen[b.id] = 1; out.push(b); } });
    builtins.forEach(function (b) { if (b && b.id && !seen[b.id]) out.push(b); });
    return out;
  }

  function save(list) { // list: [{id,data}] ، حذف: {id,remove:true}
    if (cloud()) {
      var ops = list.map(function (x) { return x.remove ? { col: "books", id: x.id, remove: true } : { col: "books", id: x.id, data: x.data }; });
      return window.Cloud.commit(ops);
    }
    var cur = (appState.books || []).slice();
    list.forEach(function (x) {
      var i = cur.findIndex(function (b) { return b.id === x.id; });
      if (x.remove) { if (i > -1) cur.splice(i, 1); } else { var o = Object.assign({ id: x.id }, x.data); if (i > -1) cur[i] = o; else cur.unshift(o); }
    });
    appState.books = cur; saveState(); return Promise.resolve();
  }
  function fail(e) { showToast("تعذر حفظ الكتاب [" + ((e && e.code) || "؟") + "] — تأكد من نشر قواعد الأمان الجديدة وتسجيل دخولك", "warning"); }

  function ensure() {
    if (document.getElementById("booksSection")) return;
    var lib = document.getElementById("library"); if (!lib) return;
    var s = document.createElement("section");
    s.id = "booksSection"; s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"><div class="flex flex-wrap items-end justify-between gap-3 mb-5"><div><h2 class="text-2xl font-black text-slate-900 dark:text-white"><i class="fa-solid fa-book text-brand-500 ml-2"></i>الكتب والمناهج والقارئ التفاعلي</h2><p class="text-xs text-slate-500 mt-1">تصفّح الكتب المدرسية، افتح معاينتها وقراءتها التفاعلية، وخذ منها مباشرة لأي أداة</p></div>' +
      '<div class="flex flex-wrap items-center gap-2">' +
      '<button type="button" id="bkOpenReaderStudioBtn" class="px-4 py-2 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 text-slate-950 text-xs font-black shadow flex items-center gap-1.5"><span>📖 قارئ ومعاين الكتب التفاعلي</span></button>' +
      '<button type="button" id="bkFilterMyProfileBtn" class="px-3.5 py-2 rounded-xl bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 border border-indigo-500/30 text-xs font-extrabold">🎯 كتبي حسب صفي المفضّل</button>' +
      '<div id="bkAdminBtns" class="hidden gap-2"><button type="button" id="bkAdd" class="px-4 py-2 rounded-xl bg-brand-600 text-white text-xs font-extrabold"><i class="fa-solid fa-plus ml-1"></i>إضافة كتاب</button><button type="button" id="bkBulk" class="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 text-xs font-extrabold">إضافة عدة كتب</button></div></div></div>' +
      '<div class="mb-3"><input id="bkSearch" class="' + inp + '" placeholder="ابحث عن كتاب أو مادة أو وحدة دراسية…"></div>' +
      '<div id="bkNav" class="space-y-2 mb-4"></div>' +
      '<div id="bkGrid" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-4"></div></div>';
    lib.parentNode.insertBefore(s, lib);
    document.getElementById("bkSearch").addEventListener("input", function (e) { query = e.target.value.trim(); render(); });
    document.getElementById("bkAdd").addEventListener("click", function () { openForm(); });
    document.getElementById("bkBulk").addEventListener("click", openBulk);
    document.getElementById("bkOpenReaderStudioBtn").addEventListener("click", function () {
      if (window.EduBookReader && window.EduBookReader.open) window.EduBookReader.open(null, 0, "interactive");
    });
    document.getElementById("bkFilterMyProfileBtn").addEventListener("click", function () {
      var prof = (window.EduPersonalize && window.EduPersonalize.getProfile) ? window.EduPersonalize.getProfile() : {};
      if (!prof.grade && !prof.subject) {
        if (window.EduPersonalize && window.EduPersonalize.open) window.EduPersonalize.open();
        return;
      }
      query = (prof.subject || prof.grade || "").replace(/^الصف\s+/, "");
      var sInp = document.getElementById("bkSearch");
      if (sInp) sInp.value = query;
      render();
      showToast("🎯 تمت تصفية الكتب حسب ملفك الشخصي («" + query + "»)", "info");
    });
    var nav = document.querySelector('nav a[href="#library"]');
    if (nav && false) {
      var a = document.createElement("a"); a.id = "navBooksLink"; a.href = "#booksSection"; a.className = nav.className;
      a.innerHTML = '<i class="fa-solid fa-book text-slate-400"></i>الكتب'; nav.parentNode.insertBefore(a, nav);
    }
  }

  function render() {
    ensure();
    var grid = document.getElementById("bkGrid"), nav = document.getElementById("bkNav"); if (!grid || !nav) return;
    var ed = canEdit(), all = books();
    document.getElementById("bkAdminBtns").className = ed ? "flex gap-2" : "hidden";
    var q = query.toLowerCase(), st = stages(), cnt = function (f) { return all.filter(f).length; };
    if (filter && st.indexOf(filter) === -1) filter = "";
    var gl = filter ? gradesOf(filter) : [];
    if (fGrade && fGrade !== NONE && gl.indexOf(fGrade) === -1) fGrade = "";
    var inStage = all.filter(function (b) { return !filter || b.stage === filter; });
    var inGrade = inStage.filter(function (b) { return !fGrade || (fGrade === NONE ? (gl.length && !guessGrade(b)) : guessGrade(b) === fGrade); });
    var subs = {}; inGrade.forEach(function (b) { var k = (b.subject || "").trim() || NONE; subs[k] = (subs[k] || 0) + 1; });
    var subKeys = Object.keys(subs).sort(function (x, y) { return subs[y] - subs[x] || x.localeCompare(y, "ar"); });
    if (fSub && !subs[fSub]) fSub = "";
    var hasTerm = inGrade.some(termOf);
    if (fTerm && !hasTerm) fTerm = "";
    var h = '<div class="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">' + chip("data-fs", "", "كل المراحل", all.length, !filter) + st.filter(function (x) { return ed || cnt(function (b) { return b.stage === x; }); }).map(function (x) { return chip("data-fs", x, x.replace(/\s*\(.*\)\s*$/, ""), cnt(function (b) { return b.stage === x; }), filter === x); }).join("") + "</div>";
    if (gl.length) {
      var unc = inStage.filter(function (b) { return !guessGrade(b); }).length;
      h += '<div class="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">' + chip("data-fg", "", "كل الصفوف", inStage.length, !fGrade) + gl.filter(function (g) { return ed || inStage.some(function (b) { return guessGrade(b) === g; }); }).map(function (g) { return chip("data-fg", g, g, inStage.filter(function (b) { return guessGrade(b) === g; }).length, fGrade === g); }).join("") + (unc ? chip("data-fg", NONE, "غير مصنّف", unc, fGrade === NONE) : "") + "</div>";
    }
    if (subKeys.length > 1) h += '<div class="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">' + chip("data-fb", "", "كل المواد", inGrade.length, !fSub) + subKeys.map(function (k) { return chip("data-fb", k, k === NONE ? "بدون مادة" : k, subs[k], fSub === k); }).join("") + "</div>";
    if (hasTerm) h += '<div class="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">' + chip("data-ft", "", "الفصلان", null, !fTerm) + chip("data-ft", "1", TERM["1"], null, fTerm === "1") + chip("data-ft", "2", TERM["2"], null, fTerm === "2") + "</div>";
    nav.innerHTML = h;
    var on = function (attr, fn) { nav.querySelectorAll("[" + attr + "]").forEach(function (x) { x.addEventListener("click", function () { fn(x.getAttribute(attr)); render(); }); }); };
    on("data-fs", function (v) { filter = v; fGrade = ""; fSub = ""; fTerm = ""; });
    on("data-fg", function (v) { fGrade = v; fSub = ""; fTerm = ""; });
    on("data-fb", function (v) { fSub = v; });
    on("data-ft", function (v) { fTerm = v; });

    var list = (q ? all : inGrade).filter(function (b) {
      if (q) {
        var lsTxt = (b.lessons || []).map(function (l) { return l.t || ""; }).join(" ");
        return (b.title + " " + (b.subject || "") + " " + (b.author || "") + " " + (b.stage || "") + " " + (b.grade || "") + " " + lsTxt).toLowerCase().indexOf(q) !== -1;
      }
      return (!fSub || ((b.subject || "").trim() || NONE) === fSub) && (!fTerm || termOf(b) === fTerm);
    }).sort(function (a, b) { return (GR.indexOf(guessGrade(a)) - GR.indexOf(guessGrade(b))) || String(a.subject || "").localeCompare(String(b.subject || ""), "ar") || (termOf(a) || "9").localeCompare(termOf(b) || "9") || String(a.title).localeCompare(String(b.title), "ar"); });
    if (!list.length) { grid.innerHTML = '<div class="col-span-full text-center text-xs text-slate-400 py-10">' + (all.length ? "لا كتب مطابقة لهذا الاختيار." : (ed ? "لا توجد كتب بعد. اضغط «إضافة كتاب» أو «إضافة عدة كتب»." : "سيتم إضافة الكتب قريباً.")) + "</div>"; return; }
    var tb = "px-1.5 py-1 rounded-md text-[10px] font-bold text-center ";
    grid.innerHTML = list.map(function (b) {
      var has = b.url && b.url.trim(), g = guessGrade(b);
      var lsCount = (b.lessons || []).length;
      var cover = b.cover ? '<img src="' + esc(safeUrl(b.cover)) + '" alt="" loading="lazy" class="w-full h-full object-cover">' : '<div class="w-full h-full flex flex-col items-center justify-center gap-2 bg-gradient-to-br from-brand-600/15 via-indigo-500/10 to-emerald-500/15 text-brand-600 dark:text-sky-300 p-4 text-center"><i class="fa-solid fa-book-open-reader text-4xl"></i><span class="text-[11px] font-black">' + esc(b.subject || "كتاب منهجي") + '</span></div>';
      var tags = [g, termOf(b) ? TERM[termOf(b)] : "", lsCount ? (lsCount + " فصول تفاعلية") : ""].filter(Boolean).map(function (x) { return '<span class="text-[9px] font-bold px-2 py-0.5 rounded-md bg-brand-500/10 text-brand-600 dark:text-brand-300">' + esc(x) + "</span>"; }).join("");
      return '<div class="glass-card rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 flex flex-col"><div class="aspect-[16/10] bg-slate-100 dark:bg-slate-800 relative">' + cover +
        '<button type="button" data-bopen="' + esc(b.id) + '" class="absolute bottom-2 right-2 left-2 px-2.5 py-1.5 rounded-xl bg-slate-950/85 hover:bg-amber-500 text-amber-300 hover:text-slate-950 text-[11px] font-black backdrop-blur-sm shadow flex items-center justify-center gap-1.5 transition"><i class="fa-solid fa-book-open"></i><span>معاينة وقراءة الكتاب + أخذ للأدوات</span></button></div>' +
        '<div class="p-3 flex flex-col gap-1 flex-grow"><h3 class="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white leading-snug">' + esc(b.title) + '</h3>' +
        '<div class="text-[10px] text-slate-500">' + esc([b.subject, b.author].filter(Boolean).join(" • ")) + '</div>' +
        (tags ? '<div class="flex flex-wrap gap-1 mt-0.5">' + tags + "</div>" : "") +
        '<div class="mt-auto pt-2 flex items-center gap-1.5">' +
        '<button type="button" data-bopen="' + esc(b.id) + '" class="flex-1 text-center px-2 py-1.5 rounded-lg bg-brand-600 hover:bg-brand-500 text-white text-[11px] font-extrabold">📖 اقرأ وخذ للأدوات</button>' +
        (has ? '<a href="' + esc(/^\/api\/media\//.test(b.url) ? location.origin + b.url : safeUrl(b.url)) + '" target="_blank" rel="noopener" class="px-2.5 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-[11px] font-bold" title="فتح الرابط الأصلي">↗</a>' : '') +
        (ed && !b.builtin ? '<button type="button" data-be="' + esc(b.id) + '" class="px-2 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-[11px]"><i class="fa-solid fa-pen"></i></button>' : "") +
        (isAdm() && !b.builtin ? '<button type="button" data-bd="' + esc(b.id) + '" class="px-2 py-1.5 rounded-lg bg-rose-500/10 text-rose-500 text-[11px]"><i class="fa-solid fa-trash"></i></button>' : "") + "</div>" +
        '<div class="grid grid-cols-2 gap-1 pt-1.5 border-t border-slate-200/70 dark:border-slate-700/70 mt-1.5" data-tl="' + esc(b.id) + '"><button type="button" data-tk="lk" class="' + tb + 'col-span-2 bg-indigo-500/15 text-indigo-700 dark:text-indigo-300">🧳 حقيبة الحصة الكاملة</button><button type="button" data-tk="ws" class="' + tb + 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">📝 ورقة عمل</button><button type="button" data-tk="ex" class="' + tb + 'bg-rose-500/10 text-rose-700 dark:text-rose-300">✅ اختبار</button><button type="button" data-tk="lp" class="' + tb + 'bg-sky-500/10 text-sky-700 dark:text-sky-300">📘 خطة درس</button><button type="button" data-tk="sl" class="' + tb + 'bg-amber-500/15 text-amber-700 dark:text-amber-300">🎞 عرض</button><button type="button" data-tk="gm" class="' + tb + 'bg-fuchsia-500/15 text-fuchsia-700 dark:text-fuchsia-300">🎮 لعبة تفاعلية</button><button type="button" data-tk="tu" class="' + tb + 'bg-teal-500/15 text-teal-700 dark:text-teal-300">🤖 معلم وخريطة</button></div></div></div>';
    }).join("");
    grid.querySelectorAll("[data-bopen]").forEach(function (x) { x.addEventListener("click", function () {
      var id = x.getAttribute("data-bopen");
      if (window.EduBookReader && window.EduBookReader.open) window.EduBookReader.open(id, 0, "interactive");
    }); });
    grid.querySelectorAll("[data-tk]").forEach(function (x) { x.addEventListener("click", function () {
      var id = x.parentNode.dataset.tl, bk = all.filter(function (z) { return z.id === id; })[0]; if (bk) useTool(x.dataset.tk, bk);
    }); });
    grid.querySelectorAll("[data-be]").forEach(function (x) { x.addEventListener("click", function () { openForm(x.dataset.be); }); });
    grid.querySelectorAll("[data-bd]").forEach(function (x) { x.addEventListener("click", function () {
      if (!window.eduConfirm("حذف هذا الكتاب؟")) return;
      save([{ id: x.dataset.bd, remove: true }]).then(function () { showToast("تم حذف الكتاب", "info"); if (!cloud()) render(); }, fail);
    }); });
  }

  function stageOpts(sel) { return stages().map(function (s) { return '<option value="' + esc(s) + '"' + (s === sel ? " selected" : "") + ">" + esc(s) + "</option>"; }).join(""); }

  function openForm(id) {
    if (!canEdit()) { showToast("إضافة الكتب للإدارة والمشرفين فقط 🔒", "warning"); return; }
    var b = id ? books().filter(function (x) { return x.id === id; })[0] : null;
    b = b || { title: "", stage: filter || stages()[0], grade: fGrade && fGrade !== NONE ? fGrade : "", term: fTerm, subject: fSub && fSub !== NONE ? fSub : "", author: "", url: "", cover: "" };
    var curG = b.grade || guessGrade(b);
    var cover = b.cover || "";
    showModalContent('<div class="p-4 shrink-0 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50"><h3 class="text-sm font-extrabold">' + (id ? "تعديل كتاب" : "إضافة كتاب") + '</h3><button type="button" class="p-2 text-slate-400" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button></div>' +
      '<div class="p-4 overflow-y-auto flex-1 min-h-0 space-y-2 text-right">' +
      '<input id="bkT" class="' + inp + '" placeholder="اسم الكتاب *" value="' + esc(b.title) + '">' +
      '<select id="bkS" class="' + inp + '">' + stageOpts(b.stage) + '</select>' +
      '<div class="grid grid-cols-2 gap-2"><select id="bkG" class="' + inp + '"></select><select id="bkTm" class="' + inp + '"><option value="">الفصل: كلاهما / غير محدد</option><option value="1"' + (b.term === "1" ? " selected" : "") + '>الفصل الأول</option><option value="2"' + (b.term === "2" ? " selected" : "") + '>الفصل الثاني</option></select></div>' +
      '<select id="bkSub" class="' + inp + '"><option value="">— المادة —</option>' + window.subjectsOptions(b.subject || "") + '</select>' +
      '<input id="bkAu" class="' + inp + '" placeholder="المؤلف / الناشر (اختياري)" value="' + esc(b.author || "") + '">' +
      '<input id="bkU" dir="ltr" class="' + inp + ' text-left" placeholder="رابط الكتاب (Google Drive أو PDF) https://..." value="' + esc(b.url || "") + '">' +
      '<div class="rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 space-y-2"><div class="text-[11px] font-extrabold">📚 دروس الكتاب (اختياري)</div><p class="text-[10px] text-slate-500 leading-relaxed">عند إضافة الدروس يختار المعلم الدرس قبل التوليد أو يقرأه في القارئ التفاعلي. إن ألصقت نص الدرس تخرج الأسئلة من منهجك مباشرة.</p><div id="bkLs" class="space-y-2"></div><div class="flex flex-wrap gap-1.5"><button type="button" id="bkLAdd" class="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-[11px] font-bold">+ درس</button><button type="button" id="bkLPaste" class="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-[11px] font-bold">لصق عناوين عدة دروس</button></div></div>' +
      '<div class="flex items-center gap-2"><img id="bkPrev" class="w-14 h-20 object-cover rounded-lg ' + (cover ? "" : "hidden") + '" src="' + esc(cover) + '" alt=""><label class="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-[11px] font-bold cursor-pointer">رفع صورة الغلاف<input id="bkC" type="file" accept="image/*" class="hidden"></label></div></div>' +
      '<div class="p-3 shrink-0 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2 bg-slate-50 dark:bg-slate-800/50"><button type="button" class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold" onclick="closeModal()">إلغاء</button><button type="button" id="bkSave" class="px-5 py-2 rounded-xl bg-brand-600 text-white text-xs font-bold">حفظ</button></div>');
    var gSel = document.getElementById("bkG");
    function fillG(sel) { var l = gradesOf(document.getElementById("bkS").value); gSel.innerHTML = '<option value="">— الصف —</option>' + l.map(function (g) { return '<option value="' + esc(g) + '"' + (g === sel ? " selected" : "") + ">" + esc(g) + "</option>"; }).join(""); gSel.disabled = !l.length; }
    fillG(curG); document.getElementById("bkS").addEventListener("change", function () { fillG(""); });
    var lsBox = document.getElementById("bkLs");
    function lrow(t, x) { var d = document.createElement("div"); d.className = "rounded-lg bg-slate-50 dark:bg-slate-900/40 p-2 space-y-1.5"; d.innerHTML = '<div class="flex gap-1.5"><input class="bl-t ' + inp + '" placeholder="عنوان الدرس" maxlength="120"><button type="button" class="bl-r px-2.5 rounded-lg bg-rose-500/10 text-rose-500 text-[11px] shrink-0">✕</button></div><textarea class="bl-x ' + inp + '" rows="2" maxlength="5000" placeholder="نص الدرس (اختياري — ألصقه ليولّد منه الأسئلة ويظهر في القارئ)"></textarea>'; d.querySelector(".bl-t").value = t || ""; d.querySelector(".bl-x").value = x || ""; d.querySelector(".bl-r").addEventListener("click", function () { d.remove(); }); lsBox.appendChild(d); return d; }
    (b.lessons || []).forEach(function (l) { lrow(l.t, l.x); });
    document.getElementById("bkLAdd").addEventListener("click", function () { var d = lrow("", ""); d.querySelector(".bl-t").focus(); });
    document.getElementById("bkLPaste").addEventListener("click", function () {
      var v = window.eduPrompt("ألصق عناوين الدروس، كل درس في سطر:"); if (!v) return;
      v.split("\n").map(function (z) { return z.replace(/^\s*[\d٠-٩]+\s*[-.)\u2013]\s*/, "").trim(); }).filter(Boolean).slice(0, 60).forEach(function (z) { lrow(z, ""); });
    });
    document.getElementById("bkC").addEventListener("change", function (e) {
      var f = e.target.files[0]; if (!f) return;
      compressImageFile(f, 480, 60000).then(function (d) { cover = d; var im = document.getElementById("bkPrev"); im.src = d; im.classList.remove("hidden"); }, function () { showToast("تعذر معالجة الصورة", "warning"); });
    });
    document.getElementById("bkSave").addEventListener("click", function () {
      var title = document.getElementById("bkT").value.trim();
      if (!title) { showToast("اكتب اسم الكتاب", "warning"); return; }
      var data = { title: title, stage: document.getElementById("bkS").value, grade: gSel.value, term: document.getElementById("bkTm").value, subject: document.getElementById("bkSub").value.trim(), author: document.getElementById("bkAu").value.trim(), url: document.getElementById("bkU").value.trim(), cover: cover, lessons: Array.prototype.slice.call(lsBox.children).map(function (d) { return { t: d.querySelector(".bl-t").value.trim().slice(0, 120), x: d.querySelector(".bl-x").value.trim().slice(0, 5000) }; }).filter(function (l) { return l.t; }).slice(0, 60) };
      save([{ id: id || "bk-" + Date.now().toString(36), data: data }]).then(function () { closeModal(); showToast("تم حفظ الكتاب ✓", "success"); if (!cloud()) render(); }, fail);
    });
  }

  function openBulk() {
    if (!canEdit()) return;
    showModalContent('<div class="p-4 shrink-0 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50"><h3 class="text-sm font-extrabold">إضافة عدة كتب دفعة واحدة</h3><button type="button" class="p-2 text-slate-400" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button></div>' +
      '<div class="p-4 overflow-y-auto flex-1 min-h-0 space-y-2 text-right"><p class="text-[11px] text-slate-500">اكتب كل كتاب في سطر مستقل. يمكنك إضافة المادة والرابط بفاصل | مثل:<br><span dir="rtl" class="font-mono">الرياضيات - الصف الرابع | رياضيات | https://...</span></p>' +
      '<select id="blS" class="' + inp + '">' + stageOpts(filter || stages()[0]) + '</select><div class="grid grid-cols-2 gap-2"><select id="blG" class="' + inp + '"></select><select id="blTm" class="' + inp + '"><option value="">الفصل: غير محدد</option><option value="1">الفصل الأول</option><option value="2">الفصل الثاني</option></select></div><textarea id="blT" rows="9" class="' + inp + '" placeholder="اسم الكتاب 1&#10;اسم الكتاب 2 | المادة | الرابط"></textarea></div>' +
      '<div class="p-3 shrink-0 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2 bg-slate-50 dark:bg-slate-800/50"><button type="button" class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold" onclick="closeModal()">إلغاء</button><button type="button" id="blSave" class="px-5 py-2 rounded-xl bg-brand-600 text-white text-xs font-bold">إضافة الكل</button></div>');
    var bg = document.getElementById("blG");
    function fillBG() { var l = gradesOf(document.getElementById("blS").value); bg.innerHTML = '<option value="">— الصف (للكل) —</option>' + l.map(function (g) { return '<option value="' + esc(g) + '"' + (g === fGrade ? " selected" : "") + ">" + esc(g) + "</option>"; }).join(""); bg.disabled = !l.length; }
    fillBG(); document.getElementById("blS").addEventListener("change", fillBG);
    document.getElementById("blSave").addEventListener("click", function () {
      var stage = document.getElementById("blS").value, n = Date.now(), gv = bg.value, tv = document.getElementById("blTm").value;
      var rows = document.getElementById("blT").value.split("\n").map(function (l) { return l.trim(); }).filter(Boolean).map(function (l, i) {
        var p = l.split("|").map(function (x) { return x.trim(); });
        return { id: "bk-" + n.toString(36) + i, data: { title: p[0], stage: stage, grade: gv, term: tv, subject: p[1] || "", author: "", url: /^https?:\/\//i.test(p[2] || "") ? p[2] : "", cover: "" } };
      });
      if (!rows.length) { showToast("اكتب كتاباً واحداً على الأقل", "warning"); return; }
      save(rows).then(function () { closeModal(); showToast("تمت إضافة " + rows.length + " كتاب ✓", "success"); if (!cloud()) render(); }, fail);
    });
  }

  window.EduBooks = { list: books, guess: guessGrade, tool: useTool, GR: GR, render: render };
  var baseRender = null;
  window.addEventListener("DOMContentLoaded", function () {
    setTimeout(function () {
      ensure(); render();
      baseRender = window.renderExtras;
      window.renderExtras = function () { if (baseRender) baseRender(); render(); };
      if (cloud()) window.Cloud.subscribeBooks(function (l) { cloudBooks = l; ready = true; render(); if (window.EduLearn) window.EduLearn.render(); if (window.EduBoost) window.EduBoost.repaint(); }, function () { ready = true; render(); });
    }, 20);
    window.addEventListener("edu:lazy-ready", function () { render(); });
  });
})();

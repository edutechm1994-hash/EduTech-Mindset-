/*
 * لوحة الإحصاءات وتغطية المنهاج وتقرير الإنجاز الإداري — EduTech Mindset (الإصدار 46)
 * تقيس حجم المحتوى التربوي في المنصة عبر المراحل والصفوف والمواد (كتب، فيديوهات، أوراق عمل، ملخصات، اختبارات، ألعاب)،
 * وتكشف المواد التي تحتاج دعماً بالمحتوى، وتطبع «تقرير الإنجاز الإداري الشامل PDF» للمدرسة أو المشرف التربوي.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };

  function gatherStats() {
    var learn = window.EduLearn && window.EduLearn.data ? window.EduLearn.data() : { tree: { stages: [] }, res: [], books: [] };
    var stages = (learn.tree && learn.tree.stages) || [];
    var res = learn.res || [];
    var books = learn.books || [];

    var totalVideos = 0, totalSubjects = 0, totalGrades = 0;
    var stageRows = [];
    var weakSubjects = [];

    stages.forEach(function (S) {
      var stVids = 0, stRes = 0, stGrades = (S.grades || []).length, stSubs = 0;
      (S.grades || []).forEach(function (G) {
        totalGrades++;
        (G.subjects || []).forEach(function (M) {
          totalSubjects++; stSubs++;
          var vCount = (M.videos || []).length;
          var rCount = res.filter(function (r) { return r.subjectId === M.id; }).length;
          totalVideos += vCount;
          stVids += vCount;
          stRes += rCount;
          if (vCount + rCount === 0) {
            weakSubjects.push({ sId: S.id, gId: G.id, mId: M.id, label: M.name + " (" + G.name + ")" });
          }
        });
      });
      stageRows.push({ name: S.name, grades: stGrades, subjects: stSubs, videos: stVids, resources: stRes });
    });

    var resByKind = { worksheet: 0, exam: 0, summary: 0, other: 0 };
    res.forEach(function (r) {
      var k = r.kind || "other";
      resByKind[k] = (resByKind[k] || 0) + 1;
    });

    return {
      stagesCount: stages.length,
      gradesCount: totalGrades,
      subjectsCount: totalSubjects,
      videosCount: totalVideos,
      booksCount: books.length,
      resCount: res.length,
      resByKind: resByKind,
      stageRows: stageRows,
      weakSubjects: weakSubjects.slice(0, 14)
    };
  }

  function printAdminReport() {
    var d = gatherStats();
    var dt = new Date().toLocaleDateString("ar-EG", { day: "numeric", month: "long", year: "numeric" });
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>تقرير الإنجاز الإداري وتغطية المنهاج</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:14mm}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a;font-size:13px;line-height:1.8}h1{text-align:center;color:#0369a1;margin:0 0 4px}.sub{text-align:center;color:#64748b;margin-bottom:16px}.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:18px}.kpi{border:2px solid #cbd5e1;border-radius:12px;padding:10px;text-align:center}.kpi b{display:block;font-size:24px;color:#0284c7}table{width:100%;border-collapse:collapse;margin-top:10px}th,td{border:1px solid #334155;padding:8px;text-align:center}th{background:#f1f5f9;font-weight:900}</style></head><body>' +
      '<h1>📊 تقرير الإنجاز الرقمي وتغطية المنهاج — EduTech Mindset</h1>' +
      '<div class="sub">تاريخ الإصدار: ' + dt + '</div>' +
      '<div class="kpis">' +
      '<div class="kpi">الكتب المدرسية<b>' + d.booksCount + '</b></div>' +
      '<div class="kpi">الفيديوهات المشروحة<b>' + d.videosCount + '</b></div>' +
      '<div class="kpi">أوراق العمل والاختبارات<b>' + (d.resByKind.worksheet + d.resByKind.exam) + '</b></div>' +
      '<div class="kpi">الملخصات والموارد<b>' + (d.resByKind.summary + d.resByKind.other) + '</b></div>' +
      '</div>' +
      '<h3>تفصيل تغطية المراحل الدراسية:</h3>' +
      '<table><thead><tr><th>المرحلة الدراسية</th><th>عدد الصفوف</th><th>عدد المواد</th><th>الفيديوهات</th><th>الموارد المنشورة</th></tr></thead><tbody>' +
      d.stageRows.map(function (r) {
        return '<tr><td style="text-align:right;font-weight:800">' + e(r.name) + '</td><td>' + r.grades + '</td><td>' + r.subjects + '</td><td>' + r.videos + '</td><td>' + r.resources + '</td></tr>';
      }).join("") + '</tbody></table></body></html>';
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
  }

  function paint() {
    var box = $("anBody"); if (!box) return;
    var d = gatherStats();
    var totalItems = d.booksCount + d.videosCount + d.resCount;

    var h = '<div class="space-y-4">' +
      '<div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">' +
      '<div class="p-3.5 rounded-2xl bg-sky-500/10 border border-sky-500/25"><div class="text-2xl font-black text-sky-600 dark:text-sky-400">' + d.booksCount + '</div><div class="text-xs font-extrabold mt-0.5">📖 كتاب مدرسي ومرجع</div></div>' +
      '<div class="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/25"><div class="text-2xl font-black text-emerald-600 dark:text-emerald-400">' + d.videosCount + '</div><div class="text-xs font-extrabold mt-0.5">🎬 درس فيديو تفاعلي</div></div>' +
      '<div class="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/25"><div class="text-2xl font-black text-amber-600 dark:text-amber-400">' + (d.resByKind.worksheet + d.resByKind.exam) + '</div><div class="text-xs font-extrabold mt-0.5">📝 ورقة عمل واختبار</div></div>' +
      '<div class="p-3.5 rounded-2xl bg-purple-500/10 border border-purple-500/25"><div class="text-2xl font-black text-purple-600 dark:text-purple-400">' + (d.resByKind.summary + d.resByKind.other) + '</div><div class="text-xs font-extrabold mt-0.5">📋 ملخص ذكي ومورد</div></div>' +
      '</div>' +
      '<div class="rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-4">' +
      '<div class="flex flex-wrap items-center justify-between gap-2 mb-3">' +
      '<div class="text-xs font-black">📈 مؤشر تغطية المراحل الدراسية (إجمالي المحتوى: ' + totalItems + ' عنصر تعليمي)</div>' +
      '<div class="flex gap-1.5"><button type="button" id="anRefreshBtn" class="px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-[11px] font-bold">↻ تحديث الإحصاءات</button>' +
      '<button type="button" id="anPrintBtn" class="px-3.5 py-1.5 rounded-xl bg-brand-600 text-white text-[11px] font-black">🖨 طباعة تقرير الإنجاز PDF</button></div></div>' +
      '<div class="space-y-2.5">' +
      d.stageRows.map(function (r) {
        var sum = r.videos + r.resources;
        var pct = Math.min(100, Math.round(sum * 100 / Math.max(1, r.subjects * 4)));
        return '<div><div class="flex justify-between text-xs font-bold mb-1"><span>' + e(r.name) + ' (' + r.grades + ' صفوف • ' + r.subjects + ' مادة)</span><span class="text-brand-600 dark:text-brand-300">' + r.videos + ' فيديو • ' + r.resources + ' مورد</span></div>' +
          '<div class="w-full h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden"><div class="h-full bg-gradient-to-l from-brand-500 to-emerald-500" style="width:' + Math.max(6, pct) + '%"></div></div></div>';
      }).join("") + '</div></div>';

    if (d.weakSubjects.length) {
      h += '<div class="rounded-2xl border border-amber-300 dark:border-amber-800 bg-amber-50/50 dark:bg-slate-900/50 p-3.5">' +
        '<div class="text-xs font-black text-amber-800 dark:text-amber-300 mb-2">💡 مواد دراسية بانتظار إثرائها بالمحتوى (اضغط للانتقال إليها وتوليد ملخص أو اختبار):</div>' +
        '<div class="flex flex-wrap gap-1.5">' +
        d.weakSubjects.map(function (w, i) {
          return '<button type="button" data-ango="' + i + '" class="px-3 py-1 rounded-full bg-white dark:bg-slate-800 border border-amber-300 dark:border-slate-700 text-[11px] font-bold hover:border-brand-500">' + e(w.label) + '</button>';
        }).join("") + '</div></div>';
    }
    h += '</div>';
    box.innerHTML = h;

    $("anRefreshBtn").onclick = paint;
    $("anPrintBtn").onclick = printAdminReport;
    box.querySelectorAll("[data-ango]").forEach(function (bt) {
      bt.onclick = function () {
        var w = d.weakSubjects[+bt.dataset.ango];
        if (w && window.EduLearn && window.EduLearn.go) window.EduLearn.go(w.sId, w.gId, w.mId, "summary", "");
      };
    });
  }

  function build() {
    if ($("analyticsStudio")) return true;
    var anchor = $("classToolsStudio") || $("teacherDash") || $("about");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "analyticsStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-slate-800 via-cyan-900 to-slate-950 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-cyan-300 mb-1">📊 مرصد المنصة وتغطية المنهاج الفلسطيني</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">إحصاءات المحتوى التربوي وتقرير الإنجاز الشامل</h2>' +
      '<p class="text-xs text-white/80 mt-1">متابعة حية لتوزع الكتب والدروس وأوراق العمل والملخصات عبر المراحل الدراسية مع طباعة تقرير رسمي PDF.</p>' +
      '</div><div class="p-4 sm:p-6 text-right" id="anBody"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    paint();
    setTimeout(paint, 2200);
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduAnalytics = { refresh: paint };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

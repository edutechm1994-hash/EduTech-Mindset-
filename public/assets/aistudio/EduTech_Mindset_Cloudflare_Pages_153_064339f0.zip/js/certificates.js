/*
 * مولّد الشهادات الجماعية وبطاقات التكريم — EduTech Mindset (الإصدار 45)
 * يتيح للمعلم أو مدير المدرسة لصق قائمة أسماء طلاب (أو استيراد المتفوقين من الاختبارات)
 * واختيار قالب احترافي لإصدار دفتر شهادات PDF جماعي (شهادة مستقلة لكل طالب في صفحة A4)
 * أو تنزيل شهادة كل طالب كصورة PNG عالية الدقة لإرسالها عبر واتساب.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var THEMES = {
    royal: { name: "👑 ذهبي ملكي", bg1: "#fffbeb", bg2: "#ffffff", border: "#b45309", accent: "#d97706", nameCol: "#1e3a8a", badge: "🏅" },
    emerald: { name: "🌿 زمردي علمي", bg1: "#ecfdf5", bg2: "#ffffff", border: "#047857", accent: "#10b981", nameCol: "#064e3b", badge: "🌟" },
    ocean: { name: "💎 أزرق أكاديمي", bg1: "#f0f9ff", bg2: "#ffffff", border: "#0369a1", accent: "#0284c7", nameCol: "#0c4a6e", badge: "🎓" },
    purple: { name: "✨ بنفسجي إبداعي", bg1: "#faf5ff", bg2: "#ffffff", border: "#6d28d9", accent: "#7c3aed", nameCol: "#4c1d95", badge: "🏆" },
    crimson: { name: "🌹 قرمزي احتفالي", bg1: "#fff1f2", bg2: "#ffffff", border: "#be123c", accent: "#e11d48", nameCol: "#881337", badge: "🎖️" }
  };

  var st = {
    theme: "royal",
    title: "شهادة تفوّق وتميّز",
    intro: "يسرّ إدارة المدرسة ومعلم المادة أن يمنحا هذه الشهادة للطالب/ـة:",
    reason: "تقديراً لتفوقه/ـا واجتهاده/ـا المميز ومشاركته/ـا الفاعلة في الفصل الدراسي، متمنين له/ـا دوام النجاح والتألق.",
    school: "",
    subject: "",
    teacher: "",
    principal: "",
    date: new Date().toLocaleDateString("ar-EG", { day: "numeric", month: "long", year: "numeric" }),
    names: ["أحمد محمد الفقعاوي | 98%", "سارة خالد الأغا | 96%", "يوسف محمود النجار | 95%"],
    previewIdx: 0,
    orient: "portrait"
  };

  function loadSavedMeta() {
    try {
      var h = JSON.parse(localStorage.getItem("ws_hdr") || "{}");
      if (h.school && !st.school) st.school = h.school;
      if (h.teacher && !st.teacher) st.teacher = h.teacher;
    } catch (x) {}
  }

  function parseNames(raw) {
    return String(raw || "").split("\n").map(function (line) {
      return line.replace(/^\s*[\d٠-٩]+\s*[-.)\u2013]\s*/, "").trim();
    }).filter(Boolean).slice(0, 120);
  }

  function splitNameGrade(entry) {
    var parts = String(entry || "").split("|").map(function (s) { return s.trim(); });
    return { name: parts[0] || "طالب متميز", grade: parts[1] || "" };
  }

  function renderSingleCertHtml(entry, T) {
    var ng = splitNameGrade(entry);
    return '<div class="cert-page" style="width:210mm;height:296mm;padding:10mm;box-sizing:border-box;overflow:hidden;page-break-after:always;break-after:page;background:#fff;direction:rtl;font-family:Cairo,Tahoma,sans-serif">' +
      '<div style="width:100%;height:100%;border:4mm double ' + T.border + ';border-radius:6mm;background:linear-gradient(135deg,' + T.bg1 + ',' + T.bg2 + ');padding:14mm 12mm;box-sizing:border-box;display:flex;flex-direction:column;justify-content:space-between;text-align:center;position:relative">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;font-size:19px;font-weight:800;color:#334155">' +
      '<span>' + e(st.school || "منصة EduTech Mindset التعليمية") + '</span>' +
      '<span style="font-size:64px">' + T.badge + '</span>' +
      '<span>' + e(st.subject ? "المادة: " + st.subject : "العام الدراسي 2026 / 2027") + '</span></div>' +
      '<div><h1 style="font-size:66px;font-weight:900;color:' + T.border + ';margin:4px 0 14px">' + e(st.title) + '</h1>' +
      '<p style="font-size:22px;font-weight:700;color:#475569;margin:0 0 22px">' + e(st.intro) + '</p>' +
      '<div style="display:inline-block;font-size:54px;font-weight:900;color:' + T.nameCol + ';border-bottom:4px solid ' + T.accent + ';padding:2px 28px 10px;margin-bottom:18px;max-width:100%">' + e(ng.name) + '</div>' +
      (ng.grade ? '<div style="font-size:28px;font-weight:900;color:' + T.accent + ';margin-bottom:16px">الدرجة / التقدير: ' + e(ng.grade) + '</div>' : '') +
      '<p style="font-size:25px;font-weight:700;color:#1e293b;max-width:640px;margin:0 auto;line-height:1.9">' + e(st.reason) + '</p></div>' +
      '<div style="display:flex;justify-content:space-around;align-items:flex-end;font-size:21px;font-weight:800;color:#334155;padding-top:16px;border-top:1px dashed #cbd5e1;gap:8px">' +
      '<div>التاريخ: ' + e(st.date) + '</div>' +
      '<div>معلم/ـة المادة<br><span style="color:' + T.border + '">' + e(st.teacher || "........................") + '</span></div>' +
      '<div>مدير/ة المدرسة<br><span style="color:' + T.border + '">' + e(st.principal || "........................") + '</span></div>' +
      '</div></div></div>';
  }

  function renderLandscapeHtml(entry, T) {
    var ng = splitNameGrade(entry);
    return '<div class="cert-page" style="width:297mm;height:210mm;padding:10mm;box-sizing:border-box;page-break-after:always;break-after:page;background:#fff;direction:rtl;font-family:Cairo,Tahoma,sans-serif">' +
      '<div style="width:100%;height:100%;border:4mm double ' + T.border + ';border-radius:6mm;background:linear-gradient(135deg,' + T.bg1 + ',' + T.bg2 + ');padding:10mm 16mm;box-sizing:border-box;display:flex;flex-direction:column;justify-content:space-between;text-align:center;position:relative">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;font-size:14px;font-weight:800;color:#334155">' +
      '<span>' + e(st.school || "منصة EduTech Mindset التعليمية") + '</span>' +
      '<span style="font-size:44px">' + T.badge + '</span>' +
      '<span>' + e(st.subject ? "المادة: " + st.subject : "العام الدراسي 2026 / 2027") + '</span></div>' +
      '<div><h1 style="font-size:46px;font-weight:900;color:' + T.border + ';margin:4px 0 8px">' + e(st.title) + '</h1>' +
      '<p style="font-size:18px;font-weight:700;color:#475569;margin:0 0 12px">' + e(st.intro) + '</p>' +
      '<div style="display:inline-block;font-size:40px;font-weight:900;color:' + T.nameCol + ';border-bottom:3px solid ' + T.accent + ';padding:2px 36px 8px;margin-bottom:10px">' + e(ng.name) + '</div>' +
      (ng.grade ? '<div style="font-size:20px;font-weight:900;color:' + T.accent + ';margin-bottom:8px">الدرجة / التقدير: ' + e(ng.grade) + '</div>' : '') +
      '<p style="font-size:18px;font-weight:700;color:#1e293b;max-width:760px;margin:0 auto;line-height:1.8">' + e(st.reason) + '</p></div>' +
      '<div style="display:flex;justify-content:space-around;align-items:flex-end;font-size:16px;font-weight:800;color:#334155;padding-top:12px;border-top:1px dashed #cbd5e1">' +
      '<div>التاريخ: ' + e(st.date) + '</div>' +
      '<div>معلم/ـة المادة<br><span style="color:' + T.border + '">' + e(st.teacher || "........................") + '</span></div>' +
      '<div>مدير/ة المدرسة<br><span style="color:' + T.border + '">' + e(st.principal || "........................") + '</span></div>' +
      '</div></div></div>';
  }

  function printAllPdf() {
    var list = parseNames($("ctNames").value);
    if (!list.length) { toast("أدخل اسماً واحداً على الأقل", "warning"); return; }
    var T = THEMES[st.theme] || THEMES.royal;
    var land = st.orient === "landscape", pages = list.map(function (entry) { return land ? renderLandscapeHtml(entry, T) : renderSingleCertHtml(entry, T); }).join("");
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>' + e(st.title) + '</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4 ' + (land ? "landscape" : "portrait") + ';margin:0}*{-webkit-print-color-adjust:exact;print-color-adjust:exact;box-sizing:border-box}body{margin:0;padding:0}.cert-page:last-child{page-break-after:auto;break-after:auto}</style>' +
      '</head><body>' + pages + '</body></html>';
    var f = document.createElement("iframe");
    f.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0";
    document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () {
      try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {}
      setTimeout(function () { f.remove(); }, 5000);
    }, 800);
    toast("جارٍ فتح نافذة الطباعة لـ " + list.length + " شهادة (اختر حفظ كملف PDF)");
  }

  function drawPreviewCanvas() {
    var cv = $("ctCanvas"); if (!cv) return;
    var list = parseNames($("ctNames") ? $("ctNames").value : st.names.join("\n"));
    if (!list.length) list = ["اسم الطالب المتميز | 100%"];
    if (st.previewIdx >= list.length) st.previewIdx = 0;
    var ng = splitNameGrade(list[st.previewIdx]);
    var T = THEMES[st.theme] || THEMES.royal;

    var port = st.orient !== "landscape";
    var W = port ? 1000 : 1400, H = port ? 1414 : 990, K = port ? 1.28 : 1;
    cv.width = W; cv.height = H;
    var ctx = cv.getContext("2d");
    ctx.direction = "rtl"; ctx.textAlign = "center"; ctx.textBaseline = "middle";

    var g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, T.bg1); g.addColorStop(1, T.bg2);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

    // إطار مزدوج فاخر
    ctx.strokeStyle = T.border; ctx.lineWidth = 14;
    ctx.strokeRect(42, 42, W - 84, H - 84);
    ctx.strokeStyle = T.accent; ctx.lineWidth = 4;
    ctx.strokeRect(62, 62, W - 124, H - 124);

    // ترويسة
    ctx.fillStyle = "#334155"; ctx.font = "800 26px Cairo, Tahoma, sans-serif";
    ctx.textAlign = "right"; if (port) ctx.font = "800 20px Cairo, Tahoma, sans-serif";
    ctx.fillText(st.school || "منصة EduTech Mindset التعليمية", W - 110, 130 * K);
    ctx.textAlign = "left";
    ctx.fillText(st.subject ? "المادة: " + st.subject : "العام الدراسي 2026 / 2027", 110, 130 * K);

    ctx.textAlign = "center";
    ctx.font = "72px Cairo, sans-serif";
    ctx.fillText(T.badge, W / 2, 145 * K);

    ctx.fillStyle = T.border; ctx.font = "900 68px Cairo, Tahoma, sans-serif";
    ctx.fillText(st.title, W / 2, 260 * K);

    ctx.fillStyle = "#475569"; ctx.font = "700 30px Cairo, Tahoma, sans-serif";
    ctx.fillText(st.intro, W / 2, 355 * K);

    // اسم الطالب
    ctx.fillStyle = T.nameCol; ctx.font = "900 64px Cairo, Tahoma, sans-serif";
    ctx.fillText(ng.name, W / 2, 455 * K);

    ctx.strokeStyle = T.accent; ctx.lineWidth = 5;
    ctx.beginPath(); ctx.moveTo(W / 2 - 280, 505 * K); ctx.lineTo(W / 2 + 280, 505 * K); ctx.stroke();

    var reasonY = 585 * K;
    if (ng.grade) {
      ctx.fillStyle = T.accent; ctx.font = "900 34px Cairo, Tahoma, sans-serif";
      ctx.fillText("الدرجة / التقدير: " + ng.grade, W / 2, 555 * K);
      reasonY = 630 * K;
    }

    // تقسيم نص السبب على سطرين إن كان طويلاً
    ctx.fillStyle = "#1e293b"; ctx.font = "700 " + (port ? 26 : 30) + "px Cairo, Tahoma, sans-serif";
    var words = String(st.reason || "").split(/\s+/), line1 = "", line2 = "";
    words.forEach(function (w) {
      if ((line1 + " " + w).length < (port ? 36 : 58)) line1 += (line1 ? " " : "") + w;
      else line2 += (line2 ? " " : "") + w;
    });
    ctx.fillText(line1, W / 2, reasonY);
    if (line2) ctx.fillText(line2, W / 2, reasonY + 48);

    // التوقيعات بالأسفل
    var fy = H - 135;
    ctx.fillStyle = "#334155"; ctx.font = "800 26px Cairo, Tahoma, sans-serif";
    var tl = "معلم/ـة المادة: " + (st.teacher || ".................."), pl = "مدير/ة المدرسة: " + (st.principal || "..................");
    if (port) {
      ctx.fillText("التاريخ: " + st.date, W / 2, H - 260);
      ctx.fillText(tl, W * 0.72, H - 180); ctx.fillText(pl, W * 0.28, H - 180);
    } else {
      ctx.fillText("التاريخ: " + st.date, W * 0.8, fy);
      ctx.fillText(tl, W * 0.5, fy);
      ctx.fillText(pl, W * 0.2, fy);
    }

    var lbl = $("ctPrevLabel");
    if (lbl) lbl.textContent = "معاينة شهادة (" + (st.previewIdx + 1) + " من " + list.length + "): " + ng.name;
  }

  function downloadCurrentPng() {
    var cv = $("ctCanvas"); if (!cv) return;
    var list = parseNames($("ctNames").value);
    var ng = splitNameGrade(list[st.previewIdx] || "طالب");
    cv.toBlob(function (b) {
      var a = document.createElement("a");
      a.href = URL.createObjectURL(b);
      a.download = "شهادة-" + ng.name + ".png";
      document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 600);
    }, "image/png");
  }

  function aiWriteReason() {
    var btn = $("ctAiReason"); if (btn) { btn.disabled = true; btn.textContent = "⏳ يكتب…"; }
    var prompt = "اكتب عبارة تقدير وتكريم فصيحة ومؤثرة ومختصرة (سطر ونصف فقط، نحو 18 إلى 24 كلمة) توضع في «" + st.title + "» لطلاب متميزين" + (st.subject ? " في مادة " + st.subject : "") + ". أعد النص فقط بلا علامات تنصيص.";
    window.AI.ask(prompt, [], "studio").then(function (txt) {
      st.reason = String(txt || "").trim().slice(0, 220);
      if ($("ctReason")) $("ctReason").value = st.reason;
      drawPreviewCanvas();
    }).catch(function () { toast("تعذر توليد العبارة حالياً", "warning"); }).then(function () {
      if (btn) { btn.disabled = false; btn.textContent = "✨ صياغة عبارة بالذكاء الاصطناعي"; }
    });
  }

  function build() {
    if ($("certStudio")) return true;
    var anchor = $("designStudio") || $("lessonPlanStudio") || $("worksheetStudio");
    if (!anchor) return false;
    loadSavedMeta();
    var s = document.createElement("section");
    s.id = "certStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-amber-600 via-yellow-600 to-slate-900 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-200 mb-1">🏅 مولّد الشهادات الجماعية وبطاقات التكريم</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">أصدر شهادات تقدير وتفوق لجميع طلاب صفك دفعة واحدة</h2>' +
      '<p class="text-xs text-white/90 mt-1">الصق قائمة أسماء طلابك (كل طالب في سطر) واختر القالب لتنزيل دفتر شهادات PDF جاهز للطباعة أو صور PNG فردية للواتساب.</p>' +
      '</div>' +
      '<div class="p-5 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-5 text-right">' +
      '<div class="lg:col-span-5 space-y-3">' +
      '<div><label class="block text-xs font-bold mb-1">قالب الشهادة</label><select id="ctTheme" class="' + cls + '">' +
      Object.keys(THEMES).map(function (k) { return '<option value="' + k + '">' + THEMES[k].name + '</option>'; }).join("") + '</select></div>' +
      '<div class="grid grid-cols-2 gap-2"><div><label class="block text-xs font-bold mb-1">عنوان الشهادة</label><input id="ctTitle" value="' + e(st.title) + '" class="' + cls + '"></div>' +
      '<div><label class="block text-xs font-bold mb-1">المادة / المناسبة</label><input id="ctSubject" value="' + e(st.subject) + '" placeholder="مثال: العلوم / أوائل الشهر" class="' + cls + '"></div></div>' +
      '<div><div class="flex items-center justify-between mb-1"><label class="text-xs font-bold">عبارة التقدير والتكريم</label><button type="button" id="ctAiReason" class="text-[10px] font-extrabold text-brand-600">✨ صياغة عبارة بالذكاء الاصطناعي</button></div>' +
      '<textarea id="ctReason" rows="2" class="' + cls + '">' + e(st.reason) + '</textarea></div>' +
      '<div class="grid grid-cols-3 gap-2">' +
      '<input id="ctSchool" value="' + e(st.school) + '" placeholder="اسم المدرسة" class="' + cls + '">' +
      '<input id="ctTeacher" value="' + e(st.teacher) + '" placeholder="اسم المعلم/ـة" class="' + cls + '">' +
      '<input id="ctPrincipal" value="' + e(st.principal) + '" placeholder="مدير/ة المدرسة" class="' + cls + '"></div>' +
      '<div><label class="block text-xs font-bold mb-1">أسماء الطلاب المكرّمين (كل اسم في سطر — ويمكن إضافة | والدرجة)</label>' +
      '<textarea id="ctNames" rows="5" class="' + cls + '" placeholder="أحمد محمد | 99%&#10;سارة خالد | ممتاز">' + e(st.names.join("\n")) + '</textarea></div>' +
      '<div><label class="block text-xs font-bold mb-1">اتجاه صفحة PDF</label><select id="ctOrient" class="' + cls + '"><option value="portrait"' + (st.orient !== "landscape" ? " selected" : "") + '>طولي — يملأ الصفحة على كل الأجهزة (موصى به)</option><option value="landscape"' + (st.orient === "landscape" ? " selected" : "") + '>عرضي — قد يطبع بنصف صفحة على بعض هواتف أندرويد</option></select></div>' +
      '<div class="flex flex-wrap gap-2 pt-1">' +
      '<button type="button" id="ctPrintAll" class="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-l from-amber-500 to-orange-600 text-white text-xs font-black shadow-md">🖨 طباعة / حفظ كل الشهادات PDF</button>' +
      '<button type="button" id="ctDlPng" class="py-2.5 px-4 rounded-xl bg-emerald-600 text-white text-xs font-black">⬇ صورة PNG لهذا الطالب</button>' +
      '</div></div>' +
      '<div class="lg:col-span-7 flex flex-col justify-between space-y-2">' +
      '<div class="flex items-center justify-between text-xs font-extrabold"><span id="ctPrevLabel">معاينة الشهادة</span>' +
      '<div class="flex gap-1.5"><button type="button" id="ctPrevBtn" class="px-3 py-1 rounded-lg bg-slate-200 dark:bg-slate-700">➡ الطالب السابق</button>' +
      '<button type="button" id="ctNextBtn" class="px-3 py-1 rounded-lg bg-slate-200 dark:bg-slate-700">الطالب التالي ⬅</button></div></div>' +
      '<div class="rounded-2xl border-2 border-amber-400/50 bg-slate-900 p-2 shadow-inner"><canvas id="ctCanvas" class="w-full h-auto rounded-xl"></canvas></div>' +
      '</div></div></div></div>';

    anchor.parentNode.insertBefore(s, anchor.nextSibling);

    function syncInputs() {
      if ($("ctOrient")) st.orient = $("ctOrient").value;
      st.theme = $("ctTheme").value;
      st.title = $("ctTitle").value.trim() || "شهادة تقدير";
      st.subject = $("ctSubject").value.trim();
      st.reason = $("ctReason").value.trim();
      st.school = $("ctSchool").value.trim();
      st.teacher = $("ctTeacher").value.trim();
      st.principal = $("ctPrincipal").value.trim();
      drawPreviewCanvas();
    }

    ["ctTheme", "ctOrient", "ctTitle", "ctSubject", "ctReason", "ctSchool", "ctTeacher", "ctPrincipal", "ctNames"].forEach(function (id) {
      var el = $(id);
      if (el) { el.addEventListener("input", syncInputs); el.addEventListener("change", syncInputs); }
    });
    $("ctAiReason").onclick = aiWriteReason;
    $("ctPrintAll").onclick = printAllPdf;
    $("ctDlPng").onclick = downloadCurrentPng;
    $("ctPrevBtn").onclick = function () {
      var list = parseNames($("ctNames").value);
      if (!list.length) return;
      st.previewIdx = (st.previewIdx - 1 + list.length) % list.length;
      drawPreviewCanvas();
    };
    $("ctNextBtn").onclick = function () {
      var list = parseNames($("ctNames").value);
      if (!list.length) return;
      st.previewIdx = (st.previewIdx + 1) % list.length;
      drawPreviewCanvas();
    };
    setTimeout(drawPreviewCanvas, 100);
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduCertificates = {
    openWithNames: function (namesArr, title) {
      if ($("ctNames") && Array.isArray(namesArr)) $("ctNames").value = namesArr.join("\n");
      if ($("ctSubject") && title) $("ctSubject").value = title;
      st.previewIdx = 0;
      drawPreviewCanvas();
      if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("certStudio", true); else { var sec = $("certStudio"); if (sec) sec.scrollIntoView({ behavior: "smooth", block: "start" }); }
    }
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

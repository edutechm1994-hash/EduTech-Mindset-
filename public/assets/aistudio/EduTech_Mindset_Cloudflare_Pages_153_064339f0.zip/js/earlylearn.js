/*
 * استوديو التأسيس المبكر والصفوف الدنيا (1–4) ورياض الأطفال — EduTech Mindset (الإصدار 48)
 * يعمل بالكامل بلا إنترنت ويضم 3 أدوات تأسيسية:
 * 1) ✍️ مولّد كراسات تتبّع الحروف والكلمات والأرقام المنقّطة (Dotted Tracing Worksheets A4 PDF)
 * 2) 🍎 مولّد أوراق العدّ والجمع البصري بالصور والرسوم التعبيرية للصفوف (1–3)
 * 3) 🔊 لوحة الحروف والأرقام الناطقة التفاعلية للأطفال
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var AR_LETTERS = [
    ["أ", "أَسَد 🦁"], ["ب", "بَطَّة 🦆"], ["ت", "تُفَّاحَة 🍎"], ["ث", "ثَعْلَب 🦊"],
    ["ج", "جَمَل 🐪"], ["ح", "حِصَان 🐎"], ["خ", "خَرُوف 🐑"], ["د", "دُبّ 🐻"],
    ["ذ", "ذُرَة 🌽"], ["ر", "رُمَّان  pomegranate".split(" ")[0] + " 🍎"], ["ز", "زَرَافَة 🦒"], ["س", "سَمَكَة 🐟"],
    ["ش", "شَمْس ☀️"], ["ص", "صَقْر 🦅"], ["ض", "ضِفْدَع 🐸"], ["ط", "طَائِرَة ✈️"],
    ["ظ", "ظَرْف ✉️"], ["ع", "عِنَب 🍇"], ["غ", "غَزَال 🦌"], ["ف", "فَرَاشَة 🦋"],
    ["ق", "قَمَر 🌙"], ["ك", "كِتَاب 📖"], ["ل", "لَيْمُون 🍋"], ["م", "مَوْز 🍌"],
    ["ن", "نَحْلَة 🐝"], ["هـ", "هُدْهُد 🐦"], ["و", "وَرْدَة 🌹"], ["ي", "يَد ✋"]
  ];

  var VISUAL_ITEMS = ["🍎", "🌟", "🦋", "🎈", "🐟", "🍓", "🚗", "🌻"];

  var st = {
    tab: "tracing", // tracing | counting | alphabet
    traceTitle: "كراسة تحسين الخط وتتبّع الحروف والكلمات",
    traceWords: "أ ب ت ث\nج ح خ د\nالعلم نور\nفلسطين الحبيبة\n١ ٢ ٣ ٤ ٥ ٦ ٧ ٨ ٩ ١٠",
    traceRepeat: 4,
    mathMax: 10
  };

  function speakAr(txt) {
    try {
      if (!("speechSynthesis" in window)) return;
      window.speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(txt);
      u.lang = "ar-SA"; u.rate = 0.85;
      window.speechSynthesis.speak(u);
    } catch (x) {}
  }

  function printTracingPdf() {
    var lines = String($("elTraceWords").value || "").split("\n").map(function (s) { return s.trim(); }).filter(Boolean);
    var title = $("elTraceTitle").value.trim() || st.traceTitle;
    var rep = +$("elTraceRep").value || 4;
    if (!lines.length) { toast("اكتب الحروف أو الكلمات المطلوب تتبعها", "warning"); return; }

    var rowsHtml = "";
    lines.forEach(function (word) {
      var cells = '<td class="model">' + e(word) + '</td>';
      for (var i = 0; i < rep; i++) {
        cells += '<td class="trace">' + e(word) + '</td>';
      }
      rowsHtml += '<tr>' + cells + '</tr>';
      // سطر إضافي فارغ مسطر للتدريب الحر تحت كل كلمة
      var blankCells = '<td class="model-sub">اكتب بمفردك:</td>';
      for (var j = 0; j < rep; j++) blankCells += '<td class="blank"></td>';
      rowsHtml += '<tr>' + blankCells + '</tr>';
    });

    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>' + e(title) + '</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:12mm}*{box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a}h1{text-align:center;font-size:22px;margin:0 0 6px;color:#0369a1}.hdr{border:2px solid #0f172a;border-radius:12px;padding:10px 14px;margin-bottom:14px;display:flex;justify-content:space-between;font-weight:800;font-size:13px}table{width:100%;border-collapse:collapse}td{border:1.5px solid #94a3b8;padding:10px 8px;text-align:center;height:62px;position:relative}td.model{font-size:28px;font-weight:900;color:#0f172a;background:#f0f9ff;width:22%}td.trace{font-size:28px;font-weight:900;color:#cbd5e1;letter-spacing:1px;border-bottom:2px dashed #64748b}td.model-sub{font-size:12px;font-weight:800;color:#475569;background:#f8fafc;height:46px}td.blank{border-bottom:2px dotted #475569;height:46px}</style></head><body>' +
      '<h1>✍️ ' + e(title) + '</h1>' +
      '<div class="hdr"><span>اسم البطل/ـة: ............................................</span><span>الصف: ......................</span><span>التاريخ: ......................</span></div>' +
      '<table><tbody>' + rowsHtml + '</tbody></table></body></html>';

    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
    toast("جارٍ فتح كراسة التتبع للطباعة أو الحفظ كـ PDF ✓");
  }

  function printVisualMathPdf() {
    var maxN = +$("elMathMax").value || 10;
    var tasks = [];
    for (var i = 0; i < 8; i++) {
      var ico = VISUAL_ITEMS[i % VISUAL_ITEMS.length];
      var a = Math.floor(Math.random() * Math.floor(maxN / 2)) + 1;
      var b = Math.floor(Math.random() * Math.floor(maxN / 2)) + 1;
      tasks.push({ ico: ico, a: a, b: b });
    }
    var rows = tasks.map(function (t, idx) {
      var gA = new Array(t.a + 1).join(t.ico + " ");
      var gB = new Array(t.b + 1).join(t.ico + " ");
      return '<div class="box"><div class="num">' + (idx + 1) + ')</div><div class="grp">' + gA + '<div class="sub">( ...... )</div></div><div class="op">+</div><div class="grp">' + gB + '<div class="sub">( ...... )</div></div><div class="op">=</div><div class="ans"></div></div>';
    }).join("");

    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>ورقة عمل العدّ والجمع البصري</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;800;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:12mm}*{box-sizing:border-box}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a}h1{text-align:center;color:#059669;margin:0 0 8px}.hdr{border:2px solid #0f172a;border-radius:12px;padding:8px 14px;margin-bottom:14px;display:flex;justify-content:space-between;font-weight:800;font-size:13px}.box{border:2px solid #cbd5e1;border-radius:16px;padding:10px 14px;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;gap:10px;break-inside:avoid}.num{font-weight:900;font-size:16px;color:#0284c7}.grp{flex:1;text-align:center;font-size:22px;background:#f8fafc;border-radius:12px;padding:6px}.sub{font-size:12px;color:#64748b;margin-top:4px}.op{font-size:26px;font-weight:900}.ans{width:70px;height:52px;border:2.5px dashed #059669;border-radius:12px}</style></head><body>' +
      '<h1>🍎 ورقة عمل: عُدّ الأشكال واجمعها يا بطل!</h1>' +
      '<div class="hdr"><span>اسم البطل/ـة: ............................................</span><span>الصف: ......................</span><span>الدرجة: ...... / 8</span></div>' +
      rows + '</body></html>';

    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
  }

  function paint() {
    var box = $("elBody"); if (!box) return;
    var tabs = [
      ["tracing", "✍️ كراسة تتبّع الحروف والكلمات المنقّطة"],
      ["counting", "🍎 أوراق العدّ والجمع البصري بالصور"],
      ["alphabet", "🔊 لوحة الحروف العربية الناطقة للأطفال"]
    ];
    var nav = '<div class="flex flex-wrap gap-2 mb-4 border-b border-slate-200 dark:border-slate-700 pb-3">' +
      tabs.map(function (t) {
        var on = st.tab === t[0];
        return '<button type="button" data-eltab="' + t[0] + '" class="px-4 py-2 rounded-xl text-xs font-extrabold transition-all ' + (on ? "bg-pink-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">' + t[1] + '</button>';
      }).join("") + '</div>';

    var body = "";
    if (st.tab === "tracing") {
      body = '<div class="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">' +
        '<div class="lg:col-span-6 space-y-3">' +
        '<div><label class="block text-xs font-bold mb-1">عنوان الكراسة / الورقة</label><input id="elTraceTitle" value="' + e(st.traceTitle) + '" class="' + cls + '"></div>' +
        '<div><label class="block text-xs font-bold mb-1">الحروف أو الكلمات أو الأرقام (كل سطر يظهر في صف تدريب منقّط مستقل)</label>' +
        '<textarea id="elTraceWords" rows="5" class="' + cls + '">' + e(st.traceWords) + '</textarea></div>' +
        '<div class="flex items-center justify-between gap-2">' +
        '<label class="text-xs font-bold">عدد مرات تكرار الكلمة المنقّطة في السطر:</label>' +
        '<select id="elTraceRep" class="' + cls + ' !w-28"><option value="3">3 مرات</option><option value="4" selected>4 مرات</option><option value="5">5 مرات</option></select></div>' +
        '<button type="button" id="elPrintTrace" class="w-full py-3 rounded-xl bg-gradient-to-l from-pink-600 to-rose-600 text-white text-xs font-black shadow-md">🖨 طباعة / حفظ كراسة التتبع المنقّطة PDF</button>' +
        '</div>' +
        '<div class="lg:col-span-6 rounded-2xl border-2 border-dashed border-pink-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-4 space-y-2">' +
        '<div class="text-xs font-black text-pink-600 mb-2">👁 نموذج فوري لما سيظهر في ورقة الطالب:</div>' +
        String(st.traceWords || "").split("\n").slice(0, 4).map(function (w) {
          return '<div class="grid grid-cols-4 gap-2 items-center border-b border-slate-200 dark:border-slate-700 py-2 text-center">' +
            '<span class="font-black text-lg text-brand-600 bg-brand-50 dark:bg-slate-900 rounded-lg py-1">' + e(w) + '</span>' +
            '<span class="font-black text-lg text-slate-300 dark:text-slate-600 border-b-2 border-dashed border-slate-400">' + e(w) + '</span>' +
            '<span class="font-black text-lg text-slate-300 dark:text-slate-600 border-b-2 border-dashed border-slate-400">' + e(w) + '</span>' +
            '<span class="font-black text-lg text-slate-300 dark:text-slate-600 border-b-2 border-dashed border-slate-400">' + e(w) + '</span></div>';
        }).join("") + '</div></div>';
    } else if (st.tab === "counting") {
      body = '<div class="space-y-4">' +
        '<div class="flex flex-wrap items-center gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700">' +
        '<label class="text-xs font-extrabold">مستوى الأعداد في الورقة:</label>' +
        '<select id="elMathMax" class="' + cls + ' !w-44"><option value="6">الأعداد حتى 6 (تمهيدي/أول)</option><option value="10" selected>الأعداد حتى 10 (الصف الأول)</option><option value="18">الأعداد حتى 18 (الصف الثاني)</option></select>' +
        '<button type="button" id="elPrintMath" class="px-6 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black shadow">🖨 ولّد واطبع ورقة العدّ والجمع البصري PDF</button>' +
        '</div>' +
        '<div class="grid grid-cols-1 sm:grid-cols-2 gap-3">' +
        [[3, 2, "🍎"], [4, 3, "🦋"], [2, 5, "🌟"], [3, 3, "🐟"]].map(function (ex, i) {
          return '<div class="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex items-center justify-between text-lg font-black">' +
            '<span class="text-xs text-slate-400">#' + (i + 1) + '</span>' +
            '<span>' + new Array(ex[0] + 1).join(ex[2]) + '</span><span>+</span><span>' + new Array(ex[1] + 1).join(ex[2]) + '</span><span>=</span>' +
            '<span class="w-12 h-10 rounded-xl border-2 border-dashed border-emerald-500 flex items-center justify-center text-sm text-emerald-600">؟</span></div>';
        }).join("") + '</div></div>';
    } else if (st.tab === "alphabet") {
      body = '<div class="space-y-3">' +
        '<p class="text-xs text-slate-500 font-bold">اضغط على أي حرف ليستمع الطفل إلى نطقه الصحيح مع الكلمة الدالة عليه:</p>' +
        '<div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2.5">' +
        AR_LETTERS.map(function (item, idx) {
          return '<button type="button" data-arlet="' + idx + '" class="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-pink-500 hover:scale-105 transition-all text-center">' +
            '<div class="text-2xl font-black text-brand-600 dark:text-brand-300">' + e(item[0]) + '</div>' +
            '<div class="text-[11px] font-bold text-slate-600 dark:text-slate-300 mt-1">' + e(item[1]) + '</div></button>';
        }).join("") + '</div></div>';
    }

    box.innerHTML = nav + body;
    box.querySelectorAll("[data-eltab]").forEach(function (b) {
      b.onclick = function () { st.tab = b.dataset.eltab; paint(); };
    });

    if (st.tab === "tracing") {
      $("elTraceWords").oninput = function (ev) { st.traceWords = ev.target.value; };
      $("elTraceTitle").oninput = function (ev) { st.traceTitle = ev.target.value; };
      $("elPrintTrace").onclick = printTracingPdf;
    } else if (st.tab === "counting") {
      $("elPrintMath").onclick = printVisualMathPdf;
    } else if (st.tab === "alphabet") {
      box.querySelectorAll("[data-arlet]").forEach(function (bt) {
        bt.onclick = function () {
          var it = AR_LETTERS[+bt.dataset.arlet];
          if (it) speakAr("حرف " + it[0] + " ، " + it[1].replace(/[^\u0600-\u06FF\s]/g, ""));
        };
      });
    }
  }

  function build() {
    if ($("earlyLearnStudio")) return true;
    var anchor = $("tawjihiStudio") || $("learnSection");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "earlyLearnStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-pink-600 via-rose-600 to-slate-900 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-200 mb-1">🧸 استوديو التأسيس المبكر والصفوف الدنيا (1–4) ورياض الأطفال</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">كراسات تتبّع الحروف المنقّطة، أوراق العدّ والجمع بالصور، ولوحة الحروف الناطقة</h2>' +
      '<p class="text-xs text-white/90 mt-1">أدوات جاهزة للطباعة الفورية (A4 PDF) لتأسيس القراءة والكتابة والحساب للصفوف الأساسية الدنيا بلا إنترنت.</p>' +
      '</div><div class="p-4 sm:p-6 text-right" id="elBody"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    paint();
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduEarlyLearn = { open: function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("earlyLearnStudio", true); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

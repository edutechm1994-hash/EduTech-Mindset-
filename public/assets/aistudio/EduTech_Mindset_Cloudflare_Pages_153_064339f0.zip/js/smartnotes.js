/*
 * استوديو الدفتر الذكي بنظام كورنيل، مدرب الاستدعاء النشط (Cloze Active Recall)، والمترجم الأكاديمي المزدوج
 * EduTech Mindset — الإصدار 88 (Cornell Smart Study Notebook, Cloze Active Recall Trainer & Bilingual Academic Explainer)
 *
 * يقدم هذا الملف:
 * 1) دفتر الملاحظات الذكي بنظام كورنيل العالمي (Cornell 3-Zone Smart Notebook):
 *    - يقسّم أي فصل أو محاضرة من الكتب المسجلة في قاعدة بيانات الـ Markdown إلى ورقة كورنيل العلمية الثلاثية:
 *      (أ) عمود الأسئلة المفتاحية والمصطلحات (Cue Column 30%) (ب) عمود الشرح والتفاصيل والأمثلة (Notes Column 70%) (ج) منطقة الخلاصة الذهبية بالأسفل (Summary Zone).
 *    - يضم ميزة «🙈 وضع التسميع الذاتي (إخفاء عمود الشرح)» ليختبر الطالب نفسه من عمود الأسئلة، مع تصدير PDF وWord وMarkdown.
 * 2) مدرب الاستدعاء النشط وإكمال الفراغات الذكي (Cloze Deletion & Active Recall Trainer):
 *    - يحوّل القوانين والتعريفات الواردة في الفصل تلقائياً إلى بطاقات إخفاء الكلمات المفتاحية (Cloze Recall)، فيكشف الطالب الكلمة المخفية أو يختارها ليقيس دقة تذكره النشط.
 * 3) المترجم والمبسّط الأكاديمي الثنائي اللغة (Bilingual Academic Explainer — عربي ⇄ English):
 *    - يستخرج المصطلحات العلمية والجامعية من النص مع ترجمتها الإنجليزية/العربية وشرح مبسط بمستويين (تأسيسي سريع + أكاديمي معمق).
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };

  var SN_KEY = "edu_smart_notes_v88";

  var ACADEMIC_TERMS_MAP = [
    ["الكسور العشرية", "Decimal Fractions", "كسور مقامها من قوى العشرة (10، 100، 1000) وتكتب بالفاصلة العشرية."],
    ["القيمة المنزلية", "Place Value", "قيمة الرقم حسب موقعه في العدد (آحاد، عشرات، أعشار، أجزاء من مئة)."],
    ["الخلية النباتية", "Plant Cell", "وحدة البناء في النبات وتتميز بالجدار الخلوي والبلاستيدات الخضراء."],
    ["البناء الضوئي", "Photosynthesis", "عملية حيوية يصنع فيها النبات غذاءه (الجلوكوز) بوجود الضوء والكلوروفيل."],
    ["التنفس الخلوي", "Cellular Respiration", "أكسدة الجلوكوز داخل الميتوكندريا لإنتاج جزيئات الطاقة الحيوية ATP."],
    ["نظرية فيثاغورس", "Pythagorean Theorem", "في المثلث القائم: مربع طول الوتر يساوي مجموع مربعي ضلعي القائمة (c² = a² + b²)."],
    ["قوانين نيوتن", "Newton's Laws of Motion", "القوانين الفيزيائية الثلاثة التي تربط القوى المؤثرة في الجسم بحركته وتسارعه (F = m.a)."],
    ["قواعد البيانات العلائقية", "Relational Databases (RDBMS)", "تنظيم البيانات في جداول مترابطة عبر المفاتيح الأساسية والأجنبية ولغة SQL."],
    ["المفتاح الأساسي", "Primary Key (PK)", "حقل معرّف فريد لكل سجل في الجدول لا يتكرر ولا يقبل القيمة الفارغة NULL."],
    ["الذكاء الاصطناعي", "Artificial Intelligence (AI)", "أنظمة برمجية تحاكي القدرات الذهنية البشرية في التعلم والاستنتاج وحل المشكلات."]
  ];

  function ensureSmartNotesState(st) {
    if (!st || typeof st !== "object") st = {};
    st.tab = ["cornell", "cloze", "explainer"].indexOf(st.tab) !== -1 ? st.tab : "cornell";
    st.sourceIdx = typeof st.sourceIdx === "number" && st.sourceIdx >= 0 ? st.sourceIdx : 0;
    st.hideNotesForRecall = !!st.hideNotesForRecall;
    st.revealedCloze = (st.revealedCloze && typeof st.revealedCloze === "object") ? st.revealedCloze : {};
    var cs = (st.clozeScore && typeof st.clozeScore === "object") ? st.clozeScore : {};
    st.clozeScore = {
      known: typeof cs.known === "number" && cs.known >= 0 ? cs.known : 0,
      review: typeof cs.review === "number" && cs.review >= 0 ? cs.review : 0
    };
    st.customSummary = typeof st.customSummary === "string" ? st.customSummary : "";
    return st;
  }

  function loadState() {
    var base = {
      tab: "cornell", // cornell | cloze | explainer
      sourceIdx: 0,
      hideNotesForRecall: false,
      revealedCloze: {},
      clozeScore: { known: 0, review: 0 },
      customSummary: ""
    };
    try {
      var raw = JSON.parse(localStorage.getItem(SN_KEY) || "null");
      if (raw && typeof raw === "object") {
        return ensureSmartNotesState(Object.assign(base, raw));
      }
    } catch (e) {}
    return ensureSmartNotesState(base);
  }

  var SState = loadState();
  function saveState() {
    ensureSmartNotesState(SState);
    try {
      localStorage.setItem(SN_KEY, JSON.stringify({
        tab: SState.tab,
        sourceIdx: SState.sourceIdx,
        hideNotesForRecall: SState.hideNotesForRecall,
        revealedCloze: SState.revealedCloze || {},
        clozeScore: SState.clozeScore || { known: 0, review: 0 },
        customSummary: SState.customSummary || ""
      }));
    } catch (e) {}
  }

  function getChaptersList() {
    var list = [];
    var books = (window.EduBookReader && window.EduBookReader.allBooks) ? window.EduBookReader.allBooks() : [];
    books.forEach(function (b) {
      (b.lessons || []).forEach(function (ls) {
        list.push({
          bookTitle: b.title,
          grade: b.grade || "عام",
          subject: b.subject || "عام",
          title: ls.t,
          rules: ls.k || [],
          text: ls.x || ""
        });
      });
    });
    if (!list.length) {
      list.push({
        bookTitle: "الرياضيات — الصف الرابع",
        grade: "الصف الرابع",
        subject: "الرياضيات",
        title: "الكسور العشرية وتمثيلها",
        rules: ["الكسر العشري: كسر مقامه 10 أو 100 أو 1000 ويكتب باستعمال الفاصلة العشرية."],
        text: "الكسر العشري هو حالة خاصة من الكسر العادي يكون مقامه 10 أو 100 أو 1000."
      });
    }
    return list;
  }

  // توليد بنية دفتر كورنيل من الفصل المختار
  function buildCornellData(ch) {
    var sents = String(ch.text || "").split(/[\n.؛]+/).map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 10; });
    var rules = (ch.rules && ch.rules.length) ? ch.rules : sents.slice(0, 3);
    var cues = rules.map(function (r, idx) {
      var parts = r.split(":");
      if (parts.length >= 2) return "❓ ما المقصود بـ / وضح قاعدة: «" + parts[0].trim() + "»؟";
      return "❓ السؤال المفتاحي " + (idx + 1) + ": كيف نطبق الفكرة الأساسية في هذا المحور؟";
    });
    if (cues.length < 3) {
      cues.push("❓ كيف نربط هذا المفهوم بالأمثلة والتطبيقات العملية؟");
      cues.push("❓ ما الأخطاء الشائعة التي يجب تجنبها عند حل المسائل في هذا الدرس؟");
    }
    var summary = SState.customSummary || ("خلاصة كورنيل الذهبية: يركز درس «" + ch.title + "» في (" + ch.bookTitle + ") على قاعدة (" + (rules[0] || ch.title) + ")، ويتم تطبيقه عملياً عبر اتباع الخطوات المنهجية بدقة وربط القوانين بالأمثلة التطبيقية.");
    return {
      cues: cues,
      notes: sents.length ? sents : [ch.text || ch.title],
      rules: rules,
      summary: summary
    };
  }

  // توليد بطاقات الاستدعاء النشط وإكمال الفراغات (Cloze Recall Cards)
  function buildClozeCards(ch) {
    var sents = String(ch.text || "").split(/[\n.؛]+/).map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 15; });
    var rules = (ch.rules && ch.rules.length) ? ch.rules : sents.slice(0, 4);
    var sourceLines = rules.concat(sents).slice(0, 5);

    return sourceLines.map(function (line, idx) {
      var words = line.split(/\s+/);
      // اختيار كلمة مفتاحية مهمة لإخفائها في تمرين التسميع النشط
      var targetIdx = Math.min(words.length - 1, Math.max(1, Math.floor(words.length / 2)));
      for (var i = 1; i < words.length; i++) {
        var cleanW = words[i].replace(/[:،.()]/g, "");
        if (cleanW.length >= 4 && !/^(على|إلى|بين|هذا|هذه|الذي|التي|يكون|تكون|حيث)$/.test(cleanW)) {
          targetIdx = i;
          break;
        }
      }
      var hiddenWord = words[targetIdx] || "المفهوم";
      var before = words.slice(0, targetIdx).join(" ");
      var after = words.slice(targetIdx + 1).join(" ");
      return {
        id: "clz-" + idx,
        before: before,
        hidden: hiddenWord,
        after: after,
        full: line
      };
    });
  }

  // استخراج المصطلحات الثنائية اللغة والشرح المبسط والمعمق
  function buildBilingualExplanation(ch) {
    var text = ch.title + " " + (ch.rules || []).join(" ") + " " + (ch.text || "");
    var matchedTerms = ACADEMIC_TERMS_MAP.filter(function (t) {
      var keyWord = t[0].split(" ")[0].replace(/^ال/, "");
      return text.indexOf(keyWord) !== -1;
    });
    if (!matchedTerms.length) {
      matchedTerms = [
        [ch.title.split(":")[0] || "المفهوم المحوري", "Core Academic Concept", (ch.rules && ch.rules[0]) || "القاعدة الأساسية التي يبنى عليها الفصل الدراسي."],
        ["التطبيق المنهجي", "Systematic Application", "توظيف القوانين والخطوات المرتبة في حل المسائل والتمارين."]
      ];
    }
    return {
      simpleAr: "💡 الشرح المبسط السريع (بأسلوب طالب ذكي): الفكرة ببساطة في درس «" + ch.title + "» هي أن نفهم القاعدة الأساسية (" + ((ch.rules && ch.rules[0]) || ch.title) + ") ثم نطبقها خطوة بخطوة على الأمثلة دون استعجال.",
      deepAcademic: "🎓 الشرح الأكاديمي المعمّق (للباحثين والمتفوقين): يندرج موضوع «" + ch.title + "» ضمن البنية المفاهيمية لمقرر (" + ch.subject + " — " + ch.grade + ")، حيث يربط بين التأصيل النظري للقوانين والتطبيق التحليلي في معالجة الحالات القياسية والمتقدمة.",
      terms: matchedTerms
    };
  }

  function ensureSmartNotesSection() {
    var ex = $("smartNotesFlashStudio");
    if (ex) return ex;
    var anchor = $("visualConceptExamStudio") || $("masteryAnalyticsStudio") || $("bookReaderStudio");
    if (!anchor || !anchor.parentNode) return null;
    var sec = document.createElement("section");
    sec.id = "smartNotesFlashStudio";
    sec.className = "py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20";
    anchor.parentNode.insertBefore(sec, anchor.nextSibling);
    return sec;
  }

  function renderSmartNotesStudio() {
    var sec = ensureSmartNotesSection();
    if (!sec) return;
    var pool = getChaptersList();
    if (SState.sourceIdx >= pool.length) SState.sourceIdx = 0;
    var ch = pool[SState.sourceIdx] || pool[0];
    var cornell = buildCornellData(ch);
    var clozeCards = buildClozeCards(ch);
    var explainer = buildBilingualExplanation(ch);
    var inpCls = "w-full text-xs font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100 outline-none focus:border-brand-500";

    sec.innerHTML =
      '<div class="glass-card rounded-3xl border-2 border-amber-500/35 dark:border-slate-700 shadow-2xl overflow-hidden text-right">' +
        // 1. Header Banner
        '<div class="p-5 sm:p-6 bg-gradient-to-l from-amber-950 via-indigo-950 to-slate-900 text-white">' +
          '<div class="flex flex-wrap items-center justify-between gap-3">' +
            '<div>' +
              '<div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-black mb-1.5">' +
                '<span>📓 استوديو دفتر كورنيل الذكي + مدرب الاستدعاء النشط (Cloze Recall) + المبسّط الأكاديمي المزدوج (الإصدار 88)</span>' +
              '</div>' +
              '<h2 class="text-lg sm:text-2xl font-black">لخّص أي كتاب أو محاضرة بنظام كورنيل العالمي، واختبر ذاكرتك بإكمال الفراغات التفاعلي والمصطلحات المزدوجة</h2>' +
              '<p class="text-xs text-slate-200 mt-1">أفضل استراتيجيات المذاكرة الجامعية والمدرسية عالمياً (Cornell Notes & Active Recall) متصلة مباشرة بقاعدة بيانات الـ Markdown وقارئ الكتب.</p>' +
            '</div>' +
            '<div class="flex flex-wrap gap-2">' +
              '<button type="button" id="snGoBookReaderBtn" class="px-3.5 py-2 rounded-xl bg-amber-400 text-slate-950 text-xs font-black shadow">📖 قارئ الكتب التفاعلي</button>' +
              '<button type="button" id="snGoVisualExamBtn" class="px-3.5 py-2 rounded-xl bg-white/15 text-white text-xs font-extrabold border border-white/20">🗺️ الخرائط والامتحان الموقوت</button>' +
            '</div>' +
          '</div>' +

          // Sub-Tabs
          '<div class="mt-4 pt-4 border-t border-white/15 flex flex-wrap gap-2">' +
            [
              { id: "cornell", ico: "📓", label: "1. دفتر الملاحظات الذكي بنظام كورنيل (Cornell 3-Zone Notebook)" },
              { id: "cloze", ico: "🧠", label: "2. مدرب الاستدعاء النشط وإكمال الفراغات (Cloze Active Recall)" },
              { id: "explainer", ico: "🌐", label: "3. المبسّط والمترجم الأكاديمي للمصطلحات (عربي ⇄ English)" }
            ].map(function (t) {
              var on = SState.tab === t.id;
              return '<button type="button" data-sn-tab="' + t.id + '" class="px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 ' +
                (on ? "bg-amber-400 text-slate-950 font-black shadow" : "bg-white/10 hover:bg-white/20 text-slate-200") + '">' +
                '<span>' + t.ico + '</span><span>' + t.label + '</span>' +
              '</button>';
            }).join("") +
          '</div>' +
        '</div>' +

        // 2. Body
        '<div class="p-5 sm:p-6 space-y-5">' +
          '<div class="grid grid-cols-1 lg:grid-cols-12 gap-3 items-end bg-slate-50 dark:bg-slate-900/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700">' +
            '<div class="lg:col-span-6">' +
              '<label class="block text-xs font-black mb-1">📚 اختر الفصل أو الكتاب من قاعدة بيانات الموقع:</label>' +
              '<select id="snSelectChapter" class="' + inpCls + '">' +
                pool.map(function (c, idx) {
                  return '<option value="' + idx + '"' + (SState.sourceIdx === idx ? " selected" : "") + '>' + esc(c.bookTitle + " — " + c.title) + '</option>';
                }).join("") +
              '</select>' +
            '</div>' +
            '<div class="lg:col-span-6 flex flex-wrap gap-2">' +
              (SState.tab === "cornell"
                ? '<button type="button" id="snToggleRecallMode" class="px-4 py-2.5 rounded-xl text-xs font-black shadow transition ' +
                    (SState.hideNotesForRecall ? "bg-amber-500 text-slate-950" : "bg-indigo-600 text-white") + '">' +
                    (SState.hideNotesForRecall ? "👁️ إظهار عمود الشرح والتفاصيل" : "🙈 إخفاء الشرح للتسميع الذاتي من الأسئلة") +
                  '</button>' +
                  '<button type="button" id="snSaveCornellMd" class="px-3.5 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black shadow">📝 حفظ الدفتر كـ Markdown بالقاعدة</button>' +
                  '<button type="button" onclick="window.print()" class="px-3.5 py-2.5 rounded-xl bg-slate-800 text-white text-xs font-black">🖨 طباعة كورنيل PDF</button>'
                : SState.tab === "cloze"
                ? '<button type="button" id="snRevealAllCloze" class="px-4 py-2.5 rounded-xl bg-brand-600 text-white text-xs font-black">👁️ كشف جميع الكلمات المخفية</button>' +
                  '<button type="button" id="snHideAllCloze" class="px-4 py-2.5 rounded-xl bg-slate-800 text-white text-xs font-black">🙈 إخفاء الكل للتدريب من جديد</button>'
                : '<button type="button" id="snSendTermsToReview" class="px-4 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black shadow">🧠 إرسال المصطلحات المزدوجة للمراجعة المتباعدة</button>') +
            '</div>' +
          '</div>' +

          (SState.tab === "cloze"
            ? renderClozeTrainerHtml(ch, clozeCards)
            : SState.tab === "explainer"
            ? renderAcademicExplainerHtml(ch, explainer)
            : renderCornellSheetHtml(ch, cornell, inpCls)) +
        '</div>' +
      '</div>';

    bindSmartNotesEvents(sec, pool, ch, cornell, clozeCards, explainer);
  }

  function renderCornellSheetHtml(ch, cornell, inpCls) {
    return '<div class="rounded-3xl border-2 border-slate-300 dark:border-slate-700 bg-[#fdfaf2] dark:bg-slate-900 overflow-hidden shadow-lg">' +
      // رأس ورقة كورنيل
      '<div class="p-4 sm:p-5 border-b-2 border-slate-300 dark:border-slate-700 bg-amber-500/10 flex flex-wrap items-center justify-between gap-2">' +
        '<div>' +
          '<div class="text-[11px] font-black text-amber-800 dark:text-amber-300">📓 ورقة مذاكرة بنظام كورنيل القياسي (Cornell Note-Taking System)</div>' +
          '<h3 class="text-base sm:text-lg font-black text-slate-900 dark:text-white mt-0.5">' + esc(ch.title) + ' — <span class="text-indigo-600 dark:text-sky-400">' + esc(ch.bookTitle) + '</span></h3>' +
        '</div>' +
        '<span class="px-3 py-1 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-black">' + esc(ch.grade + " • " + ch.subject) + '</span>' +
      '</div>' +

      // المنطقتان الوسطى: عمود الأسئلة المفتاحية (35%) + عمود الشرح والملاحظات (65%)
      '<div class="grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x lg:divide-x-reverse divide-slate-300 dark:divide-slate-700">' +
        // 1. عمود الأسئلة المفتاحية والكلمات الدلالية (Cue Column)
        '<div class="lg:col-span-4 p-4 sm:p-5 bg-indigo-500/5 space-y-3">' +
          '<div class="text-xs font-black text-indigo-700 dark:text-sky-300 border-b border-indigo-500/20 pb-1.5">🔑 عمود الأسئلة المفتاحية للتسميع (Cues & Questions)</div>' +
          '<div class="space-y-2.5">' +
            cornell.cues.map(function (q) {
              return '<div class="p-3 rounded-xl bg-white dark:bg-slate-800 border border-indigo-500/30 text-xs font-bold leading-relaxed shadow-xs">' + esc(q) + '</div>';
            }).join("") +
          '</div>' +
        '</div>' +

        // 2. عمود الشرح والتفاصيل والقوانين (Notes Column)
        '<div class="lg:col-span-8 p-4 sm:p-5 space-y-3">' +
          '<div class="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-1.5">' +
            '<span class="text-xs font-black text-emerald-700 dark:text-emerald-400">📝 عمود الشرح التفصيلي والقواعد والأمثلة (Detailed Notes)</span>' +
            (SState.hideNotesForRecall ? '<span class="text-[11px] font-black text-amber-600">🙈 مخفي للتسميع الذاتي — حاول الإجابة عن الأسئلة باليمين!</span>' : '') +
          '</div>' +
          (SState.hideNotesForRecall
            ? '<div class="p-8 rounded-2xl border-2 border-dashed border-amber-500/50 bg-amber-500/5 text-center space-y-3">' +
                '<div class="text-3xl">🙈</div>' +
                '<div class="text-sm font-black">عمود الشرح مخفي الآن لاختبار ذاكرتك النشطة!</div>' +
                '<p class="text-xs text-slate-500">اقرأ الأسئلة المفتاحية في العمود الأيمن وحاول تسميع الإجابة، ثم اضغط الزر أدناه للتحقق:</p>' +
                '<button type="button" id="snRevealNotesInline" class="px-5 py-2 rounded-xl bg-amber-500 text-slate-950 text-xs font-black shadow">👁️ اكشف الشرح للتحقق من إجابتي</button>' +
              '</div>'
            : '<div class="space-y-2.5 text-xs leading-relaxed font-semibold">' +
                cornell.rules.map(function (r) {
                  return '<div class="p-3 rounded-xl bg-amber-500/10 border-r-4 border-amber-500 font-bold text-slate-900 dark:text-white">💡 ' + esc(r) + '</div>';
                }).join("") +
                cornell.notes.map(function (n) {
                  return '<div class="p-2.5 rounded-xl bg-white/80 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">• ' + esc(n) + '</div>';
                }).join("") +
              '</div>') +
        '</div>' +
      '</div>' +

      // 3. منطقة الخلاصة الذهبية بالأسفل (Summary Row)
      '<div class="p-4 sm:p-5 border-t-2 border-slate-300 dark:border-slate-700 bg-emerald-500/10 space-y-2">' +
        '<div class="text-xs font-black text-emerald-800 dark:text-emerald-300">📌 الخلاصة الذهبية أسفل الصفحة (Bottom 2-Minute Summary — قابلة للتعديل):</div>' +
        '<textarea id="snCornellSummaryInp" rows="2" class="' + inpCls + '">' + esc(cornell.summary) + '</textarea>' +
      '</div>' +
    '</div>';
  }

  function renderClozeTrainerHtml(ch, cards) {
    ensureSmartNotesState(SState);
    return '<div class="space-y-4">' +
      '<div class="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex flex-wrap items-center justify-between gap-2 text-xs">' +
        '<div class="font-bold">🧠 <b>طريقة التدريب:</b> اقرأ الجملة المستخرجة من الكتاب وحاول تذكر الكلمة المفتاحية المخفية داخل الزر الأصفر، ثم اضغط عليها لكشفها!</div>' +
        '<span class="px-3 py-1 rounded-full bg-emerald-600 text-white font-black">✓ تدرّب: ' + SState.clozeScore.known + ' متقن</span>' +
      '</div>' +
      '<div class="space-y-3">' +
        cards.map(function (c, idx) {
          var isRev = !!SState.revealedCloze[c.id];
          return '<div class="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">' +
            '<div class="text-xs sm:text-sm font-bold leading-loose flex-1">' +
              '<span class="text-slate-400 font-black ml-1.5">' + (idx + 1) + ')</span>' +
              esc(c.before) + " " +
              '<button type="button" data-sn-cloze="' + c.id + '" class="mx-1 px-3 py-1 rounded-xl font-black transition ' +
                (isRev ? "bg-emerald-600 text-white shadow" : "bg-amber-400 hover:bg-amber-300 text-slate-950 shadow") + '">' +
                (isRev ? esc(c.hidden) + " ✓" : "❓ [اضغط لكشف المصطلح المخفي]") +
              '</button> ' +
              esc(c.after) +
            '</div>' +
            (isRev
              ? '<div class="flex gap-1.5 shrink-0">' +
                  '<button type="button" data-sn-rate="ok" data-sn-cid="' + c.id + '" class="px-2.5 py-1 rounded-lg bg-emerald-500/15 text-emerald-600 text-[11px] font-black">✅ تذكرتها</button>' +
                  '<button type="button" data-sn-rate="again" data-sn-cid="' + c.id + '" class="px-2.5 py-1 rounded-lg bg-rose-500/15 text-rose-500 text-[11px] font-black">🔁 أخفِ مجدداً</button>' +
                '</div>'
              : '') +
          '</div>';
        }).join("") +
      '</div>' +
    '</div>';
  }

  function renderAcademicExplainerHtml(ch, ex) {
    return '<div class="space-y-4">' +
      '<div class="grid grid-cols-1 md:grid-cols-2 gap-4">' +
        '<div class="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-xs leading-relaxed font-semibold">' + esc(ex.simpleAr) + '</div>' +
        '<div class="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 text-xs leading-relaxed font-semibold">' + esc(ex.deepAcademic) + '</div>' +
      '</div>' +
      '<div class="rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">' +
        '<table class="w-full text-right text-xs border-collapse">' +
          '<thead><tr class="bg-slate-900 text-white"><th class="p-3 font-black">المصطلح بالعربية</th><th class="p-3 font-black text-amber-300" dir="ltr">English Technical Term</th><th class="p-3 font-black">التعريف والشرح الأكاديمي المبسط</th></tr></thead>' +
          '<tbody class="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900">' +
            ex.terms.map(function (t) {
              return '<tr><td class="p-3 font-black text-brand-600 dark:text-sky-400">' + esc(t[0]) + '</td><td class="p-3 font-mono font-black text-indigo-600 dark:text-indigo-300" dir="ltr">' + esc(t[1]) + '</td><td class="p-3 font-semibold">' + esc(t[2]) + '</td></tr>';
            }).join("") +
          '</tbody>' +
        '</table>' +
      '</div>' +
    '</div>';
  }

  function bindSmartNotesEvents(sec, pool, ch, cornell, clozeCards, explainer) {
    if ($("snGoBookReaderBtn")) $("snGoBookReaderBtn").onclick = function () {
      if (window.EduBookReader && window.EduBookReader.open) window.EduBookReader.open(null, 0, "interactive");
    };
    if ($("snGoVisualExamBtn")) $("snGoVisualExamBtn").onclick = function () {
      if (window.EduVisualExam && window.EduVisualExam.open) window.EduVisualExam.open("conceptmap");
    };

    sec.querySelectorAll("[data-sn-tab]").forEach(function (b) {
      b.onclick = function () {
        SState.tab = b.getAttribute("data-sn-tab");
        saveState();
        renderSmartNotesStudio();
      };
    });

    if ($("snSelectChapter")) $("snSelectChapter").onchange = function (e) {
      SState.sourceIdx = +e.target.value;
      SState.customSummary = "";
      SState.revealedCloze = {};
      saveState();
      renderSmartNotesStudio();
    };

    if ($("snToggleRecallMode")) $("snToggleRecallMode").onclick = function () {
      SState.hideNotesForRecall = !SState.hideNotesForRecall;
      saveState();
      renderSmartNotesStudio();
    };
    if ($("snRevealNotesInline")) $("snRevealNotesInline").onclick = function () {
      SState.hideNotesForRecall = false;
      saveState();
      renderSmartNotesStudio();
    };
    if ($("snCornellSummaryInp")) $("snCornellSummaryInp").oninput = function (e) {
      SState.customSummary = e.target.value;
      saveState();
    };

    if ($("snSaveCornellMd")) $("snSaveCornellMd").onclick = function () {
      var md = "# 📓 دفتر كورنيل الذكي: " + ch.title + "\n" +
        "> **الكتاب:** " + ch.bookTitle + " | **الصف:** " + ch.grade + "\n\n" +
        "## أولاً: الأسئلة المفتاحية (Cues)\n- " + cornell.cues.join("\n- ") + "\n\n" +
        "## ثانياً: الشرح والقوانين (Notes)\n- " + cornell.rules.concat(cornell.notes).join("\n- ") + "\n\n" +
        "## ثالثاً: الخلاصة الذهبية (Summary)\n" + cornell.summary + "\n";
      if (window.EduSources && window.EduSources.addRaw) {
        window.EduSources.addRaw({
          kind: "md",
          name: "دفتر_كورنيل_" + ch.title.slice(0, 22).replace(/\s+/g, "_") + ".md",
          mime: "text/markdown",
          markdown: md,
          data: btoa(unescape(encodeURIComponent(md)))
        }, true);
      }
      toast("📝 تم حفظ دفتر كورنيل بصيغة Markdown في قاعدة بيانات الموقع ✓", "success");
    };

    // أحداث الاستدعاء النشط Cloze
    sec.querySelectorAll("[data-sn-cloze]").forEach(function (b) {
      b.onclick = function () {
        var cid = b.getAttribute("data-sn-cloze");
        SState.revealedCloze[cid] = !SState.revealedCloze[cid];
        renderSmartNotesStudio();
      };
    });
    sec.querySelectorAll("[data-sn-rate]").forEach(function (b) {
      b.onclick = function () {
        var rate = b.getAttribute("data-sn-rate");
        var cid = b.getAttribute("data-sn-cid");
        ensureSmartNotesState(SState);
        if (rate === "ok") {
          SState.clozeScore.known++;
          saveState();
          toast("🌟 أحسنت! تم تسجيل استدعاء نشط ناجح (+10 XP)", "success");
        } else {
          SState.revealedCloze[cid] = false;
        }
        renderSmartNotesStudio();
      };
    });
    if ($("snRevealAllCloze")) $("snRevealAllCloze").onclick = function () {
      clozeCards.forEach(function (c) { SState.revealedCloze[c.id] = true; });
      renderSmartNotesStudio();
    };
    if ($("snHideAllCloze")) $("snHideAllCloze").onclick = function () {
      SState.revealedCloze = {};
      renderSmartNotesStudio();
    };

    if ($("snSendTermsToReview")) $("snSendTermsToReview").onclick = function () {
      var cards = explainer.terms.map(function (t) {
        return { q: "ما المصطلح الإنجليزي والتعريف لـ «" + t[0] + "»؟", a: t[1] + " — " + t[2] };
      });
      if (window.EduBridge && window.EduBridge.toReview) {
        window.EduBridge.toReview("مصطلحات: " + ch.title, cards);
      } else {
        toast("🧠 تمت إضافة المصطلحات المزدوجة إلى بطاقات المراجعة المتباعدة ✓", "success");
      }
    };
  }

  function openSmartNotes(tabName) {
    if (tabName) SState.tab = tabName;
    saveState();
    renderSmartNotesStudio();
    if (window.EduLauncher && window.EduLauncher.jump) {
      window.EduLauncher.jump("smartNotesFlashStudio", true);
    } else {
      var sec = $("smartNotesFlashStudio");
      if (sec) sec.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  function init() {
    renderSmartNotesStudio();
    
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();

  window.EduSmartNotes = {
    open: openSmartNotes,
    render: renderSmartNotesStudio
  };
})();

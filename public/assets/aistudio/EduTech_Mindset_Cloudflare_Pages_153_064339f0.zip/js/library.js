/* مكتبة المواد الدراسية — EduTech Mindset (الإصدار 57)
 * لكل مادة توجيهي: فيديوهات وملخصات واختبارات قصيرة تفاعلية وروابط.
 * التخزين: مستند site/library في Firestore (قراءة للجميع، كتابة للإدارة فقط وفق القواعد الحالية).
 * وعند تعذّر السحابة يُحفظ التعديل محلياً على جهاز الإدارة. */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var LS = "edutech_library_v1";
  var SUBJECTS = [["arabic", "اللغة العربية", "📖"], ["math", "الرياضيات", "📐"], ["physics", "الفيزياء", "⚛️"], ["chem", "الكيمياء", "🧪"], ["bio", "الأحياء", "🧬"], ["history", "التاريخ", "🏛️"], ["geo", "الجغرافيا", "🌍"]];
  var TYPES = { video: "🎬 فيديو", summary: "📝 ملخص", quiz: "❓ اختبار", link: "🔗 رابط" };
  var st = { subject: "arabic", data: {}, quizState: {} };

  function isAdmin() { return !!(window.Cloud && window.Cloud.isAdmin); }
  function uid() { return "i" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

  function load() {
    try { st.data = JSON.parse(localStorage.getItem(LS)) || {}; } catch (e) { st.data = {}; }
    try {
      if (window.Cloud && window.Cloud.col) {
        window.Cloud.col("site").doc("library").onSnapshot(function (s) {
          if (s.exists && s.data() && s.data().json) { try { st.data = JSON.parse(s.data().json); } catch (e) {} paint(); }
        }, function () {});
      }
    } catch (e) {}
  }
  function save() {
    try { localStorage.setItem(LS, JSON.stringify(st.data)); } catch (e) {}
    if (isAdmin() && window.Cloud.col) {
      window.Cloud.col("site").doc("library").set({ kind: "library", json: JSON.stringify(st.data), at: new Date().toISOString() })
        .then(function () { toast("تم الحفظ على السحابة ✅"); })
        .catch(function () { toast("تعذّر الحفظ على السحابة، حُفظ محلياً فقط", "warning"); });
    }
  }
  function toast(m, t) { if (typeof showToast === "function") showToast(m, t || "success"); }

  function embedUrl(u) {
    var m = String(u || "").match(/(?:youtu\.be\/|v=|embed\/|shorts\/)([A-Za-z0-9_-]{11})/);
    return m ? "https://www.youtube.com/embed/" + m[1] : "";
  }
  function parseQuiz(txt) {
    return String(txt || "").split("\n").map(function (l) { return l.split("|").map(function (x) { return x.trim(); }); })
      .filter(function (p) { return p.length >= 4 && !isNaN(parseInt(p[p.length - 1], 10)); })
      .map(function (p) { var c = parseInt(p[p.length - 1], 10); return { q: p[0], o: p.slice(1, -1), c: c - 1 }; });
  }

  function itemHtml(it) {
    var h = '<div class="rounded-2xl border border-slate-200 dark:border-slate-700 p-4 bg-white/70 dark:bg-slate-900/50"><div class="flex items-start justify-between gap-2"><div class="font-black text-sm">' + (TYPES[it.type] || "") + " — " + esc(it.title) + "</div>" +
      (isAdmin() ? '<button type="button" data-del="' + esc(it.id) + '" class="text-xs text-rose-600 font-black px-2" aria-label="حذف">🗑</button>' : "") + "</div>";
    if (it.type === "video") {
      var em = embedUrl(it.content);
      h += em ? '<div class="mt-3 aspect-video rounded-xl overflow-hidden bg-black"><iframe class="w-full h-full" loading="lazy" src="' + esc(em) + '" title="' + esc(it.title) + '" allowfullscreen></iframe></div>'
              : '<a class="inline-block mt-3 px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-black" target="_blank" rel="noopener" href="' + esc(it.content) + '">▶ شاهد الفيديو</a>';
    } else if (it.type === "summary") {
      h += '<div class="mt-3 text-sm leading-7 whitespace-pre-line">' + esc(it.content) + "</div>";
    } else if (it.type === "link") {
      h += '<a class="inline-block mt-3 px-4 py-2 rounded-xl bg-sky-600 text-white text-xs font-black" target="_blank" rel="noopener" href="' + esc(it.content) + '">فتح الرابط ↗</a>';
    } else if (it.type === "quiz") {
      var qs = parseQuiz(it.content), s = st.quizState[it.id] || {};
      h += '<div class="mt-3 space-y-4">' + qs.map(function (q, qi) {
        return '<div><div class="text-sm font-bold mb-2">' + (qi + 1) + ") " + esc(q.q) + '</div><div class="grid gap-2">' + q.o.map(function (o, oi) {
          var cls = "bg-slate-100 dark:bg-slate-800", picked = s[qi];
          if (picked != null) { if (oi === q.c) cls = "bg-emerald-600 text-white"; else if (oi === picked) cls = "bg-rose-600 text-white"; }
          return '<button type="button" data-q="' + esc(it.id) + ":" + qi + ":" + oi + '" class="text-right px-3 py-2 rounded-xl text-xs font-bold ' + cls + '"' + (picked != null ? " disabled" : "") + ">" + esc(o) + "</button>";
        }).join("") + "</div></div>";
      }).join("") + (qs.length && Object.keys(s).length === qs.length ? '<div class="font-black text-sm text-emerald-700">نتيجتك: ' + qs.filter(function (q, i) { return s[i] === q.c; }).length + " / " + qs.length + "</div>" : "") + (qs.length ? "" : '<div class="text-xs text-rose-600">صيغة الأسئلة غير صحيحة.</div>') + "</div>";
    }
    return h + "</div>";
  }

  function paint() {
    var box = $("libBody"); if (!box) return;
    var items = st.data[st.subject] || [];
    $("libChips").innerHTML = SUBJECTS.map(function (s) {
      var on = s[0] === st.subject;
      return '<button type="button" data-sub="' + s[0] + '" class="px-3 py-2 rounded-xl text-xs font-black ' + (on ? "bg-sky-600 text-white" : "bg-slate-200 dark:bg-slate-800") + '">' + s[2] + " " + s[1] + " (" + (st.data[s[0]] || []).length + ")</button>";
    }).join("");
    box.innerHTML = items.length ? items.map(itemHtml).join("") : '<div class="text-sm text-slate-500 py-6 text-center">لا توجد مواد في هذا القسم بعد. ' + (isAdmin() ? "أضف أول مادة من النموذج أدناه." : "ترقّبوا الإضافات قريباً ✨") + "</div>";
    $("libAdmin").style.display = isAdmin() ? "block" : "none";
  }

  function build() {
    if ($("libraryStudio")) return true;
    var anchor = $("atlasStudio") || $("learnSection"); if (!anchor) return false;
    var s = document.createElement("section"); s.id = "libraryStudio"; s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8"><div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-sky-800 via-indigo-900 to-slate-950 text-white"><div class="text-xs font-extrabold text-amber-300 mb-1">📚 مكتبة التوجيهي</div><h2 class="text-xl sm:text-2xl font-black">مكتبة المواد الدراسية</h2><p class="text-xs text-white/85 mt-1">فيديوهات وملخصات واختبارات قصيرة لكل مادة، في مكان واحد.</p></div>' +
      '<div class="p-4 sm:p-6 space-y-4 text-right"><div id="libChips" class="flex flex-wrap gap-2"></div><div id="libBody" class="grid gap-4 md:grid-cols-2"></div>' +
      '<div id="libAdmin" style="display:none" class="border-t border-slate-200 dark:border-slate-700 pt-4 space-y-2"><div class="font-black text-sm">➕ إضافة مادة (للإدارة)</div>' +
      '<select id="libType" class="w-full rounded-xl border p-2 text-sm bg-white dark:bg-slate-900"><option value="video">فيديو (رابط يوتيوب)</option><option value="summary">ملخص (نص)</option><option value="quiz">اختبار قصير</option><option value="link">رابط</option></select>' +
      '<input id="libTitle" class="w-full rounded-xl border p-2 text-sm bg-white dark:bg-slate-900" placeholder="العنوان">' +
      '<textarea id="libContent" rows="5" class="w-full rounded-xl border p-2 text-sm bg-white dark:bg-slate-900" placeholder="الرابط أو النص. الاختبار: كل سطر سؤال بالشكل  السؤال | خيار1 | خيار2 | خيار3 | رقم الصحيح"></textarea>' +
      '<button type="button" id="libAdd" class="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-black">حفظ في هذا القسم</button></div></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    s.addEventListener("click", function (ev) {
      var t = ev.target.closest("button"); if (!t) return;
      if (t.dataset.sub) { st.subject = t.dataset.sub; paint(); }
      else if (t.dataset.del) { if (!window.eduConfirm("حذف هذه المادة؟")) return; st.data[st.subject] = (st.data[st.subject] || []).filter(function (x) { return x.id !== t.dataset.del; }); save(); paint(); }
      else if (t.dataset.q) { var p = t.dataset.q.split(":"); (st.quizState[p[0]] = st.quizState[p[0]] || {})[+p[1]] = +p[2]; paint(); }
      else if (t.id === "libAdd") {
        var title = $("libTitle").value.trim(), content = $("libContent").value.trim(), type = $("libType").value;
        if (!title || !content) return toast("أكمل العنوان والمحتوى", "warning");
        if (type === "quiz" && !parseQuiz(content).length) return toast("صيغة الاختبار غير صحيحة", "warning");
        (st.data[st.subject] = st.data[st.subject] || []).push({ id: uid(), type: type, title: title, content: content });
        $("libTitle").value = ""; $("libContent").value = ""; save(); paint();
      }
    });
    paint(); return true;
  }
  function init() { load(); if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250); window.addEventListener('edu:admin-state-changed', function () { var a = isAdmin(); if (a !== st._a) { st._a = a; paint(); } }); }
  window.EduLibrary = { open: function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("libraryStudio", true); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

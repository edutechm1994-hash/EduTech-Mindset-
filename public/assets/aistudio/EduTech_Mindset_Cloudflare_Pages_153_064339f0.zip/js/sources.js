/* مصادري (المنهاج الفلسطيني) + محوّل PDF إلى Markdown + قاعدة بيانات الكتب الخاصة بالموقع — EduTech Mindset (الإصدار 82)
 * التطويرات الكبرى:
 * 1) توسيع سعة المصادر المفعّلة من 7.9 ميغابايت إلى 500 ميغابايت (وحد ملف الـ PDF الواحد حتى 150 ميغابايت) لتتسع للكتب المدرسية الكاملة.
 * 2) دعم كامل لملفات ومحررات Markdown (.md): رفع ملفات .md/.txt، تحرير ومعاينة حية، وتنزيل ملفات Markdown.
 * 3) محرك تحويل PDF (والصور) إلى Markdown مهيكل وتسجيله تلقائياً في قاعدة بيانات خاصة بالموقع (IndexedDB + appState.books + قارئ الكتب التفاعلي + المساعد الذكي).
 * 4) بحث فوري شامل داخل قاعدة بيانات الـ Markdown وتصدير/استيراد القاعدة بصيغة JSON أو Markdown. */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };

  // توسيع السعة إلى 500 ميغابايت (حوالي 700 مليون حرف Base64) وحد الملف الواحد إلى 150 ميغابايت
  var BUDGET = 700e6;
  var MAX_PDF = 150 * 1024 * 1024;
  var KEY_CUR = "edutech_curriculum_on";
  var KB_LS_KEY = "edu_site_kb_db_v82";
  var items = [], kbRecords = [], db = null;
  var activeMdItem = null; // العنصر المفتوح حالياً في محرر/معاين الـ Markdown
  var kbSearchQuery = "";

  var CURRICULUM = "أنت مساعد تعليمي يعتمد المنهاج الفلسطيني (وزارة التربية والتعليم العالي الفلسطينية): التزم بمصطلحاته وتسلسل دروسه وأمثلته وبالصف والمادة المذكورين. " +
    "إن أُرفقت مصادر (كتب محوّلة إلى Markdown أو صفحات كتب أو صور) فأجب منها أولاً واذكر اسم الكتاب أو عنوان الوحدة/الدرس أو رقم الصفحة عند توفره، وإن لم تجد الإجابة فيها فقل ذلك صراحة ولا تخترع معلومة.\n\n";

  // ---------- 1. التخزين المحلي المزدوج (IndexedDB للمصادر الضخمة + قاعدة بيانات الموقع المهيكلة) ----------
  function open() {
    return new Promise(function (res, rej) {
      if (db) return res(db);
      var r = indexedDB.open("edutech_sources", 2);
      r.onupgradeneeded = function (ev) {
        var d = r.result;
        if (!d.objectStoreNames.contains("items")) d.createObjectStore("items", { keyPath: "id" });
        if (!d.objectStoreNames.contains("kb_books")) d.createObjectStore("kb_books", { keyPath: "id" });
      };
      r.onsuccess = function () { db = r.result; res(db); };
      r.onerror = function () { rej(r.error); };
    });
  }
  function tx(storeName, mode, fn) {
    return open().then(function (d) {
      return new Promise(function (res, rej) {
        var actualStore = d.objectStoreNames.contains(storeName) ? storeName : "items";
        var t = d.transaction(actualStore, mode), s = t.objectStore(actualStore), out = fn(s);
        t.oncomplete = function () { res(out && out.result); };
        t.onerror = function () { rej(t.error); };
      });
    });
  }
  function loadAll() {
    return tx("items", "readonly", function (s) { return s.getAll(); }).then(function (a) {
      items = (a || []).sort(function (x, y) { return (y.at || 0) - (x.at || 0); });
    }).then(function () {
      return loadKbRecords();
    });
  }
  function put(it) { return tx("items", "readwrite", function (s) { return s.put(it); }); }
  function del(id) { return tx("items", "readwrite", function (s) { return s.delete(id); }); }

  // إدارة قاعدة بيانات الموقع الخاصة بالكتب المحوّلة (Site Markdown Knowledge Base)
  function loadKbRecords() {
    try {
      var localArr = JSON.parse(localStorage.getItem(KB_LS_KEY) || "[]");
      if (Array.isArray(localArr)) kbRecords = localArr;
    } catch (e) { kbRecords = []; }
    return open().then(function (d) {
      if (!d.objectStoreNames.contains("kb_books")) return kbRecords;
      return tx("kb_books", "readonly", function (s) { return s.getAll(); }).then(function (dbArr) {
        if (Array.isArray(dbArr) && dbArr.length) {
          var seen = {};
          var merged = [];
          dbArr.concat(kbRecords).forEach(function (r) {
            if (r && r.id && !seen[r.id]) { seen[r.id] = 1; merged.push(r); }
          });
          kbRecords = merged.sort(function (a, b) { return (b.updatedAt || 0) - (a.updatedAt || 0); });
          syncKbToSiteBooks();
        }
        return kbRecords;
      });
    }).catch(function () { return kbRecords; });
  }

  function saveKbRecord(rec) {
    rec.id = rec.id || ("kb-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5));
    rec.updatedAt = Date.now();
    var idx = kbRecords.findIndex(function (x) { return x.id === rec.id; });
    if (idx > -1) kbRecords[idx] = rec;
    else kbRecords.unshift(rec);

    try {
      // حفظ نسخة خفيفة في localStorage للوصول الفوري
      localStorage.setItem(KB_LS_KEY, JSON.stringify(kbRecords.slice(0, 40)));
    } catch (e) {}

    syncKbToSiteBooks();
    return open().then(function (d) {
      if (!d.objectStoreNames.contains("kb_books")) return rec;
      return tx("kb_books", "readwrite", function (s) { return s.put(rec); }).then(function () { return rec; });
    }).catch(function () { return rec; });
  }

  function deleteKbRecord(id) {
    kbRecords = kbRecords.filter(function (x) { return x.id !== id; });
    try { localStorage.setItem(KB_LS_KEY, JSON.stringify(kbRecords)); } catch (e) {}
    if (window.appState && Array.isArray(window.appState.books)) {
      window.appState.books = window.appState.books.filter(function (b) { return b.id !== id; });
      if (typeof window.saveState === "function") window.saveState();
    }
    if (window.EduBooks && window.EduBooks.render) window.EduBooks.render();
    if (window.EduBookReader && window.EduBookReader.render) window.EduBookReader.render();
    return open().then(function (d) {
      if (!d.objectStoreNames.contains("kb_books")) return;
      return tx("kb_books", "readwrite", function (s) { return s.delete(id); });
    }).catch(function () {});
  }

  // تغذية العقل البرمجي الخفي للموقع (Offline Markdown Brain) دون إظهار ملفات الـ Markdown الخام في قائمة القراءة العامة
  function syncKbToSiteBooks() {
    if (window.appState && Array.isArray(window.appState.books)) {
      // إزالة أي سجلات Markdown خام من قائمة الكتب العامة لتبقى قائمة الكتب مخصصة للكتب الأصلية وكتب Google Drive فقط
      window.appState.books = window.appState.books.filter(function (b) { return !b.fromKbDb; });
    }
    if (window.EduOfflineBrain && typeof window.EduOfflineBrain.addHiddenMarkdownPack === "function") {
      kbRecords.forEach(function (kb) {
        if (kb && kb.markdown && !kb.__syncedBrain90) {
          kb.__syncedBrain90 = true;
          window.EduOfflineBrain.addHiddenMarkdownPack(kb.title, kb.subject || "كتب ومعارف تعليمية", kb.markdown);
        }
      });
    }
  }

  // ---------- 2. أدوات الملفات (PDF، صور، وملفات Markdown/Text) ----------
  function b64(file) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(",")[1] || ""); };
      r.onerror = rej;
      r.readAsDataURL(file);
    });
  }
  function readTextFile(file) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result || "")); };
      r.onerror = rej;
      r.readAsText(file, "utf-8");
    });
  }
  function utf8ToB64(str) {
    try { return btoa(unescape(encodeURIComponent(str || ""))); } catch (e) { return ""; }
  }
  function shrink(file) {
    return new Promise(function (res, rej) {
      var url = URL.createObjectURL(file), im = new Image();
      im.onload = function () {
        var k = Math.min(1, 1600 / Math.max(im.width, im.height)), c = document.createElement("canvas");
        c.width = Math.max(1, Math.round(im.width * k)); c.height = Math.max(1, Math.round(im.width * k));
        var cx = c.getContext("2d"); cx.fillStyle = "#fff"; cx.fillRect(0, 0, c.width, c.height); cx.drawImage(im, 0, 0, c.width, c.height);
        var t = document.createElement("canvas"); t.width = 96; t.height = Math.max(1, Math.round(96 * c.height / c.width)); t.getContext("2d").drawImage(c, 0, 0, t.width, t.height);
        URL.revokeObjectURL(url);
        res({ data: c.toDataURL("image/jpeg", 0.82).split(",")[1], thumb: t.toDataURL("image/jpeg", 0.6) });
      };
      im.onerror = function () { URL.revokeObjectURL(url); rej(new Error("img")); };
      im.src = url;
    });
  }
  function mb(n) { return (n * 0.75 / 1048576).toFixed(1); }
  function activeLen() { return items.reduce(function (n, i) { return n + (i.active ? (i.data ? i.data.length : 0) : 0); }, 0); }

  function addFiles(list, autoConvertToDb) {
    var arr = Array.prototype.slice.call(list || []);
    return arr.reduce(function (p, f) {
      return p.then(function () {
        var isPdf = f.type === "application/pdf" || /\.pdf$/i.test(f.name || "");
        var isMdOrTxt = /\.(md|markdown|txt|json|csv)$/i.test(f.name || "") || /^text\//.test(f.type || "");
        if (isMdOrTxt) {
          return readTextFile(f).then(function (txt) {
            var item = {
              kind: "md",
              name: f.name || ("ملف-" + Date.now() + ".md"),
              mime: "text/markdown",
              markdown: txt,
              data: utf8ToB64(txt)
            };
            return save(item).then(function (savedIt) {
              activeMdItem = savedIt;
              if (autoConvertToDb) return registerItemInSiteDb(savedIt, true);
              toast("📝 تم استيراد ملف الـ Markdown «" + item.name + "» بنجاح ✓", "success");
            });
          });
        }
        if (isPdf) {
          if (f.size > MAX_PDF) { toast("ملف PDF أكبر من الحد الأقصى (150 ميغابايت)", "warning"); return; }
          toast("📕 جارٍ حفظ الكتاب «" + f.name + "» في مصادري…", "info");
          return b64(f).then(function (d) {
            return save({ kind: "pdf", name: f.name, mime: "application/pdf", data: d });
          }).then(function (savedPdf) {
            if (autoConvertToDb && savedPdf) {
              return convertPdfItemToMarkdownAndDb(savedPdf.id, true);
            }
            toast("📕 تم حفظ الكتاب في مصادري — اضغط «⚡ حوّل لـ Markdown وسجّل بالقاعدة» لتحويله وفهرسته!", "success");
          });
        }
        if (!/^image\//.test(f.type)) { toast("الصيغ المدعومة: كتب PDF، ملفات Markdown (.md / .txt)، وصور", "warning"); return; }
        return shrink(f).then(function (x) {
          return save({ kind: "img", name: f.name && f.name !== "image.jpg" ? f.name : "صفحة مصوّرة " + new Date().toLocaleTimeString("ar"), mime: "image/jpeg", data: x.data, thumb: x.thumb });
        }, function () { toast("تعذّر قراءة الصورة", "warning"); });
      });
    }, Promise.resolve()).then(paint);
  }

  function save(it) {
    it.id = it.id || ("s" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5));
    it.at = Date.now();
    it.active = ((it.data ? it.data.length : 0) + activeLen()) <= BUDGET;
    var existingIdx = items.findIndex(function (x) { return x.id === it.id; });
    if (existingIdx > -1) items[existingIdx] = it;
    else items.unshift(it);
    return put(it).then(function () { return it; }).catch(function () {
      toast("تعذّر الحفظ على الجهاز (تأكد من المساحة المتاحة)", "warning");
      return it;
    });
  }

  // ---------- 3. محرك استخراج وتحويل PDF إلى Markdown مهيكل (pdf.js + AI) ----------
  function loadPdfJs() {
    if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
    return new Promise(function (res, rej) {
      var s = document.createElement("script");
      s.src = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js";
      s.onload = function () {
        if (window.pdfjsLib) {
          window.pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
          res(window.pdfjsLib);
        } else rej(new Error("no_pdfjs"));
      };
      s.onerror = rej;
      document.head.appendChild(s);
    });
  }

  function extractPdfToMarkdownLocal(it, onProgress) {
    return loadPdfJs().then(function (pdfjsLib) {
      var raw = atob(it.data || "");
      var uint8 = new Uint8Array(raw.length);
      for (var i = 0; i < raw.length; i++) uint8[i] = raw.charCodeAt(i);
      return pdfjsLib.getDocument({ data: uint8 }).promise;
    }).then(function (pdfDoc) {
      var totalPages = pdfDoc.numPages;
      var maxPagesToScan = Math.min(totalPages, 120); // استخراج حتى 120 صفحة محلياً بسرعة فائقة
      var bookTitle = (it.name || "كتاب مدرسي").replace(/\.pdf$/i, "");
      var mdChunks = [
        "# " + bookTitle,
        "> **المصدر:** المنهاج الفلسطيني — تم التحويل والفهرسة في قاعدة بيانات الموقع (" + totalPages + " صفحة)",
        ""
      ];
      var curPage = 1;

      function nextPage() {
        if (curPage > maxPagesToScan) {
          return Promise.resolve(mdChunks.join("\n"));
        }
        if (typeof onProgress === "function") onProgress(curPage, maxPagesToScan);
        return pdfDoc.getPage(curPage).then(function (page) {
          return page.getTextContent();
        }).then(function (textContent) {
          var lines = [];
          var lastY = null;
          var currentLine = [];
          (textContent.items || []).forEach(function (item) {
            var str = String(item.str || "").trim();
            if (!str) return;
            var y = item.transform ? Math.round(item.transform[5]) : 0;
            if (lastY !== null && Math.abs(y - lastY) > 6) {
              if (currentLine.length) lines.push(currentLine.join(" "));
              currentLine = [str];
            } else {
              currentLine.push(str);
            }
            lastY = y;
          });
          if (currentLine.length) lines.push(currentLine.join(" "));

          var pageText = lines.join("\n").trim();
          if (pageText) {
            // الكشف الذكي عن عناوين الوحدات والدروس في الصفحة
            var firstLine = lines[0] || ("صفحة " + curPage);
            var isHeading = /(الوحدة|الفصل|الدرس|المبحث|الباب|القسم|نشاط|قانون|مثال)/.test(firstLine) && firstLine.length < 95;
            mdChunks.push("## " + (isHeading ? firstLine + " (ص " + curPage + ")" : "صفحة " + curPage + " — " + firstLine.slice(0, 60)));
            mdChunks.push(pageText);
            mdChunks.push("");
          }
          curPage++;
          return nextPage();
        });
      }
      return nextPage();
    });
  }

  function convertPdfItemToMarkdownAndDb(id, autoRegister) {
    var it = items.filter(function (x) { return x.id === id; })[0];
    if (!it) return Promise.resolve();

    var statusEl = $("srcConvertStatus");
    function setStatus(msg) {
      if (statusEl) {
        statusEl.textContent = msg;
        statusEl.classList.remove("hidden");
      }
    }

    toast("⏳ جارٍ قراءة وتحويل «" + it.name + "» إلى Markdown مهيكل…", "info");
    setStatus("⏳ جارٍ فحص واستخراج نصوص الصفحات من «" + it.name + "»…");

    var extractPromise = (it.kind === "pdf")
      ? extractPdfToMarkdownLocal(it, function (pg, tot) {
          setStatus("📖 جارٍ تحويل الصفحة " + pg + " من " + tot + " إلى Markdown…");
        }).catch(function () { return ""; })
      : Promise.resolve("");

    return extractPromise.then(function (localMd) {
      var cleanLocal = String(localMd || "").replace(/^#.*$/gm, "").replace(/^>.*$/gm, "").trim();
      // إن كان الملف الممسوح ضوئياً (Scanned PDF أو صورة) لا يحتوي طبقة نصية كافية، نستعين بالذكاء الاصطناعي أو ننشئ هيكل Markdown قابل للإثراء
      if (cleanLocal.length < 80 && window.AI && window.AI.ask) {
        setStatus("🤖 الملف مصوّر — جارٍ استخراج محتواه وتنسيقه بصيغة Markdown عبر الذكاء الاصطناعي…");
        var prompt = "حوّل هذا المستند أو الصفحة المرفقة من المنهاج الفلسطيني («" + it.name + "») إلى وثيقة Markdown (.md) منظمة وكاملة باللغة العربية:\n" +
          "- ابدأ بعنوان الكتاب `# " + it.name.replace(/\.[^.]+$/, "") + "`\n" +
          "- قسّم المحتوى إلى فصول أو دروس باستخدام `## عنوان الدرس`\n" +
          "- ضع القواعد والمفاهيم الأساسية في نقاط تبدأ بـ `- **المفهوم:** التوضيح`\n" +
          "- اكتب الشرح الكامل والأمثلة والتمارين بدقة تحت كل درس.";
        return window.AI.ask(prompt, [{ mime: it.mime, data: it.data, name: it.name }], "prep").then(function (aiMd) {
          return String(aiMd || "").trim() || localMd;
        }).catch(function () { return localMd; });
      }
      return localMd;
    }).then(function (finalMd) {
      var bookTitle = (it.name || "كتاب مدرسي").replace(/\.[^.]+$/, "");
      if (!finalMd || finalMd.trim().length < 40) {
        finalMd = "# " + bookTitle + "\n\n" +
          "## الوحدة 1: المحتوى الأساسي في " + bookTitle + "\n" +
          "- **الكتاب:** " + bookTitle + " (المنهاج الفلسطيني)\n" +
          "- **حالة الفهرسة:** مسجل في قاعدة بيانات الموقع وجاهز للاستخدام مع الذكاء الاصطناعي وجميع الأدوات.\n\n" +
          "يمكنك الضغط على «🤖 إثراء وتوليد فصول الكتاب بالـ AI» أو لصق فصول إضافية هنا ليتم تقسيمها تلقائياً.";
      }
      it.markdown = finalMd;
      activeMdItem = it;
      return put(it).then(function () {
        setStatus("✅ اكتمل التحويل إلى Markdown! جارٍ التسجيل في قاعدة بيانات الموقع…");
        if (autoRegister !== false) {
          return registerItemInSiteDb(it, true);
        }
      });
    }).then(function () {
      setTimeout(function () { if (statusEl) statusEl.classList.add("hidden"); }, 3500);
      paint();
    });
  }

  // ---------- 4. تحليل كود الـ Markdown وتحويله إلى سجل كتاب مهيكل في قاعدة بيانات الموقع ----------
  function guessGradeAndSubjectFromTitle(titleStr) {
    var t = String(titleStr || "");
    var grades = ["الأول الأساسي", "الثاني الأساسي", "الثالث الأساسي", "الرابع الأساسي", "الخامس الأساسي", "السادس الأساسي", "السابع", "الثامن", "التاسع", "العاشر", "الحادي عشر", "الثاني عشر"];
    var gKeys = ["الحادي عشر", "الثاني عشر", "توجيهي", "الأول", "الثاني", "الثالث", "الرابع", "الخامس", "السادس", "السابع", "الثامن", "التاسع", "العاشر"];
    var detectedGrade = "";
    for (var i = 0; i < gKeys.length; i++) {
      if (t.indexOf(gKeys[i]) !== -1) {
        if (gKeys[i] === "توجيهي") { detectedGrade = "الثاني عشر"; break; }
        detectedGrade = grades.filter(function (g) { return g.indexOf(gKeys[i]) === 0; })[0] || gKeys[i];
        break;
      }
    }
    var subjects = ["الرياضيات", "العلوم والحياة", "اللغة العربية", "اللغة الإنجليزية", "الفيزياء", "الكيمياء", "الأحياء", "التكنولوجيا", "الدراسات الاجتماعية", "التربية الإسلامية", "التاريخ", "الجغرافيا"];
    var detectedSubj = "";
    for (var j = 0; j < subjects.length; j++) {
      var stem = subjects[j].replace(/^ال/, "").split(" ")[0];
      if (t.indexOf(stem) !== -1) { detectedSubj = subjects[j]; break; }
    }
    var prof = (window.EduPersonalize && window.EduPersonalize.getProfile) ? window.EduPersonalize.getProfile() : {};
    if (!detectedGrade && prof.grade) detectedGrade = prof.grade.replace(/^الصف\s+/, "");
    if (!detectedSubj && prof.subject) detectedSubj = prof.subject;

    var stage = "المتوسطة / الإعدادية (الصفوف 5 - 9)";
    if (/الأول|الثاني الأساسي|الثالث|الرابع/.test(detectedGrade)) stage = "الابتدائية (الصفوف 1 - 4)";
    else if (/العاشر|الحادي عشر|الثاني عشر/.test(detectedGrade)) stage = "الثانوية (الصفوف 10 - 12)";

    return { grade: detectedGrade || "السابع", subject: detectedSubj || "العلوم والحياة", stage: stage };
  }

  function parseMarkdownToLessons(mdText, fallbackTitle) {
    var lines = String(mdText || "").split(/\r?\n/);
    var lessons = [];
    var curLesson = null;

    lines.forEach(function (rawLine) {
      var line = rawLine.trim();
      var h2Match = line.match(/^#{2,3}\s+(.+)$/);
      if (h2Match) {
        if (curLesson && (curLesson.x.trim() || curLesson.k.length)) {
          lessons.push(curLesson);
        }
        var headingTitle = h2Match[1].replace(/\*\*/g, "").trim();
        var pgMatch = headingTitle.match(/\((ص\s*[\d\-–]+)\)/);
        curLesson = {
          t: headingTitle,
          p: pgMatch ? pgMatch[1] : ("فصل " + (lessons.length + 1)),
          k: [],
          x: ""
        };
        return;
      }
      if (/^#\s+/.test(line) || /^>\s*/.test(line)) return;
      if (!curLesson) {
        curLesson = {
          t: "الوحدة 1: " + (fallbackTitle || "مقدمة ومحتوى الكتاب"),
          p: "فصل 1",
          k: [],
          x: ""
        };
      }
      // استخراج النقاط المميزة كقواعد ومفاهيم أساسية
      if (/^([-*•]|\d+[.)])\s+/.test(line) && (line.indexOf(":") !== -1 || line.indexOf("**") !== -1) && curLesson.k.length < 8) {
        var cleanRule = line.replace(/^([-*•]|\d+[.)])\s+/, "").replace(/\*\*/g, "").trim();
        if (cleanRule.length > 8 && cleanRule.length < 240) curLesson.k.push(cleanRule);
      }
      if (line) {
        curLesson.x += (curLesson.x ? "\n" : "") + rawLine.replace(/\*\*/g, "");
      }
    });

    if (curLesson && (curLesson.x.trim() || curLesson.k.length)) {
      lessons.push(curLesson);
    }
    if (!lessons.length) {
      lessons.push({
        t: fallbackTitle || "محتوى الكتاب",
        p: "كامل",
        k: ["مرجع منهجي محوّل بصيغة Markdown في قاعدة بيانات الموقع."],
        x: String(mdText || "").trim()
      });
    }
    return lessons.slice(0, 80);
  }

  function registerItemInSiteDb(it, silentModal) {
    if (!it) return Promise.resolve();
    var md = it.markdown || "";
    var cleanTitle = (it.name || "كتاب مدرسي").replace(/\.(pdf|md|markdown|txt)$/i, "");
    var h1Match = md.match(/^#\s+(.+)$/m);
    if (h1Match && h1Match[1].trim()) cleanTitle = h1Match[1].replace(/\*\*/g, "").trim();

    var guessed = guessGradeAndSubjectFromTitle(cleanTitle);
    var parsedLessons = parseMarkdownToLessons(md, cleanTitle);

    var kbRec = {
      id: "kb-" + it.id,
      sourceItemId: it.id,
      title: cleanTitle,
      stage: guessed.stage,
      grade: guessed.grade,
      subject: guessed.subject,
      term: "1",
      author: "قاعدة بيانات الموقع (Markdown)",
      lessons: parsedLessons,
      markdown: md,
      pagesCount: parsedLessons.length,
      updatedAt: Date.now()
    };

    return saveKbRecord(kbRec).then(function (savedRec) {
      it.kbId = savedRec.id;
      return put(it).then(function () {
        paint();
        toast("🗄️ تم تحويل «" + savedRec.title + "» إلى Markdown وتسجيله في قاعدة بيانات الموقع (" + parsedLessons.length + " فصل/درس) ✓", "success");
        return savedRec;
      });
    });
  }

  // ---------- 5. قص صفحات من PDF (مكتبة pdf-lib تُحمَّل عند الطلب فقط) ----------
  function loadPdfLib() {
    if (window.PDFLib) return Promise.resolve();
    return new Promise(function (res, rej) { var s = document.createElement("script"); s.src = "https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js"; s.onload = res; s.onerror = rej; document.head.appendChild(s); });
  }
  function cut(id) {
    var it = items.filter(function (x) { return x.id === id; })[0]; if (!it) return;
    if (typeof showModalContent === "function") {
      showModalContent(
        '<div class="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-900 text-white">' +
          '<h3 class="text-sm font-black">✂ اقتطاع صفحات محددة من الكتاب: ' + esc(it.name) + '</h3>' +
          '<button type="button" onclick="closeModal()" class="text-slate-300">✕</button>' +
        '</div>' +
        '<div class="p-4 space-y-3 text-right text-xs">' +
          '<p class="text-slate-600 dark:text-slate-300">حدد من صفحة كم إلى صفحة كم تريد اقتطاعها وتحويلها إلى Markdown وقاعدة بيانات:</p>' +
          '<div class="grid grid-cols-2 gap-3">' +
            '<div><label class="block font-bold mb-1">من الصفحة</label><input id="cutFromPg" type="number" min="1" value="1" class="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800 font-bold"></div>' +
            '<div><label class="block font-bold mb-1">إلى الصفحة</label><input id="cutToPg" type="number" min="1" value="15" class="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800 font-bold"></div>' +
          '</div>' +
        '</div>' +
        '<div class="p-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">' +
          '<button type="button" onclick="closeModal()" class="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold">إلغاء</button>' +
          '<button type="button" id="cutConfirmBtn" class="px-5 py-2 rounded-xl bg-indigo-600 text-white text-xs font-black">✂ اقتطاع وتحويل لـ Markdown</button>' +
        '</div>'
      );
      $("cutConfirmBtn").onclick = function () {
        var a = +($("cutFromPg").value || 1), b = +($("cutToPg").value || 15);
        closeModal();
        runPdfCut(it, a, b);
      };
      return;
    }
  }

  function runPdfCut(it, a, b) {
    if (a < 1 || b < a || b - a > 120) return toast("النطاق غير صالح (حتى 120 صفحة في المقتطف الواحد)", "warning");
    toast("جارٍ قص الصفحات (" + a + "-" + b + ")… ⏳", "info");
    loadPdfLib().then(function () {
      var bytes = Uint8Array.from(atob(it.data), function (c) { return c.charCodeAt(0); });
      return PDFLib.PDFDocument.load(bytes, { ignoreEncryption: true }).then(function (src) {
        var n = src.getPageCount(); if (a > n) throw new Error("range"); b = Math.min(b, n);
        return PDFLib.PDFDocument.create().then(function (out) {
          var idx = []; for (var i = a - 1; i < b; i++) idx.push(i);
          return out.copyPages(src, idx).then(function (pgs) { pgs.forEach(function (p) { out.addPage(p); }); return out.saveAsBase64(); });
        });
      });
    }).then(function (d) {
      return save({ kind: "pdf", name: it.name.replace(/\.pdf$/i, "") + " (ص " + a + "-" + b + ")", mime: "application/pdf", data: d });
    }).then(function (newIt) {
      paint();
      toast("تم إنشاء مقتطف الصفحات وجارٍ تحويله لـ Markdown ✅");
      if (newIt) return convertPdfItemToMarkdownAndDb(newIt.id, true);
    }).catch(function () { toast("تعذّر القص (تأكد من أن نطاق الصفحات ضمن الكتاب)", "warning"); });
  }

  // ---------- 6. عرض محرر ومعاين الـ Markdown المبسط ----------
  function renderSimpleMarkdownPreview(md) {
    var html = esc(md || "")
      .replace(/^###\s+(.+)$/gm, '<h4 class="text-xs font-black text-indigo-700 dark:text-indigo-300 mt-3 mb-1">$1</h4>')
      .replace(/^##\s+(.+)$/gm, '<h3 class="text-sm font-black text-brand-700 dark:text-sky-300 mt-4 mb-1.5 pb-1 border-b border-slate-200 dark:border-slate-700">$1</h3>')
      .replace(/^#\s+(.+)$/gm, '<h2 class="text-base font-black text-slate-900 dark:text-white mb-2">$1</h2>')
      .replace(/^&gt;\s*(.+)$/gm, '<div class="p-2.5 rounded-xl bg-amber-500/10 border-r-4 border-amber-500 text-xs font-bold my-2">$1</div>')
      .replace(/\*\*(.+?)\*\*/g, '<strong class="font-black text-slate-900 dark:text-white">$1</strong>')
      .replace(/^[-*•]\s+(.+)$/gm, '<div class="pr-3 py-0.5">• $1</div>');
    return '<div class="text-xs leading-7 whitespace-pre-line font-semibold text-slate-800 dark:text-slate-200">' + html + '</div>';
  }

  function downloadTextFile(filename, content, mime) {
    var blob = new Blob([content], { type: (mime || "text/markdown") + ";charset=utf-8" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 400);
  }

  // ---------- 7. الواجهة الكاملة لـ «مصادري + محول PDF إلى Markdown + قاعدة البيانات» ----------
  function paint() {
    var box = $("srcList"); if (!box) return;
    var used = activeLen(), pct = Math.min(100, Math.round(used / BUDGET * 100));
    $("srcMeter").style.width = pct + "%";
    $("srcMeter").className = "h-2.5 rounded-full transition-all " + (pct > 85 ? "bg-rose-500" : "bg-emerald-500");
    $("srcMeterTxt").innerHTML = "المصادر المفعّلة: <b>" + mb(used) + "</b> من <b>" + mb(BUDGET) + " ميغابايت</b> (سعة موسّعة تتسع لعشرات الكتب الكاملة + عدد غير محدود من كتب الـ Markdown المفهرسة في قاعدة بيانات الموقع: <b>" + kbRecords.length + " كتاب مهيكل</b>)";
    $("srcCur").checked = localStorage.getItem(KEY_CUR) !== "0";

    // 1. قائمة المصادر الأصلية المعروضة للقارئ (تقتصر على الكتب بصيغتها الأصلية PDF وGoogle Drive والصور عالية الوضوح، بينما تبقى ملفات الـ Markdown في القاعدة البرمجية الخفية)
    var visibleOriginalItems = items.filter(function (i) { return i.kind !== 'md'; });
    box.innerHTML = visibleOriginalItems.length ? visibleOriginalItems.map(function (i) {
      var isMd = i.kind === "md" || !!i.markdown;
      var ico = i.thumb
        ? '<img src="' + i.thumb + '" alt="" class="w-12 h-12 rounded-xl object-cover border">'
        : i.kind === "md"
        ? '<div class="w-12 h-12 rounded-xl bg-indigo-500/15 text-indigo-600 dark:text-indigo-300 flex items-center justify-center text-xl font-black">M↓</div>'
        : '<div class="w-12 h-12 rounded-xl bg-rose-500/15 text-rose-600 dark:text-rose-400 flex items-center justify-center text-xl">📕</div>';

      return '<div class="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white/90 dark:bg-slate-900/70 shadow-xs">' +
        '<div class="flex items-center gap-3 min-w-0 flex-1">' +
          '<input type="checkbox" data-act="' + i.id + '"' + (i.active ? " checked" : "") + ' class="w-5 h-5 accent-emerald-600 shrink-0" aria-label="تفعيل المصدر">' +
          ico +
          '<div class="min-w-0 flex-1">' +
            '<div class="flex flex-wrap items-center gap-1.5">' +
              '<span class="text-xs sm:text-sm font-black truncate text-slate-900 dark:text-white">' + esc(i.name) + '</span>' +
              (isMd ? '<span class="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-[10px] font-black">✓ محوّل لـ Markdown</span>' : '') +
              (i.kbId ? '<span class="px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 text-[10px] font-black">🗄️ مسجل بقاعدة الموقع</span>' : '') +
            '</div>' +
            '<div class="text-[11px] text-slate-500 mt-0.5">' + mb((i.data || "").length) + " ميغابايت" + (i.markdown ? " • حجم نص الـ Markdown: " + Math.max(1, Math.round(i.markdown.length / 1024)) + " كيلوبايت (سريع جداً)" : "") + '</div>' +
          '</div>' +
        '</div>' +
        '<div class="flex flex-wrap items-center gap-1.5 shrink-0">' +
          '<button type="button" data-md-convert="' + i.id + '" class="px-3 py-1.5 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 text-slate-950 text-[11px] font-black shadow hover:opacity-95 transition">' +
            (i.markdown ? "🔄 تحديث الـ Markdown والقاعدة" : "⚡ حوّل لـ Markdown وسجّل بالقاعدة") +
          '</button>' +
          (i.markdown ? '<button type="button" data-md-open="' + i.id + '" class="px-2.5 py-1.5 rounded-xl bg-brand-600 text-white text-[11px] font-black">📝 محرر الـ Markdown</button>' : '') +
          (i.kbId ? '<button type="button" data-kb-read="' + i.kbId + '" class="px-2.5 py-1.5 rounded-xl bg-emerald-600 text-white text-[11px] font-black">📖 افتح بالقارئ</button>' : '') +
          (i.kind === "pdf" ? '<button type="button" data-cut="' + i.id + '" class="px-2.5 py-1.5 rounded-xl bg-indigo-600/15 text-indigo-700 dark:text-indigo-300 text-[11px] font-black">✂ قص صفحات</button>' : "") +
          '<button type="button" data-del="' + i.id + '" class="px-2 py-1.5 rounded-xl bg-rose-500/10 text-rose-600 text-xs font-black" aria-label="حذف">🗑</button>' +
        '</div>' +
      '</div>';
    }).join("") : '<div class="text-xs sm:text-sm text-slate-500 text-center py-6 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl">ارفع كتاب المنهاج (PDF حتى 150 ميغابايت) أو ملف Markdown (.md) أو صوّر صفحة بالكاميرا، ثم اضغط «⚡ حوّل لـ Markdown وسجّل بالقاعدة».</div>';

    // 2. محرر ومعاين الـ Markdown النشط
    var mdBox = $("srcMdStudioBox");
    if (mdBox) {
      if (!activeMdItem && items.some(function (x) { return x.markdown; })) {
        activeMdItem = items.filter(function (x) { return x.markdown; })[0];
      }
      if (activeMdItem && activeMdItem.markdown !== undefined) {
        mdBox.classList.remove("hidden");
        mdBox.innerHTML =
          '<div class="rounded-2xl border-2 border-brand-500/35 bg-slate-50 dark:bg-slate-900/80 p-4 space-y-3">' +
            '<div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800 pb-2.5">' +
              '<div>' +
                '<div class="text-xs sm:text-sm font-black text-brand-700 dark:text-sky-300">📝 محرر ومعاين الـ Markdown المستخرج: «' + esc(activeMdItem.name) + '»</div>' +
                '<div class="text-[11px] text-slate-500">يمكنك تعديل نص الـ Markdown أو تقسيمه بعناوين `## اسم الدرس` ثم حفظه في قاعدة بيانات الموقع</div>' +
              '</div>' +
              '<div class="flex flex-wrap gap-1.5">' +
                '<button type="button" id="btnMdSaveToDb" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow">🗄️ حفظ وتسجيل في قاعدة بيانات الموقع</button>' +
                '<button type="button" id="btnMdAiEnrich" class="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow">🤖 تنظيم وإثراء الـ Markdown بالـ AI</button>' +
                '<button type="button" id="btnMdDownload" class="px-3 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-extrabold">📥 تنزيل .md</button>' +
                '<button type="button" id="btnMdClose" class="px-2.5 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-xs font-bold">إغلاق</button>' +
              '</div>' +
            '</div>' +
            '<div class="grid grid-cols-1 lg:grid-cols-2 gap-3">' +
              '<div>' +
                '<label class="block text-[11px] font-black text-slate-500 mb-1">كود الـ Markdown القابل للتعديل (`# كتاب`، `## درس`، `- **قاعدة:** ...`):</label>' +
                '<textarea id="srcMdTextarea" rows="11" class="w-full text-xs font-mono font-semibold p-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-100 leading-relaxed">' + esc(activeMdItem.markdown) + '</textarea>' +
              '</div>' +
              '<div>' +
                '<label class="block text-[11px] font-black text-slate-500 mb-1">المعاينة الحية المنسّقة (Live Markdown Preview):</label>' +
                '<div id="srcMdLivePreview" class="h-[248px] overflow-y-auto p-3.5 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800">' +
                  renderSimpleMarkdownPreview(activeMdItem.markdown) +
                '</div>' +
              '</div>' +
            '</div>' +
          '</div>';

        var ta = $("srcMdTextarea");
        if (ta) {
          ta.oninput = function () {
            activeMdItem.markdown = ta.value;
            var prev = $("srcMdLivePreview");
            if (prev) prev.innerHTML = renderSimpleMarkdownPreview(ta.value);
          };
        }
        if ($("btnMdSaveToDb")) $("btnMdSaveToDb").onclick = function () {
          if (ta) activeMdItem.markdown = ta.value;
          registerItemInSiteDb(activeMdItem, true);
        };
        if ($("btnMdDownload")) $("btnMdDownload").onclick = function () {
          var fname = (activeMdItem.name || "book").replace(/\.[^.]+$/, "") + ".md";
          downloadTextFile(fname, activeMdItem.markdown || "", "text/markdown");
        };
        if ($("btnMdClose")) $("btnMdClose").onclick = function () {
          activeMdItem = null;
          paint();
        };
        if ($("btnMdAiEnrich")) $("btnMdAiEnrich").onclick = function () {
          if (!window.AI || !window.AI.ask) { toast("المساعد الذكي غير متصل حالياً", "warning"); return; }
          var btn = $("btnMdAiEnrich");
          btn.disabled = true;
          btn.textContent = "⏳ جارٍ التنسيق بالـ AI…";
          var prompt = "أعد تنسيق وهيكلة النص التالي من المنهاج الفلسطيني إلى وثيقة Markdown قياسية واحترافية مقسمة إلى دروس (`## عنوان الدرس`) وتحت كل درس قائمة بالقواعد الأساسية (`- **المفهوم:** ...`) متبوعة بالشرح الكامل:\n\n" + (activeMdItem.markdown || "").slice(0, 7500);
          window.AI.ask(prompt, [], "prep").then(function (res) {
            if (res && res.trim()) {
              activeMdItem.markdown = res.trim();
              return registerItemInSiteDb(activeMdItem, true);
            }
          }).catch(function () {
            toast("تعذر الاتصال بالـ AI — النص الحالي محفوظ", "info");
          }).then(function () {
            btn.disabled = false;
            btn.textContent = "🤖 تنظيم وإثراء الـ Markdown بالـ AI";
            paint();
          });
        };
      } else {
        mdBox.classList.add("hidden");
        mdBox.innerHTML = "";
      }
    }

    // 3. عرض جدول «🗄️ قاعدة بيانات الكتب والمصادر المهيكلة الخاصة بالموقع»
    paintKbDatabaseBox();
  }

  function paintKbDatabaseBox() {
    var kbBox = $("srcKbDatabaseBox");
    if (!kbBox) return;
    var q = (kbSearchQuery || "").trim().toLowerCase();
    var filtered = kbRecords.filter(function (r) {
      if (!q) return true;
      var hay = (r.title + " " + r.grade + " " + r.subject + " " + (r.markdown || "")).toLowerCase();
      return hay.indexOf(q) !== -1;
    });

    kbBox.innerHTML =
      '<div class="rounded-3xl border-2 border-indigo-500/30 bg-gradient-to-l from-indigo-500/5 via-sky-500/5 to-emerald-500/5 p-4 sm:p-5 space-y-4">' +
        '<div class="flex flex-wrap items-center justify-between gap-2">' +
          '<div>' +
            '<div class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-black mb-1">🗄️ قاعدة بيانات الموقع الخاصة (Markdown Knowledge Base)</div>' +
            '<h3 class="text-sm sm:text-base font-black text-slate-900 dark:text-white">الكتب والملفات المحوّلة والمسجّلة في قاعدة بيانات المنصة (' + kbRecords.length + ' سجل مهيكل)</h3>' +
            '<p class="text-[11px] text-slate-500">كل ملف PDF تحوّله إلى Markdown يُحفظ هنا كقاعدة بيانات دائمة، ويظهر تلقائياً في «قارئ الكتب التفاعلي» وقسم «الكتب والمناهج» ويجيب منه الذكاء الاصطناعي فوراً.</p>' +
          '</div>' +
          '<div class="flex flex-wrap gap-1.5">' +
            '<button type="button" id="btnNewMdBookModal" class="px-3 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-black shadow">+ إنشاء كتاب Markdown جديد</button>' +
            '<button type="button" id="btnExportKbJson" class="px-3 py-2 rounded-xl bg-slate-800 text-amber-300 text-xs font-extrabold">📦 تصدير قاعدة البيانات (JSON)</button>' +
            '<label class="px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-extrabold cursor-pointer">📥 استيراد قاعدة JSON<input id="inpImportKbJson" type="file" accept=".json" class="hidden"></label>' +
          '</div>' +
        '</div>' +

        '<div class="relative">' +
          '<input id="inpKbSearch" type="search" value="' + esc(kbSearchQuery) + '" placeholder="🔍 ابحث داخل قاعدة بيانات الكتب والـ Markdown (اسم كتاب، درس، مفهوم، قانون…)" class="w-full text-xs font-bold px-4 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 outline-none focus:border-brand-500">' +
        '</div>' +

        (filtered.length
          ? '<div class="grid grid-cols-1 md:grid-cols-2 gap-3">' +
              filtered.map(function (r) {
                var lsCount = (r.lessons || []).length;
                return '<div class="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex flex-col justify-between gap-3 shadow-xs">' +
                  '<div>' +
                    '<div class="flex items-start justify-between gap-2">' +
                      '<div class="font-black text-xs sm:text-sm text-slate-900 dark:text-white">📘 ' + esc(r.title) + '</div>' +
                      '<span class="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-[10px] font-black shrink-0">' + lsCount + ' فصول مهيكلة</span>' +
                    '</div>' +
                    '<div class="flex flex-wrap gap-1.5 mt-1.5">' +
                      '<span class="px-2 py-0.5 rounded-md bg-brand-500/10 text-brand-600 dark:text-sky-300 text-[10px] font-bold">🏫 ' + esc(r.grade || "عام") + '</span>' +
                      '<span class="px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-600 dark:text-indigo-300 text-[10px] font-bold">📚 ' + esc(r.subject || "عام") + '</span>' +
                      '<span class="px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-700 dark:text-amber-300 text-[10px] font-bold">Markdown ' + Math.max(1, Math.round((r.markdown || "").length / 1024)) + ' KB</span>' +
                    '</div>' +
                    '<div class="mt-2 text-[11px] text-slate-500 line-clamp-2">' +
                      esc((r.lessons || []).map(function (l) { return l.t; }).join(" • ")) +
                    '</div>' +
                  '</div>' +
                  '<div class="flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-100 dark:border-slate-800">' +
                    '<button type="button" data-kb-openreader="' + esc(r.id) + '" class="px-3 py-1.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-[11px] font-black">📖 اقرأ وخذ للأدوات</button>' +
                    '<button type="button" data-kb-editmd="' + esc(r.id) + '" class="px-2.5 py-1.5 rounded-xl bg-indigo-500/15 text-indigo-700 dark:text-indigo-300 text-[11px] font-black">📝 تحرير الـ Markdown</button>' +
                    '<button type="button" data-kb-dlmd="' + esc(r.id) + '" class="px-2.5 py-1.5 rounded-xl bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-[11px] font-black">📥 تنزيل .md</button>' +
                    '<button type="button" data-kb-del="' + esc(r.id) + '" class="px-2 py-1.5 rounded-xl text-rose-500 hover:bg-rose-500/10 text-[11px] font-bold mr-auto">🗑</button>' +
                  '</div>' +
                '</div>';
              }).join("") +
            '</div>'
          : '<div class="text-center py-6 text-xs text-slate-500">لا توجد سجلات مطابقة في قاعدة البيانات بعد — ارفع أي ملف PDF بالأعلى واضغط «⚡ حوّل لـ Markdown وسجّل بالقاعدة».</div>') +
      '</div>';

    var sInp = $("inpKbSearch");
    if (sInp) {
      sInp.oninput = function () {
        var pos = sInp.selectionStart;
        kbSearchQuery = sInp.value;
        paintKbDatabaseBox();
        var nInp = $("inpKbSearch");
        if (nInp) { nInp.focus(); try { nInp.setSelectionRange(pos, pos); } catch (e) {} }
      };
    }

    if ($("btnNewMdBookModal")) $("btnNewMdBookModal").onclick = function () {
      var sampleMd = "# كتاب جديد في المنهاج الفلسطيني\n\n## الوحدة 1: الدرس الأول\n- **القاعدة الأولى:** اكتب هنا المفهوم أو القانون الأساسي.\n- **التطبيق:** اكتب هنا المثال التطبيقي.\n\nاشرح تفاصيل الدرس هنا ليتم تقسيمه وفهرسته في قاعدة بيانات الموقع.";
      save({
        kind: "md",
        name: "كتاب-منهجي-جديد.md",
        mime: "text/markdown",
        markdown: sampleMd,
        data: utf8ToB64(sampleMd)
      }).then(function (it) {
        activeMdItem = it;
        return registerItemInSiteDb(it, true);
      });
    };

    if ($("btnExportKbJson")) $("btnExportKbJson").onclick = function () {
      downloadTextFile("EduTech_Site_Markdown_Database.json", JSON.stringify(kbRecords, null, 2), "application/json");
      toast("📦 تم تصدير قاعدة بيانات الموقع بنجاح ✓", "success");
    };

    var impInp = $("inpImportKbJson");
    if (impInp) {
      impInp.onchange = function (ev) {
        var f = ev.target.files && ev.target.files[0];
        if (!f) return;
        readTextFile(f).then(function (txt) {
          try {
            var arr = JSON.parse(txt);
            if (Array.isArray(arr)) {
              arr.forEach(function (r) { if (r && r.title) saveKbRecord(r); });
              paint();
              toast("📥 تم استيراد " + arr.length + " كتاب مهيكل إلى قاعدة بيانات الموقع ✓", "success");
            }
          } catch (e) {
            toast("ملف JSON غير صالح", "warning");
          }
        });
        ev.target.value = "";
      };
    }

    kbBox.querySelectorAll("[data-kb-openreader]").forEach(function (b) {
      b.onclick = function () {
        var id = b.getAttribute("data-kb-openreader");
        syncKbToSiteBooks();
        if (window.EduBookReader && window.EduBookReader.open) window.EduBookReader.open(id, 0, "interactive");
      };
    });
    kbBox.querySelectorAll("[data-kb-editmd]").forEach(function (b) {
      b.onclick = function () {
        var id = b.getAttribute("data-kb-editmd");
        var rec = kbRecords.filter(function (x) { return x.id === id; })[0];
        if (!rec) return;
        var srcIt = items.filter(function (x) { return x.id === rec.sourceItemId || x.kbId === rec.id; })[0];
        if (srcIt) {
          srcIt.markdown = rec.markdown;
          activeMdItem = srcIt;
          paint();
        } else {
          save({ kind: "md", name: rec.title + ".md", mime: "text/markdown", markdown: rec.markdown, data: utf8ToB64(rec.markdown), kbId: rec.id }).then(function (newIt) {
            activeMdItem = newIt;
            paint();
          });
        }
      };
    });
    kbBox.querySelectorAll("[data-kb-dlmd]").forEach(function (b) {
      b.onclick = function () {
        var id = b.getAttribute("data-kb-dlmd");
        var rec = kbRecords.filter(function (x) { return x.id === id; })[0];
        if (rec) downloadTextFile(rec.title + ".md", rec.markdown || "", "text/markdown");
      };
    });
    kbBox.querySelectorAll("[data-kb-del]").forEach(function (b) {
      b.onclick = function () {
        var id = b.getAttribute("data-kb-del");
        deleteKbRecord(id).then(paint);
        toast("تم حذف السجل من قاعدة البيانات", "info");
      };
    });
  }

  function build() {
    if ($("sourcesStudio")) return true;
    var anchor = $("aiStudio") || $("generator") || $("learnSection"); if (!anchor) return false;
    var s = document.createElement("section"); s.id = "sourcesStudio"; s.className = "py-12 scroll-mt-20"; s.style.display = "none";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8"><div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-rose-700 via-red-900 to-slate-950 text-white"><div class="text-xs font-extrabold text-amber-300 mb-1">🔐 واجهة خاصة بالإدارة فقط • سعة 500 ميغابايت + تغذية القاعدة البرمجية الخفية (Markdown) وربط الكتب الأصلية</div><h2 class="text-xl sm:text-2xl font-black">مصادري: كتبي وصور صفحاتي وقاعدة بيانات الـ Markdown</h2><p class="text-xs text-white/85 mt-1">ارفع الكتاب (PDF أو Markdown) أو صوّر الصفحات؛ حوّل أي كتاب PDF إلى Markdown وسجّله في قاعدة بيانات الموقع ليعمل في القارئ التفاعلي وجميع الأدوات.</p></div>' +
      '<div class="p-4 sm:p-6 space-y-5 text-right">' +
      '<label class="flex items-center gap-2 text-sm font-bold"><input id="srcCur" type="checkbox" class="w-5 h-5 accent-emerald-600"> اعتماد المنهاج الفلسطيني وقاعدة بيانات مصادري في كل إجابات المساعد الذكي</label>' +
      '<div class="flex flex-wrap gap-2">' +
        '<label class="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold cursor-pointer shadow flex items-center gap-1.5"><span>📷 تصوير صفحة بالكاميرا</span><input id="srcCam" type="file" accept="image/*" capture="environment" class="hidden"></label>' +
        '<label class="px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-extrabold cursor-pointer shadow flex items-center gap-1.5"><span>📂 رفع كتاب PDF أو صور (حتى 150 MB)</span><input id="srcPick" type="file" accept="image/*,application/pdf,.pdf" multiple class="hidden"></label>' +
        '<label class="px-4 py-2.5 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 hover:opacity-95 text-slate-950 text-xs font-black cursor-pointer shadow flex items-center gap-1.5"><span>⚡ أعطه ملف PDF وحوّله فوراً لـ Markdown وقاعدة بيانات</span><input id="srcPdfToMdDirect" type="file" accept="application/pdf,.pdf" multiple class="hidden"></label>' +
        '<label class="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-extrabold cursor-pointer shadow flex items-center gap-1.5"><span>📝 استيراد ملف Markdown (.md / .txt)</span><input id="srcMdPick" type="file" accept=".md,.markdown,.txt,.json,.csv,text/markdown,text/plain" multiple class="hidden"></label>' +
      '</div>' +
      '<div id="srcConvertStatus" class="hidden p-3 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-xs font-black text-amber-800 dark:text-amber-300"></div>' +
      '<div><div class="w-full h-2.5 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden"><div id="srcMeter" class="h-2.5 rounded-full bg-emerald-500" style="width:0"></div></div><div id="srcMeterTxt" class="text-[11px] text-slate-500 mt-1.5"></div></div>' +
      '<div id="srcList" class="grid gap-3"></div>' +
      '<div id="srcMdStudioBox" class="hidden"></div>' +
      '<div id="srcKbDatabaseBox"></div>' +
      '<p class="text-[11px] text-slate-500 leading-6">تُحفظ الكتب والمصادر وقاعدة بيانات الـ Markdown على جهازك بسعة موسّعة (500 ميغابايت)، وتُرسَل الفصول ذات الصلة تلقائياً مع سؤالك إلى محرك الذكاء الاصطناعي وجميع الأدوات.</p></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor);
    $("srcCam").addEventListener("change", function (e) { addFiles(e.target.files, false); e.target.value = ""; });
    $("srcPick").addEventListener("change", function (e) { addFiles(e.target.files, false); e.target.value = ""; });
    $("srcPdfToMdDirect").addEventListener("change", function (e) { addFiles(e.target.files, true); e.target.value = ""; });
    $("srcMdPick").addEventListener("change", function (e) { addFiles(e.target.files, true); e.target.value = ""; });
    $("srcCur").addEventListener("change", function (e) { localStorage.setItem(KEY_CUR, e.target.checked ? "1" : "0"); });
    s.addEventListener("click", function (e) {
      var d = e.target.closest("[data-del]"),
          c = e.target.closest("[data-cut]"),
          mConv = e.target.closest("[data-md-convert]"),
          mOpen = e.target.closest("[data-md-open]"),
          kRead = e.target.closest("[data-kb-read]");
      if (d) {
        items = items.filter(function (x) { return x.id !== d.dataset.del; });
        del(d.dataset.del).then(paint);
        toast("تم حذف المصدر", "info");
      } else if (c) {
        cut(c.dataset.cut);
      } else if (mConv) {
        convertPdfItemToMarkdownAndDb(mConv.getAttribute("data-md-convert"), true);
      } else if (mOpen) {
        var it = items.filter(function (x) { return x.id === mOpen.getAttribute("data-md-open"); })[0];
        if (it) { activeMdItem = it; paint(); }
      } else if (kRead) {
        var kbId = kRead.getAttribute("data-kb-read");
        syncKbToSiteBooks();
        if (window.EduBookReader && window.EduBookReader.open) window.EduBookReader.open(kbId, 0, "interactive");
      }
    });
    s.addEventListener("change", function (e) {
      var a = e.target.closest("[data-act]"); if (!a) return;
      var it = items.filter(function (x) { return x.id === a.dataset.act; })[0]; if (!it) return;
      if (a.checked && activeLen() + (it.data ? it.data.length : 0) > BUDGET) {
        a.checked = false;
        return toast("تجاوزت السعة القصوى (500 ميغابايت) — حوّل الكتاب إلى Markdown لتوفير المساحة", "warning");
      }
      it.active = a.checked; put(it).then(paint);
    });
    paint(); return true;
  }

  // ---------- 8. ربط المصادر وقاعدة بيانات الـ Markdown بالمساعد الذكي ----------
  function hook() {
    if (!window.AI || !window.AI.ask || window.AI.ask.__src) return !!(window.AI && window.AI.ask && window.AI.ask.__src);
    var orig = window.AI.ask;
    window.AI.ask = function (prompt, files, toolId) {
      var cur = localStorage.getItem(KEY_CUR) !== "0", extra = [], mdContexts = [], base = (files || []).slice();
      var baseLen = base.reduce(function (n, f) { return n + ((f && f.data) ? f.data.length : 0); }, 0), total = baseLen;

      items.filter(function (i) { return i.active; }).forEach(function (i) {
        if (i.markdown && i.markdown.trim()) {
          mdContexts.push("📘 [مصدر Markdown مفهرس: " + i.name + "]:\n" + i.markdown.slice(0, 12000));
        } else if (i.data && base.length + extra.length < 12 && total + i.data.length <= 18e6) {
          extra.push({ mime: i.mime, data: i.data, name: i.name });
          total += i.data.length;
        }
      });

      // إضافة سجلات قاعدة البيانات المهيكلة ذات الصلة بالسؤال تلقائياً
      if (kbRecords.length && mdContexts.length < 3) {
        var qWords = String(prompt || "").split(/\s+/).filter(function (w) { return w.length > 3; });
        kbRecords.slice(0, 5).forEach(function (kb) {
          var match = !qWords.length || qWords.some(function (w) { return (kb.title + " " + kb.subject + " " + (kb.markdown || "")).indexOf(w) !== -1; });
          if (match && kb.markdown) {
            mdContexts.push("🗄️ [من قاعدة بيانات الموقع — " + kb.title + " (" + kb.grade + ")]:\n" + kb.markdown.slice(0, 8000));
          }
        });
      }

      var p = String(prompt || "");
      var mdBlock = mdContexts.length ? ("=== نصوص الكتب المحوّلة إلى Markdown في قاعدة بيانات الموقع ===\n" + mdContexts.slice(0, 3).join("\n\n---\n\n") + "\n===================\n\n") : "";
      if (cur || extra.length || mdBlock) {
        p = CURRICULUM + (extra.length ? "المرفقات المباشرة (" + extra.length + "): " + extra.map(function (x) { return x.name; }).join("، ") + "\n\n" : "") + mdBlock + p;
      }
      function extractTopicFromPrompt(pr) {
        var m = String(pr || "").match(/«([^»]{2,90})»/);
        if (m && m[1]) return m[1].trim();
        var m2 = String(pr || "").match(/(?:عن|لدرس|موضوع|بعنوان)[:\s]+([^\n.،]{3,70})/);
        if (m2 && m2[1]) return m2[1].trim();
        return "المفاهيم والتطبيقات المنهجية";
      }
      function buildSchemaJsonIfNeeded(rawPrompt, offText) {
        var pr = String(rawPrompt || "");
        var tp = extractTopicFromPrompt(pr);
        var pts = String(offText || "").split(/[\n•\-]+/).map(function (s) { return s.replace(/^[*#\d.]+\s*/, "").trim(); }).filter(function (s) { return s.length > 12 && s.length < 180; });
        while (pts.length < 6) {
          pts.push("المفهوم الأساسي في «" + tp + "» يربط القاعدة العلمية بالتطبيق العملي المباشر.");
          pts.push("تطبيق خطوات الحل المنظمة يساعد الطالب على التحقق من صحة النتيجة بدقة.");
          pts.push("مراجعة الأمثلة المحلولة والأنشطة التدريبية تعزز الفهم والاستيعاب.");
        }
        // 1. Slides JSON
        if (pr.indexOf('"slides":[') !== -1 || toolId === "slides") {
          return JSON.stringify({
            title: tp,
            slides: [
              { t: "title", title: tp, sub: "عرض تعليمي تفاعلي مبسط — منصة EduTech Mindset" },
              { t: "points", title: "المفاهيم والركائز الأساسية", points: pts.slice(0, 4) },
              { t: "mcq", q: "ما الفكرة المحورية التي يرتكز عليها موضوع «" + tp + "»؟", options: [pts[0].slice(0, 90), "الاعتماد على التخمين دون قاعدة", "تجاهل خطوات التطبيق العملي", "حفظ العناوين فقط"], answer: 0, why: "لأن الفهم المنهجي يربط القاعدة بالتطبيق." },
              { t: "points", title: "خطوات التطبيق والأمثلة العملية", points: pts.slice(1, 5) },
              { t: "poll", q: "ما مدى وضوح خطوات وتطبيقات درس «" + tp + "» بالنسبة لك؟", options: ["واضح جداً ومستعد للتطبيق", "أحتاج مثالاً إضافياً", "أرغب في مراجعة القاعدة"] },
              { t: "summary", title: "الخلاصة والتقويم الختامي", points: [pts[0], pts[1], "حل تدريبات الكتاب وتدوين الملاحظات في دفتر الهامش."] }
            ]
          });
        }
        // 2. Lesson Plan JSON
        if (pr.indexOf('"lesson":{') !== -1 || toolId === "lessonplan") {
          return JSON.stringify({
            unit: tp,
            lesson: {
              title: tp,
              outcomes: [
                "أن يوضّح الطالب المفهوم الأساسي لدرس «" + tp + "» بدقة.",
                "أن يطبّق الطالب القواعد والخطوات العملية لحل تدريبات «" + tp + "».",
                "أن يستنتج الطالب أهمية «" + tp + "» وتطبيقاته في الحياة اليومية."
              ],
              concepts: [tp, "القاعدة المنهجية", "التطبيق العملي"],
              resources: ["الكتاب المدرسي", "السبورة التفاعلية الذكية", "أوراق عمل متمايزة"],
              prior: "مراجعة المفاهيم الأساسية السابقة المرتبطة بموضوع «" + tp + "».",
              intro: { time: 5, text: "طرح سؤال عصف ذهني ومثال من واقع الطالب للتمهيد لدرس «" + tp + "»." },
              activities: [
                { time: 15, title: "النشاط الأول: الاستكشاف وبناء المفهوم", teacher: "يعرض المعلم مثالاً توضيحياً على السبورة ويوجه أسئلة سقراطية لاستنتاج القاعدة.", student: "يشارك الطلبة في تحليل المثال واستخلاص الفكرة المحورية وتدوينها." },
                { time: 15, title: "النشاط الثاني: التطبيق التعاوني", teacher: "يوزع المعلم مهام تدريبية متدرجة على المجموعات ويتابع خطوات الحل.", student: "يتعاون الطلبة في حل التدريبات ومناقشة خطوات الحل وعرض النتائج." },
                { time: 5, title: "النشاط الثالث: التمايز والتحدي", teacher: "يطرح مسألة إثرائية لربط الدرس بالحياة العملية.", student: "يطبق الطلبة القاعدة على الموقف الجديد ويبررون إجاباتهم." }
              ],
              closure: { time: 5, text: "تلخيص النقاط الأساسية للدرس مع الطلبة باستخدام خريطة مفاهيمية سريعة." },
              assessment: ["ما المقصود بـ «" + tp + "»؟", "طبّق قاعدة الدرس على المثال التدريبي المعطى."],
              homework: "حل أسئلة التقويم في الكتاب المدرسي وتلخيص القاعدة في دفتر كورنيل.",
              notes: "مراعاة الفروق الفردية بتقديم دعم بصري وأمثلة متدرجة."
            }
          });
        }
        // 3. Games JSON
        if (pr.indexOf('"pairA"') !== -1) {
          return JSON.stringify({
            title: "لعبة تفاعلية: " + tp,
            categories: ["المفاهيم والقواعد", "التطبيقات والأمثلة"],
            items: [
              { q: "ما الركيزة الأولى في فهم درس «" + tp + "»؟", options: [pts[0].slice(0, 80), "تجاهل المعطيات", "التخمين العشوائي", "حذف الخطوات"], answer: 0, pairA: tp, pairB: pts[0].slice(0, 75), cat: 0 },
              { q: "أي مما يلي يُعد خطوة صحيحة عند تطبيق «" + tp + "»؟", options: [pts[1].slice(0, 80), "ترك التحقق من الحل", "إهمال الوحدات", "عدم قراءة السؤال"], answer: 0, pairA: "خطوة التطبيق", pairB: pts[1].slice(0, 75), cat: 1 },
              { q: "ما الهدف من دراسة الأمثلة المحلولة في «" + tp + "»؟", options: ["استيعاب طريقة الحل وتطبيقها بثقة", "نسخ الأرقام دون فهم", "تخطي التدريبات", "تجاهل القوانين"], answer: 0, pairA: "الأمثلة التدريبية", pairB: "تثبيت الفهم العميق", cat: 1 },
              { q: "كيف نتحقق من صحة الناتج في تدريبات «" + tp + "»؟", options: ["بمراجعة الخطوات والتعويض في القاعدة", "بالمصادفة", "بعدم كتابة الخطوات", "بتغيير السؤال"], answer: 0, pairA: "التحقق المنهجي", pairB: "مراجعة الخطوات والقاعدة", cat: 0 }
            ]
          });
        }
        // 4. Stories JSON
        if (pr.indexOf('"scenes":[') !== -1) {
          return JSON.stringify({
            title: "رحلة الاكتشاف في عالم «" + tp + "»",
            moral: "بالعلم والتعاون والتفكير المنظم نكتشف أسرار «" + tp + "» ونبدع في تطبيقها.",
            scenes: [
              { title: "المشهد 1: سؤال يثير الفضول", emoji: "🌟", text: "في صباح مشرق داخل المدرسة، تساءل الأصدقاء عن سر «" + tp + "» وكيف نستخدمه في حياتنا اليومية.", dialogue: "قال ساري: هيا نبحث معاً عن القاعدة الأساسية ونكتشف أمثلتها!" },
              { title: "المشهد 2: استكشاف القاعدة", emoji: "🔍", text: "فتح الأصدقاء الكتاب التفاعلي وقرؤوا الشرح بتركيز: " + pts[0], dialogue: "قالت سلمى: الآن فهمت! القاعدة واضحة ومنظمة جداً." },
              { title: "المشهد 3: التجربة والتطبيق", emoji: "🧪", text: "بدأ الفريق بتطبيق ما تعلموه عملياً خطوة بخطوة: " + pts[1], dialogue: "قال ساري: عندما نرتب الخطوات تصبح المسألة سهلة وممتعة!" },
              { title: "المشهد 4: التغلب على التحدي", emoji: "🤝", text: "واجه الأصدقاء سؤالاً ذكياً، فتعاونوا في تحليله ومراجعة القاعدة حتى توصلوا للحل الصحيح.", dialogue: "قالت سلمى: التعاون والمراجعة سر النجاح والتفوق." },
              { title: "المشهد 5: فرحة الإنجاز", emoji: "🏆", text: "عرض الأصدقاء مشروعهم أمام الصف ونالوا إعجاب المعلم وزملائهم.", dialogue: "قال المعلم: أحسنتم يا أبطال العلم في فلسطين!" }
            ],
            questions: [
              { q: "ما المفهوم الذي استكشفه الأصدقاء في القصة؟", a: tp },
              { q: "كيف تمكن الأصدقاء من حل التحدي بنجاح؟", a: "بالتعاون وتطبيق الخطوات العلمية المنظمة." }
            ]
          });
        }
        // 5. Radio Broadcast JSON
        if (pr.indexOf('"hadith":') !== -1) {
          return JSON.stringify({
            topic: tp,
            intro: "بسم الله الرحمن الرحيم، أسعد الله صباحكم بكل خير وأمل من أرض فلسطين الحبيبة. يسرنا أن نقدم لكم إذاعتنا المدرسية لهذا اليوم بعنوان: «" + tp + "».",
            quran: "قال تعالى: ﴿وَقُلْ رَبِّ زِدْنِي عِلْمًا﴾ [طه: 114].",
            hadith: "قال رسول الله ﷺ: «مَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقًا إِلَى الْجَنَّةِ».",
            word: "كلمتنا الصباحية اليوم تدور حول «" + tp + "»؛ حيث يُعد هذا الموضوع من الركائز المهمة التي تنمّي عقولنا وتبني مستقبلنا بالعلم والعمل: " + pts[0],
            wisdom: "العلم يبني بيوتاً لا عماد لها، والمثابرة مفتاح كل تفوق وإبداع.",
            fact: "هل تعلم أن تنظيم المعرفة وربط المفاهيم النظرية بالتطبيق العملي يضاعف قدرة الدماغ على الاستيعاب والتذكر بنسبة تزيد عن 70%؟",
            quizQ: "ما الفائدة الأساسية التي نجنيها من إتقان وتطبيق «" + tp + "»؟",
            quizA: "تنمية التفكير العلمي والقدرة على حل المشكلات بدقة.",
            dua: "اللهم علّمنا ما ينفعنا، وانفعنا بما علّمتنا، وزدنا علماً وتوفيقاً يا رب العالمين."
          });
        }
        // 6. Tutor Flashcards / Mindmap / Podcast JSON
        if (pr.indexOf('"cards":[') !== -1) {
          return JSON.stringify({
            cards: [
              { front: "ما المفهوم المحوري في درس «" + tp + "»؟", back: pts[0], hint: "الركيزة الأساسية للدرس" },
              { front: "اذكر أهم قاعدة تطبيقية في «" + tp + "».", back: pts[1], hint: "خطوة العمل الأولى" },
              { front: "كيف نتحقق من صحة الحل في «" + tp + "»؟", back: pts[2], hint: "المراجعة والتعويض" },
              { front: "ما العلاقة بين المفهوم والتطبيق في «" + tp + "»؟", back: "القانون يوجه خطوات الحل، والمثال العملي يثبت صحة الاستنتاج.", hint: "ربط النظرية بالتطبيق" }
            ]
          });
        }
        if (pr.indexOf('"branches":[') !== -1) {
          return JSON.stringify({
            root: tp,
            branches: [
              { title: "1. المفهوم والتعريف", items: [pts[0].slice(0, 45), "الخصائص الأساسية للمفهوم"] },
              { title: "2. القواعد والخطوات", items: [pts[1].slice(0, 45), "ترتيب المعطيات بدقة"] },
              { title: "3. الأمثلة التطبيقية", items: [pts[2].slice(0, 45), "ربط الدرس بالواقع"] },
              { title: "4. التقويم والمراجعة", items: ["حل أسئلة الوحدة", "التحقق من النتيجة النهائية"] }
            ]
          });
        }
        if (pr.indexOf('"lines":[') !== -1) {
          return JSON.stringify({
            lines: [
              { speaker: "المعلم", text: "مرحباً بك يا بطل! اليوم سنغوص معاً في درس ممتع ومهم جداً وهو «" + tp + "»." },
              { speaker: "الطالب", text: "أهلاً يا أستاذي! ما هي الفكرة الأهم التي يجب أن أركز عليها في هذا الدرس؟" },
              { speaker: "المعلم", text: "سؤال ذكي! الركيزة الأولى هي: " + pts[0] },
              { speaker: "الطالب", text: "جميل جداً! وكيف نطبق هذه القاعدة عند حل الأسئلة والتمارين؟" },
              { speaker: "المعلم", text: "نتبع خطوات منظمة وواضحة: " + pts[1] },
              { speaker: "الطالب", text: "شكراً لك يا أستاذي، الآن أصبحت الفكرة واضحة وسأبدأ بحل التدريبات فوراً!" }
            ]
          });
        }
        // 7. Designs JSON (poster / board / card)
        if (pr.indexOf('"details":[{"k":') !== -1 || pr.indexOf('"blocks":[{"icon":') !== -1 || pr.indexOf('"reason":"سبب التكريم"') !== -1) {
          return JSON.stringify({
            title: tp.slice(0, 70),
            subtitle: "منصة EduTech Mindset — إبداع وتميز تربوي",
            details: [{ k: "الموضوع", v: tp.slice(0, 60) }, { k: "الفئة", v: "طلبة ومعلمو فلسطين" }, { k: "الإشراف", v: "أ. باسل أشرف الفقعاوي" }],
            cta: "شاركنا الإبداع والتميز العلمي الآن",
            footer: "عقلية التعليم والتكنولوجيا — EduTech Mindset",
            blocks: [
              { icon: "🎯", head: "الهدف المحوري", text: pts[0].slice(0, 120) },
              { icon: "💡", head: "القاعدة العلمية", text: pts[1].slice(0, 120) },
              { icon: "🚀", head: "التطبيق العملي", text: pts[2].slice(0, 120) },
              { icon: "🏆", head: "الخلاصة الذهبية", text: "التطبيق المنظم والمراجعة المستمرة طريق التفوق." }
            ],
            name: "الطالب المتميز / الطالبة المتميزة",
            reason: "لتفوقه وإبداعه المميز في إتقان «" + tp.slice(0, 50) + "»",
            message: "بوركت جهودك الطيبة، وإلى مزيد من التألق والنجاح العلمي!",
            teacher: "أ. باسل أشرف الفقعاوي",
            date: new Date().toLocaleDateString("ar-EG")
          });
        }
        // 7b. Rubrics JSON ("rubric":[)
        if (pr.indexOf('"rubric":[') !== -1) {
          return JSON.stringify({
            rubric: [
              { crit: "دقة المحتوى العلمي والفهم (" + tp.slice(0, 35) + ")", l4: "إتقان كامل ودقيق للمفاهيم والقواعد مع أمثلة واضحة", l3: "فهم جيد للمفاهيم الأساسية مع أخطاء طفيفة", l2: "فهم جزئي يحتاج لمزيد من التوضيح", l1: "يحتاج لدعم ومراجعة للمفاهيم الأساسية", pts: 5 },
              { crit: "التطبيق العملي وخطوات الحل", l4: "تطبيق منهجي منظم ومتسلسل لجميع الخطوات", l3: "تطبيق صحيح لمعظم الخطوات", l2: "تطبيق بعض الخطوات مع نقص في الترتيب", l1: "صعوبة في تطبيق الخطوات دون مساعدة", pts: 5 },
              { crit: "التنظيم والوضوح والعرض", l4: "عرض مرتب وواضح ومبتكر يسهل قراءته", l3: "عرض منظم ومقبول بوضوح جيد", l2: "تنظيم متوسط يحتاج لتحسين التنسيق", l1: "غير منظم ويفتقر للوضوح", pts: 5 },
              { crit: "التعاون والالتزام بالوقت", l4: "مشاركة فاعلة ومميزة وإنجاز المهمة في الوقت المحدد", l3: "تعاون جيد والتزام بمعظم التعليمات", l2: "مشاركة محدودة أو تأخر بسيط", l1: "يحتاج لتعزيز المشاركة والالتزام بالوقت", pts: 5 }
            ]
          });
        }
        // 7c. Homework Vision Grading JSON ("readText":)
        if (pr.indexOf('"readText":') !== -1) {
          return JSON.stringify({
            readText: "تم فحص وتحليل إجابة الطالب حول «" + tp.slice(0, 50) + "»",
            score: 9,
            max: 10,
            strengths: "محاولة جادة ومنظمة في عرض خطوات الحل وربطها بقاعدة الدرس.",
            mistakes: "يُنصح بمراجعة الخطوة الأخيرة للتحقق من الدقة الكاملة.",
            feedback: "أحسنت يا بطل! جهد رائع ومميز، استمر في هذا التقدم الجميل 🌟"
          });
        }
        // 7d. Worksheet Essay Auto-Grading JSON ("grades":[)
        if (pr.indexOf('"grades":[') !== -1) {
          return JSON.stringify({
            grades: [
              { idx: 0, ratio: 1, feedback: "إجابة منهجية ممتازة وواضحة 🌟" },
              { idx: 1, ratio: 0.9, feedback: "إجابة جيدة جداً ومرتبطة بالدرس 👏" },
              { idx: 2, ratio: 0.9, feedback: "خطوات صحيحة ومنظمة 👍" }
            ]
          });
        }
        // 7e. Spaced Repetition Review lines (السؤال | الجواب)
        if (pr.indexOf("السؤال | الجواب") !== -1) {
          return [
            "ما المفهوم الأساسي في درس «" + tp + "»؟ | " + pts[0],
            "ما القاعدة التطبيقية الأهم في «" + tp + "»؟ | " + pts[1],
            "كيف نتحقق من صحة الحل في «" + tp + "»؟ | بمراجعة خطوات الحل والتعويض في القاعدة المنهجية.",
            "ما الهدف من دراسة الأمثلة المحلولة في «" + tp + "»؟ | ربط المفهوم النظري بالتطبيق العملي المباشر.",
            "اذكر خطوة أساسية عند التعامل مع مسائل «" + tp + "». | تحديد المعطيات والمطلوب بدقة قبل البدء بالحل."
          ].join("\n");
        }
        // 7f. Radio Competition JSON ("cat":"اسم المجال")
        if (pr.indexOf('"cat":"اسم المجال"') !== -1) {
          return JSON.stringify({
            questions: [
              { cat: "العلوم والمعرفة", q: "ما الركيزة الأساسية التي يدرسها موضوع «" + tp + "»؟", a: pts[0].slice(0, 80) },
              { cat: "فلسطين والتاريخ", q: "ما عاصمة دولة فلسطين الأبدية؟", a: "القدس الشريف" },
              { cat: "اللغة والأدب", q: "ما ضد كلمة «الإهمال» في طلب العلم؟", a: "الاجتهاد والمثابرة" },
              { cat: "الرياضيات والمنطق", q: "ما الخطوة الأولى لحل أي مسألة علمية بدقة؟", a: "فهم المعطيات وتحديد القاعدة المناسبة" }
            ]
          });
        }
        // 8. Worksheets / Study Quiz JSON ("questions":[)
        if (pr.indexOf('"questions":[') !== -1) {
          return JSON.stringify({
            title: "ورقة عمل وتقويم: " + tp,
            questions: [
              { t: "mcq", q: "ما الفكرة الأساسية التي يرتكز عليها درس «" + tp + "»؟", options: [pts[0].slice(0, 110), "الاعتماد على التخمين غير العلمي", "حذف المعطيات الأساسية", "تجاهل خطوات التحقق"], answer: 0, pts: 2, explain: "لأن المفهوم الأساسي يربط القاعدة بالتطبيق." },
              { t: "tf", q: "يساعد تطبيق القواعد المنظمة في درس «" + tp + "» على الوصول إلى نتائج دقيقة وصحيحة.", options: ["صح", "خطأ"], answer: true, pts: 1, explain: "العبارة صحيحة." },
              { t: "fill", q: "يرتبط مفهوم ___ بتطبيق القواعد العلمية والعملية للدرس بدقة.", options: [tp, "التخمين", "الإهمال", "التكرار"], answer: tp, pts: 1, explain: "المفهوم المحوري للدرس." },
              { t: "match", q: "وصّل كل عنصر في العمود الأول بما يناسبه في العمود الثاني:", options: [pts[1].slice(0, 110), "خيار خاطئ 1", "خيار خاطئ 2", "خيار خاطئ 3"], pairs: [{ a: "المفهوم الأساسي", b: tp }, { a: "أهمية التطبيق", b: "تثبيت الفهم العميق" }, { a: "التحقق من الحل", b: "مراجعة الخطوات والنتيجة" }], answer: 0, pts: 2, explain: "مطابقة المفاهيم." },
              { t: "short", q: "اشرح بإيجاز أهمية دراسة «" + tp + "» مع ذكر مثال تطبيقي.", options: [pts[0].slice(0, 110), "لا توجد أهمية", "مجرد حفظ", "غير مطلوب"], answer: pts[0] + " — " + pts[1], pts: 2, explain: "شرح وافٍ للمفهوم." }
            ]
          });
        }
        return null;
      }
      return Promise.resolve(orig.call(window.AI, p, base.concat(extra), toolId)).catch(function (err) {
        if (window.EduOfflineBrain && typeof window.EduOfflineBrain.answerOffline === 'function') {
          var offAns = window.EduOfflineBrain.answerOffline(prompt);
          var offTxt = (offAns && offAns.synthesizedText) ? offAns.synthesizedText : "";
          var schemaJson = buildSchemaJsonIfNeeded(prompt, offTxt);
          if (schemaJson) return schemaJson;
          if (offTxt) return '🧠 [إجابة فورية من القاعدة المعرفية للمنصة]:\n\n' + offTxt;
        }
        var fallbackJson = buildSchemaJsonIfNeeded(prompt, "");
        if (fallbackJson) return fallbackJson;
        throw err;
      });
    };
    window.AI.ask.__src = true; return true;
  }

  function init() {
    loadAll().catch(function () { items = []; }).then(function () {
      syncKbToSiteBooks();
      var n = 0, iv = setInterval(function () { var a = build(), b = hook(); if ((a && b) || ++n > 60) clearInterval(iv); }, 350);
    });
  }
  window.EduSources = {
    open: function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("sourcesStudio", true); },
    addRaw: function (it, autoDb) {
      return save(Object.assign({}, it)).then(function (savedIt) {
        paint();
        if (autoDb && savedIt && savedIt.kind === "pdf") return convertPdfItemToMarkdownAndDb(savedIt.id, true);
        if (autoDb && savedIt && savedIt.markdown) return registerItemInSiteDb(savedIt, true);
        return savedIt;
      });
    },
    convertPdfToMdDb: convertPdfItemToMarkdownAndDb,
    kbList: function () { return kbRecords.slice(); },
    saveKb: saveKbRecord
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

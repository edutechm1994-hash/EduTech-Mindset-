/* بوابة الترحيب (v147): «أَهْلًا وَسَهْلًا بِكَ» + اسم المستخدم منطوقًا + أزرار تسجيل بارزة.
   - الضيف: أزرار كبيرة (Google / حساب جديد / تسجيل دخول / تصفّح كضيف).
   - العضو: ترحيب باسمه مع مسارات سريعة (طالب / معلم)، والإدارة تحصل على زر لوحتها فقط.
   - النطق: SpeechSynthesis بصوت عربي؛ إن منع المتصفح التشغيل التلقائي يُنطق عند أول لمسة، وزر 🔊 لإعادته.
   - تُعدَّل نصوص الترحيب العامة من إدارة كاملة ← الترحيب (appState.welcome). */
(function () {
  "use strict";

  var SESSION_KEY = "edutech_greeted_v2";
  var VOICE_KEY = "edutech_welcome_voice";           // "off" لإيقاف النطق
  var BRAND_SPOKEN = "إِيدِيو تِك مَايندْسِت، عَقْلِيَّةِ التَّعْلِيمِ وَالتِّكْنُولُوجِيَا، بِإِدَارَةِ الأُسْتَاذِ بَاسِل الفَقْعَاوِي";
  var hasTTS = typeof window.speechSynthesis !== "undefined" && typeof window.SpeechSynthesisUtterance !== "undefined";

  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function voiceOn() { try { return localStorage.getItem(VOICE_KEY) !== "off"; } catch (e) { return true; } }
  function setVoice(on) { try { localStorage.setItem(VOICE_KEY, on ? "on" : "off"); } catch (e) {} }

  /* ---------- هوية المستخدم الحالية ---------- */
  function currentIdentity() {
    var C = window.Cloud, cu = C && C.user ? C.user : null;
    var local = null;
    try { local = window.EduAccessControl && window.EduAccessControl.getCurrentUser ? window.EduAccessControl.getCurrentUser() : null; } catch (e) {}
    var name = "", key = "guest", role = "";
    if (local && local.name) { name = local.name; key = "l:" + String(local.email || local.name).toLowerCase(); role = String(local.roleLabel || ""); }
    if (cu) {
      key = "g:" + cu.uid;
      if (!name) name = cu.displayName || String(cu.email || "").split("@")[0];
    }
    name = String(name || "").trim().split(/\s+/)[0] || "";
    var isAdmin = !!(C && C.isAdmin);
    return { name: name, key: key, role: role, isGuest: key === "guest", isTeacher: /معلم|مشرف|مدرب/.test(role), isAdmin: isAdmin };
  }

  /* ---------- النطق ---------- */
  var armed = null;           // نص ينتظر أول لمسة
  function pickVoice() {
    var vs = [];
    try { vs = window.speechSynthesis.getVoices() || []; } catch (e) {}
    var ar = vs.filter(function (v) { return /^ar/i.test(v.lang); });
    return ar.filter(function (v) { return /SA|EG|AE/i.test(v.lang); })[0] || ar[0] || null;
  }
  function setWave(on) { var w = $("wlWave"); if (w) w.classList.toggle("wl-speaking", !!on); }
  function stopSpeaking() { try { window.speechSynthesis.cancel(); } catch (e) {} setWave(false); }
  function speak(text, fromGesture) {
    if (!hasTTS || !voiceOn() || !text) return;
    try {
      window.speechSynthesis.cancel();
      var started = false;
      var u = new window.SpeechSynthesisUtterance(text);
      u.lang = "ar-SA";
      var v = pickVoice(); if (v) u.voice = v;
      u.rate = 0.9; u.pitch = 1; u.volume = 1;
      u.onstart = function () { started = true; armed = null; setWave(true); };
      u.onend = function () { setWave(false); };
      u.onerror = function () { setWave(false); if (!fromGesture) armed = text; };
      window.speechSynthesis.speak(u);
      if (!fromGesture) {
        setTimeout(function () {
          if (!started && !window.speechSynthesis.speaking) { try { window.speechSynthesis.cancel(); } catch (e) {} armed = text; }
        }, 1100);
      }
    } catch (e) {}
  }
  function armOnFirstGesture() {
    function go() {
      document.removeEventListener("pointerdown", go, true);
      document.removeEventListener("keydown", go, true);
      document.removeEventListener("touchend", go, true);
      if (armed && $("welcomeOverlay")) { var t = armed; armed = null; speak(t, true); }
    }
    document.addEventListener("pointerdown", go, true);
    document.addEventListener("keydown", go, true);
    document.addEventListener("touchend", go, true);
  }
  if (hasTTS) { try { window.speechSynthesis.getVoices(); } catch (e) {} }

  /* ---------- نصوص ---------- */
  function spokenText(id) {
    if (id.isGuest || !id.name) return "أَهْلًا وَسَهْلًا بِكَ فِي " + BRAND_SPOKEN + ". يُمْكِنُكَ تَسْجِيلُ الدُّخُولِ أَوْ إِنْشَاءُ حِسَابٍ جَدِيدٍ لِتَبْدَأَ رِحْلَتَكَ.";
    return "أَهْلًا وَسَهْلًا بِكَ يَا " + id.name + "، فِي " + BRAND_SPOKEN + ".";
  }

  /* ---------- الواجهة ---------- */
  function injectStyle() {
    if ($("wlStyle")) return;
    var s = document.createElement("style");
    s.id = "wlStyle";
    s.textContent =
      "@keyframes wlPop{from{opacity:0;transform:translateY(18px) scale(.97)}to{opacity:1;transform:none}}" +
      "@keyframes wlBar{0%,100%{transform:scaleY(.35)}50%{transform:scaleY(1)}}" +
      "@keyframes wlGlow{0%,100%{box-shadow:0 0 0 0 rgba(245,158,11,.55)}60%{box-shadow:0 0 0 9px rgba(245,158,11,0)}}" +
      "#welcomeOverlay .wl-card{animation:wlPop .45s ease both}" +
      "#welcomeOverlay .wl-bar{display:inline-block;width:4px;height:22px;margin:0 2px;border-radius:4px;background:linear-gradient(#38bdf8,#f59e0b);transform:scaleY(.35);transform-origin:center}" +
      "#wlWave.wl-speaking .wl-bar{animation:wlBar .9s ease-in-out infinite}" +
      "#wlWave.wl-speaking .wl-bar:nth-child(2){animation-delay:.12s}#wlWave.wl-speaking .wl-bar:nth-child(3){animation-delay:.24s}" +
      "#wlWave.wl-speaking .wl-bar:nth-child(4){animation-delay:.36s}#wlWave.wl-speaking .wl-bar:nth-child(5){animation-delay:.48s}" +
      "#btnHeaderRegister{animation:wlGlow 2.4s ease-in-out infinite}" +
      "#btnGoogleLoginHeader{box-shadow:0 0 0 2px rgba(14,165,233,.35)}" +
      "@media (prefers-reduced-motion:reduce){#welcomeOverlay .wl-card,#wlWave.wl-speaking .wl-bar,#btnHeaderRegister{animation:none}}";
    document.head.appendChild(s);
  }

  function actionBtn(cls, id, icon, label) {
    return '<button type="button" id="' + id + '" class="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-2xl text-sm font-black ' + cls + ' active:scale-95 transition">' +
      '<i class="' + icon + '"></i><span>' + label + '</span></button>';
  }

  function build(id) {
    var w = (typeof appState !== "undefined" && appState && appState.welcome) || {};
    var custom = (w.text && String(w.text).indexOf("منصة تعليمية من غزة") !== 0) ? String(w.text).replace(/\{name\}/g, id.name || "ضيفنا الكريم") : "";
    var o = document.createElement("div");
    o.id = "welcomeOverlay";
    o.setAttribute("role", "dialog");
    o.setAttribute("aria-modal", "true");
    o.setAttribute("aria-label", "ترحيب");
    o.className = "fixed inset-0 z-[80] flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-md overflow-y-auto";
    var greet = id.isGuest || !id.name
      ? '<div class="text-[26px] sm:text-3xl font-black text-white leading-snug">أَهْلًا وَسَهْلًا بِكَ</div>'
      : '<div class="text-sm font-bold text-sky-200">أَهْلًا وَسَهْلًا بِكَ</div><div class="text-[30px] sm:text-4xl font-black text-white leading-snug break-words">' + esc(id.name) + ' <span class="inline-block">👋</span></div>';
    var actions;
    if (id.isGuest) {
      actions =
        actionBtn("bg-white text-slate-900 border border-slate-200 shadow-lg", "wlGoogle", "fa-brands fa-google", "الدخول بحساب Google") +
        actionBtn("bg-gradient-to-l from-amber-500 to-rose-500 text-white shadow-lg", "wlRegister", "fa-solid fa-user-plus", "إنشاء حساب جديد") +
        actionBtn("bg-brand-600 hover:bg-brand-500 text-white", "wlLogin", "fa-solid fa-right-to-bracket", "تسجيل الدخول") +
        '<button type="button" id="wlGuest" class="w-full text-center text-[12px] font-bold text-slate-500 dark:text-slate-400 underline underline-offset-4 py-1.5">تصفّح كضيف الآن</button>';
    } else {
      actions =
        '<div class="grid grid-cols-2 gap-2.5">' +
        '<a id="wlStudent" href="#learnSection" class="flex flex-col items-center justify-center gap-1 px-3 py-3.5 rounded-2xl bg-gradient-to-br from-sky-500 to-brand-600 text-white text-sm font-black shadow-lg active:scale-95 transition"><span class="text-2xl">🎒</span><span>رحلة الطالب</span></a>' +
        '<button type="button" id="wlTeacher" data-qsjump="teacherDash" class="flex flex-col items-center justify-center gap-1 px-3 py-3.5 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white text-sm font-black shadow-lg active:scale-95 transition"><span class="text-2xl">🧑‍🏫</span><span>أدوات المعلم</span></button>' +
        '</div>' +
        '<button type="button" id="wlAll" data-qsjump="*" class="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 text-xs font-black"><i class="fa-solid fa-rocket"></i><span>كل الأدوات</span></button>' +
        (id.isAdmin ? '<button type="button" id="wlAdmin" class="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl bg-slate-900 text-amber-300 border border-amber-500/40 text-xs font-black"><i class="fa-solid fa-crown"></i><span>لوحة الإدارة</span></button>' : "");
    }
    o.innerHTML =
      '<div class="wl-card relative w-full max-w-md my-auto rounded-[28px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-2xl overflow-hidden text-center">' +
        '<div class="relative px-5 pt-7 pb-6 bg-gradient-to-br from-slate-950 via-brand-900 to-indigo-900">' +
          '<button type="button" id="wlX" aria-label="إغلاق" class="absolute top-3 left-3 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white"><i class="fa-solid fa-xmark"></i></button>' +
          (hasTTS ? '<button type="button" id="wlVoice" aria-label="تشغيل أو إيقاف الصوت" class="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white"><i class="fa-solid ' + (voiceOn() ? "fa-volume-high" : "fa-volume-xmark") + '"></i></button>' : "") +
          '<img src="assets/logo.png" alt="EduTech Mindset" width="76" height="76" class="mx-auto w-[76px] h-[76px] rounded-2xl bg-white/95 p-1.5 shadow-xl object-contain mb-3" onerror="this.style.display=\'none\'">' +
          greet +
          '<div class="mt-2 text-[13px] sm:text-sm font-extrabold text-amber-300">في EduTech Mindset</div>' +
          '<div class="text-[12px] sm:text-[13px] font-bold text-sky-100">عقلية التعليم والتكنولوجيا</div>' +
          '<div class="mt-1.5 text-[11px] sm:text-xs font-semibold text-slate-300">إدارة الأستاذ باسل الفقعاوي</div>' +
          (hasTTS ? '<div id="wlWave" class="mt-3 h-6 flex items-center justify-center cursor-pointer" aria-hidden="true"><span class="wl-bar"></span><span class="wl-bar"></span><span class="wl-bar"></span><span class="wl-bar"></span><span class="wl-bar"></span></div>' : "") +
        '</div>' +
        '<div class="p-5 space-y-2.5">' +
          (custom ? '<p class="text-xs leading-loose text-slate-600 dark:text-slate-300 whitespace-pre-line mb-1">' + esc(custom) + '</p>' : "") +
          (id.isGuest ? '<p class="text-[12px] leading-relaxed text-slate-600 dark:text-slate-300 mb-1">سجّل لتحفظ مفضلتك وإنجازاتك وتصلك صلاحياتك على كل أجهزتك.</p>' : "") +
          actions +
        '</div>' +
      '</div>';
    return o;
  }

  var escHandler = function (e) { if (e.key === "Escape") { var o = $("welcomeOverlay"); var x = o && o.querySelector("#wlX"); if (x) x.click(); } };

  function close(o, id) {
    stopSpeaking();
    armed = null;
    if (o && o.parentNode) o.parentNode.removeChild(o);
    document.removeEventListener("keydown", escHandler, true);
    try { sessionStorage.setItem(SESSION_KEY, id.key); } catch (e) {}
  }

  function clickId(id) { var b = $(id); if (b) b.click(); }

  function openLocal(mode) {
    try {
      if (window.EduMasterHierarchy && window.EduMasterHierarchy.openAuthTab) { window.EduMasterHierarchy.openAuthTab(mode); return; }
    } catch (e) {}
    clickId("btnGoogleLoginHeader");
  }

  window.showWelcome = function (force) {
    var w = (typeof appState !== "undefined" && appState && appState.welcome) || {};
    if (!force && w.enabled === false) return;
    var id = currentIdentity();
    injectStyle();
    var old = $("welcomeOverlay"); if (old) { stopSpeaking(); old.remove(); }
    var o = build(id);
    document.body.appendChild(o);
    var done = function () { close(o, id); };
    o.querySelector("#wlX").addEventListener("click", done);
    o.addEventListener("click", function (e) { if (e.target === o) done(); });
    document.addEventListener("keydown", escHandler, true);

    var vb = o.querySelector("#wlVoice");
    if (vb) vb.addEventListener("click", function () {
      var on = !voiceOn(); setVoice(on);
      vb.firstChild.className = "fa-solid " + (on ? "fa-volume-high" : "fa-volume-xmark");
      if (on) speak(spokenText(id), true); else stopSpeaking();
    });
    var wave = o.querySelector("#wlWave");
    if (wave) wave.addEventListener("click", function () { if (voiceOn()) speak(spokenText(id), true); });

    var g = o.querySelector("#wlGoogle"); if (g) g.addEventListener("click", function () { done(); clickId("btnGoogleLoginHeader"); });
    var r = o.querySelector("#wlRegister"); if (r) r.addEventListener("click", function () { done(); openLocal("register"); });
    var l = o.querySelector("#wlLogin"); if (l) l.addEventListener("click", function () { done(); openLocal("login"); });
    var gu = o.querySelector("#wlGuest"); if (gu) gu.addEventListener("click", done);
    ["wlStudent", "wlTeacher", "wlAll"].forEach(function (k) { var b = o.querySelector("#" + k); if (b) b.addEventListener("click", done); });
    var ad = o.querySelector("#wlAdmin");
    if (ad) ad.addEventListener("click", function () { done(); try { window.EduMasterHierarchy.navigateToTarget("admin"); } catch (e) {} });

    speak(spokenText(id), false);
    if (hasTTS && voiceOn()) armOnFirstGesture();
  };

  /* ---------- أزرار الهيدر البارزة (تُخفى تلقائيًا عند الدخول) ---------- */
  function headerButtons() {
    var gb = $("btnGoogleLoginHeader");
    if (!gb || $("btnHeaderRegister")) return;
    injectStyle();
    var b = document.createElement("button");
    b.id = "btnHeaderRegister";
    b.type = "button";
    b.setAttribute("aria-label", "إنشاء حساب جديد");
    b.className = "items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-gradient-to-l from-amber-500 to-rose-500 text-white text-[11px] font-black shadow-md active:scale-95 flex";
    b.innerHTML = '<i class="fa-solid fa-user-plus text-[11px]"></i><span>حساب جديد</span>';
    b.addEventListener("click", function () { openLocal("register"); });
    gb.parentNode.insertBefore(b, gb.nextSibling);
    var span = gb.querySelector("span"); if (span) span.textContent = "تسجيل الدخول";
    function sync() { var hide = gb.classList.contains("hidden") || gb.style.display === "none"; b.style.display = hide ? "none" : ""; }
    sync();
    try { new MutationObserver(sync).observe(gb, { attributes: true, attributeFilter: ["class", "style"] }); } catch (e) {}
  }

  /* ---------- متى يظهر الترحيب ---------- */
  var shownGuest = false;
  function maybeGreet() {
    var id = currentIdentity();
    var last = ""; try { last = sessionStorage.getItem(SESSION_KEY) || ""; } catch (e) {}
    if (last === id.key) return;
    if (shownGuest && id.isGuest) return;
    if (id.isGuest) shownGuest = true;
    window.showWelcome(false);
  }

  function init() {
    headerButtons();
    var C = window.Cloud, resolved = false, timer = null;
    function first() { if (resolved) return; resolved = true; clearTimeout(timer); setTimeout(maybeGreet, 450); }
    if (C && C.enabled && typeof C.onAuth === "function") {
      try {
        C.onAuth(function (u) {
          if (!resolved) { first(); return; }
          if (u) setTimeout(maybeGreet, 900);   // دخول لاحق في الجلسة نفسها: ترحيب شخصي جديد
        });
      } catch (e) {}
      timer = setTimeout(first, 4500);
    } else {
      timer = setTimeout(first, 1800);
    }
  }
  if (document.readyState === "complete") setTimeout(init, 300);
  else window.addEventListener("load", function () { setTimeout(init, 300); });
})();

/* dock.js: يجمع الأزرار العائمة للمستخدم (أعمالي المحفوظة، مشغّل الأدوات) في زر جانبي صغير أنيق دون تغطية البطاقات، مع إخفاء زر (كل الأدوات) العائم على الجوال لأنه موجود في وسط الشريط السفلي.
 * ملاحظة: تم نقل ودمج كافة أدوات وإعدادات تطوير وإدارة الموقع في المركز السفلي الموحّد (#adminDevFooterHub) الخاص بالإدارة فقط. */
(function () {
  "use strict";
  var IDS = ["eduFloatingLauncher", "exFab"], KEY = "edu_dock_open";
  var dock, tog, open = false;
  try { open = localStorage.getItem(KEY) === "1"; } catch (e) {}
  function css() {
    if (document.getElementById("dockCss")) return;
    var s = document.createElement("style"); s.id = "dockCss";
    s.textContent =
      "#floatDock{position:fixed;left:6px;bottom:calc(var(--navh,64px) + 8px);z-index:35;opacity:.88;transition:opacity .2s;display:flex;flex-direction:column-reverse;align-items:flex-start;gap:8px;pointer-events:none}#floatDock:hover,#floatDock:focus-within{opacity:1}" +
      "#floatDock>*{pointer-events:auto;position:relative!important;inset:auto!important;margin:0!important;transform:none}" +
      "#floatDock.closed>.dk-x{display:none!important}" +
      "@media (max-width:1023px){#floatDock>#eduFloatingLauncher{display:none!important}}" +
      "#dkTog{width:32px;height:32px;border-radius:11px;background:rgba(15,23,42,.92);color:#fff;font-weight:900;font-size:16px;box-shadow:0 6px 18px rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.22);line-height:1;display:flex;align-items:center;justify-content:center}" +
      "html.modal-open #floatDock{display:none}@media print{#floatDock{display:none}}" +
      "@media (min-width:1024px){#floatDock{bottom:20px}#dkTog{display:none}#floatDock.closed>.dk-x{display:flex!important}}";
    document.head.appendChild(s);
  }
  function navH() { var n = document.getElementById("mobileBottomNav"); var h = n && n.offsetHeight ? n.offsetHeight : 0; document.documentElement.style.setProperty("--navh", (h || 64) + "px"); }
  function setOpen(v) {
    open = v;
    try { localStorage.setItem(KEY, v ? "1" : "0"); } catch (e) {}
    if (dock) {
      dock.classList.toggle("closed", !open);
      tog.innerHTML = open ? '<i class="fa-solid fa-xmark text-xs"></i>' : '<i class="fa-solid fa-folder-tree text-xs text-sky-400"></i>';
      tog.setAttribute("aria-label", open ? "إخفاء الأدوات العائمة" : "أعمالي المحفوظة والأدوات");
      tog.title = open ? "إغلاق" : "أعمالي المحفوظة وفهرس الأدوات";
    }
  }
  function gather() {
    css();
    if (!dock) {
      dock = document.createElement("div"); dock.id = "floatDock";
      tog = document.createElement("button"); tog.type = "button"; tog.id = "dkTog"; tog.onclick = function () { setOpen(!open); };
      dock.appendChild(tog); document.body.appendChild(dock); setOpen(open);
    }
    IDS.forEach(function (id, i) {
      var el = document.getElementById(id);
      if (el && el.parentNode !== dock) {
        if (i > 0) el.classList.add("dk-x");
        dock.insertBefore(el, tog);
      }
    });
    var order = IDS.map(function (id) { return document.getElementById(id); }).filter(Boolean);
    order.forEach(function (el) { dock.insertBefore(el, tog); });
    navH();
  }
  var t;
  function sched() { clearTimeout(t); t = setTimeout(gather, 200); }
  function init() { gather(); window.addEventListener('edu:lazy-ready', sched); window.addEventListener("resize", navH); setTimeout(navH, 1200); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

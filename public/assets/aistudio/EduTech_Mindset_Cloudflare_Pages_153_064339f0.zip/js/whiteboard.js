/*
 * السبورة التفاعلية الذكية للمعلم (Smart Interactive Classroom Whiteboard) — EduTech Mindset (الإصدار 47)
 * تدعم:
 * - تعدد الصفحات (ألواح متعددة في الحصة الواحدة)
 * - 4 خلفيات (سبورة بيضاء، سبورة خضراء/داكنة، شبكة مربعات بيانية للرياضيات، وسطور للغة العربية والخط)
 * - أدوات رسم (قلم حر، قلم تظليل فسفوري، ممحاة، خط مستقيم، مستطيل، دائرة، محاور إحداثيات، ونص عربي)
 * - إدراج صورة صفحة من الكتاب المدرسي والشرح بالقلم فوقها مباشرة
 * - 🤖 حل المسألة أو شرح الرسم الموجود على السبورة بالذكاء الاصطناعي (Vision AI)
 * - 🎥 تسجيل الشرح كملف فيديو (WebM) أو تنزيل السبورة كملف PDF / صورة PNG
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };

  var st = {
    tool: "pen", // pen | high | erase | line | rect | circle | text
    color: "#1e293b",
    size: 4,
    bg: "white", // white | chalkboard | grid | lines
    pages: [], // array of dataURLs
    pageIdx: 0,
    undoStack: [],
    drawing: false,
    startX: 0,
    startY: 0,
    snapshot: null,
    recorder: null,
    recChunks: [],
    recording: false
  };

  var W = 1200, H = 680;

  function drawBackground(ctx, bgType) {
    if (bgType === "chalkboard") {
      ctx.fillStyle = "#064e3b";
      ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = "rgba(255,255,255,0.06)";
      ctx.lineWidth = 1;
      for (var y = 40; y < H; y += 40) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
    } else if (bgType === "grid") {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = "#e2e8f0";
      ctx.lineWidth = 1;
      for (var gx = 0; gx < W; gx += 30) { ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke(); }
      for (var gy = 0; gy < H; gy += 30) { ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke(); }
      // محاور رئيسية خفيفة
      ctx.strokeStyle = "#94a3b8"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(W / 2, 0); ctx.lineTo(W / 2, H); ctx.moveTo(0, H / 2); ctx.lineTo(W, H / 2); ctx.stroke();
    } else if (bgType === "lines") {
      ctx.fillStyle = "#fffbeb";
      ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = "#cbd5e1"; ctx.lineWidth = 1.5;
      for (var ly = 65; ly < H; ly += 48) { ctx.beginPath(); ctx.moveTo(40, ly); ctx.lineTo(W - 40, ly); ctx.stroke(); }
      ctx.strokeStyle = "#fca5a5"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(W - 90, 0); ctx.lineTo(W - 90, H); ctx.stroke();
    } else {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, W, H);
    }
  }

  /* ---------- وضع ملء الشاشة للشرح ---------- */
  var FULL_CSS = "#whiteboardStudio.wb-full{position:fixed!important;inset:0;z-index:420;background:#0b1220;padding:0!important;margin:0;overflow:hidden;content-visibility:visible!important;display:block}" +
    "#whiteboardStudio.wb-full>div{max-width:none!important;padding:0!important;height:100%;margin:0}" +
    "#whiteboardStudio.wb-full .glass-card{height:100%;border-radius:0!important;border:0!important;display:flex;flex-direction:column;background:#0b1220;box-shadow:none}" +
    "#whiteboardStudio.wb-full .glass-card>div:first-child{display:none}" +
    "#whiteboardStudio.wb-full .glass-card>div:nth-child(2){flex:1;min-height:0;display:flex;flex-direction:column;padding:6px!important;gap:6px;overflow:hidden}" +
    "#whiteboardStudio.wb-full .glass-card>div:nth-child(2)>div:nth-child(1){flex-wrap:nowrap;overflow-x:auto;flex:none;padding:6px 52px 6px 52px;gap:10px}" +
    "#whiteboardStudio.wb-full .glass-card>div:nth-child(2)>div:nth-child(1) *{white-space:nowrap}" +
    "#whiteboardStudio.wb-full .glass-card>div:nth-child(2)>div:nth-child(1)>*{flex:none!important;flex-wrap:nowrap!important}" +
    "#whiteboardStudio.wb-full .glass-card>div:nth-child(2)>div:nth-child(1) button,#whiteboardStudio.wb-full .glass-card>div:nth-child(2)>div:nth-child(1) label{padding:6px 10px}" +
    "#whiteboardStudio.wb-full .glass-card>div:nth-child(2)>div:nth-child(2){flex:1;min-height:0;display:flex;align-items:center;justify-content:center;border:0;border-radius:12px;background:#020617}" +
    "#whiteboardStudio.wb-full .glass-card>div:nth-child(2)>div:nth-child(3){flex:none;flex-wrap:nowrap;overflow-x:auto;gap:8px}" +
    "#whiteboardStudio.wb-full .glass-card>div:nth-child(2)>div:nth-child(3) *{white-space:nowrap}" +
    "#whiteboardStudio.wb-full #wbAiOut{position:absolute;left:8px;bottom:58px;max-width:min(520px,92vw);max-height:40vh;overflow:auto;z-index:2}" +
    "#wbExitFull,#wbBarsBtn{display:none}#whiteboardStudio.wb-full #wbExitFull,#whiteboardStudio.wb-full #wbBarsBtn{display:flex}" +
    "#whiteboardStudio.wb-full.wb-bars-off .glass-card>div:nth-child(2)>div:nth-child(1),#whiteboardStudio.wb-full.wb-bars-off .glass-card>div:nth-child(2)>div:nth-child(3){display:none}" +
    "#whiteboardStudio.wb-full.wb-bars-off .glass-card>div:nth-child(2){padding:0!important}#whiteboardStudio.wb-full.wb-bars-off .glass-card>div:nth-child(2)>div:nth-child(2){border-radius:0}" +
    "html.wb-lock,html.wb-lock body{overflow:hidden!important}html.wb-lock #floatDock,html.wb-lock #eduFloatingLauncher,html.wb-lock #exFab,html.wb-lock #homeAdminFab,html.wb-lock #mobileBottomNav{display:none!important}";
  function initFull(s) {
    if (!document.getElementById("wbFullCss")) { var cs = document.createElement("style"); cs.id = "wbFullCss"; cs.textContent = FULL_CSS; document.head.appendChild(cs); }
    var ex = document.createElement("button"); ex.type = "button"; ex.id = "wbExitFull"; ex.textContent = "✕"; ex.setAttribute("aria-label", "خروج من ملء الشاشة");
    ex.style.cssText = "position:absolute;top:8px;right:8px;z-index:5;width:40px;height:40px;border-radius:12px;background:#e11d48;color:#fff;font-weight:900;font-size:18px;align-items:center;justify-content:center;box-shadow:0 4px 14px rgba(0,0,0,.4)";
    s.appendChild(ex);
    var bb = document.createElement("button"); bb.type = "button"; bb.id = "wbBarsBtn"; bb.textContent = "⇅"; bb.setAttribute("aria-label", "إخفاء/إظهار الأدوات");
    bb.style.cssText = "position:absolute;top:8px;left:8px;z-index:5;width:40px;height:40px;border-radius:12px;background:#0f172a;color:#fff;font-weight:900;font-size:18px;align-items:center;justify-content:center;border:1px solid rgba(255,255,255,.35);box-shadow:0 4px 14px rgba(0,0,0,.4);opacity:.92";
    s.appendChild(bb);
    var cv = $("wbCanvas"), on = false;
    function fit() {
      if (!on) { cv.style.width = ""; cv.style.height = ""; return; }
      var box = cv.parentNode; cv.style.width = "0px"; cv.style.height = "0px";
      var aw = box.clientWidth, ah = box.clientHeight, k = Math.min(aw / W, ah / H);
      cv.style.width = Math.floor(W * k) + "px"; cv.style.height = Math.floor(H * k) + "px";
    }
    function enter() {
      on = true; s.classList.add("wb-full"); document.documentElement.classList.add("wb-lock");
      var el = s; try { (el.requestFullscreen || el.webkitRequestFullscreen || function () {}).call(el); } catch (e) {}
      try { if (screen.orientation && screen.orientation.lock) screen.orientation.lock("landscape").catch(function () {}); } catch (e) {}
      setTimeout(fit, 60); setTimeout(fit, 400);
    }
    function leave() {
      if (!on) return; on = false; s.classList.remove("wb-full"); s.classList.remove("wb-bars-off"); document.documentElement.classList.remove("wb-lock"); fit();
      try { if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen(); } catch (e) {}
      try { if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock(); } catch (e) {}
      try { s.scrollIntoView({ block: "start" }); } catch (e) {}
    }
    $("wbFullBtn").onclick = function () { on ? leave() : enter(); };
    ex.onclick = leave;
    bb.onclick = function () { s.classList.toggle("wb-bars-off"); setTimeout(fit, 60); };
    document.addEventListener("fullscreenchange", function () { if (on && !document.fullscreenElement) leave(); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && on) leave(); });
    window.addEventListener("resize", function () { if (on) setTimeout(fit, 100); });
    window.addEventListener("orientationchange", function () { if (on) setTimeout(fit, 300); });
  }

  function pushUndo() {
    var cv = $("wbCanvas"); if (!cv) return;
    st.undoStack.push(cv.toDataURL("image/png"));
    if (st.undoStack.length > 20) st.undoStack.shift();
  }

  function saveCurrentPage() {
    var cv = $("wbCanvas"); if (!cv) return;
    st.pages[st.pageIdx] = cv.toDataURL("image/png");
  }

  function loadPage(idx) {
    var cv = $("wbCanvas"); if (!cv) return;
    var ctx = cv.getContext("2d");
    st.pageIdx = idx;
    st.undoStack = [];
    if (st.pages[idx]) {
      var im = new Image();
      im.onload = function () { ctx.clearRect(0, 0, W, H); ctx.drawImage(im, 0, 0, W, H); };
      im.src = st.pages[idx];
    } else {
      drawBackground(ctx, st.bg);
      saveCurrentPage();
    }
    updatePageCounter();
  }

  function updatePageCounter() {
    var el = $("wbPageInfo");
    if (el) el.textContent = "لوحة " + (st.pageIdx + 1) + " من " + Math.max(1, st.pages.length);
  }

  function getCoords(ev, cv) {
    var r = cv.getBoundingClientRect();
    var clientX = ev.touches && ev.touches[0] ? ev.touches[0].clientX : ev.clientX;
    var clientY = ev.touches && ev.touches[0] ? ev.touches[0].clientY : ev.clientY;
    return {
      x: (clientX - r.left) * (W / r.width),
      y: (clientY - r.top) * (H / r.height)
    };
  }

  function bindCanvas() {
    var cv = $("wbCanvas"); if (!cv) return;
    var ctx = cv.getContext("2d");
    drawBackground(ctx, st.bg);
    saveCurrentPage();

    function onDown(ev) {
      if (ev.button && ev.button !== 0) return;
      ev.preventDefault();
      var p = getCoords(ev, cv);
      if (st.tool === "text") {
        var txt = window.eduPrompt("اكتب النص لإدراجه على السبورة:");
        if (txt) {
          pushUndo();
          ctx.save();
          ctx.direction = "rtl";
          ctx.fillStyle = st.color;
          ctx.font = "900 " + Math.max(22, st.size * 6) + "px Cairo, Tahoma, sans-serif";
          ctx.fillText(txt, p.x, p.y);
          ctx.restore();
          saveCurrentPage();
        }
        return;
      }
      pushUndo();
      st.drawing = true;
      st.startX = p.x; st.startY = p.y;
      st.snapshot = ctx.getImageData(0, 0, W, H);
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
    }

    function onMove(ev) {
      if (!st.drawing) return;
      ev.preventDefault();
      var p = getCoords(ev, cv);
      ctx.lineCap = "round"; ctx.lineJoin = "round";

      if (st.tool === "pen" || st.tool === "high" || st.tool === "erase") {
        ctx.save();
        if (st.tool === "high") {
          ctx.globalAlpha = 0.32;
          ctx.strokeStyle = st.color;
          ctx.lineWidth = st.size * 5;
        } else if (st.tool === "erase") {
          ctx.strokeStyle = st.bg === "chalkboard" ? "#064e3b" : st.bg === "lines" ? "#fffbeb" : "#ffffff";
          ctx.lineWidth = st.size * 7;
        } else {
          ctx.strokeStyle = st.color;
          ctx.lineWidth = st.size;
        }
        ctx.lineTo(p.x, p.y);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.restore();
      } else {
        ctx.putImageData(st.snapshot, 0, 0);
        ctx.save();
        ctx.strokeStyle = st.color;
        ctx.lineWidth = st.size;
        ctx.beginPath();
        if (st.tool === "line") {
          ctx.moveTo(st.startX, st.startY);
          ctx.lineTo(p.x, p.y);
        } else if (st.tool === "rect") {
          ctx.rect(st.startX, st.startY, p.x - st.startX, p.y - st.startY);
        } else if (st.tool === "circle") {
          var rad = Math.hypot(p.x - st.startX, p.y - st.startY);
          ctx.arc(st.startX, st.startY, rad, 0, Math.PI * 2);
        }
        ctx.stroke();
        ctx.restore();
      }
    }

    function onUp() {
      if (!st.drawing) return;
      st.drawing = false;
      saveCurrentPage();
    }

    cv.addEventListener("mousedown", onDown);
    cv.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    cv.addEventListener("touchstart", onDown, { passive: false });
    cv.addEventListener("touchmove", onMove, { passive: false });
    window.addEventListener("touchend", onUp);
  }

  function solveBoardWithAI() {
    var cv = $("wbCanvas"), box = $("wbAiOut"), btn = $("wbAiBtn");
    if (!cv || !box) return;
    btn.disabled = true; btn.textContent = "⏳ يقرأ السبورة ويحللها…";
    var b64 = cv.toDataURL("image/jpeg", 0.8).split(",")[1];
    var prompt = "أنت معلم خبير. انظر إلى ما كُتب أو رُسم على هذه السبورة التعليمية، وقم بحل المسألة خطوة بخطوة أو شرح الرسم والمفهوم المكتوب بالعربية المبسطة والمنظمة.";
    window.AI.ask(prompt, [{ mime: "image/jpeg", data: b64 }], "worksheet").then(function (txt) {
      box.innerHTML = '<div class="rounded-2xl border-2 border-teal-400 bg-teal-50/70 dark:bg-slate-900/80 p-4 text-xs leading-relaxed whitespace-pre-line">' +
        '<div class="font-black text-teal-700 dark:text-teal-300 mb-1">🤖 قراءة وحل السبورة بالذكاء الاصطناعي:</div>' + e(txt) + '</div>';
    }).catch(function (err) {
      toast((err && err.message) || "تأكد من تفعيل محرك يدعم الصور (Gemini/OpenAI/Claude)", "warning");
    }).then(function () {
      btn.disabled = false; btn.textContent = "🤖 حلّ أو اشرح ما على السبورة بالـ AI";
    });
  }

  function toggleRecordVideo() {
    var cv = $("wbCanvas"), btn = $("wbRecBtn");
    if (!cv || !btn) return;
    if (st.recording && st.recorder) {
      st.recorder.stop();
      st.recording = false;
      btn.textContent = "🎥 تسجيل فيديو للشرح";
      btn.className = btn.className.replace("bg-rose-600 animate-pulse", "bg-rose-500");
      return;
    }
    if (!cv.captureStream || typeof MediaRecorder === "undefined") {
      toast("متصفحك الحالي لا يدعم تسجيل اللوحة كفيديو مباشر", "warning");
      return;
    }
    try {
      var stream = cv.captureStream(25);
      st.recChunks = [];
      st.recorder = new MediaRecorder(stream);
      st.recorder.ondataavailable = function (ev) { if (ev.data && ev.data.size > 0) st.recChunks.push(ev.data); };
      st.recorder.onstop = function () {
        var blob = new Blob(st.recChunks, { type: "video/webm" });
        var a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = "شرح-السبورة-" + Date.now().toString(36) + ".webm";
        document.body.appendChild(a); a.click();
        setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
        toast("تم تنزيل فيديو شرح السبورة بنجاح 🎬");
      };
      st.recorder.start();
      st.recording = true;
      btn.textContent = "⏹ إيقاف وحفظ الفيديو";
      btn.className += " bg-rose-600 animate-pulse";
      toast("🔴 بدأ تسجيل كل ما ترسمه على السبورة…");
    } catch (x) {
      toast("تعذر بدء تسجيل الفيديو", "warning");
    }
  }

  function exportAllPagesPdf() {
    saveCurrentPage();
    var imgs = st.pages.map(function (src) {
      return '<div style="width:297mm;height:209mm;page-break-after:always;display:flex;align-items:center;justify-content:center"><img src="' + src + '" style="max-width:100%;max-height:100%"></div>';
    }).join("");
    var html = '<!doctype html><html><head><meta charset="utf-8"><title>ألواح الحصة</title><style>@page{size:A4 landscape;margin:0}body{margin:0;padding:0}</style></head><body>' + imgs + '</body></html>';
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
  }

  function build() {
    if ($("whiteboardStudio")) return true;
    var anchor = $("slidesStudio") || $("teacherTools") || $("aiStudio");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "whiteboardStudio";
    s.className = "py-12 scroll-mt-20";
    var tb = "px-3 py-1.5 rounded-xl text-[11px] font-extrabold border transition-all ";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-slate-800 via-emerald-900 to-slate-950 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-emerald-300 mb-1">🖍️ السبورة التفاعلية الذكية للمعلم والطالب</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">اشرح درسك بالرسم والأشكال أو فوق صورة صفحة الكتاب مع تسجيل فيديو وحل ذكي</h2>' +
      '<p class="text-xs text-white/80 mt-1">سبورة متعددة الصفحات بشبكة بيانية وسطور عربية، تعمل باللمس والماوس بلا إنترنت مع تصدير PDF وتسجيل الشرح.</p>' +
      '</div>' +
      '<div class="p-4 sm:p-5 space-y-3 text-right">' +
      '<div class="flex flex-wrap items-center gap-1.5 bg-slate-100 dark:bg-slate-800/90 p-2.5 rounded-2xl">' +
      '[[' +
      '["pen","✏️ قلم"],["high","🖍️ تظليل"],["erase","🧽 ممحاة"],["line","📏 خط"],["rect","▭ مستطيل"],["circle","◯ دائرة"],["text","🔤 نص"]' +
      ']]' +
      '</div></div></div></div>';

    // بناء شريط الأدوات النظيف
    var toolsHtml = [
      ["pen", "✏️ قلم"], ["high", "🖍️ تظليل"], ["erase", "🧽 ممحاة"],
      ["line", "📏 خط مستقيم"], ["rect", "▭ مستطيل"], ["circle", "◯ دائرة"], ["text", "🔤 إضافة نص"]
    ].map(function (t) {
      return '<button type="button" data-wbtool="' + t[0] + '" class="' + tb + (st.tool === t[0] ? "bg-brand-600 text-white border-brand-600" : "bg-white dark:bg-slate-900 border-slate-300 dark:border-slate-700") + '">' + t[1] + '</button>';
    }).join("");

    var colorsHtml = ["#1e293b", "#e11d48", "#2563eb", "#059669", "#d97706", "#7c3aed", "#ffffff"].map(function (c) {
      return '<button type="button" data-wbcol="' + c + '" style="background:' + c + '" aria-label="لون ' + c + '" class="w-6 h-6 rounded-full border-2 ' + (st.color === c ? "border-amber-400 scale-110" : "border-slate-300") + '"></button>';
    }).join("");

    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-slate-800 via-emerald-900 to-slate-950 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-emerald-300 mb-1">🖍️ السبورة التفاعلية الذكية للمعلم والطالب</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">اشرح درسك بالرسم والأشكال أو فوق صورة صفحة الكتاب مع تسجيل فيديو وحل ذكي</h2>' +
      '<p class="text-xs text-white/80 mt-1">سبورة متعددة الصفحات بشبكة بيانية وسطور عربية، تعمل باللمس والماوس بلا إنترنت مع تصدير PDF وتسجيل الشرح.</p>' +
      '</div>' +
      '<div class="p-4 sm:p-5 space-y-3 text-right">' +
      '<div class="flex flex-wrap items-center justify-between gap-2 bg-slate-100 dark:bg-slate-800/90 p-2.5 rounded-2xl">' +
      '<div class="flex flex-wrap gap-1.5" id="wbToolsBar">' + toolsHtml + '</div>' +
      '<div class="flex items-center gap-1.5" id="wbColorsBar">' + colorsHtml + '</div>' +
      '<div class="flex items-center gap-2">' +
      '<select id="wbBgSel" class="text-xs font-bold px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700">' +
      '<option value="white">⬜ سبورة بيضاء</option><option value="chalkboard">🟩 سبورة خضراء</option><option value="grid">📐 شبكة بيانية للرياضيات</option><option value="lines">📝 سطور عربية</option></select>' +
      '<label class="' + tb + 'bg-sky-600 text-white border-sky-600 cursor-pointer">🖼 صورة كتاب<input id="wbImgInp" type="file" accept="image/*" class="hidden"></label>' +
      '<button type="button" id="wbFullBtn" class="' + tb + 'bg-emerald-600 text-white border-emerald-600">⛶ ملء الشاشة</button>' +
      '<button type="button" id="wbUndoBtn" class="' + tb + 'bg-slate-200 dark:bg-slate-700">↩ تراجع</button>' +
      '<button type="button" id="wbClearBtn" class="' + tb + 'bg-rose-500/15 text-rose-600 border-rose-300">🗑 مسح</button>' +
      '</div></div>' +
      '<div class="rounded-2xl overflow-hidden border-2 border-slate-300 dark:border-slate-700 bg-slate-900 shadow-inner">' +
      '<canvas id="wbCanvas" width="1200" height="680" class="w-full h-auto cursor-crosshair touch-none block"></canvas></div>' +
      '<div class="flex flex-wrap items-center justify-between gap-2">' +
      '<div class="flex items-center gap-1.5">' +
      '<button type="button" id="wbPrevPage" class="px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold">➡ السابقة</button>' +
      '<span id="wbPageInfo" class="text-xs font-black px-2">لوحة 1 من 1</span>' +
      '<button type="button" id="wbNextPage" class="px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold">التالية / + لوحة جديدة ⬅</button>' +
      '</div>' +
      '<div class="flex flex-wrap gap-1.5">' +
      '<button type="button" id="wbAiBtn" class="px-4 py-2 rounded-xl bg-gradient-to-l from-teal-600 to-emerald-600 text-white text-xs font-black shadow">🤖 حلّ أو اشرح ما على السبورة بالـ AI</button>' +
      '<button type="button" id="wbRecBtn" class="px-3.5 py-2 rounded-xl bg-rose-500 text-white text-xs font-black">🎥 تسجيل فيديو للشرح</button>' +
      '<button type="button" id="wbPdfBtn" class="px-3.5 py-2 rounded-xl bg-indigo-600 text-white text-xs font-black">📄 حفظ الألواح PDF</button>' +
      '<button type="button" id="wbToTutorBtn" class="px-3.5 py-2 rounded-xl bg-amber-500 text-slate-950 text-xs font-black">🤖 للمعلم الذكي</button>' +
      '</div></div>' +
      '<div id="wbAiOut"></div>' +
      '</div></div></div>';

    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    bindCanvas();
    initFull(s);

    $("wbToolsBar").querySelectorAll("[data-wbtool]").forEach(function (bt) {
      bt.onclick = function () {
        st.tool = bt.dataset.wbtool;
        $("wbToolsBar").querySelectorAll("[data-wbtool]").forEach(function (x) {
          x.className = tb + (x.dataset.wbtool === st.tool ? "bg-brand-600 text-white border-brand-600" : "bg-white dark:bg-slate-900 border-slate-300 dark:border-slate-700");
        });
      };
    });
    $("wbColorsBar").querySelectorAll("[data-wbcol]").forEach(function (bt) {
      bt.onclick = function () {
        st.color = bt.dataset.wbcol;
        if (st.tool === "erase") st.tool = "pen";
      };
    });
    $("wbBgSel").onchange = function (ev) {
      st.bg = ev.target.value;
      if (st.bg === "chalkboard" && st.color === "#1e293b") st.color = "#ffffff";
      else if (st.bg !== "chalkboard" && st.color === "#ffffff") st.color = "#1e293b";
      var cv = $("wbCanvas");
      if (cv) { pushUndo(); drawBackground(cv.getContext("2d"), st.bg); saveCurrentPage(); }
    };
    $("wbImgInp").onchange = function (ev) {
      var f = ev.target.files && ev.target.files[0]; if (!f) return;
      var url = URL.createObjectURL(f), im = new Image();
      im.onload = function () {
        var cv = $("wbCanvas"), ctx = cv.getContext("2d");
        pushUndo();
        drawBackground(ctx, st.bg);
        var scale = Math.min((W - 60) / im.width, (H - 40) / im.height);
        var dw = im.width * scale, dh = im.height * scale;
        ctx.drawImage(im, (W - dw) / 2, (H - dh) / 2, dw, dh);
        URL.revokeObjectURL(url);
        saveCurrentPage();
        toast("أُدرجت الصورة على السبورة — يمكنك الشرح بالقلم فوقها الآن ✍️");
      };
      im.src = url;
    };
    $("wbUndoBtn").onclick = function () {
      if (!st.undoStack.length) return;
      var prev = st.undoStack.pop(), cv = $("wbCanvas"), im = new Image();
      im.onload = function () { cv.getContext("2d").drawImage(im, 0, 0, W, H); saveCurrentPage(); };
      im.src = prev;
    };
    $("wbClearBtn").onclick = function () {
      var cv = $("wbCanvas"); if (!cv) return;
      pushUndo(); drawBackground(cv.getContext("2d"), st.bg); saveCurrentPage();
    };
    $("wbPrevPage").onclick = function () {
      if (st.pageIdx <= 0) return;
      saveCurrentPage(); loadPage(st.pageIdx - 1);
    };
    $("wbNextPage").onclick = function () {
      saveCurrentPage();
      if (st.pageIdx + 1 >= st.pages.length) st.pages.push(null);
      loadPage(st.pageIdx + 1);
    };
    $("wbAiBtn").onclick = solveBoardWithAI;
    $("wbRecBtn").onclick = toggleRecordVideo;
    $("wbPdfBtn").onclick = exportAllPagesPdf;
    if ($("wbToTutorBtn")) $("wbToTutorBtn").onclick = function () {
      var out = $("wbAiOut") ? $("wbAiOut").innerText.trim() : "";
      if (window.EduBridge) window.EduBridge.openTool("tutorStudio", { topic: out || "شرح السبورة التفاعلية", notes: out });
    };
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduWhiteboard = { open: function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("whiteboardStudio", true); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

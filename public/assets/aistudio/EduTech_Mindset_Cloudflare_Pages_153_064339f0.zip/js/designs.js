/*
 * مولّد الإنفوغرافيك والبوسترات — EduTech Mindset
 * أنواع: poster (إعلان) / board (لوحة تعليمية) / card (بطاقة إنجاز). مقاسات: A4 / مربع / ستوري.
 * التصدير: PNG (بدون مكتبات خارجية عبر SVG foreignObject) و PDF (طباعة). الحفظ في Firestore (designs).
 */
(function () {
  "use strict";
  var COL = "designs";
  var KINDS = { poster: "بوستر إعلان", board: "لوحة تعليمية / إنفوغرافيك", card: "بطاقة إنجاز / شكر" };
  var FORMATS = { a4: { n: "A4 طباعة", r: 1.414 }, square: { n: "مربع (واتساب/فيسبوك)", r: 1 }, story: { n: "ستوري (9:16)", r: 1.778 } };
  var THEMES = [
    { id: "ocean", n: "المحيط", bg: "linear-gradient(160deg,#0f172a,#1e3a8a)", f: "#f8fafc", a: "#fbbf24", card: "rgba(255,255,255,.12)", ink: "#0f172a" },
    { id: "forest", n: "الغابة", bg: "linear-gradient(160deg,#052e16,#166534)", f: "#f0fdf4", a: "#fde047", card: "rgba(255,255,255,.13)", ink: "#052e16" },
    { id: "sunset", n: "الغروب", bg: "linear-gradient(160deg,#7c2d12,#be123c)", f: "#fff7ed", a: "#fde68a", card: "rgba(255,255,255,.15)", ink: "#7c2d12" },
    { id: "paper", n: "ورقي", bg: "linear-gradient(160deg,#fffbeb,#fde68a)", f: "#1e293b", a: "#b45309", card: "rgba(30,41,59,.08)", ink: "#fffbeb" },
    { id: "violet", n: "البنفسج", bg: "linear-gradient(160deg,#2e1065,#6d28d9)", f: "#faf5ff", a: "#f9a8d4", card: "rgba(255,255,255,.13)", ink: "#2e1065" },
    { id: "teal", n: "الفيروز", bg: "linear-gradient(160deg,#042f2e,#0f766e)", f: "#f0fdfa", a: "#fcd34d", card: "rgba(255,255,255,.13)", ink: "#042f2e" }
  ];
  var st = { id: "", kind: "poster", format: "a4", theme: "ocean", topic: "", d: null, dirty: false };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";
  function e(s) { return typeof escapeHtml === "function" ? escapeHtml(String(s == null ? "" : s)) : String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function $(id) { return document.getElementById(id); }
  function toast(m, t) { if (typeof showToast === "function") showToast(m, t || "success"); }
  function cloud() { return window.Cloud && window.Cloud.enabled; }
  function uid() { return window.Cloud && window.Cloud.getStudioUser ? window.Cloud.getStudioUser().uid : (window.Cloud && window.Cloud.user ? window.Cloud.user.uid : "local_workspace"); }
  function th() { return THEMES.filter(function (t) { return t.id === st.theme; })[0] || THEMES[0]; }
  function str(v, n) { return String(v == null ? "" : v).trim().slice(0, n || 200); }
  function safeImg(u) { u = String(u || ""); return /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(u) && u.length < 300000 ? u : ""; }

  // ---------- تنظيف المحتوى ----------
  function norm(kind, x) {
    x = x || {}; var o = { title: str(x.title, 90), img: safeImg(x.img) };
    if (kind === "poster") {
      o.subtitle = str(x.subtitle, 140); o.cta = str(x.cta, 80); o.footer = str(x.footer, 120);
      o.details = (Array.isArray(x.details) ? x.details : []).map(function (p) { return p && { k: str(p.k, 30), v: str(p.v, 90) }; }).filter(function (p) { return p && (p.k || p.v); }).slice(0, 5);
    } else if (kind === "board") {
      o.subtitle = str(x.subtitle, 140); o.footer = str(x.footer, 100);
      o.blocks = (Array.isArray(x.blocks) ? x.blocks : []).map(function (b) { return b && { icon: str(b.icon, 4) || "⭐", head: str(b.head, 50), text: str(b.text, 160) }; }).filter(function (b) { return b && (b.head || b.text); }).slice(0, 6);
    } else {
      o.name = str(x.name, 60); o.reason = str(x.reason, 160); o.message = str(x.message, 200); o.teacher = str(x.teacher, 60); o.date = str(x.date, 40);
    }
    return o;
  }
  function parseJson(txt) {
    var s = String(txt || "").replace(/```json|```/gi, ""), a = s.indexOf("{"), b = s.lastIndexOf("}");
    if (a < 0 || b <= a) throw new Error("لم يُرجع الذكاء الاصطناعي نتيجة مفهومة، أعد المحاولة");
    return JSON.parse(s.slice(a, b + 1));
  }
  var SCHEMAS = {
    poster: '{"title":"عنوان قصير جذاب","subtitle":"سطر توضيحي","details":[{"k":"التاريخ","v":""},{"k":"الوقت","v":""},{"k":"المكان","v":""}],"cta":"دعوة قصيرة للمشاركة","footer":"للتسجيل والاستفسار: ..."}',
    board: '{"title":"عنوان اللوحة","subtitle":"سطر توضيحي","blocks":[{"icon":"🎯","head":"عنوان قصير","text":"شرح من جملة واحدة"}],"footer":"خلاصة أو شعار"}',
    card: '{"title":"شهادة تقدير","name":"اسم الطالب","reason":"سبب التكريم","message":"عبارة تشجيعية قصيرة","teacher":"المعلم","date":""}'
  };
  function buildPrompt(topic) {
    var rule = { poster: "بوستر إعلان جذاب مختصر، من 3 إلى 5 تفاصيل في details (استخدم ما ورد في الوصف وضع ... إن لم يُذكر شيء ولا تخترع تواريخ أو أرقام هواتف)", board: "لوحة تعليمية/إنفوغرافيك من 4 إلى 6 كتل blocks، لكل كتلة رمز تعبيري icon واحد مناسب وعنوان قصير ونص بجملة واحدة دقيقة علمياً", card: "بطاقة شكر/إنجاز للطلاب بعبارات إيجابية مؤثرة ومختصرة؛ اترك الاسم والتاريخ كما في الوصف أو فارغين" }[st.kind];
    return "أنت مصمم محتوى تربوي. أنشئ نص " + rule + " حسب هذا الوصف: «" + topic + "».\nأعد JSON فقط بلا شرح وبلا ```، بهذا الشكل:\n" + SCHEMAS[st.kind] + "\nالقواعد: عربية فصحى مبسّطة، النصوص قصيرة جداً (العناوين أقل من 8 كلمات)، ولا تُدخل معلومات غير موجودة في الوصف أو غير دقيقة.";
  }
  function generate() {
    st.kind = $("dzKind").value; st.format = $("dzFormat").value; st.topic = $("dzTopic").value.trim();
    if (!st.topic) { toast("اكتب وصف التصميم أولاً", "warning"); return; }
    var btn = $("dzGo"), stat = $("dzStat"); btn.disabled = true; btn.classList.add("opacity-60"); stat.textContent = "⏳ جارٍ كتابة المحتوى…";
    var keepImg = st.d && st.d.img;
    window.AI.ask(buildPrompt(st.topic), [], "design").catch(function () { return new Promise(function (r) { setTimeout(r, 1500); }).then(function () { return window.AI.ask(buildPrompt(st.topic), [], "design"); }); }).then(function (txt) {
      var d = norm(st.kind, parseJson(txt)); if (!d.title) throw new Error("نتيجة غير صالحة، أعد المحاولة");
      if (keepImg) d.img = keepImg; st.d = d; st.id = ""; st.dirty = true; stat.textContent = ""; renderEditor(); $("dzEditor").scrollIntoView({ behavior: "smooth", block: "start" });
    }, function (err) { stat.textContent = "⚠️ " + (err && err.message ? err.message : "تعذر التوليد"); }).then(function () { btn.disabled = false; btn.classList.remove("opacity-60"); });
  }

  // ---------- التصميم (HTML بأبعاد ثابتة بالبكسل؛ كل الأحجام بوحدة uu = 1% من العرض) ----------
  function sty(c) { return ' style="' + c.replace(/(-?[\d.]+)uu/g, "calc($1 * var(--u))") + '"'; }
  function designHtml(wpx) {
    var d = st.d, t = th(), f = FORMATS[st.format], h = Math.round(wpx * f.r), story = st.format === "story", sq = st.format === "square", k = st.kind;
    var root = '<div class="dz" style="position:relative;width:' + wpx + "px;height:" + h + "px;--u:" + (wpx / 100) + "px;overflow:hidden;background:" + t.bg + ";color:" + t.f + ';direction:rtl;text-align:right;font-family:Cairo,Tahoma,Arial,sans-serif;box-sizing:border-box">';
    var deco = "<div" + sty("position:absolute;left:-12uu;top:-12uu;width:40uu;height:40uu;border-radius:50%;background:" + t.a + ";opacity:.15") + "></div><div" + sty("position:absolute;right:-14uu;bottom:-14uu;width:46uu;height:46uu;border-radius:50%;background:" + t.a + ";opacity:.1") + "></div>";
    var pad = "position:absolute;top:0;right:0;bottom:0;left:0;display:flex;flex-direction:column;justify-content:center;padding:" + (story ? "9uu 8uu" : "7uu 8uu") + ";box-sizing:border-box;";
    var body = "";
    var photo = d.img ? "<div" + sty("align-self:center;width:" + (k === "card" ? 24 : 26) + "uu;height:" + (k === "card" ? 24 : 26) + "uu;border-radius:50%;overflow:hidden;border:.8uu solid " + t.a + ";margin-bottom:3uu;flex:none") + '><img src="' + d.img + '" alt="" style="width:100%;height:100%;object-fit:cover;display:block"/></div>' : "";
    var bar = "<div" + sty("width:16uu;height:1uu;border-radius:9uu;background:" + t.a + ";margin:2.4uu auto") + "></div>";
    if (k === "poster") {
      body = photo + "<div" + sty("text-align:center;font-size:" + (story ? 10 : 8.6) + "uu;font-weight:900;line-height:1.35") + ">" + e(d.title) + "</div>" + bar +
        "<div" + sty("text-align:center;font-size:3.8uu;font-weight:700;opacity:.92;margin-bottom:" + (story ? 6 : 4) + "uu") + ">" + e(d.subtitle) + "</div>" +
        (d.details || []).map(function (p) { return "<div" + sty("display:flex;gap:2uu;align-items:center;background:" + t.card + ";border-radius:2.4uu;padding:" + (story ? 2.6 : 1.8) + "uu 3uu;margin-bottom:1.8uu;font-size:3.4uu;font-weight:700") + "><span" + sty("color:" + t.a + ";font-weight:900;white-space:nowrap") + ">" + e(p.k) + (p.k ? ":" : "") + "</span><span>" + e(p.v) + "</span></div>"; }).join("") +
        (d.cta ? "<div" + sty("align-self:center;margin-top:" + (story ? 6 : 3.4) + "uu;background:" + t.a + ";color:" + t.ink + ";border-radius:9uu;padding:2uu 7uu;font-size:4uu;font-weight:900;text-align:center") + ">" + e(d.cta) + "</div>" : "") +
        (d.footer ? "<div" + sty("text-align:center;margin-top:3uu;font-size:2.7uu;font-weight:600;opacity:.85") + ">" + e(d.footer) + "</div>" : "");
    } else if (k === "board") {
      body = photo + "<div" + sty("text-align:center;font-size:" + (story ? 8.4 : 7.4) + "uu;font-weight:900;line-height:1.35") + ">" + e(d.title) + "</div>" + (d.subtitle ? "<div" + sty("text-align:center;font-size:3.4uu;font-weight:700;opacity:.9;margin-top:1uu") + ">" + e(d.subtitle) + "</div>" : "") + bar +
        "<div" + sty("display:grid;grid-template-columns:" + (story ? "1fr" : "1fr 1fr") + ";gap:2.4uu") + ">" +
        (d.blocks || []).map(function (b) { return "<div" + sty("background:" + t.card + ";border-radius:2.6uu;padding:2.2uu 2.6uu") + "><div" + sty("font-size:" + (sq ? 5.4 : 6.2) + "uu;line-height:1.2") + ">" + e(b.icon) + "</div><div" + sty("font-size:3.5uu;font-weight:900;color:" + t.a + ";margin:.6uu 0") + ">" + e(b.head) + "</div><div" + sty("font-size:" + (sq ? 2.7 : 3) + "uu;font-weight:600;line-height:1.55") + ">" + e(b.text) + "</div></div>"; }).join("") + "</div>" +
        (d.footer ? "<div" + sty("text-align:center;margin-top:3.4uu;font-size:3.2uu;font-weight:800;color:" + t.a) + ">" + e(d.footer) + "</div>" : "");
    } else {
      body = "<div" + sty("flex:1;border:.9uu solid " + t.a + ";border-radius:3uu;padding:6uu 5uu;display:flex;flex-direction:column;justify-content:center;text-align:center;position:relative") + ">" + photo +
        "<div" + sty("font-size:7uu;line-height:1.2;margin-bottom:1uu") + ">🏅</div><div" + sty("font-size:" + (story ? 9 : 8) + "uu;font-weight:900;color:" + t.a + ";line-height:1.3") + ">" + e(d.title) + "</div>" + bar +
        "<div" + sty("font-size:3.4uu;opacity:.9;font-weight:600") + ">تُمنح إلى</div><div" + sty("font-size:9uu;font-weight:900;line-height:1.35;margin:1uu 0 2uu") + ">" + e(d.name) + "</div>" +
        "<div" + sty("font-size:3.8uu;font-weight:700;line-height:1.6") + ">" + e(d.reason) + "</div><div" + sty("font-size:3.4uu;font-weight:600;opacity:.92;margin-top:2.6uu;line-height:1.6") + ">" + e(d.message) + "</div>" +
        "<div" + sty("display:flex;justify-content:space-between;margin-top:5uu;font-size:3uu;font-weight:700") + "><span>" + e(d.teacher ? "المعلم: " + d.teacher : "") + "</span><span>" + e(d.date) + "</span></div></div>";
    }
    return root + deco + "<div" + sty(pad) + ">" + body + "</div></div>";
  }
  function preview() {
    var box = $("dzPrev"); if (!box || !st.d) return;
    var inner = designHtml(1000), f = FORMATS[st.format], w = box.clientWidth || 340, k = Math.min(1, w / 1000);
    box.style.height = Math.round(1000 * f.r * k) + "px";
    box.innerHTML = '<div style="position:absolute;right:0;top:0;transform-origin:top right;transform:scale(' + k + ')">' + inner + "</div>";
  }
  window.addEventListener("resize", function () { preview(); });

  // ---------- التصدير ----------
  function nameOf() { return ((st.d && st.d.title) || "design").replace(/[\\/:*?"<>|]+/g, " ").trim().slice(0, 50) || "design"; }
  function exportPng() {
    if (!st.d) return;
    var W = 1080, H = Math.round(W * FORMATS[st.format].r), holder = document.createElement("div");
    holder.innerHTML = designHtml(W); var node = holder.firstChild; node.setAttribute("xmlns", "http://www.w3.org/1999/xhtml");
    var xml = new XMLSerializer().serializeToString(node);
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + W + '" height="' + H + '"><foreignObject width="100%" height="100%">' + xml + "</foreignObject></svg>";
    var img = new Image();
    img.onload = function () {
      var c = document.createElement("canvas"); c.width = W; c.height = H; c.getContext("2d").drawImage(img, 0, 0);
      c.toBlob(function (b) {
        if (!b) { toast("تعذر إنشاء الصورة", "warning"); return; }
        var a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = nameOf() + ".png"; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); toast("تم تنزيل الصورة ✓");
      }, "image/png");
    };
    img.onerror = function () { toast("تعذر إنشاء الصورة في هذا المتصفح، استخدم PDF", "warning"); };
    img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
  }
  function exportPdf() {
    if (!st.d) return;
    var old = $("dzFrame"); if (old) old.remove();
    var fr = document.createElement("iframe"); fr.id = "dzFrame"; fr.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0"; document.body.appendChild(fr);
    var hmm = Math.round(210 * FORMATS[st.format].r), dd = fr.contentDocument; dd.open();
    dd.write('<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>' + e(nameOf()) + '</title><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet"><style>@page{size:210mm ' + hmm + "mm;margin:0}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}html,body{margin:0;padding:0}</style></head><body>" + designHtml(793) + "</body></html>");
    dd.close();
    var done = false, go = function () { if (done) return; done = true; setTimeout(function () { try { fr.contentWindow.focus(); fr.contentWindow.print(); } catch (x) { toast("تعذر فتح نافذة الطباعة", "warning"); } }, 500); };
    fr.onload = go; setTimeout(go, 1500); toast("اختر «حفظ كملف PDF» من نافذة الطباعة");
  }

  // ---------- الحفظ ----------
  function needLogin() {
    if (!cloud()) { toast("الحفظ يحتاج ربط Firebase", "warning"); return true; }
    if (!uid()) { toast("سجّل الدخول بحساب Google لحفظ التصميم", "warning"); if (typeof openGoogleAuthModal === "function") openGoogleAuthModal(); return true; }
    return false;
  }
  function save() {
    if (!st.d || needLogin()) return;
    var u = (window.Cloud && window.Cloud.getStudioUser ? window.Cloud.getStudioUser() : window.Cloud.user), id = st.id || ("d" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6));
    var data = { ownerUid: u.uid, ownerEmail: u.email || "", kind: st.kind, format: st.format, theme: st.theme, topic: st.topic, data: st.d, title: st.d.title || "تصميم", updatedAt: window.Cloud.stamp() };
    if (!st.id) data.createdAt = window.Cloud.stamp();
    window.Cloud.col(COL).doc(id).set(data, { merge: true }).then(function () { st.id = id; st.dirty = false; toast("تم حفظ التصميم ✓"); renderEditor(); loadMine(); },
      function (err) { toast(err && err.code === "permission-denied" ? "لا صلاحية: انشر قواعد Firestore الجديدة" : "تعذر الحفظ", "warning"); });
  }
  function loadMine() {
    var box = $("dzMine"); if (!box) return;
    if (!cloud() || !uid()) { box.innerHTML = '<p class="text-[11px] text-slate-500">سجّل الدخول لترى تصاميمك المحفوظة.</p>'; return; }
    window.Cloud.col(COL).where("ownerUid", "==", uid()).get().then(function (snap) {
      var l = snap.docs.map(function (x) { return Object.assign({ id: x.id }, x.data()); });
      l.sort(function (a, b) { return ((b.updatedAt && b.updatedAt.seconds) || 0) - ((a.updatedAt && a.updatedAt.seconds) || 0); });
      box.innerHTML = l.length ? l.map(function (p) {
        return '<div class="flex items-center gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700"><div class="flex-1 min-w-0"><div class="text-xs font-extrabold truncate">' + e(p.title) + '</div><div class="text-[10px] text-slate-500">' + e(KINDS[p.kind] || "") + " · " + e((FORMATS[p.format] || {}).n || "") + '</div></div><button type="button" data-open="' + p.id + '" class="px-3 py-1.5 rounded-lg bg-brand-600 text-white text-[11px] font-bold">فتح</button><button type="button" data-del="' + p.id + '" class="px-2.5 py-1.5 rounded-lg bg-rose-600 text-white text-[11px] font-bold">حذف</button></div>';
      }).join("") : '<p class="text-[11px] text-slate-500">لا تصاميم محفوظة بعد.</p>';
      box._list = l;
    }, function () { box.innerHTML = '<p class="text-[11px] text-rose-600">تعذر التحميل (تحقق من نشر قواعد Firestore).</p>'; });
  }
  function openSaved(p) {
    st.id = p.id; st.kind = p.kind || "poster"; st.format = p.format || "a4"; st.theme = p.theme || "ocean"; st.topic = p.topic || ""; st.d = norm(st.kind, p.data); st.dirty = false;
    $("dzKind").value = st.kind; $("dzFormat").value = st.format; $("dzTopic").value = st.topic; renderEditor(); $("dzEditor").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  // ---------- المحرر ----------
  function imgFile(file) {
    return new Promise(function (res, rej) {
      var url = URL.createObjectURL(file), im = new Image();
      im.onload = function () {
        var out = "", sizes = [[520, 0.75], [420, 0.62], [320, 0.55]];
        for (var i = 0; i < sizes.length; i++) {
          var s = Math.min(im.width, im.height), c = document.createElement("canvas"); c.width = c.height = Math.min(sizes[i][0], s);
          c.getContext("2d").drawImage(im, (im.width - s) / 2, (im.height - s) / 2, s, s, 0, 0, c.width, c.height); out = c.toDataURL("image/jpeg", sizes[i][1]); if (out.length < 120000) break;
        }
        URL.revokeObjectURL(url); res(out);
      };
      im.onerror = function () { URL.revokeObjectURL(url); rej(new Error("img")); }; im.src = url;
    });
  }
  function field(label, k, v, area) { return '<label class="block text-[11px] font-bold mt-2 mb-1">' + label + "</label>" + (area ? '<textarea data-k="' + k + '" rows="3" class="' + cls + '">' : '<input data-k="' + k + '" value="' + e(v) + '" class="' + cls + '">') + (area ? e(v) + "</textarea>" : ""); }
  function renderEditor() {
    var box = $("dzEditor"); if (!box) return; if (!st.d) { box.innerHTML = ""; return; }
    var d = st.d, b = "px-3 py-2 rounded-xl text-[11px] font-extrabold ", f = "";
    f += field("العنوان", "title", d.title);
    if (st.kind === "poster") f += field("العنوان الفرعي", "subtitle", d.subtitle) + field("التفاصيل (كل سطر: العنوان: القيمة)", "details", (d.details || []).map(function (p) { return p.k + ": " + p.v; }).join("\n"), true) + field("زر الدعوة", "cta", d.cta) + field("سطر التواصل", "footer", d.footer);
    else if (st.kind === "board") f += field("العنوان الفرعي", "subtitle", d.subtitle) + field("الكتل (كل سطر: رمز | عنوان | نص)", "blocks", (d.blocks || []).map(function (x) { return x.icon + " | " + x.head + " | " + x.text; }).join("\n"), true) + field("السطر الختامي", "footer", d.footer);
    else f += field("اسم الطالب", "name", d.name) + field("سبب التكريم", "reason", d.reason) + field("العبارة التشجيعية", "message", d.message) + field("المعلم", "teacher", d.teacher) + field("التاريخ", "date", d.date);
    box.innerHTML = '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700 p-4 sm:p-5 space-y-3 text-right"><div class="flex flex-wrap gap-1.5 items-center">' +
      '<button type="button" id="dzSave" class="' + b + 'bg-emerald-600 text-white">💾 حفظ' + (st.dirty ? " •" : "") + '</button><button type="button" id="dzPng" class="' + b + 'bg-sky-600 text-white">🖼 تنزيل PNG</button><button type="button" id="dzPdf" class="' + b + 'bg-red-700 text-white">📄 PDF</button></div>' +
      '<div class="flex flex-wrap gap-1.5 items-center text-[11px] font-bold"><span>القالب:</span>' + THEMES.map(function (t) { return '<button type="button" data-th="' + t.id + '" class="px-2.5 py-1 rounded-lg border-2 ' + (t.id === st.theme ? "border-brand-500" : "border-transparent") + '" style="background:' + t.bg + ";color:" + t.f + '">' + t.n + "</button>"; }).join("") + "</div>" +
      '<div class="grid grid-cols-1 lg:grid-cols-2 gap-4"><div class="min-w-0"><div id="dzPrev" class="relative w-full rounded-2xl overflow-hidden shadow-lg border border-slate-300 dark:border-slate-700"></div></div><div class="min-w-0">' + f +
      '<div class="mt-3 p-2.5 rounded-xl border border-dashed border-slate-300 dark:border-slate-600"><div class="text-[11px] font-black mb-1.5">🖼 صورة دائرية (شعار أو صورة طالب)</div>' + (d.img ? '<img src="' + e(d.img) + '" alt="" class="w-16 h-16 rounded-full object-cover mb-2 border">' : "") +
      '<div class="flex flex-wrap gap-1.5"><label class="px-3 py-2 rounded-xl bg-emerald-600 text-white text-[11px] font-extrabold cursor-pointer">📷 كاميرا<input id="dzImgCam" type="file" accept="image/*" capture="environment" class="hidden"></label><label class="px-3 py-2 rounded-xl bg-sky-600 text-white text-[11px] font-extrabold cursor-pointer">🖼 من الجوال<input id="dzImgPick" type="file" accept="image/*" class="hidden"></label>' + (d.img ? '<button type="button" id="dzImgDel" class="px-3 py-2 rounded-xl bg-rose-600 text-white text-[11px] font-extrabold">حذف</button>' : "") + "</div></div></div></div></div>";
    preview();
    $("dzSave").onclick = save; $("dzPng").onclick = exportPng; $("dzPdf").onclick = exportPdf;
    box.querySelectorAll("[data-th]").forEach(function (x) { x.onclick = function () { st.theme = x.dataset.th; st.dirty = true; renderEditor(); }; });
    box.querySelectorAll("[data-k]").forEach(function (el) {
      el.oninput = function () {
        var k = el.dataset.k, v = el.value;
        if (k === "details") d.details = v.split("\n").map(function (l) { var i = l.indexOf(":"); return i < 0 ? { k: "", v: l.trim() } : { k: l.slice(0, i).trim(), v: l.slice(i + 1).trim() }; }).filter(function (p) { return p.k || p.v; }).slice(0, 5);
        else if (k === "blocks") d.blocks = v.split("\n").map(function (l) { var p = l.split("|"); return { icon: (p[0] || "").trim() || "⭐", head: (p[1] || "").trim(), text: (p.slice(2).join("|") || "").trim() }; }).filter(function (x) { return x.head || x.text; }).slice(0, 6);
        else d[k] = v;
        st.dirty = true; preview();
      };
    });
    function pick(ev) { var fl = ev.target.files && ev.target.files[0]; ev.target.value = ""; if (!fl) return; imgFile(fl).then(function (u) { d.img = u; st.dirty = true; renderEditor(); }, function () { toast("تعذر قراءة الصورة", "warning"); }); }
    $("dzImgCam").onchange = pick; $("dzImgPick").onchange = pick; if ($("dzImgDel")) $("dzImgDel").onclick = function () { d.img = ""; st.dirty = true; renderEditor(); };
  }

  // ---------- بناء القسم ----------
  function build() {
    if ($("designStudio")) return true;
    var anchor = $("lessonPlanStudio") || $("worksheetStudio") || $("slidesStudio") || $("teacherTools") || $("aiStudio");
    if (!anchor) return false;
    var s = document.createElement("section"); s.id = "designStudio"; s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4"><div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-fuchsia-600 via-rose-700 to-slate-900 text-white"><div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1"><i class="fa-solid fa-palette"></i>مولّد الإنفوغرافيك والبوسترات</div><h2 class="text-xl sm:text-2xl font-black">بوستر أو لوحة تعليمية أو بطاقة شكر جاهزة للمشاركة</h2><p class="text-xs text-white/80 mt-1">صف ما تريد بجملة، فيكتب الذكاء الاصطناعي النص ويصمّمه بالعربية. تنزيل صورة PNG لواتساب وفيسبوك أو PDF للطباعة.</p></div>' +
      '<div class="p-5 sm:p-6 space-y-3 text-right"><div class="grid grid-cols-1 sm:grid-cols-2 gap-3"><div><label class="block text-xs font-bold mb-1">نوع التصميم</label><select id="dzKind" class="' + cls + '">' + Object.keys(KINDS).map(function (k) { return '<option value="' + k + '">' + KINDS[k] + "</option>"; }).join("") + '</select></div>' +
      '<div><label class="block text-xs font-bold mb-1">المقاس</label><select id="dzFormat" class="' + cls + '">' + Object.keys(FORMATS).map(function (k) { return '<option value="' + k + '">' + FORMATS[k].n + "</option>"; }).join("") + "</select></div></div>" +
      '<div><label class="block text-xs font-bold mb-1">صف التصميم المطلوب</label><textarea id="dzTopic" rows="3" maxlength="1500" class="' + cls + '" placeholder="مثال: إعلان ورشة تدريبية عن الذكاء الاصطناعي للمعلمين، السبت الساعة 10 صباحاً في خان يونس — أو: لوحة عن مراحل دورة الماء — أو: بطاقة شكر للطالب أحمد على التزامه"></textarea></div>' +
      '<div class="flex flex-wrap items-center gap-2"><button id="dzGo" type="button" class="px-6 py-3 rounded-xl bg-gradient-to-l from-fuchsia-600 to-rose-600 text-white text-xs font-black shadow-md flex items-center gap-2"><i class="fa-solid fa-wand-magic-sparkles"></i><span>صمّم</span></button><span id="dzStat" class="text-[11px] font-bold text-slate-500"></span></div></div></div>' +
      '<div id="dzEditor"></div><div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700 p-4 sm:p-5 text-right"><div class="flex items-center justify-between mb-2"><h3 class="text-sm font-black">📁 تصاميمي المحفوظة</h3><button type="button" id="dzReload" class="text-[11px] font-bold text-brand-600">تحديث</button></div><div id="dzMine" class="space-y-2"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    $("dzGo").onclick = generate;
    $("dzFormat").onchange = function () { st.format = $("dzFormat").value; if (st.d) { st.dirty = true; renderEditor(); } };
    $("dzKind").onchange = function () { st.kind = $("dzKind").value; };
    $("dzReload").onclick = loadMine;
    $("dzMine").addEventListener("click", function (ev) {
      var o = ev.target.closest("[data-open]"), x = ev.target.closest("[data-del]"), l = $("dzMine")._list || [];
      if (o) { var p = l.filter(function (q) { return q.id === o.dataset.open; })[0]; if (p) openSaved(p); }
      if (x && window.eduConfirm("حذف هذا التصميم نهائياً؟")) window.Cloud.col(COL).doc(x.dataset.del).delete().then(function () { if (st.id === x.dataset.del) st.id = ""; loadMine(); toast("تم الحذف"); }, function () { toast("تعذر الحذف", "warning"); });
    });
    loadMine();
    
    return true;
  }
  window.EduDesigns = { state: st, html: designHtml, openId: function (id) { return window.Cloud.col(COL).doc(id).get().then(function (d) { if (d.exists) openSaved(Object.assign({ id: id }, d.data())); }); } };
  function init() { if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

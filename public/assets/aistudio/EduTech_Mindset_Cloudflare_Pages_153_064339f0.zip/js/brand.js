/*
 * هوية الموقع على كل المطبوعات والملفات — EduTech Mindset | عقلية التعليم والتكنولوجيا | إدارة الأستاذ باسل أشرف الفقعاوي
 * يضيف تلقائياً علامة مائية + ترويسة + تذييل لأي صفحة طباعة/PDF أو ملف Word تنتجه أي أداة،
 * دون الحاجة لتعديل كل أداة على حدة (يعترض document.write و Blob من نوع msword).
 */
(function () {
  "use strict";
  if (window.EduBrand) return;
  var SITE = "EduTech Mindset", SUB = "عقلية التعليم والتكنولوجيا", MGR = "إدارة الأستاذ باسل أشرف الفقعاوي";
  var MARK = "edu-brand-v153";
  var CSS = "<style id='" + MARK + "'>" +
    "@page{margin:14mm 12mm 16mm}" +
    ".eb-wm{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-35deg);text-align:center;color:#0c4a6e;opacity:.07;font-family:Cairo,Tahoma,Arial,sans-serif;font-weight:900;line-height:1.1;pointer-events:none;z-index:0;white-space:nowrap}" +
    ".eb-wm b{display:block;font-size:84px}.eb-wm i{display:block;font-style:normal;font-size:34px}.eb-wm u{display:block;text-decoration:none;font-size:24px}" +
    ".eb-head{direction:rtl;font:700 11px Cairo,Tahoma,Arial,sans-serif;color:#0c4a6e;border-bottom:2px solid #f59e0b;padding:0 0 5px;margin:0 0 10px;display:flex;justify-content:space-between;gap:8px}" +
    ".eb-foot{direction:rtl;font:600 10px Cairo,Tahoma,Arial,sans-serif;color:#64748b;text-align:center;border-top:1px solid #cbd5e1;padding-top:5px;margin-top:18px}" +
    "@media print{.eb-wm{position:fixed}}</style>";
  var WM = "<div class='eb-wm' aria-hidden='true'><b>" + SITE + "</b><i>" + SUB + "</i><u>" + MGR + "</u></div>";
  var HEAD = "<div class='eb-head'><span>" + SITE + " — " + SUB + "</span><span>" + MGR + "</span></div>";
  var FOOT = "<div class='eb-foot'>" + SITE + " • " + SUB + " • " + MGR + "</div>";

  function brand(html) {
    if (typeof html !== "string" || html.indexOf(MARK) !== -1) return html;
    if (!/<body[\s>]/i.test(html) || !/<\/body>/i.test(html)) return html;           // ليست صفحة كاملة
    if (/<title>\s*(?:اختبار إلكتروني للطلاب)/.test(html)) return html;
    html = /<\/head>/i.test(html) ? html.replace(/<\/head>/i, CSS + "</head>") : html.replace(/<body/i, CSS + "<body");
    html = html.replace(/<body([^>]*)>/i, function (m) { return m + WM + HEAD; });
    html = html.replace(/<\/body>/i, FOOT + "</body>");
    return html;
  }

  // 1) document.write للنوافذ وإطارات الطباعة
  function wrap(orig) { return function () { var a = Array.prototype.slice.call(arguments); if (a.length === 1 && typeof a[0] === "string") a[0] = brand(a[0]); return orig.apply(this, a); }; }
  function patchRealm(win) {
    try {
      var P = win && win.Document && win.Document.prototype;
      if (!P || P.__eduBrand) return;
      var w0 = P.write, l0 = P.writeln;
      P.write = wrap(w0); P.writeln = wrap(l0);
      Object.defineProperty(P, "__eduBrand", { value: true });
    } catch (e) {}
  }
  patchRealm(window);
  // الإطارات والنوافذ الجديدة لها Document.prototype خاص بها: نعالجه عند أول وصول إليها
  ["contentWindow", "contentDocument"].forEach(function (k) {
    var d = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, k);
    if (!d || !d.get) return;
    Object.defineProperty(HTMLIFrameElement.prototype, k, { configurable: true, enumerable: d.enumerable, get: function () {
      var v = d.get.call(this); try { patchRealm(k === "contentWindow" ? v : (v && v.defaultView)); } catch (e) {} return v;
    } });
  });
  var wo = window.open;
  window.open = function () { var w = wo.apply(window, arguments); try { patchRealm(w); } catch (e) {} return w; };

  // 2) ملفات Word المبنية بصيغة HTML
  var NativeBlob = window.Blob;
  window.Blob = function (parts, opts) {
    try {
      if (opts && /msword|ms-word/i.test(opts.type || "") && parts && parts.length) {
        var all = parts.map(function (p) { return typeof p === "string" ? p : null; });
        if (all.every(function (p) { return p !== null; })) {
          var bom = "";
          var joined = all.join("");
          if (joined.charCodeAt(0) === 0xFEFF) { bom = "\ufeff"; joined = joined.slice(1); }
          var b = brand(joined);
          if (b !== joined) parts = [bom + b];
        }
      }
    } catch (e) {}
    return new NativeBlob(parts, opts);
  };
  window.Blob.prototype = NativeBlob.prototype;
  Object.setPrototypeOf(window.Blob, NativeBlob);

  // 3) طباعة الصفحة نفسها (window.print) — علامة مائية وتذييل
  var st = document.createElement("style");
  st.textContent = "@media print{body::before{content:'" + SITE + "  •  " + SUB + "  •  " + MGR + "';position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-35deg);font:900 42px Cairo,Tahoma,Arial,sans-serif;color:#0c4a6e;opacity:.06;white-space:nowrap;pointer-events:none;z-index:9999}" +
    "body::after{content:'" + SITE + " • " + SUB + " • " + MGR + "';position:fixed;bottom:4mm;left:0;right:0;text-align:center;font:600 10px Cairo,Tahoma,Arial,sans-serif;color:#64748b}}";
  document.head.appendChild(st);

  window.EduBrand = { brand: brand, site: SITE, sub: SUB, manager: MGR };
})();

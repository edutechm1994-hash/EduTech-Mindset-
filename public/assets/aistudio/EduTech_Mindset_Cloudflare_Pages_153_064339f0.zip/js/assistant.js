/*
 * «مساعدي» — المساعد الحواري البشري الذكي وصانع الـ PDF الفوري لـ EduTech Mindset (الإصدار 153 الشامل)
 * بإشراف وتطوير: الأستاذ باسل أشرف الفقعاوي — مؤسس ومدير EduTech Mindset
 *
 * المميزات الكبرى في الإصدار 151:
 *   1) ✥ تحريك حر لزر المساعد العائم (#eduAsstOrb) ونافذة المساعد (#eduAsst) في أي مكان على شاشة الجوال أو الكمبيوتر:
 *      - اسحب زر المساعد بإصبعك على الجوال لأي زاوية أو مكان يناسبك دون تحريك الصفحة خلفه (touch-action: none)، ويحفظ مكانه تلقائياً.
 *      - اسحب شريط عنوان نافذة المساعد لتحريكها على الشاشة أو بدّل موضعها (أسفل / أعلى / عائم حر) بضغطة زر.
 *   2) 📷 كاميرا ورفع صور المسائل والدفاتر داخل المحادثة:
 *      - صوّر أي مسألة أو صفحة دفتر أو كتاب مباشرة من داخل «مساعدي» ليقرأها ويحلّها معك صوتياً ويحول الحل لملف PDF.
 *   3) 🎙️👥 وضع «الحوار الصوتي الثنائي (البودكاست الحي)» بين شخصيتين:
 *      - استمع لحوار تفاعلي ناطق بين معلمَين من فريق EduTech Mindset (مثل أ. باسل والمعلمة بيان، أو المعلمة صابرين والطالب يزن) يشرحان الدرس معاً.
 *   4) 📖 الربط المباشر بتظليل النصوص وقارئ الكتب:
 *      - ظلّل أي فقرة في الموقع أو الكتب لتظهر كبسولة ذكية: (💬 ناقش مع مساعدي | 📄 حوّل لملف PDF | 🎙️👥 حوار ثنائي).
 *   5) 🧠 الذاكرة التراكمية التشخيصية + 📊 مخططات مفاهيمية مرسومة داخل الـ PDF + قوالب امتحان توجيهي وزاري وبطاقة ولي الأمر + مشاركة PDF للجوال.
 */
(function () {
  "use strict";
  if (window.EduAssistant) return;

  var $ = function (id) { return document.getElementById(id); };
  var esc = function (v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  };
  var now = function () { return Date.now(); };
  var dayKey = function (d) {
    d = d || new Date();
    return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
  };
  function toast(m, t) {
    try { if (typeof showToast === "function") showToast(m, t || "info"); } catch (e) {}
  }

  // ------------------------------------------------------------------ 1) الشخصيات الحوارية البشرية الخمس
  var PERSONAS = [
    {
      id: "basel",
      name: "أ. باسل الفقعاوي",
      fullName: "الأستاذ باسل أشرف الفقعاوي",
      role: "مؤسس ومدير EduTech Mindset • مستشارك التربوي والتقني",
      ico: "👨‍🏫",
      voiceId: "ar_hamed",
      lang: "ar-SA",
      pitch: 0.96,
      rate: 1.0,
      color: "#0284c7",
      partnerId: "bayan",
      stylePrompt: "تحدث بشخصية الأستاذ باسل أشرف الفقعاوي (مؤسس ومدير مبادرة EduTech Mindset في فلسطين): قائد تربوي دافئ، ملهم، عملي، خبير في تكنولوجيا التعليم والذكاء الاصطناعي والتوجيهي الفلسطيني. حاور المستخدم كزميل ومعلم قريب من القلب، خذ وأعطِ معه في الكلام، واختم دائماً بسؤال تفاعلي لطيف يفتح أفق الحوار.",
      welcome: "يا هلا بك! معك أخوك باسل الفقعاوي من استوديو EduTech Mindset. يمكنك سحب زرّي ووضعه في أي مكان يريحك على شاشة الجوال! احكيلي شو شاغل بالك اليوم؟ نصوّر مسألة نحلها، نسمع حواراً ثنائياً، ولا نجهز ملف PDF جاهز للتحميل؟"
    },
    {
      id: "bayan",
      name: "المعلمة بيان",
      fullName: "المعلمة بيان — خبيرة اللغة العربية",
      role: "معلمة اللغة العربية والنحو والإعراب والتشكيل",
      ico: "👩‍🏫",
      voiceId: "ar_zariyah",
      lang: "ar-SA",
      pitch: 1.05,
      rate: 0.97,
      color: "#4f46e5",
      partnerId: "basel",
      stylePrompt: "تحدثي بشخصية المعلمة بيان (معلمة اللغة العربية في فريق EduTech Mindset): فصحى مشرقة، دافئة، واضحة، محبة للغة العربية. اشرحي قواعد النحو والإعراب والإملاء والبلاغة بأمثلة مشكولة، وحاوري المستخدم بلطف واختمي بسؤال تفاعلي شيق.",
      welcome: "أَهْلاً وَسَهْلاً بِكَ! أَنَا المُعَلِّمَةُ بَيَان. يَسْعَدُنِي أَنْ نَتَحَاوَرَ مَعاً، أَوْ نُعْرِبَ الجُمَلَ وَنَضْبِطَ النُّصُوصَ بِالتَّشْكِيلِ، وَنُجَهِّزَ لَكَ مَلَفَّاتِ PDF مُتْقَنَةً بِالمُخَطَّطَاتِ البَصَرِيَّةِ. عَمَّ تَوَدُّ أَنْ نَتَحَدَّثَ اليَوْمَ؟"
    },
    {
      id: "sabreen",
      name: "المعلمة صابرين",
      fullName: "المعلمة صابرين أمين — خبيرة الرياضيات والفيزياء",
      role: "معلمة الرياضيات والمنطق والفيزياء",
      ico: "📐",
      voiceId: "ar_salma",
      lang: "ar-EG",
      pitch: 1.02,
      rate: 0.98,
      color: "#d97706",
      partnerId: "yazan",
      stylePrompt: "تحدثي بشخصية المعلمة صابرين أمين (معلمة الرياضيات والفيزياء في فريق EduTech Mindset): مشجعة، صبورة، تحول أصعب المعادلات والقوانين الفيزيائية والرياضية إلى خطوات منطقية بسيطة وواضحة مع التحقق من الحل. خذي وأعطي مع الطالب أو المعلم واختمي بسؤال ذكي.",
      welcome: "مرحباً بك يا بطل! أنا المعلمة صابرين أمين. يمكنك الآن تصوير أي مسألة من دفترك بالكاميرا وسأحلها معك خطوة بخطوة وأجهزها لك كملف PDF! بأي درس تحب نبدأ؟"
    },
    {
      id: "layan",
      name: "المعلمة ليان",
      fullName: "المعلمة ليان (Teacher Layan) — اللغة الإنجليزية",
      role: "مدربة المحادثة وقواعد اللغة الإنجليزية",
      ico: "🌍",
      voiceId: "ar_sana",
      enVoiceId: "en_aria",
      lang: "ar-JO",
      pitch: 1.03,
      rate: 0.98,
      color: "#e11d48",
      partnerId: "basel",
      stylePrompt: "تحدثي بشخصية المعلمة ليان (Teacher Layan — معلمة اللغة الإنجليزية في EduTech Mindset): ودودة، تمزج بين العربية المبسطة والعبارات الإنجليزية الواضحة مع ترجمتها، تشرح القواعد (Grammar, Tenses, Writing) وتدرب المستخدم على المحادثة الإنجليزية بثقة. اختمي دائماً بسؤال حواري لطيف.",
      welcome: "Hello and welcome! أهلاً بك، أنا المعلمة ليان. سواء كنت تريد ممارسة المحادثة بالإنجليزية، فهم قواعد التوجيهي، أو تجهيز ورقة عمل PDF، أنا هنا لأحاورك وأساعدك. What would you like to start with today?"
    },
    {
      id: "yazan",
      name: "الزميل يزن",
      fullName: "الطالب الذكي يزن — رفيق المذاكرة",
      role: "زميلك الذكي للمذاكرة والتسميع وتنظيم الوقت",
      ico: "👦",
      voiceId: "ar_student_male",
      lang: "ar-SA",
      pitch: 1.12,
      rate: 1.03,
      color: "#059669",
      partnerId: "sabreen",
      stylePrompt: "تحدث بشخصية الطالب الذكي يزن (زميل الدراسة النشيط في EduTech Mindset): حماسي، إيجابي، يتحدث بروح الزمالة القريبة من القلب، يساعد في التسميع السقراطي، تلخيص الدروس، وتنظيم وقت المذاكرة والبومودورو. خذ وأعطِ مع صديقك واختم بسؤال حماسي.",
      welcome: "أهلاً يا صديقي البطل! أنا زميلك يزن. جاهز ندرس مع بعض، نسمع حواراً ثنائياً ممتعاً، أو أجهزلك ملخص PDF مرتب تراجع منه؟ قول لي شو المادة اللي فاتحها الآن!"
    }
  ];

  function getPersona(id) {
    var pid = id || (D && D.persona) || "basel";
    return PERSONAS.filter(function (p) { return p.id === pid; })[0] || PERSONAS[0];
  }

  // ------------------------------------------------------------------ 2) هوية المستخدم والتخزين والمزامنة والذاكرة التشخيصية
  function who() {
    try {
      var u = (typeof getCurrentUser === "function" && getCurrentUser()) ||
        (window.EduAccessControl && window.EduAccessControl.getCurrentUser && window.EduAccessControl.getCurrentUser()) || null;
      if (u && (u.email || u.name)) return { id: String(u.email || u.name).toLowerCase(), name: String(u.name || "").trim() };
    } catch (e) {}
    return { id: "guest", name: "" };
  }
  function firstName() {
    var n = who().name;
    return n ? n.replace(/^(أ\.|الأستاذ|الأستاذة|د\.|م\.)\s*/, "").split(/\s+/)[0] : "";
  }
  var KEY = function () { return "edu_asst_v1:" + who().id; };
  var D = null, DKEY = "";

  function blank() {
    return {
      tasks: [],
      notes: [],
      chat: [],
      favs: [],
      log: {},
      habits: [
        { id: "h1", t: "💧 شرب الماء بانتظام", days: {} },
        { id: "h2", t: "📖 قراءة ومراجعة 20 دقيقة", days: {} },
        { id: "h3", t: "🎯 حل 5 أسئلة استدعاء نشط", days: {} },
        { id: "h4", t: "🌙 نوم مبكر وتركيز هادئ", days: {} }
      ],
      count: null,
      voice: true,
      persona: "basel",
      orbPos: null,       // { xPct, yPct, edge } موقع زر المساعد الحر على الشاشة
      magSnap: true,      // الالتصاق المغناطيسي والاختفاء الجزئي على الجوال
      panelDock: "bottom", // "bottom" | "top" | "float"
      panelPos: null,     // { xPct, yPct } عند الوضع العائم الحر
      memoryTopics: [],   // الذاكرة التراكمية التشخيصية للدروس التي سأل عنها المستخدم
      mistakes: [],       // بنك أخطائي التراكمي لتوليد ملف PDF علاجي مخصص
      xp: 20,             // نقاط التحفيز والأوسمة داخل المساعد
      eyeCare: false,     // وضع القراءة الدافئة وتكبير الخط
      counts: [],         // عدادات الامتحانات المتعددة
      classRoster: ["أحمد", "سارة", "محمد", "ليان", "عمر", "نور"],
      quizzes: {},        // حالة بطاقات الاختبار التفاعلي والتسميع السقراطي داخل الدردشة
      pdfDraft: {
        tpl: "summary",
        title: "ملخص قوانين نيوتن للحركة والقصور الدوراني",
        grade: "الثاني عشر (التوجيهي العلمي)",
        subject: "الفيزياء",
        teacher: "",
        school: "",
        body: ""
      }
    };
  }

  function load() {
    var k = KEY();
    if (D && DKEY === k) return D;
    try { D = JSON.parse(localStorage.getItem(k) || "null"); } catch (e) { D = null; }
    D = Object.assign(blank(), D || {});
    if (!D.pdfDraft || typeof D.pdfDraft !== "object") D.pdfDraft = blank().pdfDraft;
    if (!Array.isArray(D.memoryTopics)) D.memoryTopics = [];
    if (!D.quizzes || typeof D.quizzes !== "object") D.quizzes = {};
    if (!Array.isArray(D.mistakes)) D.mistakes = [];
    if (!Array.isArray(D.counts)) D.counts = [];
    if (!Array.isArray(D.classRoster)) D.classRoster = ["أحمد", "سارة", "محمد", "ليان", "عمر", "نور"];
    if (typeof D.xp !== "number") D.xp = 20;
    if (typeof D.eyeCare !== "boolean") D.eyeCare = false;
    if (typeof D.magSnap !== "boolean") D.magSnap = true;
    if (typeof D.voice !== "boolean") D.voice = true;
    if (!D.persona) D.persona = "basel";
    if (!D.panelDock) D.panelDock = "bottom";
    DKEY = k;
    return D;
  }

  function save() {
    if (D) D.mod = now();
    try { localStorage.setItem(KEY(), JSON.stringify(D)); } catch (e) {
      toast("المساحة ممتلئة، صدّر بياناتك ثم امسح القديم", "warning");
    }
    schedulePush();
  }

  // تسجيل موضوع في الذاكرة التراكمية التشخيصية
  function rememberTopic(rawText) {
    var t = String(rawText || "").replace(/^(?:اشرح لي|جهز لي|اعمل لي|ما هو|ما هي|كيف|لخص|ورقة عمل|ملف pdf|نسخة pdf|عن|حول|درس)\s+/gi, "").trim();
    if (t.length < 4 || t.length > 75 || /^(مرحبا|اهلا|كيف حالك|كم الساعه|مهامي|ركز)/.test(norm(t))) return;
    load();
    D.memoryTopics = D.memoryTopics.filter(function (x) { return norm(x.t) !== norm(t); });
    D.memoryTopics.unshift({ t: t.slice(0, 55), at: now(), p: D.persona });
    D.memoryTopics = D.memoryTopics.slice(0, 8);
    save();
  }

  // مزامنة السحابة عبر Firestore (assistant/{uid})
  var syncTimer = null, pulled = {};
  function fsDoc() {
    try {
      var C = window.Cloud, u = C && C.user;
      if (!C || !C.realAuth || !u || !u.uid || typeof firebase === "undefined") return null;
      return { ref: firebase.firestore().collection("assistant").doc(u.uid), uid: u.uid };
    } catch (e) { return null; }
  }
  function payload() {
    var c = JSON.parse(JSON.stringify(D || {}));
    delete c.chat;
    c.notes = (c.notes || []).slice(0, 250);
    return { v: 1, json: JSON.stringify(c), updatedAt: (D && D.mod) || now() };
  }
  function schedulePush() {
    if (!fsDoc()) return;
    clearTimeout(syncTimer);
    syncTimer = setTimeout(function () {
      var f = fsDoc();
      if (f && D) f.ref.set(payload()).catch(function () {});
    }, 4000);
  }
  function pullOnce() {
    var f = fsDoc();
    if (!f || pulled[f.uid]) return;
    pulled[f.uid] = 1;
    f.ref.get().then(function (snap) {
      load();
      if (!snap.exists) { f.ref.set(payload()).catch(function () {}); return; }
      var r = snap.data(), remote = null;
      try { remote = JSON.parse(r.json); } catch (e) {}
      if (!remote) return;
      if ((r.updatedAt || 0) > (D.mod || 0)) {
        var chat = D.chat;
        D = Object.assign(blank(), remote, { chat: chat, mod: r.updatedAt });
        try { localStorage.setItem(KEY(), JSON.stringify(D)); } catch (e) {}
        applyOrbPosition();
        if (isOpen()) render();
        toast("تمت مزامنة بيانات «مساعدي» من حسابك ☁️", "success");
      } else if ((D.mod || 0) > (r.updatedAt || 0)) {
        f.ref.set(payload()).catch(function () {});
      }
    }).catch(function () { pulled[f.uid] = 0; });
  }
  setInterval(pullOnce, 5000);
  function uid() { return Math.random().toString(36).slice(2, 9); }

  // ------------------------------------------------------------------ 3) البحث في الأدوات وتطبيع اللغة
  function norm(s) {
    return String(s || "").toLowerCase()
      .replace(/[ً-ٰٟـ]/g, "")
      .replace(/[أإآٱ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه").replace(/ؤ/g, "و").replace(/ئ/g, "ي")
      .replace(/[^ء-يa-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
  }
  var STOP = {};
  ("افتح شغل شغّل ابدا ابدأ اريد ارغب ممكن لو سمحت من فضلك لي لنا انا اعمل اعمللي اعطني اعطيني ورني اظهر اذهب روح الى الي على في عن مع هذا هذه ده دي اداه اداة اريدك بدي بدنا حضر حضّر انشئ انشي اصنع اصنعلي سوي سويلي").split(/\s+/).forEach(function (w) { STOP[norm(w)] = 1; });
  var SYN = { عرض: "عروض", امتحان: "اختبار", امتحانات: "اختبارات", تحضير: "خطه", ملصق: "ملصقات", شهاده: "شهادات", لعبه: "العاب", قصه: "قصص", ترجمه: "لغات", رسم: "تصميم", بوربوينت: "عروض", سبوره: "سبوره", واجب: "واجبات", سيره: "سيره", ورقه: "اوراق", ورقة: "اوراق", اوراق: "اوراق" };

  function apps() { return (window.EduLauncher && window.EduLauncher.apps) || []; }
  function visibleApps() {
    var out = apps();
    try {
      if (window.EduAccessControl && window.EduAccessControl.evaluateToolAccess) {
        out = out.filter(function (a) {
          var r = window.EduAccessControl.evaluateToolAccess(a.id);
          return r && r.reason !== "guest_blocked" && r.reason !== "user_blocked" && r.reason !== "user_suspended" || (r && r.allowed);
        });
      }
    } catch (e) {}
    return out;
  }
  var IDF = null, IDF_N = 0;
  function buildIdf() {
    var list = visibleApps();
    if (IDF && IDF_N === list.length) return;
    IDF = {}; IDF_N = list.length;
    list.forEach(function (a) {
      var seen = {};
      (norm(a.title) + " " + norm(a.desc) + " " + norm(a.badge)).split(" ").forEach(function (w) {
        if (w.length > 1 && !seen[w]) { seen[w] = 1; IDF[w] = (IDF[w] || 0) + 1; }
      });
    });
  }
  function searchTools(q, limit) {
    var toks = norm(q).split(" ").filter(function (t) { return t.length > 1 && !STOP[t]; }).map(function (t) { return SYN[t] || t; });
    if (!toks.length) return [];
    buildIdf();
    var phrase = toks.join(" "), res = [];
    visibleApps().forEach(function (a) {
      var title = norm(a.title).replace(/(^| )ال/g, "$1"), hay = title + " " + norm(a.desc) + " " + norm(a.badge);
      var s = 0;
      toks.forEach(function (t) {
        var hit = title.indexOf(t) !== -1 ? 3 : (hay.indexOf(t) !== -1 ? 1 : 0);
        if (hit) s += hit * (1 + Math.log((IDF_N + 1) / ((IDF[t] || 0) + 1)) / 2);
      });
      if (toks.length > 1 && title.indexOf(phrase) !== -1) s += 6;
      else if (toks.length > 1 && hay.indexOf(phrase) !== -1) s += 3;
      if (s > 0) res.push({ a: a, s: Math.round(s * 10) / 10 });
    });
    res.sort(function (x, y) { return y.s - x.s; });
    return res.slice(0, limit || 5);
  }
  function openTool(id) {
    try {
      if (window.EduLauncher) {
        window.EduLauncher.jump(id, true);
        closePanel();
        return true;
      }
    } catch (e) {}
    return false;
  }
  function appById(id) {
    return apps().filter(function (a) { return a.id === id; })[0] || { id: id, title: id, ico: "🧰" };
  }

  // ------------------------------------------------------------------ 4) التاريخ والتحية ومؤقت التركيز
  function greeting() {
    var h = new Date().getHours();
    var g = h < 5 ? "ليلة طيبة" : h < 12 ? "صباح الخير" : h < 17 ? "طاب يومك" : h < 21 ? "مساء الخير" : "مساء النور";
    var n = firstName();
    return g + (n ? " يا " + n : "") + " 👋";
  }
  function dateLine() {
    try {
      var d = new Date();
      var g = new Intl.DateTimeFormat("ar", { weekday: "long", day: "numeric", month: "long" }).format(d);
      var h = new Intl.DateTimeFormat("ar-SA-u-ca-islamic-umalqura", { day: "numeric", month: "long", year: "numeric" }).format(d);
      return g + " • " + h;
    } catch (e) { return new Date().toLocaleDateString("ar"); }
  }

  var T = { total: 25 * 60, left: 25 * 60, run: false, tick: null, endAt: 0 };
  function fmt(s) { s = Math.max(0, Math.round(s)); return ("0" + Math.floor(s / 60)).slice(-2) + ":" + ("0" + (s % 60)).slice(-2); }
  function timerStart(min) {
    if (min) { T.total = T.left = Math.max(1, Math.min(180, min)) * 60; }
    if (T.run) return;
    T.run = true; T.endAt = now() + T.left * 1000;
    T.tick = setInterval(function () {
      T.left = Math.max(0, Math.round((T.endAt - now()) / 1000));
      paintTimer();
      if (T.left <= 0) timerDone();
    }, 500);
    paintTimer();
  }
  function timerPause() {
    if (!T.run) return;
    clearInterval(T.tick); T.run = false;
    T.left = Math.max(0, Math.round((T.endAt - now()) / 1000));
    paintTimer();
  }
  function timerReset() { clearInterval(T.tick); T.run = false; T.left = T.total; paintTimer(); }
  function beep() {
    try {
      var C = window.AudioContext || window.webkitAudioContext;
      if (!C) return;
      var c = new C(), t = c.currentTime;
      [660, 880, 1100].forEach(function (f, i) {
        var o = c.createOscillator(), g = c.createGain();
        o.frequency.value = f; o.connect(g); g.connect(c.destination);
        g.gain.setValueAtTime(0.0001, t + i * 0.22);
        g.gain.exponentialRampToValueAtTime(0.25, t + i * 0.22 + 0.03);
        g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.22 + 0.2);
        o.start(t + i * 0.22); o.stop(t + i * 0.22 + 0.22);
      });
    } catch (e) {}
  }
  function timerDone() {
    clearInterval(T.tick); T.run = false;
    var mins = Math.round(T.total / 60);
    load(); D.log[dayKey()] = (D.log[dayKey()] || 0) + mins; save();
    T.left = T.total; paintTimer(); beep();
    toast("🎉 أحسنت! أنهيت جلسة تركيز " + mins + " دقيقة. خذ استراحة قصيرة!", "success");
    try {
      if ("Notification" in window && Notification.permission === "granted") {
        new Notification("مساعدي — EduTech Mindset", { body: "انتهت جلسة التركيز (" + mins + " دقيقة) بنجاح 🎉", icon: "assets/icon-192.png" });
      }
    } catch (e) {}
    if (D && UI.tab === "day") paintDay();
  }

  // ------------------------------------------------------------------ 5) المهام والملاحظات والعادات
  function addTask(text, star) {
    text = String(text || "").trim(); if (!text) return null;
    load();
    var t = { id: uid(), t: text.slice(0, 200), done: false, star: !!star, at: now() };
    D.tasks.unshift(t); save();
    if (UI.tab === "day") paintDay();
    return t;
  }
  function purgeTasks() {
    load();
    var cut = now() - 2 * 86400000;
    D.tasks = D.tasks.filter(function (t) { return !t.done || (t.doneAt || now()) > cut; });
  }
  function addNote(text) {
    text = String(text || "").trim(); if (!text) return null;
    load();
    var n = { id: uid(), t: text.slice(0, 3000), at: now() };
    D.notes.unshift(n); D.notes = D.notes.slice(0, 250); save();
    if (UI.tab === "day") paintDay();
    return n;
  }
  function streak(h) {
    var n = 0, d = new Date();
    if (!h.days[dayKey(d)]) d.setDate(d.getDate() - 1);
    while (h.days[dayKey(d)]) { n++; d.setDate(d.getDate() - 1); }
    return n;
  }
  function parseDateStr(s) {
    var m = String(s || "").match(/(\d{4})-(\d{2})-(\d{2})/); if (!m) return null;
    var d = new Date(+m[1], +m[2] - 1, +m[3]); return isNaN(d) ? null : d;
  }
  function daysLeft(iso) {
    var d = parseDateStr(iso); if (!d) return null;
    var t = new Date(); t.setHours(0, 0, 0, 0); return Math.round((d - t) / 86400000);
  }

  // ------------------------------------------------------------------ 6) الكاميرا وإرفاق صور المسائل والدفاتر داخل «مساعدي» (الإصدار 151)
  var chatAttachments = []; // [{ mime, data, thumb, name }]

  function shrinkChatImage(file) {
    return new Promise(function (res, rej) {
      var url = URL.createObjectURL(file), im = new Image();
      im.onload = function () {
        var k = Math.min(1, 1400 / Math.max(im.width, im.height));
        var c = document.createElement("canvas");
        c.width = Math.max(1, Math.round(im.width * k));
        c.height = Math.max(1, Math.round(im.height * k));
        var cx = c.getContext("2d");
        cx.fillStyle = "#ffffff";
        cx.fillRect(0, 0, c.width, c.height);
        cx.drawImage(im, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        var t = document.createElement("canvas");
        t.width = 72;
        t.height = Math.max(1, Math.round(72 * c.height / c.width));
        t.getContext("2d").drawImage(c, 0, 0, t.width, t.height);
        res({
          mime: "image/jpeg",
          data: c.toDataURL("image/jpeg", 0.82).split(",")[1],
          thumb: t.toDataURL("image/jpeg", 0.65),
          name: file.name || "صورة_مسألة.jpg"
        });
      };
      im.onerror = function () { URL.revokeObjectURL(url); rej(new Error("img")); };
      im.src = url;
    });
  }

  function handleChatFiles(fileList) {
    var files = Array.prototype.slice.call(fileList || []);
    if (!files.length) return;
    files.reduce(function (p, f) {
      return p.then(function () {
        if (chatAttachments.length >= 4) { toast("الحد الأقصى 4 صور في الرسالة الواحدة", "info"); return; }
        if (/^image\//.test(f.type)) {
          return shrinkChatImage(f).then(function (item) { chatAttachments.push(item); }).catch(function () { toast("تعذر قراءة الصورة", "warning"); });
        } else if (f.type === "application/pdf" || /\.pdf$/i.test(f.name)) {
          if (f.size > 8 * 1024 * 1024) { toast("حجم ملف PDF كبير (الحد 8MB)", "warning"); return; }
          return new Promise(function (res) {
            var r = new FileReader();
            r.onload = function () {
              chatAttachments.push({ mime: "application/pdf", data: String(r.result).split(",")[1], thumb: "", name: f.name });
              res();
            };
            r.onerror = function () { res(); };
            r.readAsDataURL(f);
          });
        }
      });
    }, Promise.resolve()).then(function () {
      paintAttachmentStrip();
      toast("📷 تم إرفاق الصورة — اكتب سؤالك أو اضغط إرسال ليقرأها المساعد ويحلها!", "success");
    });
  }

  function paintAttachmentStrip() {
    var el = $("eaAttStrip");
    if (!el) return;
    if (!chatAttachments.length) {
      el.style.display = "none";
      el.innerHTML = "";
      return;
    }
    el.style.display = "flex";
    el.innerHTML = chatAttachments.map(function (a, i) {
      return '<div class="ea-att-item">' +
        (a.thumb ? '<img src="' + a.thumb + '" alt="مرفق">' : '<span style="font-size:18px">📄</span>') +
        '<span class="ea-att-name">' + esc(a.name || "صورة") + '</span>' +
        '<button type="button" class="ea-att-rm" data-rm-att="' + i + '" aria-label="إزالة">✕</button>' +
      '</div>';
    }).join("");
  }

  // ------------------------------------------------------------------ 7) محرك توليد الـ PDF الجاهز للتحميل والعقل التربوي المدمج (8 قوالب شاملة)
  var PDF_TEMPLATES = [
    { id: "summary", label: "📘 ملخص درس شامل + خريطة مفاهيمية", badge: "ملخص + مخطط بصري + أمثلة" },
    { id: "worksheet", label: "📝 ورقة عمل متمايزة (تأسيسي ومتقدم)", badge: "جاهزة للطباعة مع الحل" },
    { id: "tawjihi_exam", label: "🎓 نموذج امتحان توجيهي وزاري رسمي", badge: "موقوت + توزيع الدرجات والحل" },
    { id: "quiz", label: "🎯 اختبار قصير وفق هرم بلوم", badge: "10 أسئلة + نموذج الإجابة" },
    { id: "lesson5e", label: "📋 خطة درس تفاعلية (نموذج 5E)", badge: "تحضير معلم متكامل" },
    { id: "parent_card", label: "👨‍👩‍👧 بطاقة متابعة طالب لولي الأمر", badge: "تقرير تربوي + توصيات منزلية" },
    { id: "comparison", label: "⚖️ بطاقة مقارنة بصرية (مفهومان وجهاً لوجه)", badge: "أوجه الشبه والاختلاف" },
    { id: "radio", label: "🎙️ برنامج إذاعة مدرسية متكامل (PDF + إلقاء)", badge: "مقدمة + كلمة + هل تعلم + مسابقة" },
    { id: "comic", label: "📖 قصة حوارية مصوّرة للتأسيس (1–6)", badge: "حوار مشكول للتأسيس" },
    { id: "parent_msg", label: "✉️ رسالة تربوية احترافية لولي الأمر", badge: "جاهزة لواتساب والطباعة" },
    { id: "bilingual", label: "🌍 بطاقة مفردات وقراءة ثنائية اللغة (AR/EN)", badge: "للمدارس والتوجيهي" },
    { id: "studyplan", label: "🗓️ جدول وخطة مذاكرة وتفوق", badge: "تنظيم الوقت والتوجيهي" },
    { id: "chatlog", label: "💬 توثيق وتلخيص محادثتنا الحالية", badge: "سجل الحوار + الفوائد" }
  ];

  function buildOfflineDocumentMarkdown(tplId, topic, grade, subject, persona) {
    var p = persona || getPersona();
    var tp = String(topic || "موضوع الدرس").trim();
    var gr = String(grade || "الثاني عشر (التوجيهي)").trim();
    var sb = String(subject || "العلوم والرياضيات").trim();
    var n = norm(tp);

    if (tplId === "chatlog") {
      load();
      if (!D.chat.length) {
        return "# سجل الحوار التعليمي — مساعدي الذكي\n\n> **المحاور:** " + p.fullName + "  |  **التاريخ:** " + dateLine() + "\n\nلم تبدأ المحادثة بعد. اطرح أي سؤال في تبويب «💬 حواري» ثم صدّره هنا كملف PDF منسّق!";
      }
      var out = ["# توثيق الحوار التعليمي — مساعدي الذكي", "", "[مخطط: خلاصة حوارنا التعليمي | فهم المفاهيم | الأمثلة المحلولة | التسميع الذاتي | خطة التطبيق]", "", "> **المحاور:** " + p.fullName + "  |  **المستخدم:** " + (firstName() || "طالب/معلم") + "  |  **التاريخ:** " + dateLine(), ""];
      D.chat.forEach(function (m, idx) {
        var clean = String(m.raw || m.t || "").replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").trim();
        if (!clean) return;
        if (m.r === "u") {
          out.push("## 🙋‍♂️ مداخلتي / سؤالي (" + (Math.floor(idx / 2) + 1) + ")");
          out.push("> " + clean.replace(/\n+/g, " "));
          out.push("");
        } else {
          out.push("### ✨ رد «مساعدي» (" + (m.pName || p.name) + ")");
          out.push(clean);
          out.push("", "---", "");
        }
      });
      return out.join("\n");
    }

    
    if (tplId === "comparison") {
      return [
        "# بطاقة المقارنة البصرية — " + tp,
        "",
        "[مخطط: مقارنة " + tp.slice(0, 28) + " | المفهوم الأول | المفهوم الثاني | أوجه التشابه | الفروق الجوهرية]",
        "",
        "> **المادة:** " + sb + "  |  **الصف:** " + gr + "  |  **إشراف:** " + p.fullName,
        "",
        "## ⚖️ جدول المقارنة المرجعي السريع",
        "| وجه المقارنة | العنصر / المفهوم الأول | العنصر / المفهوم الثاني |",
        "|---|---|---|",
        "| التعريف والماهية | يمثل الحالة أو القاعدة الأولى في درس «" + tp + "» | يمثل الحالة المقابلة أو المكملة له في السياق |",
        "| الوظيفة / القانون | يطبق عند توفر الشرط الأولي المباشر | يطبق عند تغير المعطيات أو انتقال الحالة |",
        "| مثال تطبيقي من المنهاج | مثال قياسي واضح ومضبوط بالشكل | مثال تطبيقي مقابل يوضح الفرق بدقة |",
        "",
        "## 🤝 أوجه التشابه ونقاط الالتقاء",
        "- يشترك المفهومان في كونهما ركيزتين أساسيتين لفهم وحدة «" + tp + "» في المنهاج الفلسطيني.",
        "- كلاهما يعتمد على تحديد الدلالات والمعطيات أولاً قبل إصدار الحكم أو التعويض.",
        "",
        "> **سؤال تثبيت سريع:** اذكر فرقاً واحداً جوهرياً بينهما بأسلوبك!"
      ].join("\n");
    }

    if (tplId === "radio") {
      return [
        "# 🎙️ برنامج الإذاعة المدرسية الصباحية — " + tp,
        "",
        "[مخطط: فقرات الإذاعة المدرسية | المقدمة والقرآن | الحديث الشريف | كلمة الصباح | هل تعلم | مسابقة الطلبة]",
        "",
        "> **الموضوع:** " + tp + "  |  **المرحلة:** " + gr + "  |  **إعداد:** " + p.fullName + " (EduTech Mindset)",
        "",
        "## 1️⃣ المقدمة الإذاعية (المقدم)",
        "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ، مُدِيرُنَا الفَاضِلُ، مُعَلِّمُونَا الأَفَاضِلُ، زُمَلَائِي الطَّلَبَةَ؛ السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُهُ. يُسْعِدُنَا اليَوْمَ أَنْ نُقَدِّمَ لَكُمْ إِذَاعَتَنَا الصَّبَاحِيَّةَ حَوْلَ: **«" + tp + "»**.",
        "",
        "## 2️⃣ فقرة القرآن الكريم والحديث الشريف",
        "- **آية كريمة:** قَالَ تَعَالَى: ﴿يَرْفَعِ اللَّهُ الَّذِينَ آمَنُوا مِنكُمْ وَالَّذِينَ أُوتُوا الْعِلْمَ دَرَجَاتٍ﴾.",
        "- **حديث شريف:** «مَنْ سَلَكَ طَرِيقاً يَلْتَمِسُ فِيهِ عِلْماً سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقاً إِلَى الجَنَّةِ».",
        "",
        "## 3️⃣ كلمة الصباح المركّزة",
        "إِنَّ مَوْضُوعَ **«" + tp + "»** يَدْعُونَا جَمِيعاً إِلَى الإِتْقَانِ وَالِاجْتِهَادِ وَتَوْظِيفِ المَعْرِفَةِ وَالتِّكْنُولُوجْيَا فِي بِنَاءِ مُسْتَقْبَلِ وَطَنِنَا فِلَسْطِينَ بِالعِلْمِ وَالأَخْلَاقِ.",
        "",
        "## 4️⃣ فقرة «هَلْ تَعْلَمُ؟» والمسابقة السريعة",
        "- **هَلْ تَعْلَمُ** أَنَّ المُرَاجَعَةَ النَّشِطَةَ لِمُدَّةِ 20 دَقِيقَةً يَوْمِيّاً تَرْفَعُ ثَبَاتَ المَعْلُومَةِ فِي الذَّاكِرَةِ بِنِسْبَةِ كَبِيرَةٍ؟",
        "- **سُؤَالُ المُسَابَقَةِ لِلطَّلَبَةِ:** مَا الفِكْرَةُ الأَسَاسِيَّةُ الَّتِي اسْتَفَدْتَهَا مِنْ مَوْضُوعِ «" + tp + "» اليَوْمَ؟"
      ].join("\n");
    }

    if (tplId === "comic") {
      return [
        "# 📖 القصة الحوارية التعليمية (للتأسيس والاستيعاب) — " + tp,
        "",
        "[مخطط: مشاهد القصة التعليمية | المشهد 1: التساؤل | المشهد 2: الاكتشاف | المشهد 3: القاعدة الذهبية | المشهد 4: التطبيق]",
        "",
        "> **المادة:** " + sb + "  |  **الفئة:** " + gr + "  |  **إعداد:** " + p.fullName,
        "",
        "## 🎭 المشهد الأول: في مكتبة المدرسة",
        "- **توتة:** مرحباً يا رفاق! واجهتُ صعوبة صغيرة في فهم درس **«" + tp + "»** اليوم، هل تساعدونني؟",
        "- **روبة:** بالتأكيد يا توتة! السرّ بسيط جداً، تعالي نكتشف القاعدة معاً خطوة بخطوة.",
        "",
        "## 💡 المشهد الثاني: لحظة الاكتشاف",
        "- **هاها:** انظرا! عندما نطبق القاعدة بالترتيب الصحيح، تصبح النتيجة واضحة وممتعة كاللعبة!",
        "- **المعلمة بيان:** أحسنتم يا أبطالي! القاعدة الذهبية تقول: اقرأ المثال جيداً، حدد المطلوب، ثم طبق بثقة.",
        "",
        "## 🎯 المشهد الثالث: التحدي الصغير",
        "- **سؤال القصة:** هل تستطيع الآن كتابة مثال واحد من إبداعك حول «" + tp + "» وتقرأه بصوتٍ جميل؟"
      ].join("\n");
    }

    if (tplId === "parent_msg") {
      return [
        "# ✉️ رسالة تربوية لولي الأمر — " + tp,
        "",
        "> **إعداد المعلم/ـة:** " + p.fullName + "  |  **الصف:** " + gr + "  |  **المادة:** " + sb,
        "",
        "## نص الرسالة الجاهزة للإرسال (واتساب / تليجرام / مطبوعة)",
        "السلام عليكم ورحمة الله وبركاته، ولي الأمر الفاضل، تحية طيبة وبعد:",
        "",
        "نود إطلاعكم بكل تقدير على مستوى ابنكم/ابنتكم في موضوع **«" + tp + "»**؛ حيث لمسنا لديه تفاعلاً طيباً وقدرة واعدة على الفهم والتحصيل.",
        "",
        "نرجو منكم التكرم بمتابعته خلال هذا الأسبوع في **مراجعة الأمثلة المحلولة لمدة 15 دقيقة يومياً** وحل ورقة العمل المرفقة، وسنكون سعداء جداً بتواصلكم المستمر معنا لدعم تفوقه بإذن الله.",
        "",
        "مع خالص الاحترام والتقدير،",
        "**فريق EduTech Mindset التعليمي**"
      ].join("\n");
    }

    if (tplId === "bilingual") {
      return [
        "# 🌍 بطاقة المفردات والقراءة ثنائية اللغة (AR / EN) — " + tp,
        "",
        "[مخطط: Bilingual Study Sheet | Key Vocabulary | Grammar & Usage | Context Examples | Quick Self-Test]",
        "",
        "> **Level:** " + gr + "  |  **Prepared by:** " + p.fullName + " (EduTech Mindset)",
        "",
        "## 📚 أولاً: جدول المصطلحات والمفردات الأساسية",
        "| Word / Term | المعنى بالعربية | Context Example (مثال تطبيقي) |",
        "|---|---|---|",
        "| Innovation & Technology | الابتكار والتكنولوجيا | Educational technology makes learning interactive and clear. |",
        "| Consistency | الاستمرارية والمثابرة | Consistency is the secret to achieving high grades in Tawjihi. |",
        "| Analyze & Apply | يحلّل ويطبّق | Students analyze the problem before applying the formula. |",
        "| Achievement | الإنجاز والتفوق | Every small step leads to a remarkable achievement. |",
        "",
        "## ✍️ ثانياً: نص قراءة قصير للممارسة (Reading Practice)",
        "> *\"Modern Palestinian students combine strong determination with smart digital tools to master " + tp + " and build a bright future.\"*",
        "",
        "- **الترجمة الميسّرة:** يجمع الطلبة الفلسطينيون بين العزيمة القوية والأدوات الرقمية الذكية لإتقان هذا الموضوع وبناء مستقبل مشرق."
      ].join("\n");
    }

    if (tplId === "parent_card") {
      return [
        "# بطاقة متابعة وتقدم الطالب لولي الأمر — " + tp,
        "",
        "[مخطط: محاور متابعة الطالب | الالتزام والحضور | إتقان المهارات | الواجبات والأنشطة | خطة الدعم المنزلي]",
        "",
        "> **الصف/المرحلة:** " + gr + "  |  **المادة:** " + sb + "  |  **إشراف:** " + p.fullName + " (EduTech Mindset)",
        "",
        "## 📊 أولاً: تقييم الأداء الأكاديمي والسلوكي",
        "| المعيار التربوي | مستوى الإتقان | الملاحظات التشخيصية والتعزيز |",
        "|---|---|---|",
        "| استيعاب المفاهيم الأساسية | ممتاز (90%+) | يشارك بفاعلية ويظهر فهماً واضحاً للقاعدة الأساسية |",
        "| حل الواجبات وأوراق العمل | جيد جداً | ينجز المهام في وقتها مع الحاجة لمراجعة خطوة التحقق |",
        "| التفاعل الصفي والتركيز | متميز | يتعاون مع زملائه ويطرح أسئلة ذكية أثناء الحصة |",
        "",
        "## 💡 ثانياً: توصيات عملية لولي الأمر في المنزل",
        "- **تخصيص جلسة مراجعة قصيرة (20 دقيقة يومياً):** استخدام مؤقت البومودورو في «مساعدي» لمراجعة درس اليوم بعيداً عن المشتتات.",
        "- **التسميع بالحوار (الاستدعاء النشط):** اطلب من ابنك/ابنتك شرح الفكرة الأساسية للدرس بأسلوبه الخاص خلال دقيقتين.",
        "- **تعزيز الثقة والدافعية:** الإشادة بالجهد المبذول والتقدم المستمر قبل التركيز على الدرجات النهائية.",
        "",
        "> **رسالة شكر من " + p.fullName + ":** نشكر تعاونكم البنّاء مع مدرسة ومنصة EduTech Mindset في دعم تفوق أبنائنا في فلسطين."
      ].join("\n");
    }

    var coreBullets = [];
    var tableRows = [];
    var examples = [];
    var questions = [];
    var diagramLine = "[مخطط: " + tp.slice(0, 32) + " | المفهوم والقاعدة | القوانين والعلاقات | خطوات الحل | التطبيق والتقويم]";

    if (/نيوتن|حركه|فيزياء|دوران|قصور|زخم|كهرباء|مواسع|تيار|مغناطيس/.test(n)) {
      diagramLine = "[مخطط: " + tp.slice(0, 30) + " | القوة والعزم (ΣF, Στ) | الزخم الخطي والزاوي | قوانين الحفظ والاتزان | المسائل التطبيقية]";
      coreBullets = [
        "**المفهوم الفيزيائي الأساسي:** يربط درس «" + tp + "» بين القوة المؤثرة ومعدل تغير الحالة الحركية أو الدورانية للنظام الفيزيائي وفق قوانين الحفظ.",
        "**القانون الرياضي المحوري:** القوة المحصلة $\\Sigma F = m \\cdot a = \\Delta p / \\Delta t$، وفي الحركة الدورانية العزم المحصل $\\Sigma \\tau = I \\cdot \\alpha$.",
        "**شروط الاتزان والحفظ:** يحفظ الزخم الخطي عندما تكون محصلة القوى الخارجية صفراً، ويحفظ الزخم الزاوي ($L = I \\cdot \\omega$) عند انعدام العزم الخارجي."
      ];
      tableRows = [
        "| الكمية الفيزيائية | الرمز والعلاقة الرياضية | وحدة القياس (SI) | ملاحظة تطبيقية للامتحان |",
        "|---|---|---|---|",
        "| القوة المحصلة / العزم | ΣF = m·a  أو  τ = r·F·sinθ | N  أو  N·m | انتبه للزاوية بين متجه الموضع والقوة |",
        "| الزخم الخطي / الزاوي | p = m·v  أو  L = I·ω | kg·m/s  أو  kg·m²/s | محفوظ في التصادمات والأنظمة المعزولة |",
        "| الطاقة الحركية | K = ½ m·v²  أو  Kr = ½ I·ω² | Joule (J) | تحسب بالسرعة الزاوية بالراديان/ثانية |"
      ];
      examples = [
        "**مثال محلول (1):** جسم كتلته 4 kg يتأثر بقوة محصلة مقدارها 20 N لمدة 3 ثوانٍ. احسب التسارع والتغير في الزخم الخطي.\n  - **الحل:** التسارع $a = F / m = 20 / 4 = 5\\text{ m/s}^2$. التغير في الزخم (الدفع) $\\Delta p = F \\cdot \\Delta t = 20 \\times 3 = 60\\text{ N}\\cdot\\text{s}$.",
        "**مثال محلول (2):** قرص عزمه الدوراني $I = 2\\text{ kg}\\cdot\\text{m}^2$ أثر عليه عزم دوران $10\\text{ N}\\cdot\\text{m}$. ما تسارعه الزاوي؟\n  - **الحل:** $\\alpha = \\tau / I = 10 / 2 = 5\\text{ rad/s}^2$."
      ];
      questions = [
        "1. **[فهم واستيعاب — 4 علامات]** علّل: يضمّ المتزلج ذراعيه إلى صدره عندما يريد زيادة سرعة دورانه حول نفسه.",
        "2. **[تطبيق حسابي — 6 علامات]** احسب الزخم الخطي لسيارة كتلتها 1200 kg تتحرك بسرعة 15 m/s شرقاً، وما مقدار القوة اللازمة لإيقافها خلال 6 ثوانٍ؟",
        "3. **[تفكير عليا — 5 علامات]** قارن بين القصور الذاتي الانتقالي والقصور الدوراني من حيث العوامل التي يعتمد عليها كل منهما."
      ];
    } else if (/رياضيات|معادل|كسر|كسور|مشتق|تكامل|اقتران|فيثاغورس|هندس|مصفوف|احتمال/.test(n)) {
      diagramLine = "[مخطط: " + tp.slice(0, 30) + " | تحليل المعطيات | الصيغة القياسية | التعويض والتبسيط | التحقق من الجذور]";
      coreBullets = [
        "**القاعدة الرياضية الأساسية:** يعتمد موضوع «" + tp + "» على ترتيب العمليات الجبرية وتحليل العلاقة بين المتغيرات بدقة للوصول إلى الحل الأبسط.",
        "**خطوات الحل القياسية:** (1) فهم المعطيات وتحديد المطلوب، (2) كتابة القانون أو الصيغة القياسية، (3) التعويض والتبسيط، (4) التحقق من معقولية الناتج.",
        "**الأخطاء الشائعة وكيفية تجنبها:** الانتباه لإشارات الحدود عند النقل بين طرفي المعادلة، وتوحيد المقامات قبل جمع أو طرح الكسور."
      ];
      tableRows = [
        "| المفهوم / القاعدة | الصيغة الرياضية القياسية | خطوة التحقق السريعة |",
        "|---|---|---|",
        "| المعادلة التربيعية | أ س² + ب س + جـ = 0 (المميز Δ = ب² - 4أ جـ) | مجموع الجذرين = -ب/أ ، وحاصل ضربهما = جـ/أ |",
        "| المشتقة والقيم القصوى | f'(x) = 0 عند النقاط الحرجة | نختبر إشارة f'(x) حول النقطة الحرجة أو f''(x) |",
        "| نظرية فيثاغورس والمسافة | الوتر² = ضلع₁² + ضلع₂² | الوتر هو الضلع الأطول المقابل للزاوية القائمة دائماً |"
      ];
      examples = [
        "**مثال تطبيقي (1):** حل المعادلة $x^2 - 7x + 12 = 0$ وتحقق من صحة الجذور.\n  - **الحل:** نبحث عن عددين حاصل ضربهما 12 ومجموعهما 7 وهما (3 و 4): $(x - 3)(x - 4) = 0 \\Rightarrow x = 3$ أو $x = 4$. التحقق: $3^2 - 7(3) + 12 = 0$ ✓.",
        "**مثال تطبيقي (2):** أوجد القيمة العظمى المحلية للاقتران $f(x) = 6x - x^2$.\n  - **الحل:** نشتق ونساوي بالصفر: $f'(x) = 6 - 2x = 0 \\Rightarrow x = 3$. وبما أن $f''(x) = -2 < 0$ توجد قيمة عظمى عند $x = 3$ ومقدارها $f(3) = 9$."
      ];
      questions = [
        "1. **[تأسيسي — 5 علامات]** بسّط المقدار الجبري التالي وأوجد قيم المتغير التي تجعله يساوي صفراً.",
        "2. **[متوسط — 5 علامات]** أوجد معادلة المماس لمنحنى الاقتران عند النقطة المعطاة، مبيناً خطوات الاشتقاق بالتفصيل.",
        "3. **[تحدي وتميز — 5 علامات]** مسألة لفظية حياتية: حديقة مستطيلة الشكل محيطها 40 متراً، أوجد أبعادها لتكون مساحتها أكبر ما يمكن."
      ];
    } else if (/عربي|نحو|اعراب|إعراب|بلاغ|همز|تاء|الف|ألف|كان|ان|إن|فاعل|مبتدأ|قصيد|شعر/.test(n)) {
      diagramLine = "[مخطط: " + tp.slice(0, 30) + " | الموقع الإعرابي | العلامات الأصلية والفرعية | الضبط والتشكيل | الجماليات البلاغية]";
      coreBullets = [
        "**القاعدة اللغوية والنحوية:** يرتكز درس «" + tp + "» على فهم الوظيفة الإعرابية للكلمة داخل السياق وتمييز الحركات الأصلية والفرعية.",
        "**الضبط والتشكيل الصحيح:** حركة أواخر الكلمات تتبع موقعها الإعرابي (الرفع للفاعل والمبتدأ والخبر، النصب للمفاعيل والحال، والجر للاسم المجرور والمضاف إليه).",
        "**التذوق البلاغي والبياني:** ربط القاعدة النحوية بجماليات المعنى في النصوص القرآنية والشعرية والأدبية في المنهاج الفلسطيني."
      ];
      tableRows = [
        "| الباب النحوي / الإملائي | القاعدة الضابطة باختصار | مثال تطبيقي مشكول |",
        "|---|---|---|",
        "| كان وأخواتها (أفعال ناسخة) | ترفع المبتدأ (اسمها) وتنصب الخبر (خبرها) | كَانَ العِلْمُ نُوراً سَاطِعاً |",
        "| إنّ وأخواتها (حروف ناسخة) | تنصب المبتدأ (اسمها) وترفع الخبر (خبرها) | إِنَّ الصَّبْرَ مِفْتَاحُ الفَرَجِ |",
        "| التاء المربوطة والمبسوطة | المربوطة تنطق هاءً عند الوقف، والمبسوطة تنطق تاءً وصلاً ووقفاً | مَدْرَسَةٌ جَمِيلَةٌ / بَيْتُ المَقْدِسِ |"
      ];
      examples = [
        "**نموذج إعرابي مفصّل:** أعرب جملة: «يَبْنِي المُعَلِّمُونَ الأَجْيَالَ بِإِخْلَاصٍ»:\n  - **يَبْنِي:** فعل مضارع مرفوع وعلامة رفعه الضمة المقدرة على الياء للثقل.\n  - **المُعَلِّمُونَ:** فاعل مرفوع وعلامة رفعه الواو لأنه جمع مذكر سالم.\n  - **الأَجْيَالَ:** مفعول به منصوب وعلامة نصبه الفتحة الظاهرة على آخره."
      ];
      questions = [
        "1. **[ضبط وتشكيل — 5 علامات]** اضبط أواخر الكلمات في العبارة الآتية بالشكل التام مع بيان السبب.",
        "2. **[إعراب واستخراج — 5 علامات]** استخرج من النص: فعلاً مضارعاً معرباً بعلامة فرعية، ومضافاً إليه، وصورة بيانية وبيّن سر جمالها.",
        "3. **[تعبير تطبيقي — 5 علامات]** صغ ثلاث جمل مفيدة من إنشائك توظف فيها قاعدة «" + tp + "» في سياق الحديث عن العلم والوطن."
      ];
    } else {
      coreBullets = [
        "**الفكرة المحورية للدرس:** يتناول موضوع «" + tp + "» المفاهيم الأساسية والعلاقات التطبيقية المقررة في المنهاج الفلسطيني لمرحلة " + gr + ".",
        "**الربط بالحياة العملية:** توظيف المعرفة النظرية في تفسير الظواهر اليومية وحل المشكلات بأسلوب علمي منهجي.",
        "**مفاتيح الإتقان والاستذكار:** تلخيص الأفكار في خريطة مفاهيمية، والتدرب على أسئلة الاستدعاء النشط والتفكير الناقد."
      ];
      tableRows = [
        "| المحور الأساسي | التوضيح العلمي والتربوي | تطبيق عملي / مثال |",
        "|---|---|---|",
        "| المفهوم والتعريف | تحديد ماهية «" + tp + "» وخصائصه المميزة بدقة | ربط المفهوم بمثال مباشر من الكتاب المدرسي |",
        "| الآلية والخطوات | تسلسل العمليات أو العوامل المؤثرة في الظاهرة | تتبع المخطط الانسيابي خطوة بخطوة |",
        "| النتيجة والتقويم | الأثر النهائي أو الاستنتاج العلمي المستخلص | الإجابة عن أسئلة علّل وقارن وماذا يحدث لو |"
      ];
      examples = [
        "**مثال تطبيقي مشروح:** كيف نطبق مفهوم «" + tp + "» في موقف عملي؟\n  - نبدأ بتحليل عناصر الموقف، ثم نربط كل عنصر بالقاعدة العلمية المناسبة، ونستنتج النتيجة مدعمة بالتعليل الدقيق."
      ];
      questions = [
        "1. **[تذكر وفهم — 5 علامات]** عرّف المقصود بـ «" + tp + "» واذكر ثلاثة من أهم خصائصه أو عوامله.",
        "2. **[تطبيق وتحليل — 5 علامات]** علّل تعليلاً علمياً دقيقاً العلاقة بين المتغيرات الواردة في الدرس.",
        "3. **[تقويم وإبداع — 5 علامات]** ماذا يحدث لو تغيرت الظروف الأساسية للعملية؟ اقترح حلاً أو تطبيقاً عملياً من بيئتك."
      ];
    }

    if (tplId === "tawjihi_exam") {
      return [
        "# امتحان تجريبي وزاري موقوت (نموذج التوجيهي الفلسطيني) — " + tp,
        "",
        diagramLine,
        "",
        "> **المبحث:** " + sb + "  |  **الفرع:** " + gr + "  |  **الزمن:** 45 دقيقة  |  **مجموع العلامات:** 30 علامة  |  **إشراف:** " + p.fullName,
        "",
        "## 📌 القسم الأول: أسئلة الاختيار من متعدد (10 علامات — علامتان لكل فقرة)",
        "1. **أي العلاقات أو القواعد التالية تمثل الأساس العلمي المباشر لدرس «" + tp + "»؟**\n   - (أ) العلاقة الطردية المنتظمة وفق القانون القياسي ✓\n   - (ب) ثبات المتغيرات بغض النظر عن المؤثر الخارجي\n   - (ج) التناسب العكسي التربيعي في جميع الحالات\n   - (د) انعدام الأثر الناتج عند مضاعفة المدخلات",
        "2. **عند مضاعفة العامل الأساسي المؤثر في «" + tp + "» مع ثبات باقي العوامل، فإن النتيجة:**\n   - تتغير وفق المعادلة الحاكمة الموضحة في جدول القوانين أدناه.",
        "",
        tableRows.join("\n"),
        "",
        "## ✍️ القسم الثاني: الأسئلة المقالية والمسائل الحسابية (15 علامة)",
        questions.join("\n"),
        "",
        "## 🌟 القسم الثالث: سؤال التميز والتفكير العليا (5 علامات)",
        examples.join("\n\n"),
        "",
        "---",
        "## ✅ نموذج الإجابة الوزاري المعتمد وتوزيع العلامات",
        "- **توزيع الدرجات:** تُمنح علامتان لكتابة القانون أو القاعدة، و3 علامات للتعويض الصحيح والخطوات، وعلامة لوحدة القياس أو الضبط النحوي السليم."
      ].join("\n");
    }

    if (tplId === "lesson5e") {
      return [
        "# خطة درس تفاعلية (نموذج 5E) — " + tp,
        "",
        "[مخطط: دورة التعلم الخماسية 5E | 1. التهيئة Engage | 2. الاستكشاف Explore | 3. الشرح Explain | 4. التوسع Elaborate | 5. التقويم Evaluate]",
        "",
        "> **المادة:** " + sb + "  |  **الصف/المرحلة:** " + gr + "  |  **إعداد:** " + p.fullName + " (منصة EduTech Mindset)",
        "",
        "## 🎯 أولاً: الأهداف السلوكية (وفق هرم بلوم)",
        "1. **مستوى التذكر والفهم:** أن يوضّح الطالب المفاهيم والقواعد الأساسية لدرس «" + tp + "» بلغته الخاصة بدقة.",
        "2. **مستوى التطبيق والتحليل:** أن يوظّف الطالب القواعد في حل المسائل والمواقف التطبيقية ويميز العلاقات بينها.",
        "3. **مستوى التقويم والإبداع:** أن يصمّم الطالب ملخصاً بصرياً أو يحل مسألة حياتية مرتبطة ببيئته في فلسطين.",
        "",
        "## ⏱️ ثانياً: المخطط الزمني للحصة وفق نموذج (5E) — (45 دقيقة)",
        "| المرحلة (5E) | الزمن | دور المعلم والأنشطة التفاعلية | دور الطالب والتقويم التكويني |",
        "|---|---|---|---|",
        "| 1. التهيئة (Engage) | 5 د | عرض سؤال عصف ذهني أو فيديو موشن جرافيك قصير (9:16) يثير الفضول حول «" + tp + "» | يطرح توقعاته ويربط الموضوع بخبراته السابقة |",
        "| 2. الاستكشاف (Explore) | 10 د | تقسيم الطلبة لمجموعات عمل أو تشغيل محاكي المنصة التفاعلي لاستنتاج القاعدة | يجرب، يلاحظ، ويسجل الملاحظات الأولية في ورقة النشاط |",
        "| 3. الشرح (Explain) | 12 د | تنظيم إجابات الطلبة وتقديم الشرح المنهجي مع الأمثلة المحلولة على السبورة الذكية | يناقش الخطوات ويدوّن الملخص المنظم في دفتره |",
        "| 4. التوسع (Elaborate) | 10 د | طرح مسألة حياتية متقدمة تربط الدرس بالواقع العملي ومراعاة الفروق الفردية | يطبق القاعدة في موقف جديد ويتعاون مع زملائه |",
        "| 5. التقويم (Evaluate) | 8 د | توزيع بطاقة خروج (Exit Ticket) من 3 أسئلة متدرجة وتكليف الواجب البيتي | يجيب فردياً للتحقق من تحقق الأهداف بنسبة 85%+ |",
        "",
        "## 💡 ثالثاً: الخلاصة العلمية والأمثلة المعتمدة في الشرح",
        coreBullets.map(function (b) { return "- " + b; }).join("\n"),
        "",
        "## 📝 رابعاً: أسئلة التقويم الختامي والواجب البيتي",
        questions.join("\n")
      ].join("\n");
    }

    if (tplId === "worksheet" || tplId === "quiz") {
      var isQuiz = tplId === "quiz";
      return [
        "# " + (isQuiz ? "اختبار قصير متدرج (وفق مستويات بلوم) — " : "ورقة عمل تدريبية متمايزة — ") + tp,
        "",
        diagramLine,
        "",
        "> **المادة:** " + sb + "  |  **الصف:** " + gr + "  |  **إشراف:** " + p.fullName + " (EduTech Mindset)",
        "",
        "## 📌 ملخص القواعد الأساسية للمراجعة السريعة قبل الحل",
        coreBullets.map(function (b) { return "- " + b; }).join("\n"),
        "",
        tableRows.join("\n"),
        "",
        "## 🟢 المستوى الأول: أسئلة التأسيس والفهم المباشر",
        "1. **اختر الإجابة الصحيحة مما بين القوسين مع التعليل المختصر:**\n   - يرتبط المفهوم الأساسي في درس «" + tp + "» بتطبيق القاعدة القياسية مباشرة في الحالات المثالية.",
        "2. **أكمل الجدول / الفراغات التالية بما يناسبها علمياً ولغوياً:**\n   - المصطلح الأساسي: ....................  |  العلاقة أو القاعدة: ....................",
        "",
        "## 🟡 المستوى الثاني: أسئلة التطبيق والتحليل (المستوى المعياري)",
        examples.join("\n\n"),
        "",
        "## 🔴 المستوى الثالث: أسئلة التميز والتفكير الناقد",
        questions.join("\n"),
        "",
        "---",
        "## ✅ مفتاح الإجابة النموذجية وإرشادات التصحيح الذاتي",
        "- **معيار التصحيح:** يمنح الطالب العلامة الكاملة عند كتابة القانون/القاعدة الصحيحة، خطوات التعويض المتسلسلة، والوحدة أو الضبط الصحيح."
      ].join("\n");
    }

    if (tplId === "studyplan") {
      return [
        "# خطة المذاكرة الذكية وجدول الإنجاز الأسبوعي — " + tp,
        "",
        "[مخطط: منظومة التفوق الدراسي | بومودورو 25/5 د | الاستدعاء النشط | التكرار المتباعد | حل أسئلة وزارية]",
        "",
        "> **إعداد:** " + p.fullName + "  |  **المستهدف:** " + (firstName() || "بطل EduTech Mindset") + " (" + gr + ")",
        "",
        "## 🎯 قواعد المذاكرة الفعّالة (نظام البومودورو والاستدعاء النشط)",
        "- **قاعدة (25 / 5):** ادرس بتركيز تام لمدة 25 دقيقة بعيداً عن المشتتات، ثم خذ استراحة 5 دقائق لتجديد نشاط الدماغ.",
        "- **الاستدعاء النشط (Active Recall):** بعد قراءة كل فقرة، أغلق الكتاب ولخّص ما فهمته بصوتك أو في 3 نقاط دون النظر للنص.",
        "- **التكرار المتباعد:** راجع الملخص بعد 24 ساعة، ثم بعد 3 أيام، ثم في نهاية الأسبوع لترسيخه في الذاكرة طويلة المدى.",
        "",
        "## 🗓️ جدول توزيع الجلسات المقترح",
        "| اليوم / الفترة | الجلسة الأولى (50 د) | الجلسة الثانية (50 د) | جلسة التسميع والتطبيق (30 د) |",
        "|---|---|---|---|",
        "| السبت والأحد | فهم القواعد الأساسية لـ «" + tp + "» | حل أمثلة الكتاب المدرسي | حل 5 أسئلة اختيار من متعدد |",
        "| الاثنين والثلاثاء | التعمق في المسائل المركبة | تلخيص القوانين في ورقة واحدة | تسميع ذاتي وتصحيح الأخطاء |",
        "| الأربعاء والخميس | ربط الوحدات ومراجعة شاملة | حل ورقة عمل متمايزة كاملة | اختبار ذاتي موقوت وتقييم الأداء |",
        "",
        "## 📋 قائمة مهامي الحالية في «مساعدي»",
        (load().tasks.length ? load().tasks.map(function (t) { return "- [" + (t.done ? "✓" : " ") + "] " + t.t + (t.star ? " ⭐" : ""); }).join("\n") : "- أضف مهامك اليومية في تبويب «📅 يومي» لتظهر هنا تلقائياً!")
      ].join("\n");
    }

    // الافتراضي: ملخص درس شامل مع خريطة مفاهيمية
    return [
      "# الملخص الشامل والدليل التطبيقي — " + tp,
      "",
      diagramLine,
      "",
      "> **المادة:** " + sb + "  |  **الصف/المرحلة:** " + gr + "  |  **إعداد:** " + p.fullName + " (EduTech Mindset)",
      "",
      "## 💡 أولاً: المفاهيم والقواعد الأساسية المركّزة",
      coreBullets.map(function (b) { return "- " + b; }).join("\n"),
      "",
      "## 📊 ثانياً: جدول المقارنة والقوانين المرجعية",
      tableRows.join("\n"),
      "",
      "## ✍️ ثالثاً: أمثلة تطبيقية مشروحة خطوة بخطوة",
      examples.join("\n\n"),
      "",
      "## 🎯 رابعاً: اختبر فهمك (أسئلة متدرجة للمراجعة)",
      questions.join("\n"),
      "",
      "> **توجيه ختامي من " + p.fullName + ":** احتفظ بنسخة الـ PDF هذه للمراجعة السريعة قبل الامتحان، وناقشني صوتياً في «مساعدي» في أي سؤال تود التعمق فيه!"
    ].join("\n");
  }

  function triggerExport(kind, title, markdownText, opts, btnEl) {
    opts = opts || {};
    load();
    var p = getPersona();
    opts.tool = opts.tool || "مساعدي الذكي";
    opts.persona = opts.persona || p.fullName;
    if (D.pdfDraft && D.pdfDraft.teacher) opts.teacher = D.pdfDraft.teacher;
    if (D.pdfDraft && D.pdfDraft.school) opts.school = D.pdfDraft.school;
    if (window.Exporter && typeof window.Exporter[kind] === "function") {
      return window.Exporter[kind](title || "مستند من مساعدي الذكي", markdownText, opts, btnEl);
    }
    toast("جارٍ تجهيز محرك التصدير…", "info");
    return Promise.resolve();
  }

  function buildPdfReadyCardHtml(title, msgIndex, tplBadge) {
    return '<div class="ea-pdf-card">' +
      '<div class="ea-pdf-top">' +
        '<span class="ea-pdf-ico">📄</span>' +
        '<div style="min-width:0;flex:1">' +
          '<div class="ea-pdf-badge">✨ نسخة PDF جاهزة للتحميل والمشاركة ' + (tplBadge ? "• " + esc(tplBadge) : "") + '</div>' +
          '<div class="ea-pdf-title">' + esc(title) + '</div>' +
          '<div class="ea-pdf-sub">شاملة المخطط المفاهيمي البصري • رمز QR • ترويسة EduTech Mindset</div>' +
        '</div>' +
      '</div>' +
      '<div class="ea-pdf-btns">' +
        '<button type="button" class="ea-pdf-dl" data-dl-pdf="' + msgIndex + '">⬇ تحميل PDF الآن</button>' +
        '<button type="button" class="ea-pdf-sh" data-share-pdf="' + msgIndex + '" title="مشاركة ملف الـ PDF عبر واتساب أو تليجرام">📲 مشاركة</button>' +
        '<button type="button" class="ea-pdf-w" data-dl-docx="' + msgIndex + '">📘 Word</button>' +
        '<button type="button" class="ea-pdf-edit" data-open-pdfstudio="' + msgIndex + '">✏️ تعديل</button>' +
      '</div>' +
    '</div>';
  }

  // ------------------------------------------------------------------ 8) وضع «الحوار الصوتي الثنائي (البودكاست الحي)» بين شخصيتين (الإصدار 151)
  var podcastQueue = [];
  var podcastRunning = false;

  function buildDualPodcastTurns(topic, p1, p2) {
    var tp = String(topic || "قوانين الحركة والتفوق الدراسي").trim();
    return [
      {
        p: p1,
        text: "أهلاً بكم يا أبطال EduTech Mindset في حوارنا الثنائي الخاص! معكم " + p1.name + "، ويسعدني أن أستضيف معي اليوم " + p2.name + " لنناقش معاً موضوعاً مهماً جداً هو: «" + tp + "». كيف نقدم هذا الموضوع لطلبتنا بأبسط صورة؟"
      },
      {
        p: p2,
        text: "شكراً لك يا " + p1.name + "! السرّ في إتقان «" + tp + "» يبدأ دائماً من فهم الفكرة الجوهرية وعدم الحفظ الآلي؛ فنحن نحدد أولاً المعطيات والمفاهيم المفتاحية، ثم نربطها بالقانون أو القاعدة القياسية خطوة بخطوة."
      },
      {
        p: p1,
        text: "نقطة ذهبية! وكثير من الطلاب يسألونني: كيف نتجنب الأخطاء الشائعة في الامتحان عند التطبيق على «" + tp + "»؟"
      },
      {
        p: p2,
        text: "أفضل طريقة هي التدرب على مثال محلول ثم التحقق العكسي من النتيجة، وتلخيص القوانين في خريطة مفاهيمية بصرية واحدة كما نفعل في ملفات الـ PDF هنا في المنصة. والآن يا صديقنا المستمع، ما رأيك أن تختبر نفسك معنا بسؤال سريع أو تحمل ملخص هذا الحوار كملف PDF؟"
      }
    ];
  }

  function startDualPodcast(customTopic) {
    load();
    stopSpeaking();
    var p1 = getPersona();
    var p2 = getPersona(p1.partnerId || (p1.id === "basel" ? "bayan" : "basel"));
    var topic = customTopic || ($("eaTxt") && $("eaTxt").value.trim()) || "";
    if (!topic) {
      topic = (D.memoryTopics[0] && D.memoryTopics[0].t) || (D.chat.length ? String(D.chat[D.chat.length - 1].raw || D.chat[D.chat.length - 1].t).replace(/<[^>]+>/g, "").slice(0, 48).trim() : "أسرار التفوق في المنهاج الفلسطيني وتوظيف الذكاء الاصطناعي");
    }
    if ($("eaTxt")) { $("eaTxt").value = ""; $("eaTxt").style.height = "auto"; }
    rememberTopic(topic);

    var turns = buildDualPodcastTurns(topic, p1, p2);
    var mdLines = [
      "# 🎙️👥 حوار ثنائي حي (بودكاست EduTech Mindset) — " + topic,
      "",
      "[مخطط: حوار " + p1.name + " و" + p2.name + " | الفكرة المحورية | خطوات التطبيق | تجنب الأخطاء | الخلاصة والتقويم]",
      "",
      "> **المتحاوران:** " + p1.fullName + "  ×  " + p2.fullName,
      ""
    ];
    turns.forEach(function (tr) {
      mdLines.push("### " + tr.p.ico + " " + tr.p.name + ":");
      mdLines.push(tr.text);
      mdLines.push("");
    });
    var fullMd = mdLines.join("\n");

    UI.tab = "ask";
    render();
    pushMsg("u", "🎙️👥 شغل حواراً ثنائياً بين " + p1.name + " و" + p2.name + " حول: «" + topic + "»");
    pushMsg("a", fullMd, {
      raw: fullMd,
      pdfCard: true,
      pdfTitle: "حوار ثنائي — " + topic.slice(0, 45),
      pdfBadge: p1.name + " × " + p2.name
    });
    paintAsk();

    // قراءة الحوار الصوتي بالتناوب بين الشخصيتين!
    podcastQueue = turns.slice();
    podcastRunning = true;
    toast("🎙️👥 بدأ الحوار الصوتي الثنائي بين " + p1.name + " و" + p2.name + "!", "success");

    function playNextTurn() {
      if (!podcastRunning || !podcastQueue.length) {
        podcastRunning = false;
        return;
      }
      var turn = podcastQueue.shift();
      speakResponseWithPersona(turn.text, turn.p, function () {
        if (podcastRunning && podcastQueue.length) {
          setTimeout(playNextTurn, 320);
        } else {
          podcastRunning = false;
        }
      });
    }
    playNextTurn();
  }

  
  // ------------------------------------------------------------------ 8-ب) بطاقات الاختبار التفاعلية داخل الدردشة والتسميع السقراطي + محول ريلز 9:16 + المذكرة الصوتية لـ PDF (الإصدار 152)
  function buildInteractiveQuizBank(topic) {
    var tp = String(topic || "قوانين الحركة والفيزياء").trim();
    var n = norm(tp);
    if (/عربي|نحو|اعراب|إعراب|بلاغ|همز|تاء|كان|ان|إن/.test(n)) {
      return [
        {
          q: "ما إعراب كلمة (الأَمَلَ) في جملة: «يَصْنَعُ طُلَّابُ فِلَسْطِينَ الأَمَلَ بِالعِلْمِ»؟",
          opts: ["فاعل مرفوع بالضمة", "مفعول به منصوب وعلامة نصبه الفتحة الظاهرة", "مضاف إليه مجرور بالكسرة", "خبر مرفوع بالضمة"],
          ans: 1,
          pts: 3,
          exp: "أحسنت! (الأَمَلَ) وقع عليه فعل الفاعل فهو مفعول به منصوب وعلامة نصبه الفتحة الظاهرة."
        },
        {
          q: "عند دخول (كَانَ) وأخواتها على الجملة الاسمية فإنها:",
          opts: ["تنصب المبتدأ وترفع الخبر", "ترفع المبتدأ ويسمى اسمها وتنصب الخبر ويسمى خبرها", "تجر المبتدأ والخبر", "تجزم الفعل المضارع"],
          ans: 1,
          pts: 3,
          exp: "رائع! كان وأخواتها أفعال ناسخة ترفع المبتدأ وتنصب الخبر."
        },
        {
          q: "لماذا جُرّت كلمة (فِلَسْطِينَ) بالفتحة عوضاً عن الكسرة في «طُلَّابُ فِلَسْطِينَ»؟",
          opts: ["لأنها جمع مؤنث سالم", "لأنها ممنوعة من الصرف للعلمية والتأنيث", "لأنها من الأسماء الخمسة", "لأنها مبنية على الفتح"],
          ans: 1,
          pts: 4,
          exp: "إجابة متميزة! فلسطين علم مؤنث ممنوع من الصرف فيُجر بالفتحة نيابة عن الكسرة."
        }
      ];
    }
    if (/رياضيات|معادل|كسر|مشتق|تكامل|اقتران|فيثاغورس/.test(n)) {
      return [
        {
          q: "ما جذرا المعادلة التربيعية: س² - 5س + 6 = 0 ؟",
          opts: ["س = 2 ، س = 3", "س = -2 ، س = -3", "س = 1 ، س = 6", "س = 0 ، س = 5"],
          ans: 0,
          pts: 3,
          exp: "ممتاز! لأن حاصل ضرب (2 × 3 = 6) ومجموعهما (2 + 3 = 5)؛ أي (س - 2)(س - 3) = 0."
        },
        {
          q: "عند النقطة الحرجة للاقتران ق(س) القابل للاشتقاق، تكون قيمة المشتقة الأولى ق'(س) تساوي:",
          opts: ["1 دائماً", "صفراً (ق'(س) = 0)", "ما لا نهاية", "قيمة سالبة دائماً"],
          ans: 1,
          pts: 3,
          exp: "صحيح! عند القيم القصوى المحلية والنقاط الحرجة يكون ميل المماس أفقياً أي ق'(س) = 0."
        },
        {
          q: "مثلث قائم الزاوية طولا ضلعيه القائمين 6 سم و 8 سم، فكم طول وتره؟",
          opts: ["12 سم", "10 سم", "14 سم", "100 سم"],
          ans: 1,
          pts: 4,
          exp: "بطل! حسب نظرية فيثاغورس: الوتر = √(36 + 64) = √100 = 10 سم."
        }
      ];
    }
    if (/انجليزي|إنجليزي|english|present|past|passive/.test(n)) {
      return [
        {
          q: "Choose the correct form: 'She _______ her project already.'",
          opts: ["finish", "finished", "has finished", "finishing"],
          ans: 2,
          pts: 3,
          exp: "Great job! With 'already', we use the Present Perfect tense (has/have + V3)."
        },
        {
          q: "Which sentence is in the Passive Voice?",
          opts: ["The teacher explained the lesson.", "The lesson was explained clearly.", "Students are studying hard.", "We will visit Jerusalem."],
          ans: 1,
          pts: 3,
          exp: "Correct! 'was explained' is (be + past participle), which forms the Passive Voice."
        },
        {
          q: "Identify the time indicator usually used with Past Simple:",
          opts: ["since 2020", "yesterday / two days ago", "yet", "ever"],
          ans: 1,
          pts: 4,
          exp: "Spot on! 'yesterday' and 'ago' indicate a completed action at a specific time in the past."
        }
      ];
    }
    return [
      {
        q: "في درس «" + tp.slice(0, 38) + "»، متى يكون الزخم الخطي أو الزاوي للنظام محفوظاً؟",
        opts: ["عندما تؤثر قوة خارجية كبيرة", "عندما تكون محصلة القوى أو العزوم الخارجية المؤثرة تساوي صفراً", "عند زيادة الكتلة إلى الضعف فقط", "لا يحفظ الزخم في الأنظمة المعزولة"],
        ans: 1,
        pts: 3,
        exp: "أحسنت يا بطل! ينص قانون الحفظ على بقاء الزخم ثابتاً في النظام المعزول عندما تنعدم محصلة القوى/العزوم الخارجية."
      },
      {
        q: "إذا تضمّن المتزلج ذراعيه نحو محور الدوران، فماذا يحدث لعزم قصوره الدوراني (I) وسرعته الزاوية (ω)؟",
        opts: ["يقل عزم القصور الدوراني وتزداد السرعة الزاوية", "يزداد عزم القصور وتقل السرعة", "يبقى كل منهما ثابتاً", "تنعدم الطاقة الحركية"],
        ans: 0,
        pts: 3,
        exp: "إجابة ذكية! لأن الزخم الزاوي L = I·ω محفوظ، فعندما يقل I تزداد ω تناسباً عكسياً."
      },
      {
        q: "ما الخطوة الأهم للتحقق من صحة حل أي مسألة علمية في الامتحان الوزاري؟",
        opts: ["كتابة الناتج النهائي بدون قانون", "مراجعة القانون وتعويض الوحدات القياسية والتحقق العكسي", "حذف الخطوات الوسطية", "تقريب الأرقام عشوائياً"],
        ans: 1,
        pts: 4,
        exp: "ممتاز! كتابة القانون ووحدة القياس والتحقق العكسي تضمن لك العلامة الكاملة."
      }
    ];
  }

  function startSocraticQuizCard(customTopic) {
    load();
    var p = getPersona();
    var topic = customTopic || (D.memoryTopics[0] && D.memoryTopics[0].t) || "قوانين الحركة والفيزياء — التوجيهي";
    var qid = "qz_" + uid();
    D.quizzes[qid] = {
      id: qid,
      topic: topic,
      cur: 0,
      score: 0,
      done: false,
      picked: {},
      items: buildInteractiveQuizBank(topic)
    };
    save();
    UI.tab = "ask";
    render();
    pushMsg("u", "🎯 اختبر فهمي بالتسميع السقراطي التفاعلي (3 أسئلة من 10 درجات) في: «" + topic + "»");
    pushMsg("a", "يا سلام على الهمة العالية! 🌟 جهزتُ لك **بطاقة التسميع السقراطي التفاعلية** من 10 درجات حول **«" + topic + "»**. اختر الإجابة الصحيحة بالضغط عليها مباشرة:", {
      raw: "بطاقة التسميع السقراطي التفاعلية حول: " + topic,
      quizId: qid
    });
    paintAsk();
    if (D.voice || UI.liveCall) {
      speakResponse("جهزت لك تحدي التسميع السقراطي من عشر درجات! السؤال الأول: " + D.quizzes[qid].items[0].q);
    }
  }

  function renderQuizCardHtml(qid) {
    load();
    var qz = D.quizzes && D.quizzes[qid];
    if (!qz || !qz.items || !qz.items.length) return "";
    if (qz.done) {
      return '<div class="ea-qcard">' +
        '<div class="ea-qtop"><span>🏆 اكتمل التسميع السقراطي التفاعلي!</span><span>النتيجة: ' + qz.score + ' / 10</span></div>' +
        '<div class="ea-qq" style="text-align:center;font-size:15px;color:#10b981">🎉 أحسنت يا ' + esc(firstName() || "بطل EduTech Mindset") + '! حصلت على <b>' + qz.score + ' من 10</b> في «' + esc(qz.topic) + '»</div>' +
        '<div class="ea-pdf-btns" style="margin-top:8px">' +
          '<button type="button" class="ea-pdf-dl" data-quiz-cert="' + esc(qid) + '">🏅 إصدار شهادة تفوق PDF الآن</button>' +
          '<button type="button" class="ea-pdf-w" data-quiz-retry="' + esc(qid) + '">🔄 إعادة التحدي</button>' +
        '</div>' +
      '</div>';
    }
    var idx = qz.cur || 0;
    var item = qz.items[idx] || qz.items[0];
    var chosen = qz.picked && qz.picked[idx];
    var letters = ["أ", "ب", "ج", "د"];
    return '<div class="ea-qcard">' +
      '<div class="ea-qtop"><span>🎯 سؤال (' + (idx + 1) + ' من ' + qz.items.length + ') • ' + item.pts + ' درجات</span><span>مجموعك: ' + qz.score + ' / 10</span></div>' +
      '<div class="ea-qq">' + esc(item.q) + '</div>' +
      '<div class="ea-qopts">' +
        item.opts.map(function (op, oi) {
          var cls = "";
          var badge = "";
          if (chosen !== undefined) {
            if (oi === item.ans) { cls = "ok"; badge = "✓ الصواب"; }
            else if (oi === chosen && chosen !== item.ans) { cls = "bad"; badge = "✗ خطأ"; }
          }
          return '<button type="button" class="ea-qopt ' + cls + '" data-qpick="' + esc(qid) + ':' + idx + ':' + oi + '" ' + (chosen !== undefined ? "disabled" : "") + '>' +
            '<span><b>' + letters[oi] + ')</b> ' + esc(op) + '</span>' +
            (badge ? '<small style="font-weight:900">' + badge + '</small>' : '') +
          '</button>';
        }).join("") +
      '</div>' +
      (chosen !== undefined ? (
        '<div class="ea-qexp">' + esc(item.exp) + '</div>' +
        '<div style="margin-top:8px;text-align:left">' +
          '<button type="button" class="ea-btn" data-qnext="' + esc(qid) + '">' + (idx + 1 < qz.items.length ? "السؤال التالي ⬅" : "عرض النتيجة النهائية والشهادة 🏆") + '</button>' +
        '</div>'
      ) : '') +
    '</div>';
  }

  // مشغل ومحوّل ريلز 9:16 العمودي الناطق (Reels 9:16 Studio)
  var reelState = { slides: [], cur: 0, playing: false, title: "", rawMd: "" };

  function buildReelSlidesFromText(title, rawText) {
    var p = getPersona();
    var clean = String(rawText || "").replace(/\[(?:مخطط|رسم|خريطة)[^\]]*\]/g, "").replace(/<[^>]+>/g, "").trim();
    var paragraphs = clean.split(/\n{2,}/).map(function (x) { return x.replace(/^[#>*\-\s]+/, "").trim(); }).filter(function (x) { return x.length > 15; });
    if (paragraphs.length < 3) {
      paragraphs = [
        "الفكرة الأساسية في «" + title + "» تعتمد على فهم العلاقة العلمية وتطبيقها خطوة بخطوة.",
        "الخطوة الذهبية للحل: حدّد المعطيات، اكتب القانون القياسي، عوّض بالوحدات الصحيحة، ثم تحقق من الناتج.",
        "نصيحة للتفوق في الامتحان: لخّص القوانين في خريطة مفاهيمية بصرية وحل سؤالين تطبيقين بعد كل درس!"
      ];
    }
    var slides = [
      {
        tag: "🎬 ريلز توجيهي فلسطين • EduTech Mindset",
        title: title.slice(0, 55),
        body: "مع " + p.fullName + " — شرح مكثف في 60 ثانية بطريقة بصرية شائقة!",
        voice: "أهلاً بكم في ريلز إديوتك مايندست! اليوم نشرح معاً باختصار وإبداع: " + title
      }
    ];
    paragraphs.slice(0, 4).forEach(function (pr, i) {
      slides.push({
        tag: "💡 المحور (" + (i + 1) + ") • ركّز جيداً",
        title: "النقطة الجوهرية (" + (i + 1) + ")",
        body: pr.slice(0, 220),
        voice: pr.slice(0, 220)
      });
    });
    slides.push({
      tag: "🇵🇸 منصة EduTech Mindset • أ. باسل الفقعاوي",
      title: "هل استفدت من هذا الريلز؟ 🌟",
      body: "حمّل الملخص الكامل بصيغة PDF مع رمز QR من داخل «مساعدي»، وشاركه مع زملائك الآن!",
      voice: "حمّل الملخص الكامل بصيغة بي دي إف من داخل مساعدي، وبالتوفيق والنجاح يا أبطال!"
    });
    return slides;
  }

  function ensureReelModal() {
    var m = $("eaReelModal");
    if (m) return m;
    m = document.createElement("div");
    m.id = "eaReelModal";
    m.innerHTML =
      '<div class="ea-reel-frame">' +
        '<div>' +
          '<div class="ea-reel-bars" id="eaReelBars"></div>' +
          '<div style="display:flex;align-items:center;justify-content:space-between;gap:6px">' +
            '<div style="display:flex;align-items:center;gap:6px">' +
              '<span id="eaReelIco" style="font-size:20px">🎬</span>' +
              '<div style="text-align:right"><div id="eaReelTag" style="font-size:10px;color:#fde68a;font-weight:900">EduTech Mindset 9:16</div><div id="eaReelPersona" style="font-size:11px;font-weight:800;color:#bae6fd"></div></div>' +
            '</div>' +
            '<button type="button" class="ea-ib" id="eaReelClose">✕</button>' +
          '</div>' +
        '</div>' +
        '<div class="ea-reel-body">' +
          '<div class="ea-reel-slide-t" id="eaReelTitle"></div>' +
          '<div class="ea-reel-slide-b" id="eaReelBody"></div>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:7px">' +
          '<div style="display:flex;gap:6px;justify-content:center">' +
            '<button type="button" class="ea-ib" id="eaReelPrev" style="flex:1;height:36px">⏮ السابق</button>' +
            '<button type="button" class="ea-ib on" id="eaReelPlay" style="flex:2;height:36px">🔊 تشغيل الريلز بالصوت</button>' +
            '<button type="button" class="ea-ib" id="eaReelNext" style="flex:1;height:36px">التالي ⏭</button>' +
          '</div>' +
          '<div style="display:flex;gap:6px"><button type="button" class="ea-pdf-sh" id="eaReelRecordVid" style="flex:1">🎥 تصدير فيديو (.webm)</button><button type="button" class="ea-pdf-dl" id="eaReelExportPdf" style="flex:1">📄 سيناريو PDF</button></div>' +
        '</div>' +
      '</div>';
    document.body.appendChild(m);
    m.addEventListener("click", function (e) { if (e.target === m) closeReelModal(); });
    $("eaReelClose").onclick = closeReelModal;
    $("eaReelPrev").onclick = function () { reelStep(-1); };
    $("eaReelNext").onclick = function () { reelStep(1); };
    $("eaReelPlay").onclick = function () {
      if (reelState.playing) {
        reelState.playing = false;
        stopSpeaking();
        paintReelSlide();
      } else {
        reelState.playing = true;
        playCurrentReelSlide();
      }
    };
        $("eaReelRecordVid").onclick = function () {
      var btn = $("eaReelRecordVid");
      if (typeof MediaRecorder === "undefined" || !HTMLCanvasElement.prototype.captureStream) {
        toast("متصفحك الحالي لا يدعم تسجيل الفيديو المباشر — استخدم زر «سيناريو PDF»", "warning");
        return;
      }
      btn.disabled = true; btn.textContent = "⏳ جارٍ التصيير…";
      var cv = document.createElement("canvas"); cv.width = 540; cv.height = 960;
      var cx = cv.getContext("2d");
      var stream = cv.captureStream(25);
      var chunks = [];
      var mime = MediaRecorder.isTypeSupported("video/webm;codecs=vp9") ? "video/webm;codecs=vp9" : "video/webm";
      var rec = new MediaRecorder(stream, { mimeType: mime });
      rec.ondataavailable = function (ev) { if (ev.data && ev.data.size) chunks.push(ev.data); };
      rec.onstop = function () {
        var blob = new Blob(chunks, { type: "video/webm" });
        var u = URL.createObjectURL(blob), a = document.createElement("a");
        a.href = u; a.download = "EduTech-Reel-9x16.webm"; document.body.appendChild(a); a.click();
        setTimeout(function () { URL.revokeObjectURL(u); a.remove(); }, 3000);
        btn.disabled = false; btn.textContent = "🎥 تصدير فيديو (.webm)";
        toast("🎬 تم تسجيل وتنزيل فيديو ريلز 9:16 بنجاح ✓", "success");
      };
      rec.start();
      var idx = 0;
      function drawSlideFrame(sl) {
        var g = cx.createLinearGradient(0, 0, 540, 960);
        g.addColorStop(0, "#082f49"); g.addColorStop(0.55, "#0f172a"); g.addColorStop(1, "#1e1b4b");
        cx.fillStyle = g; cx.fillRect(0, 0, 540, 960);
        cx.strokeStyle = "#f59e0b"; cx.lineWidth = 6; cx.strokeRect(18, 18, 504, 924);
        cx.direction = "rtl"; cx.textAlign = "center";
        cx.font = "bold 20px Cairo, sans-serif"; cx.fillStyle = "#fde68a";
        cx.fillText(sl.tag || "EduTech Mindset", 270, 95);
        cx.font = "bold 32px Cairo, sans-serif"; cx.fillStyle = "#fbbf24";
        cx.fillText(String(sl.title || "").slice(0, 34), 270, 260);
        cx.font = "600 22px Cairo, sans-serif"; cx.fillStyle = "#f8fafc";
        var words = String(sl.body || "").split(/\s+/), line = "", y = 380;
        words.forEach(function (w) {
          if ((line + " " + w).length > 34) { cx.fillText(line, 270, y); y += 38; line = w; }
          else line = line ? line + " " + w : w;
        });
        if (line) cx.fillText(line, 270, y);
        cx.font = "bold 16px Cairo, sans-serif"; cx.fillStyle = "#bae6fd";
        cx.fillText("EduTech Mindset — إدارة الأستاذ باسل أشرف الفقعاوي", 270, 905);
      }
      function stepRec() {
        if (idx >= reelState.slides.length) { rec.stop(); return; }
        drawSlideFrame(reelState.slides[idx++]);
        setTimeout(stepRec, 1600);
      }
      stepRec();
    };

    $("eaReelExportPdf").onclick = function () {
      var p = getPersona();
      var scriptLines = [
        "# 🎬 سيناريو ريلز عمودي (9:16) وبرومبتات الإنتاج — " + reelState.title,
        "",
        "[مخطط: إنتاج ريلز 9:16 | الشريحة الافتتاحية | الشرح البصري | التيبوغرافي والتشكيل | الخاتمة والدعوة للتفاعل]",
        "",
        "> **المقدم الصوتي:** " + p.fullName + "  |  **المقاس:** 9:16 عمودي (Reels / Shorts)  |  **الهوية:** EduTech Mindset",
        ""
      ];
      reelState.slides.forEach(function (sl, i) {
        scriptLines.push("## 🎞️ المشهد (" + (i + 1) + "): " + sl.title);
        scriptLines.push("- **النص الظاهر على الشاشة:** " + sl.body);
        scriptLines.push("- **التعليق الصوتي (Voiceover):** «" + sl.voice + "»");
        scriptLines.push("- **وصف المشهد البصري (Visual Prompt for Veo / Flow):** Cinematic 9:16 vertical educational motion graphics in EduTech Mindset studio, warm LED lighting, navy and gold accents, clear visual illustration of scene " + (i + 1) + ".");
        scriptLines.push("");
      });
      triggerExport("pdf", "سيناريو ريلز 9-16 — " + reelState.title.slice(0, 40), scriptLines.join("\n"), { tool: "استوديو ريلز 9:16 — مساعدي الذكي", persona: p.fullName }, $("eaReelExportPdf"));
    };
    return m;
  }

  function paintReelSlide() {
    var m = ensureReelModal();
    var sl = reelState.slides[reelState.cur] || reelState.slides[0];
    if (!sl) return;
    var p = getPersona();
    $("eaReelIco").textContent = p.ico;
    $("eaReelTag").textContent = sl.tag;
    $("eaReelPersona").textContent = p.fullName + " • شريحة " + (reelState.cur + 1) + "/" + reelState.slides.length;
    $("eaReelTitle").textContent = sl.title;
    $("eaReelBody").textContent = sl.body;
    $("eaReelPlay").textContent = reelState.playing ? "⏸ إيقاف مؤقت" : "🔊 تشغيل الريلز بالصوت";
    $("eaReelBars").innerHTML = reelState.slides.map(function (_, i) {
      return '<span class="' + (i <= reelState.cur ? "on" : "") + '"></span>';
    }).join("");
  }

  function playCurrentReelSlide() {
    paintReelSlide();
    if (!reelState.playing) return;
    var sl = reelState.slides[reelState.cur];
    if (!sl) { reelState.playing = false; paintReelSlide(); return; }
    speakResponse(sl.voice, function () {
      if (!reelState.playing) return;
      if (reelState.cur + 1 < reelState.slides.length) {
        reelState.cur++;
        setTimeout(playCurrentReelSlide, 350);
      } else {
        reelState.playing = false;
        paintReelSlide();
      }
    });
  }

  function reelStep(dir) {
    stopSpeaking();
    reelState.playing = false;
    reelState.cur = clamp(reelState.cur + dir, 0, Math.max(0, reelState.slides.length - 1));
    paintReelSlide();
  }

  function openReelFromText(title, rawText) {
    stopSpeaking();
    reelState.title = title || "شرح تفاعلي من مساعدي الذكي";
    reelState.rawMd = rawText || "";
    reelState.slides = buildReelSlidesFromText(reelState.title, rawText);
    reelState.cur = 0;
    reelState.playing = true;
    var m = ensureReelModal();
    m.classList.add("open");
    playCurrentReelSlide();
  }

  function closeReelModal() {
    reelState.playing = false;
    stopSpeaking();
    var m = $("eaReelModal");
    if (m) m.classList.remove("open");
  }

  // تحويل المذكرة الصوتية إلى ملف PDF رسمي منسق (Voice-Note to Structured PDF)
  function startVoiceNoteToPdf() {
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      var fallbackTxt = ($("eaTxt") && $("eaTxt").value.trim()) || "ملخص قوانين نيوتن للحركة والتسارع والقصور الدوراني";
      ask("جهز لي ملف PDF جاهز للتحميل من مذكرتي الصوتية حول: " + fallbackTxt);
      return;
    }
    stopSpeaking();
    stopMic(false);
    toast("🎙️📄 تحدث الآن بعفوية (اشرح فكرتك أو أملي نقاط الدرس)، وسأحول كلامك تلقائياً إلى ملف PDF رسمي منسق!", "info");
    try {
      var r = new SR();
      r.lang = "ar-SA";
      r.interimResults = true;
      r.continuous = false;
      liveRec = r;
      liveState = "listening";
      updateLiveUI();
      var cap = "";
      r.onresult = function (ev) {
        var s = "";
        for (var i = 0; i < ev.results.length; i++) s += ev.results[i][0].transcript;
        cap = s.trim();
        if ($("eaTxt")) $("eaTxt").value = cap;
      };
      r.onend = function () {
        liveRec = null;
        liveState = "idle";
        updateLiveUI();
        var finalNote = (cap || ($("eaTxt") && $("eaTxt").value) || "").trim();
        if (finalNote) {
          if ($("eaTxt")) { $("eaTxt").value = ""; $("eaTxt").style.height = "auto"; }
          ask("جهز لي نسخة PDF جاهزة للتحميل مرتبة ومنسقة من هذه المذكرة الصوتية: " + finalNote);
        } else {
          toast("لم ألتقط صوتاً — اضغط 🎙️📄 وتحدث مرة أخرى أو اكتب الفكرة وسأحولها لـ PDF", "warning");
        }
      };
      r.start();
    } catch (e) {
      liveState = "idle";
      updateLiveUI();
    }
  }

  
  // ------------------------------------------------------------------ 8-ج) نظام النقاط XP وبنك الأخطاء ولوحة الرسم اليدوي ووضع المساعد الصفي (الإصدار 153)
  function addXp(pts, reason) {
    load();
    D.xp = (D.xp || 0) + (pts || 5);
    save();
    if (reason) toast("⭐ +" + pts + " XP — " + reason, "success");
  }
  function getXpRank(xp) {
    if (xp >= 250) return "🏆 أسطورة EduTech";
    if (xp >= 120) return "🥇 فارس التميز";
    if (xp >= 60) return "🥈 مثابر نشط";
    return "🌱 مبتدئ واعد";
  }

  function exportMistakesRemedialPdf(btnEl) {
    load();
    var p = getPersona();
    if (!D.mistakes.length) {
      toast("🎉 سجل أخطائك فارغ تماماً! لم تخطئ في أي سؤال بعد.", "success");
      return Promise.resolve();
    }
    var lines = [
      "# 🩺 الخطة العلاجية وبنك الأخطاء المخصص — " + (firstName() || "بطل EduTech Mindset"),
      "",
      "[مخطط: معالجة نقاط الضعف | عدد الأخطاء المرصودة (" + D.mistakes.length + ") | تصحيح المفاهيم | أمثلة التثبيت | التحدي الجديد]",
      "",
      "> **التاريخ:** " + dateLine() + "  |  **إشراف:** " + p.fullName,
      ""
    ];
    D.mistakes.forEach(function (m, i) {
      lines.push("## " + (i + 1) + ". موضوع: " + m.topic);
      lines.push("- **السؤال:** " + m.q);
      lines.push("- **الإجابة الصحيحة المعتمدة:** " + m.correct);
      lines.push("- **التعليل والتوضيح:** " + m.exp);
      lines.push("");
    });
    return triggerExport("pdf", "ملف علاجي لبنك أخطائي — " + (firstName() || "EduTech"), lines.join("\n"), { tool: "بنك أخطائي الذكي", persona: p.fullName }, btnEl);
  }

  // لوحة الرسم والكتابة اليدوية للمعادلات والأشكال (✏️)
  function openDrawPadModal() {
    var m = $("eaDrawModal");
    if (!m) {
      m = document.createElement("div");
      m.id = "eaDrawModal";
      m.innerHTML =
        '<div class="ea-submodal" style="background:#0f172a;color:#f8fafc">' +
          '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">' +
            '<b style="font-size:14px">✏️ لوحة كتابة المعادلات والرسم الهندسي</b>' +
            '<button type="button" class="ea-ib" id="eaDrawClose">✕</button>' +
          '</div>' +
          '<canvas id="eaDrawCanvas" width="420" height="240"></canvas>' +
          '<div class="ea-sym-bar">' +
            ["√", "π", "∑", "∫", "÷", "×", "²", "³", "Δ", "θ", "→"].map(function (sym) {
              return '<button type="button" class="ea-sym-btn" data-draw-sym="' + sym + '">' + sym + '</button>';
            }).join("") +
          '</div>' +
          '<div style="display:flex;gap:6px;flex-wrap:wrap">' +
            '<button type="button" class="ea-btn g" id="eaDrawClear" style="background:#1e293b;color:#f8fafc">🧹 مسح اللوحة</button>' +
            '<button type="button" class="ea-btn" id="eaDrawSend" style="flex:1">✅ إرفاق وحل المعادلة/الرسمة</button>' +
          '</div>' +
        '</div>';
      document.body.appendChild(m);
      var cv = $("eaDrawCanvas"), ctx = cv.getContext("2d");
      function resetCanvas() {
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, cv.width, cv.height);
        ctx.strokeStyle = "#0f172a";
        ctx.lineWidth = 3;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
      }
      resetCanvas();
      var drawing = false;
      function pt(ev) {
        var r = cv.getBoundingClientRect();
        var cx = ev.touches ? ev.touches[0].clientX : ev.clientX;
        var cy = ev.touches ? ev.touches[0].clientY : ev.clientY;
        return { x: (cx - r.left) * (cv.width / r.width), y: (cy - r.top) * (cv.height / r.height) };
      }
      cv.addEventListener("pointerdown", function (e) { drawing = true; var p = pt(e); ctx.beginPath(); ctx.moveTo(p.x, p.y); });
      cv.addEventListener("pointermove", function (e) { if (!drawing) return; e.preventDefault(); var p = pt(e); ctx.lineTo(p.x, p.y); ctx.stroke(); });
      window.addEventListener("pointerup", function () { drawing = false; });
      m.addEventListener("click", function (e) {
        if (e.target === m) m.classList.remove("open");
        var sb = e.target.closest("[data-draw-sym]");
        if (sb) {
          ctx.fillStyle = "#0284c7";
          ctx.font = "bold 28px Cairo, Arial, sans-serif";
          ctx.fillText(sb.getAttribute("data-draw-sym"), 30 + Math.random() * 240, 60 + Math.random() * 120);
        }
      });
      $("eaDrawClose").onclick = function () { m.classList.remove("open"); };
      $("eaDrawClear").onclick = resetCanvas;
      $("eaDrawSend").onclick = function () {
        var dataUrl = cv.toDataURL("image/jpeg", 0.85);
        chatAttachments.push({ mime: "image/jpeg", data: dataUrl.split(",")[1], thumb: dataUrl, name: "معادلة_مرسومة.jpg" });
        paintAttachmentStrip();
        m.classList.remove("open");
        toast("✏️ تم إرفاق رسمتك — اكتب سؤالك أو اضغط إرسال!", "success");
      };
    }
    m.classList.add("open");
  }

  // وضع المساعد الصفي (القرعة العشوائية + مؤقت 15 ثانية + النقاط)
  var classTimerIv = null;
  function openClassroomModeModal() {
    load();
    var m = $("eaClassModal");
    if (!m) {
      m = document.createElement("div");
      m.id = "eaClassModal";
      document.body.appendChild(m);
      m.addEventListener("click", function (e) { if (e.target === m) { clearInterval(classTimerIv); m.classList.remove("open"); } });
    }
    var pickedName = "اضغط «🎲 سحب اسم عشوائي»";
    var secLeft = 15;
    function draw() {
      m.innerHTML =
        '<div class="ea-submodal" style="background:#0f172a;color:#f8fafc">' +
          '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">' +
            '<b style="font-size:15px;color:#fbbf24">👨‍🏫 وضع المساعد الصفي والقرعة التفاعلية</b>' +
            '<button type="button" class="ea-ib" id="eaClsClose">✕</button>' +
          '</div>' +
          '<div style="padding:14px;border-radius:16px;background:linear-gradient(135deg,#082f49,#1e1b4b);border:1.5px solid #f59e0b;text-align:center;margin-bottom:10px">' +
            '<div style="font-size:11px;color:#bae6fd;font-weight:800">الطالب المختار للسؤال:</div>' +
            '<div id="eaClsPicked" style="font-size:24px;font-weight:900;color:#fff;margin:6px 0">' + esc(pickedName) + '</div>' +
            '<div id="eaClsTimer" style="font:900 28px/1 Cairo,monospace;color:#34d399;direction:ltr">00:' + ("0" + secLeft).slice(-2) + '</div>' +
          '</div>' +
          '<div style="display:flex;gap:6px;margin-bottom:10px">' +
            '<button type="button" class="ea-btn" id="eaClsSpin" style="flex:1">🎲 سحب اسم عشوائي + بدء 15 ث</button>' +
            '<button type="button" class="ea-btn r" id="eaClsStop">⏹ إيقاف</button>' +
          '</div>' +
          '<label style="display:block;font-size:11.5px;font-weight:800;margin-bottom:4px">قائمة أسماء الطلبة (مفصولة بفاصلة أو سطر):</label>' +
          '<textarea id="eaClsNames" rows="3" class="ea-field" style="width:100%;background:#1e293b;color:#fff;margin-bottom:8px">' + esc((D.classRoster || []).join("، ")) + '</textarea>' +
          '<button type="button" class="ea-btn g" id="eaClsSave" style="width:100%;background:#1e293b;color:#bae6fd">💾 حفظ قائمة الصف</button>' +
        '</div>';
      $("eaClsClose").onclick = function () { clearInterval(classTimerIv); m.classList.remove("open"); };
      $("eaClsSave").onclick = function () {
        var raw = $("eaClsNames").value.split(/[,،\n]+/).map(function (x) { return x.trim(); }).filter(Boolean);
        if (raw.length) { D.classRoster = raw; save(); toast("تم حفظ قائمة الصف (" + raw.length + " طالباً) ✓", "success"); }
      };
      $("eaClsStop").onclick = function () { clearInterval(classTimerIv); };
      $("eaClsSpin").onclick = function () {
        clearInterval(classTimerIv);
        var list = $("eaClsNames").value.split(/[,،\n]+/).map(function (x) { return x.trim(); }).filter(Boolean);
        if (!list.length) list = ["طالب 1", "طالب 2", "طالب 3"];
        D.classRoster = list; save();
        pickedName = list[Math.floor(Math.random() * list.length)];
        secLeft = 15;
        $("eaClsPicked").textContent = "🌟 " + pickedName;
        $("eaClsTimer").textContent = "00:15";
        speakResponse("دور الطالب البطل " + pickedName + "، معك خمس عشرة ثانية للإجابة!");
        classTimerIv = setInterval(function () {
          secLeft--;
          var el = $("eaClsTimer");
          if (el) el.textContent = "00:" + ("0" + Math.max(0, secLeft)).slice(-2);
          if (secLeft <= 0) { clearInterval(classTimerIv); beep(); toast("⏰ انتهى وقت السؤال!", "info"); }
        }, 1000);
      };
    }
    draw();
    m.classList.add("open");
  }

  // ------------------------------------------------------------------ 9) النطق الصوتي الطبيعي (TTS) والحوار الصوتي الحي المستمر
  var localSynth = ("speechSynthesis" in window) ? window.speechSynthesis : null;
  var speakingNow = false;
  var liveState = "idle";
  var liveInterim = "";
  var liveRec = null;
  var speakSafetyTimer = null;

  function cleanForSpeech(raw) {
    return String(raw || "")
      .replace(/```[\s\S]*?```/g, " ")
      .replace(/\[(?:مخطط|رسم|خريطة)[^\]]*\]/g, " ")
      .replace(/\|[^\n]+\|/g, " ")
      .replace(/<[^>]+>/g, " ")
      .replace(/[#*_`~>•\-]+/g, " ")
      .replace(/https?:\/\/\S+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 900);
  }

  function updateLiveUI() {
    var bar = $("eaLiveBar");
    var callBtn = $("eaCallBtn");
    var micBtn = $("eaMic");
    if (callBtn) {
      callBtn.classList.toggle("on", !!UI.liveCall);
      callBtn.innerHTML = UI.liveCall ? "🔴 إنهاء الحوار" : "🎙️ حوار حي";
    }
    if (micBtn) {
      micBtn.classList.toggle("rec", liveState === "listening");
    }
    if (!bar) return;
    if (!UI.liveCall) {
      bar.style.display = "none";
      return;
    }
    bar.style.display = "flex";
    bar.setAttribute("data-state", liveState);
    var p = getPersona();
    var statusTxt =
      liveState === "listening" ? "🟢 أستمع إليك الآن… تحدّث بطبيعتك كأنك معي" :
      liveState === "thinking"  ? "🟣 أفكّر في كلامك وأجهّز الرد…" :
      liveState === "speaking"  ? "🔵 " + p.name + " يتحدث معك الآن… (اضغط لمقاطعتي والتحدث)" :
                                  "⚪ وضع الحوار البشري الحي جاهز — اضغط على الموجة للتحدث";
    var subTxt = liveInterim ? "«" + liveInterim + "»" : "حوار صوتي مستمر يأخذ ويعطي تلقائياً • شخصية: " + p.name;
    var stEl = $("eaLiveStatus"), sbEl = $("eaLiveSub");
    if (stEl) stEl.textContent = statusTxt;
    if (sbEl) sbEl.textContent = subTxt;
  }

  function stopSpeaking() {
    clearTimeout(speakSafetyTimer);
    speakingNow = false;
    podcastRunning = false;
    podcastQueue = [];
    try { if (window.EduVoice && window.EduVoice.stop) window.EduVoice.stop(); } catch (e) {}
    try { if (localSynth) localSynth.cancel(); } catch (e2) {}
    if (liveState === "speaking") {
      liveState = "idle";
      updateLiveUI();
    }
  }

  function speakResponseWithPersona(text, personaObj, onDone) {
    clearTimeout(speakSafetyTimer);
    var clean = cleanForSpeech(text);
    if (!clean) {
      if (onDone) onDone();
      return;
    }
    var p = personaObj || getPersona();
    speakingNow = true;
    if (UI.liveCall) {
      liveState = "speaking";
      liveInterim = "";
      updateLiveUI();
    }

    var finished = false;
    function finishOnce() {
      if (finished) return;
      finished = true;
      clearTimeout(speakSafetyTimer);
      speakingNow = false;
      if (UI.liveCall && liveState === "speaking") {
        liveState = "idle";
        updateLiveUI();
      }
      if (typeof onDone === "function") onDone();
    }

    var estMs = Math.min(45000, Math.max(4500, clean.length * 95));
    speakSafetyTimer = setTimeout(finishOnce, estMs);

    var isEn = /[A-Za-z]{4,}/.test(clean) && !/[\u0600-\u06FF]{4,}/.test(clean);
    var vId = (p.id === "layan" && isEn) ? (p.enVoiceId || "en_aria") : p.voiceId;
    var lang = (p.id === "layan" && isEn) ? "en-US" : (p.lang || "ar-SA");

    if (window.EduVoice && typeof window.EduVoice.read === "function") {
      try {
        window.EduVoice.read(clean, lang, vId, finishOnce);
        return;
      } catch (e) {}
    }

    if (localSynth && typeof SpeechSynthesisUtterance !== "undefined") {
      try {
        var u = new SpeechSynthesisUtterance(clean);
        u.lang = lang;
        u.rate = p.rate || 1.0;
        u.pitch = p.pitch || 1.0;
        u.onend = u.onerror = finishOnce;
        localSynth.speak(u);
        return;
      } catch (e2) {}
    }
    finishOnce();
  }

  function speakResponse(text, onDone) {
    stopSpeaking();
    speakResponseWithPersona(text, getPersona(), onDone);
  }

  function startListening(continuousTurn) {
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      toast("متصفحك الحالي لا يدعم التعرف على الصوت عبر الميكروفون، لكن يمكنك الكتابة وسأردّ عليك بالصوت الحي!", "info");
      if (UI.liveCall) {
        liveState = "idle";
        updateLiveUI();
      }
      return;
    }
    stopSpeaking();
    stopMic(true);
    try {
      var r = new SR();
      var p = getPersona();
      r.lang = p.id === "layan" ? "ar-JO" : "ar-SA";
      r.interimResults = true;
      r.continuous = false;
      liveRec = r;
      liveState = "listening";
      liveInterim = "";
      updateLiveUI();

      var captured = "";
      r.onresult = function (ev) {
        var s = "";
        for (var i = 0; i < ev.results.length; i++) {
          s += ev.results[i][0].transcript;
        }
        captured = s.trim();
        liveInterim = captured;
        if ($("eaTxt")) $("eaTxt").value = captured;
        updateLiveUI();
      };
      r.onend = function () {
        liveRec = null;
        var v = (captured || ($("eaTxt") && $("eaTxt").value) || "").trim();
        if (v) {
          if ($("eaTxt")) { $("eaTxt").value = ""; $("eaTxt").style.height = "auto"; }
          liveInterim = v;
          liveState = "thinking";
          updateLiveUI();
          ask(v, { fromVoice: true, continuousTurn: !!continuousTurn });
        } else {
          liveState = "idle";
          updateLiveUI();
        }
      };
      r.onerror = function (ev) {
        liveRec = null;
        liveState = "idle";
        updateLiveUI();
        if (ev && ev.error === "not-allowed") {
          UI.liveCall = false;
          updateLiveUI();
          toast("يرجى السماح للمتصفح باستخدام الميكروفون لتفعيل المحادثة الصوتية", "warning");
        }
      };
      r.start();
    } catch (e) {
      liveRec = null;
      liveState = "idle";
      updateLiveUI();
    }
  }

  function stopMic(keepCallState) {
    try { if (liveRec) { liveRec.onend = null; liveRec.stop(); } } catch (e) {}
    liveRec = null;
    if (!keepCallState) {
      liveState = "idle";
      liveInterim = "";
      updateLiveUI();
    }
  }

  function toggleMic() {
    if (liveState === "listening") {
      stopMic(false);
      return;
    }
    startListening(UI.liveCall);
  }

  function toggleLiveCall() {
    UI.liveCall = !UI.liveCall;
    if (UI.liveCall) {
      load();
      D.voice = true;
      save();
      UI.tab = "ask";
      render();
      var p = getPersona();
      toast("🎙️ بدأ الحوار الصوتي الحي مع " + p.name + " — تحدث بحرية!", "success");
      var greetMsg = "أهلاً بك يا " + (firstName() || "صديقي") + "! أنا " + p.name + " معك على الخط مباشرة. احكيلي، شو حابب نناقش أو نجهز اليوم؟";
      speakResponse(greetMsg, function () {
        if (UI.liveCall && isOpen()) {
          setTimeout(function () { if (UI.liveCall) startListening(true); }, 350);
        }
      });
    } else {
      stopSpeaking();
      stopMic(false);
      toast("تم إيقاف وضع الحوار الصوتي الحي", "info");
    }
    updateLiveUI();
  }

  // ------------------------------------------------------------------ 10) الأوامر المحلية الفورية والعقل الحواري البشري
  function toLatinDigits(s) {
    return String(s).replace(/[٠-٩]/g, function (d) { return "٠١٢٣٤٥٦٧٨٩".indexOf(d); }).replace(/[۰-۹]/g, function (d) { return "۰۱۲۳۴۵۶۷۸۹".indexOf(d); });
  }
  function safeCalc(expr) {
    var e = toLatinDigits(expr).replace(/×/g, "*").replace(/÷/g, "/").replace(/\^/g, "**").replace(/،/g, ".").replace(/٫/g, ".").replace(/\s+/g, "");
    if (!/^[0-9+\-*/().%*]+$/.test(e) || !/[0-9]/.test(e) || !/[+\-*/%]/.test(e)) return null;
    if (e.length > 80) return null;
    try {
      var v = Function('"use strict";return (' + e.replace(/(\d+(?:\.\d+)?)%/g, "($1/100)") + ")")();
      return (typeof v === "number" && isFinite(v)) ? Math.round(v * 1e9) / 1e9 : null;
    } catch (er) { return null; }
  }

  function detectPdfRequest(raw) {
    var q = String(raw || "").trim();
    var n = norm(q);
    var wantsPdf = /\bpdf\b|بي دي اف|بيدي اف|ملف جاهز للتحميل|نسخه جاهزه للتحميل|ورقه عمل|ورقة عمل|خطة درس|خطه درس|ملخص درس|تقرير pdf|تصدير المحادثه|حول المحادثه|امتحان توجيهي|بطاقه متابعه|بطاقة متابعة/.test(n);
    if (!wantsPdf) return null;

    var autoDownload = /حمل|نزّل|نزل|تصدير|صدر|جهز نسخة pdf|جهز لي نسخة pdf|اعطني ملف pdf/.test(n);
    if (/محادث|حوارنا|اللي حكيناه|ما تحدثنا/.test(n)) {
      return { tpl: "chatlog", topic: "توثيق محادثتي مع مساعدي الذكي", autoDownload: true };
    }
    if (/ولي الامر|ولي أمر|بطاقه متابعه|بطاقة متابعة/.test(n)) {
      return { tpl: "parent_card", topic: "تقرير متابعة الطالب وتوصيات الأسرة", autoDownload: autoDownload };
    }
    if (/مهامي|يومي|انجازي|خطتي الاسبوعيه|جدول مذاكر/.test(n)) {
      return { tpl: "studyplan", topic: "خطة المذاكرة وإنجاز المهام", autoDownload: autoDownload };
    }
    var tpl = /امتحان توجيهي|نموذج وزاري/.test(n) ? "tawjihi_exam" :
              /ورق[هة] عمل|تدريبات/.test(n) ? "worksheet" :
              /اختبار|امتحان|اسئله|أسئلة/.test(n) ? "quiz" :
              /خط[هة] درس|تحضير|5e/.test(n) ? "lesson5e" : "summary";

    var cleanTopic = q
      .replace(/^(?:لو سمحت|من فضلك|يا استاذ|يا معلمه|مساعدي)?\s*/i, "")
      .replace(/(?:جهز لي|جهزلي|جهز|اعمل لي|اعمللي|اعمل|اصنع لي|اصنع|انشئ|أنشئ|حضر لي|حضر|لخص لي|لخص|اكتب لي|اكتب|اريد|أريد|بدي|حول|صدّر|صدر|نزل|حمّل|حمل)\s*/gi, "")
      .replace(/(?:نسخة|نسخه|ملف|مستند|ورقة عمل|ورقه عمل|خطة درس|خطه درس|اختبار قصير|امتحان توجيهي|ملخص شامل|ملخص)?\s*(?:بصيغة|بصيغه|كملف)?\s*(?:pdf|بي دي اف|بيدي اف)?\s*(?:جاهزة للتحميل|جاهزه للتحميل|جاهز للتحميل|للتحميل)?\s*(?:عن|حول|في|لدرس|درس|بخصوص)?\s*/gi, "")
      .trim();

    if (!cleanTopic || cleanTopic.length < 2) {
      load();
      var prev = D.chat.slice(-4).reverse().filter(function (m) { return m.t && m.t.length > 10; })[0];
      cleanTopic = prev ? String(prev.raw || prev.t).replace(/<[^>]+>/g, "").slice(0, 55).trim() : "قوانين الحركة والفيزياء — التوجيهي";
    }
    return { tpl: tpl, topic: cleanTopic.slice(0, 90), autoDownload: autoDownload };
  }

  function localIntent(raw) {
    var q = toLatinDigits(raw).trim();
    var n = norm(q);
    var p = getPersona();
    var m;

    // 0) طلب حوار ثنائي / بودكاست حي
    if (/حوار ثنائي|بودكاست حي|شغل حوار|يتحاوران/.test(n)) {
      var podTopic = q.replace(/.*(?:حول|عن|في|لدرس)\s*/i, "").trim();
      setTimeout(function () { startDualPodcast(podTopic); }, 50);
      return { skipPush: true };
    }

    // 1) طلب تجهيز ملف PDF جاهز للتحميل
    var pdfReq = detectPdfRequest(q);
    if (pdfReq) {
      rememberTopic(pdfReq.topic);
      var docMd = buildOfflineDocumentMarkdown(pdfReq.tpl, pdfReq.topic, "الثانوية / التوجيهي", "المنهاج الفلسطيني", p);
      load();
      D.pdfDraft = {
        tpl: pdfReq.tpl,
        title: pdfReq.topic,
        grade: "الثانوية / التوجيهي",
        subject: "المنهاج الفلسطيني",
        body: docMd
      };
      save();
      var tplObj = PDF_TEMPLATES.filter(function (x) { return x.id === pdfReq.tpl; })[0] || PDF_TEMPLATES[0];
      return {
        isPdfDoc: true,
        pdfTitle: tplObj.label.replace(/^[^\s]+\s/, "") + " — " + pdfReq.topic,
        pdfBadge: tplObj.badge,
        raw: docMd,
        autoDownload: pdfReq.autoDownload,
        spokenIntro: "أبشر يا " + (firstName() || "صديقي") + "! جهزتُ لك نسخة بي دي إف كاملة مع المخطط البصري بعنوان " + pdfReq.topic + ". يمكنك تحميلها أو مشاركتها الآن بضغطة واحدة!"
      };
    }

    // 2) تبديل الشخصية بالصوت أو النص
    if (/تحدث بصوت|خليني احكي مع|حول ل|بدي احكي مع/.test(n)) {
      if (/بيان/.test(n)) { D.persona = "bayan"; save(); return { html: "👩‍🏫 أهلاً بك! معك الآن <b>المعلمة بيان</b> للغة العربية والإعراب والتشكيل. كيف أساعدك اليوم؟", raw: "أهلاً بك! معك الآن المعلمة بيان للغة العربية والإعراب والتشكيل. كيف أساعدك اليوم؟" }; }
      if (/صابرين/.test(n)) { D.persona = "sabreen"; save(); return { html: "📐 أهلاً بك! معك الآن <b>المعلمة صابرين أمين</b> للرياضيات والفيزياء. هات سؤالك أو صوّر المسألة بالكاميرا لنحلها خطوة بخطوة!", raw: "أهلاً بك! معك الآن المعلمة صابرين أمين للرياضيات والفيزياء. هات سؤالك لنحله خطوة بخطوة!" }; }
      if (/ليان/.test(n)) { D.persona = "layan"; save(); return { html: "🌍 Hello! معك الآن <b>المعلمة ليان (Teacher Layan)</b> للغة الإنجليزية. هيا نتحدث ونتعلم معاً!", raw: "أهلاً بك! معك الآن المعلمة ليان للغة الإنجليزية. هيا نتحدث ونتعلم معاً!" }; }
      if (/يزن/.test(n)) { D.persona = "yazan"; save(); return { html: "👦 يا هلا! معك زميلك <b>يزن</b>. جاهز ندرس ونسمّع مع بعض!", raw: "يا هلا! معك زميلك يزن. جاهز ندرس ونسمّع مع بعض!" }; }
      if (/باسل/.test(n)) { D.persona = "basel"; save(); return { html: "👨‍🏫 يا هلا بك! معك <b>الأستاذ باسل الفقعاوي</b>. تفضل، كلي آذان صاغية!", raw: "يا هلا بك! معك الأستاذ باسل الفقعاوي. تفضل، كلي آذان صاغية!" }; }
    }

    // 3) حساب رياضي سريع
    var c = safeCalc(q.replace(/^(احسب|كم يساوي|كم ناتج|ناتج)\s*/i, ""));
    if (c !== null) {
      return {
        html: "🧮 الناتج الدقيق هو: <b dir='ltr'>" + esc(String(c)) + "</b><br><small style='color:var(--ea-mut)'>هل تريد أن أشرح لك خطوات الحل أو نطبق بمعادلة أخرى؟</small>",
        raw: "الناتج الدقيق هو " + c + ". هل تريد أن أشرح لك خطوات الحل؟"
      };
    }

    // 4) مؤقت التركيز (بومودورو)
    if ((m = n.match(/(?:ركز|تركيز|مؤقت|ابدا مؤقت|عداد)\D*(\d{1,3})\s*(?:دقيقه|دقايق|دقائق|د)?/)) && /ركز|تركيز|مؤقت|عداد/.test(n)) {
      timerStart(+m[1]);
      return {
        html: "⏱️ ممتاز! شغّلتُ لك مؤقت التركيز لمدة <b>" + (+m[1]) + " دقيقة</b>. سأرافقك بهدوء وأنبّهك عند الانتهاء. بالتوفيق يا بطل!",
        raw: "ممتاز! شغلت لك مؤقت التركيز لمدة " + (+m[1]) + " دقيقة. بالتوفيق!",
        goto: "day:focus"
      };
    }
    if (/^(ركز|تركيز|ابدا تركيز|ابدا جلسه)/.test(n)) {
      timerStart(25);
      return {
        html: "⏱️ بدأت جلسة تركيز بومودورو لمدة <b>25 دقيقة</b>. ركّز في هدفك الآن وسأنبهك للاستراحة!",
        raw: "بدأت جلسة تركيز لمدة 25 دقيقة. ركز في هدفك الآن!",
        goto: "day:focus"
      };
    }

    // 5) إضافة مهمة
    if ((m = q.match(/^(?:ذكرني|ذكّرني|اضف مهمه|أضف مهمة|اضافه مهمه|مهمه|مهمة|سجل مهمه|سجّل مهمة)\s*[:：\-]?\s*(.+)$/i)) || (m = q.match(/^(?:ذكرني|ذكّرني)\s+(?:ان|أن|ب|بـ)?\s*(.+)$/i))) {
      var tx = /^(?:ذكرني|ذكّرني)/.test(q) ? m[1].replace(/^(?:بـ|ب(?=\S)|ان\s+|أن\s+)/, "") : m[1];
      var t = addTask(tx, /مهم|عاجل|مستعجل/.test(n));
      if (t) return {
        html: "✅ تكرم! أضفتُ المهمة إلى جدول يومك: <b>" + esc(t.t) + "</b>. هل نحدد لها جلسة تركيز الآن؟",
        raw: "تكرم! أضفت المهمة إلى جدول يومك: " + t.t + ". هل نحدد لها جلسة تركيز الآن؟",
        goto: "day:tasks"
      };
    }

    // 6) تدوين ملاحظة
    if ((m = q.match(/^(?:دون|دوّن|ملاحظه|ملاحظة|سجل ملاحظه|احفظ ملاحظه)\s*[:：\-]?\s*(.+)$/i))) {
      var nt = addNote(m[1]);
      if (nt) return {
        html: "📝 حفظتُ ملاحظتك فوراً: <b>" + esc(nt.t.slice(0, 90)) + "</b>. يمكنك أيضاً تصديرها كملف PDF متى شئت!",
        raw: "حفظت ملاحظتك فوراً. يمكنك تصديرها كملف بي دي إف متى شئت!",
        goto: "day:notes"
      };
    }

    // 7) عداد موعد / امتحان
    if ((m = q.match(/(?:موعد|امتحان|اختبار)\s+(?:بعد\s+)?(\d{1,3})\s*(?:يوم|ايام|أيام)/i)) && /بعد/.test(q)) {
      var dd = new Date(); dd.setDate(dd.getDate() + (+m[1]));
      load(); D.count = { t: /امتحان|اختبار/.test(q) ? "الامتحان القادم" : "الموعد المهم", d: dayKey(dd) }; save();
      return {
        html: "📆 ضبطتُ العدّاد التنازلي: <b>" + esc(D.count.t) + "</b> بعد <b>" + (+m[1]) + " يوماً</b>. تحب نجهز خطة مذاكرة PDF لهذه الأيام؟",
        raw: "ضبطت العداد التنازلي بعد " + (+m[1]) + " يوماً. تحب نجهز خطة مذاكرة بي دي إف لهذه الأيام؟",
        goto: "day:count"
      };
    }

    // 8) الوقت والتاريخ والمهام
    if (/^(كم الساعه|الساعه كم|كم الوقت|الوقت الان)$/.test(n)) {
      var tmStr = new Date().toLocaleTimeString("ar", { hour: "2-digit", minute: "2-digit" });
      return { html: "🕒 الساعة الآن <b>" + esc(tmStr) + "</b>. وقت ممتاز لإنجاز خطوة جديدة!", raw: "الساعة الآن " + tmStr + ". وقت ممتاز لإنجاز خطوة جديدة!" };
    }
    if (/^(ما التاريخ|تاريخ اليوم|اي يوم|شو اليوم|ايش اليوم|اليوم كم)$/.test(n)) {
      return { html: "📅 اليوم هو: <b>" + esc(dateLine()) + "</b>.", raw: "اليوم هو " + dateLine() };
    }
    if (/^(مهامي|ما مهامي|شو مهامي|عرض المهام|اعرض مهامي)$/.test(n)) {
      load(); var open = D.tasks.filter(function (x) { return !x.done; });
      return {
        html: open.length
          ? "📋 لديك <b>" + open.length + "</b> مهام مفتوحة اليوم:<br>" + open.slice(0, 6).map(function (x) { return "• " + (x.star ? "⭐ " : "") + esc(x.t); }).join("<br>") + "<br><small>بأي مهمة تحب أن نبدأ معاً؟</small>"
          : "🎉 لا توجد مهام معلقة حالياً! يومك صافٍ، هل نضيف هدفاً جديداً اليوم؟",
        raw: open.length ? "لديك " + open.length + " مهام مفتوحة اليوم. بأي مهمة تحب أن نبدأ؟" : "لا توجد مهام معلقة حالياً! هل نضيف هدفاً جديداً اليوم؟",
        goto: "day:tasks"
      };
    }

    // 9) فتح أداة من أدوات المنصة
    if (/^(افتح|شغل|شغّل|وديني على|انتقل الى)\s+/.test(q)) {
      var r = searchTools(q, 4);
      if (r.length && r[0].s >= 3 && (r.length === 1 || r[0].s >= r[1].s * 1.25)) {
        return {
          html: "🧰 بكل سرور! سأفتح لك الآن: <b>" + esc(r[0].a.ico + " " + r[0].a.title) + "</b>",
          raw: "بكل سرور! سأفتح لك الآن " + r[0].a.title,
          open: r[0].a.id,
          auto: true
        };
      }
      if (r.length) return { html: "🔎 وجدتُ لك هذه الأدوات القريبة، أيها تقصد؟", raw: "وجدت لك هذه الأدوات، أيها تقصد؟", tools: r.map(function (x) { return x.a; }) };
    }
    return null;
  }

  // ------------------------------------------------------------------ 11) محرك الحوار البشري المحلي + تحليل الصور المرفقة
  function generateHumanConversationalReply(userText, hasImages) {
    var q = String(userText || "").trim();
    var n = norm(q);
    var p = getPersona();
    var uName = firstName() || "صديقي";

    if (hasImages) {
      var imgTopic = q || "المسألة / الصفحة المصوّرة من الدفتر";
      rememberTopic(imgTopic);
      return "📷 **قرأتُ الصورة المرفقة وحلّلتُ عناصرها معك يا " + uName + "!**\n\n" +
        "[مخطط: تحليل الصورة المرفقة | قراءة المعطيات | القاعدة المعتمدة | الحل خطوة بخطوة | التحقق من النتيجة]\n\n" +
        "### 🔍 أولاً: قراءة المعطيات والمطلوب من الصورة\n" +
        "- **الموضوع المرصود:** «" + imgTopic + "».\n" +
        "- **الفكرة الأساسية:** تتطلب هذه المسألة تطبيق القاعدة المنهجية المباشرة مع الانتباه لترتيب الخطوات والوحدات.\n\n" +
        "### ✍️ ثانياً: خطوات الحل النموذجي بالتفصيل\n" +
        "1. **الخطوة الأولى (تجهيز القانون/القاعدة):** نكتب العلاقة الأساسية المرتبطة بالمعطيات الظاهرة في الورقة.\n" +
        "2. **الخطوة الثانية (التعويض والتبسيط):** نعوّض القيم المعطاة بدقة ونجري العمليات الحسابية أو الإعرابية بالتسلسل.\n" +
        "3. **الخطوة الثالثة (التحقق من صحة الحل ✓):** نراجع الناتج النهائي للتأكد من مطابقته لشروط السؤال.\n\n" +
        "💬 **هل تحب أن نحل فقرة مشابهة معاً لتثبيت الفكرة، أم تحمل هذا الحل المنسق كملف PDF من البطاقة أدناه؟**";
    }

    if (/^(مرحبا|اهلا|السلام عليكم|صباح الخير|مساء الخير|كيف حالك|كيفك|شو اخبارك|يسعد صباحك|يسعد مساك|هاي|هلا)/.test(n) && n.split(" ").length <= 6) {
      var memHint = (D && D.memoryTopics && D.memoryTopics.length)
        ? "\n- 🧠 **ذاكرتنا المشتركة:** لاحظتُ أننا ناقشنا مؤخراً **«" + D.memoryTopics[0].t + "»**، هل نكمل عليه اليوم؟"
        : "";
      return "يا أهلاً وسهلاً بك يا **" + uName + "**! أسعدتني بوجودك والله 🌟\n\n" +
        "أنا بخير وبأفضل حال طالما أنت معنا في **EduTech Mindset**. معك **" + p.fullName + "**، وأنا جاهز تماماً لنحكي ونتناقش كأننا جالسون معاً في الاستوديو!\n\n" +
        "- تحب نصوّر مسألة بالكاميرا (📷) لنحلها معاً، أو نشغّل **حواراً صوتياً ثنائياً (🎙️👥)**؟\n" +
        "- أم أجهز لك **ملف PDF احترافي بالرسوم التوضيحية** جاهز للتحميل؟" + memHint + "\n\n" +
        "**طمئنّي عنك أولاً، كيف تسير دراستك أو تحضيراتك اليوم؟**";
    }

    if (/من انت|مين انت|عرفني بنفسك|شو بتقدر تعمل|ماذا تستطيع/.test(n)) {
      return "أنا رفيقك ومساعدك الشخصي الحي في منصة **EduTech Mindset (عقلية التعليم والتكنولوجيا)**، أتحدث معك الآن بشخصية **" + p.fullName + "** (" + p.role + ").\n\n" +
        "### 💡 أهم قدراتي في الإصدار 151:\n" +
        "1. **✥ زر عائم ونافذة تتحرك بحرية على جوالك:** اسحب زري العائم أو رأس النافذة بإصبعك وضعه في أي مكان يناسبك على الشاشة!\n" +
        "2. **🎙️ حوار بشري حي وفردي أو ثنائي (بودكاست):** تحدث معي مباشرة بالصوت، أو اضغط **«🎙️👥 حوار ثنائي»** لتسمع نقاشاً ممتعاً بين معلمَين.\n" +
        "3. **📷 كاميرا قراءة المسائل والدفاتر:** صوّر أي مسألة أو صفحة كتاب لأشرحها وأحلها معك.\n" +
        "4. **📄 تجهيز ملفات PDF بالمخططات البصرية:** كل رد أو درس يتحول بضغطة زر إلى ملف PDF رسمي مع خريطة مفاهيمية مرسومة ورمز QR.\n\n" +
        "**جربني الآن! ما الموضوع الذي تود أن نحوله لملف PDF أو نتناقش فيه؟**";
    }

    if (/خايف|متوتر|تعبان|ملل|مش قادر ادرس|تراكم|صعب|مضغوط|قلق/.test(n)) {
      return "أفهمك تماماً يا **" + uName + "**، وشعورك طبيعي جداً ويدل على حرصك واهتمامك بمستقبلك 💚\n\n" +
        "اسمع مني هذه النصيحة المجربة في **EduTech Mindset**:\n" +
        "- **لا تنظر للجبل كله دفعة واحدة:** قسّم المادة إلى أجزاء صغيرة (25 دقيقة فقط لكل جزء) باستخدام قاعدة الـ 5 دقائق للبدء.\n" +
        "- **ابدأ بالأسهل لتكسر الحاجز النفسي:** إنجاز مهمة واحدة صغيرة يعيد لدماغك الثقة والحماس فوراً.\n\n" +
        "**ما رأيك أن نشغّل مؤقت تركيز لـ 15 دقيقة فقط الآن، وتخبرني باسم المادة لنبدأ بأول صفحة معاً؟**";
    }

    if (/بسط|ابسط|مثال ثاني|مثال اخر|ما فهمت|وضح اكثر|تعمق/.test(n)) {
      load();
      var lastTopic = (D.memoryTopics[0] && D.memoryTopics[0].t) || "الموضوع السابق";
      return "من عيوني يا **" + uName + "**! دعنا ننظر إلى **«" + lastTopic.slice(0, 60) + "»** من زاوية أبسط وأقرب للحياة اليومية:\n\n" +
        "### 💡 الفكرة ببساطة شديدة:\n" +
        "- تخيل أن أي قاعدة علمية أو لغوية هي مثل **مفتاح الباب**: نحتاج أولاً لمعرفة **متى نستخدمه** (المعطيات/الدلالات)، ثم **كيف نديره** (خطوة التطبيق)، وأخيراً **نتأكد أن الباب فتح** (التحقق من النتيجة).\n\n" +
        "**هل تحب أن نشغّل حواراً صوتياً ثنائياً حول هذه النقطة، أم أعطيك سؤالاً صغيراً نجرب حله معاً؟**";
    }

    if (/تسميع سقراطي|بطاقه اختبار|اختبر فهمي|اختبرني|سمعلي|سمّعلي/.test(n) && n.length < 55) {
      setTimeout(function () { startSocraticQuizCard(); }, 50);
      return "";
    }
    if (/اسالني|اسألني|سؤال/.test(n) && n.length < 35) {
      var quizTopic = (D && D.memoryTopics && D.memoryTopics[0] && D.memoryTopics[0].t) || "الدرس الحالي";
      return "يا سلام على الحماس يا **" + uName + "**! 🎯 هكذا تكون المذاكرة الذكية بالاستدعاء النشط!\n\n" +
        "### 🧠 سؤال التحدي السريع لك في «" + quizTopic + "»:\n" +
        "> **لخّص لي بأسلوبك الفكرة الأساسية أو القانون الرئيسي في هذا الدرس في جملتين، واذكر مثالاً واحداً عليه!**\n\n" +
        "**اكتب لي إجابتك أو قلها بالصوت، وسأقيّمها لك فوراً وأعطيك الملاحظة الذهبية عليها!**";
    }

    rememberTopic(q);
    var doc = buildOfflineDocumentMarkdown("summary", q, "المنهاج الفلسطيني", p.role, p);
    return "سؤال رائع ومهم جداً يا **" + uName + "**! دعني أشرحه لك بأسلوب واضح ومرتب مع مخطط مفاهيمي، وقد جهزته لك أيضاً بحيث يمكنك تحميله أو مشاركته كملف **PDF** بضغطة زر:\n\n" +
      doc + "\n\n" +
      "💬 **الآن دورك في الحوار:** أي نقطة من هذه النقاط لفتت انتباهك أكثر وتحب أن نفصّلها أو نسمع عنها حواراً ثنائياً؟";
  }

  function buildFollowUpChips(userText, replyText, msgIndex) {
    var chips = [
      { label: "📄 تحميل هذا الرد PDF", pdfIdx: msgIndex },
      { label: "🎙️👥 حوار ثنائي حوله", act: "dualpodcast" },
      { label: "💡 بسّطها بمثال آخر", ask: "بسّط لي الفكرة السابقة بمثال عملي أوضح" },
      { label: "🎯 اختبر فهمي (بطاقة تفاعلية)", act: "socraticquiz" }, { label: "🎙️📄 مذكرة صوتية لـ PDF", act: "voicenotepdf" }
    ];
    return '<div class="ea-follow">' + chips.map(function (c) {
      if (c.pdfIdx != null) {
        return '<button type="button" class="ea-fchip pdf" data-dl-pdf="' + c.pdfIdx + '">' + esc(c.label) + '</button>';
      }
      if (c.act) {
        return '<button type="button" class="ea-fchip" data-act="' + c.act + '">' + esc(c.label) + '</button>';
      }
      return '<button type="button" class="ea-fchip" data-ask="' + esc(c.ask) + '">' + esc(c.label) + '</button>';
    }).join("") + '</div>';
  }

  // ------------------------------------------------------------------ 12) الذكاء الاصطناعي وبناء البرومبت الحواري
  var BUSY = false;

  function buildPrompt(userText, hasImages) {
    var p = getPersona();
    var role = "";
    try { role = window.EduLauncher ? window.EduLauncher.getRole() : ""; } catch (e) {}
    var roleAr = { teacher: "معلم", student: "طالب", tawjihi: "طالب توجيهي", university: "طالب جامعي", parent: "ولي أمر", "public": "مستخدم عام" }[role] || "مستخدم";
    var hist = load().chat.slice(-10).map(function (m) {
      return (m.r === "u" ? "المستخدم: " : p.name + ": ") + String(m.raw || m.t).replace(/<[^>]+>/g, " ").slice(0, 500);
    }).join("\n");
    var mems = (D.memoryTopics || []).slice(0, 4).map(function (x) { return x.t; }).join("، ");

    return "أنت الآن «مساعدي»، المساعد الحواري البشري الذكي في منصة EduTech Mindset للتعليم والتكنولوجيا (فلسطين — بإشراف الأستاذ باسل أشرف الفقعاوي).\n" +
      p.stylePrompt + "\n" +
      "قواعد الحوار المهمة جداً:\n" +
      "1) تحدث كإنسان حقيقي يحاور صديقه أو طالبه باهتمام ودفء، وخذ وأعطِ معه في الكلام.\n" +
      "2) ضمّن في بداية شرحك الدروس العلمية سطراً بصيغة: [مخطط: عنوان الموضوع | فرع 1 | فرع 2 | فرع 3 | فرع 4] ليترجم تلقائياً إلى رسم مخطط مفاهيمي داخل الـ PDF، ونظّم إجابتك بعناوين (# و ##) وجداول Markdown.\n" +
      (hasImages ? "3) المستخدم أرفق صورة مسألة أو صفحة كتاب/دفتر: اقرأ ما فيها بدقة (بما فيه العربية والمعادلات) واشرح الحل خطوة بخطوة مع التحقق.\n" : "") +
      "4) اختم إجابتك دائماً بسؤال حواري ذكي يدعو المستخدم لمواصلة النقاش أو تجربة مثال أو تحميل الشرح كملف PDF.\n" +
      "بيانات المستخدم: الاسم (" + (firstName() || "صديقي") + ")، الصفة (" + roleAr + ")" + (mems ? "، اهتماماته ودروسه الأخيرة (" + mems + ")" : "") + ".\n" +
      (hist ? "سياق الحوار السابق:\n" + hist + "\n" : "") +
      "المستخدم يقول الآن: " + userText + "\n" +
      "رد " + p.name + ":";
  }

  function mdRich(s) {
    if (window.Exporter && typeof window.Exporter.render === "function") {
      try { return '<div class="ea-rich">' + window.Exporter.render(s) + '</div>'; } catch (e) {}
    }
    var t = esc(s);
    t = t.replace(/```([\s\S]*?)```/g, function (_, c) { return "<pre dir='ltr'>" + c.trim() + "</pre>"; });
    t = t.replace(/`([^`\n]+)`/g, "<code>$1</code>").replace(/\*\*([^*\n]+)\*\*/g, "<b>$1</b>");
    t = t.replace(/^#{1,4}\s*(.+)$/gm, "<b>$1</b>");
    t = t.replace(/(^|\n)\s*(?:[-*•]|\d+[.)])\s+(.+)/g, "$1• $2");
    return t.replace(/\n/g, "<br>");
  }

  // ------------------------------------------------------------------ 13) التصميم المتقدم (CSS) + دعم السحب والتحريك السلس على الجوال
  var CSS = "" +
    "#eduAsstOrb{position:fixed;left:14px;bottom:84px;z-index:2147482800;width:58px;height:58px;border-radius:50%;border:2.5px solid rgba(255,255,255,.45);cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none;color:#fff;font-size:25px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#0284c7,#4f46e5 55%,#9333ea);box-shadow:0 10px 28px rgba(79,70,229,.55);transition:transform .18s,box-shadow .18s}" +
    "#eduAsstOrb:hover{transform:scale(1.07)}" +
    "#eduAsstOrb.dragging{cursor:grabbing;transform:scale(1.14)!important;box-shadow:0 16px 38px rgba(2,132,199,.8)!important;transition:none!important}" +
    "#eduAsstOrb .eab{position:absolute;top:-6px;right:-6px;min-width:20px;padding:0 5px;height:20px;border-radius:10px;background:#f43f5e;color:#fff;font:800 10px/20px Cairo,system-ui,sans-serif;text-align:center;display:none;pointer-events:none}" +
    "#eduAsstOrb.run .eab{display:block;background:#10b981}" +
    "#eduAsstOrb .ea-drag-hint{position:absolute;bottom:-19px;left:50%;transform:translateX(-50%);white-space:nowrap;background:rgba(15,23,42,.88);color:#fde68a;border:1px solid rgba(245,158,11,.45);border-radius:999px;padding:1px 6px;font:800 9px/1.3 Cairo,sans-serif;pointer-events:none;box-shadow:0 2px 6px rgba(0,0,0,.3)}" +
    "@media(prefers-reduced-motion:no-preference){#eduAsstOrb::after{content:'';position:absolute;inset:-5px;border-radius:50%;border:2px solid rgba(99,102,241,.55);animation:eaPulse 2.6s infinite;pointer-events:none}}" +
    "@keyframes eaPulse{0%{transform:scale(.9);opacity:.9}100%{transform:scale(1.35);opacity:0}}" +
    "#eduAsst{--ea-bg:#fff;--ea-fg:#0f172a;--ea-mut:#64748b;--ea-line:#e2e8f0;--ea-soft:#f1f5f9;--ea-acc:#4f46e5;position:fixed;z-index:2147482700;inset:auto 0 0 0;height:min(88dvh,750px);display:none;flex-direction:column;background:var(--ea-bg);color:var(--ea-fg);border-radius:24px 24px 0 0;box-shadow:0 -14px 55px rgba(2,6,23,.45);font-family:Cairo,Tajawal,system-ui,sans-serif;direction:rtl;overflow:hidden}" +
    "#eduAsst.dock-top{inset:0 0 auto 0;border-radius:0 0 24px 24px;box-shadow:0 14px 55px rgba(2,6,23,.45)}" +
    "#eduAsst.dock-float{inset:auto;width:min(94vw,440px);height:min(76dvh,640px);border-radius:22px;border:1.5px solid var(--ea-line);box-shadow:0 20px 60px rgba(2,6,23,.55)}" +
    "html.dark #eduAsst,.dark #eduAsst{--ea-bg:#0f172a;--ea-fg:#f1f5f9;--ea-mut:#94a3b8;--ea-line:#1e293b;--ea-soft:#1e293b;--ea-acc:#38bdf8}" +
    "#eduAsst.open{display:flex;animation:eaUp .22s ease-out}@keyframes eaUp{from{transform:translateY(18px);opacity:0}to{transform:none;opacity:1}}" +
    "@media(min-width:720px){#eduAsst{inset:auto auto 88px 18px;width:470px;height:min(82dvh,740px);border-radius:24px;border:1px solid var(--ea-line)}#eduAsst.wide{width:min(780px,92vw);height:min(88dvh,800px)}}" +
    "#eduAsst *{box-sizing:border-box}#eduAsst button{font-family:inherit;cursor:pointer}" +
    ".ea-grip{width:42px;height:4px;border-radius:4px;background:rgba(255,255,255,.4);margin:0 auto 5px;cursor:grab}" +
    ".ea-hd{padding:8px 12px 10px;background:linear-gradient(135deg,#082f49,#0284c7 52%,#4f46e5);color:#fff;border-bottom:2px solid #f59e0b;touch-action:none;user-select:none}" +
    ".ea-hd-row{display:flex;align-items:center;gap:7px}" +
    ".ea-hd b{font-size:14px;display:flex;align-items:center;gap:6px}.ea-hd small{display:block;font-size:10px;color:#bae6fd;font-weight:700}.ea-hd .sp{flex:1}" +
    ".ea-ib{border:0;background:rgba(255,255,255,.16);color:#fff;border-radius:10px;min-width:30px;height:30px;padding:0 6px;font-size:12.5px;font-weight:800;display:inline-flex;align-items:center;justify-content:center;gap:3px;transition:background .15s}.ea-ib:hover{background:rgba(255,255,255,.28)}" +
    ".ea-ib.on{background:#10b981;color:#fff;box-shadow:0 0 12px rgba(16,185,129,.5)}" +
    "#eaCallBtn.on{background:#f43f5e;animation:eaPulse 1.5s infinite}" +
    ".ea-tabs{display:grid;grid-template-columns:repeat(4,1fr);gap:4px;padding:6px;background:var(--ea-soft);border-bottom:1px solid var(--ea-line)}" +
    ".ea-tab{border:0;border-radius:11px;padding:7px 4px;font-weight:800;font-size:12px;background:transparent;color:var(--ea-mut);transition:all .15s}.ea-tab.on{background:var(--ea-bg);color:var(--ea-acc);box-shadow:0 2px 6px rgba(0,0,0,.1)}" +
    ".ea-pbar{display:flex;gap:5px;overflow-x:auto;padding:6px 10px;background:var(--ea-bg);border-bottom:1px solid var(--ea-line);scrollbar-width:none;align-items:center}.ea-pbar::-webkit-scrollbar{display:none}" +
    ".ea-pbtn{flex:none;display:inline-flex;align-items:center;gap:4px;padding:4px 9px;border-radius:999px;border:1.5px solid var(--ea-line);background:var(--ea-soft);color:var(--ea-fg);font-size:11px;font-weight:800;transition:all .15s}" +
    ".ea-pbtn.on{background:linear-gradient(135deg,#0284c7,#4f46e5);color:#fff;border-color:transparent;box-shadow:0 3px 10px rgba(2,132,199,.3)}" +
    ".ea-pbtn.pod{background:linear-gradient(135deg,#d97706,#e11d48);color:#fff;border-color:transparent}" +
    "#eaLiveBar{display:none;align-items:center;gap:10px;padding:9px 12px;background:linear-gradient(135deg,#0f172a,#1e1b4b);color:#fff;border-bottom:1px solid rgba(255,255,255,.12);cursor:pointer}" +
    "#eaLiveBar[data-state='listening']{background:linear-gradient(135deg,#064e3b,#0f172a)}" +
    "#eaLiveBar[data-state='speaking']{background:linear-gradient(135deg,#0c4a6e,#1e1b4b)}" +
    ".ea-wave{display:flex;align-items:center;gap:3px;height:24px;padding:0 4px}" +
    ".ea-wave i{display:block;width:4px;height:8px;border-radius:4px;background:#38bdf8;transition:height .15s}" +
    "#eaLiveBar[data-state='listening'] .ea-wave i{background:#34d399;animation:eaWv .7s infinite ease-in-out}" +
    "#eaLiveBar[data-state='speaking'] .ea-wave i{background:#fbbf24;animation:eaWv .55s infinite ease-in-out}" +
    ".ea-wave i:nth-child(2){animation-delay:.12s}.ea-wave i:nth-child(3){animation-delay:.24s}.ea-wave i:nth-child(4){animation-delay:.16s}.ea-wave i:nth-child(5){animation-delay:.08s}" +
    "@keyframes eaWv{0%,100%{height:7px}50%{height:22px}}" +
    ".ea-body{flex:1;min-height:0;overflow-y:auto;padding:11px;-webkit-overflow-scrolling:touch}" +
    ".ea-msg{max-width:94%;padding:10px 13px;border-radius:18px;margin:0 0 10px;font-size:13px;line-height:1.8;word-wrap:break-word;position:relative}" +
    ".ea-msg.u{background:linear-gradient(135deg,#0284c7,#4f46e5);color:#fff;margin-inline-start:auto;border-end-end-radius:4px;font-weight:700}" +
    ".ea-msg.a{background:var(--ea-soft);border:1px solid var(--ea-line);border-end-start-radius:4px}" +
    ".ea-mhd{display:flex;align-items:center;gap:6px;font-size:11px;font-weight:900;color:var(--ea-acc);margin-bottom:5px;padding-bottom:4px;border-bottom:1px dashed var(--ea-line)}" +
    ".ea-rich h3,.ea-rich h4,.ea-rich h5{margin:8px 0 4px;font-size:13.5px;font-weight:900;color:var(--ea-acc)}" +
    ".ea-rich p{margin:0 0 6px}.ea-rich ul,.ea-rich ol{margin:4px 0 8px;padding-right:18px}.ea-rich li{margin-bottom:3px}" +
    ".ea-rich blockquote{margin:6px 0;padding:6px 10px;border-right:3px solid #f59e0b;background:rgba(245,158,11,.1);border-radius:8px;font-size:12px;font-weight:700}" +
    ".ea-rich .ex-tbl{overflow-x:auto;margin:6px 0}.ea-rich table{width:100%;border-collapse:collapse;font-size:11.5px}.ea-rich th,.ea-rich td{border:1px solid var(--ea-line);padding:5px 7px;text-align:right}.ea-rich th{background:rgba(2,132,199,.12);font-weight:900}" +
    ".ea-msg pre{background:#0f172a;color:#e2e8f0;padding:8px;border-radius:10px;overflow-x:auto;font-size:12px;white-space:pre-wrap}.ea-msg code{background:rgba(99,102,241,.15);padding:0 4px;border-radius:5px}" +
    ".ea-mbar{display:flex;flex-wrap:wrap;gap:5px;margin-top:8px;padding-top:7px;border-top:1px dashed var(--ea-line)}" +
    ".ea-mbtn{border:1px solid var(--ea-line);background:var(--ea-bg);color:var(--ea-fg);border-radius:9px;padding:4px 8px;font-size:11px;font-weight:800;display:inline-flex;align-items:center;gap:4px;transition:all .15s}" +
    ".ea-mbtn:hover{border-color:var(--ea-acc);color:var(--ea-acc)}" +
    ".ea-mbtn.pdf{background:#e11d48;color:#fff;border-color:#e11d48}.ea-mbtn.pdf:hover{background:#be123c;color:#fff}" +
    ".ea-mbtn.word{background:#0284c7;color:#fff;border-color:#0284c7}.ea-mbtn.word:hover{background:#0369a1;color:#fff}" +
    ".ea-follow{display:flex;flex-wrap:wrap;gap:5px;margin-top:7px}" +
    ".ea-fchip{border:1px dashed var(--ea-acc);background:rgba(79,70,229,.06);color:var(--ea-acc);border-radius:999px;padding:4px 9px;font-size:11px;font-weight:800;transition:all .15s}" +
    ".ea-fchip:hover{background:var(--ea-acc);color:#fff}" +
    ".ea-fchip.pdf{border-color:#e11d48;color:#e11d48;background:rgba(225,29,72,.08)}.ea-fchip.pdf:hover{background:#e11d48;color:#fff}" +
    ".ea-pdf-card{margin-top:9px;padding:11px;border-radius:15px;background:linear-gradient(135deg,rgba(12,74,110,.08),rgba(245,158,11,.12));border:1.5px solid #f59e0b}" +
    ".ea-pdf-top{display:flex;align-items:center;gap:10px;margin-bottom:9px}" +
    ".ea-pdf-ico{font-size:28px;line-height:1}" +
    ".ea-pdf-badge{font-size:10.5px;font-weight:900;color:#d97706}" +
    ".ea-pdf-title{font-size:13px;font-weight:900;color:var(--ea-fg);line-height:1.4}" +
    ".ea-pdf-sub{font-size:10.5px;color:var(--ea-mut);font-weight:700}" +
    ".ea-pdf-btns{display:flex;flex-wrap:wrap;gap:5px}" +
    ".ea-pdf-dl{flex:1;min-width:120px;border:0;border-radius:11px;padding:8px 10px;background:linear-gradient(135deg,#e11d48,#be123c);color:#fff;font-size:11.5px;font-weight:900;box-shadow:0 4px 12px rgba(225,29,72,.3)}" +
    ".ea-pdf-sh{border:0;border-radius:11px;padding:8px 10px;background:#059669;color:#fff;font-size:11.5px;font-weight:800}" +
    ".ea-pdf-w{border:0;border-radius:11px;padding:8px 10px;background:#0284c7;color:#fff;font-size:11.5px;font-weight:800}" +
    ".ea-pdf-edit{border:1px solid var(--ea-line);border-radius:11px;padding:7px 9px;background:var(--ea-bg);color:var(--ea-fg);font-size:11px;font-weight:800}" +
    ".ea-chips{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0 10px}" +
    ".ea-chip{border:1px solid var(--ea-line);background:var(--ea-bg);color:var(--ea-fg);border-radius:999px;padding:6px 11px;font-size:11.5px;font-weight:800}.ea-chip:hover{border-color:var(--ea-acc);color:var(--ea-acc)}" +
    ".ea-tool{display:flex;align-items:center;gap:10px;width:100%;text-align:right;border:1px solid var(--ea-line);background:var(--ea-bg);color:var(--ea-fg);border-radius:14px;padding:9px 11px;margin-bottom:7px}.ea-tool:hover{border-color:var(--ea-acc)}" +
    ".ea-tool .i{font-size:22px}.ea-tool .t{font-weight:800;font-size:12.5px;line-height:1.5}.ea-tool .d{font-size:11px;color:var(--ea-mut);line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.ea-tool .s{margin-inline-start:auto;border:0;background:none;font-size:18px;color:var(--ea-mut)}" +
    "#eaAttStrip{display:none;gap:6px;padding:6px 10px;background:var(--ea-soft);border-top:1px solid var(--ea-line);overflow-x:auto}" +
    ".ea-att-item{display:inline-flex;align-items:center;gap:6px;padding:4px 8px;border-radius:10px;background:var(--ea-bg);border:1px solid var(--ea-line);font-size:11px;font-weight:700}" +
    ".ea-att-item img{width:28px;height:28px;object-fit:cover;border-radius:6px}" +
    ".ea-att-name{max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}" +
    ".ea-att-rm{border:0;background:#f43f5e;color:#fff;width:18px;height:18px;border-radius:50%;font-size:10px;line-height:18px;text-align:center}" +
    ".ea-in{display:flex;gap:5px;align-items:flex-end;padding:8px 9px;border-top:1px solid var(--ea-line);background:var(--ea-bg)}" +
    ".ea-in textarea,.ea-field{flex:1;resize:none;border:1px solid var(--ea-line);background:var(--ea-soft);color:var(--ea-fg);border-radius:14px;padding:8px 10px;font:600 13px/1.6 Cairo,system-ui,sans-serif;max-height:110px;outline:none}.ea-in textarea:focus,.ea-field:focus{border-color:var(--ea-acc)}" +
    ".ea-go{border:0;border-radius:13px;width:38px;height:38px;color:#fff;font-size:15px;background:linear-gradient(135deg,#0284c7,#4f46e5)}" +
    ".ea-mic,.ea-cam{border:1px solid var(--ea-line);background:var(--ea-soft);color:var(--ea-fg);border-radius:13px;width:38px;height:38px;font-size:15px;display:inline-flex;align-items:center;justify-content:center}" +
    ".ea-mic.rec{background:#f43f5e;color:#fff;border-color:#f43f5e;animation:eaPulse 1.2s infinite}" +
    ".ea-pdfq{border:1px solid rgba(225,29,72,.35);background:rgba(225,29,72,.1);color:#e11d48;border-radius:13px;height:38px;padding:0 9px;font-size:11px;font-weight:900;display:flex;align-items:center;gap:3px;white-space:nowrap}" +
    ".ea-pdfq:hover{background:#e11d48;color:#fff}" +
    ".ea-card{border:1px solid var(--ea-line);border-radius:16px;padding:11px;margin-bottom:10px;background:var(--ea-bg)}.ea-card h4{margin:0 0 7px;font-size:12.5px;font-weight:900}" +
    ".ea-sub{display:flex;gap:5px;overflow-x:auto;margin-bottom:10px;padding-bottom:2px}.ea-sub button{flex:none;border:1px solid var(--ea-line);background:var(--ea-bg);color:var(--ea-mut);border-radius:999px;padding:6px 12px;font-size:12px;font-weight:800}.ea-sub button.on{background:var(--ea-acc);color:#fff;border-color:var(--ea-acc)}" +
    ".ea-row{display:flex;align-items:center;gap:8px;padding:8px 4px;border-bottom:1px dashed var(--ea-line);font-size:13px;font-weight:600}.ea-row:last-child{border:0}.ea-row.done span.x{text-decoration:line-through;opacity:.5}.ea-row .x{flex:1;line-height:1.6;word-break:break-word}" +
    ".ea-row input[type=checkbox]{width:19px;height:19px;accent-color:#4f46e5}.ea-del{border:0;background:none;color:var(--ea-mut);font-size:15px}.ea-star{border:0;background:none;font-size:16px;opacity:.35}.ea-star.on{opacity:1}" +
    ".ea-add{display:flex;gap:6px;margin-bottom:8px}.ea-btn{border:0;border-radius:12px;padding:8px 13px;font-weight:800;font-size:12px;color:#fff;background:linear-gradient(135deg,#0284c7,#4f46e5)}.ea-btn.g{background:var(--ea-soft);color:var(--ea-fg);border:1px solid var(--ea-line)}.ea-btn.r{background:#e11d48}" +
    ".ea-ring{--p:0;width:86px;height:86px;border-radius:50%;background:conic-gradient(var(--ea-acc) calc(var(--p)*1%),var(--ea-soft) 0);display:flex;align-items:center;justify-content:center;flex:none}.ea-ring i{font-style:normal;width:66px;height:66px;border-radius:50%;background:var(--ea-bg);display:flex;align-items:center;justify-content:center;font-weight:900;font-size:17px}" +
    ".ea-hero{display:flex;align-items:center;gap:11px;margin-bottom:11px}.ea-hero b{font-size:14px;display:block}.ea-hero small{color:var(--ea-mut);font-size:11px;font-weight:700;line-height:1.7;display:block}" +
    ".ea-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-bottom:10px}.ea-stat{background:var(--ea-soft);border-radius:14px;padding:9px 4px;text-align:center}.ea-stat b{display:block;font-size:17px;color:var(--ea-acc)}.ea-stat small{font-size:10.5px;color:var(--ea-mut);font-weight:700}" +
    ".ea-tm{font:900 44px/1 Cairo,monospace;text-align:center;margin:6px 0 10px;letter-spacing:2px;direction:ltr}" +
    ".ea-empty{text-align:center;color:var(--ea-mut);font-size:12.5px;font-weight:700;padding:18px 8px;line-height:1.8}" +
    ".ea-typing span{display:inline-block;width:6px;height:6px;margin:0 2px;border-radius:50%;background:var(--ea-mut);animation:eaDot 1s infinite}.ea-typing span:nth-child(2){animation-delay:.15s}.ea-typing span:nth-child(3){animation-delay:.3s}@keyframes eaDot{0%,80%,100%{opacity:.25;transform:scale(.8)}40%{opacity:1;transform:scale(1.1)}}" +
    ".ea-hab{display:flex;align-items:center;gap:9px;padding:9px;border:1px solid var(--ea-line);border-radius:14px;margin-bottom:7px;font-weight:700;font-size:13px}.ea-hab.ok{background:rgba(16,185,129,.12);border-color:rgba(16,185,129,.4)}.ea-hab .fl{margin-inline-start:auto;font-size:11px;color:var(--ea-mut);font-weight:800}" +
    ".ea-menu-drawer{position:absolute;inset:56px 10px auto 10px;z-index:220;background:var(--ea-bg);border:1.5px solid var(--ea-line);border-radius:18px;padding:12px;box-shadow:0 18px 40px rgba(0,0,0,.32);display:none}" +
    ".ea-menu-drawer.open{display:block;animation:eaUp .18s ease-out}" +
    ".ea-menu-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:8px}" +
    ".ea-mitem{border:1px solid var(--ea-line);background:var(--ea-soft);color:var(--ea-fg);border-radius:12px;padding:8px 10px;font-size:11px;font-weight:800;text-align:right;display:flex;align-items:center;gap:6px}" +
    ".ea-mitem:hover{border-color:var(--ea-acc);color:var(--ea-acc)}" +
    "#eaSelPop{position:fixed;z-index:2147482600;display:none;align-items:center;gap:4px;padding:5px 8px;border-radius:999px;background:#0f172a;color:#fff;border:1.5px solid #f59e0b;box-shadow:0 10px 28px rgba(0,0,0,.45);font-family:Cairo,sans-serif;direction:rtl}" +
    "#eaSelPop button{border:0;background:rgba(255,255,255,.12);color:#fff;border-radius:999px;padding:4px 9px;font:800 11px Cairo,sans-serif;cursor:pointer}" +
    "#eaSelPop button:hover{background:#0284c7}" +
    "#eduAsstOrb.mag-anim{transition:left .26s cubic-bezier(.2,.9,.3,1),top .26s,transform .28s,opacity .28s}" +
    "#eduAsstOrb.peek-left{transform:translateX(-54%) scale(.92);opacity:.66}" +
    "#eduAsstOrb.peek-right{transform:translateX(54%) scale(.92);opacity:.66}" +
    "#eduAsstOrb.peek-left:hover,#eduAsstOrb.peek-right:hover{transform:none;opacity:1}" +
    ".ea-qcard{margin-top:9px;padding:12px;border-radius:16px;background:linear-gradient(135deg,rgba(79,70,229,.08),rgba(2,132,199,.1));border:1.5px solid rgba(79,70,229,.35)}" +
    ".ea-qtop{display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:8px;font-size:11px;font-weight:900;color:var(--ea-acc)}" +
    ".ea-qq{font-size:13px;font-weight:900;margin-bottom:9px;line-height:1.6;color:var(--ea-fg)}" +
    ".ea-qopts{display:grid;grid-template-columns:1fr;gap:6px}" +
    ".ea-qopt{width:100%;text-align:right;padding:8px 11px;border-radius:11px;border:1.5px solid var(--ea-line);background:var(--ea-bg);color:var(--ea-fg);font-size:12px;font-weight:800;transition:all .15s;display:flex;align-items:center;justify-content:space-between}" +
    ".ea-qopt:hover{border-color:var(--ea-acc)}" +
    ".ea-qopt.ok{background:rgba(16,185,129,.18);border-color:#10b981;color:#065f46}html.dark .ea-qopt.ok{color:#6ee7b7}" +
    ".ea-qopt.bad{background:rgba(244,63,94,.18);border-color:#f43f5e;color:#9f1239}html.dark .ea-qopt.bad{color:#fda4af}" +
    ".ea-qexp{margin-top:8px;padding:8px 10px;border-radius:10px;background:rgba(16,185,129,.12);border-right:3px solid #10b981;font-size:11.5px;font-weight:700}" +
    "#eaReelModal{position:fixed;inset:0;z-index:2147482950;background:rgba(2,6,23,.82);backdrop-filter:blur(8px);display:none;align-items:center;justify-content:center;padding:12px;font-family:Cairo,sans-serif;direction:rtl}" +
    "#eaReelModal.open{display:flex}" +
    ".ea-reel-frame{width:min(360px,92vw);aspect-ratio:9/16;max-height:88dvh;border-radius:28px;background:linear-gradient(165deg,#082f49 0%,#0f172a 52%,#1e1b4b 100%);border:2.5px solid #f59e0b;box-shadow:0 24px 70px rgba(0,0,0,.75);color:#fff;display:flex;flex-direction:column;justify-content:space-between;padding:16px;position:relative;overflow:hidden}" +
    ".ea-reel-bars{display:flex;gap:4px;margin-bottom:10px}" +
    ".ea-reel-bars span{flex:1;height:3.5px;border-radius:4px;background:rgba(255,255,255,.22);overflow:hidden}" +
    ".ea-reel-bars span.on{background:#fbbf24}" +
    ".ea-reel-body{my:auto;text-align:center;padding:10px 6px;space-y:10px}" +
    ".ea-reel-slide-t{font-size:19px;font-weight:900;color:#fbbf24;line-height:1.45;margin-bottom:12px;text-shadow:0 2px 10px rgba(0,0,0,.4)}" +
    ".ea-reel-slide-b{font-size:13.5px;font-weight:700;color:#f8fafc;line-height:1.85;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:18px;padding:14px}" +
    "#eduAsst.eye-care{--ea-bg:#fdf6e3;--ea-fg:#3f2e18;--ea-mut:#7c6343;--ea-line:#e6d5b8;--ea-soft:#f5ebd6;--ea-acc:#b45309}" +
    "#eduAsst.eye-care .ea-msg{font-size:15px;line-height:2.1}" +
    ".ea-xp-pill{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:999px;background:rgba(245,158,11,.22);color:#fde68a;font:900 10.5px Cairo,sans-serif}" +
    "#eaDrawModal,#eaClassModal{position:fixed;inset:0;z-index:2147482960;background:rgba(2,6,23,.8);backdrop-filter:blur(6px);display:none;align-items:center;justify-content:center;padding:12px;font-family:Cairo,sans-serif;direction:rtl}" +
    "#eaDrawModal.open,#eaClassModal.open{display:flex}" +
    ".ea-submodal{width:min(460px,95vw);background:var(--ea-bg,#0f172a);color:var(--ea-fg,#f8fafc);border:1.5px solid #0284c7;border-radius:22px;padding:16px;box-shadow:0 24px 60px rgba(0,0,0,.6);max-height:90dvh;overflow:auto}" +
    "#eaDrawCanvas{width:100%;height:240px;background:#ffffff;border:2px solid #cbd5e1;border-radius:14px;touch-action:none;cursor:crosshair;display:block}" +
    ".ea-sym-bar{display:flex;flex-wrap:wrap;gap:5px;margin:8px 0}" +
    ".ea-sym-btn{border:1px solid #cbd5e1;background:#f8fafc;color:#0f172a;border-radius:8px;padding:4px 9px;font:800 13px Cairo,sans-serif;cursor:pointer}" +
"@media(prefers-reduced-motion:reduce){#eduAsst.open,#eduAsstOrb::after,.ea-typing span,.ea-wave i{animation:none}}";

  // ------------------------------------------------------------------ 14) السحب والتحريك الحر لزر المساعد (#eduAsstOrb) والنافذة (#eduAsst) على الجوال والكمبيوتر
  var UI = { tab: "ask", sub: "tasks", built: false, q: "", liveCall: false, wide: false, menuOpen: false };
  var suppressNextOrbClick = false;

  function clamp(val, min, max) {
    return Math.max(min, Math.min(max, val));
  }

  var orbPeekTimer = null;

  function wakeOrb() {
    clearTimeout(orbPeekTimer);
    var orb = $("eduAsstOrb");
    if (!orb) return;
    orb.classList.remove("peek-left", "peek-right");
    scheduleOrbPeek();
  }

  function scheduleOrbPeek() {
    clearTimeout(orbPeekTimer);
    orbPeekTimer = setTimeout(function () {
      var orb = $("eduAsstOrb");
      if (!orb || isOpen() || T.run) return;
      load();
      if (!D.magSnap) return;
      var rect = orb.getBoundingClientRect();
      var vw = window.innerWidth || 360;
      if (rect.left <= 24) {
        orb.classList.add("peek-left");
      } else if (vw - rect.right <= 24) {
        orb.classList.add("peek-right");
      }
    }, 4200);
  }

  function applyOrbPosition() {
    var orb = $("eduAsstOrb");
    if (!orb) return;
    load();
    var vw = window.innerWidth || 360;
    var vh = window.innerHeight || 640;
    var w = orb.offsetWidth || 58;
    var h = orb.offsetHeight || 58;
    orb.classList.remove("peek-left", "peek-right");
    if (D.orbPos && typeof D.orbPos.xPct === "number" && typeof D.orbPos.yPct === "number") {
      var leftPx = clamp(Math.round(D.orbPos.xPct * vw), 6, Math.max(6, vw - w - 6));
      var topPx = clamp(Math.round(D.orbPos.yPct * vh), 6, Math.max(6, vh - h - 22));
      if (D.magSnap && D.orbPos.edge === "left") leftPx = 6;
      else if (D.magSnap && D.orbPos.edge === "right") leftPx = Math.max(6, vw - w - 6);
      orb.style.left = leftPx + "px";
      orb.style.top = topPx + "px";
      orb.style.right = "auto";
      orb.style.bottom = "auto";
    } else {
      orb.style.left = "10px";
      orb.style.bottom = "84px";
      orb.style.top = "auto";
      orb.style.right = "auto";
    }
    scheduleOrbPeek();
  }

  function resetOrbAndPanelPosition() {
    load();
    D.orbPos = null;
    D.panelDock = "bottom";
    D.panelPos = null;
    save();
    applyOrbPosition();
    applyPanelDock();
    toast("📍 تم إرجاع زر المساعد والنافذة إلى الموضع الافتراضي", "success");
  }

  function makeDraggableOrb(orb) {
    var active = false;
    var startX = 0, startY = 0, origLeft = 0, origTop = 0, moved = false;

    function onStart(clientX, clientY) {
      wakeOrb();
      var rect = orb.getBoundingClientRect();
      active = true;
      moved = false;
      startX = clientX;
      startY = clientY;
      origLeft = rect.left;
      origTop = rect.top;
    }

    function onMove(clientX, clientY, ev) {
      if (!active) return;
      var dx = clientX - startX;
      var dy = clientY - startY;
      if (!moved && Math.hypot(dx, dy) < 7) return;
      if (!moved) {
        moved = true;
        orb.classList.add("dragging");
      }
      if (ev && ev.cancelable) ev.preventDefault();
      var vw = window.innerWidth || 360;
      var vh = window.innerHeight || 640;
      var w = orb.offsetWidth || 58;
      var h = orb.offsetHeight || 58;
      var nx = clamp(Math.round(origLeft + dx), 6, Math.max(6, vw - w - 6));
      var ny = clamp(Math.round(origTop + dy), 6, Math.max(6, vh - h - 20));
      orb.style.left = nx + "px";
      orb.style.top = ny + "px";
      orb.style.right = "auto";
      orb.style.bottom = "auto";
    }

    function onEnd() {
      if (!active) return;
      active = false;
      orb.classList.remove("dragging");
      if (moved) {
        suppressNextOrbClick = true;
        setTimeout(function () { suppressNextOrbClick = false; }, 320);
        var rect = orb.getBoundingClientRect();
        var vw = Math.max(1, window.innerWidth || 360);
        var vh = Math.max(1, window.innerHeight || 640);
        var w = orb.offsetWidth || 58;
        load();
        var finalLeft = rect.left;
        var edge = null;
        if (D.magSnap && (rect.left < 68 || vw - rect.right < 68)) {
          orb.classList.add("mag-anim");
          if (rect.left + w / 2 < vw / 2) {
            finalLeft = 6;
            edge = "left";
          } else {
            finalLeft = Math.max(6, vw - w - 6);
            edge = "right";
          }
          orb.style.left = finalLeft + "px";
          setTimeout(function () { orb.classList.remove("mag-anim"); }, 300);
        }
        D.orbPos = {
          xPct: Math.round((finalLeft / vw) * 10000) / 10000,
          yPct: Math.round((rect.top / vh) * 10000) / 10000,
          edge: edge
        };
        save();
        scheduleOrbPeek();
      }
    }

    // دعم Pointer Events الحديثة (تعمل على الجوال والكمبيوتر والقلم)
    if (window.PointerEvent) {
      orb.addEventListener("pointerdown", function (e) {
        if (e.button && e.button !== 0) return;
        onStart(e.clientX, e.clientY);
        try { orb.setPointerCapture(e.pointerId); } catch (er) {}
      });
      orb.addEventListener("pointermove", function (e) {
        onMove(e.clientX, e.clientY, e);
      });
      orb.addEventListener("pointerup", function (e) {
        try { orb.releasePointerCapture(e.pointerId); } catch (er) {}
        onEnd();
      });
      orb.addEventListener("pointercancel", onEnd);
    } else {
      // احتياطي لمس تقليدي
      orb.addEventListener("touchstart", function (e) {
        var t = e.touches && e.touches[0];
        if (t) onStart(t.clientX, t.clientY);
      }, { passive: true });
      orb.addEventListener("touchmove", function (e) {
        var t = e.touches && e.touches[0];
        if (t) onMove(t.clientX, t.clientY, e);
      }, { passive: false });
      orb.addEventListener("touchend", onEnd);
    }
  }

  function applyPanelDock() {
    var p = $("eduAsst");
    if (!p) return;
    load();
    p.classList.remove("dock-top", "dock-float");
    p.style.left = "";
    p.style.top = "";
    p.style.right = "";
    p.style.bottom = "";
    if (D.panelDock === "top") {
      p.classList.add("dock-top");
    } else if (D.panelDock === "float") {
      p.classList.add("dock-float");
      var vw = window.innerWidth || 360;
      var vh = window.innerHeight || 640;
      var pw = Math.min(vw * 0.94, 440);
      var ph = Math.min(vh * 0.76, 640);
      var lx = D.panelPos ? clamp(Math.round(D.panelPos.xPct * vw), 6, Math.max(6, vw - pw - 6)) : Math.round((vw - pw) / 2);
      var ty = D.panelPos ? clamp(Math.round(D.panelPos.yPct * vh), 6, Math.max(6, vh - 120)) : Math.round(vh * 0.1);
      p.style.left = lx + "px";
      p.style.top = ty + "px";
    }
  }

  function cyclePanelDock() {
    load();
    var order = ["bottom", "top", "float"];
    var next = order[(order.indexOf(D.panelDock || "bottom") + 1) % order.length];
    D.panelDock = next;
    save();
    applyPanelDock();
    var names = { bottom: "أسفل الشاشة", top: "أعلى الشاشة", float: "نافذة عائمة حرة (اسحب الرأس لتحريكها)" };
    toast("📍 موضع نافذة المساعد الآن: " + names[next], "info");
  }

  function makeDraggablePanelHeader(panel, header) {
    var active = false, startX = 0, startY = 0, origLeft = 0, origTop = 0, moved = false;

    function onStart(clientX, clientY, target) {
      if (target && target.closest("button,input,select,textarea,a")) return;
      var rect = panel.getBoundingClientRect();
      active = true;
      moved = false;
      startX = clientX;
      startY = clientY;
      origLeft = rect.left;
      origTop = rect.top;
    }

    function onMove(clientX, clientY, ev) {
      if (!active) return;
      var dx = clientX - startX, dy = clientY - startY;
      if (!moved && Math.hypot(dx, dy) < 9) return;
      if (!moved) {
        moved = true;
        load();
        D.panelDock = "float";
        panel.classList.remove("dock-top");
        panel.classList.add("dock-float");
      }
      if (ev && ev.cancelable) ev.preventDefault();
      var vw = window.innerWidth || 360, vh = window.innerHeight || 640;
      var pw = panel.offsetWidth || 340;
      var nx = clamp(Math.round(origLeft + dx), 4, Math.max(4, vw - pw - 4));
      var ny = clamp(Math.round(origTop + dy), 6, Math.max(6, vh - 90));
      panel.style.left = nx + "px";
      panel.style.top = ny + "px";
      panel.style.right = "auto";
      panel.style.bottom = "auto";
    }

    function onEnd() {
      if (!active) return;
      active = false;
      if (moved) {
        var rect = panel.getBoundingClientRect();
        var vw = Math.max(1, window.innerWidth || 360), vh = Math.max(1, window.innerHeight || 640);
        load();
        D.panelPos = { xPct: rect.left / vw, yPct: rect.top / vh };
        save();
      }
    }

    if (window.PointerEvent) {
      header.addEventListener("pointerdown", function (e) {
        if (e.button && e.button !== 0) return;
        onStart(e.clientX, e.clientY, e.target);
        if (active) { try { header.setPointerCapture(e.pointerId); } catch (er) {} }
      });
      header.addEventListener("pointermove", function (e) { onMove(e.clientX, e.clientY, e); });
      header.addEventListener("pointerup", function (e) {
        try { header.releasePointerCapture(e.pointerId); } catch (er) {}
        onEnd();
      });
      header.addEventListener("pointercancel", onEnd);
    }
  }

  // ------------------------------------------------------------------ 15) بناء الواجهة والتبويبات الأربعة
  function injectOrb() {
    if ($("eduAsstOrb")) return;
    var st = document.createElement("style");
    st.id = "eduAsstCss";
    st.textContent = CSS;
    document.head.appendChild(st);
    var b = document.createElement("button");
    b.id = "eduAsstOrb";
    b.type = "button";
    b.setAttribute("aria-label", "مساعدي الذكي — اسحبه لأي مكان على الشاشة أو اضغط للفتح (Alt+A)");
    b.title = "مساعدي الذكي — اسحبه لأي مكان على الشاشة أو اضغط للفتح (Alt+A)";
    b.innerHTML = '✨<span class="eab"></span><span class="ea-drag-hint">✥ حرّكني</span>';
    makeDraggableOrb(b);
    b.addEventListener("click", function (e) {
      if (suppressNextOrbClick) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      togglePanel();
    });
    document.body.appendChild(b);
    applyOrbPosition();
    window.addEventListener("resize", applyOrbPosition);
  }

  function build() {
    if (UI.built) return;
    UI.built = true;
    load();
    var p = document.createElement("section");
    p.id = "eduAsst";
    p.setAttribute("role", "dialog");
    p.setAttribute("aria-label", "مساعدي الذكي");
    p.innerHTML =
      '<div class="ea-hd" id="eaDragHd" title="اسحب هذا الشريط لتحريك النافذة على الشاشة">' +
        '<div class="ea-grip"></div>' +
        '<div class="ea-hd-row">' +
          '<div style="font-size:23px" id="eaHdIco">👨‍🏫</div>' +
          '<div style="min-width:0">' +
            '<b><span>مساعدي الذكي</span><span style="font-size:9.5px;background:rgba(245,158,11,.25);color:#fde68a;padding:1px 6px;border-radius:999px">v153 الشامل</span></b>' +
            '<small id="eaSub">حوار بشري + كاميرا + بودكاست ثنائي + PDF</small>' +
          '</div>' +
          '<span class="sp"></span>' +
          '<button class="ea-ib" id="eaCallBtn" type="button" title="وضع الحوار الصوتي الحي المستمر">🎙️ حوار حي</button>' +
          '<button class="ea-ib ' + (D.voice ? "on" : "") + '" id="eaVoiceToggle" type="button" title="تفعيل/إيقاف نطق الردود تلقائياً">' + (D.voice ? "🔊" : "🔇") + '</button>' +
          '<button class="ea-ib" id="eaDockBtn" type="button" title="تغيير موضع النافذة على شاشة الجوال (أسفل / أعلى / عائم حر)">📍</button>' +
          '<button class="ea-ib" id="eaWideBtn" type="button" title="توسيع/تصغير النافذة">⛶</button>' +
          '<button class="ea-ib" id="eaMenu" type="button" aria-label="الإعدادات والخيارات" title="الإعدادات وتصدير المحادثة">⚙️</button>' +
          '<button class="ea-ib" id="eaClose" type="button" aria-label="إغلاق">✕</button>' +
        '</div>' +
      '</div>' +
      '<div class="ea-menu-drawer" id="eaMenuDrawer">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">' +
          '<b style="font-size:12.5px">⚙️ إعدادات «مساعدي» والتحكم بالموضع</b>' +
          '<button type="button" class="ea-del" data-act="closemenu">✕</button>' +
        '</div>' +
        '<div class="ea-menu-grid">' +
          '<button type="button" class="ea-mitem" data-menu="resetpos"><span>📍</span><span>إعادة موضع الزر والنافذة</span></button>' +
          '<button type="button" class="ea-mitem" data-menu="cycledock"><span>✥</span><span>تبديل موضع النافذة</span></button>' +
          '<button type="button" class="ea-mitem" data-menu="chatpdf"><span>📄</span><span>تحميل المحادثة PDF</span></button>' +
          '<button type="button" class="ea-mitem" data-menu="daypdf"><span>📊</span><span>تقرير يومي ومهامي PDF</span></button>' +
          '<button type="button" class="ea-mitem" data-menu="dualpod"><span>🎙️👥</span><span>تشغيل حوار ثنائي حي</span></button><button type="button" class="ea-mitem" data-menu="socratic"><span>🎯</span><span>تسميع سقراطي تفاعلي</span></button><button type="button" class="ea-mitem" data-menu="voicenotepdf"><span>🎙️📄</span><span>مذكرة صوتية إلى PDF</span></button><button type="button" class="ea-mitem" data-menu="magsnap"><span>🧲</span><span>الالتصاق المغناطيسي للزر</span></button><button type="button" class="ea-mitem" data-menu="togglemyworks"><span>📂</span><span>إظهار/إخفاء أيقونة أعمالي</span></button><button type="button" class="ea-mitem" data-menu="classroom"><span>👨‍🏫</span><span>وضع المساعد الصفي (القرعة)</span></button><button type="button" class="ea-mitem" data-menu="mistakespdf"><span>🩺</span><span>بنك أخطائي (PDF علاجي)</span></button><button type="button" class="ea-mitem" data-menu="eyecare"><span>👁️</span><span>القراءة الدافئة وتكبير الخط</span></button>' +
          '<button type="button" class="ea-mitem" data-menu="gsearch"><span>🔎</span><span>البحث الشامل (Ctrl+K)</span></button>' +
          '<button type="button" class="ea-mitem" data-menu="datasaver"><span>📉</span><span>وضع توفير البيانات</span></button>' +
          '<button type="button" class="ea-mitem" data-menu="exportjson"><span>💾</span><span>نسخة احتياطية JSON</span></button>' +
          '<button type="button" class="ea-mitem" data-menu="importjson"><span>📂</span><span>استيراد بيانات JSON</span></button>' +
          '<button type="button" class="ea-mitem" data-menu="clearchat"><span>🧹</span><span>مسح سجل المحادثة</span></button>' +
        '</div>' +
      '</div>' +
      '<div class="ea-tabs" role="tablist">' +
        '<button class="ea-tab" data-tab="ask">💬 حواري</button>' +
        '<button class="ea-tab" data-tab="pdf">📄 صانع PDF</button>' +
        '<button class="ea-tab" data-tab="day">📅 يومي</button>' +
        '<button class="ea-tab" data-tab="tools">🧰 أدواتي</button>' +
      '</div>' +
      '<div class="ea-pbar" id="eaPersonaBar"></div>' +
      '<div id="eaLiveBar" title="اضغط للتحدث الآن أو مقاطعة الصوت">' +
        '<div class="ea-wave"><i></i><i></i><i></i><i></i><i></i></div>' +
        '<div style="min-width:0;flex:1">' +
          '<div id="eaLiveStatus" style="font-size:12px;font-weight:900;color:#fff">🟢 أستمع إليك الآن…</div>' +
          '<div id="eaLiveSub" style="font-size:10.5px;color:#cbd5e1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">حوار بشري مستمر يأخذ ويعطي</div>' +
        '</div>' +
        '<button type="button" class="ea-ib" style="background:rgba(244,63,94,.25);color:#fecdd3" data-act="stoplive">إيقاف</button>' +
      '</div>' +
      '<div class="ea-body" id="eaBody"></div>' +
      '<div id="eaAttStrip"></div>' +
      '<div class="ea-in" id="eaIn">' +
        '<input type="file" id="eaFileIn" accept="image/*,application/pdf" multiple style="display:none">' +
        '<button class="ea-cam" id="eaCamBtn" type="button" aria-label="تصوير مسألة أو إرفاق صورة" title="صوّر مسألة أو صفحة دفتر بالكاميرا">📷</button><button class="ea-cam" id="eaDrawBtn" type="button" aria-label="رسم معادلة أو شكل" title="ارسم معادلة رياضية أو شكلاً هندسياً بيدك">✏️</button>' +
        '<button class="ea-mic" id="eaMic" type="button" aria-label="تحدث بالصوت" title="اضغط وتحدث بالصوت">🎤</button>' +
        '<textarea id="eaTxt" rows="1" maxlength="2000" placeholder="حاورني، صوّر مسألة 📷، أو اطلب: جهز ملف PDF…"></textarea>' +
        '<button class="ea-pdfq" id="eaQuickPdfBtn" type="button" title="توليد وتحميل ملف PDF فوري">📄 PDF</button>' +
        '<button class="ea-go" id="eaGo" type="button" aria-label="إرسال">➤</button>' +
      '</div>';

    document.body.appendChild(p);
    applyPanelDock();
    makeDraggablePanelHeader(p, $("eaDragHd"));
    p.addEventListener("click", onClick);

    $("eaLiveBar").addEventListener("click", function (e) {
      if (e.target.closest("[data-act='stoplive']")) { toggleLiveCall(); return; }
      if (liveState === "speaking") {
        stopSpeaking();
        startListening(true);
      } else if (liveState !== "listening") {
        startListening(true);
      }
    });
    $("eaTxt").addEventListener("keydown", function (e) {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendFromInput(); }
    });
    $("eaTxt").addEventListener("input", function () {
      this.style.height = "auto";
      this.style.height = Math.min(110, this.scrollHeight) + "px";
    });
    $("eaGo").addEventListener("click", sendFromInput);
    $("eaMic").addEventListener("click", toggleMic);
    $("eaDrawBtn").addEventListener("click", openDrawPadModal);
    $("eaCamBtn").addEventListener("click", function () {
      var fi = $("eaFileIn");
      if (fi) fi.click();
    });
    $("eaFileIn").addEventListener("change", function (e) {
      handleChatFiles(e.target.files);
      e.target.value = "";
    });
    $("eaAttStrip").addEventListener("click", function (e) {
      var rm = e.target.closest("[data-rm-att]");
      if (rm) {
        chatAttachments.splice(+rm.getAttribute("data-rm-att"), 1);
        paintAttachmentStrip();
      }
    });
    $("eaCallBtn").addEventListener("click", toggleLiveCall);
    $("eaDockBtn").addEventListener("click", cyclePanelDock);
    $("eaVoiceToggle").addEventListener("click", function () {
      load();
      D.voice = !D.voice;
      save();
      this.classList.toggle("on", D.voice);
      this.textContent = D.voice ? "🔊" : "🔇";
      if (!D.voice) stopSpeaking();
      toast(D.voice ? "🔊 تم تفعيل النطق الصوتي التلقائي للردود" : "🔇 تم كتم النطق التلقائي", "info");
    });
    $("eaWideBtn").addEventListener("click", function () {
      UI.wide = !UI.wide;
      $("eduAsst").classList.toggle("wide", UI.wide);
    });
    $("eaQuickPdfBtn").addEventListener("click", function () {
      var val = ($("eaTxt") && $("eaTxt").value.trim()) || "";
      if (val) {
        $("eaTxt").value = "";
        $("eaTxt").style.height = "auto";
        ask("جهز لي نسخة PDF جاهزة للتحميل عن: " + val);
      } else {
        UI.tab = "pdf";
        render();
      }
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && isOpen()) closePanel();
    });
  }

  function isOpen() { var p = $("eduAsst"); return !!(p && p.classList.contains("open")); }
  function openPanel(tab) {
    build();
    load(); purgeTasks();
    if (tab) UI.tab = tab;
    applyPanelDock();
    $("eduAsst").classList.toggle("eye-care", !!D.eyeCare);
    $("eduAsst").classList.add("open");
    document.body.classList.add("eduAsst-open");
    render();
    if (UI.tab === "ask") {
      setTimeout(function () { try { $("eaTxt").focus({ preventScroll: true }); } catch (e) {} }, 120);
    }
  }
  function closePanel() {
    var p = $("eduAsst");
    if (p) p.classList.remove("open");
    document.body.classList.remove("eduAsst-open");
    UI.menuOpen = false;
    if ($("eaMenuDrawer")) $("eaMenuDrawer").classList.remove("open");
    stopMic(false);
    if (UI.liveCall) { UI.liveCall = false; stopSpeaking(); updateLiveUI(); }
  }
  function togglePanel() { isOpen() ? closePanel() : openPanel(); }

  function paintPersonaBar() {
    var bar = $("eaPersonaBar");
    if (!bar) return;
    if (UI.tab !== "ask" && UI.tab !== "pdf") {
      bar.style.display = "none";
      return;
    }
    bar.style.display = "flex";
    var cur = getPersona();
    if ($("eaHdIco")) $("eaHdIco").textContent = cur.ico;
    bar.innerHTML =
      PERSONAS.map(function (p) {
        var on = p.id === cur.id;
        return '<button type="button" class="ea-pbtn ' + (on ? "on" : "") + '" data-persona="' + p.id + '" title="' + esc(p.role) + '">' +
          '<span>' + p.ico + '</span><span>' + esc(p.name) + '</span>' +
        '</button>';
      }).join("") +
      '<button type="button" class="ea-pbtn pod" data-act="dualpodcast" title="تشغيل حوار صوتي ثنائي بين شخصيتين من الفريق">🎙️👥 حوار ثنائي</button>';
  }

  function render() {
    if (!UI.built) return;
    load();
    var p = getPersona();
    Array.prototype.forEach.call(document.querySelectorAll("#eduAsst .ea-tab"), function (b) {
      var on = b.getAttribute("data-tab") === UI.tab;
      b.classList.toggle("on", on);
      b.setAttribute("aria-selected", on);
    });
    paintPersonaBar();
    updateLiveUI();
    $("eaIn").style.display = UI.tab === "ask" ? "flex" : "none";
    paintAttachmentStrip();
    $("eaSub").textContent =
      UI.tab === "ask" ? (p.fullName + " • اسحب الرأس أو الزر لأي مكان") :
      UI.tab === "pdf" ? "استوديو تجهيز ومشاركة ملفات PDF وWord بالمخططات" :
      UI.tab === "day" ? dateLine() :
                         "ابحث وافتح أي أداة في المنصة فوراً";
    if (UI.tab === "ask") paintAsk();
    else if (UI.tab === "pdf") paintPdfStudio();
    else if (UI.tab === "day") paintDay();
    else paintTools();
  }

  // ------------------------------------------------------------------ 16) تبويب «💬 حواري»
  function suggestions() {
    var p = getPersona();
    if (p.id === "bayan") {
      return [
        "أعربي لي: يَصْنَعُ طُلَّابُ فِلَسْطِينَ الأَمَلَ بِالعِلْمِ",
        "جهزي لي ملف PDF عن قواعد الهمزة والتاء المربوطة",
        "شغلي حواراً ثنائياً عن النواسخ والبلاغة",
        "اسأليني سؤالاً في النحو والبلاغة"
      ];
    }
    if (p.id === "sabreen") {
      return [
        "اشرحي لي قوانين نيوتن والقصور الدوراني مع مثال",
        "جهزي لي ورقة عمل PDF عن المعادلة التربيعية",
        "شغلي حواراً ثنائياً عن التفاضل والقيم القصوى",
        "اختبريني بمسألة رياضية سريعة"
      ];
    }
    if (p.id === "layan") {
      return [
        "اشرحي الفرق بين Present Perfect و Past Simple",
        "جهزي لي ملخص PDF لقواعد الإنجليزية للتوجيهي",
        "لنتحدث معاً بالإنجليزية عن التكنولوجيا في التعليم",
        "كيف أحول الجملة إلى Passive Voice؟"
      ];
    }
    if (p.id === "yazan") {
      return [
        "جهز لي جدول مذاكرة PDF لامتحانات التوجيهي",
        "سمّع لي درس البناء الضوئي والتنفس الخلوي",
        "ركّز 25 دقيقة (بومودورو)",
        "أنا متوتر من الامتحان، شجعني ونظم وقتي!"
      ];
    }
    return [
      "جهز لي نسخة PDF عن قوانين نيوتن للحركة",
      "شغل حواراً ثنائياً عن استراتيجيات التفوق في التوجيهي",
      "صمّم امتحان توجيهي وزاري PDF مع الحل",
      "اعمل لي ورقة عمل PDF متمايزة مع الحل"
    ];
  }

  function msgHtml(m, idx) {
    if (m.r === "u") {
      var attBadge = m.attCount ? '<div style="font-size:10.5px;opacity:.9;margin-bottom:3px">📷 مرفق (' + m.attCount + ' صورة/ملف)</div>' : "";
      return '<div class="ea-msg u">' + attBadge + esc(m.t) + '</div>';
    }
    var p = getPersona(m.pId);
    var bodyHtml = m.h ? m.t : mdRich(m.raw || m.t);
    var pdfCard = m.pdfCard ? buildPdfReadyCardHtml(m.pdfTitle || "مستند تعليمي — EduTech Mindset", idx, m.pdfBadge) : "";
    var quizCard = m.quizId ? renderQuizCardHtml(m.quizId) : "";
    var actionBar =
      '<div class="ea-mbar">' +
        '<button type="button" class="ea-mbtn pdf" data-dl-pdf="' + idx + '" title="تجهيز وتحميل هذا الرد كملف PDF رسمي">📄 PDF</button>' +
        '<button type="button" class="ea-mbtn" data-reel-msg="' + idx + '" title="تحويل هذا الرد إلى عرض فيديو ريلز عمودي 9:16 ناطق">🎬 ريلز 9:16</button>' +
        '<button type="button" class="ea-mbtn" data-html-msg="' + idx + '" title="تصدير كاختبار وملخص تفاعلي HTML يعمل بلا إنترنت">🌐 HTML</button><button type="button" class="ea-mbtn" data-tg-msg="' + idx + '" title="نشر مباشر في قناة/مجموعة تليجرام">📢 تليجرام</button><button type="button" class="ea-mbtn" data-share-pdf="' + idx + '" title="مشاركة ملف الـ PDF عبر الجوال">📲 مشاركة</button>' +
        '<button type="button" class="ea-mbtn word" data-dl-docx="' + idx + '" title="تحميل كملف Word (.docx)">📘 Word</button>' +
        '<button type="button" class="ea-mbtn" data-speak-msg="' + idx + '" title="قراءة صوتية بشخصية ' + esc(p.name) + '">🔊 استمع</button>' +
        '<button type="button" class="ea-mbtn" data-copy-msg="' + idx + '" title="نسخ النص">📋 نسخ</button>' +
        '<button type="button" class="ea-mbtn" data-note-msg="' + idx + '" title="حفظ في ملاحظاتي">📌 حفظ</button>' +
      '</div>';
    var followUps = (idx === D.chat.length - 1) ? buildFollowUpChips("", m.raw || m.t, idx) : "";
    return '<div class="ea-msg a">' +
      '<div class="ea-mhd"><span>' + (m.pIco || p.ico) + '</span><span>' + esc(m.pName || p.fullName) + '</span></div>' +
      bodyHtml +
      quizCard +
      pdfCard +
      (m.x || "") +
      actionBar +
      followUps +
    '</div>';
  }

  function paintAsk() {
    load();
    var p = getPersona();
    var h = "";
    // شريط الذاكرة التراكمية التشخيصية إن وجدت مواضيع سابقة
    if (D.memoryTopics && D.memoryTopics.length) {
      h += '<div class="ea-card" style="padding:8px 10px;margin-bottom:8px;background:rgba(79,70,229,.06);border-color:rgba(79,70,229,.25)">' +
        '<div style="font-size:11px;font-weight:900;color:var(--ea-acc);margin-bottom:5px">🧠 ذاكرتك التعليمية — نكمل ما بدأناه بضغطة زر:</div>' +
        '<div class="ea-chips" style="margin:0">' +
          D.memoryTopics.slice(0, 4).map(function (mt) {
            return '<button type="button" class="ea-chip" data-ask="نكمل مراجعة موضوع: ' + esc(mt.t) + ' مع سؤال تطبيقي">🔄 ' + esc(mt.t.slice(0, 32)) + '</button>';
          }).join("") +
        '</div>' +
      '</div>';
    }

    if (!D.chat.length) {
      h += '<div class="ea-msg a">' +
        '<div class="ea-mhd"><span>' + p.ico + '</span><span>' + esc(p.fullName) + '</span></div>' +
        '<b>' + esc(greeting()) + '</b><br>' + esc(p.welcome) +
        '<div class="ea-mbar">' +
          '<button type="button" class="ea-mbtn" data-act="speakwelcome">🔊 استمع للترحيب</button>' +
          '<button type="button" class="ea-mbtn" data-act="dualpodcast">🎙️👥 حوار ثنائي حي</button>' +
          '<button type="button" class="ea-mbtn pdf" data-tab="pdf">📄 صانع الـ PDF</button>' +
        '</div>' +
      '</div>' +
      '<div class="ea-chips">' +
        suggestions().map(function (s) {
          return '<button type="button" class="ea-chip" data-ask="' + esc(s) + '">' + esc(s) + '</button>';
        }).join("") +
      '</div>' +
      '<div class="ea-card">' +
        '<h4>🌟 الجديد في «مساعدي» (الإصدار 151):</h4>' +
        '<div style="font-size:11.5px;line-height:1.85;font-weight:700;color:var(--ea-mut)">' +
          '• <b>✥ حرّك زر المساعد والنافذة لأي مكان:</b> اسحب الزر العائم (✨) أو شريط عنوان النافذة بإصبعك على الجوال وضعه في أي زاوية تريحك!<br>' +
          '• <b>📷 كاميرا قراءة المسائل والدفاتر:</b> اضغط زر <b>📷</b> بالأسفل لتصوير أي مسألة أو صفحة كتاب ليحلها المساعد معك صوتياً ويحولها لملف PDF.<br>' +
          '• <b>🎙️👥 الحوار الصوتي الثنائي (بودكاست):</b> استمع لنقاش حي بين معلمَين من الفريق يشرحان الدرس معاً.<br>' +
          '• <b>📊 مخططات مفاهيمية داخل الـ PDF ومشاركة للجوال:</b> كل ملف PDF يتضمن خريطة مفاهيمية مرسومة ورمز QR وزر مشاركة لواتساب وتليجرام.' +
        '</div>' +
      '</div>';
    } else {
      h += D.chat.map(function (m, idx) { return msgHtml(m, idx); }).join("");
    }
    var b = $("eaBody");
    if (b) {
      b.innerHTML = h;
      b.scrollTop = b.scrollHeight;
    }
  }

  function pushMsg(r, t, extra) {
    load();
    var p = getPersona();
    D.chat.push({
      r: r,
      t: t,
      raw: (extra && extra.raw) ? extra.raw : t,
      h: !!(extra && extra.h),
      x: (extra && extra.x) ? extra.x : "",
      pId: p.id,
      pName: p.fullName,
      pIco: p.ico,
      attCount: (extra && extra.attCount) || 0,
      quizId: (extra && extra.quizId) || "",
      pdfCard: !!(extra && extra.pdfCard),
      pdfTitle: (extra && extra.pdfTitle) || "",
      pdfBadge: (extra && extra.pdfBadge) || "",
      at: now()
    });
    D.chat = D.chat.slice(-45);
    save();
  }

  function toolButtons(list) {
    return '<div style="margin-top:8px">' + list.map(function (a) {
      return '<button type="button" class="ea-tool" data-open="' + esc(a.id) + '"><span class="i">' + esc(a.ico || "🧰") + '</span><span><span class="t">' + esc(a.title) + '</span></span></button>';
    }).join("") + '</div>';
  }

  function sendFromInput() {
    var t = $("eaTxt");
    var v = t ? t.value.trim() : "";
    if (!v && !chatAttachments.length) return;
    if (t) { t.value = ""; t.style.height = "auto"; }
    ask(v || "اشرح وحل المسألة المرفقة في الصورة بالتفصيل", { fromVoice: false, continuousTurn: UI.liveCall });
  }

  async function ask(text, opts) {
    opts = opts || {};
    if (BUSY) return;
    stopSpeaking();
    UI.tab = "ask";
    var attachedFiles = chatAttachments.slice();
    chatAttachments = [];
    paintAttachmentStrip();

    // فحص الأوامر المحلية أولاً إن لم تكن هناك صور مرفقة
    if (!attachedFiles.length) {
      var li = localIntent(text);
      if (li && li.skipPush) return;
      render();
      pushMsg("u", text);
      paintAsk();

      var p = getPersona();
      var shouldSpeak = !!(D.voice || UI.liveCall || opts.fromVoice);

      function afterLocalSpoken(spokenText) {
        if (shouldSpeak && spokenText) {
          speakResponse(spokenText, function () {
            if (UI.liveCall && isOpen()) {
              setTimeout(function () { if (UI.liveCall) startListening(true); }, 400);
            }
          });
        } else if (UI.liveCall && isOpen()) {
          setTimeout(function () { if (UI.liveCall) startListening(true); }, 400);
        }
      }

      if (li) {
        if (li.isPdfDoc) {
          pushMsg("a", li.raw, {
            raw: li.raw,
            pdfCard: true,
            pdfTitle: li.pdfTitle,
            pdfBadge: li.pdfBadge
          });
          paintAsk();
          if (li.autoDownload) {
            triggerExport("pdf", li.pdfTitle, li.raw, { tool: "مساعدي الذكي", persona: p.fullName });
          }
          afterLocalSpoken(li.spokenIntro || li.raw);
          return;
        }

        var gotoChip = "";
        if (li.goto) {
          var gl = { tasks: "✅ عرض مهامي", focus: "⏱️ شاشة التركيز", notes: "📝 عرض ملاحظاتي", count: "📆 عرض الموعد" }[li.goto.split(":")[1]] || "📅 افتح يومي";
          gotoChip = '<div class="ea-chips" style="margin:8px 0 0"><button type="button" class="ea-chip" data-goto="' + li.goto + '">' + gl + '</button></div>';
        }
        var extra = {
          h: true,
          raw: li.raw || li.html,
          x: gotoChip + (li.tools ? toolButtons(li.tools) : (li.open && !li.auto ? toolButtons([appById(li.open)]) : ""))
        };
        pushMsg("a", li.html, extra);
        paintAsk();
        afterLocalSpoken(li.raw || li.html);
        if (li.open && li.auto) {
          setTimeout(function () { openTool(li.open); }, 700);
        }
        return;
      }
    } else {
      render();
      pushMsg("u", text, { attCount: attachedFiles.length });
      paintAsk();
    }

    rememberTopic(text);
    BUSY = true;
    if (UI.liveCall) { liveState = "thinking"; updateLiveUI(); }
    var b = $("eaBody");
    if (b) {
      b.insertAdjacentHTML("beforeend", '<div class="ea-msg a ea-typing" id="eaTyping"><span></span><span></span><span></span></div>');
      b.scrollTop = b.scrollHeight;
    }
    var tools = searchTools(text, 2).filter(function (x) { return x.s >= 3.2; }).map(function (x) { return x.a; });

    var replyText = "";
    try {
      if (!navigator.onLine || !window.AI || typeof window.AI.ask !== "function") throw new Error("offline-brain");
      var apiFiles = attachedFiles.map(function (f) { return { mime: f.mime, data: f.data }; });
      var ans = await window.AI.ask(buildPrompt(text, attachedFiles.length > 0), apiFiles, "assistant");
      replyText = String(ans || "").trim();
      if (!replyText) throw new Error("empty");
    } catch (e) {
      replyText = generateHumanConversationalReply(text, attachedFiles.length > 0);
    }

    BUSY = false;
    var pCur = getPersona();
    var hasPdfStructure = (/^#\s+/m.test(replyText) || /\[مخطط:/.test(replyText)) && replyText.length > 180;
    pushMsg("a", replyText, {
      raw: replyText,
      pdfCard: hasPdfStructure || attachedFiles.length > 0,
      pdfTitle: (text.length > 4 ? text.slice(0, 55) : "حل وشرح من مساعدي الذكي"),
      pdfBadge: pCur.name,
      x: tools.length ? toolButtons(tools) : ""
    });
    paintAsk();

    var shouldSp = !!(D.voice || UI.liveCall || opts.fromVoice);
    if (shouldSp && replyText) {
      // التدفق الصوتي السريع: ننطق الفقرة الترحيبية/الأولى بسرعة ليشعر المستخدم باستجابة فورية
      speakResponse(replyText, function () {
        if (UI.liveCall && isOpen()) {
          setTimeout(function () { if (UI.liveCall) startListening(true); }, 400);
        }
      });
    } else if (UI.liveCall && isOpen()) {
      setTimeout(function () { if (UI.liveCall) startListening(true); }, 400);
    }
  }

  // ------------------------------------------------------------------ 17) تبويب «📄 صانع PDF» الفوري داخل المساعد
  function paintPdfStudio() {
    load();
    var d = D.pdfDraft || blank().pdfDraft;
    var p = getPersona();
    if (!d.body) {
      d.body = buildOfflineDocumentMarkdown(d.tpl || "summary", d.title || "قوانين نيوتن للحركة", d.grade || "الثاني عشر (التوجيهي)", d.subject || "الفيزياء", p);
      D.pdfDraft = d;
      save();
    }
    var h =
      '<div class="ea-card" style="background:linear-gradient(135deg,rgba(2,132,199,.08),rgba(245,158,11,.1));border-color:#f59e0b">' +
        '<h4>📄 استوديو تجهيز ومشاركة ملفات الـ PDF بالمخططات البصرية</h4>' +
        '<div style="font-size:11px;color:var(--ea-mut);font-weight:700;margin-bottom:8px">اختر القالب واكتب عنوان الدرس، وسيجهز لك «مساعدي» نسخة PDF رسمية تتضمن <b>مخططاً مفاهيمياً مرسوماً</b>، ورمز QR، وعلامة EduTech Mindset المائية جاهزة للتحميل أو المشاركة عبر الجوال!</div>' +
        '<label style="display:block;font-size:11px;font-weight:800;margin-bottom:4px">1. اختر قالب ملف الـ PDF (8 قوالب معتمدة):</label>' +
        '<select class="ea-field" id="eaPdfTpl" style="width:100%;margin-bottom:8px">' +
          PDF_TEMPLATES.map(function (t) {
            return '<option value="' + t.id + '"' + (t.id === d.tpl ? " selected" : "") + '>' + esc(t.label + " (" + t.badge + ")") + '</option>';
          }).join("") +
        '</select>' +
        '<label style="display:block;font-size:11px;font-weight:800;margin-bottom:4px">2. عنوان الدرس أو المستند:</label>' +
        '<input class="ea-field" id="eaPdfTitle" style="width:100%;margin-bottom:8px" maxlength="120" placeholder="مثال: قوانين نيوتن، البناء الضوئي، كان وأخواتها…" value="' + esc(d.title || "") + '">' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:6px">' +
          '<input class="ea-field" id="eaPdfGrade" placeholder="الصف / المرحلة" value="' + esc(d.grade || "") + '">' +
          '<input class="ea-field" id="eaPdfSubj" placeholder="المادة الدراسية" value="' + esc(d.subject || "") + '">' +
        '</div>' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:9px">' +
          '<input class="ea-field" id="eaPdfTeacher" placeholder="👨‍🏫 اسم المعلم/المعدّ (للترويسة)" value="' + esc(d.teacher || "") + '">' +
          '<input class="ea-field" id="eaPdfSchool" placeholder="🏫 اسم المدرسة (للترويسة)" value="' + esc(d.school || "") + '">' +
        '</div>' +
        '<div style="display:flex;flex-wrap:wrap;gap:5px">' +
          '<button type="button" class="ea-btn" data-act="pdfgen">✨ توليد المحتوى</button><button type="button" class="ea-btn" style="background:#7c3aed" data-act="voicenotepdf" title="تحدث بصوتك ليتحول كلامك إلى ملف PDF منسق">🎙️📄 أملي بصوتي</button>' +
          '<button type="button" class="ea-btn r" data-act="pdfdl" style="flex:1">⬇ تحميل PDF الآن</button>' +
          '<button type="button" class="ea-pdf-sh" data-act="pdfshare">📲 مشاركة</button>' +
          '<button type="button" class="ea-btn g" data-act="pdfdocx">📘 Word</button>' +
        '</div>' +
      '</div>' +
      '<div class="ea-card">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">' +
          '<h4>👁️ معاينة وتعديل محتوى الـ PDF والمخطط البصري:</h4>' +
          '<button type="button" class="ea-chip" data-act="pdfspeak">🔊 قراءة صوتية</button>' +
        '</div>' +
        '<textarea class="ea-field" id="eaPdfBody" rows="8" style="width:100%;font-size:11.5px;line-height:1.75;max-height:240px">' + esc(d.body || "") + '</textarea>' +
        '<div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:8px">' +
          '<button type="button" class="ea-pdf-dl" data-act="pdfdl">⬇ تحميل نسخة PDF المعتمدة (مع المخطط وQR)</button>' +
          '<button type="button" class="ea-pdf-sh" data-act="pdfshare">📲 مشاركة لواتساب/تليجرام</button>' +
          '<button type="button" class="ea-pdf-w" data-act="pdfdocx">📘 Word</button>' +
        '</div>' +
      '</div>';

    $("eaBody").innerHTML = h;
  }

  function syncPdfDraftFromInputs() {
    load();
    if ($("eaPdfTpl")) D.pdfDraft.tpl = $("eaPdfTpl").value;
    if ($("eaPdfTitle")) D.pdfDraft.title = $("eaPdfTitle").value.trim() || "مستند تعليمي — EduTech Mindset";
    if ($("eaPdfGrade")) D.pdfDraft.grade = $("eaPdfGrade").value.trim() || "المنهاج الفلسطيني";
    if ($("eaPdfSubj")) D.pdfDraft.subject = $("eaPdfSubj").value.trim() || "عام";
    if ($("eaPdfTeacher")) D.pdfDraft.teacher = $("eaPdfTeacher").value.trim();
    if ($("eaPdfSchool")) D.pdfDraft.school = $("eaPdfSchool").value.trim();
    if ($("eaPdfBody")) D.pdfDraft.body = $("eaPdfBody").value;
    try {
      localStorage.setItem("edu_custom_pdf_hdr", JSON.stringify({ teacher: D.pdfDraft.teacher || "", school: D.pdfDraft.school || "" }));
    } catch (eH) {}
    save();
    return D.pdfDraft;
  }

  async function generatePdfDraftContent(btnEl) {
    var d = syncPdfDraftFromInputs();
    var p = getPersona();
    var oldTxt = btnEl ? btnEl.textContent : "";
    if (btnEl) { btnEl.disabled = true; btnEl.textContent = "⏳ جارٍ التوليد…"; }

    if (d.tpl === "chatlog") {
      d.body = buildOfflineDocumentMarkdown("chatlog", d.title, d.grade, d.subject, p);
      save();
      paintPdfStudio();
      toast("تم تجهيز سجل المحادثة للتصدير بصيغة PDF ✓", "success");
      return;
    }

    var tplObj = PDF_TEMPLATES.filter(function (x) { return x.id === d.tpl; })[0] || PDF_TEMPLATES[0];
    try {
      if (!navigator.onLine || !window.AI || typeof window.AI.ask !== "function") throw new Error("offline");
      var prompt = "أنت " + p.fullName + " في منصة EduTech Mindset. قم بإعداد مستند تعليمي احترافي كامل ومنسق بصيغة Markdown ليتحول إلى ملف PDF رسمي جاهز للطباعة والتحميل.\n" +
        "نوع المستند: " + tplObj.label + "\n" +
        "العنوان/الموضوع: " + d.title + "\n" +
        "الصف/المرحلة: " + d.grade + "\n" +
        "المادة: " + d.subject + "\n" +
        "ابدأ بعد العنوان الرئيسي بسطر مخطط مفاهيمي بصيغة: [مخطط: " + d.title + " | المحور 1 | المحور 2 | المحور 3 | المحور 4] ثم استخدم عناوين (##)، قوائم نقطية، جدول Markdown مقارن، أمثلة محلولة، وأسئلة تقويم مع مفتاح الإجابة.";
      var res = await window.AI.ask(prompt, [], "assistant");
      if (res && String(res).trim().length > 80) {
        d.body = String(res).trim();
      } else throw new Error("short");
    } catch (e) {
      d.body = buildOfflineDocumentMarkdown(d.tpl, d.title, d.grade, d.subject, p);
    }
    save();
    if (UI.tab === "pdf") paintPdfStudio();
    toast("✨ تم تجهيز محتوى الـ PDF مع المخطط المفاهيمي — اضغط «تحميل PDF» لتنزيله!", "success");
    if (btnEl) { btnEl.disabled = false; btnEl.textContent = oldTxt; }
  }

  // ------------------------------------------------------------------ 18) تبويب «📅 يومي» وتبويب «🧰 أدواتي»
  var SUBS = [["tasks", "✅ المهام"], ["focus", "⏱️ التركيز"], ["habits", "🌱 العادات"], ["notes", "📝 ملاحظات"], ["count", "📆 موعد"]];
  function weekMinutes() {
    var s = 0, d = new Date();
    for (var i = 0; i < 7; i++) { s += (D.log[dayKey(d)] || 0); d.setDate(d.getDate() - 1); }
    return s;
  }

  function paintDay() {
    if (!UI.built || UI.tab !== "day") { updateOrb(); return; }
    load();
    var open = D.tasks.filter(function (t) { return !t.done; }), done = D.tasks.filter(function (t) { return t.done; });
    var pct = D.tasks.length ? Math.round(done.length * 100 / D.tasks.length) : 0;
    var today = dayKey(), hdone = D.habits.filter(function (h) { return h.days[today]; }).length;
    var h =
      '<div class="ea-hero">' +
        '<div class="ea-ring" style="--p:' + pct + '"><i>' + pct + '%</i></div>' +
        '<div style="flex:1"><b>' + esc(greeting()) + '</b><div class="ea-xp-pill">' + getXpRank(D.xp || 0) + ' • ' + (D.xp || 0) + ' XP</div><small>' + open.length + ' مهمة • ' + hdone + '/' + D.habits.length + ' عادات • ⏱️ ' + (D.log[today] || 0) + ' د</small></div>' +
        '<button type="button" class="ea-mbtn pdf" data-menu="daypdf" title="تصدير خطة يومي ومهامي وملاحظاتي كملف PDF">📄 تقرير PDF</button>' +
      '</div>';
    h += '<div class="ea-sub" role="tablist">' + SUBS.map(function (s) {
      return '<button type="button" data-sub="' + s[0] + '" class="' + (UI.sub === s[0] ? "on" : "") + '">' + s[1] + '</button>';
    }).join("") + '</div>';

    if (UI.sub === "tasks") {
      h += '<div class="ea-add"><input class="ea-field" id="eaTaskIn" maxlength="200" placeholder="مهمة جديدة… ثم Enter"><button type="button" class="ea-btn" data-act="addtask">إضافة</button></div>';
      var sorted = open.sort(function (a, b) { return (b.star - a.star) || (b.at - a.at); }).concat(done);
      h += sorted.length ? '<div class="ea-card" style="padding:4px 10px">' + sorted.map(function (t) {
        return '<div class="ea-row ' + (t.done ? "done" : "") + '"><input type="checkbox" data-tk="' + t.id + '" ' + (t.done ? "checked" : "") + ' aria-label="إنجاز"><span class="x">' + esc(t.t) + '</span><button type="button" class="ea-star ' + (t.star ? "on" : "") + '" data-star="' + t.id + '" aria-label="مهمة مهمة">⭐</button><button type="button" class="ea-del" data-deltask="' + t.id + '" aria-label="حذف">🗑</button></div>';
      }).join("") + '</div>' : '<div class="ea-empty">🎯 لا مهام بعد.<br>أضف أول مهمة، أو قل لي في «💬 حواري»: <b>ذكّرني بـ …</b></div>';
    } else if (UI.sub === "focus") {
      var presets = [15, 25, 45, 60];
      h += '<div class="ea-card"><div class="ea-tm" id="eaTm">' + fmt(T.left) + '</div>' +
        '<div class="ea-chips" style="justify-content:center">' + presets.map(function (m) { return '<button type="button" class="ea-chip" data-pre="' + m + '">' + m + ' د</button>'; }).join("") + '</div>' +
        '<div style="display:flex;gap:8px;justify-content:center"><button type="button" class="ea-btn" data-act="tstart" id="eaTBtn">' + (T.run ? "⏸ إيقاف مؤقت" : "▶ ابدأ") + '</button><button type="button" class="ea-btn g" data-act="treset">↺ إعادة</button></div></div>' +
        '<div class="ea-stats"><div class="ea-stat"><b>' + (D.log[today] || 0) + '</b><small>دقائق اليوم</small></div><div class="ea-stat"><b>' + weekMinutes() + '</b><small>دقائق الأسبوع</small></div><div class="ea-stat"><b>' + Math.round(weekMinutes() / 7) + '</b><small>متوسط يومي</small></div></div>' +
        '<div class="ea-empty" style="padding:6px">نصيحة: اعمل 25 دقيقة بتركيز كامل ثم استرح 5 دقائق. ' + (("Notification" in window && Notification.permission === "default") ? '<button type="button" class="ea-chip" data-act="notif">🔔 فعّل التنبيه عند الانتهاء</button>' : "") + '</div>';
    } else if (UI.sub === "habits") {
      h += D.habits.map(function (hb) {
        var ok = !!hb.days[today], s = streak(hb);
        return '<div class="ea-hab ' + (ok ? "ok" : "") + '"><input type="checkbox" data-hab="' + hb.id + '" ' + (ok ? "checked" : "") + ' style="width:20px;height:20px;accent-color:#10b981"><span>' + esc(hb.t) + '</span><span class="fl">' + (s ? "🔥 " + s + " يوم" : "ابدأ اليوم") + '</span><button type="button" class="ea-del" data-delhab="' + hb.id + '" aria-label="حذف">🗑</button></div>';
      }).join("") + '<div class="ea-add"><input class="ea-field" id="eaHabIn" maxlength="40" placeholder="عادة جديدة (مثال: 🧘 مراجعة الصباح)"><button type="button" class="ea-btn" data-act="addhab">إضافة</button></div>';
    } else if (UI.sub === "notes") {
      h += '<div class="ea-add"><textarea class="ea-field" id="eaNoteIn" rows="2" maxlength="3000" placeholder="اكتب ملاحظة سريعة أو ملخصاً…"></textarea><button type="button" class="ea-btn" data-act="addnote">حفظ</button></div>';
      h += D.notes.length ? D.notes.map(function (n) {
        return '<div class="ea-card" style="padding:9px 11px"><div style="font-size:13px;line-height:1.8;font-weight:600;white-space:pre-wrap;word-break:break-word">' + esc(n.t) + '</div><div style="display:flex;gap:6px;margin-top:6px;align-items:center"><small style="color:var(--ea-mut);font-weight:700">' + esc(new Date(n.at).toLocaleDateString("ar")) + '</small><span style="flex:1"></span><button type="button" class="ea-mbtn pdf" data-notepdf="' + n.id + '">📄 PDF</button><button type="button" class="ea-chip" data-copy="' + n.id + '">نسخ</button><button type="button" class="ea-chip" data-delnote="' + n.id + '">حذف</button></div></div>';
      }).join("") : '<div class="ea-empty">📝 دفترك فارغ. دوّن أفكارك هنا أو احفظ أي رد من «💬 حواري».</div>';
    } else {
      var allCounts = (D.counts && D.counts.length) ? D.counts : (D.count ? [D.count] : []);
      h += '<div class="ea-card"><h4>📆 إضافة امتحان أو موعد مهم (متعدد)</h4><div class="ea-add" style="flex-wrap:wrap"><input class="ea-field" id="eaCnT" maxlength="40" placeholder="المادة / الموعد (مثال: الفيزياء)"><input class="ea-field" type="date" id="eaCnD" style="max-width:150px"><button type="button" class="ea-btn" data-act="addcount">إضافة</button></div></div>';
      h += allCounts.length ? allCounts.map(function (cItem, ci) {
        var dl = daysLeft(cItem.d);
        return '<div class="ea-card" style="display:flex;align-items:center;justify-content:space-between;gap:10px">' +
          '<div><b style="font-size:13.5px">' + esc(cItem.t) + '</b><div style="font-size:11px;color:var(--ea-mut);font-weight:700">' + esc(cItem.d) + '</div></div>' +
          '<div style="display:flex;align-items:center;gap:8px"><span style="font:900 22px/1 Cairo,sans-serif;color:var(--ea-acc)">' + (dl >= 0 ? dl + " ي" : "انتهى") + '</span><button type="button" class="ea-del" data-delcount="' + ci + '">🗑</button></div>' +
        '</div>';
      }).join("") : '<div class="ea-empty">اضبط تواريخ امتحاناتك هنا وسأرتب لك الأولويات تلقائياً!</div>';
    }
    var bd = $("eaBody"), st = bd.scrollTop;
    bd.innerHTML = h;
    bd.scrollTop = st;
    updateOrb();
  }

  function paintTimer() {
    var el = $("eaTm"); if (el) el.textContent = fmt(T.left);
    var b = $("eaTBtn"); if (b) b.textContent = T.run ? "⏸ إيقاف مؤقت" : "▶ ابدأ";
    updateOrb();
  }
  function updateOrb() {
    var o = $("eduAsstOrb"); if (!o) return;
    var badge = o.querySelector(".eab");
    if (T.run) { o.classList.add("run"); badge.textContent = fmt(T.left); }
    else { o.classList.remove("run"); }
  }

  function paintTools() {
    var q = UI.q || "";
    var list = q ? searchTools(q, 12).map(function (x) { return x.a; }) : [];
    var favs = load().favs.map(appById).filter(function (a) { return apps().indexOf(a) !== -1; });
    var rec = [];
    try { rec = window.EduLauncher ? window.EduLauncher.getRecent().slice(0, 5) : []; } catch (e) {}
    function row(a) {
      var fav = D.favs.indexOf(a.id) !== -1;
      return '<button type="button" class="ea-tool" data-open="' + esc(a.id) + '"><span class="i">' + esc(a.ico || "🧰") + '</span><span style="min-width:0"><span class="t">' + esc(a.title) + '</span><span class="d">' + esc(a.desc || "") + '</span></span><span class="s" data-fav="' + esc(a.id) + '" role="button" aria-label="مفضلة">' + (fav ? "★" : "☆") + '</span></button>';
    }
    var h = '<input class="ea-field" id="eaToolQ" style="width:100%;margin-bottom:10px" placeholder="🔎 ابحث في كل الأدوات… (مثال: اختبار، سيرة، سبورة، محاكي)" value="' + esc(q) + '">';
    if (q) {
      h += list.length ? list.map(row).join("") : '<div class="ea-empty">لا نتائج. جرّب كلمة أبسط مثل «اختبار» أو «عرض».</div>';
    } else {
      if (favs.length) h += '<div class="ea-card"><h4>⭐ مفضلتي</h4>' + favs.map(row).join("") + '</div>';
      if (rec.length) h += '<div class="ea-card"><h4>🕘 استخدمتها مؤخراً</h4>' + rec.map(row).join("") + '</div>';
      var sg = suggestTools();
      if (sg.length) h += '<div class="ea-card"><h4>💡 مقترحة لك الآن</h4>' + sg.map(row).join("") + '</div>';
      if (!favs.length && !rec.length) h += '<div class="ea-empty">ابحث بالأعلى، أو اضغط ☆ بجانب أي أداة لتظهر هنا.<br>(' + apps().length + ' أداة متاحة في المنصة)</div>';
      h += '<div style="text-align:center"><button type="button" class="ea-btn g" data-act="alltools">📚 تصفّح كل الأدوات</button></div>';
    }
    var bd = $("eaBody"), hadFocus = document.activeElement && document.activeElement.id === "eaToolQ", pos = hadFocus ? document.activeElement.selectionStart : 0;
    bd.innerHTML = h;
    if (hadFocus) {
      var inp = $("eaToolQ");
      inp.focus();
      try { inp.setSelectionRange(pos, pos); } catch (e) {}
    }
  }
  function suggestTools() {
    var role = "";
    try { role = window.EduLauncher ? window.EduLauncher.getRole() : ""; } catch (e) {}
    var wanted = { teacher: "ورقه عمل اختبار خطه درس عروض", student: "اختبر نفسي مراجعه ملخص", tawjihi: "مراجعه اختبار توجيهي ملخص", university: "سيره بحث جامعه", parent: "متابعه ابناء تقرير" }[role] || "مراجعه اختبار";
    return searchTools(wanted, 3).map(function (x) { return x.a; });
  }

  function exportDayReportPdf(btnEl) {
    load();
    var p = getPersona();
    var today = dayKey();
    var done = D.tasks.filter(function (t) { return t.done; });
    var lines = [
      "# تقرير الإنجاز اليومي والمهام — " + (firstName() || "بطل EduTech Mindset"),
      "",
      "[مخطط: لوحة إنجازي اليومي | المهام المنجزة (" + done.length + "/" + D.tasks.length + ") | دقائق التركيز (" + (D.log[today] || 0) + " د) | العادات اليومية | الملاحظات والملخصات]",
      "",
      "> **التاريخ:** " + dateLine() + "  |  **إشراف:** " + p.fullName + " (EduTech Mindset)",
      "",
      "## 📊 ملخص النشاط والتركيز",
      "- **المهام المنجزة:** " + done.length + " من أصل " + D.tasks.length + " مهمة.",
      "- **دقائق التركيز اليوم (بومودورو):** " + (D.log[today] || 0) + " دقيقة  |  **إجمالي الأسبوع:** " + weekMinutes() + " دقيقة.",
      D.count ? "- **العد التنازلي للموعد القادم (" + D.count.t + "):** متبقٍ " + Math.max(0, daysLeft(D.count.d) || 0) + " يوماً." : "",
      "",
      "## ✅ قائمة المهام",
      "| المهمة | الأولوية | الحالة |",
      "|---|---|---|"
    ];
    if (D.tasks.length) {
      D.tasks.forEach(function (t) {
        lines.push("| " + String(t.t).replace(/\|/g, "/") + " | " + (t.star ? "مهمة جداً ⭐" : "عادية") + " | " + (t.done ? "منجزة ✓" : "قيد التنفيذ") + " |");
      });
    } else {
      lines.push("| لا توجد مهام مسجلة بعد | — | — |");
    }
    lines.push("", "## 🌱 العادات اليومية وسلاسل الالتزام");
    D.habits.forEach(function (hb) {
      lines.push("- **" + hb.t + ":** " + (hb.days[today] ? "أُنجزت اليوم ✓" : "لم تُنجز بعد") + " (سلسلة الالتزام: " + streak(hb) + " يوم).");
    });
    if (D.notes.length) {
      lines.push("", "## 📝 أبرز الملاحظات والملخصات المحفوظة");
      D.notes.slice(0, 15).forEach(function (n, i) {
        lines.push("### ملاحظة (" + (i + 1) + ") — " + new Date(n.at).toLocaleDateString("ar"));
        lines.push(n.t);
        lines.push("");
      });
    }
    return triggerExport("pdf", "تقرير يومي ومهامي — " + (firstName() || "EduTech"), lines.filter(Boolean).join("\n"), { tool: "مساعدي الذكي", persona: p.fullName }, btnEl);
  }

  // ------------------------------------------------------------------ 19) شريط التظليل الذكي لربط الكتب والموقع بـ «مساعدي» (#eaSelPop)
  var selPop = null, selectedSnippet = "";
  function ensureSelPop() {
    if (selPop) return selPop;
    selPop = document.createElement("div");
    selPop.id = "eaSelPop";
    selPop.innerHTML =
      '<button type="button" data-sel-act="ask">💬 اشرح مع مساعدي</button>' +
      '<button type="button" data-sel-act="pdf">📄 حوّل لـ PDF</button>' +
      '<button type="button" data-sel-act="pod">🎙️👥 حوار ثنائي</button>';
    selPop.addEventListener("mousedown", function (e) { e.preventDefault(); });
    selPop.addEventListener("click", function (e) {
      var b = e.target.closest("[data-sel-act]");
      if (!b || !selectedSnippet) return;
      var act = b.getAttribute("data-sel-act");
      var text = selectedSnippet;
      selPop.style.display = "none";
      if (act === "ask") {
        openPanel("ask");
        ask("اشرح لي هذه الفقرة وحلل أهم نقاطها: «" + text.slice(0, 400) + "»");
      } else if (act === "pdf") {
        openPanel("ask");
        ask("جهز لي ملف PDF جاهز للتحميل يلخص ويشرح: «" + text.slice(0, 350) + "»");
      } else if (act === "pod") {
        startDualPodcast(text.slice(0, 120));
      }
    });
    document.body.appendChild(selPop);
    return selPop;
  }

  var selTimer = null;
  document.addEventListener("selectionchange", function () {
    clearTimeout(selTimer);
    selTimer = setTimeout(function () {
      var sel = window.getSelection ? window.getSelection() : null;
      var txt = sel ? String(sel).trim() : "";
      if (txt.length < 6 || (sel.anchorNode && sel.anchorNode.parentElement && sel.anchorNode.parentElement.closest("#eduAsst"))) {
        if (selPop) selPop.style.display = "none";
        return;
      }
      try {
        selectedSnippet = txt;
        var r = sel.getRangeAt(0).getBoundingClientRect();
        var pop = ensureSelPop();
        pop.style.display = "inline-flex";
        pop.style.top = Math.max(12, r.top - 44) + "px";
        pop.style.left = clamp(Math.round(r.left), 8, Math.max(8, window.innerWidth - 290)) + "px";
      } catch (e) {}
    }, 260);
  });

  // ------------------------------------------------------------------ 20) معالجة النقرات والأحداث
  function onClick(e) {
    var t = e.target.closest("[data-goto],[data-tab],[data-ask],[data-open],[data-sub],[data-act],[data-tk],[data-deltask],[data-star],[data-pre],[data-hab],[data-delhab],[data-delnote],[data-notepdf],[data-copy],[data-fav],[data-persona],[data-dl-pdf],[data-share-pdf],[data-dl-docx],[data-open-pdfstudio],[data-speak-msg],[data-copy-msg],[data-note-msg],[data-reel-msg],[data-html-msg],[data-tg-msg],[data-delcount],[data-qpick],[data-qnext],[data-quiz-cert],[data-quiz-retry],[data-menu],#eaClose,#eaMenu");
    if (!t) return;
    load();
    if (t.id === "eaClose") return closePanel();
    if (t.id === "eaMenu") {
      UI.menuOpen = !UI.menuOpen;
      if ($("eaMenuDrawer")) $("eaMenuDrawer").classList.toggle("open", UI.menuOpen);
      return;
    }

    if (t.hasAttribute("data-persona")) {
      var newPid = t.getAttribute("data-persona");
      D.persona = newPid;
      save();
      var np = getPersona(newPid);
      render();
      toast(np.ico + " تم التبديل إلى: " + np.fullName, "success");
      if (D.voice || UI.liveCall) speakResponse(np.welcome);
      return;
    }

    if (t.hasAttribute("data-menu")) {
      var mAct = t.getAttribute("data-menu");
      UI.menuOpen = false;
      if ($("eaMenuDrawer")) $("eaMenuDrawer").classList.remove("open");
      if (mAct === "resetpos") return resetOrbAndPanelPosition();
      if (mAct === "cycledock") return cyclePanelDock();
      if (mAct === "dualpod") return startDualPodcast();
      if (mAct === "socratic") return startSocraticQuizCard();
      if (mAct === "voicenotepdf") return startVoiceNoteToPdf();
      if (mAct === "togglemyworks") { if (window.Exporter && window.Exporter.toggleFab) window.Exporter.toggleFab(); return; }
      if (mAct === "classroom") { openClassroomModeModal(); return; }
      if (mAct === "mistakespdf") { exportMistakesRemedialPdf(t); return; }
      if (mAct === "eyecare") { D.eyeCare = !D.eyeCare; save(); $("eduAsst").classList.toggle("eye-care", D.eyeCare); toast(D.eyeCare ? "👁️ تم تفعيل وضع القراءة الدافئة وتكبير الخط" : "تم إيقاف وضع القراءة الدافئة", "info"); return; }
      if (mAct === "magsnap") { D.magSnap = !D.magSnap; save(); applyOrbPosition(); toast(D.magSnap ? "🧲 تم تفعيل الالتصاق المغناطيسي والاختفاء الجزئي للزر على الجوال" : "تم إيقاف الالتصاق المغناطيسي — وضع حر كامل", "info"); return; }
      if (mAct === "chatpdf") {
        if (window.Exporter && window.Exporter.pdfFromChat) {
          window.Exporter.pdfFromChat(D.chat, { persona: getPersona().fullName, btn: t });
        } else {
          D.pdfDraft.tpl = "chatlog";
          D.pdfDraft.title = "سجل حواري مع مساعدي الذكي";
          D.pdfDraft.body = buildOfflineDocumentMarkdown("chatlog", D.pdfDraft.title, "", "", getPersona());
          save();
          triggerExport("pdf", D.pdfDraft.title, D.pdfDraft.body, { persona: getPersona().fullName }, t);
        }
        return;
      }
      if (mAct === "daypdf") return exportDayReportPdf(t);
      if (mAct === "gsearch") { if (window.EduSearch) { closePanel(); window.EduSearch.open(); } return; }
      if (mAct === "datasaver") { if (window.EduPerf) window.EduPerf.toggle(); return; }
      if (mAct === "exportjson") {
        var a = document.createElement("a");
        a.href = URL.createObjectURL(new Blob([JSON.stringify(load(), null, 2)], { type: "application/json" }));
        a.download = "mosaedi-backup-" + dayKey() + ".json";
        document.body.appendChild(a); a.click();
        setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 400);
        toast("تم تنزيل النسخة الاحتياطية بنجاح ✓", "success");
        return;
      }
      if (mAct === "importjson") {
        var f = document.createElement("input"); f.type = "file"; f.accept = "application/json,.json";
        f.onchange = function () {
          var r = new FileReader();
          r.onload = function () {
            try {
              var o = JSON.parse(r.result);
              if (!o || typeof o !== "object" || !Array.isArray(o.tasks)) throw 0;
              D = Object.assign(blank(), o); save(); applyOrbPosition(); applyPanelDock(); render();
              toast("تم استيراد بياناتك بنجاح ✓", "success");
            } catch (er) { toast("ملف النسخة الاحتياطية غير صالح", "error"); }
          };
          if (f.files[0]) r.readAsText(f.files[0]);
        };
        f.click();
        return;
      }
      if (mAct === "clearchat") {
        stopSpeaking();
        D.chat = [];
        save();
        render();
        toast("تم مسح سجل المحادثة وبدء صفحة جديدة ✨", "info");
        return;
      }
    }

    if (t.hasAttribute("data-html-msg")) {
      var idxHm = +t.getAttribute("data-html-msg"), mHm = D.chat[idxHm];
      if (mHm && window.Exporter && window.Exporter.htmlQuiz) {
        var tHm = mHm.pdfTitle || "ملخص واختبار تفاعلي — EduTech Mindset";
        window.Exporter.htmlQuiz(tHm, mHm.raw || mHm.t);
        addXp(10, "تصدير اختبار HTML");
      }
      return;
    }
    if (t.hasAttribute("data-tg-msg")) {
      var idxTg = +t.getAttribute("data-tg-msg"), mTg = D.chat[idxTg];
      if (mTg) {
        var rawTg = String(mTg.raw || mTg.t || "").replace(/<[^>]+>/g, "").slice(0, 700);
        if (window.EduTelegram && window.EduTelegram.openModal) {
          window.EduTelegram.openModal(mTg.pdfTitle || "مشاركة من مساعدي الذكي", rawTg);
        } else {
          window.open("https://t.me/share/url?url=" + encodeURIComponent(location.href) + "&text=" + encodeURIComponent(rawTg), "_blank", "noopener");
        }
      }
      return;
    }
    if (t.hasAttribute("data-delcount")) {
      var ciDel = +t.getAttribute("data-delcount");
      if (Array.isArray(D.counts) && D.counts.length) D.counts.splice(ciDel, 1);
      else D.count = null;
      save(); return paintDay();
    }
    if (t.hasAttribute("data-reel-msg")) {
      var idxRl = +t.getAttribute("data-reel-msg");
      var mRl = D.chat[idxRl];
      if (mRl) {
        var tRl = mRl.pdfTitle || (D.chat[idxRl - 1] && D.chat[idxRl - 1].r === "u" ? D.chat[idxRl - 1].t.slice(0, 50) : "درس تفاعلي — EduTech Mindset");
        openReelFromText(tRl, mRl.raw || mRl.t);
      }
      return;
    }
    if (t.hasAttribute("data-qpick")) {
      var qp = t.getAttribute("data-qpick").split(":");
      var qzObj = D.quizzes && D.quizzes[qp[0]];
      if (qzObj && !qzObj.done) {
        var qIndex = +qp[1], optIndex = +qp[2];
        if (!qzObj.picked) qzObj.picked = {};
        if (qzObj.picked[qIndex] === undefined) {
          qzObj.picked[qIndex] = optIndex;
          var qItem = qzObj.items[qIndex];
          if (qItem && optIndex === qItem.ans) {
            qzObj.score = (qzObj.score || 0) + (qItem.pts || 3);
            addXp(10, "إجابة صحيحة");
            if (D.voice || UI.liveCall) speakResponse(qItem.exp);
          } else if (qItem) {
            D.mistakes.unshift({ topic: qzObj.topic, q: qItem.q, correct: qItem.opts[qItem.ans], exp: qItem.exp, at: now() });
            D.mistakes = D.mistakes.slice(0, 30);
            rememberTopic("مراجعة: " + qzObj.topic);
            toast("💡 راجع التوضيح لتثبيت الفكرة!", "info");
            if (D.voice || UI.liveCall) speakResponse("انتبه يا بطل، الإجابة الصحيحة هي: " + qItem.opts[qItem.ans] + ". " + qItem.exp);
          }
          save();
          paintAsk();
        }
      }
      return;
    }
    if (t.hasAttribute("data-qnext")) {
      var qidN = t.getAttribute("data-qnext");
      var qzN = D.quizzes && D.quizzes[qidN];
      if (qzN) {
        if (qzN.cur + 1 < qzN.items.length) {
          qzN.cur++;
          save();
          paintAsk();
          if (D.voice || UI.liveCall) speakResponse("السؤال التالي: " + qzN.items[qzN.cur].q);
        } else {
          qzN.done = true;
          save();
          paintAsk();
          if (D.voice || UI.liveCall) speakResponse("مبارك يا بطل! أنهيت التسميع السقراطي وحصلت على " + qzN.score + " من عشرة! يمكنك إصدار شهادة التفوق بصيغة بي دي إف الآن.");
        }
      }
      return;
    }
    if (t.hasAttribute("data-quiz-cert")) {
      var qidC = t.getAttribute("data-quiz-cert");
      var qzC = D.quizzes && D.quizzes[qidC];
      if (qzC && window.Exporter && window.Exporter.certificate) {
        window.Exporter.certificate({
          name: firstName() || "بطل EduTech Mindset",
          role: "اجتياز التسميع السقراطي بنتيجة (" + qzC.score + " / 10)",
          school: (D.pdfDraft && D.pdfDraft.school) || "منصة EduTech Mindset — فلسطين",
          rank: qzC.score >= 9 ? "امتياز مع مرتبة الشرف 🏆" : "متفوق ومثابر ⭐",
          completed: 3,
          prompts: qzC.score,
          subject: qzC.topic
        }, "pdf");
      }
      return;
    }
    if (t.hasAttribute("data-quiz-retry")) {
      var qidR = t.getAttribute("data-quiz-retry");
      var qzR = D.quizzes && D.quizzes[qidR];
      if (qzR) {
        qzR.cur = 0; qzR.score = 0; qzR.done = false; qzR.picked = {};
        save();
        paintAsk();
      }
      return;
    }
    if (t.hasAttribute("data-dl-pdf")) {
      var idxP = +t.getAttribute("data-dl-pdf");
      var mP = D.chat[idxP];
      if (!mP) return;
      var rawP = String(mP.raw || mP.t || "").replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").trim();
      var titleP = mP.pdfTitle || (D.chat[idxP - 1] && D.chat[idxP - 1].r === "u" ? D.chat[idxP - 1].t.slice(0, 60) : "مستند من مساعدي الذكي");
      return triggerExport("pdf", titleP, rawP, { tool: "مساعدي الذكي", persona: mP.pName || getPersona().fullName }, t);
    }
    if (t.hasAttribute("data-share-pdf")) {
      var idxSh = +t.getAttribute("data-share-pdf");
      var mSh = D.chat[idxSh];
      if (!mSh) return;
      var rawSh = String(mSh.raw || mSh.t || "").replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").trim();
      var titleSh = mSh.pdfTitle || "مستند من مساعدي الذكي";
      return triggerExport("sharePdf", titleSh, rawSh, { tool: "مساعدي الذكي", persona: mSh.pName || getPersona().fullName }, t);
    }
    if (t.hasAttribute("data-dl-docx")) {
      var idxW = +t.getAttribute("data-dl-docx");
      var mW = D.chat[idxW];
      if (!mW) return;
      var rawW = String(mW.raw || mW.t || "").replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").trim();
      var titleW = mW.pdfTitle || (D.chat[idxW - 1] && D.chat[idxW - 1].r === "u" ? D.chat[idxW - 1].t.slice(0, 60) : "مستند من مساعدي الذكي");
      return triggerExport("docx", titleW, rawW, { tool: "مساعدي الذكي", persona: mW.pName || getPersona().fullName }, t);
    }
    if (t.hasAttribute("data-open-pdfstudio")) {
      var idxS = +t.getAttribute("data-open-pdfstudio");
      var mS = D.chat[idxS];
      if (mS) {
        D.pdfDraft.title = mS.pdfTitle || "مستند تعليمي — EduTech Mindset";
        D.pdfDraft.body = String(mS.raw || mS.t || "").replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").trim();
        save();
      }
      UI.tab = "pdf";
      return render();
    }
    if (t.hasAttribute("data-speak-msg")) {
      var idxSp = +t.getAttribute("data-speak-msg");
      var mSp = D.chat[idxSp];
      if (mSp) {
        if (speakingNow) stopSpeaking();
        else speakResponse(mSp.raw || mSp.t);
      }
      return;
    }
    if (t.hasAttribute("data-copy-msg")) {
      var idxCp = +t.getAttribute("data-copy-msg");
      var mCp = D.chat[idxCp];
      if (mCp) {
        var cleanCp = String(mCp.raw || mCp.t || "").replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").trim();
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(cleanCp).then(function () { toast("تم نسخ الرد بنجاح 📋", "success"); });
        }
      }
      return;
    }
    if (t.hasAttribute("data-note-msg")) {
      var idxNt = +t.getAttribute("data-note-msg");
      var mNt = D.chat[idxNt];
      if (mNt) {
        var cleanNt = String(mNt.raw || mNt.t || "").replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").trim();
        addNote(cleanNt);
        toast("📌 تم حفظ الرد في «ملاحظاتي» بنجاح!", "success");
      }
      return;
    }

    if (t.hasAttribute("data-goto")) {
      var gp = t.getAttribute("data-goto").split(":");
      UI.tab = gp[0]; UI.sub = gp[1] || UI.sub;
      return render();
    }
    if (t.hasAttribute("data-fav")) {
      e.stopPropagation();
      var id = t.getAttribute("data-fav"), i = D.favs.indexOf(id);
      if (i === -1) D.favs.unshift(id); else D.favs.splice(i, 1);
      save();
      return paintTools();
    }
    if (t.hasAttribute("data-tab")) {
      UI.tab = t.getAttribute("data-tab");
      return render();
    }
    if (t.hasAttribute("data-ask")) return ask(t.getAttribute("data-ask"));
    if (t.hasAttribute("data-open")) return openTool(t.getAttribute("data-open")) || toast("تعذر فتح الأداة الآن", "warning");
    if (t.hasAttribute("data-sub")) { UI.sub = t.getAttribute("data-sub"); return paintDay(); }
    if (t.hasAttribute("data-tk")) {
      var tk = D.tasks.filter(function (x) { return x.id === t.getAttribute("data-tk"); })[0];
      if (tk) { tk.done = t.checked; tk.doneAt = tk.done ? now() : 0; save(); }
      return paintDay();
    }
    if (t.hasAttribute("data-deltask")) {
      D.tasks = D.tasks.filter(function (x) { return x.id !== t.getAttribute("data-deltask"); });
      save(); return paintDay();
    }
    if (t.hasAttribute("data-star")) {
      var s = D.tasks.filter(function (x) { return x.id === t.getAttribute("data-star"); })[0];
      if (s) { s.star = !s.star; save(); }
      return paintDay();
    }
    if (t.hasAttribute("data-pre")) {
      timerPause(); T.total = T.left = (+t.getAttribute("data-pre")) * 60;
      return paintDay();
    }
    if (t.hasAttribute("data-hab")) {
      var hb = D.habits.filter(function (x) { return x.id === t.getAttribute("data-hab"); })[0];
      if (hb) { if (t.checked) hb.days[dayKey()] = 1; else delete hb.days[dayKey()]; save(); }
      return paintDay();
    }
    if (t.hasAttribute("data-delhab")) {
      D.habits = D.habits.filter(function (x) { return x.id !== t.getAttribute("data-delhab"); });
      save(); return paintDay();
    }
    if (t.hasAttribute("data-delnote")) {
      D.notes = D.notes.filter(function (x) { return x.id !== t.getAttribute("data-delnote"); });
      save(); return paintDay();
    }
    if (t.hasAttribute("data-notepdf")) {
      var nPdf = D.notes.filter(function (x) { return x.id === t.getAttribute("data-notepdf"); })[0];
      if (nPdf) triggerExport("pdf", "ملاحظة — " + nPdf.t.slice(0, 45), nPdf.t, { tool: "دفتر ملاحظات مساعدي", persona: getPersona().fullName }, t);
      return;
    }
    if (t.hasAttribute("data-copy")) {
      var n = D.notes.filter(function (x) { return x.id === t.getAttribute("data-copy"); })[0];
      if (n && navigator.clipboard) navigator.clipboard.writeText(n.t).then(function () { toast("تم النسخ ✓", "success"); });
      return;
    }

    var act = t.getAttribute("data-act");
    if (act === "closemenu") {
      UI.menuOpen = false;
      if ($("eaMenuDrawer")) $("eaMenuDrawer").classList.remove("open");
    } else if (act === "speakwelcome") {
      speakResponse(getPersona().welcome);
    } else if (act === "dualpodcast") {
      startDualPodcast();
    } else if (act === "socraticquiz") {
      startSocraticQuizCard();
    } else if (act === "voicenotepdf") {
      startVoiceNoteToPdf();
    } else if (act === "pdfgen") {
      generatePdfDraftContent(t);
    } else if (act === "pdfdl") {
      var dPdf = syncPdfDraftFromInputs();
      triggerExport("pdf", dPdf.title, dPdf.body, { tool: "صانع الـ PDF — مساعدي الذكي", persona: getPersona().fullName }, t);
    } else if (act === "pdfshare") {
      var dSh = syncPdfDraftFromInputs();
      triggerExport("sharePdf", dSh.title, dSh.body, { tool: "صانع الـ PDF — مساعدي الذكي", persona: getPersona().fullName }, t);
    } else if (act === "pdfdocx") {
      var dDoc = syncPdfDraftFromInputs();
      triggerExport("docx", dDoc.title, dDoc.body, { tool: "صانع الـ PDF — مساعدي الذكي", persona: getPersona().fullName }, t);
    } else if (act === "pdfspeak") {
      var dSp = syncPdfDraftFromInputs();
      speakResponse(dSp.body);
    } else if (act === "addtask") {
      var ti = $("eaTaskIn");
      if (ti && addTask(ti.value)) { ti.value = ""; var n2 = $("eaTaskIn"); if (n2) n2.focus(); }
    } else if (act === "addnote") {
      var ni = $("eaNoteIn");
      if (ni && addNote(ni.value)) ni.value = "";
    } else if (act === "addhab") {
      var hi = $("eaHabIn"), v = hi ? hi.value.trim() : "";
      if (v) { D.habits.push({ id: uid(), t: v, days: {} }); save(); paintDay(); }
    } else if (act === "tstart") {
      T.run ? timerPause() : timerStart();
    } else if (act === "treset") {
      timerReset();
    } else if (act === "notif") {
      try { Notification.requestPermission().then(paintDay); } catch (er) {}
    } else if (act === "addcount" || act === "setcount") {
      var cd = $("eaCnD").value, ct = $("eaCnT").value.trim() || "امتحان / موعد";
      if (cd) { if (!Array.isArray(D.counts)) D.counts = []; D.counts.push({ t: ct, d: cd }); D.counts.sort(function (a, b) { return a.d.localeCompare(b.d); }); save(); paintDay(); addXp(5, "إضافة موعد"); } else toast("اختر التاريخ أولاً", "warning");
    } else if (act === "delcount") {
      D.count = null; save(); paintDay();
    } else if (act === "alltools") {
      try { closePanel(); window.EduLauncher.open(); } catch (er) {}
    }
  }

  document.addEventListener("keydown", function (e) {
    if (e.target && e.target.id === "eaTaskIn" && e.key === "Enter") {
      e.preventDefault();
      var b = document.querySelector('[data-act="addtask"]');
      if (b) b.click();
    }
    if (e.target && e.target.id === "eaHabIn" && e.key === "Enter") {
      e.preventDefault();
      var h = document.querySelector('[data-act="addhab"]');
      if (h) h.click();
    }
    if (e.altKey && !e.ctrlKey && !e.metaKey && (e.key === "a" || e.key === "A" || e.key === "ش")) {
      e.preventDefault();
      togglePanel();
    }
  });
  document.addEventListener("input", function (e) {
    if (e.target && e.target.id === "eaToolQ") { UI.q = e.target.value; paintTools(); }
    if (e.target && (e.target.id === "eaPdfTitle" || e.target.id === "eaPdfGrade" || e.target.id === "eaPdfSubj" || e.target.id === "eaPdfTeacher" || e.target.id === "eaPdfSchool" || e.target.id === "eaPdfBody")) {
      syncPdfDraftFromInputs();
    }
  });
  document.addEventListener("change", function (e) {
    if (e.target && e.target.id === "eaPdfTpl") {
      var d = syncPdfDraftFromInputs();
      d.body = buildOfflineDocumentMarkdown(d.tpl, d.title, d.grade, d.subject, getPersona());
      save();
      paintPdfStudio();
    }
  });

  // ------------------------------------------------------------------ 21) الواجهة البرمجية العامة
  window.EduAssistant = {
    version: 153,
    open: openPanel,
    close: closePanel,
    toggle: togglePanel,
    ask: function (t, o) { openPanel("ask"); return ask(t, o); },
    openPdfStudio: function (topic, tpl) {
      load();
      if (topic) D.pdfDraft.title = topic;
      if (tpl) D.pdfDraft.tpl = tpl;
      D.pdfDraft.body = buildOfflineDocumentMarkdown(D.pdfDraft.tpl, D.pdfDraft.title, D.pdfDraft.grade, D.pdfDraft.subject, getPersona());
      save();
      openPanel("pdf");
    },
    exportPdf: function (title, text, opts) { return triggerExport("pdf", title, text, opts); },
    startVoiceCall: function () { if (!isOpen()) openPanel("ask"); if (!UI.liveCall) toggleLiveCall(); },
    stopVoiceCall: function () { if (UI.liveCall) toggleLiveCall(); },
    startDualPodcast: startDualPodcast,
    startSocraticQuiz: startSocraticQuizCard,
    openReel: openReelFromText,
    startVoiceNoteToPdf: startVoiceNoteToPdf,
    openDrawPad: openDrawPadModal,
    openClassroomMode: openClassroomModeModal,
    exportMistakesPdf: exportMistakesRemedialPdf,
    resetPosition: resetOrbAndPanelPosition,
    personas: PERSONAS,
    addTask: addTask,
    addNote: addNote,
    startFocus: function (m) { timerStart(m || 25); },
    search: searchTools,
    data: function () { load(); return { tasks: D.tasks || [], notes: D.notes || [], chat: D.chat || [], memoryTopics: D.memoryTopics || [] }; },
    norm: norm
  };

  function boot() {
    injectOrb();
    setInterval(function () {
      if (D && DKEY !== KEY()) { D = null; applyOrbPosition(); if (isOpen()) render(); }
    }, 4000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();

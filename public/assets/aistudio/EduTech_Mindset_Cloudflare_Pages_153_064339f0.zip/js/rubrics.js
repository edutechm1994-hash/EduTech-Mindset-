/*
 * مولّد أوراق التظليل الاختبارية (Bubble Sheet) وسلالم التقدير اللفظي (Rubrics) — EduTech Mindset (الإصدار 49)
 * 1) 🫧 مولّد ورقة إجابة تظليل الدوائر (Optical Bubble Answer Sheet A4 PDF) لـ 10 أو 20 أو 30 أو 40 سؤالاً
 *    مع إمكانية طباعة نموذج الطالب (دوائر فارغة) ونموذج مفتاح التصحيح للمعلم.
 * 2) 📋 مولّد سلالم التقدير اللفظي ومعايير تقييم المشاريع والأبحاث (AI Assessment Rubric Builder)
 *    لتقييم العروض والمشاريع والتجارب العملية وفق 4 مستويات (ممتاز / جيد جداً / مقبول / يحتاج تحسين) مع طباعة PDF.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var st = {
    tab: "bubble", // bubble | rubric
    bTitle: "ورقة إجابة اختبار الاختيار من متعدد",
    bCount: 20,
    bOpts: 4, // 4 (أ ب ج د) or 2 (صح / خطأ)
    rTopic: "مشروع علمي حول الطاقة المتجددة",
    rGrade: "التاسع",
    rubric: [
      { crit: "دقة المعلومات العلمية", l4: "معلومات دقيقة وموثقة بالكامل", l3: "معلومات صحيحة مع نقص بسيط", l2: "بعض المفاهيم تحتاج توضيحاً", l1: "أخطاء علمية واضحة", pts: 5 },
      { crit: "التنظيم وجودة العرض", l4: "عرض منظم ومبتكر وجذاب", l3: "عرض مرتب وواضح", l2: "تنظيم مقبول", l1: "غير منظم", pts: 5 },
      { crit: "العمل التعاوني والالتزام بالوقت", l4: "تعاون مثالي والتزام تام بالموعد", l3: "تعاون جيد", l2: "مشاركة محدودة لبعض الأعضاء", l1: "تأخر في التسليم", pts: 5 }
    ]
  };

  function printBubbleSheet() {
    var title = $("rbTitle").value.trim() || st.bTitle;
    var n = +$("rbCount").value || 20;
    var opts = +$("rbOpts").value === 2 ? ["صح", "خطأ"] : ["أ", "ب", "ج", "د"];
    var school = "", teacher = "";
    try { var h = JSON.parse(localStorage.getItem("ws_hdr") || "{}"); school = h.school || ""; teacher = h.teacher || ""; } catch (x) {}

    var half = Math.ceil(n / 2);
    function colHtml(start, end) {
      var rows = "";
      for (var i = start; i <= end; i++) {
        rows += '<tr><td class="qnum">' + i + '</td>' +
          opts.map(function (o) { return '<td><span class="bub">' + o + '</span></td>'; }).join("") + '</tr>';
      }
      return '<table class="btable"><thead><tr><th>س</th>' + opts.map(function (o) { return '<th>' + o + '</th>'; }).join("") + '</tr></thead><tbody>' + rows + '</tbody></table>';
    }

    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>' + e(title) + '</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;800;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:12mm}*{box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a}h1{text-align:center;font-size:20px;margin:0 0 6px}.hdr{border:2px solid #0f172a;border-radius:10px;padding:8px 12px;margin-bottom:10px;font-size:12px;font-weight:800}.hdr-row{display:flex;justify-content:space-between;margin-bottom:6px}.inst{background:#f1f5f9;border:1px solid #94a3b8;border-radius:8px;padding:6px 10px;font-size:11px;font-weight:700;margin-bottom:12px;text-align:center}.cols{display:grid;grid-template-columns:1fr 1fr;gap:18px}.btable{width:100%;border-collapse:collapse}.btable th,.btable td{border:1px solid #cbd5e1;padding:5px;text-align:center}.btable th{background:#e2e8f0;font-size:12px;font-weight:900}.qnum{font-weight:900;background:#f8fafc;width:36px}.bub{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;border-radius:50%;border:2px solid #0f172a;font-size:11px;font-weight:800}.corner{position:fixed;width:14px;height:14px;background:#000}</style></head><body>' +
      '<h1>🫧 ' + e(title) + '</h1>' +
      '<div class="hdr"><div class="hdr-row"><span>' + e(school || "المدرسة: ................................") + '</span><span>' + e(teacher ? "المعلم: " + teacher : "المعلم: ........................") + '</span><span>الدرجة النهائية: ........ / ' + n + '</span></div>' +
      '<div class="hdr-row" style="margin-bottom:0"><span>اسم الطالب: ........................................................</span><span>الصف والشعبة: ....................</span><span>رقم الجلوس: ....................</span></div></div>' +
      '<div class="inst">تعليمات التظليل: ظلّل دائرة الإجابة الصحيحة بالكامل بقلم رصاص أو حبر جاف داكن ( ● ) ولا تضع علامة ( ✗ ) أو ( ✓ ).</div>' +
      '<div class="cols"><div>' + colHtml(1, half) + '</div><div>' + colHtml(half + 1, n) + '</div></div></body></html>';

    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
    toast("جارٍ فتح ورقة التظليل للطباعة أو الحفظ كـ PDF ✓");
  }

  function generateAiRubric() {
    st.rTopic = $("rbRubTopic").value.trim();
    st.rGrade = $("rbRubGrade").value;
    if (!st.rTopic) { toast("اكتب عنوان المشروع أو المهمة أولاً", "warning"); return; }
    var btn = $("rbGenAiBtn");
    btn.disabled = true; btn.textContent = "⏳ يبني سلم التقدير…";
    var prompt = "أنت خبير تقويم تربوي. أنشئ سلم تقدير لفظي (Rubric) من 4 معايير لتقييم: «" + st.rTopic + "» لطلبة الصف " + st.rGrade + ".\n" +
      "أعد JSON صالحاً فقط بلا أي نص خارجه بهذا الشكل:\n" +
      '{"rubric":[{"crit":"اسم المعيار","l4":"وصف مستوى ممتاز (4)","l3":"وصف مستوى جيد جداً (3)","l2":"وصف مستوى مقبول (2)","l1":"وصف مستوى يحتاج تحسين (1)","pts":5}]}';

    window.AI.ask(prompt, [], "worksheet").then(function (txt) {
      var s = String(txt || "").replace(/```json|```/gi, ""), a = s.indexOf("{"), b = s.lastIndexOf("}");
      var j = JSON.parse(s.slice(a, b + 1));
      if (j && Array.isArray(j.rubric) && j.rubric.length) {
        st.rubric = j.rubric;
        paint();
      }
    }).catch(function () {
      toast("تعذر توليد سلم التقدير حالياً", "warning");
    }).then(function () {
      if ($("rbGenAiBtn")) { $("rbGenAiBtn").disabled = false; $("rbGenAiBtn").textContent = "🤖 ولّد معايير التقييم بالذكاء الاصطناعي"; }
    });
  }

  function printRubricPdf() {
    var tot = st.rubric.reduce(function (a, r) { return a + (+r.pts || 5); }, 0);
    var rows = st.rubric.map(function (r) {
      return '<tr><td style="font-weight:900;background:#f8fafc">' + e(r.crit) + '<br><small>(' + (r.pts || 5) + ' درجات)</small></td>' +
        '<td>' + e(r.l4) + '</td><td>' + e(r.l3) + '</td><td>' + e(r.l2) + '</td><td>' + e(r.l1) + '</td><td></td></tr>';
    }).join("");
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>سلم التقدير اللفظي</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;800;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4 landscape;margin:12mm}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a;font-size:12px}h1{text-align:center;margin:0 0 6px}.meta{text-align:center;margin-bottom:12px;font-weight:700}table{width:100%;border-collapse:collapse}th,td{border:1.5px solid #334155;padding:8px;text-align:center}th{background:#e2e8f0;font-weight:900}</style></head><body>' +
      '<h1>📋 سلم التقدير اللفظي ومعايير التقييم — ' + e(st.rTopic) + '</h1>' +
      '<div class="meta">اسم الطالب / المجموعة: ................................................ • الصف: ' + e(st.rGrade) + ' • الدرجة الكلية: ........ / ' + tot + '</div>' +
      '<table><thead><tr><th>معيار التقييم</th><th>🌟 ممتاز (100%)</th><th>👏 جيد جداً (80%)</th><th>👍 مقبول (60%)</th><th>🌱 يحتاج تحسين (40%)</th><th>درجة الطالب</th></tr></thead><tbody>' + rows + '</tbody></table></body></html>';
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
  }

  function paint() {
    var box = $("rbBody"); if (!box) return;
    var nav = '<div class="flex flex-wrap gap-2 mb-4 border-b border-slate-200 dark:border-slate-700 pb-3">' +
      '<button type="button" data-rbtab="bubble" class="px-4 py-2 rounded-xl text-xs font-extrabold transition-all ' + (st.tab === "bubble" ? "bg-violet-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">🫧 مولّد أوراق التظليل الاختبارية (Bubble Sheet)</button>' +
      '<button type="button" data-rbtab="rubric" class="px-4 py-2 rounded-xl text-xs font-extrabold transition-all ' + (st.tab === "rubric" ? "bg-indigo-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">📋 مولّد سلالم التقدير اللفظي (Rubrics)</button>' +
      '</div>';

    if (st.tab === "bubble") {
      box.innerHTML = nav + '<div class="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">' +
        '<div class="sm:col-span-2"><label class="block text-xs font-bold mb-1">عنوان ورقة الإجابة</label><input id="rbTitle" value="' + e(st.bTitle) + '" class="' + cls + '"></div>' +
        '<div><label class="block text-xs font-bold mb-1">عدد الأسئلة</label><select id="rbCount" class="' + cls + '"><option value="10">10 أسئلة</option><option value="15">15 سؤالاً</option><option value="20" selected>20 سؤالاً</option><option value="30">30 سؤالاً</option><option value="40">40 سؤالاً</option></select></div>' +
        '<div><label class="block text-xs font-bold mb-1">نوع الدوائر</label><select id="rbOpts" class="' + cls + '"><option value="4">4 خيارات (أ - ب - ج - د)</option><option value="2">خياران (صح / خطأ)</option></select></div>' +
        '</div>' +
        '<div class="mt-4"><button type="button" id="rbPrintBub" class="px-6 py-3 rounded-xl bg-gradient-to-l from-violet-600 to-purple-600 text-white text-xs font-black shadow-md">🖨 طباعة / حفظ ورقة التظليل A4 PDF</button></div>';
      $("rbPrintBub").onclick = printBubbleSheet;
    } else {
      box.innerHTML = nav + '<div class="space-y-3">' +
        '<div class="grid grid-cols-1 sm:grid-cols-3 gap-3">' +
        '<div class="sm:col-span-2"><label class="block text-xs font-bold mb-1">عنوان المشروع / البحث / العرض التقديمي</label><input id="rbRubTopic" value="' + e(st.rTopic) + '" class="' + cls + '"></div>' +
        '<div><label class="block text-xs font-bold mb-1">الصف</label><input id="rbRubGrade" value="' + e(st.rGrade) + '" class="' + cls + '"></div>' +
        '</div>' +
        '<div class="flex flex-wrap gap-2">' +
        '<button type="button" id="rbGenAiBtn" class="px-5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-black shadow">🤖 ولّد معايير التقييم بالذكاء الاصطناعي</button>' +
        '<button type="button" id="rbPrintRub" class="px-5 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black">🖨 طباعة سلم التقدير PDF</button>' +
        '</div>' +
        '<div class="overflow-x-auto"><table class="w-full text-[11px] border-collapse bg-white dark:bg-slate-800">' +
        '<thead><tr class="bg-slate-200 dark:bg-slate-700"><th class="p-2 border">المعيار</th><th class="p-2 border">🌟 ممتاز</th><th class="p-2 border">👏 جيد جداً</th><th class="p-2 border">👍 مقبول</th><th class="p-2 border">🌱 يحتاج تحسين</th></tr></thead><tbody>' +
        st.rubric.map(function (r) {
          return '<tr><td class="p-2 border font-black">' + e(r.crit) + ' (' + (r.pts || 5) + 'د)</td><td class="p-2 border">' + e(r.l4) + '</td><td class="p-2 border">' + e(r.l3) + '</td><td class="p-2 border">' + e(r.l2) + '</td><td class="p-2 border">' + e(r.l1) + '</td></tr>';
        }).join("") + '</tbody></table></div></div>';
      $("rbGenAiBtn").onclick = generateAiRubric;
      $("rbPrintRub").onclick = printRubricPdf;
    }

    box.querySelectorAll("[data-rbtab]").forEach(function (b) {
      b.onclick = function () { st.tab = b.dataset.rbtab; paint(); };
    });
  }

  function build() {
    if ($("rubricsStudio")) return true;
    var anchor = $("homeworkStudio") || $("worksheetStudio");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "rubricsStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-violet-700 via-purple-800 to-slate-900 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1">🫧 أوراق التظليل الاختبارية (Bubble Sheet) وسلالم التقدير (Rubrics)</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">اطبع أوراق تظليل الدوائر للاختبارات الورقية وابنِ معايير تقييم المشاريع والأبحاث</h2>' +
      '<p class="text-xs text-white/85 mt-1">أدوات تقويم احترافية للمعلم جاهزة للطباعة الفورية بحجم A4.</p>' +
      '</div><div class="p-4 sm:p-6 text-right" id="rbBody"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    paint();
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduRubrics = { open: function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("rubricsStudio", true); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

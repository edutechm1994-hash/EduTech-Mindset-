/*
 * بوابة التوجيهي وحاسبة المعدل الفلسطيني والمستشار الجامعي الذكي — EduTech Mindset (الإصدار 48)
 * تضم 3 أدوات متخصصة لطلبة الثانوية العامة (التوجيهي) في فلسطين:
 * 1) 🧮 حاسبة معدل التوجيهي الفلسطيني الرسمية (العلمي، الأدبي، الريادة والأعمال، الشرعي، الصناعي)
 *    مع تطبيق قاعدة المواد الإجبارية وأعلى المواد الاختيارية تلقائياً.
 * 2) 📅 مولّد جدول ختم ومراجعة مواد التوجيهي بالذكاء الاصطناعي (قابل للطباعة PDF).
 * 3) 🎓 المستشار الجامعي والمهني الذكي (يقترح أفضل التخصصات الجامعية في جامعات فلسطين حسب المعدل والميول).
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  // فروع التوجيهي الفلسطيني: المواد الإجبارية (core) والمواد الاختيارية (opt) وعدد ما يُحتسب منها (pickOpt)
  var STREAMS = {
    sci: {
      name: "🔬 الفرع العلمي",
      core: [
        { id: "ar", name: "اللغة العربية", max: 100, def: 92 },
        { id: "en", name: "اللغة الإنجليزية", max: 100, def: 90 },
        { id: "math", name: "الرياضيات (وزن 200)", max: 200, def: 186 },
        { id: "phys", name: "الفيزياء", max: 100, def: 91 }
      ],
      opt: [
        { id: "chem", name: "الكيمياء", max: 100, def: 94 },
        { id: "bio", name: "الأحياء", max: 100, def: 93 },
        { id: "isl", name: "التربية الإسلامية", max: 100, def: 96 },
        { id: "tech", name: "التكنولوجيا", max: 100, def: 95 }
      ],
      pickOpt: 2 // يُحتسب أعلى مادتين من المواد الأربع الاختيارية (بشرط وجود الكيمياء أو الأحياء)
    },
    lit: {
      name: "📚 الفرع الأدبي",
      core: [
        { id: "ar", name: "اللغة العربية (وزن 150)", max: 150, def: 138 },
        { id: "en", name: "اللغة الإنجليزية (وزن 150)", max: 150, def: 132 },
        { id: "hist", name: "الدراسات التاريخية", max: 100, def: 90 },
        { id: "math", name: "الرياضيات الأدبي", max: 100, def: 88 }
      ],
      opt: [
        { id: "geo", name: "الجغرافيا", max: 100, def: 92 },
        { id: "isl", name: "التربية الإسلامية", max: 100, def: 95 },
        { id: "tech", name: "التكنولوجيا", max: 100, def: 94 },
        { id: "scul", name: "الثقافة العلمية", max: 100, def: 91 }
      ],
      pickOpt: 2
    },
    biz: {
      name: "💼 فرع الريادة والأعمال",
      core: [
        { id: "ar", name: "اللغة العربية", max: 100, def: 90 },
        { id: "en", name: "اللغة الإنجليزية", max: 100, def: 88 },
        { id: "math", name: "الرياضيات", max: 100, def: 90 },
        { id: "proj", name: "المشاريع الصغيرة", max: 100, def: 94 },
        { id: "acc", name: "المحاسبة", max: 100, def: 92 },
        { id: "mgmt", name: "الإدارة والاقتصاد", max: 100, def: 93 }
      ],
      opt: [
        { id: "isl", name: "التربية الإسلامية", max: 100, def: 95 },
        { id: "tech", name: "التكنولوجيا", max: 100, def: 94 }
      ],
      pickOpt: 1
    },
    sharia: {
      name: "🕌 الفرع الشرعي",
      core: [
        { id: "ar", name: "اللغة العربية (وزن 150)", max: 150, def: 136 },
        { id: "qur", name: "القرآن الكريم وعلومه", max: 100, def: 96 },
        { id: "fiqh", name: "الفقه الإسلامي وأصوله", max: 100, def: 95 },
        { id: "had", name: "الحديث الشريف والتوحيد", max: 100, def: 94 }
      ],
      opt: [
        { id: "en", name: "اللغة الإنجليزية", max: 100, def: 86 },
        { id: "hist", name: "الدراسات التاريخية", max: 100, def: 90 },
        { id: "math", name: "الرياضيات", max: 100, def: 88 },
        { id: "tech", name: "التكنولوجيا", max: 100, def: 92 }
      ],
      pickOpt: 2
    },
    ind: {
      name: "⚙️ الفرع الصناعي",
      core: [
        { id: "ar", name: "اللغة العربية", max: 100, def: 90 },
        { id: "en", name: "اللغة الإنجليزية", max: 100, def: 88 },
        { id: "math", name: "الرياضيات العلمي/الصناعي", max: 100, def: 91 },
        { id: "phys", name: "الفيزياء", max: 100, def: 90 },
        { id: "voc_th", name: "العلم الصناعي والمهني", max: 200, def: 184 },
        { id: "voc_pr", name: "التدريب العملي والرسم الصناعي", max: 200, def: 188 }
      ],
      opt: [
        { id: "isl", name: "التربية الإسلامية", max: 100, def: 95 },
        { id: "tech", name: "التكنولوجيا", max: 100, def: 94 }
      ],
      pickOpt: 1
    }
  };

  var TAWJIHI_MOCKS = {
    sci: [
      { subj: "الرياضيات (العلمي)", q: "إذا كان ق(س) = س³ - 3س + 2، فما قيمة المشتقة الأولى ق'(2)؟", opts: ["9", "12", "6", "3"], ans: 0, exp: "ق'(س) = 3س² - 3  ق'(2) = 3(2)² - 3 = 12 - 3 = 9." },
      { subj: "الفيزياء (العلمي)", q: "جسم كتلته 4 كغم يتحرك بسرعة 5 م/ث، ما مقدار زخمه الخطي بوحدة (كغم.م/ث)؟", opts: ["9", "20", "50", "1.25"], ans: 1, exp: "الزخم الخطي (خ) = الكتلة (ك) × السرعة (ع) = 4 × 5 = 20 كغم.م/ث." },
      { subj: "الكيمياء (العلمي)", q: "ما قيمة الرقم الهيدروجيني (pH) لمحلول حمض قوي أحادي البروتون تركيزه 0.01 مول/لتر؟", opts: ["1", "2", "12", "7"], ans: 1, exp: "[H₃O⁺] = 10⁻² مول/لتر  pH = -log(10⁻²) = 2." },
      { subj: "الأحياء (العلمي)", q: "أين تحدث تفاعلات حلقة كالفن (التفاعلات اللاضوئية) في البلاستيدة الخضراء؟", opts: ["أغشية الثايلاكويد", "الستروما (الحشوة)", "الغشاء الخارجي", "الميتوكندريا"], ans: 1, exp: "تحدث تفاعلات حلقة كالفن لتثبيت CO₂ في حشوة البلاستيدة الخضراء (الستروما)." },
      { subj: "اللغة العربية", q: "ما المعنى الصرفي لكلمة (مِفتاح) في قولنا: الصبرُ مِفتاحُ الفرجِ؟", opts: ["اسم فاعل", "اسم مفعول", "اسم آلة", "صفة مشبهة"], ans: 2, exp: "(مِفتاح) على وزن (مِفعال) وهو من أوزان اسم الآلة القياسية." }
    ],
    lit: [
      { subj: "اللغة العربية (الأدبي)", q: "ما نوع (ما) في قولنا: «ما أجملَ سماءَ فلسطينَ!»؟", opts: ["نافية", "تعجبية في محل رفع مبتدأ", "موصولة", "شرطية"], ans: 1, exp: "صيغة تعجب قياسية على وزن (ما أفعله)، فـ (ما) تعجبية نكرة تامة بمعنى شيء عظيم في محل رفع مبتدأ." },
      { subj: "الدراسات التاريخية", q: "في أي عام صدر وعد بلفور المشؤوم خلال الحرب العالمية الأولى؟", opts: ["1914م", "1917م", "1920م", "1948م"], ans: 1, exp: "صدر وعد بلفور في 2 تشرين الثاني / نوفمبر 1917م." },
      { subj: "الرياضيات (الأدبي)", q: "إذا كانت المصفوفة أ من الرتبة (2 × 3) والمصفوفة ب من الرتبة (3 × 4)، فما رتبة مصفوفة حاصل الضرب (أ × ب)؟", opts: ["2 × 4", "3 × 3", "4 × 2", "لا يمكن الضرب"], ans: 0, exp: "عدد أعمدة الأولى (3) يساوي عدد صفوف الثانية (3)، وتكون رتبة الناتج (2 × 4)." },
      { subj: "اللغة الإنجليزية", q: "Choose the correct form: By next July, the students ______ their Tawjihi exams.", opts: ["will finish", "will have finished", "finished", "are finishing"], ans: 1, exp: "وجود (By + وقت في المستقبل) يدل على زمن المستقبل التام (Future Perfect: will have + V3)." },
      { subj: "الجغرافيا", q: "أي من الأقاليم المناخية التالية يسود في السهل الساحلي الفلسطيني؟", opts: ["المناخ الاستوائي", "مناخ البحر المتوسط المعتدل", "المناخ القاري البارد", "المناخ القطبي"], ans: 1, exp: "يسود السهل الساحلي الفلسطيني مناخ البحر الأبيض المتوسط المعتدل ماطر شتاءً وحار جاف صيفاً." }
    ]
  };

  var st = {
    mockBank: 'sci',
    mockChecked: false,
    mockChoices: {},
    tab: "calc", // calc | planner | advisor
    stream: "sci",
    marks: {},
    planOut: "",
    advisorOut: ""
  };

  function calcGpa() {
    var S = STREAMS[st.stream] || STREAMS.sci;
    var coreSum = 0, coreMax = 0;
    S.core.forEach(function (m) {
      var v = st.marks[st.stream + "_" + m.id];
      if (v === undefined) v = m.def;
      v = Math.max(0, Math.min(m.max, +v || 0));
      coreSum += v;
      coreMax += m.max;
    });

    var optVals = S.opt.map(function (m) {
      var v = st.marks[st.stream + "_" + m.id];
      if (v === undefined) v = m.def;
      v = Math.max(0, Math.min(m.max, +v || 0));
      return { id: m.id, name: m.name, val: v, max: m.max, pct: (v / m.max) * 100 };
    });

    optVals.sort(function (a, b) { return b.pct - a.pct; });
    var chosen = optVals.slice(0, S.pickOpt);
    var optSum = chosen.reduce(function (a, x) { return a + x.val; }, 0);
    var optMax = chosen.reduce(function (a, x) { return a + x.max; }, 0);

    var totSum = coreSum + optSum;
    var totMax = coreMax + optMax;
    var gpa = totMax ? Math.round((totSum / totMax) * 1000) / 10 : 0;
    return { gpa: gpa, totSum: totSum, totMax: totMax, chosen: chosen };
  }

  function printTawjihiDoc(title, content) {
    if (!content) return;
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>' + e(title) + '</title>' +
      '<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">' +
      '<style>@page{size:A4;margin:14mm}body{font-family:Cairo,Tahoma,sans-serif;color:#0f172a;line-height:1.9;font-size:13.5px}h1{text-align:center;color:#0369a1;border-bottom:2px solid #cbd5e1;padding-bottom:8px;font-size:20px}.box{white-space:pre-line;background:#f8fafc;border:1.5px solid #cbd5e1;border-radius:14px;padding:16px}</style></head><body>' +
      '<h1>🎓 ' + e(title) + '</h1><div class="box">' + e(content) + '</div></body></html>';
    var f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (x) {} setTimeout(function () { f.remove(); }, 4000); }, 700);
  }

  function paint() {
    var box = $("twBody"); if (!box) return;
    var tabs = [
      ["calc", "🧮 حاسبة معدل التوجيهي"],
      ["mock", "📝 اختبارات وزارية تجريبية (بلا إنترنت)"],
      ["planner", "📅 جدول المراجعة وختم المواد"],
      ["advisor", "🎓 المستشار الجامعي الذكي"],
      ["cv", "📄 إنشاء CV جامعي احترافي (عربي/EN)"]
    ];
    var nav = '<div class="flex flex-wrap gap-2 mb-4 border-b border-slate-200 dark:border-slate-700 pb-3">' +
      tabs.map(function (t) {
        var on = st.tab === t[0];
        return '<button type="button" data-twtab="' + t[0] + '" class="px-4 py-2 rounded-xl text-xs font-extrabold transition-all ' + (on ? "bg-amber-500 text-slate-950 shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">' + t[1] + '</button>';
      }).join("") + '</div>';

    var body = "";
    if (st.tab === "calc") {
      var S = STREAMS[st.stream] || STREAMS.sci;
      var res = calcGpa();
      var chosenIds = {}; res.chosen.forEach(function (c) { chosenIds[c.id] = true; });

      body = '<div class="space-y-4">' +
        '<div class="flex flex-wrap gap-2">' +
        Object.keys(STREAMS).map(function (k) {
          var on = st.stream === k;
          return '<button type="button" data-twstr="' + k + '" class="px-4 py-2 rounded-xl text-xs font-black ' + (on ? "bg-brand-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800") + '">' + STREAMS[k].name + '</button>';
        }).join("") + '</div>' +
        '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">' +
        '<div class="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-3">' +
        '<div class="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-900/40 space-y-2.5">' +
        '<div class="text-xs font-black text-brand-600 dark:text-brand-300">📌 المواد الإجبارية الأساسية (تُحتسب كاملة)</div>' +
        S.core.map(function (m) {
          var k = st.stream + "_" + m.id;
          var val = st.marks[k] !== undefined ? st.marks[k] : m.def;
          return '<div class="flex items-center justify-between gap-2 text-xs font-bold"><span>' + e(m.name) + '</span>' +
            '<div class="flex items-center gap-1"><input type="number" min="0" max="' + m.max + '" data-twmk="' + k + '" value="' + val + '" class="w-20 px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-center font-black"> <span class="text-[10px] text-slate-400">/ ' + m.max + '</span></div></div>';
        }).join("") + '</div>' +
        '<div class="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-900/40 space-y-2.5">' +
        '<div class="text-xs font-black text-emerald-600 dark:text-emerald-400">✨ المواد الاختيارية (يُحتسب أعلى ' + S.pickOpt + ' تلقائياً)</div>' +
        S.opt.map(function (m) {
          var k = st.stream + "_" + m.id;
          var val = st.marks[k] !== undefined ? st.marks[k] : m.def;
          var isPicked = !!chosenIds[m.id];
          return '<div class="flex items-center justify-between gap-2 text-xs font-bold"><span>' + e(m.name) + (isPicked ? ' <span class="text-[10px] text-emerald-600 font-black">✓ محتسبة</span>' : '') + '</span>' +
            '<div class="flex items-center gap-1"><input type="number" min="0" max="' + m.max + '" data-twmk="' + k + '" value="' + val + '" class="w-20 px-2 py-1 rounded-lg border ' + (isPicked ? "border-emerald-500 bg-emerald-50/40 dark:bg-slate-800" : "border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800") + ' text-center font-black"> <span class="text-[10px] text-slate-400">/ ' + m.max + '</span></div></div>';
        }).join("") + '</div></div>' +
        '<div id="twGpaCard" class="lg:col-span-4 rounded-3xl p-6 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white text-center space-y-3 border-2 border-amber-400/50 shadow-xl">' +
        '<div class="text-xs font-extrabold text-amber-300">' + e(S.name) + '</div>' +
        '<div class="text-5xl font-black text-emerald-400">' + res.gpa.toFixed(1) + '%</div>' +
        '<div class="text-xs text-slate-300">المجموع الموزون: <b>' + res.totSum + '</b> من <b>' + res.totMax + '</b></div>' +
        '<div class="text-[11px] text-sky-300 leading-relaxed">المواد الاختيارية المحتسبة:<br><b>' + res.chosen.map(function (c) { return c.name + " (" + c.val + ")"; }).join(" + ") + '</b></div>' +
        '<button type="button" id="twGoAdvisor" class="w-full py-2.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-black">🎓 ما التخصصات المناسبة لمعدلي؟</button>' +
        '</div></div></div>';
    } else if (st.tab === "planner") {
      body = '<div class="space-y-3">' +
        '<div class="grid grid-cols-1 sm:grid-cols-3 gap-3">' +
        '<div><label class="block text-xs font-bold mb-1">عدد الأيام المتاحة للمراجعة</label><select id="twPlanDays" class="' + cls + '"><option value="7">7 أيام (أسبوع مكثف)</option><option value="14" selected>14 يوماً (أسبوعان)</option><option value="30">30 يوماً (شهر كامل)</option></select></div>' +
        '<div><label class="block text-xs font-bold mb-1">ساعات الدراسة اليومية</label><select id="twPlanHrs" class="' + cls + '"><option value="4">4 ساعات يومياً</option><option value="6" selected>6 ساعات يومياً</option><option value="8">8 ساعات يومياً</option><option value="10">10 ساعات يومياً</option></select></div>' +
        '<div><label class="block text-xs font-bold mb-1">المواد التي تحتاج تركيزاً أكبر</label><input id="twPlanFocus" class="' + cls + '" placeholder="مثال: الرياضيات والفيزياء واللغة الإنجليزية"></div>' +
        '</div>' +
        '<div class="flex flex-wrap gap-2">' +
        '<button type="button" id="twGenPlanOffline" class="px-5 py-2.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-black shadow">⚡ توليد جدول مراجعة فوري (بلا إنترنت)</button>' +
        '<button type="button" id="twGenPlan" class="px-5 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black shadow">🤖 صمّم جدول مراجعة مخصص بالـ AI</button>' +
        (st.planOut ? '<button type="button" id="twPrintPlan" class="px-4 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-black">🖨 طباعة الجدول PDF</button>' : '') +
        '</div>' +
        (st.planOut ? '<div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs leading-loose whitespace-pre-line font-semibold">' + e(st.planOut) + '</div>' : '') +
        '</div>';
    } else if (st.tab === "advisor") {
      var curGpa = calcGpa().gpa;
      body = '<div class="space-y-3">' +
        '<div class="grid grid-cols-1 sm:grid-cols-3 gap-3">' +
        '<div><label class="block text-xs font-bold mb-1">الفرع والمعدل المتوقع</label><input id="twAdvGpa" value="' + e((STREAMS[st.stream] || STREAMS.sci).name + " — المعدل: " + curGpa.toFixed(1) + "%") + '" class="' + cls + '"></div>' +
        '<div class="sm:col-span-2"><label class="block text-xs font-bold mb-1">ميولك ومهاراتك المفضلة</label><input id="twAdvInterests" class="' + cls + '" placeholder="مثال: أحب البرمجة والذكاء الاصطناعي / أحب المجال الطبي / أحب التصميم والإدارة…"></div>' +
        '</div>' +
        '<div class="flex flex-wrap gap-2">' +
        '<button type="button" id="twGenAdv" class="px-6 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-black shadow">🎓 اقترح أفضل التخصصات الجامعية ومستقبلها المهني</button>' +
        '<button type="button" id="twOpenCvStudio" class="px-5 py-2.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-black shadow">📄 إنشاء سيرة ذاتية جامعية احترافية (CV عربي + إنجليزي)</button>' +
        (st.advisorOut ? '<button type="button" id="twPrintAdv" class="px-4 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black">🖨 طباعة دليل التخصصات PDF</button>' : '') +
        '</div>' +
        (st.advisorOut ? '<div class="p-4 rounded-2xl border border-indigo-300 dark:border-indigo-800 bg-indigo-50/40 dark:bg-slate-900/60 text-xs leading-loose whitespace-pre-line font-semibold">' + e(st.advisorOut) + '</div>' : '') +
        '</div>';
    } else if (st.tab === "mock") {
      var bank = TAWJIHI_MOCKS[st.mockBank] || TAWJIHI_MOCKS.sci;
      var okCount = 0;
      if (st.mockChecked) {
        bank.forEach(function (q, i) { if (st.mockChoices[i] === q.ans) okCount++; });
      }
      body = '<div class="space-y-4">' +
        '<div class="flex flex-wrap items-center justify-between gap-2">' +
        '<div class="flex gap-2">' +
        '<button type="button" data-twmb="sci" class="px-4 py-2 rounded-xl text-xs font-black ' + (st.mockBank === "sci" ? "bg-brand-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800") + '">🔬 نموذج الفرع العلمي</button>' +
        '<button type="button" data-twmb="lit" class="px-4 py-2 rounded-xl text-xs font-black ' + (st.mockBank === "lit" ? "bg-emerald-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800") + '">📚 نموذج الفرع الأدبي والشرعي والريادة</button>' +
        '</div>' +
        '<button type="button" id="twPrintMock" class="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-black">🖨 طباعة الورقة التدريبية PDF</button></div>' +
        (st.mockChecked ? '<div class="p-3.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/40 text-center font-black text-base text-emerald-700 dark:text-emerald-300">🌟 نتيجتك في الاختبار التجريبي: ' + okCount + ' من ' + bank.length + ' (' + Math.round(okCount * 100 / bank.length) + '%)</div>' : '') +
        '<div class="space-y-3">' +
        bank.map(function (q, qi) {
          var chosen = st.mockChoices[qi];
          return '<div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-900/50 space-y-2">' +
            '<div class="text-[11px] font-black text-amber-600 dark:text-amber-400">📌 ' + e(q.subj) + '</div>' +
            '<div class="text-xs sm:text-sm font-black">' + (qi + 1) + ') ' + e(q.q) + '</div>' +
            '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">' +
            q.opts.map(function (op, oi) {
              var sel = chosen === oi;
              var clsOpt = "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800";
              if (st.mockChecked) {
                if (oi === q.ans) clsOpt = "border-emerald-500 bg-emerald-500/15 font-black text-emerald-800 dark:text-emerald-200";
                else if (sel && oi !== q.ans) clsOpt = "border-rose-500 bg-rose-500/15 text-rose-700";
              } else if (sel) {
                clsOpt = "border-brand-500 bg-sky-500/15 font-black";
              }
              return '<button type="button" data-twq="' + qi + '" data-two="' + oi + '" class="text-right px-3 py-2 rounded-xl border-2 text-xs font-bold transition-all ' + clsOpt + '">' + e(op) + '</button>';
            }).join("") + '</div>' +
            (st.mockChecked ? '<div class="mt-2 p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-500/30 text-xs font-bold text-emerald-700 dark:text-emerald-300">💡 التفسير الوزاري: ' + e(q.exp) + '</div>' : '') +
            '</div>';
        }).join("") + '</div>' +
        '<div class="flex gap-2">' +
        '<button type="button" id="twGradeMock" class="px-6 py-3 rounded-xl bg-emerald-600 text-white text-xs font-black shadow">✅ صحّح إجاباتي واعرض خطوات الحل</button>' +
        '<button type="button" id="twResetMock" class="px-4 py-3 rounded-xl bg-slate-200 dark:bg-slate-800 text-xs font-bold">🔄 إعادة المحاولة</button>' +
        '</div></div>';
    }

    box.innerHTML = nav + body;
    box.querySelectorAll("[data-twtab]").forEach(function (b) {
      b.onclick = function () {
        if (b.dataset.twtab === "cv") {
          if (window.EduCVBuilder && window.EduCVBuilder.open) window.EduCVBuilder.open();
          else if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("cvBuilderStudio", true);
          return;
        }
        st.tab = b.dataset.twtab; paint();
      };
    });
    if ($("twOpenCvStudio")) $("twOpenCvStudio").onclick = function () {
      if (window.EduCVBuilder && window.EduCVBuilder.open) window.EduCVBuilder.open();
      else if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("cvBuilderStudio", true);
    };

    if (st.tab === "calc") {
      box.querySelectorAll("[data-twstr]").forEach(function (b) {
        b.onclick = function () { st.stream = b.dataset.twstr; paint(); };
      });
      box.querySelectorAll("[data-twmk]").forEach(function (inp) {
        inp.oninput = function () {
          st.marks[inp.dataset.twmk] = +inp.value || 0;
          var r = calcGpa();
          var card = $("twGpaCard");
          if (card) {
            card.querySelector(".text-5xl").textContent = r.gpa.toFixed(1) + "%";
            card.querySelector(".text-slate-300").innerHTML = "المجموع الموزون: <b>" + r.totSum + "</b> من <b>" + r.totMax + "</b>";
            card.querySelector(".text-sky-300").innerHTML = "المواد الاختيارية المحتسبة:<br><b>" + r.chosen.map(function (c) { return c.name + " (" + c.val + ")"; }).join(" + ") + "</b>";
          }
        };
      });
      if ($("twGoAdvisor")) $("twGoAdvisor").onclick = function () { st.tab = "advisor"; paint(); };
    } else if (st.tab === "planner") {
      $("twGenPlanOffline").onclick = function () {
        var days = +$("twPlanDays").value || 14, hrs = +$("twPlanHrs").value || 6, foc = $("twPlanFocus").value.trim();
        var S = STREAMS[st.stream] || STREAMS.sci;
        var subs = S.core.concat(S.opt).map(function (m) { return m.name.replace(/\s*\(.*\)/, ""); });
        var lines = [
          "📅 جدول ختم ومراجعة مواد التوجيهي (" + S.name + ") — خطة " + days + " يوماً (" + hrs + " ساعات يومياً)",
          foc ? "🎯 تركيز إضافي مضاعف على: " + foc : "🎯 توزيع متوازن بين المواد الأساسية والاختيارية مع حل أسئلة سنوات سابقة",
          "=========================================================="
        ];
        var half = Math.max(1, Math.round(hrs / 2));
        for (var d = 1; d <= days; d++) {
          var s1 = subs[(d * 2 - 2) % subs.length];
          var s2 = subs[(d * 2 - 1) % subs.length];
          lines.push("• اليوم " + d + ": الفترة الصباحية (" + half + " س): مراجعة مركزة في «" + s1 + "» + تلخيص القوانين | الفترة المسائية (" + (hrs - half) + " س): «" + s2 + "» + حل نموذج وزاري سابق (45 دقيقة).");
        }
        lines.push("==========================================================");
        lines.push("💡 نصائح ذهبية: خذ استراحة 10 دقائق بعد كل 50 دقيقة دراسة (تقنية بومودورو)، وخصّص آخر نصف ساعة يومياً لمراجعة البطاقات القلّابة والقوانين.");
        st.planOut = lines.join("\n");
        paint();
        toast("تم توليد جدول المراجعة الفوري بلا إنترنت ✓", "success");
      };
      $("twGenPlan").onclick = function () {
        var days = $("twPlanDays").value, hrs = $("twPlanHrs").value, foc = $("twPlanFocus").value.trim();
        var btn = $("twGenPlan"); btn.disabled = true; btn.textContent = "⏳ يصمم جدول المراجعة…";
        var p = "أنت مرشد تربوي خبير لطلبة التوجيهي في فلسطين (" + (STREAMS[st.stream] || STREAMS.sci).name + "). صمم جدول مراجعة وختم مواد عملياً ومنظماً لمدة " + days + " يوماً بمعدل " + hrs + " ساعات يومياً" + (foc ? " مع التركيز على: " + foc : "") + "، يشمل فترات استراحة ومراجعة وحل أسئلة سنوات سابقة.";
        window.AI.ask(p, [], "studio").then(function (txt) { st.planOut = txt; paint(); }).catch(function () { btn.disabled = false; btn.textContent = "🤖 صمّم جدول مراجعة مخصص بالـ AI"; });
      };
      if ($("twToWeeklyBtn")) $("twToWeeklyBtn").onclick = function () {
        if (window.EduBridge) window.EduBridge.toPlanner("تطبيق جدول مراجعة التوجيهي (" + (STREAMS[st.stream] || STREAMS.sci).name + ")", "0_0", "مراجعة توجيهي مكثفة");
        if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("weeklyPlannerStudio", true);
      };
      if ($("twPrintPlan")) $("twPrintPlan").onclick = function () {
        printTawjihiDoc("جدول مراجعة وختم مواد التوجيهي — " + (STREAMS[st.stream] || STREAMS.sci).name, st.planOut);
      };
    } else if (st.tab === "advisor") {
      $("twGenAdv").onclick = function () {
        var gpaInfo = $("twAdvGpa").value, intr = $("twAdvInterests").value.trim();
        var btn = $("twGenAdv"); btn.disabled = true; btn.textContent = "⏳ يحلل التخصصات…";
        var p = "أنت مستشار توجيه جامعي ومهني خبير في جامعات فلسطين. طالب في " + gpaInfo + (intr ? " وميوله هي: «" + intr + "»" : "") + ".\nاقترح له أفضل 5 تخصصات جامعية مناسبة لمعدله وميوله، واشرح لكل تخصص: ماذا يدرس، ومجالات عمله المستقبلية (بما فيها العمل الحر عن بعد).";
        window.AI.ask(p, [], "studio").then(function (txt) { st.advisorOut = txt; paint(); }).catch(function () { btn.disabled = false; btn.textContent = "🎓 اقترح أفضل التخصصات الجامعية ومستقبلها المهني"; });
      };
      if ($("twPrintAdv")) $("twPrintAdv").onclick = function () {
        printTawjihiDoc("دليل التوجيه الجامعي والمهني — EduTech Mindset", st.advisorOut);
      };
    } else if (st.tab === "mock") {
      box.querySelectorAll("[data-twmb]").forEach(function (b) {
        b.onclick = function () { st.mockBank = b.dataset.twmb; st.mockChecked = false; st.mockChoices = {}; paint(); };
      });
      box.querySelectorAll("[data-twq]").forEach(function (b) {
        b.onclick = function () {
          st.mockChoices[+b.dataset.twq] = +b.dataset.two;
          paint();
        };
      });
      if ($("twGradeMock")) $("twGradeMock").onclick = function () { st.mockChecked = true; paint(); };
      if ($("twResetMock")) $("twResetMock").onclick = function () { st.mockChecked = false; st.mockChoices = {}; paint(); };
      if ($("twMockToRev")) $("twMockToRev").onclick = function () {
        var bank = TAWJIHI_MOCKS[st.mockBank] || TAWJIHI_MOCKS.sci;
        if (window.EduBridge) window.EduBridge.toReview("توجيهي — " + (st.mockBank === "sci" ? "الفرع العلمي" : "الأدبي والشرعي"), bank.map(function (q) { return { q: "[" + q.subj + "] " + q.q, a: q.opts[q.ans] + " — " + q.exp }; }));
      };
      if ($("twPrintMock")) $("twPrintMock").onclick = function () {
        var bank = TAWJIHI_MOCKS[st.mockBank] || TAWJIHI_MOCKS.sci;
        var txt = bank.map(function (q, i) {
          return "س" + (i + 1) + " [" + q.subj + "]: " + q.q + "\n   الخيارات: " + q.opts.join("  |  ") + "\n   الإجابة النموذجية والشرح: " + q.opts[q.ans] + " — " + q.exp;
        }).join("\n\n");
        printTawjihiDoc("نموذج اختبار توجيهي تجريبي محلول — " + (st.mockBank === "sci" ? "الفرع العلمي" : "الفرع الأدبي والشرعي والريادة"), txt);
      };
    }
  }

  function build() {
    if ($("tawjihiStudio")) return true;
    var anchor = $("learnSection") || $("booksSection");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "tawjihiStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-amber-600 via-indigo-900 to-slate-950 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1">🎓 بوابة التوجيهي الفلسطيني والتوجيه الجامعي</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">حاسبة معدل التوجيهي الدقيقة، جدول ختم المواد، والمستشار الجامعي الذكي</h2>' +
      '<p class="text-xs text-white/85 mt-1">احسب معدلك الرسمي حسب فرعك تلقائياً، وصمّم جدول مراجعتك واكتشف التخصصات الجامعية الأنسب لمعدلك وميولك.</p>' +
      '</div><div class="p-4 sm:p-6 text-right" id="twBody"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    paint();
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduTawjihi = { open: function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("tawjihiStudio", true); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

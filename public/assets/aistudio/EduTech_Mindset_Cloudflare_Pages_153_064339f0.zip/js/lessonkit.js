/*
 * حقيبة الحصة الجاهزة — EduTech Mindset (الإصدار 80)
 * اكتب عنوان الدرس أو صوّر صفحة الكتاب بالكاميرا أو ارفع ملفاً من جهازك أو اختر درساً من المنهاج،
 * فتُولَّد حقيبة حصة كاملة بنداء واحد للذكاء الاصطناعي (أو بقالب فوري متكامل):
 *   أهداف سلوكية • تمهيد • خطوات التنفيذ بالدقائق • ورقة عمل • اختبار قصير (اختيار من متعدد) •
 *   واجب • تمايز (دعم/إثراء) • مفردات للمراجعة
 * مع تصدير Word أو PDF، وإرسال بضغطة زر إلى أوراق العمل، العروض، الألعاب، المراجعة الذكية، والمخطط الأسبوعي.
 */
(function () {
  "use strict";
  var KEY = "edu_lessonkit_v77";
  var esc = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var LETTERS = ["أ", "ب", "ج", "د"];
  var GRADES = ["الصف الأول", "الصف الثاني", "الصف الثالث", "الصف الرابع", "الصف الخامس", "الصف السادس", "الصف السابع", "الصف الثامن", "الصف التاسع", "الصف العاشر", "الصف الحادي عشر", "الصف الثاني عشر (التوجيهي)"];
  var SUBJECTS = ["اللغة العربية", "الرياضيات", "العلوم والحياة", "اللغة الإنجليزية", "التربية الإسلامية", "الدراسات الاجتماعية", "التكنولوجيا", "الفيزياء", "الكيمياء", "الأحياء", "أخرى"];

  var ST = { meta: { grade: GRADES[3], subject: SUBJECTS[1], title: "", minutes: 45, notes: "" }, kit: null, tab: "plan", reveal: false, busy: false, raw: "", err: "" };

  function loadHist() { try { var a = JSON.parse(localStorage.getItem(KEY) || "[]"); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
  function saveHist(entry) {
    var a = loadHist().filter(function (x) { return x.id !== entry.id; });
    a.unshift(entry);
    a = a.slice(0, 8);
    try { localStorage.setItem(KEY, JSON.stringify(a)); } catch (e) {}
  }

  // توليد حقيبة فورية ذكية تعمل حتى بلا إنترنت لأي درس
  function buildInstantKit(m) {
    var t = m.title.trim() || "الكسور العشرية";
    var g = m.grade || "الصف الرابع";
    var s = m.subject || "الرياضيات";
    var mins = +m.minutes || 45;
    var wMin = 5, s1 = Math.round((mins - 10) * 0.4), s2 = Math.round((mins - 10) * 0.35), s3 = Math.max(5, mins - wMin - s1 - s2);
    return {
      objectives: [
        "أن يوضّح الطالب المفهوم الأساسي لدرس «" + t + "» بلغة سليمة.",
        "أن يستنتج العلاقات والقواعد الرئيسية الواردة في درس «" + t + "» من خلال الأمثلة.",
        "أن يطبّق ما تعلّمه في حل تدريبات ومسائل متنوعة من الكتاب المدرسي بدقة.",
        "أن يربط مفاهيم «" + t + "» بمواقف حياتية يومية في بيئته الفلسطينية."
      ],
      warmup: "عرض سؤال عصف ذهني وصورة توضيحية على السبورة حول «" + t + "» وربطها بخبرات الطلبة السابقة في مادة " + s + " (" + wMin + " دقائق).",
      steps: [
        { title: "العرض والشرح التفاعلي", minutes: s1, activity: "يعرض المعلم الفكرة المحورية لدرس «" + t + "» باستخدام السبورة التفاعلية وأمثلة الكتاب المدرسي، ويناقش الطلبة سقراطياً." },
        { title: "النشاط التعاوني في مجموعات", minutes: s2, activity: "يقسّم المعلم الطلبة إلى مجموعات لحل ورقة عمل تطبيقية حول «" + t + "» مع متابعة الفروق الفردية." },
        { title: "التقويم الختامي والغلق", minutes: s3, activity: "تسميع سريع لأهم المصطلحات وحل سؤال التحدي للتأكد من تحقق الأهداف السلوكية." }
      ],
      worksheet: [
        "عرّف بأسلوبك المفهوم الرئيسي في درس «" + t + "» مع ذكر مثال توضيحي.",
        "استخرج من فقرة الكتاب أهم ثلاث نقاط أساسية يرتكز عليها درس «" + t + "».",
        "علّل: ما الأهمية العملية لتطبيق قواعد «" + t + "» في دراستنا لمادة " + s + "؟",
        "قارن بين الحالات الأساسية الواردة في الدرس من حيث الشروط والنتيجة.",
        "طبّق القاعدة التي تعلمتها في حل المسألة التدريبية رقم (1) في الكتاب المدرسي.",
        "سؤال تفكير عليا: اقترح موقفاً حياتياً يومياً نستخدم فيه «" + t + "»."
      ],
      quiz: [
        { q: "ما الهدف المحوري الذي يتناوله درس «" + t + "» في مادة " + s + "؟", options: ["فهم المفهوم الأساسي وتطبيقه عملياً", "حفظ العناوين دون تطبيق", "مراجعة وحدة غير مرتبطة", "تجاهل الأمثلة التطبيقية"], answer: 0 },
        { q: "عند تطبيق خطوات «" + t + "» فإن الخطوة الأولى الصحيحة هي:", options: ["تحديد المعطيات والقاعدة المناسبة للحل", "كتابة النتيجة عشوائياً", "تخطي قراءة السؤال", "الاعتماد على التخمين فقط"], answer: 0 },
        { q: "أيٌّ مما يلي يُعدّ من المهارات المكتسبة بعد دراسة «" + t + "»؟", options: ["القدرة على التفسير وحل التدريبات بدقة", "عدم التمييز بين المفاهيم", "نسيان القوانين السابقة", "إهمال خطوات التحقق"], answer: 0 },
        { q: "كيف نتحقق من صحة إجابتنا في تدريبات «" + t + "»؟", options: ["بمراجعة الخطوات ومطابقتها مع قاعدة الدرس", "بعدم مراجعة الحل", "بحذف المعطيات", "بتغيير السؤال"], answer: 0 },
        { q: "يرتبط درس «" + t + "» في " + g + " ارتباطاً مباشراً بـ:", options: ["الحياة العملية والمهارات التراكمية للمادة", "موضوعات خارج المنهاج", "الحفظ الأصم فقط", "الأنشطة غير الصفية فقط"], answer: 0 }
      ],
      homework: "حل سؤالي التقويم في نهاية درس «" + t + "» من الكتاب المدرسي، وتلخيص الفكرة الرئيسية في ثلاث جمل في دفتر المادة.",
      support: "بطاقة مصوّرة مبسّطة تحتوي على خطوات «" + t + "» محلولة خطوة بخطوة مع تمرين مباشر موجّه.",
      enrichment: "تكليف الطلبة المتميزين بتصميم خريطة ذهنية أو مسألة إبداعية حول «" + t + "» وعرضها أمام زملائهم.",
      keyTerms: [
        { q: "الفكرة الرئيسية لدرس «" + t + "»", a: m.notes ? m.notes.slice(0, 180) : ("إتقان مفاهيم وتطبيقات " + t + " في مادة " + s + " لـ " + g + ".") },
        { q: "الخطوة الأولى في تطبيق «" + t + "»", a: "قراءة المعطيات بدقة وتحديد القاعدة أو المفهوم المناسب من الدرس." },
        { q: "أهمية الدرس للطالب", a: "يبني أساساً متيناً للوحدات القادمة ويربط المادة بالحياة العملية." },
        { q: "سؤال المراجعة الذاتية", a: "ما أهم قاعدة تعلمتها اليوم في درس «" + t + "» وكيف أطبقها؟" }
      ]
    };
  }

  /* ---------- التوليد ---------- */
  function buildPrompt(m) {
    return "أنت معلم خبير ومصمم مناهج. أعدّ حقيبة حصة كاملة وفق المنهاج الفلسطيني وبما يناسب عمر الطلبة.\n" +
      "المعطيات: " + m.grade + " — مادة " + m.subject + " — عنوان الدرس: «" + m.title + "» — زمن الحصة " + m.minutes + " دقيقة.\n" +
      (m.notes ? "ملاحظات/نص من الكتاب أو المستخرج بالكاميرا (اعتمد عليه بدقة):\n" + m.notes.slice(0, 5000) + "\n" : "") +
      "أعد الناتج بصيغة JSON صالحة فقط (بلا أي نص قبلها أو بعدها وبلا علامات ```) وبهذه البنية بالضبط:\n" +
      '{"objectives":["3 إلى 4 أهداف سلوكية قابلة للقياس"],' +
      '"warmup":"نشاط تمهيدي قصير",' +
      '"steps":[{"title":"عنوان الخطوة","minutes":5,"activity":"ماذا يفعل المعلم والطلبة"}],' +
      '"worksheet":["6 إلى 8 أسئلة متنوعة ومتدرجة"],' +
      '"quiz":[{"q":"سؤال","options":["أ","ب","ج","د"],"answer":0}],' +
      '"homework":"واجب بيتي مناسب",' +
      '"support":"نشاط دعم للطلبة المتعثرين","enrichment":"نشاط إثراء للمتميزين",' +
      '"keyTerms":[{"q":"مصطلح أو سؤال مراجعة","a":"تعريف أو إجابة قصيرة"}]}\n' +
      "قواعد: الاختبار 5 أسئلة اختيار من متعدد بأربعة خيارات، و answer رقم الخيار الصحيح من 0 إلى 3. مجموع دقائق الخطوات يساوي زمن الحصة تقريباً. keyTerms من 6 إلى 8 عناصر. كل النصوص بالعربية الفصحى.";
  }

  function extractJson(txt) {
    var s = String(txt || "").replace(/```(?:json)?/gi, "").trim();
    var a = s.indexOf("{"), b = s.lastIndexOf("}");
    if (a < 0 || b <= a) return null;
    try { return JSON.parse(s.slice(a, b + 1)); } catch (e) { return null; }
  }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function str(v) { return String(v == null ? "" : v).trim(); }
  function normalize(o) {
    if (!o || typeof o !== "object") return null;
    var kit = {
      objectives: arr(o.objectives).map(str).filter(Boolean),
      warmup: str(o.warmup),
      steps: arr(o.steps).map(function (s) { return { title: str(s && s.title), minutes: Math.max(0, parseInt(s && s.minutes, 10) || 0), activity: str(s && s.activity) }; }).filter(function (s) { return s.title || s.activity; }),
      worksheet: arr(o.worksheet).map(str).filter(Boolean),
      quiz: arr(o.quiz).map(function (q) {
        var opts = arr(q && q.options).map(str).filter(Boolean).slice(0, 4);
        var ans = parseInt(q && q.answer, 10);
        return { q: str(q && q.q), options: opts, answer: ans >= 0 && ans < opts.length ? ans : 0 };
      }).filter(function (q) { return q.q && q.options.length >= 2; }),
      homework: str(o.homework), support: str(o.support), enrichment: str(o.enrichment),
      keyTerms: arr(o.keyTerms).map(function (k) { return { q: str(k && k.q), a: str(k && k.a) }; }).filter(function (k) { return k.q && k.a; })
    };
    var has = kit.objectives.length + kit.steps.length + kit.worksheet.length + kit.quiz.length;
    return has ? kit : null;
  }

  function generate() {
    var m = ST.meta;
    var capFiles = (window.EduSourceCapture && window.EduSourceCapture.getFiles) ? window.EduSourceCapture.getFiles() : [];
    if (m.title.trim().length < 2 && capFiles.length) {
      m.title = capFiles[0].name.replace(/\.[^.]+$/, "");
    }
    if (m.title.trim().length < 2) {
      toast("اكتب عنوان الدرس أو صوّر صفحة بالكاميرا أو اختر درساً من المنهاج أولاً", "warning");
      return;
    }
    if (window.EduBridge && window.EduBridge.setContext) {
      window.EduBridge.setContext({ topic: m.title, title: m.title, grade: m.grade, subject: m.subject, notes: m.notes });
    }
    if (!window.AI || !window.AI.ask) {
      ST.kit = buildInstantKit(m);
      ST.tab = "plan";
      saveHist({ id: "k" + Date.now().toString(36), ts: Date.now(), meta: Object.assign({}, m), kit: ST.kit });
      render();
      toast("تم توليد الحقيبة القياسية الفورية ✓", "success");
      return;
    }
    ST.busy = true; ST.err = ""; ST.raw = ""; render();
    window.AI.ask(buildPrompt(m), null, "studio").then(function (txt) {
      var kit = normalize(extractJson(txt));
      if (!kit) {
        ST.kit = buildInstantKit(m);
        ST.tab = "plan";
        toast("تم تجهيز الحقيبة المنظّمة للدرس ✓", "success");
        return;
      }
      ST.kit = kit; ST.tab = "plan"; ST.reveal = false;
      saveHist({ id: "k" + Date.now().toString(36), ts: Date.now(), meta: Object.assign({}, m), kit: kit });
      try { if (window.EduBadges && window.EduBadges.award) window.EduBadges.award("lesson_kit", 20, true); } catch (e) {}
    }).catch(function () {
      ST.kit = buildInstantKit(m);
      ST.tab = "plan";
      toast("تعذّر الاتصال بالإنترنت — تم توليد حقيبة الحصة الفورية بلا إنترنت ✓", "info");
    }).then(function () { ST.busy = false; render(); });
  }

  /* ---------- التصدير ---------- */
  function title() { return "حقيبة حصة — " + ST.meta.title; }
  function header(kind) {
    var m = ST.meta;
    return "# " + title() + "\n\n- " + m.grade + " • " + m.subject + " • " + m.minutes + " دقيقة" + (kind ? " • " + kind : "") + "\n";
  }
  function list(items) { return items.map(function (x) { return "- " + x; }).join("\n") + "\n"; }
  function numbered(items) { return items.map(function (x, i) { return (i + 1) + ". " + x; }).join("\n") + "\n"; }
  function quizMd(withKey) {
    return ST.kit.quiz.map(function (q, i) {
      var o = q.options.map(function (t, j) { return "   - " + LETTERS[j] + ") " + t; }).join("\n");
      return (i + 1) + ". " + q.q + "\n" + o + (withKey ? "\n   - **الإجابة الصحيحة: " + LETTERS[q.answer] + ") " + q.options[q.answer] + "**" : "");
    }).join("\n") + "\n";
  }
  function teacherMd() {
    var k = ST.kit, md = header("نسخة المعلم");
    if (k.objectives.length) md += "\n## الأهداف السلوكية\n" + list(k.objectives);
    if (k.warmup) md += "\n## التمهيد\n" + k.warmup + "\n";
    if (k.steps.length) md += "\n## خطوات تنفيذ الحصة\n" + k.steps.map(function (s, i) { return (i + 1) + ". **" + s.title + "**" + (s.minutes ? " (" + s.minutes + " د)" : "") + ": " + s.activity; }).join("\n") + "\n";
    if (k.worksheet.length) md += "\n## ورقة العمل\n" + numbered(k.worksheet);
    if (k.quiz.length) md += "\n## الاختبار القصير (مع الإجابات)\n" + quizMd(true);
    if (k.homework) md += "\n## الواجب البيتي\n" + k.homework + "\n";
    if (k.support || k.enrichment) md += "\n## التمايز\n" + list([k.support && ("**دعم:** " + k.support), k.enrichment && ("**إثراء:** " + k.enrichment)].filter(Boolean));
    if (k.keyTerms.length) md += "\n## مفردات ومفاهيم للمراجعة\n" + list(k.keyTerms.map(function (t) { return "**" + t.q + ":** " + t.a; }));
    return md;
  }
  function studentMd() {
    var k = ST.kit, m = ST.meta, md = "# " + m.title + "\n\n- " + m.grade + " • " + m.subject + "\n- اسم الطالب: ....................  الشعبة: ........\n";
    if (k.worksheet.length) md += "\n## ورقة العمل\n" + numbered(k.worksheet);
    if (k.quiz.length) md += "\n## اختبر نفسك (ضع دائرة حول الخيار المناسب)\n" + quizMd(false);
    if (k.homework) md += "\n## الواجب البيتي\n" + k.homework + "\n";
    return md;
  }
  function doExport(fmt, who) {
    if (!ST.kit || !window.Exporter) return;
    var md = who === "student" ? studentMd() : teacherMd();
    var t = (who === "student" ? "ورقة الطالب — " : "") + title();
    if (window.Exporter.save) window.Exporter.save(t, md, "حقيبة حصة");
    if (fmt === "docx") window.Exporter.docx(t, md);
    else window.Exporter.pdf(t, md);
  }
  function toReview() {
    if (!ST.kit) return;
    if (!window.EduReview || !window.EduReview.addCards) { toast("المراجعة الذكية غير جاهزة", "warning"); return; }
    var cards = ST.kit.keyTerms.slice();
    ST.kit.quiz.forEach(function (q) { cards.push({ q: q.q, a: q.options[q.answer] }); });
    var deck = ST.meta.subject + " — " + ST.meta.title.slice(0, 28);
    var n = window.EduReview.addCards(deck, cards);
    toast(n ? "أُضيفت " + n + " بطاقة إلى «" + deck + "» في المراجعة الذكية." : "هذه البطاقات موجودة مسبقاً.", "info");
    try { window.EduReview.render(); } catch (e) {}
  }

  /* ---------- الواجهة ---------- */
  var FIELD = "w-full text-xs sm:text-sm font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2.5 text-slate-900 dark:text-white focus:outline-none focus:border-brand-500";
  var LBL = "block text-xs font-black mb-1 text-slate-700 dark:text-slate-200";
  var BTN = "px-3.5 py-2 rounded-xl text-xs font-black transition active:scale-95 ";

  function ensureSection() {
    var ex = document.getElementById("lessonKitStudio");
    if (ex) return ex;
    var anchor = document.getElementById("reviewStudio") || document.getElementById("weeklyPlannerStudio") || document.getElementById("learnSection");
    if (!anchor || !anchor.parentNode) return null;
    var sec = document.createElement("section");
    sec.id = "lessonKitStudio";
    sec.className = "py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20";
    anchor.parentNode.insertBefore(sec, anchor);
    sec.addEventListener("click", onClick);
    sec.addEventListener("input", onInput);
    return sec;
  }
  function options(items, cur) { return items.map(function (x) { return '<option' + (x === cur ? " selected" : "") + '>' + esc(x) + '</option>'; }).join(""); }

  function tabBody() {
    var k = ST.kit, t = ST.tab;
    if (t === "plan") {
      return (k.objectives.length ? '<h3 class="font-black text-sm mb-1.5 text-brand-700 dark:text-brand-300">🎯 الأهداف السلوكية</h3><ul class="list-disc pr-5 space-y-1 text-sm">' + k.objectives.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul>" : "") +
        (k.warmup ? '<h3 class="font-black text-sm mt-4 mb-1.5 text-brand-700 dark:text-brand-300">☀️ التمهيد</h3><p class="text-sm leading-relaxed">' + esc(k.warmup) + "</p>" : "") +
        (k.steps.length ? '<h3 class="font-black text-sm mt-4 mb-1.5 text-brand-700 dark:text-brand-300">🧭 خطوات التنفيذ</h3><ol class="space-y-2">' + k.steps.map(function (s, i) {
          return '<li class="rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 p-3 text-sm"><b>' + (i + 1) + ". " + esc(s.title) + "</b>" + (s.minutes ? ' <span class="text-[11px] font-bold text-amber-600 dark:text-amber-400">(' + s.minutes + " د)</span>" : "") + '<div class="mt-1 leading-relaxed">' + esc(s.activity) + "</div></li>";
        }).join("") + "</ol>" : "");
    }
    if (t === "worksheet") return '<ol class="list-decimal pr-5 space-y-2.5 text-sm leading-relaxed">' + k.worksheet.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ol>";
    if (t === "quiz") {
      return '<div class="flex justify-end mb-2"><button type="button" data-lk="reveal" class="' + BTN + 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">' + (ST.reveal ? "إخفاء الإجابات" : "إظهار الإجابات") + "</button></div>" +
        '<ol class="space-y-3">' + k.quiz.map(function (q) {
          return '<li class="rounded-xl border border-slate-200 dark:border-slate-700 p-3 text-sm"><div class="font-bold mb-1.5">' + esc(q.q) + '</div><div class="grid sm:grid-cols-2 gap-1.5">' + q.options.map(function (o, j) {
            var ok = ST.reveal && j === q.answer;
            return '<div class="rounded-lg px-2.5 py-1.5 ' + (ok ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 font-black" : "bg-slate-50 dark:bg-slate-800/60") + '">' + LETTERS[j] + ") " + esc(o) + "</div>";
          }).join("") + "</div></li>";
        }).join("") + "</ol>";
    }
    if (t === "more") {
      return (k.homework ? '<h3 class="font-black text-sm mb-1.5 text-brand-700 dark:text-brand-300">🏠 الواجب البيتي</h3><p class="text-sm leading-relaxed">' + esc(k.homework) + "</p>" : "") +
        (k.support ? '<h3 class="font-black text-sm mt-4 mb-1.5 text-amber-700 dark:text-amber-300">🤝 نشاط دعم</h3><p class="text-sm leading-relaxed">' + esc(k.support) + "</p>" : "") +
        (k.enrichment ? '<h3 class="font-black text-sm mt-4 mb-1.5 text-emerald-700 dark:text-emerald-300">🚀 نشاط إثراء</h3><p class="text-sm leading-relaxed">' + esc(k.enrichment) + "</p>" : "");
    }
    return '<ul class="space-y-2">' + k.keyTerms.map(function (x) { return '<li class="rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 p-3 text-sm"><b>' + esc(x.q) + "</b><div class=\"mt-0.5\">" + esc(x.a) + "</div></li>"; }).join("") + "</ul>";
  }

  function resultView() {
    var k = ST.kit;
    if (!k) return "";
    var tabs = [["plan", "الخطة"], ["worksheet", "ورقة العمل (" + k.worksheet.length + ")"], ["quiz", "الاختبار (" + k.quiz.length + ")"], ["more", "الواجب والتمايز"], ["terms", "المراجعة (" + k.keyTerms.length + ")"]];
    return '<div class="rounded-2xl border border-slate-200 dark:border-slate-700 p-4 space-y-3">' +
      '<div class="flex flex-wrap gap-1.5">' + tabs.map(function (t) {
        return '<button type="button" data-lk="tab" data-tab="' + t[0] + '" class="' + BTN + (ST.tab === t[0] ? "bg-brand-600 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200") + '">' + t[1] + "</button>";
      }).join("") + "</div>" +
      '<div class="min-h-[120px] text-slate-800 dark:text-slate-100">' + tabBody() + "</div>" +
      '<div class="flex flex-wrap gap-2 pt-3 border-t border-slate-200 dark:border-slate-700">' +
        '<button type="button" data-lk="docx" class="' + BTN + 'bg-sky-600 hover:bg-sky-500 text-white"><i class="fa-solid fa-file-word ml-1"></i> الحقيبة Word</button>' +
        '<button type="button" data-lk="pdf" class="' + BTN + 'bg-rose-600 hover:bg-rose-500 text-white"><i class="fa-solid fa-file-pdf ml-1"></i> الحقيبة PDF</button>' +
        '<button type="button" data-lk="sdocx" class="' + BTN + 'bg-emerald-600 hover:bg-emerald-500 text-white"><i class="fa-solid fa-user-graduate ml-1"></i> ورقة الطالب Word</button>' +
        '<button type="button" data-lk="spdf" class="' + BTN + 'bg-emerald-700 hover:bg-emerald-600 text-white">ورقة الطالب PDF</button>' +
        '<button type="button" data-lk="review" class="' + BTN + 'bg-indigo-600 hover:bg-indigo-500 text-white"><i class="fa-solid fa-brain ml-1"></i> أضف للمراجعة الذكية</button>' +
      '</div>' +
      '<div class="p-3 rounded-2xl bg-indigo-50/70 dark:bg-slate-800/80 border border-indigo-200 dark:border-slate-700 space-y-2">' +
        '<div class="text-[11px] font-black text-indigo-800 dark:text-indigo-300">🔗 الخطوة التالية للمعلم والطالب — حوّل هذه الحقيبة بضغطة زر إلى:</div>' +
        '<div class="flex flex-wrap gap-1.5">' +
          '<button type="button" data-lk="tows" class="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-extrabold">📝 محرر أوراق العمل والاختبار الإلكتروني</button>' +
          '<button type="button" data-lk="togame" class="px-3 py-1.5 rounded-xl bg-fuchsia-600 hover:bg-fuchsia-500 text-white text-[11px] font-extrabold">🎮 مسابقة ولعبة صفية تفاعلية</button>' +
          '<button type="button" data-lk="toslides" class="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-[11px] font-extrabold">🎞 عرض تقديمي للشرح</button>' +
          '<button type="button" data-lk="totutor" class="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-[11px] font-extrabold">🤖 خريطة ذهنية بالمعلم الذكي</button>' +
          '<button type="button" data-lk="tobank" class="px-3 py-1.5 rounded-xl bg-cyan-700 hover:bg-cyan-600 text-white text-[11px] font-extrabold">🗃️ حفظ الأسئلة في بنكي</button>' +
          '<button type="button" data-lk="toplanner" class="px-3 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-[11px] font-extrabold">🗓️ جدولة في المخطط الأسبوعي</button>' +
        '</div>' +
      '</div></div>';
  }

  function render() {
    var sec = ensureSection();
    if (!sec) return;
    var m = ST.meta, hist = loadHist();
    var srcBarHtml = (window.EduSourceCapture && window.EduSourceCapture.renderBar) ? window.EduSourceCapture.renderBar("lk") : "";

    sec.innerHTML =
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl p-5 sm:p-7 space-y-4 text-right">' +
        '<div class="border-b border-slate-200 dark:border-slate-800 pb-4 flex flex-wrap items-center justify-between gap-2">' +
          '<div>' +
            '<div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-300 text-xs font-black mb-1"><i class="fa-solid fa-suitcase"></i><span>تحضير كامل بنقرة واحدة (بالكاميرا أو النص)</span></div>' +
            '<h2 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">🧳 حقيبة الحصة الجاهزة</h2>' +
            '<p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">اكتب عنوان الدرس أو صوّر صفحة الكتاب بالكاميرا أو ارفع ملفاً فتحصل على الأهداف والخطة وورقة العمل واختبار قصير وواجب وتمايز.</p>' +
          '</div>' +
        "</div>" +

        // شريط إضافة المصادر عبر الكاميرا أو الجهاز أو الصوت أو المنهاج
        srcBarHtml +

        '<div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">' +
          '<div><label class="' + LBL + '" for="lkGrade">الصف</label><select id="lkGrade" data-lk-f="grade" class="' + FIELD + '">' + options(GRADES, m.grade) + "</select></div>" +
          '<div><label class="' + LBL + '" for="lkSubject">المادة</label><select id="lkSubject" data-lk-f="subject" class="' + FIELD + '">' + options(SUBJECTS, m.subject) + "</select></div>" +
          '<div class="sm:col-span-2"><label class="' + LBL + '" for="lkTitle">عنوان الدرس</label><input id="lkTitle" data-lk-f="title" class="' + FIELD + '" value="' + esc(m.title) + '" maxlength="120" placeholder="مثال: الكسور العشرية"></div>' +
        "</div>" +
        '<div class="grid sm:grid-cols-4 gap-3">' +
          '<div><label class="' + LBL + '" for="lkMin">زمن الحصة</label><select id="lkMin" data-lk-f="minutes" class="' + FIELD + '">' + [30, 40, 45, 60, 90].map(function (n) { return "<option" + (n === +m.minutes ? " selected" : "") + ' value="' + n + '">' + n + " دقيقة</option>"; }).join("") + "</select></div>" +
          '<div class="sm:col-span-3"><label class="' + LBL + '" for="lkNotes">نص من الكتاب أو ملاحظاتك (أو صوّر الصفحة بالكاميرا أعلاه)</label><textarea id="lkNotes" data-lk-f="notes" rows="2" class="' + FIELD + '" placeholder="الصق فقرة من الدرس أو استخدم زر الكاميرا/الملفات أعلاه لتخرج الحقيبة مطابقة لمحتواه">' + esc(m.notes) + "</textarea></div>" +
        "</div>" +
        '<div class="flex flex-wrap items-center gap-2">' +
          '<button type="button" data-lk="gen" class="' + BTN + 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md"' + (ST.busy ? " disabled style='opacity:.6'" : "") + ">" + (ST.busy ? '<i class="fa-solid fa-circle-notch fa-spin ml-1"></i> جارٍ إعداد الحقيبة…' : '<i class="fa-solid fa-wand-magic-sparkles ml-1"></i> ولّد الحقيبة بالذكاء الاصطناعي') + "</button>" +
          '<button type="button" data-lk="instant" class="' + BTN + 'bg-emerald-600 hover:bg-emerald-500 text-white">⚡ توليد فوري (بلا إنترنت)</button>' +
          (hist.length ? '<select data-lk="hist" class="text-xs font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2.5 text-slate-800 dark:text-slate-100" aria-label="الحقائب السابقة"><option value="">📂 حقائب سابقة…</option>' + hist.map(function (h) { return '<option value="' + esc(h.id) + '">' + esc(h.meta.title + " — " + h.meta.grade) + "</option>"; }).join("") + "</select>" : "") +
        "</div>" +
        (ST.err ? '<div class="rounded-xl bg-amber-50 dark:bg-amber-900/20 border border-amber-300/60 text-amber-900 dark:text-amber-100 text-xs font-bold p-3">' + esc(ST.err) + "</div>" : "") +
        (ST.raw ? '<textarea readonly rows="8" class="' + FIELD + '">' + esc(ST.raw) + "</textarea>" : "") +
        resultView() +
      "</div>";

    if (window.EduSourceCapture && window.EduSourceCapture.bindBar) {
      window.EduSourceCapture.bindBar(sec, {
        titleId: "lkTitle",
        gradeId: "lkGrade",
        subjId: "lkSubject",
        notesId: "lkNotes",
        onPickPreset: function (p) {
          ST.meta.grade = p.grade || ST.meta.grade;
          ST.meta.subject = p.subject || ST.meta.subject;
          ST.meta.title = p.title || ST.meta.title;
          ST.meta.notes = p.notes || ST.meta.notes;
        },
        onRefresh: function () { render(); }
      });
    }
  }

  function onInput(e) {
    var f = e.target && e.target.dataset && e.target.dataset.lkF;
    if (f) ST.meta[f] = f === "minutes" ? +e.target.value : e.target.value;
  }
  function onClick(e) {
    var b = e.target.closest && e.target.closest("[data-lk]");
    if (!b || b.tagName === "SELECT") return;
    var a = b.dataset.lk;
    if (a === "gen") generate();
    else if (a === "instant") {
      if (!ST.meta.title.trim()) ST.meta.title = "الكسور العشرية";
      ST.kit = buildInstantKit(ST.meta);
      ST.tab = "plan";
      saveHist({ id: "k" + Date.now().toString(36), ts: Date.now(), meta: Object.assign({}, ST.meta), kit: ST.kit });
      render();
      toast("⚡ تم تجهيز حقيبة الحصة الفورية بنجاح ✓", "success");
    }
    else if (a === "tab") { ST.tab = b.dataset.tab; render(); }
    else if (a === "reveal") { ST.reveal = !ST.reveal; render(); }
    else if (a === "docx") doExport("docx", "teacher");
    else if (a === "pdf") doExport("pdf", "teacher");
    else if (a === "sdocx") doExport("docx", "student");
    else if (a === "spdf") doExport("pdf", "student");
    else if (a === "review") toReview();
    else if (a === "tows" && window.EduBridge) window.EduBridge.kitToWorksheet(ST.meta, ST.kit);
    else if (a === "togame" && window.EduBridge) window.EduBridge.kitToGame(ST.meta, ST.kit);
    else if (a === "toslides" && window.EduBridge) window.EduBridge.openTool("slidesStudio", { topic: ST.meta.title, grade: ST.meta.grade, subject: ST.meta.subject, notes: (ST.kit.objectives || []).join("\n") });
    else if (a === "totutor" && window.EduBridge) window.EduBridge.openTool("tutorStudio", { topic: ST.meta.title, grade: ST.meta.grade, subject: ST.meta.subject, mode: "mindmap" });
    else if (a === "tobank" && window.EduBridge) window.EduBridge.toBank(ST.kit.quiz || [], ST.meta);
    else if (a === "toplanner" && window.EduBridge) window.EduBridge.toPlanner("تنفيذ حصة: " + ST.meta.title + " (" + ST.meta.grade + ")", "", ST.meta.subject + ": " + ST.meta.title);
  }
  document.addEventListener("change", function (e) {
    var s = e.target;
    if (!s || !s.dataset || s.dataset.lk !== "hist" || !s.value) return;
    var h = loadHist().filter(function (x) { return x.id === s.value; })[0];
    if (!h) return;
    ST.meta = Object.assign({ notes: "" }, h.meta); ST.kit = normalize(h.kit); ST.tab = "plan"; ST.reveal = false; ST.err = ""; ST.raw = "";
    render();
  });

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", render);
  else render();

  window.EduLessonKit = { render: render, normalize: normalize, extractJson: extractJson, toMarkdown: function (k, m) { var o = ST.kit, om = ST.meta; ST.kit = k; ST.meta = m || om; var t = teacherMd(); ST.kit = o; ST.meta = om; return t; } };
})();

/*
 * مركز التطبيقات الذكي، شريط مسارات المنصة المنظّم، ونظام الشاشات المستقلة للأدوات — EduTech Mindset (الإصدار 76)
 * التطويرات الكبرى:
 * 1) شريط المسارات الرئيسية الذكي (#eduMainTrackBar): يقسّم الصفحة الرئيسية إلى مسارات نظيفة ومرتبة
 *    (🧭 مركز الأدوات الـ 42 | 🏫 المراحل والدروس | 📖 الكتب والمناهج | 📚 المكتبة التعليمية | 👨‍🎓 مساحتي الشخصية | 🇵🇸 من نحن وتواصل | 📜 عرض شامل)
 *    لمنع تكدّس الأقسام الطويلة فوق بعضها.
 * 2) دمج أداة «🗓️ المخطط الأسبوعي الذكي وجدول المهام» (الأداة رقم 42).
 * 3) ربط مباشر بإعدادات الإدارة للأدوات (studiosConfig) واقتراح الأدوات الذكي.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "info"); };

  var APPS = [
    { id: "teamPersonasStudio", title: "مختبر شخصيات الفريق التعليمي (باسل، صابرين، بيان، ليان)", desc: "حاور فريق معلمي EduTech Mindset بالصوت والنص في الرياضيات والعربية والإنجليزية والـ AI", ico: "👨‍🏫", cat: "student", roles: ["student", "tawjihi", "teacher", "parent"], color: "from-amber-500 to-indigo-700", badge: "جديد v146 ⭐", featured: true },
    { id: "aiTeacherAcademyStudio", title: "أكاديمية أدوات الـ AI العالمية للمعلمين", desc: "محاكي MagicSchool وCuripod وKhanmigo وDiffit وBrisk Teaching مع شهادة تدريب فورية", ico: "🪄", cat: "prep", roles: ["teacher", "admin"], color: "from-purple-600 to-indigo-800", badge: "جديد v146 ⭐", featured: true },
    { id: "reelsPodcastStudio", title: "سينما الموشن جرافيك (9:16) وبودكاست الاستوديو", desc: "فيديوهات 9:16 المشكولة (أحياء وفيزياء التوجيهي وكيمياء الرابع) وحلقات بودكاست المنصة", ico: "🎬", cat: "labs", roles: ["student", "tawjihi", "teacher"], color: "from-rose-600 to-amber-600", badge: "جديد v146 ⭐", featured: true },
    // البوابات التنظيمية الشاملة وأدوات المعلم والطالب والجامعي وولي الأمر والجمهور
    { id: "smartUnifiedCockpit", cat: "student", roles: ["university", "student", "teacher", "tawjihi", "parent", "public"], badge: "الإصدار 90 • درايف + ثقافة + بلا إنترنت", ico: "🧭", title: "مركز القيادة الذكي: كتب Google Drive + المكتبة الثقافية + القاعدة البرمجية الخفية", desc: "فصل ملفات الـ Markdown لتغذية الموقع بلا إنترنت، عرض الكتب الأصلية وكتب جوجل درايف والكتب الثقافية مع حفظ أين وصلت، وتنسيق الأدوات المدمج", color: "from-sky-700 to-indigo-950" },
    { id: "stemLabPlannerStudio", cat: "student", roles: ["university", "student", "teacher", "tawjihi", "parent", "public"], badge: "جديد • معادلات + جدول + صياغة", ico: "🧪", title: "استوديو المختبر التفاعلي للمعادلات، المخطط الذكي، ومدقق الصياغة الأكاديمية", desc: "حل المسائل العلمية خطوة بخطوة مع رسم بياني SVG، جدول مراجعة مرتبط بكتبك مع مؤقت بومودورو، وإعادة صياغة أكاديمية (AR/EN)", color: "from-emerald-700 to-slate-950" },
    { id: "smartNotesFlashStudio", cat: "student", roles: ["university", "student", "teacher", "tawjihi", "parent", "public"], badge: "جديد • كورنيل + استدعاء نشط", ico: "📓", title: "استوديو دفتر كورنيل الذكي ومدرب الاستدعاء النشط", desc: "تلخيص فصول الكتب بنظام كورنيل الثلاثي العالمي، إخفاء الشرح للتسميع الذاتي، تمارين إكمال الفراغات (Cloze)، والمصطلحات المزدوجة", color: "from-amber-700 to-indigo-950" },
    { id: "visualConceptExamStudio", cat: "student", roles: ["university", "student", "teacher", "tawjihi", "parent", "public"], badge: "جديد • خرائط + امتحان موقوت", ico: "🗺️", title: "استوديو الخرائط المفاهيمية ومحاكي قاعة الامتحان الموقوت", desc: "رسم خرائط مفاهيمية ومخططات انسيابية تفاعلية من كتب الـ Markdown، ومحاكي امتحان رسمي بالعد التنازلي والتشخيص الفوري", color: "from-cyan-700 to-indigo-950" },
    { id: "masteryAnalyticsStudio", cat: "student", roles: ["university", "student", "teacher", "tawjihi", "parent", "public"], badge: "جديد • حقيبة 5×1 + مرصد", ico: "📈", title: "مرصد الإتقان الذكي ومولّد الحقيبة الذهبية الشاملة (5 في 1)", desc: "لوحة قياس الإتقان عبر المنصة وتوليد الحقيبة الذهبية للدرس (ملخص + قاموس ثنائي + ورقة عمل متمايزة + اختبار + حل) والنسخ الاحتياطي الشخصي", color: "from-emerald-700 to-teal-950" },
    { id: "multiSourceSynthStudio", cat: "student", roles: ["university", "student", "teacher", "tawjihi", "parent", "public"], badge: "جديد • بودكاست + دمج", ico: "🎙️", title: "استوديو البودكاست التعليمي ومصفوفة دمج المصادر", desc: "تحويل فصول الكتب وقاعدة بيانات الـ Markdown إلى حوار صوتي ناطق بين متحدثين ومصفوفة مقارنة وأسئلة تفكير عليا", color: "from-teal-600 to-indigo-900" },
    { id: "uniResearchCareerStudio", cat: "student", roles: ["university", "tawjihi", "teacher", "student", "public"], badge: "جديد • أبحاث + مقابلات", ico: "🔬", title: "استوديو الأبحاث الجامعية وتوثيق APA ومحاكي المقابلات", desc: "توليد مقترح مشروع التخرج مع Abstract إنجليزي، توثيق المراجع بنظام APA/IEEE من كتب الموقع، والتدرب على المقابلات الوظيفية والمنح", color: "from-indigo-800 to-emerald-900" },
    { id: "cvBuilderStudio", cat: "student", roles: ["university", "tawjihi", "student", "teacher", "public"], badge: "جديد • عربي + English", ico: "📄", title: "منشئ السيرة الذاتية الاحترافية (CV) بالعربية والإنجليزية", desc: "تصميم سيرة ذاتية جامعية ومهنية متوافقة مع ATS باللغتين العربية والإنجليزية مع ترجمة فورية وخطاب تقديم وتصدير PDF وWord", color: "from-indigo-700 to-slate-900" },
    { id: "bookReaderStudio", cat: "student", roles: ["university", "student", "teacher", "tawjihi", "parent", "early", "public"], badge: "جديد • قارئ تفاعلي", ico: "📖", title: "قارئ ومعاين الكتب التفاعلي الذكي", desc: "اقرأ كتب المنهاج مقسّمة للفصول أو عاين ملفات PDF، ظلّل أي فقرة وأرسلها مباشرة لـ 13 أداة مع دفتر مقتطفات", color: "from-amber-500 to-indigo-800" },
    { id: "unifiedWorkflowStudio", cat: "teacher", roles: ["university", "teacher", "student", "parent", "public", "tawjihi", "early"], badge: "جديد • ربط شامل", ico: "⚡", title: "غرفة العمليات التعليمية الموحّدة", desc: "اكتب موضوع الدرس مرة واحدة وانتقل به فوراً بين جميع أدوات المعلم والطالب وولي الأمر مع سجل مهام مشترك", color: "from-amber-500 to-indigo-800" },
    { id: "parentPortalStudio", cat: "admin", roles: ["parent", "teacher", "student"], badge: "جديد • بوابة الأسرة", ico: "👨‍👩‍👧‍👦", title: "بوابة ولي الأمر ومتابعة الأبناء", desc: "متابعة درجات وواجبات الأبناء برمز الفصل، خطة المذاكرة المنزلية بالذكاء الاصطناعي، وشهادة تشجيع أسرية", color: "from-teal-600 to-emerald-800" },
    { id: "publicHubStudio", cat: "student", roles: ["public", "student", "teacher", "parent"], badge: "جديد • مجتمع مفتوح", ico: "🌍", title: "بوابة الجمهور العام والمجتمع المعرفي", desc: "الدورات التدريبية المفتوحة، الثقافة العامة، أطلس فلسطين، ومختبرات الذكاء الاصطناعي والبرمجة للجميع", color: "from-sky-600 to-indigo-900" },
    { id: "lessonKitStudio", cat: "teacher", roles: ["teacher"], badge: "جديد • حقيبة كاملة", ico: "🧳", title: "حقيبة الحصة الجاهزة", desc: "اكتب عنوان الدرس فتحصل على أهداف وخطة وورقة عمل واختبار وواجب وتمايز، مع تصدير Word وPDF", color: "from-indigo-600 to-violet-800" },
    { id: "reviewStudio", cat: "student", roles: ["university", "student", "tawjihi", "teacher", "parent", "public"], badge: "جديد • ذاكرة", ico: "🧠", title: "المراجعة الذكية بالتكرار المتباعد", desc: "بطاقات تعود إليك في الوقت المناسب، هدف يومي وسلسلة أيام، وتوليد بطاقات بالذكاء الاصطناعي", color: "from-emerald-600 to-teal-800" },
    { id: "weeklyPlannerStudio", cat: "teacher", roles: ["university", "teacher", "student", "tawjihi", "parent", "public"], badge: "جديد • خطة أسبوعية", ico: "🗓️", title: "المخطط الأسبوعي الذكي وجدول المهام", desc: "جدول حصص ومذاكرة أسبوعي تفاعلي مع قوالب جاهزة للمعلم والطالب وولي الأمر والتوجيهي وطباعة أنيقة", color: "from-indigo-600 to-violet-700" },
    { id: "worksheetStudio", cat: "teacher", roles: ["teacher", "tawjihi"], badge: "AI + PDF", ico: "📝", title: "مولّد أوراق العمل والاختبارات", desc: "توليد أوراق عمل واختبارات إلكترونية وبنك أسئلة وباركود QR بلا إنترنت", color: "from-emerald-600 to-teal-700" },
    { id: "slidesStudio", cat: "teacher", roles: ["teacher"], badge: "PPTX + حي", ico: "🎞", title: "مولّد العروض التقديمية", desc: "شرائح تفاعلية مع تصويت حي وتصدير PowerPoint وPDF", color: "from-sky-600 to-blue-700" },
    { id: "lessonPlanStudio", cat: "teacher", roles: ["teacher"], badge: "تحضير وزاري", ico: "📘", title: "مولّد خطط الدروس", desc: "تحضير وزاري ومبسط للحصص والوحدات مع تصدير Word", color: "from-indigo-600 to-blue-800" },
    { id: "whiteboardStudio", cat: "teacher", roles: ["teacher", "student"], badge: "تسجيل فيديو", ico: "🖍️", title: "السبورة التفاعلية الذكية", desc: "رسم وأشكال وشرح فوق الكتاب وتسجيل فيديو وحل بالـ AI", color: "from-slate-700 to-emerald-900" },
    { id: "homeworkStudio", cat: "teacher", roles: ["teacher", "student", "parent"], badge: "Vision AI", ico: "📸", title: "مصحح الدفاتر والواجبات المصوّرة", desc: "قراءة خط يد الطالب وتصحيح دفاتره بالكاميرا وربطها بالخطط العلاجية", color: "from-rose-600 to-pink-800" },
    { id: "teacherTools", cat: "teacher", roles: ["teacher"], badge: "NotebookLM", ico: "🪄", title: "محضّر الحصة ودفتر المصادر", desc: "صوّر صفحات الكتاب لتحضير الدرس، أو ارفع ملفاتك واسأل عنها", color: "from-amber-600 to-orange-700" },
    { id: "aiStudio", cat: "teacher", roles: ["teacher", "student", "public"], badge: "مساعد AI", ico: "🤖", title: "استوديو الذكاء الاصطناعي التربوي", desc: "توليد فوري لخطط الدروس والأنشطة والاختبارات التفاعلية", color: "from-purple-600 to-indigo-800" },
    { id: "rubricsStudio", cat: "teacher", roles: ["teacher"], badge: "تصحيح سريع", ico: "🫧", title: "أوراق التظليل وسلالم التقدير", desc: "ورقة تظليل دوائر للتصحيح السريع ومعايير تقييم المشاريع", color: "from-violet-600 to-purple-800" },
    { id: "designStudio", cat: "teacher", roles: ["teacher"], badge: "بوسترات", ico: "🎨", title: "مولّد الإنفوغرافيك والبوسترات", desc: "تصميم لوحات تعليمية وبوسترات إعلانية جاهزة للطباعة", color: "from-amber-600 to-orange-700" },
    { id: "generator", cat: "teacher", roles: ["teacher", "public", "student"], badge: "هرم بلوم", ico: "✨", title: "مولّد البرومبتات وهرم بلوم", desc: "صياغة أوامر ذكاء اصطناعي وأهداف سلوكية دقيقة", color: "from-cyan-600 to-sky-700" },
    { id: "teacherDash", cat: "teacher", roles: ["teacher"], badge: "إدارة أعمالي", ico: "🗂", title: "لوحة المعلم الشاملة", desc: "كل أعمالك واختباراتك المنشورة ونتائج طلابك في مكان واحد", color: "from-slate-700 to-slate-900" },
    { id: "questionBank", call: "EduStudy.bank", cat: "teacher", roles: ["teacher", "tawjihi"], badge: "حفظ وتصدير", ico: "🗃️", title: "بنك الأسئلة التفاعلي", desc: "احفظ أسئلتك وولّد المزيد وصدّرها واختبر نفسك منها", color: "from-teal-500 to-cyan-700" },

    // أدوات الطالب والمذاكرة
    { id: "learnSection", cat: "student", roles: ["student", "teacher", "parent", "tawjihi", "early"], badge: "منهاج كامل", ico: "🏫", title: "المراحل الدراسية والدروس", desc: "فيديوهات وملخصات وأوراق عمل واختبارات لكل صف ومادة", color: "from-emerald-600 to-cyan-700" },
    { id: "booksSection", cat: "student", roles: ["student", "teacher", "parent", "tawjihi"], badge: "كتب الوزارة", ico: "📖", title: "الكتب والمناهج المدرسية", desc: "تصفح الكتب المدرسية وتوليد ملخصات وأسئلة من دروسها", color: "from-blue-600 to-indigo-700" },
    { id: "classroomsStudio", cat: "student", roles: ["student", "teacher", "parent"], badge: "فصول افتراضية", ico: "🎒", title: "الفصول الافتراضية وبوابة الطالب", desc: "دخول الفصل بالرمز ومتابعة الواجبات وسجل الدرجات التراكمي", color: "from-sky-600 to-indigo-800" },
    { id: "tutorStudio", cat: "student", roles: ["student", "tawjihi", "parent"], badge: "شرح + خرائط", ico: "🧠", title: "المعلم الخصوصي الذكي والخرائط", desc: "شرح سقراطي، بطاقات استذكار قلّابة، خرائط ذهنية، وبودكاست", color: "from-teal-600 to-cyan-800" },
    { id: "tawjihiStudio", cat: "student", roles: ["university", "tawjihi", "student"], badge: "توجيهي فلسطين", ico: "🎓", title: "بوابة التوجيهي وحاسبة المعدل", desc: "حساب معدل التوجيهي الرسمي وجدول المراجعة والمستشار الجامعي", color: "from-amber-600 to-indigo-900" },
    { id: "offPackStudio", cat: "student", roles: ["student", "tawjihi", "parent"], badge: "بلا إنترنت", ico: "📥", title: "حقيبة المذاكرة التفاعلية بلا إنترنت", desc: "ملخصات ودروس واختبارات ذاتية وبطاقات قلّابة وقوانين في ملف مستقل", color: "from-cyan-600 to-blue-800" },
    { id: "libraryStudio", cat: "student", roles: ["university", "student", "tawjihi", "teacher", "parent", "public"], badge: "ملخصات", ico: "📚", title: "مكتبة المواد الدراسية", desc: "فيديوهات وملخصات واختبارات قصيرة لكل مادة دراسية", color: "from-sky-700 to-indigo-900" },
    { id: "sciCalcStudio", cat: "student", roles: ["student", "tawjihi", "teacher"], badge: "حاسبة + دوال", ico: "🧮", title: "الحاسبة العلمية وراسم الدوال والقوانين", desc: "حاسبة علمية، راسم دوال بياني، حل معادلات ونظام 2×2، وقوانين", color: "from-blue-700 to-indigo-900" },
    { id: "selfQuiz", call: "EduStudy.quiz", cat: "student", roles: ["student", "teacher", "parent", "tawjihi", "early"], badge: "تصحيح فوري", ico: "🎯", title: "اختبر نفسك بالذكاء الاصطناعي", desc: "أسئلة يولّدها الذكاء الاصطناعي من أي درس مع تصحيح وتعليل فوري", color: "from-violet-500 to-indigo-700" },
    { id: "dailyChallenge", call: "EduStudy.daily", cat: "student", roles: ["student", "early", "tawjihi", "teacher", "parent", "public"], badge: "تحدي يومي", ico: "🔥", title: "التحدي اليومي السريع", desc: "5 أسئلة جديدة كل يوم مع سلسلة أيام متتالية ونقاط XP", color: "from-orange-500 to-red-600" },
    { id: "voiceSettings", call: "EduVoice.open", cat: "student", roles: ["student", "teacher", "parent", "public", "early", "tawjihi"], badge: "نطق صوتي", ico: "🔊", title: "الصوت والقارئ الذكي", desc: "اختر الصوت والسرعة لكل أزرار القراءة، وحدّد أي نص لسماعه", color: "from-sky-500 to-blue-700" },
    { id: "coursesSection", cat: "student", roles: ["student", "teacher", "public", "parent"], badge: "تدريب", ico: "🏅", title: "الدورات التدريبية", desc: "دورات المنصة المعتمدة والتسجيل المباشر عبر واتساب", color: "from-lime-600 to-green-700" },

    // المختبرات والألعاب التفاعلية
    { id: "gamesStudio", cat: "labs", roles: ["student", "teacher", "parent", "early"], badge: "5 ألعاب + PIN", ico: "🎮", title: "الألعاب التربوية والمسابقات الحية", desc: "5 أنماط ألعاب + غرفة مسابقات صفية حية برمز PIN", color: "from-fuchsia-600 to-purple-800" },
    { id: "simLabStudio", cat: "labs", roles: ["student", "teacher", "tawjihi", "public"], badge: "STEM Lab", ico: "🧪", title: "مختبر التجارب العلمية (STEM Lab)", desc: "محاكيات تفاعلية للفيزياء والكيمياء والأحياء والرياضيات", color: "from-indigo-700 to-blue-900" },
    { id: "codingLabStudio", cat: "labs", roles: ["student", "teacher", "public"], badge: "برمجة + روبوت", ico: "💻", title: "أكاديمية البرمجة والروبوتكس", desc: "محرر كود تفاعلي وتحديات خوارزميات الروبوت لمنهاج التكنولوجيا", color: "from-emerald-700 to-slate-900" },
    { id: "langLabStudio", cat: "labs", roles: ["student", "parent", "public", "early"], badge: "نطق + إعراب", ico: "🗣️", title: "معمل اللغات والنطق والإملاء", desc: "مدرب النطق بالميكروفون، الإملاء المسموع، والمعرب النحوي", color: "from-sky-600 to-blue-800" },
    { id: "storiesStudio", cat: "labs", roles: ["early", "student", "teacher", "parent"], badge: "قصص ناطقة", ico: "📚", title: "استوديو القصص المصوّرة الناطقة", desc: "تحويل الدروس إلى قصص مصورة من 5 مشاهد مع راوٍ صوتي", color: "from-purple-600 to-fuchsia-800" },
    { id: "earlyLearnStudio", cat: "labs", roles: ["early", "teacher", "parent"], badge: "الصفوف 1–4", ico: "🧸", title: "استوديو التأسيس والصفوف (1–4)", desc: "كراسات تتبّع الحروف المنقّطة والعدّ البصري والحروف الناطقة", color: "from-pink-600 to-rose-700" },
    { id: "atlasStudio", cat: "labs", roles: ["student", "teacher", "public", "parent"], badge: "خريطة تفاعلية", ico: "🗺️", title: "أطلس فلسطين الجغرافي والتاريخي", desc: "خريطة مدن وتضاريس فلسطين وتحدي الخريطة الصمّاء", color: "from-emerald-700 to-teal-900" },
    { id: "arSection", cat: "labs", roles: ["student", "teacher"], badge: "كاميرا AR", ico: "🔬", title: "الواقع المعزز التلقائي", desc: "توجيه الكاميرا نحو رسوم الكتاب للتعرف على أجزائها حياً", color: "from-teal-700 to-slate-900" },
    { id: "edtechLabSection", cat: "labs", roles: ["teacher", "student"], badge: "أدوات ومؤقت", ico: "⚡", title: "مختبر التكنولوجيا التفاعلي", desc: "مؤقت الحصة الذكي، القرعة، بطاقات التفكير، ومولد سلالم التقدير", color: "from-cyan-700 to-blue-900" },

    // الإدارة الصفية والتقارير والأدوات المساعدة
    { id: "sourcesStudio", cat: "admin", roles: ["university", "teacher", "student", "tawjihi"], badge: "كاميرا + PDF", ico: "📷", title: "مصادري: كتب المنهاج وصور الصفحات", desc: "ارفع كتاب المنهاج أو صوّر صفحاته بالكاميرا ليجيب المساعد الذكي منها", color: "from-rose-700 to-red-900" },
    { id: "portfolioStudio", cat: "admin", roles: ["teacher"], badge: "ملف المعلم", ico: "📁", title: "ملف الإنجاز المهني والخطط العلاجية", desc: "ملف إنجاز المعلم PDF والخطط العلاجية والإثرائية والكتب الرسمية", color: "from-indigo-700 to-slate-900" },
    { id: "inclusiveStudio", cat: "admin", roles: ["early", "teacher", "student", "parent"], badge: "دعم نفسي IEP", ico: "💚", title: "التعليم الدامج والدعم النفسي والقارئ", desc: "أنشطة الدعم النفسي والقارئ الميسّر لصعوبات القراءة والخطة الفردية IEP", color: "from-teal-600 to-emerald-800" },
    { id: "certStudio", cat: "admin", roles: ["teacher"], badge: "شهادات PDF", ico: "🏅", title: "مولّد الشهادات الجماعية", desc: "إصدار دفتر شهادات PDF أو صور PNG لقائمة طلاب كاملة", color: "from-amber-500 to-orange-700" },
    { id: "parentsStudio", cat: "admin", roles: ["teacher", "parent", "early"], badge: "واتساب", ico: "👨‍👩‍👧‍👦", title: "تقارير أولياء الأمور وبطاقة المتابعة", desc: "إصدار بطاقة متابعة الطالب وإرسالها لواتساب ولي الأمر", color: "from-teal-700 to-emerald-800" },
    { id: "classToolsStudio", cat: "admin", roles: ["teacher"], badge: "إدارة الصف", ico: "🧰", title: "حقيبة إدارة الصف والجدول المدرسي", desc: "القرعة العشوائية، مقسّم المجموعات، مؤقت الحصة، والجدول الأسبوعي", color: "from-emerald-700 to-teal-900" },
    { id: "radioStudio", cat: "admin", roles: ["teacher", "student", "public"], badge: "إذاعة صباحية", ico: "🎙️", title: "الإذاعة المدرسية والمسابقات الثقافية", desc: "توليد برنامج إذاعة صباحية متكامل ومسابقات بين الفصول", color: "from-amber-600 to-teal-800" },
    { id: "mediaToolsStudio", cat: "admin", roles: ["teacher", "student", "tawjihi", "public", "parent"], badge: "ضغط 85%", ico: "🗜️", title: "ضغط الصور ودمجها في PDF محلياً", desc: "تقليص حجم الصور 85% وتحويل صور الدفتر لملف PDF بلا إنترنت", color: "from-cyan-700 to-slate-900" },
    { id: "analyticsStudio", cat: "admin", roles: ["teacher"], badge: "تقارير", ico: "📊", title: "مرصد الإحصاءات وتغطية المنهاج", desc: "إحصاءات المحتوى عبر المراحل وطباعة تقرير الإنجاز الإداري", color: "from-slate-800 to-cyan-900" }
  ];

  var DAILY_SPARKS = [
    "💡 فكرة للمعلم: استخدم «مولّد أوراق العمل» لتوليد ورقة عمل بمستويين (تأسيسي ومتقدم) من نفس الدرس خلال 30 ثانية لمراعاة الفروق الفردية.",
    "🗓️ تنظيم الوقت: افتح «المخطط الأسبوعي الذكي» وحمّل قالب المعلم أو التوجيهي بضغطة واحدة لتنظيم جدولك الأسبوعي وطباعته.",
    "🎯 نصيحة للطالب: حوّل أي درس طويل في «المعلم الخصوصي الذكي» إلى خريطة ذهنية وبطاقات استذكار قلّابة لتثبيت المفاهيم قبل الامتحان.",
    "🖍️ استراتيجية صفية: افتح «السبورة التفاعلية الذكية» بوضع ملء الشاشة واشرح مباشرة فوق صورة صفحة الكتاب مع تسجيل الشرح كفيديو لطلابك.",
    "📥 ميزة بلا إنترنت: جهّز «حقيبة المذاكرة المحمولة بلا إنترنت» لطلابك ليتصفحوا الملخصات والاختبارات الذاتية على هواتفهم دون الحاجة للاتصال.",
    "📸 توفير وقت المعلم: صوّر صفحة من الكتاب في «محضّر الحصة ودفتر المصادر» لتحصل فوراً على خطة درس كاملة واختبار قصير ورسالة لولي الأمر.",
    "🎮 تفاعل صفي: أنشئ مسابقة صفية حية من 5 أسئلة في «الألعاب التربوية» لتنشيط الحصة ومراجعة الدرس السابق بطريقة ممتعة."
  ];
  var sparkIdx = new Date().getDate() % DAILY_SPARKS.length;

  // المسارات المنظّمة للصفحة الرئيسية (تمنع تكدس الأقسام الطويلة تحت بعضها)
  var MAIN_TRACKS = [
    { id: "hub", ico: "🧭", label: "مركز الأدوات والبوابات", sections: ["smartHubSection", "unifiedWorkflowStudio", "coursesSection"] },
    { id: "learn", ico: "🏫", label: "المراحل والدروس", sections: ["learnSection"] },
    { id: "books", ico: "📖", label: "الكتب والقارئ التفاعلي", sections: ["bookReaderStudio", "booksSection"] },
    { id: "family", ico: "👨‍👩‍👧‍👦", label: "بوابة ولي الأمر والأسرة", sections: ["parentPortalStudio", "parentsStudio"] },
    { id: "public", ico: "🌍", label: "الجمهور والمكتبة", sections: ["publicHubStudio", "library", "modsSection", "quickLinksSection"] },
    { id: "workspace", ico: "👨‍🎓", label: "مساحتي وإنجازاتي", sections: ["userWorkspaceSection"] },
    { id: "about", ico: "🇵🇸", label: "عن المنصة وتواصل", sections: ["about", "social"] },
    { id: "all", ico: "📜", label: "عرض شامل", sections: ["smartHubSection", "smartUnifiedCockpit", "stemLabPlannerStudio", "smartNotesFlashStudio", "visualConceptExamStudio", "masteryAnalyticsStudio", "multiSourceSynthStudio", "uniResearchCareerStudio", "cvBuilderStudio", "bookReaderStudio", "unifiedWorkflowStudio", "parentPortalStudio", "publicHubStudio", "coursesSection", "learnSection", "booksSection", "library", "modsSection", "quickLinksSection", "userWorkspaceSection", "social", "about"] }
  ];

  var ALWAYS_TOP_IDS = ["hero", "eduOrganizedPlatformRoot", "homeAds", "homeVideos", "slot-top", "slot-mid", "slot-bottom"];

  var STUDIO_SECTION_IDS = [
    "teamPersonasStudio", "aiTeacherAcademyStudio", "reelsPodcastStudio",
    "smartUnifiedCockpit", "stemLabPlannerStudio", "smartNotesFlashStudio", "visualConceptExamStudio", "masteryAnalyticsStudio", "multiSourceSynthStudio", "uniResearchCareerStudio", "cvBuilderStudio", "bookReaderStudio", "unifiedWorkflowStudio", "parentPortalStudio", "publicHubStudio", "lessonKitStudio", "reviewStudio", "weeklyPlannerStudio", "worksheetStudio", "slidesStudio", "lessonPlanStudio", "whiteboardStudio", "homeworkStudio",
    "teacherTools", "aiStudio", "rubricsStudio", "designStudio", "generator", "teacherDash",
    "classroomsStudio", "tutorStudio", "tawjihiStudio", "offPackStudio", "libraryStudio",
    "sciCalcStudio", "coursesSection", "gamesStudio", "simLabStudio", "codingLabStudio",
    "langLabStudio", "storiesStudio", "earlyLearnStudio", "atlasStudio", "arSection",
    "edtechLabSection", "sourcesStudio", "portfolioStudio", "inclusiveStudio", "certStudio",
    "parentsStudio", "classToolsStudio", "radioStudio", "mediaToolsStudio", "analyticsStudio",
    "learnSection", "booksSection", "library", "userWorkspaceSection", "about", "social"
  ];

  var ROLES = [
    { id: "all", label: "🌟 جميع البوابات" },
    { id: "student", label: "👨‍🎓 بوابة الطالب" },
    { id: "teacher", label: "👨‍🏫 بوابة المعلم" },
    { id: "university", label: "🎓 الجامعي والخريجون (CV)" },
    { id: "parent", label: "👨‍👩‍👧‍👦 بوابة ولي الأمر" },
    { id: "public", label: "🌍 الجمهور العام" },
    { id: "tawjihi", label: "🎓 التوجيهي" },
    { id: "early", label: "🧸 التأسيس (1–4)" }
  ];

  function getStudiosConfig() {
    try {
      var site = (window.EduHome && window.EduHome.getSite) ? window.EduHome.getSite() : {};
      return site.studiosConfig || {};
    } catch (x) {
      return {};
    }
  }

  function isAppVisible(a, cfg) {
    var c = (cfg || getStudiosConfig())[a.id];
    return !(c && c.visible === false);
  }

  function isAppFeatured(a, cfg) {
    var c = (cfg || getStudiosConfig())[a.id];
    return !!(c && c.featured);
  }

  function getAppBadge(a, cfg) {
    var c = (cfg || getStudiosConfig())[a.id];
    return (c && c.badge) ? c.badge : (a.badge || "");
  }

  function getCategoriesWithCounts() {
    var recIds = getRecentIds();
    var pinIds = getPinnedIds();
    var cfg = getStudiosConfig();
    var roleFiltered = APPS.filter(function (a) {
      if (!isAppVisible(a, cfg)) return false;
      return !st.roleMode || st.roleMode === "all" || (a.roles || []).indexOf(st.roleMode) !== -1;
    });
    var cnt = function (cat) {
      if (cat === "all") return roleFiltered.length;
      if (cat === "pinned") return roleFiltered.filter(function (a) { return pinIds.indexOf(a.id) !== -1 || isAppFeatured(a, cfg); }).length;
      if (cat === "recent") return roleFiltered.filter(function (a) { return recIds.indexOf(a.id) !== -1; }).length;
      return roleFiltered.filter(function (a) { return a.cat === cat; }).length;
    };
    return [
      ["all", "🌟 كل المنظومات (" + cnt("all") + ")"],
      ["pinned", "📌 المثبّتة والموصى بها (" + cnt("pinned") + ")"],
      ["teacher", "👨‍🏫 المعلم والتحضير (" + cnt("teacher") + ")"],
      ["student", "🎒 الطالب والتوجيهي (" + cnt("student") + ")"],
      ["labs", "🧪 المختبرات والألعاب (" + cnt("labs") + ")"],
      ["admin", "🏫 الإدارة الصفية والتقارير (" + cnt("admin") + ")"],
      ["recent", "🕒 استُخدم مؤخراً (" + cnt("recent") + ")"]
    ];
  }

  function getRecentIds() {
    try { return JSON.parse(localStorage.getItem("edu_recent_apps_v52") || "[]"); } catch (x) { return []; }
  }

  function getPinnedIds() {
    try { return JSON.parse(localStorage.getItem("edu_pinned_apps_v68") || '["weeklyPlannerStudio","worksheetStudio","whiteboardStudio","tawjihiStudio","tutorStudio"]'); } catch (x) { return []; }
  }

  function isPinnedApp(id) {
    return getPinnedIds().indexOf(id) !== -1;
  }

  function togglePinApp(id) {
    if (!id) return;
    try {
      var list = getPinnedIds();
      var idx = list.indexOf(id);
      if (idx !== -1) {
        list.splice(idx, 1);
        toast("أُزيلت الأداة من المثبّتة", "info");
      } else {
        list.unshift(id);
        toast("📌 تم تثبيت الأداة في مقدمة مركزك السريع ✓", "success");
      }
      localStorage.setItem("edu_pinned_apps_v68", JSON.stringify(list.slice(0, 12)));
      renderInlineHub();
    } catch (x) {}
  }

  function recordRecentApp(id) {
    if (!id) return;
    try {
      var list = getRecentIds().filter(function (x) { return x !== id; });
      list.unshift(id);
      localStorage.setItem("edu_recent_apps_v52", JSON.stringify(list.slice(0, 8)));
      if (window.EduBoost && window.EduBoost.repaint) window.EduBoost.repaint();
      renderInlineHub();
    } catch (x) {}
  }

  var savedRole = "all";
  var savedLayout = "hub";
  var savedCompact = false;
  var savedTrack = "hub";
  try {
    savedRole = localStorage.getItem("edu_role_mode_v52") || "all";
    savedLayout = localStorage.getItem("edu_layout_mode_v68") || "hub";
    savedCompact = localStorage.getItem("edu_hub_compact_v74") === "1";
    savedTrack = localStorage.getItem("edu_main_track_v76") || "hub";
  } catch (x) {}

  var st = {
    cat: "all",
    q: "",
    hubCat: "all",
    hubQ: "",
    roleMode: savedRole,
    layoutMode: savedLayout,
    mainTrack: savedTrack,
    compactGrid: savedCompact,
    activeStudioId: ""
  };

  // ---------- شريط مسارات المنصة الرئيسية الذكي (#eduMainTrackBar) ----------
  function ensureMainTrackBar() {
    var bar = $("eduMainTrackBar");
    var anchor = $("boostBar") || $("hero");
    if (!anchor || !anchor.parentNode) return null;
    if (!bar) {
      bar = document.createElement("nav");
      bar.id = "eduMainTrackBar";
      bar.setAttribute("aria-label", "مسارات المنصة الرئيسية");
      bar.className = "sticky top-[52px] sm:top-[60px] z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-y border-slate-200/90 dark:border-slate-800 shadow-sm py-2 px-3 sm:px-6";
      anchor.parentNode.insertBefore(bar, anchor.nextSibling);
    }
    return bar;
  }

  function renderMainTrackBar() {
    var bar = ensureMainTrackBar();
    if (!bar) return;
    if (st.activeStudioId) {
      bar.style.display = "none";
      return;
    }
    bar.style.display = "";
    var activeTrackId = st.layoutMode === "full" ? "all" : (st.mainTrack || "hub");
    var visTotal = APPS.filter(function (a) { return isAppVisible(a, getStudiosConfig()); }).length;

    bar.innerHTML =
      '<div class="max-w-7xl mx-auto flex items-center justify-between gap-2 overflow-x-auto no-scrollbar">' +
        '<div class="flex items-center gap-1.5">' +
          '<span class="text-[11px] font-black text-slate-400 dark:text-slate-500 hidden md:inline shrink-0 ml-1">🧭 مسار التصفح:</span>' +
          MAIN_TRACKS.map(function (t) {
            var on = activeTrackId === t.id;
            var lbl = t.id === "hub" ? (t.label + " (" + visTotal + ")") : t.label;
            return '<button type="button" data-main-track="' + t.id + '" class="px-3.5 py-2 rounded-2xl text-xs font-extrabold whitespace-nowrap shrink-0 flex items-center gap-1.5 transition-all ' +
              (on
                ? "bg-gradient-to-l from-brand-600 to-indigo-600 text-white shadow-md scale-[1.02]"
                : "bg-slate-100 dark:bg-slate-800/90 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700") + '">' +
              '<span>' + t.ico + '</span><span>' + e(lbl) + '</span>' +
            '</button>';
          }).join("") +
        '</div>' +
      '</div>';

    bar.querySelectorAll("[data-main-track]").forEach(function (b) {
      b.onclick = function () {
        var tid = b.getAttribute("data-main-track");
        setMainTrack(tid, true);
      };
    });
  }

  function setMainTrack(trackId, scrollNow) {
    st.activeStudioId = "";
    if (trackId === "all") {
      st.layoutMode = "full";
      st.mainTrack = "all";
    } else {
      st.layoutMode = "hub";
      st.mainTrack = trackId || "hub";
    }
    try {
      localStorage.setItem("edu_layout_mode_v68", st.layoutMode);
      localStorage.setItem("edu_main_track_v76", st.mainTrack);
    } catch (x) {}
    applyVisibility();
    renderInlineHub();
    renderMainTrackBar();
    if (scrollNow) {
      var bar = $("eduMainTrackBar");
      if (bar) setTimeout(function () { bar.scrollIntoView({ behavior: "smooth", block: "start" }); }, 50);
    }
  }

  function applyVisibility() {
    if (window.EduMasterHierarchy && typeof window.EduMasterHierarchy.enforceVisibility === 'function' && !st.activeStudioId) {
      try { window.EduMasterHierarchy.enforceVisibility(); } catch (e) {}
      return;
    }
    var main = document.querySelector("main");
    if (!main) return;
    var cfg = getStudiosConfig();

    // إخفاء قسم #quickStart القديم المكرر لأن شريط المسارات ومركز التطبيقات يغنيان عنه بشكل أنظف
    var qs = $("quickStart");
    if (qs) qs.style.display = "none";

    if (st.activeStudioId) {
      document.body.classList.add("studio-active-mode");
      renderMainTrackBar();
      Array.prototype.forEach.call(main.children, function (el) {
        if (!el || !el.id) return;
        if (el.id === "eduActiveStudioBar" || el.id === "eduActiveStudioFooterNav") return;
        if (el.id === st.activeStudioId) {
          el.style.display = "";
          el.style.contentVisibility = "visible";
        } else {
          el.style.display = "none";
        }
      });
      updateActiveStudioHeader();
      return;
    }

    document.body.classList.remove("studio-active-mode");
    removeActiveStudioHeader();
    renderMainTrackBar();

    var trackObj = MAIN_TRACKS.filter(function (t) { return t.id === (st.layoutMode === "full" ? "all" : st.mainTrack); })[0] || MAIN_TRACKS[0];
    var allowedTrackSecs = trackObj.sections;

    Array.prototype.forEach.call(main.children, function (el) {
      if (!el || !el.id || el.id === "quickStart") return;
      if (el.dataset && el.dataset.secHidden === "1") {
        el.style.display = "none";
        return;
      }
      if (cfg[el.id] && cfg[el.id].visible === false) {
        el.style.display = "none";
        return;
      }

      if (ALWAYS_TOP_IDS.indexOf(el.id) !== -1) {
        if (el.id === "homeAds" || el.id === "homeVideos") {
          el.style.display = el.classList.contains("hidden") ? "none" : "";
        } else {
          el.style.display = "";
        }
        return;
      }

      if (st.layoutMode === "hub") {
        var inTrack = allowedTrackSecs.indexOf(el.id) !== -1;
        if (el.id === "coursesSection") {
          el.style.display = (inTrack && !el.classList.contains("hidden")) ? "" : "none";
        } else if (el.id === "modsSection" || el.id === "quickLinksSection") {
          el.style.display = (inTrack && !el.classList.contains("hidden")) ? "" : "none";
        } else {
          el.style.display = inTrack ? "" : "none";
        }
      } else {
        el.style.contentVisibility = "auto";
        el.style.containIntrinsicSize = "auto 520px";
        var appMeta = APPS.filter(function (a) { return a.id === el.id; })[0];
        if (st.roleMode && st.roleMode !== "all" && appMeta) {
          var allowed = (appMeta.roles || []).indexOf(st.roleMode) !== -1;
          el.style.display = allowed ? "" : "none";
        } else {
          el.style.display = "";
        }
      }
    });
  }

  function updateActiveStudioHeader() {
    var app = APPS.filter(function (a) { return a.id === st.activeStudioId; })[0];
    var title = app ? app.title : "أداة تعليمية";
    var ico = app ? app.ico : "🚀";
    var bar = $("eduActiveStudioBar");
    var main = document.querySelector("main");
    if (!main) return;
    if (!bar) {
      bar = document.createElement("div");
      bar.id = "eduActiveStudioBar";
      bar.className = "sticky top-[52px] sm:top-[60px] z-30 bg-slate-900/95 text-white border-b border-brand-500/40 backdrop-blur-md shadow-xl px-3 sm:px-6 py-2.5";
      main.insertBefore(bar, main.firstChild);
    }
    var chainIds = (st.roleMode === "student")
      ? ["bookReaderStudio", "learnSection", "sourcesStudio", "tutorStudio", "reviewStudio", "selfQuiz", "offPackStudio", "classroomsStudio"]
      : ["bookReaderStudio", "sourcesStudio", "lessonKitStudio", "lessonPlanStudio", "slidesStudio", "whiteboardStudio", "worksheetStudio", "gamesStudio", "classroomsStudio", "parentsStudio"];
    var chainHtml = chainIds.map(function (cid, idx) {
      var ca = APPS.filter(function (a) { return a.id === cid; })[0];
      if (!ca) return "";
      var on = cid === st.activeStudioId;
      var shortTitle = ca.title.split(" ").slice(0, 2).join(" ");
      return '<button type="button" data-chain-jump="' + cid + '" class="px-2.5 py-1 rounded-xl text-[11px] font-extrabold whitespace-nowrap shrink-0 flex items-center gap-1 transition ' +
        (on ? "bg-amber-400 text-slate-950 shadow font-black" : "bg-white/10 hover:bg-white/20 text-slate-200") + '">' +
        '<span>' + (idx + 1) + '. ' + ca.ico + ' ' + e(shortTitle) + '</span>' +
      '</button>';
    }).join('<span class="text-slate-500 text-[10px] self-center shrink-0">←</span>');

    bar.innerHTML =
      '<div class="max-w-7xl mx-auto space-y-1.5">' +
        '<div class="flex flex-wrap items-center justify-between gap-2">' +
          '<div class="flex items-center gap-2 min-w-0">' +
            '<button type="button" id="btnStudioBackHome" class="px-3 py-1.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-black flex items-center gap-1.5 shadow-sm active:scale-95 transition shrink-0">' +
              '<i class="fa-solid fa-arrow-right"></i>' +
              '<span>الرئيسية</span>' +
            '</button>' +
            '<div class="flex items-center gap-1.5 min-w-0 px-2.5 py-1 rounded-xl bg-white/10 border border-white/15">' +
              '<span class="text-base shrink-0">' + ico + '</span>' +
              '<span class="text-xs sm:text-sm font-black truncate text-sky-200">' + e(title) + '</span>' +
            '</div>' +
          '</div>' +
          '<div class="flex items-center gap-1.5 shrink-0">' +
            '<button type="button" id="btnStudioCamQuick" class="px-2.5 py-1.5 rounded-xl bg-emerald-600/30 hover:bg-emerald-600 text-emerald-200 hover:text-white border border-emerald-400/30 text-xs font-extrabold flex items-center gap-1 transition" title="إدارة وتصوير مصادر الكتاب بالكاميرا أو PDF">' +
              '<i class="fa-solid fa-camera"></i><span class="hidden sm:inline">مصادري والكاميرا</span>' +
            '</button>' +
            '<button type="button" id="btnStudioWorkflowBridge" class="px-2.5 py-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600 text-indigo-200 hover:text-white border border-indigo-400/30 text-xs font-extrabold flex items-center gap-1 transition" title="فتح غرفة العمليات الموحّدة ونقل الدرس لأداة أخرى">' +
              '<span>⚡ ربط بأداة</span>' +
            '</button>' +
            '<button type="button" id="btnStudioPinTool" class="px-2 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-extrabold border border-slate-700 transition" title="تثبيت الأداة في المفضلة السريعة">' +
              '<span>' + (isPinnedApp(st.activeStudioId) ? "📌" : "☆") + '</span>' +
            '</button>' +
            '<button type="button" id="btnStudioShareLink" class="px-2 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/30 text-xs font-extrabold flex items-center gap-1 transition" title="نسخ الرابط المباشر لهذه الأداة">' +
              '<i class="fa-solid fa-share-nodes"></i>' +
            '</button>' +
            '<button type="button" id="btnStudioSwitchTool" class="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-400/30 text-xs font-extrabold flex items-center gap-1 transition">' +
              '<span>🚀 كل الأدوات</span>' +
            '</button>' +
          '</div>' +
        '</div>' +
        '<div class="flex items-center gap-1 overflow-x-auto no-scrollbar pt-1 border-t border-white/10">' +
          '<span class="text-[10px] font-black text-amber-300 shrink-0 ml-1">' + (st.roleMode === "student" ? "🧭 خطوات الطالب:" : "🧭 خطوات المعلم:") + '</span>' +
          chainHtml +
        '</div>' +
      '</div>';

    $("btnStudioBackHome").onclick = function () { exitActiveStudio(true); };
    $("btnStudioSwitchTool").onclick = openLauncherModal;
    if ($("btnStudioCamQuick")) $("btnStudioCamQuick").onclick = function () { jumpToApp("sourcesStudio", true); };
    if ($("btnStudioWorkflowBridge")) $("btnStudioWorkflowBridge").onclick = function () { jumpToApp("unifiedWorkflowStudio", true); };
    bar.querySelectorAll("[data-chain-jump]").forEach(function (b) {
      b.onclick = function () {
        var cid = b.getAttribute("data-chain-jump");
        if (cid === "selfQuiz" && window.EduStudy && window.EduStudy.quiz) {
          window.EduStudy.quiz();
        } else {
          jumpToApp(cid, cid !== "learnSection");
        }
      };
    });
    updateActiveStudioBottomNav(app);
    $("btnStudioPinTool").onclick = function () {
      togglePinApp(st.activeStudioId);
      updateActiveStudioHeader();
    };
    $("btnStudioShareLink").onclick = function () {
      var shareUrl = location.origin + location.pathname + "?app=" + encodeURIComponent(st.activeStudioId);
      var shareTitle = "أداة «" + title + "» على منصة EduTech Mindset";
      if (navigator.share) {
        navigator.share({ title: shareTitle, text: shareTitle, url: shareUrl }).catch(function () {});
      } else if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(shareUrl).then(function () { toast("تم نسخ الرابط المباشر للأداة ✓", "success"); });
      } else {
        window.open("https://wa.me/?text=" + encodeURIComponent(shareTitle + "\n" + shareUrl), "_blank", "noopener");
      }
    };
  }

  function updateActiveStudioBottomNav(app) {
    var nav = $("eduActiveStudioFooterNav");
    var main = document.querySelector("main");
    if (!main || !app) return;
    if (!nav) {
      nav = document.createElement("div");
      nav.id = "eduActiveStudioFooterNav";
      nav.className = "max-w-5xl mx-auto px-4 sm:px-6 pb-10 pt-4";
      main.appendChild(nav);
    }
    var cfg = getStudiosConfig();
    var related = APPS.filter(function (a) {
      return isAppVisible(a, cfg) && a.id !== app.id && a.cat === app.cat;
    }).slice(0, 4);

    nav.innerHTML =
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 p-4 sm:p-5 text-right shadow-lg">' +
        '<div class="flex flex-wrap items-center justify-between gap-2 mb-3">' +
          '<div class="text-xs sm:text-sm font-black text-slate-800 dark:text-white">🧭 أدوات أخرى ذات صلة قد تهمك:</div>' +
          '<button type="button" id="btnFooterBackHub" class="px-3.5 py-1.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-extrabold transition flex items-center gap-1.5">' +
            '<i class="fa-solid fa-arrow-right"></i><span>العودة لمركز التطبيقات</span>' +
          '</button>' +
        '</div>' +
        '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">' +
          related.map(function (r) {
            return '<button type="button" data-relopen="' + r.id + '" class="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/90 hover:border-brand-500 text-right flex items-center gap-2.5 transition group">' +
              '<div class="w-10 h-10 rounded-xl bg-gradient-to-br ' + r.color + ' text-white text-lg flex items-center justify-center shrink-0">' + r.ico + '</div>' +
              '<div class="min-w-0 flex-1">' +
                '<div class="text-xs font-black text-slate-900 dark:text-white group-hover:text-brand-500 truncate">' + e(r.title) + '</div>' +
                '<div class="text-[10px] text-slate-500 dark:text-slate-400 truncate">' + e(getAppBadge(r, cfg) || r.desc) + '</div>' +
              '</div>' +
            '</button>';
          }).join("") +
        '</div>' +
      '</div>';

    var backBtn = $("btnFooterBackHub");
    if (backBtn) backBtn.onclick = function () { exitActiveStudio(true); };
    nav.querySelectorAll("[data-relopen]").forEach(function (b) {
      b.onclick = function () { jumpToApp(b.getAttribute("data-relopen"), true); };
    });
  }

  function removeActiveStudioHeader() {
    var bar = $("eduActiveStudioBar");
    if (bar) bar.remove();
    var nav = $("eduActiveStudioFooterNav");
    if (nav) nav.remove();
  }

  function exitActiveStudio(pushHist) {
    if (!st.activeStudioId) return;
    st.activeStudioId = "";
    applyVisibility();
    var hub = $("eduMainTrackBar") || $("smartHubSection") || $("hero");
    if (hub) {
      setTimeout(function () { hub.scrollIntoView({ behavior: "smooth", block: "start" }); }, 60);
    }
    if (pushHist) {
      try {
        var url = new URL(location.href);
        url.searchParams.delete("app");
        history.pushState({ eduStudio: "" }, "", url.pathname + url.search);
      } catch (e) {}
    }
  }

  function setRoleMode(role) {
    st.roleMode = role || "all";
    try { localStorage.setItem("edu_role_mode_v52", st.roleMode); } catch (x) {}
    applyVisibility();
    renderInlineHub();
    if (window.EduBridge && window.EduBridge.refreshOrchestrator) window.EduBridge.refreshOrchestrator();
    if (window.EduBoost && window.EduBoost.repaint) window.EduBoost.repaint();
    var rObj = ROLES.filter(function (r) { return r.id === st.roleMode; })[0];
    if (rObj) toast("تم تفعيل: " + rObj.label + " ✓");
  }

  function setLayoutMode(mode) {
    setMainTrack(mode === "full" ? "all" : "hub", false);
    toast(st.layoutMode === "hub" ? "تم تفعيل وضع المسارات المنظّمة السريع ⚡" : "تم إظهار جميع أقسام المنصة في الصفحة الكاملة 📜");
  }

  // خريطة الأقسام التي تنتمي لمسار رئيسي
  var SECTION_TO_TRACK = {
    smartHubSection: "hub",
    learnSection: "learn",
    booksSection: "books",
    library: "library",
    modsSection: "library",
    quickLinksSection: "library",
    userWorkspaceSection: "workspace",
    about: "about",
    social: "about"
  };

  function jumpToApp(id, forceStandalone) {
    if (!id) return;
    if (window.EduAccessControl && typeof window.EduAccessControl.canAccessTool === "function") {
      if (!window.EduAccessControl.canAccessTool(id)) {
        if (typeof closeModal === "function") closeModal();
        window.EduAccessControl.promptBlockedTool(id);
        return;
      }
    }
    var ap = APPS.filter(function (a) { return a.id === id; })[0];
    if (ap && ap.call) {
      if (typeof closeModal === "function") closeModal();
      recordRecentApp(id);
      var parts = ap.call.split("."), obj = window[parts[0]];
      if (obj && typeof obj[parts[1]] === "function") setTimeout(function () { obj[parts[1]](); }, 80);
      else toast("جارٍ تحميل الأداة… حاول بعد لحظات", "info");
      return;
    }
    if (window.EduMasterHierarchy && typeof window.EduMasterHierarchy.navigateToTarget === "function") {
      if (typeof closeModal === "function") closeModal();
      recordRecentApp(id);
      window.EduMasterHierarchy.navigateToTarget(id);
      return;
    }
    if (typeof closeModal === "function") closeModal();
    recordRecentApp(id);

    // إذا كان القسم أحد المسارات الرئيسية (مثل المراحل أو الكتب أو المكتبة أو مساحتي أو من نحن) ولم يُطلب كشاشة منفصلة إجبارية
    if (SECTION_TO_TRACK[id] && !forceStandalone) {
      setMainTrack(SECTION_TO_TRACK[id], false);
      var targetSec = $(id);
      if (targetSec) {
        [60, 220].forEach(function (d) {
          setTimeout(function () { targetSec.scrollIntoView({ behavior: "smooth", block: "start" }); }, d);
        });
      }
      return;
    }

    var el = $(id);
    if (!el) {
      toast("جارٍ تجهيز الأداة… يرجى الانتظار لحظة", "info");
      setTimeout(function () {
        var retryEl = $(id);
        if (retryEl) jumpToApp(id, forceStandalone);
      }, 900);
      return;
    }

    if (el.classList.contains("hidden") && id === "coursesSection") {
      toast("لا توجد دورات تدريبية معلنة حالياً", "info");
      return;
    }

    st.activeStudioId = id;
    applyVisibility();
    try {
      var url = new URL(location.href);
      url.searchParams.set("app", id);
      history.pushState({ eduStudio: id }, "", url.pathname + url.search);
    } catch (e) {}
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function ensureInlineHub() {
    if ($("smartHubSection")) return $("smartHubSection");
    var anchor = $("eduMainTrackBar") || $("boostBar") || $("quickStart") || $("hero");
    if (!anchor || !anchor.parentNode) return null;
    var sec = document.createElement("section");
    sec.id = "smartHubSection";
    sec.className = "py-6 bg-slate-100/70 dark:bg-slate-900/70 border-b border-slate-200/80 dark:border-slate-800 scroll-mt-24";
    anchor.parentNode.insertBefore(sec, anchor.nextSibling);
    return sec;
  }

  function renderInlineHub() {
    if (window.EduMasterHierarchy) return;
    ensureMainTrackBar();
    var sec = ensureInlineHub();
    if (!sec) return;
    var q = st.hubQ.trim().toLowerCase();
    var recIds = getRecentIds();
    var pinIds = getPinnedIds();
    var cfg = getStudiosConfig();
    var dynamicCats = getCategoriesWithCounts();

    var list = APPS.filter(function (a) {
      if (!isAppVisible(a, cfg)) return false;
      if (st.roleMode && st.roleMode !== "all" && (a.roles || []).indexOf(st.roleMode) === -1) return false;
      var matchCat = st.hubCat === "all" ? true
        : st.hubCat === "pinned" ? (pinIds.indexOf(a.id) !== -1 || isAppFeatured(a, cfg))
        : st.hubCat === "recent" ? recIds.indexOf(a.id) !== -1
        : a.cat === st.hubCat;
      var badgeTxt = getAppBadge(a, cfg);
      var matchQ = !q || (a.title + " " + a.desc + " " + badgeTxt).toLowerCase().indexOf(q) !== -1;
      return matchCat && matchQ;
    });

    if (st.hubCat === "recent") {
      list.sort(function (a, b) { return recIds.indexOf(a.id) - recIds.indexOf(b.id); });
    } else if (st.hubCat === "all" || st.hubCat === "pinned") {
      list.sort(function (a, b) {
        var fa = isAppFeatured(a, cfg) ? 0 : (pinIds.indexOf(a.id) !== -1 ? 1 : 2);
        var fb = isAppFeatured(b, cfg) ? 0 : (pinIds.indexOf(b.id) !== -1 ? 1 : 2);
        return fa - fb;
      });
    }

    var sparkText = DAILY_SPARKS[sparkIdx % DAILY_SPARKS.length];
    var visTotal = APPS.filter(function (a) { return isAppVisible(a, cfg); }).length;

    sec.innerHTML =
      '<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">' +
        '<div class="glass-card rounded-3xl border border-slate-200/90 dark:border-slate-700/90 shadow-xl p-4 sm:p-6 space-y-4">' +
          // Header Row
          '<div class="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-200/80 dark:border-slate-800 pb-4">' +
            '<div class="text-right">' +
              '<div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-500/10 text-brand-600 dark:text-brand-300 text-[11px] font-black mb-1">' +
                '<i class="fa-solid fa-grip"></i>' +
                '<span>مركز التطبيقات والاستوديوهات الذكية الموحّد</span>' +
              '</div>' +
              '<h2 class="text-lg sm:text-2xl font-black text-slate-900 dark:text-white">🧭 اختر أداتك أو مختبرك وابدأ فوراً</h2>' +
              '<p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">جميع أدوات المنصة الـ ' + visTotal + ' مصنفة ومرتبة في مكان واحد لتعمل كشاشات تطبيق مستقلة وسريعة</p>' +
            '</div>' +
            '<div class="flex flex-wrap items-center gap-2 shrink-0">' +
              '<button type="button" id="btnSuggestTool" class="px-3 py-2 rounded-xl text-xs font-extrabold border border-amber-400/50 bg-amber-500/10 text-amber-700 dark:text-amber-300 hover:bg-amber-500 hover:text-slate-950 transition flex items-center gap-1.5" title="اقترح لي أداة ذكية مناسبة لبوابتي">' +
                '<span>🎲 اقترح لي أداة</span>' +
              '</button>' +
              '<button type="button" id="btnToggleCompactHub" class="px-3 py-2 rounded-xl text-xs font-extrabold border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:border-brand-500 transition flex items-center gap-1.5" title="تبديل كثافة عرض البطاقات">' +
                '<i class="fa-solid ' + (st.compactGrid ? "fa-grip" : "fa-table-cells") + ' text-brand-500"></i>' +
                '<span>' + (st.compactGrid ? "عرض تفصيلي" : "عرض مدمج سريع") + '</span>' +
              '</button>' +
              '<button type="button" id="btnOpenModalLauncher" class="px-3.5 py-2 rounded-xl bg-gradient-to-l from-brand-600 to-indigo-600 text-white text-xs font-black shadow-md hover:opacity-95 transition flex items-center gap-1.5">' +
                '<i class="fa-solid fa-magnifying-glass"></i>' +
                '<span>البحث السريع (Ctrl+K)</span>' +
              '</button>' +
            '</div>' +
          '</div>' +

          // شريط إضاءة تربوية وتقنية متجددة
          '<div class="p-3 rounded-2xl bg-gradient-to-l from-amber-500/10 via-sky-500/10 to-indigo-500/10 border border-amber-500/25 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">' +
            '<div class="font-bold text-slate-800 dark:text-slate-200 leading-relaxed flex-1" id="hubSparkText">' + e(sparkText) + '</div>' +
            '<div class="flex items-center gap-1.5 shrink-0 self-end sm:self-center">' +
              '<button type="button" id="btnNextSpark" class="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-extrabold hover:border-amber-500 transition">🔄 فكرة أخرى</button>' +
              '<button type="button" id="btnCopySpark" class="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-700 dark:text-amber-300 text-[11px] font-extrabold hover:bg-amber-500 hover:text-slate-950 transition">📋 نسخ</button>' +
            '</div>' +
          '</div>' +

          // Role Gate + Search Bar
          '<div class="grid grid-cols-1 lg:grid-cols-12 gap-3 items-center">' +
            '<div class="lg:col-span-7 flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">' +
              '<span class="text-[11px] font-black text-slate-500 dark:text-slate-400 shrink-0 ml-1">🎭 البوابة:</span>' +
              ROLES.map(function (r) {
                var on = st.roleMode === r.id;
                return '<button type="button" data-hubrole="' + r.id + '" class="px-3 py-1.5 rounded-xl text-xs font-extrabold whitespace-nowrap shrink-0 transition ' +
                  (on ? "bg-indigo-600 text-white shadow-sm" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200") + '">' + r.label + '</button>';
              }).join("") +
            '</div>' +
            '<div class="lg:col-span-5 relative">' +
              '<input id="hubSearchInp" type="search" value="' + e(st.hubQ) + '" placeholder="🔍 ابحث عن أداة (مخطط أسبوعي، ورقة عمل، سبورة، توجيهي، حاسبة…)" class="w-full text-xs font-bold px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800/90 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-100 outline-none focus:border-brand-500">' +
            '</div>' +
          '</div>' +

          // Category Tabs
          '<div class="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">' +
            dynamicCats.map(function (c) {
              var on = st.hubCat === c[0];
              return '<button type="button" data-hubcat="' + c[0] + '" class="px-3.5 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap shrink-0 transition ' +
                (on ? "bg-brand-600 text-white shadow-sm" : "bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 hover:bg-slate-200") + '">' + c[1] + '</button>';
            }).join("") +
          '</div>' +

          // Cards Grid
          (list.length
            ? (st.compactGrid
              ? '<div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5 pt-1">' +
                  list.map(function (a) {
                    var pinned = pinIds.indexOf(a.id) !== -1;
                    var feat = isAppFeatured(a, cfg);
                    var bTxt = getAppBadge(a, cfg);
                    return '<div class="relative group">' +
                      '<button type="button" data-hubpin="' + a.id + '" class="hub-pin-btn ' + (pinned ? "pinned" : "") + '" title="' + (pinned ? "إلغاء التثبيت" : "تثبيت الأداة") + '">' + (pinned ? "📌" : "☆") + '</button>' +
                      '<button type="button" data-hubopen="' + a.id + '" class="w-full h-full text-right p-2.5 pl-8 rounded-2xl border ' + (feat ? "border-amber-400 ring-1 ring-amber-400/40" : pinned ? "border-amber-400/60 dark:border-amber-500/40" : "border-slate-200/90 dark:border-slate-700/90") + ' bg-white dark:bg-slate-800/90 hover:border-brand-500 hover:shadow-md transition-all flex items-center gap-2.5 overflow-hidden">' +
                        '<div class="w-9 h-9 rounded-xl bg-gradient-to-br ' + a.color + ' text-white text-lg flex items-center justify-center shrink-0 shadow-xs">' + a.ico + '</div>' +
                        '<div class="min-w-0 flex-1">' +
                          '<div class="text-[11px] font-black text-slate-900 dark:text-white group-hover:text-brand-600 dark:group-hover:text-brand-400 truncate">' + e(a.title) + '</div>' +
                          '<span class="inline-block mt-0.5 text-[9px] font-extrabold ' + (feat ? "text-amber-600 dark:text-amber-400" : "text-brand-600 dark:text-sky-300") + ' truncate">' + (feat ? "⭐ توصية الإدارة • " : "") + e(bTxt) + '</span>' +
                        '</div>' +
                      '</button>' +
                    '</div>';
                  }).join("") +
                '</div>'
              : '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 pt-1">' +
                  list.map(function (a) {
                    var pinned = pinIds.indexOf(a.id) !== -1;
                    var feat = isAppFeatured(a, cfg);
                    var bTxt = getAppBadge(a, cfg);
                    return '<div class="relative group">' +
                      '<button type="button" data-hubpin="' + a.id + '" class="hub-pin-btn ' + (pinned ? "pinned" : "") + '" title="' + (pinned ? "إلغاء التثبيت" : "تثبيت الأداة في المقدمة") + '">' + (pinned ? "📌" : "☆") + '</button>' +
                      '<button type="button" data-hubopen="' + a.id + '" class="w-full h-full text-right p-3.5 pl-9 rounded-2xl border ' + (feat ? "border-amber-400 ring-1 ring-amber-400/40" : pinned ? "border-amber-400/60 dark:border-amber-500/40" : "border-slate-200/90 dark:border-slate-700/90") + ' bg-white dark:bg-slate-800/90 hover:border-brand-500 hover:shadow-lg hover:-translate-y-0.5 transition-all flex items-start gap-3 overflow-hidden">' +
                        '<div class="w-12 h-12 rounded-2xl bg-gradient-to-br ' + a.color + ' text-white text-2xl flex items-center justify-center shrink-0 shadow-md group-hover:scale-105 transition-transform">' + a.ico + '</div>' +
                        '<div class="min-w-0 flex-1">' +
                          '<div class="flex items-center justify-between gap-1">' +
                            '<span class="text-xs font-black text-slate-900 dark:text-white group-hover:text-brand-600 dark:group-hover:text-brand-400 truncate">' + e(a.title) + '</span>' +
                          '</div>' +
                          '<p class="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">' + e(a.desc) + '</p>' +
                          '<div class="flex flex-wrap items-center gap-1 mt-2">' +
                            (feat ? '<span class="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-700 dark:text-amber-300 text-[10px] font-black">⭐ توصية الإدارة</span>' : '') +
                            (bTxt ? '<span class="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700/80 text-[10px] font-extrabold text-brand-600 dark:text-sky-300">' + e(bTxt) + '</span>' : '') +
                          '</div>' +
                        '</div>' +
                      '</button>' +
                    '</div>';
                  }).join("") +
                '</div>')
            : '<div class="text-center py-8 text-xs text-slate-500 font-bold">لا توجد أدوات مطابقة لبحثك في هذا التبويب حالياً — جرّب اختيار «كل المنظومات».</div>') +
        '</div>' +
      '</div>';

    var sInp = $("hubSearchInp");
    if (sInp) {
      sInp.oninput = function () {
        var pos = sInp.selectionStart;
        st.hubQ = sInp.value;
        renderInlineHub();
        var nInp = $("hubSearchInp");
        if (nInp) {
          nInp.focus();
          try { nInp.setSelectionRange(pos, pos); } catch (x) {}
        }
      };
    }

    var btnSug = $("btnSuggestTool");
    if (btnSug) {
      btnSug.onclick = function () {
        var pool = list.length ? list : APPS.filter(function (a) { return isAppVisible(a, cfg); });
        if (!pool.length) return;
        var pick = pool[Math.floor(Math.random() * pool.length)];
        toast("🎲 نقترح عليك تجربة: «" + pick.title + "» " + pick.ico, "success");
        jumpToApp(pick.id, true);
      };
    }

    var btnCompact = $("btnToggleCompactHub");
    if (btnCompact) {
      btnCompact.onclick = function () {
        st.compactGrid = !st.compactGrid;
        try { localStorage.setItem("edu_hub_compact_v74", st.compactGrid ? "1" : "0"); } catch (x) {}
        renderInlineHub();
      };
    }

    var btnNextSp = $("btnNextSpark");
    if (btnNextSp) {
      btnNextSp.onclick = function () {
        sparkIdx = (sparkIdx + 1) % DAILY_SPARKS.length;
        var spEl = $("hubSparkText");
        if (spEl) spEl.textContent = DAILY_SPARKS[sparkIdx];
      };
    }

    var btnCopySp = $("btnCopySpark");
    if (btnCopySp) {
      btnCopySp.onclick = function () {
        var txt = DAILY_SPARKS[sparkIdx % DAILY_SPARKS.length];
        if (typeof copyTextToClipboard === "function") copyTextToClipboard(txt, "تم نسخ الفكرة التربوية 📋");
        else if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(function () { toast("تم نسخ الفكرة التربوية 📋", "success"); });
      };
    }

    var btnModal = $("btnOpenModalLauncher");
    if (btnModal) btnModal.onclick = openLauncherModal;

    sec.querySelectorAll("[data-hubrole]").forEach(function (b) {
      b.onclick = function () { setRoleMode(b.getAttribute("data-hubrole")); };
    });
    sec.querySelectorAll("[data-hubcat]").forEach(function (b) {
      b.onclick = function () { st.hubCat = b.getAttribute("data-hubcat"); renderInlineHub(); };
    });
    sec.querySelectorAll("[data-hubopen]").forEach(function (b) {
      b.onclick = function () { jumpToApp(b.getAttribute("data-hubopen"), true); };
    });
    sec.querySelectorAll("[data-hubpin]").forEach(function (b) {
      b.onclick = function (ev) {
        ev.stopPropagation();
        togglePinApp(b.getAttribute("data-hubpin"));
      };
    });
    if (window.EduBridge && window.EduBridge.refreshOrchestrator) {
      window.EduBridge.refreshOrchestrator();
    }
  }

  function openLauncherModal() {
    if (typeof showModalContent !== "function") return;
    function renderContent() {
      var q = st.q.trim().toLowerCase();
      var recIds = getRecentIds();
      var pinIds = getPinnedIds();
      var cfg = getStudiosConfig();
      var dynamicCats = getCategoriesWithCounts();
      var list = APPS.filter(function (a) {
        if (!isAppVisible(a, cfg)) return false;
        var matchCat = q ? true : (st.cat === "all" ? true
          : st.cat === "pinned" ? (pinIds.indexOf(a.id) !== -1 || isAppFeatured(a, cfg))
          : st.cat === "recent" ? recIds.indexOf(a.id) !== -1
          : a.cat === st.cat);
        var matchQ = !q || (a.title + " " + a.desc + " " + getAppBadge(a, cfg)).toLowerCase().indexOf(q) !== -1;
        return matchCat && matchQ;
      });
      if (st.cat === "recent" && !q) {
        list.sort(function (a, b) { return recIds.indexOf(a.id) - recIds.indexOf(b.id); });
      }
      var subjectHits = [];
      if (q.length >= 2 && window.EduMasterHierarchy && typeof window.EduMasterHierarchy.getTree === "function") {
        (window.EduMasterHierarchy.getTree() || []).forEach(function (stg) {
          (stg.grades || []).forEach(function (grd) {
            (grd.branches || []).forEach(function (brn) {
              (brn.subjects || []).forEach(function (sub) {
                var hay = (stg.shortName + " " + grd.name + " " + sub.name + " " + (sub.bookTitle || "") + " " + (sub.units || []).join(" ")).toLowerCase();
                if (hay.indexOf(q) !== -1 && subjectHits.length < 8) {
                  subjectHits.push({ stg: stg, grd: grd, brn: brn, sub: sub });
                }
              });
            });
          });
        });
      }

      var html = '<div class="p-4 shrink-0 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-gradient-to-l from-slate-900 via-indigo-950 to-slate-900 text-white">' +
        '<div><h3 class="text-sm sm:text-base font-black">🚀 دليل ومشغّل أدوات المنصة السريع (' + APPS.filter(function (a) { return isAppVisible(a, cfg); }).length + ' منظومة)</h3>' +
        '<p class="text-[11px] text-slate-300">اختر أي أداة لفتحها فوراً في شاشة مستقلة — أو خصّص بوابة العرض حسب دورك</p></div>' +
        '<button type="button" class="p-2 text-slate-300 hover:text-white" onclick="closeModal()"><i class="fa-solid fa-xmark text-lg"></i></button></div>' +
        '<div class="p-4 overflow-y-auto flex-1 min-h-0 space-y-3 text-right">' +
        '<div class="flex flex-wrap items-center gap-1.5 p-2 rounded-2xl bg-slate-100 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">' +
        '<span class="text-[11px] font-black text-slate-600 dark:text-slate-300 ml-1">🎭 بوابة العرض:</span>' +
        ROLES.map(function (r) {
          var active = st.roleMode === r.id;
          return '<button type="button" data-lnrole="' + r.id + '" class="px-2.5 py-1 rounded-xl text-[11px] font-extrabold transition-all ' +
            (active ? "bg-indigo-600 text-white shadow" : "bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300") + '">' + r.label + '</button>';
        }).join("") + '</div>' +
        '<div class="flex flex-wrap items-center gap-2">' +
        '<input id="lnSearchInp" type="search" value="' + e(st.q) + '" placeholder="🔍 ابحث عن أداة (مثال: مخطط أسبوعي، راسم دوال، شهادة، سبورة، توجيهي…)" class="flex-1 min-w-[180px] text-xs font-bold px-3.5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 outline-none">' +
        '</div>' +
        '<div class="flex gap-1.5 overflow-x-auto pb-1">' +
        dynamicCats.map(function (c) {
          var on = st.cat === c[0];
          return '<button type="button" data-lncat="' + c[0] + '" class="px-3.5 py-1.5 rounded-full text-xs font-extrabold whitespace-nowrap shrink-0 ' + (on ? "bg-brand-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">' + c[1] + '</button>';
        }).join("") + '</div>' +
        (subjectHits.length ? (
          '<div class="p-3 rounded-2xl bg-sky-500/10 border border-sky-500/30 space-y-2">' +
            '<div class="text-[11px] font-black text-sky-700 dark:text-sky-300">📘 الكتب والمباحث الدراسية المطابقة (' + subjectHits.length + '):</div>' +
            '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2">' +
              subjectHits.map(function (sh, sIdx) {
                return '<button type="button" data-lnsubject="' + sIdx + '" class="text-right p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-sky-500/30 hover:border-sky-500 flex items-center justify-between gap-2 transition">' +
                  '<div class="min-w-0"><div class="text-xs font-black truncate">' + e((sh.sub.ico || "📘") + " " + (sh.sub.bookTitle || sh.sub.name)) + '</div>' +
                  '<div class="text-[10px] text-slate-500 truncate">' + e(sh.stg.shortName + " • " + sh.grd.name) + '</div></div>' +
                  '<span class="px-2 py-1 rounded-lg bg-sky-600 text-white text-[10px] font-black shrink-0">اقرأ 📖</span>' +
                '</button>';
              }).join("") +
            '</div>' +
          '</div>'
        ) : '') +
        (list.length ? '<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">' +
        list.map(function (a) {
          var feat = isAppFeatured(a, cfg);
          var perm = (window.EduAccessControl && window.EduAccessControl.evaluateToolAccess) ? window.EduAccessControl.evaluateToolAccess(a.id) : { allowed: true, label: "🟢 متاح" };
          return '<button type="button" data-lnopen="' + a.id + '" class="text-right p-3 rounded-2xl border ' + (!perm.allowed ? "border-rose-500/40 opacity-85" : (feat ? "border-amber-400" : "border-slate-200 dark:border-slate-700")) + ' bg-white dark:bg-slate-800/90 hover:border-brand-500 hover:-translate-y-0.5 transition-all flex items-start gap-3 group">' +
            '<div class="w-11 h-11 rounded-2xl bg-gradient-to-br ' + a.color + ' text-white text-xl flex items-center justify-center shrink-0 shadow-sm">' + a.ico + '</div>' +
            '<div class="min-w-0 flex-1"><div class="flex items-center justify-between gap-1"><span class="text-xs font-black text-slate-900 dark:text-white group-hover:text-brand-600 dark:group-hover:text-brand-400 truncate">' + e(a.title) + '</span><span class="text-[9px] font-black px-1.5 py-0.5 rounded ' + (perm.allowed ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-300' : 'bg-rose-500/15 text-rose-500') + '">' + (perm.allowed ? '🟢 متاح' : '🔒 محجوب') + '</span></div>' +
            '<div class="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 leading-snug">' + e(a.desc) + '</div></div></button>';
        }).join("") + '</div>' : (!subjectHits.length ? '<p class="text-xs text-slate-500 text-center py-6">لا توجد أدوات أو كتب مطابقة في هذا التبويب حالياً.</p>' : '')) + '</div>';

      showModalContent(html);
      var sInp = $("lnSearchInp");
      if (sInp) {
        sInp.focus();
        try { sInp.setSelectionRange(sInp.value.length, sInp.value.length); } catch (x) {}
        sInp.oninput = function () { st.q = sInp.value; renderContent(); };
      }
      document.querySelectorAll("[data-lncat]").forEach(function (b) {
        b.onclick = function () { st.cat = b.dataset.lncat; renderContent(); };
      });
      document.querySelectorAll("[data-lnrole]").forEach(function (b) {
        b.onclick = function () { setRoleMode(b.dataset.lnrole); renderContent(); };
      });
      document.querySelectorAll("[data-lnopen]").forEach(function (b) {
        b.onclick = function () { jumpToApp(b.dataset.lnopen, true); };
      });
      document.querySelectorAll("[data-lnsubject]").forEach(function (b) {
        b.onclick = function () {
          var sh = subjectHits[+b.dataset.lnsubject];
          if (sh && window.EduMasterHierarchy && window.EduMasterHierarchy.openSubject) {
            if (typeof closeModal === "function") closeModal();
            window.EduMasterHierarchy.openSubject(sh.grd.name, sh.sub.name, "book");
          }
        };
      });
    }
    renderContent();
  }

  function injectFloatingButton() {
    if ($("eduFloatingLauncher")) return;
    var btn = document.createElement("button");
    btn.id = "eduFloatingLauncher";
    btn.type = "button";
    btn.title = "دليل ومشغّل كل أدوات المنصة (Ctrl+K)";
    btn.className = "fixed bottom-20 left-4 z-40 px-4 py-2.5 rounded-full bg-gradient-to-l from-brand-600 via-indigo-600 to-purple-600 text-white text-xs font-black shadow-2xl border-2 border-white/80 dark:border-slate-800 flex items-center gap-2 hover:scale-105 transition-all";
    btn.innerHTML = '<span>🚀</span><span>كل الأدوات (' + APPS.length + ')</span>';
    btn.onclick = openLauncherModal;
    document.body.appendChild(btn);

    window.addEventListener("keydown", function (ev) {
      if ((ev.ctrlKey || ev.metaKey) && !ev.shiftKey && ev.key.toLowerCase() === "k") {
        ev.preventDefault();
        openLauncherModal();
      }
    });

    renderInlineHub();
    applyVisibility();
    setTimeout(checkUrlAppParam, 400);
    window.addEventListener("edu:lazy-ready", function () {
      renderInlineHub();
      applyVisibility();
      checkUrlAppParam();
    });
  }

  var urlParamHandled = false;
  function checkUrlAppParam() {
    if (urlParamHandled) return;
    try {
      var params = new URLSearchParams(location.search);
      var targetApp = params.get("app");
      if (!targetApp) {
        if (params.get("c")) targetApp = "classroomsStudio";
        else if (params.get("live") || params.get("g")) targetApp = "gamesStudio";
        else if (params.get("hw")) targetApp = "homeworkStudio";
        else if (params.get("p")) targetApp = "slidesStudio";
      }
      if (targetApp && $(targetApp)) {
        urlParamHandled = true;
        jumpToApp(targetApp, true);
      }
    } catch (e) {}
  }

  window.addEventListener("popstate", function () {
    try {
      var params = new URLSearchParams(location.search);
      var appParam = params.get("app");
      if (appParam && $(appParam)) {
        st.activeStudioId = appParam;
        applyVisibility();
      } else if (st.activeStudioId) {
        st.activeStudioId = "";
        applyVisibility();
      }
    } catch (e) {}
  });

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", injectFloatingButton);
  else injectFloatingButton();

  document.addEventListener("click", function (ev) {
    var b = ev.target.closest && ev.target.closest("[data-qsjump]");
    if (b) {
      var id = b.getAttribute("data-qsjump");
      if (id === "*") openLauncherModal();
      else jumpToApp(id, true);
      return;
    }
    var a = ev.target.closest && ev.target.closest('a[href^="#"]');
    if (a) {
      var href = a.getAttribute("href") || "";
      var targetId = href.slice(1);
      if (!targetId) return;
      if (window.EduMasterHierarchy && typeof window.EduMasterHierarchy.navigateToTarget === "function") {
        ev.preventDefault();
        window.EduMasterHierarchy.navigateToTarget(targetId);
        return;
      }
      if (targetId === "hero") {
        ev.preventDefault();
        if (st.activeStudioId) exitActiveStudio(true);
        else setMainTrack("hub", false);
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
      }
      if (SECTION_TO_TRACK[targetId]) {
        ev.preventDefault();
        jumpToApp(targetId, false);
        return;
      }
      var isKnownStudio = STUDIO_SECTION_IDS.indexOf(targetId) !== -1;
      if (isKnownStudio) {
        ev.preventDefault();
        jumpToApp(targetId, true);
      }
    }
  });

  window.EduLauncher = {
    open: openLauncherModal,
    jump: jumpToApp,
    exitStudio: function () { exitActiveStudio(true); },
    setRole: setRoleMode,
    getRole: function () { return st.roleMode; },
    setLayout: setLayoutMode,
    getLayout: function () { return st.layoutMode; },
    setTrack: setMainTrack,
    getTrack: function () { return st.mainTrack; },
    refresh: function () { applyVisibility(); renderInlineHub(); renderMainTrackBar(); },
    repaintHub: function () { renderInlineHub(); renderMainTrackBar(); },
    getRecent: function () {
      var ids = getRecentIds();
      return ids.map(function (id) { return APPS.filter(function (a) { return a.id === id; })[0]; }).filter(Boolean);
    },
    apps: APPS
  };
})();

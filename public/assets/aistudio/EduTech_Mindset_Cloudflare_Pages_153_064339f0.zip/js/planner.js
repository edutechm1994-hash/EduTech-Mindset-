/*
 * استوديو المخطط الأسبوعي الذكي للمعلم والطالب — EduTech Mindset (الإصدار 76)
 * يوفر:
 * 1) جدولاً أسبوعياً تفاعلياً (الأحد - السبت) بـ 6 فترات/حصص يومية قابلة للتخصيص والحفظ التلقائي.
 * 2) قوالب جاهزة بضغطة واحدة: (جدول حصص وتحضيرات المعلم، جدول مذاكرة طالب التوجيهي، جدول المذاكرة اليومي).
 * 3) قائمة أولويات ومهام أسبوعية مع شريط نسبة إنجاز حي ومكافآت نقاط خبرة (+30 XP).
 * 4) تصدير وطباعة الجدول الأسبوعي بتنسيق أنيق جاهز للتعليق أو الحفظ كـ PDF.
 */
(function () {
  "use strict";
  var KEY = "edu_weekly_planner_v76";
  var DAYS = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
  var SLOTS = ["الحصة / الفترة 1", "الحصة / الفترة 2", "الحصة / الفترة 3", "الحصة / الفترة 4", "الحصة / الفترة 5", "الحصة / الفترة 6"];
  var esc = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };

  function defaultState() {
    return {
      title: "خطتي الأسبوعية الذكية",
      owner: "",
      mode: "teacher",
      cells: {},
      tasks: [
        { id: "t1", text: "تحضير خطة درس تفاعلية بالذكاء الاصطناعي", done: false },
        { id: "t2", text: "إعداد ورقة عمل واختبار قصير للوحدة الحالية", done: false },
        { id: "t3", text: "مراجعة الملخصات والخرائط الذهنية", done: false }
      ]
    };
  }

  function load() {
    try {
      var d = JSON.parse(localStorage.getItem(KEY) || "null");
      if (d && typeof d === "object") {
        d.cells = d.cells || {};
        d.tasks = Array.isArray(d.tasks) ? d.tasks : [];
        return d;
      }
    } catch (e) {}
    return defaultState();
  }

  function save(st) {
    try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) {}
  }

  var TEMPLATES = {
    teacher: {
      title: "جدول الحصص والتحضير الأسبوعي للمعلم",
      cells: {
        "0_0": "حصة 1: شرح الدرس الجديد", "0_1": "حصة 2: تطبيق وأوراق عمل", "0_2": "تحضير بالذكاء الاصطناعي", "0_3": "حصة 4: تقويم تكويني",
        "1_0": "حصة 1: مختبر / سبورة تفاعلية", "1_1": "حصة 2: متابعة دفاتر الطلاب", "1_2": "حصة 3: شرح ومناقشة", "1_4": "إعداد اختبار قصير",
        "2_0": "حصة 1: تعلم نشط ومجموعات", "2_1": "حصة 2: مسابقة صفية حية", "2_3": "تحديث ملف الإنجاز المهني",
        "3_0": "حصة 1: مراجعة وحل مسائل", "3_1": "حصة 2: دعم علاجي وإثرائي", "3_2": "إصدار بطاقات متابعة أولياء الأمور",
        "4_0": "حصة 1: اختبار نهاية الأسبوع", "4_1": "حصة 2: تغذية راجعة وتكريم", "4_2": "تخطيط الأسبوع القادم"
      },
      tasks: [
        { id: "tt1", text: "توليد أوراق عمل الأسبوع من استوديو أوراق العمل", done: false },
        { id: "tt2", text: "تجهيز عرض تقديمي تفاعلي للحصة الرئيسية", done: false },
        { id: "tt3", text: "رصد درجات الاختبار الإلكتروني وإرسال تقارير أولياء الأمور", done: false },
        { id: "tt4", text: "تحديث ملف الإنجاز المهني والخطط العلاجية", done: false }
      ]
    },
    tawjihi: {
      title: "جدول المراجعة المكثفة لطالب التوجيهي",
      cells: {
        "0_0": "فجر: رياضيات (وحدة التفاضل)", "0_1": "صباح: لغة عربية (قواعد وبلاغة)", "0_2": "عصر: حل أسئلة سنوات سابقة", "0_3": "مساء: اختبر نفسك بالذكاء الاصطناعي",
        "1_0": "فجر: فيزياء / علوم (قوانين ومسائل)", "1_1": "صباح: لغة إنجليزية (مفردات وقطعة)", "1_2": "عصر: خرائط ذهنية للمفاهيم", "1_3": "مساء: مراجعة بطاقات الاستذكار",
        "2_0": "فجر: رياضيات (تطبيقات عملية)", "2_1": "صباح: تربية إسلامية / تاريخ", "2_2": "عصر: تكنولوجيا وبرمجة", "2_3": "مساء: التحدي اليومي السريع",
        "3_0": "فجر: كيمياء / أحياء (تسميع وفهم)", "3_1": "صباح: لغة عربية (تعبير وأدب)", "3_2": "عصر: حل نموذج امتحان كامل",
        "4_0": "فجر: مراجعة النقاط الصعبة", "4_1": "صباح: لغة إنجليزية (قواعد وكتابة)", "4_2": "عصر: تقييم ذاتي وحساب المعدل",
        "5_0": "صباح: مراجعة شاملة لما سبق", "5_1": "عصر: راحة واستجمام ذهني",
        "6_0": "صباح: تهيئة دروس الأسبوع الجديد", "6_1": "مساء: حل اختبار تجريبي"
      },
      tasks: [
        { id: "tw1", text: "إتمام 3 جلسات تركيز بومودورو (25 دقيقة) يومياً", done: false },
        { id: "tw2", text: "توليد خريطة ذهنية لأصعب درس هذا الأسبوع", done: false },
        { id: "tw3", text: "حل اختبار إلكتروني ذاتي وتحقيق 90% فأعلى", done: false },
        { id: "tw4", text: "تحميل حقيبة المذاكرة بلا إنترنت للمراجعة المسائية", done: false }
      ]
    },
    parent: {
      title: "جدول المتابعة المنزلية الأسبوعي لولي الأمر والأسرة",
      cells: {
        "0_0": "تفقد واجبات الأبناء في بوابة ولي الأمر", "0_1": "جلسة قراءة وتأسيس (25 دقيقة)", "0_2": "مراجعة بطاقات التكرار المتباعد",
        "1_0": "متابعة دروس الرياضيات والعلوم", "1_1": "تدريب إملاء ونطق بمعمل اللغات", "1_2": "تشجيع الأبناء بنقاط XP",
        "2_0": "مراجعة منتصف الأسبوع", "2_1": "مشاهدة فيديو تعليمي مشترك", "2_2": "اختبار قصير بأداة اختبر نفسك",
        "3_0": "متابعة واجبات الفصل الافتراضي", "3_1": "نشاط قصصي أو لعبة تربوية", "3_2": "تحضير حقيبة الغد",
        "4_0": "تقييم إنجاز الأسبوع مع الأبناء", "4_1": "إصدار شهادة تشجيع أسرية من المنصة"
      },
      tasks: [
        { id: "tp1", text: "تفقد مهام ودرجات الأبناء في بوابة ولي الأمر", done: false },
        { id: "tp2", text: "مراجعة البطاقات المستحقة مع الأبناء في المراجعة الذكية", done: false },
        { id: "tp3", text: "مكافأة الأبناء بشهادة تقدير أسرية نهاية الأسبوع", done: false }
      ]
    },
    student: {
      title: "جدول المذاكرة والواجبات الأسبوعي للطالب",
      cells: {
        "0_0": "مراجعة دروس اليوم", "0_1": "حل واجب الرياضيات والعلوم", "0_2": "قراءة وتسميع اللغة العربية",
        "1_0": "مراجعة دروس اليوم", "1_1": "تدريب النطق والإملاء بمعمل اللغات", "1_2": "لعبة تعليمية تفاعلية",
        "2_0": "مراجعة دروس اليوم", "2_1": "مشاهدة فيديو شرح من المراحل الدراسية", "2_2": "اختبار قصير بالمعلم الذكي",
        "3_0": "مراجعة دروس اليوم", "3_1": "تجربة علمية في المختبر الافتراضي", "3_2": "حل التحدي اليومي السريع",
        "4_0": "مراجعة شاملة لدروس الأسبوع", "4_1": "تجهيز حقيبة ومهام الأسبوع القادم"
      },
      tasks: [
        { id: "ts1", text: "مراجعة دروس اليوم أولاً بأول", done: false },
        { id: "ts2", text: "إنجاز التحدي اليومي السريع لكسب نقاط XP", done: false },
        { id: "ts3", text: "قراءة ملخص الوحدة وحل ورقة العمل", done: false }
      ]
    }
  };

  function ensureSection() {
    if (document.getElementById("weeklyPlannerStudio")) return document.getElementById("weeklyPlannerStudio");
    var anchor = document.getElementById("classToolsStudio") || document.getElementById("teacherDash") || document.getElementById("library");
    if (!anchor || !anchor.parentNode) return null;
    var sec = document.createElement("section");
    sec.id = "weeklyPlannerStudio";
    sec.className = "py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-20";
    anchor.parentNode.insertBefore(sec, anchor);
    return sec;
  }

  function render() {
    var sec = ensureSection();
    if (!sec) return;
    var st = load();
    var totalTasks = st.tasks.length;
    var doneTasks = st.tasks.filter(function (t) { return t.done; }).length;
    var pct = totalTasks ? Math.round((doneTasks / totalTasks) * 100) : 0;

    sec.innerHTML =
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl p-5 sm:p-7 space-y-5 text-right">' +
        // Header
        '<div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">' +
          '<div>' +
            '<div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-300 text-xs font-black mb-1">' +
              '<i class="fa-solid fa-calendar-check"></i><span>تنظيم الوقت والتخطيط الذكي</span>' +
            '</div>' +
            '<h2 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">🗓️ المخطط الأسبوعي الذكي وجدول المهام التفاعلي</h2>' +
            '<p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">نظّم حصصك الأسبوعية أو جدول مذاكرتك ومهامك في مكان واحد مع قوالب جاهزة وطباعة مباشرة</p>' +
          '</div>' +
          '<div class="flex flex-wrap items-center gap-2 shrink-0">' +
            '<button type="button" data-wp-tpl="teacher" class="px-3 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-extrabold transition">👨‍🏫 قالب المعلم</button>' +
            '<button type="button" data-wp-tpl="tawjihi" class="px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black transition">🎓 قالب التوجيهي</button>' +
            '<button type="button" data-wp-tpl="student" class="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold transition">🎒 قالب الطالب</button>' +
            '<button type="button" data-wp-tpl="parent" class="px-3 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-extrabold transition">👨‍👩‍👧‍👦 قالب ولي الأمر</button>' +
            '<button type="button" id="btnWpPrint" class="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-extrabold transition"><i class="fa-solid fa-print ml-1"></i>طباعة الجدول</button>' +
            '<button type="button" id="btnWpClear" class="px-3 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500 hover:text-white text-rose-500 text-xs font-extrabold transition">تفريغ</button>' +
          '</div>' +
        '</div>' +

        // Title & Owner Bar
        '<div class="grid grid-cols-1 sm:grid-cols-2 gap-3">' +
          '<div><label class="block text-[11px] font-extrabold text-slate-500 mb-1">عنوان الخطة الأسبوعية:</label>' +
          '<input id="wpTitleInp" type="text" value="' + esc(st.title || "") + '" placeholder="مثال: جدول الحصص والتحضير الأسبوعي" class="w-full text-xs font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2"></div>' +
          '<div><label class="block text-[11px] font-extrabold text-slate-500 mb-1">اسم المعلم / الطالب:</label>' +
          '<input id="wpOwnerInp" type="text" value="' + esc(st.owner || "") + '" placeholder="اكتب اسمك ليظهر عند الطباعة…" class="w-full text-xs font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2"></div>' +
        '</div>' +

        // Interactive Weekly Grid
        '<div class="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">' +
          '<table class="w-full text-right border-collapse min-w-[760px]">' +
            '<thead>' +
              '<tr class="bg-slate-100 dark:bg-slate-800/90 text-slate-800 dark:text-slate-100 text-xs font-black border-b border-slate-200 dark:border-slate-700">' +
                '<th class="p-2.5 w-24 border-l border-slate-200 dark:border-slate-700">اليوم</th>' +
                SLOTS.map(function (s) { return '<th class="p-2.5 border-l border-slate-200 dark:border-slate-700 last:border-l-0">' + esc(s) + '</th>'; }).join("") +
              '</tr>' +
            '</thead>' +
            '<tbody>' +
              DAYS.map(function (day, di) {
                return '<tr class="border-b border-slate-200/70 dark:border-slate-800 last:border-b-0">' +
                  '<td class="p-2.5 font-black text-xs bg-slate-50 dark:bg-slate-900/60 text-brand-700 dark:text-sky-300 border-l border-slate-200 dark:border-slate-700">' + day + '</td>' +
                  SLOTS.map(function (_, si) {
                    var k = di + "_" + si;
                    var val = st.cells[k] || "";
                    return '<td class="p-1.5 border-l border-slate-200/60 dark:border-slate-800 last:border-l-0">' +
                      '<textarea data-wp-cell="' + k + '" rows="2" placeholder="+" class="w-full text-[11px] font-bold bg-transparent hover:bg-slate-50 dark:hover:bg-slate-800/60 focus:bg-white dark:focus:bg-slate-800 rounded-lg p-1.5 outline-none focus:ring-1 focus:ring-brand-500 resize-none leading-snug">' + esc(val) + '</textarea>' +
                    '</td>';
                  }).join("") +
                '</tr>';
              }).join("") +
            '</tbody>' +
          '</table>' +
        '</div>' +

        // Weekly Priority Tasks & Progress Bar
        '<div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">' +
          '<div class="flex flex-wrap items-center justify-between gap-2">' +
            '<h3 class="text-xs sm:text-sm font-black text-slate-900 dark:text-white"><i class="fa-solid fa-list-check text-emerald-500 ml-1.5"></i>أولويات ومهام الأسبوع (' + doneTasks + ' من ' + totalTasks + ' مكتملة — ' + pct + '%)</h3>' +
            '<div class="w-44 h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden"><div class="h-full bg-gradient-to-l from-emerald-500 to-sky-500 transition-all" style="width:' + pct + '%"></div></div>' +
          '</div>' +
          '<div class="flex gap-2">' +
            '<input id="wpNewTaskInp" type="text" placeholder="أضف مهمة أو هدفاً لهذا الأسبوع…" class="flex-1 text-xs font-bold bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2">' +
            '<button type="button" id="btnWpAddTask" class="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-black shrink-0">+ إضافة مهمة</button>' +
          '</div>' +
          '<div class="space-y-1.5">' +
            (st.tasks.length ? st.tasks.map(function (t, idx) {
              return '<div class="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">' +
                '<label class="flex items-center gap-2.5 text-xs font-bold cursor-pointer flex-1">' +
                  '<input type="checkbox" data-wp-chk="' + idx + '" class="w-4 h-4 rounded text-emerald-600" ' + (t.done ? "checked" : "") + '>' +
                  '<span class="' + (t.done ? "line-through text-slate-400" : "text-slate-800 dark:text-slate-100") + '">' + esc(t.text) + '</span>' +
                '</label>' +
                '<button type="button" data-wp-del="' + idx + '" class="text-xs text-rose-500 font-bold px-2 hover:bg-rose-500/10 rounded-lg">✕</button>' +
              '</div>';
            }).join("") : '<p class="text-xs text-slate-400 text-center py-2">لا توجد مهام مضافة بعد.</p>') +
          '</div>' +
        '</div>' +
      '</div>';

    var tInp = document.getElementById("wpTitleInp");
    if (tInp) tInp.oninput = function () { st.title = tInp.value; save(st); };
    var oInp = document.getElementById("wpOwnerInp");
    if (oInp) oInp.oninput = function () { st.owner = oInp.value; save(st); };

    sec.querySelectorAll("[data-wp-cell]").forEach(function (ta) {
      ta.oninput = function () {
        var k = ta.getAttribute("data-wp-cell");
        var v = ta.value.trim();
        if (v) st.cells[k] = ta.value;
        else delete st.cells[k];
        save(st);
      };
    });

    sec.querySelectorAll("[data-wp-tpl]").forEach(function (b) {
      b.onclick = function () {
        var tk = b.getAttribute("data-wp-tpl");
        var tpl = TEMPLATES[tk];
        if (!tpl) return;
        st.mode = tk;
        st.title = tpl.title;
        st.cells = JSON.parse(JSON.stringify(tpl.cells));
        st.tasks = JSON.parse(JSON.stringify(tpl.tasks));
        save(st);
        render();
        toast("✓ تم تحميل القالب الأسبوعي الجاهز — يمكنك تعديل أي خانة بحرية", "success");
      };
    });

    var addBtn = document.getElementById("btnWpAddTask");
    var newInp = document.getElementById("wpNewTaskInp");
    function addTask() {
      if (!newInp || !newInp.value.trim()) return;
      st.tasks.push({ id: "t" + Date.now(), text: newInp.value.trim(), done: false });
      save(st);
      render();
    }
    if (addBtn) addBtn.onclick = addTask;
    if (newInp) newInp.onkeydown = function (ev) { if (ev.key === "Enter") { ev.preventDefault(); addTask(); } };

    sec.querySelectorAll("[data-wp-chk]").forEach(function (chk) {
      chk.onchange = function () {
        var idx = +chk.getAttribute("data-wp-chk");
        if (st.tasks[idx]) {
          st.tasks[idx].done = chk.checked;
          save(st);
          if (chk.checked && window.EduBadges && window.EduBadges.award) {
            window.EduBadges.award("first_step", 10, false);
          }
          render();
        }
      };
    });

    sec.querySelectorAll("[data-wp-del]").forEach(function (del) {
      del.onclick = function () {
        var idx = +del.getAttribute("data-wp-del");
        st.tasks.splice(idx, 1);
        save(st);
        render();
      };
    });

    var clrBtn = document.getElementById("btnWpClear");
    if (clrBtn) {
      clrBtn.onclick = function () {
        if (!window.eduConfirm("هل تريد تفريغ الجدول الأسبوعي والبدء من جديد؟")) return;
        st = { title: "خطتي الأسبوعية الذكية", owner: st.owner || "", mode: "teacher", cells: {}, tasks: [] };
        save(st);
        render();
        toast("تم تفريغ الجدول الأسبوعي", "info");
      };
    }

    var prtBtn = document.getElementById("btnWpPrint");
    if (prtBtn) {
      prtBtn.onclick = function () {
        var w = window.open("", "_blank");
        if (!w) { window.print(); return; }
        var rowsHtml = DAYS.map(function (d, di) {
          return "<tr><td style='font-weight:800;background:#f0f9ff;padding:8px;border:1px solid #cbd5e1'>" + esc(d) + "</td>" +
            SLOTS.map(function (_, si) {
              return "<td style='padding:8px;border:1px solid #cbd5e1;font-size:12px'>" + esc(st.cells[di + "_" + si] || "—") + "</td>";
            }).join("") + "</tr>";
        }).join("");
        var tasksHtml = st.tasks.map(function (t) {
          return "<li style='margin:4px 0;font-size:13px'>" + (t.done ? "☑ " : "☐ ") + esc(t.text) + "</li>";
        }).join("");
        w.document.write(
          "<!DOCTYPE html><html lang='ar' dir='rtl'><head><meta charset='utf-8'><title>" + esc(st.title) + "</title>" +
          "<style>body{font-family:Cairo,Tahoma,sans-serif;padding:24px;color:#0f172a}table{width:100%;border-collapse:collapse;margin-top:14px}th{background:#0284c7;color:#fff;padding:10px;border:1px solid #0284c7;font-size:13px}</style></head><body>" +
          "<h2 style='margin:0 0 6px'>" + esc(st.title || "المخطط الأسبوعي") + "</h2>" +
          "<div style='font-size:13px;color:#475569'>الاسم: " + esc(st.owner || "................") + " | منصة EduTech Mindset — عقلية التعليم والتكنولوجيا</div>" +
          "<table><thead><tr><th>اليوم</th>" + SLOTS.map(function (s) { return "<th>" + esc(s) + "</th>"; }).join("") + "</tr></thead><tbody>" + rowsHtml + "</tbody></table>" +
          (tasksHtml ? "<h3 style='margin-top:18px;font-size:15px'>أولويات ومهام الأسبوع:</h3><ul style='list-style:none;padding:0'>" + tasksHtml + "</ul>" : "") +
          "<script>window.onload=function(){window.print();}</script></body></html>"
        );
        w.document.close();
      };
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", render);
  else render();

  window.EduWeeklyPlanner = { render: render };
})();

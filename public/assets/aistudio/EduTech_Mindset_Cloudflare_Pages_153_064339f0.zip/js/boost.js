/* تقوية الموقع (الإصدار 75):
 * 1) بحث شامل موحّد (يدمج البحث في الكتب والفيديوهات والموارد + البحث الفوري في استوديوهات وأدوات المنصة).
 * 2) مؤقت التركيز والمذاكرة الذكي (Pomodoro 25/45 دقيقة) مع مكافآت نقاط خبرة (XP) تلقائية عند إتمام الجلسة.
 * 3) التحكم السريع بحجم خط المنصة للقراءة المريحة، ومتابعة آخر درس، والمفضلة، وأحدث الإضافات. */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "info"); };
  var LS = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (x) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (x) {} }
  };
  var norm = function (s) { return String(s || "").toLowerCase().replace(/[ً-ْـ]/g, "").replace(/[أإآ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه").replace(/[٠-٩]/g, function (d) { return d.charCodeAt(0) - 1632; }); };
  var TAB = { book: "book", worksheet: "worksheet", summary: "summary", exam: "exam", other: "other" };
  var ICO = { book: "📖", worksheet: "📝", summary: "📋", exam: "✅", other: "📌", video: "🎬", subject: "📚", studio: "🚀" };
  var L = function () { return window.EduLearn; };

  // ----- مؤقت التركيز والمذاكرة (Pomodoro) -----
  var pomoSec = 0, pomoTotal = 1500, pomoTimer = null, pomoRunning = false;
  function fmtTime(s) {
    var m = Math.floor(s / 60), r = s % 60;
    return (m < 10 ? "0" : "") + m + ":" + (r < 10 ? "0" : "") + r;
  }
  function startPomo(mins) {
    clearInterval(pomoTimer);
    pomoTotal = (mins || 25) * 60;
    pomoSec = pomoTotal;
    pomoRunning = true;
    toast("⏱️ بدأت جلسة التركيز والمذاكرة (" + (mins || 25) + " دقيقة) — بالتوفيق! 🌟", "success");
    paintBar();
    pomoTimer = setInterval(function () {
      if (pomoSec > 0) {
        pomoSec--;
        var chip = document.querySelector('[data-b="pomo"]');
        if (chip) chip.innerHTML = "⏱️ تركيز نشط: " + fmtTime(pomoSec) + " (إيقاف)";
      } else {
        clearInterval(pomoTimer);
        pomoTimer = null;
        pomoRunning = false;
        if (typeof playUiSound === "function") { try { playUiSound("success"); } catch (x) {} }
        if (window.EduBadges && window.EduBadges.award) {
          window.EduBadges.award("first_step", 25, false);
        } else {
          toast("🎉 أحسنت! أتممت جلسة التركيز بنجاح (+25 XP)!", "success");
        }
        paintBar();
      }
    }, 1000);
  }
  function stopPomo() {
    clearInterval(pomoTimer);
    pomoTimer = null;
    pomoRunning = false;
    pomoSec = 0;
    toast("⏹️ تم إيقاف مؤقت التركيز", "info");
    paintBar();
  }
  function openPomoModal() {
    if (pomoRunning) { stopPomo(); return; }
    if (typeof showModalContent !== "function") { startPomo(25); return; }
    showModalContent(
      '<div class="p-4 shrink-0 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50">' +
        '<h3 class="text-sm font-black">⏱️ مؤقت التركيز والمذاكرة الذكي (Pomodoro)</h3>' +
        '<button type="button" class="p-2 text-slate-400" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button>' +
      '</div>' +
      '<div class="p-5 space-y-4 text-right">' +
        '<p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">اختر مدة جلسة المذاكرة أو الحصة الدراسية؛ سيظهر العدّ التنازلي مباشرة في شريطك السريع، وتحصل على <b>+25 نقطة خبرة (XP)</b> فور إتمام الجلسة:</p>' +
        '<div class="grid grid-cols-1 sm:grid-cols-3 gap-2.5">' +
          '<button type="button" data-pomo-min="15" class="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 hover:border-brand-500 bg-white dark:bg-slate-800 text-center transition"><div class="text-xl font-black text-brand-600 dark:text-sky-400">15 دقيقة</div><div class="text-[11px] text-slate-500 mt-1">مراجعة سريعة لدرس</div></button>' +
          '<button type="button" data-pomo-min="25" class="p-3.5 rounded-2xl border-2 border-emerald-500 bg-emerald-500/10 text-center transition"><div class="text-xl font-black text-emerald-600 dark:text-emerald-400">25 دقيقة ⭐</div><div class="text-[11px] text-slate-500 mt-1">جلسة بومودورو قياسية</div></button>' +
          '<button type="button" data-pomo-min="45" class="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 hover:border-brand-500 bg-white dark:bg-slate-800 text-center transition"><div class="text-xl font-black text-amber-500">45 دقيقة</div><div class="text-[11px] text-slate-500 mt-1">حصة دراسية كاملة</div></button>' +
        '</div>' +
      '</div>'
    );
    document.querySelectorAll("[data-pomo-min]").forEach(function (b) {
      b.onclick = function () {
        var mins = parseInt(b.getAttribute("data-pomo-min"), 10) || 25;
        closeModal();
        startPomo(mins);
      };
    });
  }

  // ----- مشاركة -----
  function linkOf(s, g, m, v) { return location.origin + location.pathname + "#learn/" + [s, g, m, v].filter(Boolean).join("/"); }
  function share(title, url) {
    var text = title + "\n" + url + "\n— EduTech Mindset";
    window.open("https://wa.me/?text=" + encodeURIComponent(text), "_blank", "noopener");
  }

  // ----- مفضلة / متابعة -----
  var favs = function () { return LS.get("edu_favs", []); };
  function isFav(id) { return favs().some(function (f) { return f.id === id; }); }
  function toggleFav(o) {
    var l = favs(), i = l.findIndex(function (f) { return f.id === o.id; });
    if (i > -1) { l.splice(i, 1); toast("أُزيل من المفضلة", "info"); } else { l.unshift(o); toast("أُضيف إلى المفضلة ⭐", "success"); }
    LS.set("edu_favs", l.slice(0, 60)); paintBar();
  }
  var lastSave = 0;
  function track(st, c) {
    if (!st || !st.m || !c || !c.M) return;
    var now = Date.now(); if (now - lastSave < 1500) return; lastSave = now;
    LS.set("edu_last", { s: st.s, g: st.g, m: st.m, v: st.v || "", t: st.t || "v", label: c.M.name + " — " + c.G.name });
    if (window.EduBadges && window.EduBadges.award) window.EduBadges.award("first_step", 10, true);
    setTimeout(paintBar, 0);
  }

  // ----- بحث موحّد (المناهج والكتب + استوديوهات المنصة الذكية) -----
  function buildIndex() {
    var out = [];
    if (window.EduLauncher && Array.isArray(window.EduLauncher.apps)) {
      window.EduLauncher.apps.forEach(function (ap) {
        out.push({
          k: "studio",
          ico: ap.ico || "🚀",
          t: ap.title,
          sub: "أداة ذكية — " + (ap.desc || ""),
          key: norm(ap.title + " " + (ap.desc || "") + " " + (ap.badge || "")),
          studioId: ap.id
        });
      });
    }
    var api = L();
    if (api && api.data) {
      var d = api.data();
      (d.tree.stages || []).forEach(function (S) { (S.grades || []).forEach(function (G) { (G.subjects || []).forEach(function (M) {
        out.push({ k: "subject", t: M.name, sub: S.name.replace(/\s*\(.*\)\s*$/, "") + " — " + G.name, key: norm(M.name + " " + G.name + " " + S.name), go: [S.id, G.id, M.id, "v", ""] });
        (M.videos || []).forEach(function (v) { out.push({ k: "video", t: v.title, sub: M.name + " — " + G.name, key: norm(v.title + " " + (v.desc || "") + " " + M.name), go: [S.id, G.id, M.id, "v", v.id] }); });
      }); }); });
      (d.res || []).forEach(function (r) { if (r.subjectId) out.push({ k: r.kind || "other", t: r.title, sub: "", key: norm(r.title + " " + (r.desc || "")), go: [r.stageId, r.gradeId, r.subjectId, TAB[r.kind] || "other", ""] }); });
      (d.books || []).forEach(function (b) { out.push({ k: "book", t: b.title, sub: [b.subject, b.stage && b.stage.replace(/\s*\(.*\)\s*$/, "")].filter(Boolean).join(" — "), key: norm(b.title + " " + (b.subject || "") + " " + (b.author || "")), book: b }); });
    }
    if (window.EduBookReader && typeof window.EduBookReader.allBooks === "function") {
      (window.EduBookReader.allBooks() || []).forEach(function (b) {
        (b.lessons || []).forEach(function (ls, cIdx) {
          out.push({
            k: "book",
            ico: "📖",
            t: ls.t + " (" + b.title + ")",
            sub: "فصل تفاعلي في قاعدة البيانات — " + (b.grade || "") + " • " + (b.subject || ""),
            key: norm(ls.t + " " + b.title + " " + (b.subject || "") + " " + (ls.k || []).join(" ")),
            readerBookId: b.id,
            readerChapIdx: cIdx
          });
        });
      });
    }
    return out;
  }
  function openHit(h) {
    if (h.readerBookId && window.EduBookReader && window.EduBookReader.open) {
      window.EduBookReader.open(h.readerBookId, h.readerChapIdx || 0, "interactive");
      return;
    }
    if (h.studioId && window.EduLauncher && window.EduLauncher.jump) {
      window.EduLauncher.jump(h.studioId);
      return;
    }
    if (h.book) {
      var loc = L() && L().locateBook && L().locateBook(h.book);
      if (loc) { L().go(loc.s, loc.g, loc.m, "book", ""); return; }
      if (h.book.url) window.open(h.book.url, "_blank", "noopener");
      return;
    }
    if (h.go && L() && L().go) L().go.apply(null, h.go);
  }
  function runSearch(q) {
    var box = $("bsRes"); if (!box) return;
    q = norm(q).trim();
    if (q.length < 2) { box.innerHTML = ""; box.classList.add("hidden"); return; }
    var words = q.split(/\s+/), idx = buildIndex(), hits = [];
    idx.forEach(function (it) {
      var sc = 0;
      for (var i = 0; i < words.length; i++) {
        if (it.key.indexOf(words[i]) === -1) { sc = 0; break; }
        sc += norm(it.t).indexOf(words[i]) !== -1 ? 3 : 1;
      }
      if (sc) hits.push({ it: it, sc: sc });
    });
    hits.sort(function (a, b) { return b.sc - a.sc; });
    hits = hits.slice(0, 12);
    box.classList.remove("hidden");
    box.innerHTML = hits.length
      ? hits.map(function (h, i) {
          return '<button type="button" data-h="' + i + '" class="w-full text-right flex items-center gap-2.5 px-3.5 py-2.5 border-b border-slate-100 dark:border-slate-700 last:border-0 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition">' +
            '<span class="text-lg shrink-0">' + (h.it.ico || ICO[h.it.k] || "📌") + '</span>' +
            '<span class="min-w-0 flex-1"><span class="block text-xs font-extrabold text-slate-900 dark:text-white truncate">' + e(h.it.t) + '</span>' +
            '<span class="block text-[10px] text-slate-500 dark:text-slate-400 truncate">' + e(h.it.sub) + "</span></span></button>";
        }).join("")
      : '<div class="px-3 py-4 text-xs text-slate-500 text-center">لا نتائج مطابقة لـ «' + e(q) + "»</div>";
    box.querySelectorAll("[data-h]").forEach(function (b) {
      b.addEventListener("click", function () {
        var h = hits[+b.dataset.h];
        box.classList.add("hidden");
        $("bsQ").value = "";
        openHit(h.it);
      });
    });
  }

  // ----- أحدث المحتوى -----
  function latest() {
    var api = L(); if (!api || !api.data) return [];
    var d = api.data(), out = [];
    var sec = function (r) { return (r && r.updatedAt && r.updatedAt.seconds) || (r && r.createdAt && r.createdAt.seconds) || 0; };
    (d.res || []).forEach(function (r) { if (r.subjectId) out.push({ at: sec(r), k: r.kind || "other", t: r.title, go: [r.stageId, r.gradeId, r.subjectId, TAB[r.kind] || "other", ""] }); });
    (d.books || []).forEach(function (b) { out.push({ at: sec(b), k: "book", t: b.title, book: b }); });
    return out.filter(function (x) { return x.at; }).sort(function (a, b) { return b.at - a.at; }).slice(0, 6);
  }

  // ----- شريط البحث الموحّد والإنجاز الشخصي -----
  var deferred = null;
  window.addEventListener("beforeinstallprompt", function (ev) { ev.preventDefault(); deferred = ev; paintBar(); });
  window.addEventListener("appinstalled", function () { deferred = null; paintBar(); });
  function build() {
    if ($("boostBar")) return true;
    var anchor = $("eduOrganizedPlatformRoot") || $("learnSection"); if (!anchor) return false;
    var s = document.createElement("section"); s.id = "boostBar"; s.className = "pt-3 pb-1";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8"><div class="relative"><div class="flex items-center gap-2 px-4 py-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm focus-within:border-brand-500 transition"><span class="text-lg">🔍</span><input id="bsQ" type="search" autocomplete="off" class="flex-1 min-w-0 bg-transparent outline-none text-xs sm:text-sm font-bold" placeholder="ابحث فوراً في جميع الكتب والفيديوهات والملخصات والأدوات الذكية…"></div><div id="bsRes" class="hidden absolute z-30 right-0 left-0 mt-2 max-h-[60vh] overflow-y-auto rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xl text-right"></div></div><div id="bsRow" class="mt-3 space-y-2"></div></div>';
    anchor.parentNode.insertBefore(s, anchor);
    var q = $("bsQ"); q.addEventListener("input", function () { runSearch(q.value); });
    document.addEventListener("click", function (ev) { var r = $("bsRes"); if (r && !ev.target.closest("#bsRes,#bsQ")) r.classList.add("hidden"); });
    paintBar(); return true;
  }
  function chipBtn(attr, label, cls) { return '<button type="button" ' + attr + ' class="px-3.5 py-2 rounded-xl text-[11px] font-extrabold whitespace-nowrap shrink-0 transition ' + cls + '">' + label + "</button>"; }
  function paintBar() {
    var row = $("bsRow"); if (!row) return;
    var last = LS.get("edu_last", null), fv = favs(), lt = latest();
    var curScale = (window.EduA11y && window.EduA11y.getScale) ? window.EduA11y.getScale() : 100;
    var h = '<div class="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1 no-scrollbar">';
    var pend = window.EduExamQueue && window.EduExamQueue.pending ? window.EduExamQueue.pending() : 0;
    if (pend > 0) h += chipBtn('data-b="syncq"', "📤 إرسال نتائج الاختبار المؤجلة (" + pend + ")", "bg-rose-600 text-white animate-pulse");
    if (last) h += chipBtn('data-b="cont"', "▶ تابع: " + e(last.label), "bg-brand-600 text-white shadow-xs");
    var bdg = window.EduBadges && window.EduBadges.summary ? window.EduBadges.summary() : { xp: 0, level: 1, count: 0 };
    h += chipBtn('data-b="badges"', "🏅 أوسمتي (مستوى " + bdg.level + " • " + bdg.xp + " XP)", "bg-gradient-to-l from-amber-500 to-yellow-400 text-slate-950 shadow-sm");
    h += chipBtn('data-b="pomo"', pomoRunning ? ("⏱️ تركيز نشط: " + fmtTime(pomoSec) + " (إيقاف)") : "⏱️ مؤقت المذاكرة (25 د)", pomoRunning ? "bg-emerald-600 text-white animate-pulse" : "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30");
    h += chipBtn('data-b="favs"', "⭐ مفضلتي (" + fv.length + ")", "bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30");
    h += chipBtn('data-b="font"', "🔠 حجم الخط (" + curScale + "%)", "bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200");
    if (deferred) h += chipBtn('data-b="inst"', "📲 ثبّت التطبيق", "bg-emerald-600 text-white");

    var recApps = (window.EduLauncher && window.EduLauncher.getRecent) ? window.EduLauncher.getRecent().slice(0, 4) : [];
    recApps.forEach(function (ap) {
      h += chipBtn('data-jump="' + ap.id + '"', "🕒 " + ap.ico + " " + e(ap.title), "bg-slate-900 text-amber-300 border border-amber-400/40");
    });
    h += "</div>";

    if (lt.length) {
      h += '<div class="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1 items-center no-scrollbar"><span class="text-[11px] font-black shrink-0 text-emerald-600 dark:text-emerald-400">🆕 أحدث الإضافات:</span>' +
        lt.map(function (x, i) {
          return '<button type="button" data-lt="' + i + '" class="px-3 py-1.5 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-brand-500 text-[11px] font-bold whitespace-nowrap shrink-0 transition">' + (ICO[x.k] || "📌") + " " + e(x.t.length > 28 ? x.t.slice(0, 28) + "…" : x.t) + "</button>";
        }).join("") + "</div>";
    }
    row.innerHTML = h;
    row.querySelectorAll("[data-b]").forEach(function (b) { b.addEventListener("click", function () { act(b.dataset.b); }); });
    row.querySelectorAll("[data-jump]").forEach(function (b) { b.addEventListener("click", function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump(b.dataset.jump, false); }); });
    row.querySelectorAll("[data-lt]").forEach(function (b) { b.addEventListener("click", function () { openHit(lt[+b.dataset.lt]); }); });
  }
  function act(a) {
    if (a === "cont") { var l = LS.get("edu_last", null); if (l) L().go(l.s, l.g, l.m, l.t, l.v); }
    else if (a === "syncq") { if (window.EduExamQueue && window.EduExamQueue.flush) { window.EduExamQueue.flush(); setTimeout(paintBar, 2000); } }
    else if (a === "launcher") { if (window.EduLauncher && window.EduLauncher.open) window.EduLauncher.open(); }
    else if (a === "badges") { if (window.EduBadges && window.EduBadges.open) window.EduBadges.open(); }
    else if (a === "pomo") openPomoModal();
    else if (a === "font") { if (window.EduA11y && window.EduA11y.cycleFont) window.EduA11y.cycleFont(); }
    else if (a === "inst") { if (deferred) { deferred.prompt(); deferred.userChoice.then(function () { deferred = null; paintBar(); }); } }
    else if (a === "favs") favModal();
  }
  function favModal() {
    var fv = favs();
    var body = fv.length ? fv.map(function (f, i) { return '<div class="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700"><button type="button" data-fo="' + i + '" class="flex-1 min-w-0 text-right"><div class="text-xs font-extrabold truncate">' + (ICO[f.k] || "⭐") + " " + e(f.title) + '</div><div class="text-[10px] text-slate-500 truncate">' + e(f.label || "") + '</div></button><button type="button" data-fd="' + i + '" class="px-2.5 py-1.5 rounded-lg bg-rose-500/10 text-rose-500 text-[11px]">✕</button></div>'; }).join("") : '<p class="text-xs text-slate-500 text-center py-6">لا مفضلة بعد. اضغط ☆ على أي كتاب أو ملخص أو فيديو.</p>';
    if (typeof showModalContent !== "function") return;
    showModalContent('<div class="p-4 shrink-0 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50"><h3 class="text-sm font-extrabold">⭐ مفضلتي</h3><button type="button" class="p-2 text-slate-400" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button></div><div class="p-3 overflow-y-auto flex-1 min-h-0 space-y-2 text-right">' + body + "</div>");
    document.querySelectorAll("[data-fo]").forEach(function (b) { b.addEventListener("click", function () { var f = fv[+b.dataset.fo]; closeModal(); L().go(f.s, f.g, f.m, f.t || "v", f.v || ""); }); });
    document.querySelectorAll("[data-fd]").forEach(function (b) { b.addEventListener("click", function () { var l = favs(); l.splice(+b.dataset.fd, 1); LS.set("edu_favs", l); paintBar(); favModal(); }); });
  }

  window.EduBoost = { track: track, share: share, linkOf: linkOf, isFav: isFav, toggleFav: toggleFav, repaint: paintBar };
  function init() { if (build()) return; var n = 0, t = setInterval(function () { if (build() || ++n > 20) clearInterval(t); }, 250); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

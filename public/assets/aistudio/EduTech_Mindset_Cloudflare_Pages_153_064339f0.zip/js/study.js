/* study.js: اختبر نفسك (بالذكاء الاصطناعي) + بنك الأسئلة + التحدي اليومي + طيّ مولّد البرومبتات */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "info"); };
  var BK = "edu_qbank_v1", SK = "edu_study_v1";
  var inp = "w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-sm font-bold";
  var btnP = "px-4 py-2.5 rounded-xl bg-brand-600 text-white font-black text-sm", btnS = "px-4 py-2.5 rounded-xl bg-slate-200 dark:bg-slate-700 font-black text-sm";

  function lg(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
  function ls(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  var bank = function () { var b = lg(BK, []); return Array.isArray(b) ? b : []; };
  var stats = function () { var s = lg(SK, {}); s.days = s.days || {}; return s; };
  function uid() { return "q" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function dayKey(d) { d = d || new Date(); return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2); }
  function streak() {
    var s = stats(), n = 0, d = new Date();
    if (!s.days[dayKey(d)]) d.setDate(d.getDate() - 1);
    while (s.days[dayKey(d)]) { n++; d.setDate(d.getDate() - 1); }
    return n;
  }
  function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function seeded(seed, n, len) { var x = 0; for (var i = 0; i < seed.length; i++) x = (x * 31 + seed.charCodeAt(i)) >>> 0; var idx = [], used = {}; while (idx.length < Math.min(n, len)) { x = (x * 1664525 + 1013904223) >>> 0; var k = x % len; if (!used[k]) { used[k] = 1; idx.push(k); } } return idx; }
  function show(html) { if (typeof showModalContent === "function") showModalContent('<div class="p-4 sm:p-5 text-right overflow-y-auto min-h-0" id="stBody">' + html + "</div>"); }
  function head(t) { return '<div class="flex items-center justify-between mb-3"><h3 class="text-lg font-black">' + t + '</h3><button type="button" onclick="closeModal()" aria-label="إغلاق" class="px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-700 text-sm font-bold">✕</button></div>'; }

  /* ---------- أسئلة التحدي الافتراضية ---------- */
  var POOL = [
    ["ما عاصمة دولة فلسطين؟", ["القدس", "غزة", "رام الله", "الخليل"], 0], ["ناتج 7 × 8 = ؟", ["54", "56", "48", "63"], 1], ["الغاز الذي نتنفسه ونحتاجه للحياة هو:", ["ثاني أكسيد الكربون", "النيتروجين", "الأكسجين", "الهيليوم"], 2],
    ["كم عدد قارات العالم؟", ["5", "6", "7", "8"], 2], ["جمع كلمة «كتاب» هو:", ["كتّاب", "كتب", "كاتبون", "مكاتب"], 1], ["أكبر كواكب المجموعة الشمسية:", ["الأرض", "المريخ", "المشتري", "عطارد"], 2],
    ["يغلي الماء النقي عند درجة:", ["50 °م", "80 °م", "100 °م", "150 °م"], 2], ["مجموع زوايا المثلث يساوي:", ["90°", "180°", "270°", "360°"], 1], ["مرادف كلمة «سعيد»:", ["حزين", "فرحان", "غاضب", "تعب"], 1],
    ["أي الكلمات التالية فعل؟", ["مدرسة", "كتبَ", "جميل", "قلم"], 1], ["الجزء الذي يمتص الماء في النبات:", ["الورقة", "الزهرة", "الجذر", "الثمرة"], 2], ["نصف العدد 250 هو:", ["125", "150", "100", "135"], 0],
    ["ضد كلمة «قصير»:", ["صغير", "طويل", "ضعيف", "بطيء"], 1], ["أصغر عدد أولي هو:", ["0", "1", "2", "3"], 2], ["أسرع الحيوانات البرية:", ["الأسد", "الحصان", "الفهد", "النمر"], 2],
    ["مساحة مربع طول ضلعه 5 سم:", ["10", "20", "25", "15"], 2], ["الفاعل في الجملة الفعلية يكون:", ["منصوباً", "مجروراً", "مرفوعاً", "مجزوماً"], 2], ["المصدر الرئيسي للطاقة على الأرض:", ["القمر", "الشمس", "الرياح", "البحر"], 1],
    ["ناتج 144 ÷ 12 = ؟", ["10", "11", "12", "14"], 2], ["العضو الذي يضخ الدم في الجسم:", ["الرئة", "الكبد", "المعدة", "القلب"], 3]
  ].map(function (r) { return { q: r[0], o: r[1], a: r[2], e: "" }; });

  /* ---------- مشغّل الاختبار ---------- */
  function runQuiz(qs, opt) {
    var run = qs.map(function (q) { var order = shuffle(q.o.map(function (_, i) { return i; })); return { q: q.q, e: q.e || "", o: order.map(function (i) { return q.o[i]; }), a: order.indexOf(q.a), src: q }; });
    var i = 0, score = 0, wrong = [];
    function paint() {
      if (i >= run.length) return done();
      var q = run[i];
      show(head(opt.title) + '<div class="flex items-center justify-between text-xs font-black text-slate-500 mb-2"><span>السؤال ' + (i + 1) + " من " + run.length + '</span><button type="button" id="stSay" class="px-2 py-1 rounded-lg bg-emerald-100 text-emerald-800">🔊 اقرأ السؤال</button></div>' +
        '<div class="h-2 rounded-full bg-slate-200 dark:bg-slate-700 mb-3"><div class="h-2 rounded-full bg-brand-600" style="width:' + Math.round(i / run.length * 100) + '%"></div></div>' +
        '<p class="text-base font-black leading-7 mb-3">' + esc(q.q) + '</p><div class="space-y-2">' + q.o.map(function (t, k) { return '<button type="button" data-k="' + k + '" class="st-opt w-full text-right px-4 py-3 rounded-xl border-2 border-slate-200 dark:border-slate-600 font-bold text-sm bg-white dark:bg-slate-800">' + esc(t) + "</button>"; }).join("") + '</div><div id="stFb" class="mt-3 text-sm font-bold"></div><div id="stNext" class="mt-3"></div>');
      $("stSay").onclick = function () { if (window.EduVoice) EduVoice.read(q.q + " ... " + q.o.map(function (t, k) { return (k + 1) + "، " + t; }).join(" ... ")); };
      Array.prototype.forEach.call(document.querySelectorAll(".st-opt"), function (b) {
        b.onclick = function () {
          var k = +b.getAttribute("data-k"), ok = k === q.a;
          Array.prototype.forEach.call(document.querySelectorAll(".st-opt"), function (x) { x.disabled = true; var xi = +x.getAttribute("data-k"); if (xi === q.a) x.className += " !border-emerald-500 !bg-emerald-50 dark:!bg-emerald-900/30"; else if (xi === k) x.className += " !border-rose-500 !bg-rose-50 dark:!bg-rose-900/30"; });
          if (ok) score++; else wrong.push(q);
          $("stFb").innerHTML = (ok ? '<span class="text-emerald-600">✅ إجابة صحيحة!</span>' : '<span class="text-rose-600">❌ الصحيح: ' + esc(q.o[q.a]) + "</span>") + (q.e ? '<div class="mt-1 text-slate-600 dark:text-slate-300 font-semibold">💡 ' + esc(q.e) + "</div>" : "");
          $("stNext").innerHTML = '<button type="button" id="stGo" class="' + btnP + '">' + (i + 1 >= run.length ? "عرض النتيجة" : "التالي ←") + "</button>";
          $("stGo").onclick = function () { i++; paint(); };
        };
      });
    }
    function done() {
      var pct = Math.round(score / run.length * 100), emo = pct >= 90 ? "🏆" : pct >= 70 ? "🌟" : pct >= 50 ? "👍" : "💪";
      var s = stats(); s.quizzes = (s.quizzes || 0) + 1; ls(SK, s);
      if (opt.onDone) opt.onDone(score, run.length);
      show(head(opt.title) + '<div class="text-center py-4"><div class="text-5xl mb-2">' + emo + '</div><div class="text-3xl font-black">' + score + " / " + run.length + '</div><div class="text-sm font-bold text-slate-500 mt-1">' + pct + "%</div>" + (opt.extra ? opt.extra() : "") + "</div>" +
        (wrong.length ? '<div class="mb-3 p-3 rounded-xl bg-rose-50 dark:bg-rose-900/20 text-xs font-bold"><b>راجع هذه الأسئلة:</b><ul class="list-disc pr-5 mt-1 space-y-1">' + wrong.map(function (w) { return "<li>" + esc(w.q) + " ← <b>" + esc(w.o[w.a]) + "</b></li>"; }).join("") + "</ul></div>" : "") +
        '<div class="flex flex-wrap gap-2">' + (opt.save ? '<button type="button" id="stSave" class="' + btnS + '">💾 احفظ الأسئلة في بنكي</button>' : "") + '<button type="button" id="stAgain" class="' + btnP + '">🔁 ' + (opt.again ? "اختبار جديد" : "أعد المحاولة") + '</button></div>');
      if ($("stSave")) $("stSave").onclick = function () { var n = addToBank(run.map(function (r) { return r.src; }), opt.meta || {}); toast("تمت إضافة " + n + " سؤال لبنك الأسئلة ✅", "success"); this.disabled = true; };
      $("stAgain").onclick = function () { if (opt.again) opt.again(); else runQuiz(qs, opt); };
    }
    paint();
  }

  /* ---------- بنك الأسئلة ---------- */
  function addToBank(list, meta) {
    var b = bank(), seen = {}; b.forEach(function (x) { seen[x.q] = 1; }); var n = 0;
    list.forEach(function (q) { if (!q || !q.q || seen[q.q]) return; seen[q.q] = 1; b.push({ id: uid(), q: q.q, o: q.o, a: q.a, e: q.e || "", s: meta.s || "", g: meta.g || "", d: Date.now() }); n++; });
    ls(BK, b); return n;
  }
  function openBank(filter) {
    var b = bank(), subs = {}; b.forEach(function (x) { if (x.s) subs[x.s] = 1; });
    var shown = filter ? b.filter(function (x) { return x.s === filter; }) : b;
    show(head("🗃️ بنك الأسئلة (" + b.length + ")") +
      '<div class="flex flex-wrap gap-2 mb-3"><select id="bkF" class="' + inp + ' !w-auto"><option value="">كل المواد</option>' + Object.keys(subs).map(function (s) { return '<option' + (s === filter ? " selected" : "") + ">" + esc(s) + "</option>"; }).join("") + '</select>' +
      '<button type="button" id="bkAdd" class="' + btnP + '">➕ سؤال يدوي</button><button type="button" id="bkGen" class="' + btnS + '">✨ ولّد بالذكاء</button><button type="button" id="bkTest" class="' + btnS + '">🎯 اختبرني منه</button><button type="button" id="bkToRev" class="' + btnS + ' !bg-emerald-600 !text-white">🧠 أرسل للمراجعة الذكية</button></div>' +
      '<div class="flex flex-wrap gap-2 mb-3 text-xs"><button type="button" id="bkCopy" class="' + btnS + ' !py-1.5">📋 نسخ كنص</button><button type="button" id="bkExp" class="' + btnS + ' !py-1.5">⬇ تصدير JSON</button><label class="' + btnS + ' !py-1.5 cursor-pointer">⬆ استيراد<input id="bkImp" type="file" accept=".json" class="hidden"></label></div>' +
      (shown.length ? '<div class="space-y-2">' + shown.map(function (x, k) { return '<div class="p-3 rounded-xl border border-slate-200 dark:border-slate-700 text-sm"><div class="font-black">' + (k + 1) + ". " + esc(x.q) + '</div><div class="text-xs mt-1 text-slate-600 dark:text-slate-300">' + x.o.map(function (t, i) { return (i === x.a ? "✅ " : "▫ ") + esc(t); }).join(" — ") + '</div><div class="flex justify-between mt-1 text-[11px] text-slate-400"><span>' + esc(x.s) + '</span><button type="button" data-del="' + x.id + '" class="text-rose-600 font-black">حذف</button></div></div>'; }).join("") + "</div>" : '<p class="text-sm font-bold text-slate-500 py-6 text-center">البنك فارغ. أضف أسئلة يدوياً، أو ولّدها بالذكاء، أو احفظها بعد «اختبر نفسك».</p>') +
      '<p class="text-[11px] text-slate-400 mt-3 font-bold">الأسئلة محفوظة على هذا الجهاز؛ استخدم التصدير للنسخ الاحتياطي أو النقل لجهاز آخر.</p>');
    $("bkF").onchange = function () { openBank(this.value); };
    $("bkAdd").onclick = function () { manualForm(); };
    $("bkGen").onclick = function () { quizForm(true); };
    if ($("bkToRev")) $("bkToRev").onclick = function () { if (!shown.length) return toast("أضف أسئلة للبنك أولاً", "warning"); if (window.EduBridge && window.EduBridge.toReview) window.EduBridge.toReview(filter || "بنك الأسئلة", shown.map(function (x) { return { q: x.q, a: (x.o || [])[x.a] || "" }; })); };
    $("bkTest").onclick = function () { if (shown.length < 3) return toast("أضف 3 أسئلة على الأقل", "warning"); runQuiz(shuffle(shown).slice(0, 10), { title: "🎯 اختبار من بنكي", again: function () { openBank(filter); } }); };
    $("bkCopy").onclick = function () { var t = shown.map(function (x, k) { return (k + 1) + ") " + x.q + "\n" + x.o.map(function (o, i) { return "   " + "أبجد"[i] + ". " + o; }).join("\n") + "\n   الإجابة: " + "أبجد"[x.a]; }).join("\n\n"); (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(function () { toast("تم النسخ ✅", "success"); }, function () { toast("تعذر النسخ", "warning"); }); };
    $("bkExp").onclick = function () { var a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify(b, null, 1)], { type: "application/json" })); a.download = "question-bank.json"; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); };
    $("bkImp").onchange = function () { var f = this.files[0]; if (!f) return; var r = new FileReader(); r.onload = function () { try { var arr = JSON.parse(r.result), n = addToBank((arr || []).map(function (x) { return x && x.q && Array.isArray(x.o) && typeof x.a === "number" ? { q: String(x.q).slice(0, 400), o: x.o.slice(0, 6).map(function (t) { return String(t).slice(0, 200); }), a: x.a, e: String(x.e || "").slice(0, 300) } : null; }), {}); toast("تم استيراد " + n + " سؤال", "success"); openBank(); } catch (e) { toast("ملف غير صالح", "warning"); } }; r.readAsText(f); };
    Array.prototype.forEach.call(document.querySelectorAll("[data-del]"), function (x) { x.onclick = function () { ls(BK, bank().filter(function (q) { return q.id !== x.getAttribute("data-del"); })); openBank(filter); }; });
  }
  function manualForm() {
    show(head("➕ سؤال جديد") + '<input id="mqQ" class="' + inp + ' mb-2" placeholder="نص السؤال *">' + [0, 1, 2, 3].map(function (i) { return '<div class="flex items-center gap-2 mb-2"><input type="radio" name="mqA" value="' + i + '"' + (i === 0 ? " checked" : "") + '><input id="mqO' + i + '" class="' + inp + '" placeholder="الخيار ' + (i + 1) + (i < 2 ? " *" : "") + '"></div>'; }).join("") +
      '<input id="mqE" class="' + inp + ' mb-2" placeholder="تعليل الإجابة (اختياري)"><input id="mqS" class="' + inp + ' mb-3" placeholder="المادة (اختياري)"><p class="text-[11px] text-slate-500 mb-2 font-bold">حدّد الدائرة بجانب الإجابة الصحيحة.</p><div class="flex gap-2"><button type="button" id="mqOk" class="' + btnP + '">حفظ</button><button type="button" id="mqBack" class="' + btnS + '">رجوع</button></div>');
    $("mqBack").onclick = function () { openBank(); };
    $("mqOk").onclick = function () {
      var q = $("mqQ").value.trim(), o = [0, 1, 2, 3].map(function (i) { return $("mqO" + i).value.trim(); }), a = +document.querySelector('input[name="mqA"]:checked').value;
      var map = [], opts = []; o.forEach(function (t, i) { if (t) { map[i] = opts.length; opts.push(t); } });
      if (!q || opts.length < 2 || o[a] === "") return toast("اكتب السؤال وخيارين على الأقل وحدّد الصحيح", "warning");
      addToBank([{ q: q, o: opts, a: map[a], e: $("mqE").value.trim() }], { s: $("mqS").value.trim() }); toast("تم الحفظ ✅", "success"); openBank();
    };
  }

  /* ---------- اختبر نفسك (توليد بالذكاء الاصطناعي) ---------- */
  function parseQs(txt) {
    var s = String(txt || "").replace(/```json|```/gi, ""), a = s.indexOf("{"), b = s.lastIndexOf("}"); if (a < 0 || b <= a) throw new Error("نتيجة غير مفهومة");
    var arr = (JSON.parse(s.slice(a, b + 1)).questions || []).map(function (x) {
      var o = (x.options || x.o || []).map(function (t) { return String(t).trim(); }).filter(Boolean), a2 = Number(x.answer != null ? x.answer : x.a);
      if (!x.q || o.length < 2 || !(a2 >= 0 && a2 < o.length)) return null; return { q: String(x.q).trim().slice(0, 400), o: o.slice(0, 5), a: a2, e: String(x.explain || x.e || "").slice(0, 300) };
    }).filter(Boolean);
    if (arr.length < 2) throw new Error("لم تُولَّد أسئلة صالحة"); return arr;
  }
  function buildFallbackQs(topic, text, n) {
    var t = String(topic || "الدرس").trim();
    var lines = String(text || "").split(/[\n.،؛!]+/).map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 18; });
    var out = [
      { q: "ما الفكرة المحورية التي يتناولها درس «" + t + "»؟", o: [lines[0] || ("فهم القواعد الأساسية وتطبيقات " + t), "حفظ الأرقام فقط دون تطبيق", "إلغاء القواعد العلمية", "تجاهل الأمثلة العملية"], a: 0, e: "يركز الدرس على الفهم العميق والتطبيق العملي للمفهوم." },
      { q: "أي مما يلي يُعد تطبيقاً صحيحاً لموضوع «" + t + "»؟", o: [lines[1] || ("ربط مفاهيم «" + t + "» بالأمثلة والتدريبات المنهجية"), "الاعتماد على التخمين العشوائي", "حذف المعطيات الأساسية", "عدم التحقق من النتيجة"], a: 0, e: "التطبيق المنهجي السليم يربط القاعدة بالمثال التدريبي." },
      { q: "عند مراجعة درس «" + t + "»، ما الخطوة الأهم للتحقق من الإتقان؟", o: [lines[2] || "حل تدريبات متنوعة وتفسير خطوات الحل", "قراءة العنوان فقط", "تخطي الأسئلة الاستنتاجية", "ترك الأمثلة المحلولة"], a: 0, e: "حل التدريبات وتفسير الخطوات يثبت الفهم ويكشف نقاط القوة." }
    ].concat(POOL);
    return out.slice(0, Math.max(3, Math.min(n || 5, 10)));
  }
  function gen(topic, text, n, ctx) {
    var p = "أنت معلم فلسطيني خبير. ولّد " + n + " أسئلة اختيار من متعدد (4 خيارات، إجابة صحيحة واحدة فقط) بالعربية الفصحى المبسطة" + (ctx ? " لـ " + ctx : "") + " حول الدرس: «" + topic + "»." + (text ? "\nاعتمد حصراً على النص التالي:\n" + text.slice(0, 5000) : "\nاعتمد على معرفتك بالمنهاج الفلسطيني.") +
      '\nأعد JSON فقط بلا أي شرح خارجه بهذا الشكل: {"questions":[{"q":"السؤال","options":["أ","ب","ج","د"],"answer":0,"explain":"سطر واحد يبرر الإجابة"}]} حيث answer رقم الخيار الصحيح (يبدأ من 0). نوّع مواضع الإجابة الصحيحة.';
    return window.AI.ask(p, null, "studio").then(parseQs).catch(function () {
      return buildFallbackQs(topic, text, n);
    });
  }
  function lessonsList() {
    var out = []; try { (window.EduBooks ? window.EduBooks.list() : []).forEach(function (b) { (b.lessons || []).forEach(function (l) { out.push({ t: l.t, x: l.x || "", b: b.title || "", s: b.subject || "", g: b.grade || "" }); }); }); } catch (e) {} return out;
  }
  function quizForm(toBank) {
    if (!window.AI || !window.AI.ask) return toast("أداة الذكاء الاصطناعي غير متاحة الآن", "warning");
    var L = lessonsList().slice(0, 300);
    show(head(toBank ? "✨ توليد أسئلة لبنك الأسئلة" : "🎯 اختبر نفسك") +
      (L.length ? '<select id="qzL" class="' + inp + ' mb-2"><option value="">— اختر درساً من الكتب (اختياري) —</option>' + L.map(function (l, i) { return '<option value="' + i + '">' + esc(l.t) + (l.x ? " 📄" : "") + (l.b ? " — " + esc(l.b) : "") + "</option>"; }).join("") + "</select>" : "") +
      '<input id="qzT" class="' + inp + ' mb-2" placeholder="عنوان الدرس / الموضوع *">' +
      '<div class="flex flex-wrap gap-1.5 mb-2">' +
        '<label class="px-2.5 py-1.5 rounded-xl bg-emerald-600 text-white text-[11px] font-black cursor-pointer flex items-center gap-1"><i class="fa-solid fa-camera"></i><span>صوّر صفحة الدرس بالكاميرا</span><input id="qzCamInp" type="file" accept="image/*" capture="environment" class="hidden"></label>' +
        '<label class="px-2.5 py-1.5 rounded-xl bg-sky-600 text-white text-[11px] font-black cursor-pointer flex items-center gap-1"><i class="fa-solid fa-folder-open"></i><span>ارفع صورة أو ملفاً من الجهاز</span><input id="qzFileInp" type="file" accept="image/*,application/pdf,.txt,.md" multiple class="hidden"></label>' +
      '</div>' +
      '<textarea id="qzX" rows="4" maxlength="6000" class="' + inp + ' mb-2" placeholder="الصق نص الدرس هنا أو صوّر الصفحة بالكاميرا أعلاه للحصول على أسئلة مطابقة لكتابك"></textarea>' +
      '<div class="flex gap-2 mb-3"><input id="qzS" class="' + inp + '" placeholder="المادة / الصف (اختياري)"><select id="qzN" class="' + inp + ' !w-28"><option>5</option><option selected>8</option><option>10</option></select></div>' +
      '<button type="button" id="qzGo" class="' + btnP + ' w-full">⚡ ' + (toBank ? "ولّد واحفظ في البنك" : "ابدأ الاختبار") + '</button><div id="qzSt" class="text-xs font-bold text-slate-500 mt-2"></div>');
    ["qzCamInp", "qzFileInp"].forEach(function (cid) {
      if ($(cid)) $(cid).onchange = function (ev) {
        if (!window.EduSourceCapture) return;
        window.EduSourceCapture.handleFiles(ev.target.files, {
          onText: function (txt, fn) {
            if ($("qzX")) $("qzX").value = txt.slice(0, 5500);
            if ($("qzT") && !$("qzT").value.trim()) $("qzT").value = (fn || "درس").replace(/\.[^.]+$/, "");
          },
          onUpdate: function (all) {
            if (all.length && $("qzT") && !$("qzT").value.trim()) $("qzT").value = all[0].name.replace(/\.[^.]+$/, "");
            if ($("qzSt")) $("qzSt").textContent = "📷 تم إرفاق " + all.length + " صفحة/ملف — اضغط «ابدأ الاختبار» لتوليد أسئلة منها";
          }
        });
        ev.target.value = "";
      };
    });
    if ($("qzL")) $("qzL").onchange = function () { var l = L[+this.value]; if (l) { $("qzT").value = l.t; $("qzX").value = l.x || ""; $("qzS").value = [l.s, l.g].filter(Boolean).join(" - "); } };
    $("qzGo").onclick = function () {
      var t = $("qzT").value.trim(); if (!t) return toast("اكتب عنوان الدرس", "warning");
      var btn = this, ctx = $("qzS").value.trim(); btn.disabled = true; btn.textContent = "جارٍ التوليد…"; $("qzSt").textContent = "⏳ قد يستغرق حتى نصف دقيقة";
      gen(t, $("qzX").value.trim(), +$("qzN").value, ctx).then(function (qs) {
        var meta = { s: ctx || t };
        if (toBank) { var n = addToBank(qs, meta); toast("أُضيف " + n + " سؤال للبنك ✅", "success"); openBank(); }
        else runQuiz(qs, { title: "🎯 " + t, save: true, meta: meta, again: function () { quizForm(false); } });
      }, function (e) { btn.disabled = false; btn.textContent = "حاول مرة أخرى"; $("qzSt").textContent = "تعذّر التوليد: " + ((e && e.message) || "خطأ"); });
    };
  }

  /* ---------- التحدي اليومي ---------- */
  function openDaily() {
    var key = dayKey(), s = stats(), done = s.days[key], pool = POOL.concat(bank().filter(function (x) { return x.o && x.o.length >= 2; }));
    var idx = seeded(key, 5, pool.length), qs = idx.map(function (i) { return pool[i]; }), st = streak();
    function stripe() { var h = ""; for (var k = 6; k >= 0; k--) { var d = new Date(); d.setDate(d.getDate() - k); h += '<span class="inline-block w-7 h-7 rounded-lg text-[11px] font-black leading-7 text-center ' + (s.days[dayKey(d)] ? "bg-emerald-500 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-500") + '">' + d.getDate() + "</span>"; } return h; }
    show(head("🔥 التحدي اليومي") + '<div class="text-center"><div class="text-5xl mb-1">' + (st ? "🔥" : "🎯") + '</div><div class="text-xl font-black">' + (st ? st + " يوم متتالٍ" : "ابدأ سلسلتك اليوم") + '</div><div class="flex justify-center gap-1 my-3" dir="ltr">' + stripe() + "</div>" +
      (done ? '<p class="text-sm font-bold text-emerald-600 mb-3">✅ أنجزت تحدي اليوم: ' + done.s + " من " + done.t + "<br>عُد غداً لتحدٍّ جديد!</p>" : '<p class="text-sm font-bold text-slate-600 dark:text-slate-300 mb-3">5 أسئلة جديدة كل يوم، أجب عنها للحفاظ على سلسلتك.</p>') +
      '<button type="button" id="dcGo" class="' + btnP + '">' + (done ? "🔁 العب مرة أخرى للتدريب" : "▶ ابدأ التحدي") + "</button></div>");
    $("dcGo").onclick = function () {
      runQuiz(qs, { title: "🔥 التحدي اليومي", onDone: function (sc, t) { var s2 = stats(); if (!s2.days[key]) { s2.days[key] = { s: sc, t: t }; ls(SK, s2); } }, extra: function () { var n = streak(); return '<div class="mt-2 text-sm font-black text-amber-600">🔥 سلسلتك: ' + n + " يوم</div>"; }, again: function () { openDaily(); } });
    };
  }

  /* ---------- طيّ مولّد البرومبتات على الجوال ---------- */
  function foldGenerator() {
    var g = $("generator"); if (!g || g.getAttribute("data-fold")) return; g.setAttribute("data-fold", "1");
    if (window.innerWidth >= 768) return;
    var inner = g.firstElementChild; if (!inner) return;
    inner.style.maxHeight = "380px"; inner.style.overflow = "hidden"; inner.style.position = "relative";
    var b = document.createElement("button"); b.type = "button"; b.id = "genToggle"; b.textContent = "▼ عرض المزيد من المولّد";
    b.className = "block mx-auto mt-3 px-5 py-2.5 rounded-full bg-brand-600 text-white font-black text-sm shadow"; g.appendChild(b);
    function open() { inner.style.maxHeight = ""; inner.style.overflow = ""; b.style.display = "none"; }
    b.onclick = open;
    document.addEventListener("click", function (e) { var a = e.target.closest && e.target.closest('a[href="#generator"]'); if (a) open(); });
    if (location.hash === "#generator") open();
  }

  window.EduStudy = { quiz: function () { quizForm(false); }, bank: function () { openBank(); }, daily: openDaily, streak: streak };
  function init() { foldGenerator(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

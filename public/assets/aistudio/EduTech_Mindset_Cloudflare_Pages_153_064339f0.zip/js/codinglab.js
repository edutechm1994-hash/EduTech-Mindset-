/*
 * أكاديمية البرمجة والتكنولوجيا والروبوتكس (Coding, Algorithm & Robotics Lab) — EduTech Mindset (الإصدار 49)
 * مصممة لمنهاج التكنولوجيا والبرمجة الفلسطيني (الصفوف 5 إلى 12) وتعمل بلا إنترنت:
 * 1) 🤖 تحديات خوارزميات الروبوت باللبنات (Block-Style Robot Maze Puzzles) لتعليم الحلقات والشروط والاتجاهات.
 * 2) 💻 محرر ومشغّل الويب والجافاسكريبت المباشر (HTML/CSS/JS Live Sandbox) مع قوالب تعليمية جاهزة.
 * 3) 🧠 معلم ومصحح البرمجة الذكي (AI Code Tutor & Debugger) لشرح الأكواد وتصحيح الأخطاء البرمجية بالعربية.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var LEVELS = [
    { name: "المستوى 1: المسار المستقيم", start: [0, 2], goal: [4, 2], walls: [[1, 1], [2, 1], [3, 1], [1, 3], [2, 3], [3, 3]], hint: "استخدم 4 خطوات «تقدم للأمام ⬆️» للوصول إلى النجمة!" },
    { name: "المستوى 2: المنعطف الذكي", start: [0, 0], goal: [3, 3], walls: [[1, 1], [2, 1], [3, 1], [1, 2]], hint: "تقدم 3 خطوات، ثم انعطف يميناً وتقدم 3 خطوات!" },
    { name: "المستوى 3: متاهة الخوارزمية", start: [0, 4], goal: [4, 0], walls: [[1, 4], [1, 3], [3, 1], [3, 0], [2, 2]], hint: "اصعد للأعلى أولاً ثم التف حول الحواجز للوصول إلى الهدف!" }
  ];

  var CODE_TEMPLATES = {
    calc: {
      name: "🧮 آلة حاسبة تفاعلية بسيطة",
      code: "<div style='font-family:Cairo,sans-serif;text-align:center;padding:20px;direction:rtl'>\n  <h2 style='color:#0284c7'>آلة جمع الأعداد التفاعلية</h2>\n  <input id='n1' type='number' value='15' style='padding:8px;width:80px;text-align:center'> +\n  <input id='n2' type='number' value='27' style='padding:8px;width:80px;text-align:center'>\n  <button onclick='calc()' style='padding:8px 16px;background:#10b981;color:#fff;border:0;border-radius:8px;cursor:pointer'>احسب الناتج</button>\n  <h3 id='out' style='color:#0f172a'>الناتج: 42</h3>\n</div>\n<script>\nfunction calc() {\n  var a = +document.getElementById('n1').value;\n  var b = +document.getElementById('n2').value;\n  document.getElementById('out').textContent = 'الناتج: ' + (a + b);\n}\n<\/script>"
    },
    shapes: {
      name: "🎨 رسم زخرفة هندسية بالحلقة التكرارية (For Loop)",
      code: "<div style='text-align:center;background:#0f172a;padding:15px'>\n  <canvas id='cv' width='400' height='260'></canvas>\n</div>\n<script>\nvar ctx = document.getElementById('cv').getContext('2d');\nctx.translate(200, 130);\nvar colors = ['#38bdf8', '#10b981', '#f59e0b', '#e11d48', '#a855f7'];\nfor (var i = 0; i < 18; i++) {\n  ctx.strokeStyle = colors[i % colors.length];\n  ctx.lineWidth = 2;\n  ctx.strokeRect(-55, -55, 110, 110);\n  ctx.rotate(Math.PI / 9);\n}\n<\/script>"
    },
    quiz: {
      name: "❓ بطاقة سؤال برمجي تفاعلي",
      code: "<div style='font-family:Cairo,sans-serif;direction:rtl;padding:20px;text-align:center'>\n  <h3>ما هي عاصمة فلسطين الأبدية؟</h3>\n  <button onclick=\"ans('القدس الشريف ✅')\" style='padding:10px 20px;margin:5px;background:#0284c7;color:#fff;border:0;border-radius:10px'>القدس</button>\n  <button onclick=\"ans('حاول مرة أخرى ❌')\" style='padding:10px 20px;margin:5px;background:#64748b;color:#fff;border:0;border-radius:10px'>أريحا</button>\n  <p id='msg' style='font-weight:bold;font-size:18px'></p>\n</div>\n<script>\nfunction ans(txt) { document.getElementById('msg').textContent = txt; }\n<\/script>"
    }
  };

  var st = {
    tab: "robot", // robot | editor | ai
    lvIdx: 0,
    cmds: [], // ["F", "R", "L", "F2"]
    robotPos: [0, 2],
    robotDir: 0, // 0: right (+x), 1: down (+y), 2: left (-x), 3: up (-y)
    code: CODE_TEMPLATES.calc.code,
    aiOut: ""
  };

  function resetRobot() {
    var lv = LEVELS[st.lvIdx] || LEVELS[0];
    st.robotPos = [lv.start[0], lv.start[1]];
    st.robotDir = 0;
    drawMaze();
  }

  function isWall(lv, x, y) {
    return (lv.walls || []).some(function (w) { return w[0] === x && w[1] === y; });
  }

  function drawMaze() {
    var cv = $("cdMazeCv"); if (!cv) return;
    var lv = LEVELS[st.lvIdx] || LEVELS[0];
    var S = 68, N = 5;
    cv.width = S * N; cv.height = S * N;
    var ctx = cv.getContext("2d");
    ctx.clearRect(0, 0, cv.width, cv.height);

    for (var y = 0; y < N; y++) {
      for (var x = 0; x < N; x++) {
        var wall = isWall(lv, x, y);
        ctx.fillStyle = wall ? "#334155" : ((x + y) % 2 === 0 ? "#0f172a" : "#1e293b");
        ctx.fillRect(x * S, y * S, S, S);
        ctx.strokeStyle = "#475569";
        ctx.strokeRect(x * S, y * S, S, S);
        if (wall) {
          ctx.font = "28px sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
          ctx.fillText("🧱", x * S + S / 2, y * S + S / 2);
        }
      }
    }
    // الهدف
    ctx.font = "34px sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText("⭐", lv.goal[0] * S + S / 2, lv.goal[1] * S + S / 2);

    // الروبوت
    var rx = st.robotPos[0] * S + S / 2, ry = st.robotPos[1] * S + S / 2;
    var arrows = ["➡️", "⬇️", "⬅️", "⬆️"];
    ctx.font = "32px sans-serif";
    ctx.fillText("🤖", rx, ry - 4);
    ctx.font = "16px sans-serif";
    ctx.fillText(arrows[st.robotDir % 4], rx + 16, ry + 16);
  }

  function runRobotProgram() {
    resetRobot();
    var lv = LEVELS[st.lvIdx] || LEVELS[0];
    var expanded = [];
    st.cmds.forEach(function (c) {
      if (c === "F2") { expanded.push("F", "F"); }
      else if (c === "F3") { expanded.push("F", "F", "F"); }
      else expanded.push(c);
    });
    if (!expanded.length) { toast("أضف أوامر برمجية للروبوت أولاً!", "warning"); return; }

    var i = 0;
    var dx = [1, 0, -1, 0], dy = [0, 1, 0, -1];
    var iv = setInterval(function () {
      if (i >= expanded.length) {
        clearInterval(iv);
        if (st.robotPos[0] === lv.goal[0] && st.robotPos[1] === lv.goal[1]) {
          toast("🎉 أحسنت يا مبرمج المستقبل! وصل الروبوت إلى الهدف بنجاح!");
          if (window.EduBadges && window.EduBadges.award) window.EduBadges.award("first_step", 40);
        } else {
          toast("لم يصل الروبوت إلى النجمة بعد — عدّل الخوارزمية وجرب مجدداً 💡", "info");
        }
        return;
      }
      var cmd = expanded[i++];
      if (cmd === "R") st.robotDir = (st.robotDir + 1) % 4;
      else if (cmd === "L") st.robotDir = (st.robotDir + 3) % 4;
      else if (cmd === "F") {
        var nx = st.robotPos[0] + dx[st.robotDir], ny = st.robotPos[1] + dy[st.robotDir];
        if (nx >= 0 && nx < 5 && ny >= 0 && ny < 5 && !isWall(lv, nx, ny)) {
          st.robotPos = [nx, ny];
        } else {
          clearInterval(iv);
          drawMaze();
          toast("💥 اصطدم الروبوت بحاجز أو حافة الشبكة! راجع خطواتك", "warning");
          return;
        }
      }
      drawMaze();
    }, 420);
  }

  function paint() {
    var box = $("cdBody"); if (!box) return;
    var tabs = [
      ["robot", "🤖 خوارزميات الروبوت باللبنات"],
      ["editor", "💻 محرر الكود التفاعلي المباشر (HTML/JS)"],
      ["ai", "🧠 معلم ومصحح البرمجة الذكي"]
    ];
    var nav = '<div class="flex flex-wrap gap-2 mb-4 border-b border-slate-200 dark:border-slate-700 pb-3">' +
      tabs.map(function (t) {
        var on = st.tab === t[0];
        return '<button type="button" data-cdtab="' + t[0] + '" class="px-4 py-2 rounded-xl text-xs font-extrabold transition-all ' + (on ? "bg-emerald-600 text-white shadow" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300") + '">' + t[1] + '</button>';
      }).join("") + '</div>';

    var body = "";
    if (st.tab === "robot") {
      var lv = LEVELS[st.lvIdx] || LEVELS[0];
      var CMD_LBL = { F: "⬆️ تقدم خطوة", F2: "⏫ كرر تقدم (2×)", F3: "🚀 كرر تقدم (3×)", R: "↪️ انعطف يميناً", L: "↩️ انعطف يساراً" };
      body = '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">' +
        '<div class="lg:col-span-6 space-y-3">' +
        '<div class="flex flex-wrap gap-1.5">' +
        LEVELS.map(function (l, i) {
          return '<button type="button" data-cdlv="' + i + '" class="px-3 py-1.5 rounded-xl text-xs font-black ' + (st.lvIdx === i ? "bg-brand-600 text-white" : "bg-slate-200 dark:bg-slate-700") + '">' + e(l.name) + '</button>';
        }).join("") + '</div>' +
        '<div class="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs font-bold text-amber-800 dark:text-amber-300">💡 التوجيه: ' + e(lv.hint) + '</div>' +
        '<div class="text-xs font-black">أضف لبنات الأوامر لبناء الخوارزمية:</div>' +
        '<div class="flex flex-wrap gap-1.5">' +
        Object.keys(CMD_LBL).map(function (k) {
          return '<button type="button" data-cdadd="' + k + '" class="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-extrabold shadow-sm">+ ' + CMD_LBL[k] + '</button>';
        }).join("") + '</div>' +
        '<div class="p-3 rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700 min-h-[90px] bg-slate-50 dark:bg-slate-900/50">' +
        '<div class="text-[11px] font-bold text-slate-400 mb-2">البرنامج الحالي (' + st.cmds.length + ' لبنات — اضغط على أي لبنة لحذفها):</div>' +
        '<div class="flex flex-wrap gap-1.5">' +
        (st.cmds.length ? st.cmds.map(function (c, idx) {
          return '<button type="button" data-cdrm="' + idx + '" class="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-xs font-bold">' + (idx + 1) + '. ' + CMD_LBL[c] + ' ✕</button>';
        }).join("") : '<span class="text-xs text-slate-400">لم تضف أوامر بعد…</span>') + '</div></div>' +
        '<div class="flex gap-2">' +
        '<button type="button" id="cdRunRobot" class="flex-1 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-black shadow">▶ شغّل الخوارزمية</button>' +
        '<button type="button" id="cdClearRobot" class="px-4 py-2.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold">🗑 مسح الأوامر</button></div>' +
        '</div>' +
        '<div class="lg:col-span-6 flex flex-col items-center justify-center">' +
        '<div class="p-3 rounded-3xl bg-slate-950 border-2 border-slate-700 shadow-xl"><canvas id="cdMazeCv" class="rounded-xl block"></canvas></div>' +
        '</div></div>';
    } else if (st.tab === "editor") {
      body = '<div class="space-y-3">' +
        '<div class="flex flex-wrap items-center gap-2">' +
        '<span class="text-xs font-bold">اختر مشروعاً جاهزاً للتجربة والتعديل:</span>' +
        Object.keys(CODE_TEMPLATES).map(function (k) {
          return '<button type="button" data-cdtpl="' + k + '" class="px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-extrabold">' + CODE_TEMPLATES[k].name + '</button>';
        }).join("") +
        '<button type="button" id="cdRunCode" class="px-5 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-black mr-auto">▶ تشغيل الكود</button></div>' +
        '<div class="grid grid-cols-1 lg:grid-cols-2 gap-3">' +
        '<textarea id="cdCodeInp" dir="ltr" rows="11" class="w-full font-mono text-xs p-3 rounded-2xl bg-slate-950 text-emerald-300 border border-slate-700">' + e(st.code) + '</textarea>' +
        '<iframe id="cdPreviewFrame" sandbox="allow-scripts" class="w-full h-64 rounded-2xl border-2 border-slate-300 dark:border-slate-700 bg-white"></iframe>' +
        '</div></div>';
    } else if (st.tab === "ai") {
      body = '<div class="space-y-3">' +
        '<label class="block text-xs font-bold">الصق أي كود برمجي (Python, JavaScript, HTML, C++, Scratch) أو اكتب سؤالك في منهاج التكنولوجيا:</label>' +
        '<textarea id="cdAiInp" rows="4" class="' + cls + '" placeholder="مثال: اشرح لي الفرق بين حلقة For وحلقة While مع مثال مبسط / أو الصق كوداً لتصحيح أخطائه…"></textarea>' +
        '<button type="button" id="cdAiAskBtn" class="px-6 py-2.5 rounded-xl bg-teal-600 text-white text-xs font-black shadow">🤖 اشرح الكود أو صحّح الخطأ البرمجي</button>' +
        (st.aiOut ? '<div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 text-xs leading-loose whitespace-pre-line font-semibold">' + e(st.aiOut) + '</div>' : '') +
        '</div>';
    }

    box.innerHTML = nav + body;
    box.querySelectorAll("[data-cdtab]").forEach(function (b) {
      b.onclick = function () { st.tab = b.dataset.cdtab; paint(); };
    });

    if (st.tab === "robot") {
      setTimeout(resetRobot, 40);
      box.querySelectorAll("[data-cdlv]").forEach(function (b) {
        b.onclick = function () { st.lvIdx = +b.dataset.cdlv; st.cmds = []; paint(); };
      });
      box.querySelectorAll("[data-cdadd]").forEach(function (b) {
        b.onclick = function () { if (st.cmds.length < 16) { st.cmds.push(b.dataset.cdadd); paint(); } };
      });
      box.querySelectorAll("[data-cdrm]").forEach(function (b) {
        b.onclick = function () { st.cmds.splice(+b.dataset.cdrm, 1); paint(); };
      });
      $("cdRunRobot").onclick = runRobotProgram;
      $("cdClearRobot").onclick = function () { st.cmds = []; paint(); };
    } else if (st.tab === "editor") {
      function runLive() {
        st.code = $("cdCodeInp").value;
        var fr = $("cdPreviewFrame");
        if (fr) fr.srcdoc = st.code;
      }
      setTimeout(runLive, 50);
      $("cdRunCode").onclick = runLive;
      box.querySelectorAll("[data-cdtpl]").forEach(function (b) {
        b.onclick = function () {
          st.code = CODE_TEMPLATES[b.dataset.cdtpl].code;
          paint();
        };
      });
    } else if (st.tab === "ai") {
      $("cdAiAskBtn").onclick = function () {
        var q = $("cdAiInp").value.trim(); if (!q) return;
        var b = $("cdAiAskBtn"); b.disabled = true; b.textContent = "⏳ يحلل الكود…";
        window.AI.ask("أنت معلم تكنولوجيا وبرمجة خبير في المنهاج الفلسطيني. اشرح هذا المفهوم أو الكود البرمجي بأسلوب مبسط مع أمثلة واضحة:\n" + q, [], "studio").then(function (txt) {
          st.aiOut = txt; paint();
        }).catch(function () { b.disabled = false; b.textContent = "🤖 اشرح الكود أو صحّح الخطأ البرمجي"; });
      };
    }
  }

  function build() {
    if ($("codingLabStudio")) return true;
    var anchor = $("simLabStudio") || $("edtechLabSection") || $("learnSection");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "codingLabStudio";
    s.className = "py-12 scroll-mt-20 overflow-x-hidden";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-emerald-800 via-teal-900 to-slate-950 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-emerald-300 mb-1">💻 أكاديمية البرمجة والتكنولوجيا والروبوتكس</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">تحديات خوارزميات الروبوت باللبنات، محرر الكود المباشر، ومعلم البرمجة الذكي</h2>' +
      '<p class="text-xs text-white/85 mt-1">مختبر تفاعلي لمنهاج التكنولوجيا والبرمجة الفلسطيني لتنمية التفكير الحاسوبي والمنطقي (يعمل بلا إنترنت).</p>' +
      '</div><div class="p-4 sm:p-6 text-right" id="cdBody"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    paint();
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduCodingLab = { open: function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("codingLabStudio", true); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

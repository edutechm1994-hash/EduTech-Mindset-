/*
 * مولّد العروض التقديمية (داخل الموقع) — EduTech Mindset
 * - توليد شرائح بالذكاء الاصطناعي (موضوع / نص / صورة من الكاميرا)
 * - تعديل كل شريحة، حفظ في Firestore (presentations)، عرض بملء الشاشة، رابط مشاركة للطلاب (?p=ID)
 * أنواع الشرائح: title / points / mcq / poll / summary
 * التصويت: مجموعة pollVotes (مستند لكل شريحة: pid + c0..c4)، يصوّت الطالب مرة لكل جهاز وتظهر النتائج مباشرة للمعلم
 */
(function () {
  "use strict";
  var COL = "presentations", VOTES = "pollVotes";
  var THEMES = [
    { id: "ocean", s: "1E3A8A", f: "F8FAFC", a: "FBBF24", name: "المحيط", bg: "linear-gradient(135deg,#0f172a,#1e3a8a)", fg: "#f8fafc", accent: "#fbbf24", card: "rgba(255,255,255,.1)" },
    { id: "forest", s: "166534", f: "F0FDF4", a: "FDE047", name: "الغابة", bg: "linear-gradient(135deg,#052e16,#166534)", fg: "#f0fdf4", accent: "#fde047", card: "rgba(255,255,255,.12)" },
    { id: "sunset", s: "9F1239", f: "FFF7ED", a: "FDE68A", name: "الغروب", bg: "linear-gradient(135deg,#7c2d12,#be123c)", fg: "#fff7ed", accent: "#fde68a", card: "rgba(255,255,255,.14)" },
    { id: "paper", s: "FEF3C7", f: "1E293B", a: "B45309", name: "ورقي", bg: "linear-gradient(135deg,#fffbeb,#fef3c7)", fg: "#1e293b", accent: "#b45309", card: "rgba(30,41,59,.07)" },
    { id: "violet", s: "4C1D95", f: "FAF5FF", a: "F9A8D4", name: "البنفسج", bg: "linear-gradient(135deg,#2e1065,#6d28d9)", fg: "#faf5ff", accent: "#f9a8d4", card: "rgba(255,255,255,.12)" }
  ];
  var TYPES = { title: "غلاف", points: "نقاط", mcq: "سؤال اختيار", poll: "تصويت سريع", summary: "خلاصة" };
  var GRADES = ["الأول الأساسي", "الثاني الأساسي", "الثالث الأساسي", "الرابع الأساسي", "الخامس الأساسي", "السادس الأساسي", "السابع", "الثامن", "التاسع", "العاشر", "الحادي عشر", "الثاني عشر", "جامعي / تدريب معلمين"];

  var st = { id: "", title: "", theme: "ocean", slides: [], cur: 0, topic: "", grade: GRADES[3], subject: "", dirty: false, attach: [] };
  var inputCls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";
  function e(s) { return typeof escapeHtml === "function" ? escapeHtml(String(s == null ? "" : s)) : String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function $(id) { return document.getElementById(id); }
  function toast(m, t) { if (typeof showToast === "function") showToast(m, t || "success"); }
  function theme(id) { return THEMES.filter(function (t) { return t.id === id; })[0] || THEMES[0]; }
  function cloud() { return window.Cloud && window.Cloud.enabled; }
  function uid() { return window.Cloud && window.Cloud.getStudioUser ? window.Cloud.getStudioUser().uid : (window.Cloud && window.Cloud.user ? window.Cloud.user.uid : "local_workspace"); }

  // ---------- عرض شريحة واحدة (HTML) — الأحجام بوحدة cqw لتتناسب مع أي شاشة ----------
  // صور الشرائح: data URL مضغوطة (jpeg/png/webp) أو رابط https
  function safeImg(u) {
    u = String(u || "").trim();
    if (/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(u) && u.length < 400000) return u;
    if (/^https:\/\/[^\s'"<>()]+$/.test(u) && u.length < 500) return u;
    return "";
  }
  function imgTotal(arr) { return (arr || []).reduce(function (a, x) { return a + (/^data:/.test(x.img || "") ? x.img.length : 0); }, 0); }
  function withImg(o, x) { var im = safeImg(x && x.img); if (im) { o.img = im; o.imgMode = x.imgMode === "bg" && o.t === "title" ? "bg" : "side"; } return o; }
  function slideHtml(s, th, interactive, idx) {
    var base = "background:" + th.bg + ";color:" + th.fg + ";direction:rtl;text-align:right;font-family:inherit;display:flex;flex-direction:column;justify-content:center;padding:5cqw 6cqw;box-sizing:border-box;overflow:hidden;";
    var h = "";
    var deco = '<div style="position:absolute;left:-8cqw;top:-8cqw;width:26cqw;height:26cqw;border-radius:50%;background:' + th.accent + ';opacity:.16"></div><div style="position:absolute;right:-6cqw;bottom:-10cqw;width:30cqw;height:30cqw;border-radius:50%;background:' + th.accent + ';opacity:.10"></div>';
    var n = '<div style="position:absolute;left:2.5cqw;bottom:1.6cqw;font-size:1.7cqw;opacity:.55;font-weight:700">' + (idx != null ? idx + 1 : "") + "</div>";
    if (s.t === "title") {
      h = '<div style="text-align:center;position:relative"><div style="font-size:6.2cqw;font-weight:900;line-height:1.35">' + e(s.title) + '</div><div style="width:12cqw;height:.8cqw;background:' + th.accent + ';border-radius:9cqw;margin:2.4cqw auto"></div><div style="font-size:2.8cqw;opacity:.88;font-weight:600">' + e(s.sub) + "</div></div>";
    } else if (s.t === "poll") {
      h = '<div style="position:relative"><div style="font-size:1.9cqw;font-weight:800;color:' + th.accent + ';margin-bottom:1cqw">📊 تصويت سريع</div><div style="font-size:3.6cqw;font-weight:900;line-height:1.5;margin-bottom:2.2cqw">' + e(s.q) + '</div>' +
        (s.options || []).map(function (o, i) {
          return '<div data-popt="' + i + '" style="position:relative;overflow:hidden;background:' + th.card + ';border-radius:1.6cqw;padding:1.3cqw 2cqw;margin-bottom:1.2cqw;font-size:2.5cqw;font-weight:700;' + (interactive ? "cursor:pointer;" : "") + '"><div data-bar style="position:absolute;top:0;right:0;bottom:0;width:0;background:' + th.accent + ';opacity:.4"></div><span style="position:relative">' + e(o) + '</span><span data-n style="position:relative;float:left;font-size:2.1cqw"></span></div>';
        }).join("") + '<div data-tot style="font-size:2cqw;font-weight:700;opacity:.85;min-height:2.6cqw"></div></div>';
    } else if (s.t === "mcq") {
      var letters = ["أ", "ب", "ج", "د"];
      h = '<div style="position:relative"><div style="font-size:1.9cqw;font-weight:800;color:' + th.accent + ';margin-bottom:1cqw">❓ سؤال</div><div style="font-size:3.6cqw;font-weight:900;line-height:1.5;margin-bottom:2.2cqw">' + e(s.q) + '</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:1.4cqw">' +
        (s.options || []).map(function (o, i) {
          return '<div ' + (interactive ? 'data-opt="' + i + '" ' : "") + 'style="background:' + th.card + ';border:.25cqw solid transparent;border-radius:1.6cqw;padding:1.4cqw 1.8cqw;font-size:2.5cqw;font-weight:700;display:flex;gap:1.2cqw;align-items:center;' + (interactive ? "cursor:pointer;" : "") + '"><span style="min-width:4cqw;height:4cqw;border-radius:50%;background:' + th.accent + ';color:#0f172a;display:flex;align-items:center;justify-content:center;font-size:2.2cqw;font-weight:900">' + letters[i] + "</span><span>" + e(o) + "</span></div>";
        }).join("") + '</div><div data-why style="margin-top:1.6cqw;font-size:2.1cqw;font-weight:700;min-height:3cqw"></div></div>';
    } else {
      var icon = s.t === "summary" ? "✅ " : "";
      h = '<div style="position:relative"><div style="font-size:4.4cqw;font-weight:900;margin-bottom:1.2cqw">' + icon + e(s.title) + '</div><div style="width:9cqw;height:.7cqw;background:' + th.accent + ';border-radius:9cqw;margin-bottom:2.4cqw"></div><div style="display:flex;flex-direction:column;gap:1.5cqw">' +
        (s.points || []).map(function (p) { return '<div style="display:flex;gap:1.6cqw;align-items:flex-start;font-size:2.9cqw;font-weight:600;line-height:1.5"><span style="margin-top:1cqw;min-width:1.6cqw;height:1.6cqw;border-radius:50%;background:' + th.accent + '"></span><span>' + e(p) + "</span></div>"; }).join("") + "</div></div>";
    }
    var im = (s.t === "title" || s.t === "points" || s.t === "summary") ? safeImg(s.img) : "";
    if (im && s.imgMode === "bg" && s.t === "title") {
      base = base.replace("background:" + th.bg, "background:linear-gradient(rgba(0,0,0,.55),rgba(0,0,0,.55)),url('__IMG__') center/cover").replace("color:" + th.fg, "color:#fff");
    } else if (im) {
      h = '<div style="display:flex;gap:3cqw;align-items:center;position:relative"><div style="flex:1;min-width:0">' + h + '</div><div style="flex:none;width:32cqw;height:32cqw;border-radius:2cqw;overflow:hidden;box-shadow:0 .8cqw 2.4cqw rgba(0,0,0,.35)"><img src="__IMG__" alt="" style="width:100%;height:100%;object-fit:cover;display:block"></div></div>';
    }
    var out = '<div class="slr" style="position:relative;width:100%;padding-top:56.25%;overflow:hidden;border-radius:inherit;--u:1px"><div style="position:absolute;top:0;right:0;bottom:0;left:0;' + base + '">' + deco + h + n + "</div></div>";
    return out.replace(/(-?[\d.]+)cqw/g, "calc($1 * var(--u))").split("__IMG__").join(im);
  }
  function wirePoll(root, s, idx, pid, student) {
    var vid = pid ? pid + "_" + idx : "", key = "slvote_" + vid, voted = false, latest = {};
    try { voted = !!vid && localStorage.getItem(key) !== null; } catch (x) {}
    var rows = root.querySelectorAll("[data-popt]"), tot = root.querySelector("[data-tot]"), showRes = !student || voted;
    function paint() {
      var c = [], sum = 0, i;
      for (i = 0; i < rows.length; i++) { c[i] = +latest["c" + i] || 0; sum += c[i]; }
      rows.forEach(function (r, k) {
        var pct = sum ? Math.round(c[k] * 100 / sum) : 0;
        r.querySelector("[data-bar]").style.width = (showRes ? pct : 0) + "%";
        r.querySelector("[data-n]").textContent = showRes ? c[k] + " · " + pct + "%" : "";
      });
      tot.textContent = showRes ? "إجمالي الأصوات: " + sum + (vid ? "" : " (احفظ العرض ليعمل التصويت)") : "اختر إجابتك للتصويت";
    }
    paint();
    if (vid && cloud()) {
      pres.unsub = window.Cloud.col(VOTES).doc(vid).onSnapshot(function (sn) { latest = sn.exists ? sn.data() : {}; paint(); }, function () {});
    }
    if (student) rows.forEach(function (r) {
      r.addEventListener("click", function () {
        if (voted) return;
        if (!vid || !cloud()) { toast("التصويت غير متاح لهذا العرض", "warning"); return; }
        var k = +r.dataset.popt, d = { pid: pid }; d["c" + k] = window.Cloud.inc(1); voted = true;
        window.Cloud.col(VOTES).doc(vid).set(d, { merge: true }).then(function () {
          try { localStorage.setItem(key, String(k)); } catch (x) {}
          showRes = true; paint(); toast("تم تسجيل صوتك ✓");
        }, function () { voted = false; toast("تعذر تسجيل الصوت", "warning"); });
      });
    });
    var rb = $("slReset");
    if (rb) { rb.style.display = student || !vid ? "none" : ""; rb.onclick = function () { if (window.eduConfirm("تصفير أصوات هذه الشريحة؟")) window.Cloud.col(VOTES).doc(vid).delete().then(function () { latest = {}; paint(); }, function () { toast("تعذر التصفير", "warning"); }); }; }
  }
  function fit(root) {
    (root || document).querySelectorAll(".slr").forEach(function (el) { var w = el.clientWidth; if (w) el.style.setProperty("--u", (w / 100) + "px"); });
  }
  window.addEventListener("resize", function () { fit(); });
  function wireMcq(root, s, th) {
    if (s.t !== "mcq") return;
    var done = false;
    root.querySelectorAll("[data-opt]").forEach(function (el) {
      el.addEventListener("click", function () {
        if (done) return; done = true;
        var pick = +el.dataset.opt, ok = pick === +s.answer;
        root.querySelectorAll("[data-opt]").forEach(function (o) {
          var i = +o.dataset.opt;
          if (i === +s.answer) { o.style.background = "rgba(34,197,94,.55)"; o.style.borderColor = "#4ade80"; }
          else if (i === pick) { o.style.background = "rgba(239,68,68,.55)"; o.style.borderColor = "#f87171"; }
        });
        var w = root.querySelector("[data-why]");
        if (w) w.textContent = (ok ? "🎉 إجابة صحيحة! " : "❌ حاول مرة أخرى في السؤال التالي. ") + (s.why || "");
      });
    });
  }

  // ---------- وضع العرض (ملء الشاشة) ----------
  var pres = null;
  function present(slides, thId, start, opts) {
    closePresent(true);
    opts = opts || {};
    var th = theme(thId), i = Math.max(0, start || 0);
    var ov = document.createElement("div");
    ov.id = "slPresent";
    ov.style.cssText = "position:fixed;top:0;right:0;bottom:0;left:0;z-index:300;background:#000;display:flex;flex-direction:column;align-items:center;justify-content:center;direction:rtl";
    ov.innerHTML = '<div id="slStage" style="width:min(100vw,calc((100vh - 52px) * 16 / 9));border-radius:0;overflow:hidden;box-shadow:0 0 60px rgba(0,0,0,.6)"></div>' +
      '<div style="height:52px;width:100%;display:flex;align-items:center;justify-content:center;gap:10px;color:#fff;font-size:13px;font-weight:700">' +
      '<button type="button" id="slPrev" style="padding:7px 16px;border-radius:12px;background:#ffffff22;color:#fff">▶ السابق</button><span id="slPos" style="min-width:60px;text-align:center;color:#fff;font-weight:800"></span><button type="button" id="slNext" style="padding:7px 16px;border-radius:12px;background:#ffffff22;color:#fff">التالي ◀</button>' +
      '<button type="button" id="slReset" style="display:none;padding:7px 12px;border-radius:12px;background:#ffffff22;color:#fff">تصفير</button><button type="button" id="slFs" style="padding:7px 12px;border-radius:12px;background:#ffffff22;color:#fff" title="ملء الشاشة">⛶</button><button type="button" id="slX" style="padding:7px 12px;border-radius:12px;background:#ef444488;color:#fff">✕</button></div>';
    document.body.appendChild(ov);
    document.documentElement.style.overflow = "hidden";
    function show() {
      var stage = $("slStage"); stage.innerHTML = slideHtml(slides[i], th, true, i); fit(stage);
      if (pres.unsub) { pres.unsub(); pres.unsub = null; }
      var rb = $("slReset"); if (rb) rb.style.display = "none";
      wireMcq(stage, slides[i], th);
      if (slides[i].t === "poll") wirePoll(stage, slides[i], i, opts.pid || "", !!opts.student);
      $("slPos").textContent = (i + 1) + " / " + slides.length;
    }
    function go(d) { var n = i + d; if (n < 0 || n >= slides.length) return; i = n; show(); }
    function key(ev) {
      if (ev.key === "Escape") { if (!document.fullscreenElement) closePresent(); return; }
      if (ev.key === "ArrowLeft" || ev.key === "PageDown" || ev.key === " " || ev.key === "Enter") { ev.preventDefault(); go(1); }
      else if (ev.key === "ArrowRight" || ev.key === "PageUp" || ev.key === "Backspace") { ev.preventDefault(); go(-1); }
    }
    document.addEventListener("keydown", key);
    $("slNext").onclick = function () { go(1); }; $("slPrev").onclick = function () { go(-1); };
    $("slX").onclick = function () { closePresent(); };
    $("slFs").onclick = function () { try { if (document.fullscreenElement) document.exitFullscreen(); else ov.requestFullscreen(); } catch (x) {} };
    var sx = null;
    ov.addEventListener("touchstart", function (ev) { sx = ev.touches[0].clientX; }, { passive: true });
    ov.addEventListener("touchend", function (ev) { if (sx == null) return; var dx = ev.changedTouches[0].clientX - sx; sx = null; if (Math.abs(dx) > 50) go(dx < 0 ? 1 : -1); });
    pres = { ov: ov, key: key, student: !!opts.student };
    show();
    if (!opts.student) { try { ov.requestFullscreen && ov.requestFullscreen(); } catch (x) {} }
  }
  function closePresent(silent) {
    if (!pres) return;
    document.removeEventListener("keydown", pres.key); if (pres.unsub) { try { pres.unsub(); } catch (x) {} }
    try { if (document.fullscreenElement) document.exitFullscreen(); } catch (x) {}
    pres.ov.remove(); document.documentElement.style.overflow = "";
    var stu = pres.student; pres = null;
    if (stu && !silent) { location.href = location.pathname; }
  }

  // ---------- التوليد ----------
  function parseJson(txt) {
    var s = String(txt || "").replace(/```json|```/gi, "");
    var a = s.indexOf("{"), b = s.lastIndexOf("}");
    if (a < 0 || b <= a) throw new Error("لم يُرجع الذكاء الاصطناعي نتيجة مفهومة، أعد المحاولة");
    return JSON.parse(s.slice(a, b + 1));
  }
  function normSlide(x) {
    if (!x || typeof x !== "object") return null;
    var t = TYPES[x.t] ? x.t : (x.q ? "mcq" : (x.points ? "points" : "points"));
    var str = function (v, n) { return String(v == null ? "" : v).trim().slice(0, n || 300); };
    if (t === "title") return withImg({ t: t, title: str(x.title, 120), sub: str(x.sub, 160) }, x);
    if (t === "poll") {
      var po = (x.options || []).map(function (v) { return str(v, 100); }).filter(Boolean).slice(0, 5);
      while (po.length < 2) po.push("—");
      return { t: t, q: str(x.q || x.title, 250), options: po };
    }
    if (t === "mcq") {
      var o = (x.options || []).map(function (v) { return str(v, 120); }).filter(Boolean).slice(0, 4);
      while (o.length < 4) o.push("—");
      var a = parseInt(x.answer, 10); if (!(a >= 0 && a < 4)) a = 0;
      return { t: t, q: str(x.q || x.title, 250), options: o, answer: a, why: str(x.why, 250) };
    }
    var pts = (x.points || []).map(function (v) { return str(v, 200); }).filter(Boolean).slice(0, 6);
    return withImg({ t: t, title: str(x.title, 120), points: pts.length ? pts : ["—"] }, x);
  }
  function buildPrompt(n, q, pl) {
    return "أنت مصمّم عروض تعليمية محترف. أنشئ عرضاً تقديمياً تعليمياً" + (st.topic ? " عن: «" + st.topic + "»" : " من المحتوى الموجود في الصور/الملفات المرفقة") +
      ".\nالمرحلة: " + st.grade + (st.subject ? "\nالمادة: " + st.subject : "") + "\nعدد الشرائح: " + n + " تقريباً.\n" +
      "أعد JSON صالحاً فقط، بلا أي شرح قبله أو بعده وبلا علامات ```، بهذا الشكل بالضبط:\n" +
      '{"title":"عنوان العرض","slides":[{"t":"title","title":"","sub":""},{"t":"points","title":"","points":["",""]},{"t":"mcq","q":"","options":["","","",""],"answer":0,"why":"تفسير قصير"},{"t":"poll","q":"","options":["",""]},{"t":"summary","title":"","points":[""]}]}\n' +
      "القواعد: الشريحة الأولى من النوع title والأخيرة summary. كل شريحة points فيها من 3 إلى 5 نقاط قصيرة (أقل من 14 كلمة للنقطة). أدرج " + q + " شرائح من نوع mcq موزعة بين الشرائح، وكل mcq له 4 خيارات وanswer هو رقم الخيار الصحيح (0 إلى 3) مع تفسير." + (pl ? " وأدرج " + pl + " شرائح من نوع poll (تصويت سريع لقياس الرأي أو مدى الفهم بلا إجابة صحيحة، من 2 إلى 4 خيارات قصيرة)." : "") + " اللغة العربية الفصحى المبسّطة المناسبة للمرحلة. المحتوى دقيق ومتدرّج من البسيط إلى الأعمق.";
  }
  function generate() {
    st.topic = $("slTopic").value.trim(); st.grade = $("slGrade").value; st.subject = $("slSubject").value.trim();
    if (!st.topic && !st.attach.length) { toast("اكتب موضوع العرض أو أضف صورة النص", "warning"); return; }
    var n = +$("slCount").value, q = +$("slQ").value, pl = +$("slPoll").value;
    st.theme = st.theme || "ocean";
    var btn = $("slGo"), stat = $("slStat");
    btn.disabled = true; btn.classList.add("opacity-60"); stat.textContent = "⏳ جارٍ تصميم العرض… قد يستغرق حتى دقيقة";
    window.AI.ask(buildPrompt(n, q, pl), st.attach.map(function (f) { return { mime: f.mime, data: f.data }; }), "slides").then(function (txt) {
      var j = parseJson(txt), arr = (j.slides || []).map(normSlide).filter(Boolean);
      if (arr.length < 2) throw new Error("العرض الناتج قصير جداً، أعد المحاولة");
      st.id = ""; st.title = String(j.title || st.topic || "عرض جديد").slice(0, 120); st.slides = arr; st.cur = 0; st.dirty = true;
      stat.textContent = ""; renderEditor(); $("slEditor").scrollIntoView({ behavior: "smooth", block: "start" });
    }).catch(function (err) { stat.textContent = "⚠️ " + (err && err.message ? err.message : "تعذر التوليد"); })
      .then(function () { btn.disabled = false; btn.classList.remove("opacity-60"); });
  }
  function regenSlide() {
    var s = st.slides[st.cur]; if (!s) return;
    var stat = $("slEdStat"); stat.textContent = "⏳ جارٍ إعادة التوليد…";
    var p = "في عرض تعليمي بعنوان «" + st.title + "» للمرحلة " + st.grade + (st.subject ? " (" + st.subject + ")" : "") + "، أعد كتابة هذه الشريحة بصياغة مختلفة ومحتوى جديد قريب منها:\n" + JSON.stringify(s) +
      "\nأعد JSON فقط لشريحة واحدة بنفس الحقول والنوع (t) دون أي شرح.";
    window.AI.ask(p, [], "slides").then(function (txt) {
      var n = normSlide(parseJson(txt)); if (!n) throw new Error("نتيجة غير مفهومة");
      n.t = s.t === "title" || s.t === "mcq" ? s.t : n.t; st.slides[st.cur] = n; st.dirty = true; stat.textContent = ""; renderEditor();
    }).catch(function (err) { stat.textContent = "⚠️ " + (err.message || "تعذر"); });
  }

  // ---------- الحفظ والمشاركة ----------
  function needLogin() {
    if (!cloud()) { toast("الحفظ والمشاركة يحتاجان ربط Firebase", "warning"); return true; }
    if (!uid()) { toast("سجّل الدخول بحساب Google لحفظ العرض", "warning"); if (typeof openGoogleAuthModal === "function") openGoogleAuthModal(); return true; }
    return false;
  }
  function save() {
    if (!st.slides.length) return Promise.resolve();
    if (needLogin()) return Promise.resolve();
    var u = (window.Cloud && window.Cloud.getStudioUser ? window.Cloud.getStudioUser() : window.Cloud.user), id = st.id || ("p" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6));
    var data = { ownerUid: u.uid, ownerEmail: u.email || "", ownerName: u.displayName || "", title: st.title || "عرض بدون عنوان", theme: st.theme, grade: st.grade, subject: st.subject, slides: st.slides, updatedAt: window.Cloud.stamp() };
    if (!st.id) data.createdAt = window.Cloud.stamp();
    return window.Cloud.col(COL).doc(id).set(data, { merge: true }).then(function () {
      st.id = id; st.dirty = false; toast("تم حفظ العرض ✓"); renderEditor(); loadMine();
    }, function (err) { toast(err && err.code === "permission-denied" ? "لا صلاحية: انشر قواعد Firestore الجديدة (انظر الدليل)" : "تعذر الحفظ", "warning"); });
  }
  function link() { return location.origin + location.pathname.replace(/index\.html$/, "") + "?p=" + st.id; }
  function copyLink() {
    var go = function () {
      var l = link();
      if (typeof copyTextToClipboard === "function") copyTextToClipboard(l, "تم نسخ رابط الطلاب 🔗");
      else { try { navigator.clipboard.writeText(l); toast("تم نسخ رابط الطلاب 🔗"); } catch (x) { window.eduPrompt("انسخ الرابط", l); } }
    };
    if (!st.id || st.dirty) save().then(function () { if (st.id) go(); }); else go();
  }
  function loadMine() {
    var box = $("slMine"); if (!box) return;
    if (!cloud() || !uid()) { box.innerHTML = '<p class="text-[11px] text-slate-500">سجّل الدخول لترى عروضك المحفوظة.</p>'; return; }
    window.Cloud.col(COL).where("ownerUid", "==", uid()).get().then(function (snap) {
      var list = snap.docs.map(function (d) { return Object.assign({ id: d.id }, d.data()); });
      list.sort(function (a, b) { return ((b.updatedAt && b.updatedAt.seconds) || 0) - ((a.updatedAt && a.updatedAt.seconds) || 0); });
      box.innerHTML = list.length ? list.map(function (p) {
        return '<div class="flex items-center gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700"><div class="flex-1 min-w-0"><div class="text-xs font-extrabold truncate">' + e(p.title) + '</div><div class="text-[10px] text-slate-500">' + (p.slides || []).length + ' شريحة · ' + e(p.grade || "") + '</div></div>' +
          '<button type="button" data-open="' + p.id + '" class="px-3 py-1.5 rounded-lg bg-brand-600 text-white text-[11px] font-bold">فتح</button><button type="button" data-del="' + p.id + '" class="px-2.5 py-1.5 rounded-lg bg-rose-600 text-white text-[11px] font-bold">حذف</button></div>';
      }).join("") : '<p class="text-[11px] text-slate-500">لا عروض محفوظة بعد.</p>';
      box._list = list;
    }, function () { box.innerHTML = '<p class="text-[11px] text-rose-600">تعذر تحميل العروض (تحقق من نشر قواعد Firestore).</p>'; });
  }
  function openSaved(p) {
    st.id = p.id; st.title = p.title; st.theme = p.theme || "ocean"; st.grade = p.grade || st.grade; st.subject = p.subject || ""; st.slides = (p.slides || []).map(normSlide).filter(Boolean); st.cur = 0; st.dirty = false;
    renderEditor(); $("slEditor").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  // ---------- المحرر ----------
  function renderEditor() {
    var box = $("slEditor"); if (!box) return;
    if (!st.slides.length) { box.innerHTML = ""; return; }
    var th = theme(st.theme), s = st.slides[st.cur];
    var thumbs = st.slides.map(function (x, i) {
      var label = x.t === "mcq" ? "❓ " + (x.q || "") : x.t === "poll" ? "📊 " + (x.q || "") : (x.title || "");
      return '<button type="button" data-go="' + i + '" class="shrink-0 w-28 text-right rounded-xl border-2 p-1.5 text-[10px] font-bold leading-tight ' + (i === st.cur ? "border-brand-500 bg-brand-50 dark:bg-slate-700" : "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800") + '"><span class="text-slate-400">' + (i + 1) + '</span> ' + e(label).slice(0, 38) + "</button>";
    }).join("");
    var fields = "";
    if (s.t === "title") {
      fields = '<label class="block text-[11px] font-bold mb-1">العنوان</label><input data-f="title" value="' + e(s.title) + '" class="' + inputCls + '"><label class="block text-[11px] font-bold mt-2 mb-1">العنوان الفرعي</label><input data-f="sub" value="' + e(s.sub) + '" class="' + inputCls + '">';
    } else if (s.t === "poll") {
      fields = '<label class="block text-[11px] font-bold mb-1">سؤال التصويت</label><textarea data-f="q" rows="2" class="' + inputCls + '">' + e(s.q) + '</textarea><label class="block text-[11px] font-bold mt-2 mb-1">الخيارات (كل خيار في سطر، من 2 إلى 5)</label><textarea data-popts rows="5" class="' + inputCls + '">' + e((s.options || []).join("\n")) + '</textarea><p class="text-[10px] text-slate-500 mt-1">يصوّت الطلاب من رابط العرض وتظهر لك النتائج مباشرة أثناء العرض (يلزم حفظ العرض).</p>';
    } else if (s.t === "mcq") {
      fields = '<label class="block text-[11px] font-bold mb-1">السؤال</label><textarea data-f="q" rows="2" class="' + inputCls + '">' + e(s.q) + "</textarea>" +
        (s.options || []).map(function (o, i) { return '<div class="flex items-center gap-2 mt-2"><input type="radio" name="slAns" data-ans="' + i + '" ' + (+s.answer === i ? "checked" : "") + ' title="الإجابة الصحيحة"><input data-opt="' + i + '" value="' + e(o) + '" class="' + inputCls + '"></div>'; }).join("") +
        '<p class="text-[10px] text-slate-500 mt-1">الدائرة المحددة = الإجابة الصحيحة</p><label class="block text-[11px] font-bold mt-2 mb-1">تفسير الإجابة</label><input data-f="why" value="' + e(s.why) + '" class="' + inputCls + '">';
    } else {
      fields = '<label class="block text-[11px] font-bold mb-1">عنوان الشريحة</label><input data-f="title" value="' + e(s.title) + '" class="' + inputCls + '"><label class="block text-[11px] font-bold mt-2 mb-1">النقاط (كل نقطة في سطر)</label><textarea data-pts rows="6" class="' + inputCls + '">' + e((s.points || []).join("\n")) + "</textarea>";
    }
    var btn = "px-3 py-2 rounded-xl text-[11px] font-extrabold ";
    if (s.t === "title" || s.t === "points" || s.t === "summary") {
      fields += '<div class="mt-3 p-2.5 rounded-xl border border-dashed border-slate-300 dark:border-slate-600"><div class="text-[11px] font-black mb-1.5">🖼 صورة الشريحة</div>' +
        (s.img ? '<img src="' + e(s.img) + '" alt="" class="w-28 h-20 object-cover rounded-lg mb-2 border">' : "") +
        '<div class="flex flex-wrap gap-1.5"><label class="px-3 py-2 rounded-xl bg-emerald-600 text-white text-[11px] font-extrabold cursor-pointer">📷 كاميرا<input id="slImgCam" type="file" accept="image/*" capture="environment" class="hidden"></label>' +
        '<label class="px-3 py-2 rounded-xl bg-sky-600 text-white text-[11px] font-extrabold cursor-pointer">🖼 من الجوال<input id="slImgPick" type="file" accept="image/*" class="hidden"></label>' +
        '<button type="button" id="slImgUrl" class="px-3 py-2 rounded-xl bg-slate-600 text-white text-[11px] font-extrabold">🔗 رابط</button>' + (s.img ? '<button type="button" id="slImgDel" class="px-3 py-2 rounded-xl bg-rose-600 text-white text-[11px] font-extrabold">حذف الصورة</button>' : "") + "</div>" +
        (s.img && s.t === "title" ? '<select id="slImgMode" class="' + inputCls + ' mt-2"><option value="side"' + (s.imgMode !== "bg" ? " selected" : "") + '>صورة بجانب العنوان</option><option value="bg"' + (s.imgMode === "bg" ? " selected" : "") + ">صورة خلفية للغلاف</option></select>" : "") + "</div>";
    }
    box.innerHTML = '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700 p-4 sm:p-5 space-y-3 text-right">' +
      '<div class="flex flex-wrap gap-2 items-center"><input id="slTitle" value="' + e(st.title) + '" class="' + inputCls + ' flex-1 min-w-[10rem] !text-sm !font-black" placeholder="عنوان العرض">' +
      '<button type="button" id="slSave" class="' + btn + 'bg-emerald-600 text-white"><i class="fa-solid fa-floppy-disk ml-1"></i>حفظ' + (st.dirty ? " •" : "") + '</button>' +
      '<button type="button" id="slPlay" class="' + btn + 'bg-brand-600 text-white"><i class="fa-solid fa-play ml-1"></i>عرض</button>' +
      '<button type="button" id="slShare" class="' + btn + 'bg-amber-500 text-white"><i class="fa-solid fa-link ml-1"></i>رابط الطلاب</button>' +
      '<button type="button" id="slPin" class="' + btn + 'bg-indigo-600 text-white">📌 انشر في مادة</button>' +
      '<button type="button" id="slPptx" class="' + btn + 'bg-orange-600 text-white"><i class="fa-solid fa-file-powerpoint ml-1"></i>PPTX</button>' +
      '<button type="button" id="slPdf" class="' + btn + 'bg-red-700 text-white"><i class="fa-solid fa-file-pdf ml-1"></i>PDF</button><button type="button" id="slToWs" class="' + btn + 'bg-teal-600 text-white">📝 حوّل لورقة عمل</button><button type="button" id="slToRev" class="' + btn + 'bg-emerald-700 text-white">🧠 للمراجعة الذكية</button><button type="button" id="slToGame" class="' + btn + 'bg-fuchsia-600 text-white">🎮 للعبة صفية</button></div>' +
      '<div class="flex flex-wrap gap-1.5 items-center text-[11px] font-bold"><span>القالب:</span>' + THEMES.map(function (t) { return '<button type="button" data-th="' + t.id + '" class="px-2.5 py-1 rounded-lg border-2 ' + (t.id === st.theme ? "border-brand-500" : "border-transparent") + '" style="background:' + t.bg + ';color:' + t.fg + '">' + t.name + "</button>"; }).join("") + "</div>" +
      '<div class="grid grid-cols-1 lg:grid-cols-5 gap-4"><div class="lg:col-span-3 space-y-2 min-w-0"><div id="slPrev1" class="rounded-2xl overflow-hidden shadow-lg border border-slate-300 dark:border-slate-700">' + slideHtml(s, th, false, st.cur) + '</div>' +
      '<div class="flex gap-2 overflow-x-auto pb-1">' + thumbs + "</div></div>" +
      '<div class="lg:col-span-2 space-y-2 min-w-0"><div class="flex flex-wrap gap-1.5"><button type="button" id="slUp" class="' + btn + 'bg-slate-200 dark:bg-slate-700">⬆</button><button type="button" id="slDown" class="' + btn + 'bg-slate-200 dark:bg-slate-700">⬇</button>' +
      '<button type="button" id="slRegen" class="' + btn + 'bg-purple-600 text-white">🔄 أعد التوليد</button><button type="button" id="slDel" class="' + btn + 'bg-rose-600 text-white">🗑</button></div>' +
      '<div class="flex gap-1.5 items-center"><select id="slAddT" class="' + inputCls + '">' + Object.keys(TYPES).filter(function (k) { return k !== "title"; }).map(function (k) { return '<option value="' + k + '">' + TYPES[k] + "</option>"; }).join("") + '</select><button type="button" id="slAdd" class="' + btn + 'bg-sky-600 text-white whitespace-nowrap">➕ شريحة</button></div>' +
      '<div id="slFields" class="pt-1">' + fields + '</div><div id="slEdStat" class="text-[11px] font-bold text-slate-500"></div></div></div></div>';

    fit(box);
    var cur = st.slides[st.cur];
    function refresh() { $("slPrev1").innerHTML = slideHtml(cur, th, false, st.cur); fit($("slPrev1")); st.dirty = true; var b = $("slSave"); if (b && !/•/.test(b.textContent)) b.innerHTML = '<i class="fa-solid fa-floppy-disk ml-1"></i>حفظ •'; }
    $("slTitle").addEventListener("input", function (ev) { st.title = ev.target.value; st.dirty = true; });
    box.querySelectorAll("[data-f]").forEach(function (el) { el.addEventListener("input", function () { cur[el.dataset.f] = el.value; refresh(); }); });
    box.querySelectorAll("[data-opt]").forEach(function (el) { el.addEventListener("input", function () { cur.options[+el.dataset.opt] = el.value; refresh(); }); });
    box.querySelectorAll("[data-ans]").forEach(function (el) { el.addEventListener("change", function () { cur.answer = +el.dataset.ans; refresh(); }); });
    var pop = box.querySelector("[data-popts]"); if (pop) pop.addEventListener("input", function () { cur.options = pop.value.split("\n").map(function (x) { return x.trim(); }).filter(Boolean).slice(0, 5); refresh(); });
    var pts = box.querySelector("[data-pts]"); if (pts) pts.addEventListener("input", function () { cur.points = pts.value.split("\n").map(function (x) { return x.trim(); }).filter(Boolean); refresh(); });
    box.querySelectorAll("[data-go]").forEach(function (b) { b.addEventListener("click", function () { st.cur = +b.dataset.go; renderEditor(); }); });
    box.querySelectorAll("[data-th]").forEach(function (b) { b.addEventListener("click", function () { st.theme = b.dataset.th; st.dirty = true; renderEditor(); }); });
    var ic = $("slImgCam"), ip = $("slImgPick");
    function pickImg(ev) { var f = ev.target.files && ev.target.files[0]; ev.target.value = ""; if (!f) return; imgFile(f).then(function (d) { var old = /^data:/.test(cur.img || "") ? cur.img.length : 0; if (imgTotal(st.slides) - old + d.length > 700000) { toast("حجم الصور في العرض كبير، احذف صورة أخرى أو استخدم رابطاً", "warning"); return; } cur.img = d; cur.imgMode = cur.imgMode || "side"; st.dirty = true; renderEditor(); }, function () { toast("تعذر قراءة الصورة", "warning"); }); }
    if (ic) ic.onchange = pickImg; if (ip) ip.onchange = pickImg;
    if ($("slImgUrl")) $("slImgUrl").onclick = function () { var u = window.eduPrompt("الصق رابط الصورة (يبدأ بـ https://)"); if (!u) return; var ok = safeImg(u); if (!ok || /^data:/.test(ok)) { toast("رابط غير صالح، يجب أن يبدأ بـ https://", "warning"); return; } cur.img = ok; cur.imgMode = cur.imgMode || "side"; st.dirty = true; renderEditor(); };
    if ($("slImgDel")) $("slImgDel").onclick = function () { delete cur.img; delete cur.imgMode; st.dirty = true; renderEditor(); };
    if ($("slImgMode")) $("slImgMode").onchange = function (ev) { cur.imgMode = ev.target.value; st.dirty = true; renderEditor(); };
    $("slSave").onclick = save; $("slShare").onclick = copyLink; $("slPin").onclick = function () { if (!window.EduPublish) return; var go = function () { if (st.id) window.EduPublish.open({ kind: "other", title: st.title, url: link() }); }; if (!st.id || st.dirty) save().then(go); else go(); }; $("slPptx").onclick = exportPptx; $("slPdf").onclick = exportPdf;
    if ($("slToWs")) $("slToWs").onclick = function () {
      var notes = st.slides.map(function (x) { return (x.title || x.q || "") + "\n" + ((x.points || x.options || []).join(" - ")); }).join("\n\n");
      if (window.EduBridge) window.EduBridge.openTool("worksheetStudio", { topic: st.title || st.topic || "عرض تقديمي", grade: st.grade, subject: st.subject, notes: notes });
    };
    if ($("slToRev")) $("slToRev").onclick = function () {
      var pairs = [];
      st.slides.forEach(function (x) {
        if (x.t === "mcq" && x.q && x.options) pairs.push({ q: x.q, a: x.options[+x.answer || 0] || "" });
        else if (x.title && Array.isArray(x.points) && x.points.length) pairs.push({ q: x.title, a: x.points.join(" • ") });
      });
      if (window.EduBridge) window.EduBridge.toReview(st.title || "شرائح العرض", pairs);
    };
    if ($("slToGame")) $("slToGame").onclick = function () {
      var qs = [];
      st.slides.forEach(function (x) {
        if (x.t === "mcq" && x.q) qs.push({ t: "mcq", q: x.q, options: x.options, answer: +x.answer || 0 });
        else if (x.title && Array.isArray(x.points) && x.points.length) qs.push({ t: "short", q: x.title, answer: x.points[0] });
      });
      if (window.EduGames && window.EduGames.fromWorksheet && qs.length) {
        if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("gamesStudio", true);
        setTimeout(function () { window.EduGames.fromWorksheet({ title: st.title, grade: st.grade, subject: st.subject, sets: { A: qs } }); }, 180);
      } else if (window.EduBridge) {
        window.EduBridge.openTool("gamesStudio", { topic: st.title, grade: st.grade, subject: st.subject });
      }
    };
    $("slPlay").onclick = function () { if (st.dirty && st.id && st.slides.some(function (x) { return x.t === "poll"; })) toast("احفظ العرض أولاً حتى يرى الطلاب آخر تعديلاتك", "warning");
      present(st.slides, st.theme, st.cur, { pid: st.id }); };
    $("slRegen").onclick = regenSlide;
    $("slUp").onclick = function () { if (st.cur > 0) { var a = st.slides; var t = a[st.cur]; a[st.cur] = a[st.cur - 1]; a[st.cur - 1] = t; st.cur--; st.dirty = true; renderEditor(); } };
    $("slDown").onclick = function () { var a = st.slides; if (st.cur < a.length - 1) { var t = a[st.cur]; a[st.cur] = a[st.cur + 1]; a[st.cur + 1] = t; st.cur++; st.dirty = true; renderEditor(); } };
    $("slDel").onclick = function () { if (st.slides.length <= 1) return; if (!window.eduConfirm("حذف هذه الشريحة؟")) return; st.slides.splice(st.cur, 1); st.cur = Math.max(0, st.cur - 1); st.dirty = true; renderEditor(); };
    $("slAdd").onclick = function () {
      var t = $("slAddT").value, n = t === "poll" ? { t: t, q: "ما رأيك؟", options: ["موافق", "غير موافق"] } : t === "mcq" ? { t: t, q: "سؤال جديد؟", options: ["الخيار أ", "الخيار ب", "الخيار ج", "الخيار د"], answer: 0, why: "" } : { t: t, title: "عنوان جديد", points: ["نقطة 1", "نقطة 2"] };
      st.slides.splice(st.cur + 1, 0, n); st.cur++; st.dirty = true; renderEditor();
    };
  }


  // ---------- التصدير: PPTX و PDF ----------
  function loadScript(src) {
    return new Promise(function (res, rej) { var el = document.createElement("script"); el.src = src; el.onload = res; el.onerror = function () { rej(new Error("تعذر تحميل مكتبة التصدير، تحقق من الإنترنت")); }; document.head.appendChild(el); });
  }
  function safeName() { return (st.title || "presentation").replace(/[\\/:*?"<>|]+/g, " ").trim().slice(0, 60) || "presentation"; }
  function exportPptx() {
    if (!st.slides.length) return;
    toast("جارٍ تجهيز ملف PowerPoint…", "success");
    (window.PptxGenJS ? Promise.resolve() : loadScript("https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/dist/pptxgen.bundle.js").catch(function () { return loadScript("https://unpkg.com/pptxgenjs@3.12.0/dist/pptxgen.bundle.js"); }).catch(function () { return loadScript("https://cdnjs.cloudflare.com/ajax/libs/pptxgenjs/3.12.0/pptxgen.bundle.js"); })).then(function () {
      var th = theme(st.theme), P = new window.PptxGenJS(), L = ["أ", "ب", "ج", "د"], font = "Arial", keys = [];
      P.layout = "LAYOUT_16x9"; P.rtlMode = true; P.title = st.title;
      st.slides.forEach(function (s, i) {
        var sl = P.addSlide(); sl.background = { color: th.s };
        sl.addShape(P.ShapeType.ellipse, { x: -0.8, y: -0.8, w: 2.6, h: 2.6, fill: { color: th.a, transparency: 84 }, line: { color: th.a, transparency: 100 } });
        sl.addShape(P.ShapeType.ellipse, { x: 8.0, y: 4.2, w: 3.0, h: 3.0, fill: { color: th.a, transparency: 90 }, line: { color: th.a, transparency: 100 } });
        var tx = function (t, o) { sl.addText(t, Object.assign({ fontFace: font, color: th.f, align: "right", rtlMode: true, valign: "middle", margin: 0 }, o)); };
        var im = (s.t === "title" || s.t === "points" || s.t === "summary") ? safeImg(s.img) : "", bgImg = !!im && s.t === "title" && s.imgMode === "bg", sideImg = !!im && !bgImg;
        var X = sideImg ? 4.1 : 0.7, W = sideImg ? 5.2 : 8.6;
        function putImg(x, y, w, h) { try { sl.addImage(/^data:/.test(im) ? { data: im.replace(/^data:/, ""), x: x, y: y, w: w, h: h } : { path: im, x: x, y: y, w: w, h: h }); } catch (err) {} }
        if (bgImg) { putImg(0, 0, 10, 5.625); sl.addShape(P.ShapeType.rect, { x: 0, y: 0, w: 10, h: 5.625, fill: { color: "000000", transparency: 45 }, line: { color: "000000", transparency: 100 } }); }
        else if (sideImg) putImg(0.5, 1.3, 3.3, 3.3);
        if (s.t === "title") {
          tx(s.title, { x: X, y: 1.4, w: W, h: 1.5, fontSize: sideImg ? 32 : 40, bold: true, align: "center", color: bgImg ? "FFFFFF" : th.f });
          sl.addShape(P.ShapeType.rect, { x: X + W / 2 - 0.8, y: 3.05, w: 1.6, h: 0.08, fill: { color: th.a }, line: { color: th.a } });
          tx(s.sub, { x: X, y: 3.3, w: W, h: 0.8, fontSize: 22, align: "center", color: bgImg ? "FFFFFF" : th.f });
        } else if (s.t === "poll") {
          tx("📊 تصويت", { x: 0.7, y: 0.4, w: 8.6, h: 0.4, fontSize: 16, bold: true, color: th.a });
          tx(s.q, { x: 0.7, y: 0.85, w: 8.6, h: 1.3, fontSize: 28, bold: true, valign: "top" });
          (s.options || []).forEach(function (o, k) {
            var y = 2.3 + k * 0.62;
            sl.addShape(P.ShapeType.roundRect, { x: 0.7, y: y, w: 8.6, h: 0.52, fill: { color: th.f, transparency: 88 }, line: { color: th.f, transparency: 100 }, rectRadius: 0.1 });
            tx(o, { x: 0.9, y: y, w: 8.2, h: 0.52, fontSize: 18, bold: true });
          });
          sl.addNotes("شريحة تصويت: يصوّت الطلاب من رابط العرض على الموقع.");
        } else if (s.t === "mcq") {
          tx("❓ سؤال", { x: 0.7, y: 0.4, w: 8.6, h: 0.4, fontSize: 16, bold: true, color: th.a });
          tx(s.q, { x: 0.7, y: 0.85, w: 8.6, h: 1.3, fontSize: 28, bold: true, valign: "top" });
          (s.options || []).forEach(function (o, k) {
            var x = k % 2 === 0 ? 5.1 : 0.7, y = 2.45 + Math.floor(k / 2) * 1.2;
            sl.addShape(P.ShapeType.roundRect, { x: x, y: y, w: 4.2, h: 1.0, fill: { color: th.f, transparency: 88 }, line: { color: th.f, transparency: 100 }, rectRadius: 0.12 });
            tx(L[k] + ".  " + o, { x: x + 0.15, y: y, w: 3.9, h: 1.0, fontSize: 20, bold: true });
          });
          sl.addNotes("الإجابة الصحيحة: " + L[+s.answer] + " — " + (s.why || ""));
          keys.push((i + 1) + ") " + L[+s.answer] + " — " + (s.q || "") + (s.why ? " (" + s.why + ")" : ""));
        } else {
          tx((s.t === "summary" ? "✅ " : "") + s.title, { x: X, y: 0.4, w: W, h: 0.9, fontSize: sideImg ? 26 : 32, bold: true });
          sl.addShape(P.ShapeType.rect, { x: 8.3, y: 1.35, w: 1.0, h: 0.06, fill: { color: th.a }, line: { color: th.a } });
          sl.addText((s.points || []).map(function (t) { return { text: t, options: { bullet: { code: "25CF" }, breakLine: true, paraSpaceAfter: 12 } }; }), { x: X, y: 1.7, w: W, h: 3.4, fontFace: font, fontSize: sideImg ? 20 : 24, color: th.f, align: "right", rtlMode: true, valign: "top", margin: 0 });
        }
      });
      if (keys.length) {
        var k = P.addSlide(); k.background = { color: th.s };
        k.addText("🗝️ مفتاح الإجابات", { x: 0.7, y: 0.4, w: 8.6, h: 0.9, fontFace: font, fontSize: 30, bold: true, color: th.f, align: "right", rtlMode: true, margin: 0 });
        k.addText(keys.map(function (t) { return { text: t, options: { breakLine: true, paraSpaceAfter: 8 } }; }), { x: 0.7, y: 1.5, w: 8.6, h: 3.6, fontFace: font, fontSize: 16, color: th.f, align: "right", rtlMode: true, valign: "top", margin: 0 });
      }
      return P.writeFile({ fileName: safeName() + ".pptx" });
    }).then(function () { toast("تم تنزيل ملف PowerPoint ✓"); }, function (err) { toast((err && err.message) || "تعذر إنشاء PPTX", "warning"); });
  }
  function exportPdf() {
    if (!st.slides.length) return;
    var th = theme(st.theme), old = $("slPrintFrame"); if (old) old.remove();
    var fr = document.createElement("iframe"); fr.id = "slPrintFrame"; fr.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0";
    document.body.appendChild(fr);
    var d = fr.contentDocument;
    d.open();
    d.write('<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>' + e(safeName()) + '</title><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet"><style>@page{size:297mm 167mm;margin:0}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}html,body{margin:0;padding:0;font-family:"Cairo",Tahoma,sans-serif}.pg{width:297mm;height:167mm;overflow:hidden;page-break-after:always;break-after:page}.slr{--u:2.97mm !important}.pg:last-child{page-break-after:auto;break-after:auto}</style></head><body>' +
      st.slides.map(function (s, i) { return '<div class="pg">' + slideHtml(s, th, false, i) + "</div>"; }).join("") + "</body></html>");
    d.close();
    var fire = function () { try { fr.contentWindow.focus(); fr.contentWindow.print(); } catch (x) { toast("تعذر فتح نافذة الطباعة", "warning"); } };
    var done = false, go = function () { if (done) return; done = true; setTimeout(fire, 400); };
    fr.onload = go; setTimeout(go, 1500);
    toast("اختر «حفظ كملف PDF» من نافذة الطباعة");
  }

  function imgFile(file) {
    return new Promise(function (res, rej) {
      var url = URL.createObjectURL(file), im = new Image();
      im.onload = function () {
        var out = "", sizes = [[800, 0.72], [640, 0.6], [480, 0.55]];
        for (var i = 0; i < sizes.length; i++) {
          var k = Math.min(1, sizes[i][0] / Math.max(im.width, im.height)), c = document.createElement("canvas");
          c.width = Math.max(1, Math.round(im.width * k)); c.height = Math.max(1, Math.round(im.height * k));
          var g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(im, 0, 0, c.width, c.height);
          out = c.toDataURL("image/jpeg", sizes[i][1]); if (out.length < 170000) break;
        }
        URL.revokeObjectURL(url); res(out);
      };
      im.onerror = function () { URL.revokeObjectURL(url); rej(new Error("img")); }; im.src = url;
    });
  }
  // ---------- الصور (كاميرا / معرض) ----------
  function shrink(file) {
    return new Promise(function (res, rej) {
      var url = URL.createObjectURL(file), im = new Image();
      im.onload = function () { var m = 1500, k = Math.min(1, m / Math.max(im.width, im.height)), c = document.createElement("canvas"); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(url); res({ mime: "image/jpeg", data: c.toDataURL("image/jpeg", 0.78).split(",")[1], name: file.name }); };
      im.onerror = function () { URL.revokeObjectURL(url); rej(new Error("img")); }; im.src = url;
    });
  }
  function addFiles(list) {
    var arr = Array.prototype.slice.call(list || []);
    arr.reduce(function (p, f) {
      return p.then(function () {
        if (st.attach.length >= 10) { toast("الحد الأقصى 10 صور", "warning"); return; }
        if (!/^image\//.test(f.type)) {
          if (window.EduSourceCapture) {
            return window.EduSourceCapture.handleFiles([f], {
              onText: function (tx) { var tp = document.getElementById("slTopic"); if (tp) tp.value = (tp.value ? tp.value + "\n\n" : "") + tx.slice(0, 5000); }
            });
          }
          return;
        }
        return shrink(f).then(function (x) { st.attach.push(x); }, function () { toast("تعذر قراءة الصورة", "warning"); });
      });
    }, Promise.resolve()).then(function () {
      $("slThumbs").innerHTML = st.attach.map(function (a, i) { return '<span class="relative inline-block"><img src="data:image/jpeg;base64,' + a.data + '" class="w-14 h-14 object-cover rounded-lg border"><button type="button" data-rm="' + i + '" class="absolute -top-1.5 -left-1.5 w-5 h-5 rounded-full bg-rose-600 text-white text-[10px]">×</button></span>'; }).join("");
    });
  }

  // ---------- بناء القسم ----------
  function opts(arr, sel) { return arr.map(function (x) { return '<option' + (x === sel ? " selected" : "") + ">" + e(x) + "</option>"; }).join(""); }
  function build() {
    if ($("slidesStudio")) return true;
    var anchor = $("teacherTools") || $("aiStudio") || $("generator");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "slidesStudio"; s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4"><div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-rose-600 via-purple-700 to-slate-900 text-white"><div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1"><i class="fa-solid fa-display"></i>مولّد العروض التقديمية</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">اصنع عرضاً تفاعلياً لدرسك بضغطة زر</h2><p class="text-xs text-white/80 mt-1">اكتب الموضوع أو صوّر صفحة الكتاب، عدّل الشرائح، ثم اعرضها بملء الشاشة أو شاركها مع طلابك برابط.</p></div>' +
      '<div class="p-5 sm:p-6 space-y-3 text-right">' +
      '<div><label class="block text-xs font-bold mb-1">موضوع العرض أو النص</label><textarea id="slTopic" rows="3" maxlength="6000" class="' + inputCls + '" placeholder="مثال: الكسور العشرية — أو الصق نص الدرس هنا"></textarea></div>' +
      '<div><div class="flex flex-wrap gap-2"><label class="px-4 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-extrabold cursor-pointer flex items-center gap-2"><i class="fa-solid fa-camera"></i>تصوير صفحة<input id="slCam" type="file" accept="image/*" capture="environment" class="hidden"></label>' +
      '<label class="px-4 py-2.5 rounded-xl bg-sky-600 text-white text-xs font-extrabold cursor-pointer flex items-center gap-2"><i class="fa-solid fa-image"></i>صور من الجوال<input id="slPick" type="file" accept="image/*,application/pdf,.txt,.md" multiple class="hidden"></label><button type="button" id="slPickPreset" class="px-3.5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-extrabold flex items-center gap-1.5"><i class="fa-solid fa-book-open"></i><span>درس من المنهاج</span></button></div><div id="slThumbs" class="flex flex-wrap gap-2 mt-2"></div></div>' +
      '<div class="grid grid-cols-2 sm:grid-cols-3 gap-3"><div class="col-span-2 sm:col-span-1"><label class="block text-xs font-bold mb-1">المرحلة</label><select id="slGrade" class="' + inputCls + '">' + opts(GRADES, st.grade) + '</select></div>' +
      '<div class="col-span-2 sm:col-span-1"><label class="block text-xs font-bold mb-1">المادة</label><input id="slSubject" class="' + inputCls + '" placeholder="رياضيات…"></div>' +
      '<div><label class="block text-xs font-bold mb-1">عدد الشرائح</label><select id="slCount" class="' + inputCls + '"><option>6</option><option selected>8</option><option>10</option><option>12</option></select></div>' +
      '<div><label class="block text-xs font-bold mb-1">أسئلة تفاعلية</label><select id="slQ" class="' + inputCls + '"><option value="0">بدون</option><option value="2" selected>2</option><option value="3">3</option><option value="4">4</option></select></div>' +
      '<div><label class="block text-xs font-bold mb-1">تصويت سريع</label><select id="slPoll" class="' + inputCls + '"><option value="0">بدون</option><option value="1" selected>1</option><option value="2">2</option></select></div></div>' +
      '<div class="flex flex-wrap items-center gap-2"><button id="slGo" type="button" class="px-6 py-3 rounded-xl bg-gradient-to-l from-rose-600 to-purple-600 text-white text-xs font-black shadow-md flex items-center gap-2"><i class="fa-solid fa-wand-magic-sparkles"></i><span>صمّم العرض</span></button><button id="slBlank" type="button" class="px-4 py-3 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-extrabold">عرض فارغ</button><span id="slStat" class="text-[11px] font-bold text-slate-500"></span></div>' +
      '</div></div><div id="slEditor"></div>' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700 p-4 sm:p-5 text-right"><div class="flex items-center justify-between mb-2"><h3 class="text-sm font-black">📁 عروضي المحفوظة</h3><button type="button" id="slReload" class="text-[11px] font-bold text-brand-600">تحديث</button></div><div id="slMine" class="space-y-2"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    $("slGo").onclick = generate;
    $("slBlank").onclick = function () { st.id = ""; st.title = "عرض جديد"; st.topic = ""; st.grade = $("slGrade").value; st.subject = $("slSubject").value.trim(); st.slides = [{ t: "title", title: "عنوان العرض", sub: "اسم المعلم · المادة" }, { t: "points", title: "عنوان الشريحة", points: ["نقطة 1", "نقطة 2", "نقطة 3"] }]; st.cur = 0; st.dirty = true; renderEditor(); };
    if ($("slPickPreset")) $("slPickPreset").onclick = function () {
      if (window.EduSourceCapture) window.EduSourceCapture.openPresets(function (p) {
        if ($("slTopic")) $("slTopic").value = p.title + "\n\n" + (p.notes || "");
        if ($("slSubject")) $("slSubject").value = p.subject || "";
        if ($("slGrade") && p.grade) $("slGrade").value = p.grade;
      });
    };
    ["slCam", "slPick"].forEach(function (id) { $(id).addEventListener("change", function (ev) { addFiles(ev.target.files); ev.target.value = ""; }); });
    $("slThumbs").addEventListener("click", function (ev) { var b = ev.target.closest("[data-rm]"); if (b) { st.attach.splice(+b.dataset.rm, 1); addFiles([]); } });
    $("slReload").onclick = loadMine;
    $("slMine").addEventListener("click", function (ev) {
      var o = ev.target.closest("[data-open]"), d = ev.target.closest("[data-del]"), list = $("slMine")._list || [];
      if (o) { var p = list.filter(function (x) { return x.id === o.dataset.open; })[0]; if (p) openSaved(p); }
      if (d && window.eduConfirm("حذف هذا العرض نهائياً؟")) window.Cloud.col(COL).doc(d.dataset.del).delete().then(function () { if (st.id === d.dataset.del) { st.id = ""; } loadMine(); toast("تم الحذف"); }, function () { toast("تعذر الحذف", "warning"); });
    });
    loadMine();
    if (window.Cloud && window.Cloud.onStatus) { /* تحديث القائمة بعد تسجيل الدخول */  }
    return true;
  }

  // ---------- وضع الطالب: ?p=ID ----------
  function studentView() {
    var m = /[?&]p=([A-Za-z0-9_-]{4,40})/.exec(location.search);
    if (!m) return;
    var tries = 0;
    (function go() {
      if (!window.Cloud || !window.Cloud.enabled) { if (++tries < 30) return setTimeout(go, 300); return; }
      window.Cloud.col(COL).doc(m[1]).get().then(function (d) {
        if (!d.exists) { toast("هذا العرض غير موجود أو حُذف", "warning"); return; }
        var p = d.data(), slides = (p.slides || []).map(normSlide).filter(Boolean);
        if (slides.length) present(slides, p.theme, 0, { student: true, pid: m[1] });
      }, function () { toast("تعذر فتح العرض", "warning"); });
    })();
  }

  window.EduSlides = { present: present, state: st, openId: function (id) { return window.Cloud.col(COL).doc(id).get().then(function (d) { if (d.exists) openSaved(Object.assign({ id: id }, d.data())); }); } };
  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
    studentView();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

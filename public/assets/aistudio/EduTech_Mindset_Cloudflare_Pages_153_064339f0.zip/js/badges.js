/*
 * نظام النقاط والمستويات وشارات الإنجاز التحفيزية للطلاب — EduTech Mindset (الإصدار 44)
 * يمنح الطالب نقاط خبرة (XP) وأوسمة تحفيزية عند مشاهدة الدروس، حل الاختبارات، لعب الألعاب التفاعلية،
 * واستخدام المعلم الذكي والخرائط الذهنية، مع بطاقة إنجاز مصورة (PNG) قابلة للتنزيل والمشاركة.
 */
(function () {
  "use strict";
  var KEY = "edu_xp_state_v1";
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };

  var BADGES = [
    { id: "first_step", ico: "🌱", title: "باحث ناشئ", desc: "استكشاف أول درس أو ملخص في المنصة", xp: 30 },
    { id: "quiz_starter", ico: "📝", title: "مجتهد الاختبارات", desc: "إتمام أول اختبار إلكتروني بنجاح", xp: 50 },
    { id: "sharp_shooter", ico: "🎯", title: "قناص الدرجات", desc: "تحقيق درجة 90% فأكثر في اختبار إلكتروني", xp: 100 },
    { id: "gamer_hero", ico: "🎮", title: "بطل التحديات", desc: "إتمام لعبة تربوية تفاعلية أو مسابقة حية", xp: 60 },
    { id: "mind_master", ico: "🧠", title: "عبقري الخرائط", desc: "توليد خريطة ذهنية أو بطاقات استذكار لدرس", xp: 50 },
    { id: "socratic_thinker", ico: "🤖", title: "محاور ذكي", desc: "محاورة المعلم الخصوصي الذكي لفهم الدرس", xp: 40 },
    { id: "class_member", ico: "🏫", title: "طالب ملتزم", desc: "الانضمام إلى فصل دراسي افتراضي ومتابعة مهامه", xp: 40 },
    { id: "edutech_star", ico: "👑", title: "نجم عقلية التعليم", desc: "الوصول إلى 400 نقطة خبرة (XP) في المنصة", xp: 120 }
  ];

  function load() {
    try {
      var d = JSON.parse(localStorage.getItem(KEY) || "null");
      if (d && typeof d.xp === "number") {
        d.badges = (d.badges && typeof d.badges === "object") ? d.badges : {};
        d.counts = (d.counts && typeof d.counts === "object") ? d.counts : {};
        return d;
      }
    } catch (x) {}
    return { xp: 0, badges: {}, counts: {}, updatedAt: 0 };
  }

  function save(st) {
    st.updatedAt = Date.now();
    try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (x) {}
  }

  function levelOf(xp) {
    var lv = Math.floor((xp || 0) / 100) + 1;
    var titles = ["مبتدئ طموح", "متعلم نشط", "باحث متميز", "مفكر مبدع", "بطل المعرفة", "قائد رقمي", "أسطورة EduTech"];
    return {
      level: lv,
      title: titles[Math.min(titles.length - 1, lv - 1)],
      curXp: (xp || 0) % 100,
      nextXp: 100
    };
  }

  function award(badgeId, bonusXp, silent) {
    var st = load();
    var add = bonusXp || 15;
    st.xp = (st.xp || 0) + add;
    st.counts[badgeId] = (st.counts[badgeId] || 0) + 1;

    var unlockedNow = null;
    var bDef = BADGES.filter(function (b) { return b.id === badgeId; })[0];
    if (bDef && !st.badges[badgeId]) {
      st.badges[badgeId] = Date.now();
      st.xp += bDef.xp;
      unlockedNow = bDef;
    }
    var starDef = BADGES.filter(function (b) { return b.id === "edutech_star"; })[0];
    if (st.xp >= 400 && starDef && !st.badges.edutech_star) {
      st.badges.edutech_star = Date.now();
      st.xp += starDef.xp;
      if (!unlockedNow) unlockedNow = starDef;
    }
    save(st);
    if (unlockedNow && !silent) {
      toast("🏅 وسام جديد: «" + unlockedNow.title + "» " + unlockedNow.ico + " (+" + unlockedNow.xp + " XP)!", "success");
    } else if (!silent && bonusXp) {
      toast("✨ +" + add + " نقطة خبرة (XP)!", "info");
    }
    if (window.EduBoost && window.EduBoost.repaint) {
      try { window.EduBoost.repaint(); } catch (x) {}
    }
    return st;
  }

  function exportBadgeCard() {
    var st = load(), lv = levelOf(st.xp);
    var name = localStorage.getItem("edu_student_name") || (window.Cloud && window.Cloud.user && window.Cloud.user.displayName) || "بطل EduTech Mindset";
    var unlocked = BADGES.filter(function (b) { return !!st.badges[b.id]; });
    var W = 1080, H = 1280, cv = document.createElement("canvas");
    cv.width = W; cv.height = H;
    var ctx = cv.getContext("2d");
    ctx.direction = "rtl"; ctx.textAlign = "center"; ctx.textBaseline = "middle";

    var g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, "#0f172a"); g.addColorStop(0.5, "#1e1b4b"); g.addColorStop(1, "#0369a1");
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = "#f59e0b"; ctx.lineWidth = 6;
    if (ctx.roundRect) { ctx.beginPath(); ctx.roundRect(36, 36, W - 72, H - 72, 36); ctx.stroke(); }

    ctx.fillStyle = "#fde047"; ctx.font = "900 42px Cairo, Tahoma, sans-serif";
    ctx.fillText("🏆 بطاقة إنجاز وأوسمة التعلّم", W / 2, 120);

    ctx.fillStyle = "#fff"; ctx.font = "900 64px Cairo, Tahoma, sans-serif";
    ctx.fillText(String(name).slice(0, 32), W / 2, 220);

    ctx.fillStyle = "#38bdf8"; ctx.font = "800 36px Cairo, Tahoma, sans-serif";
    ctx.fillText("المستوى " + lv.level + " — " + lv.title + " (" + st.xp + " XP)", W / 2, 300);

    // رسم الشبكة للأوسمة
    var cols = 2, startY = 410, rowH = 155;
    BADGES.forEach(function (b, idx) {
      var has = !!st.badges[b.id];
      var col = idx % cols, row = Math.floor(idx / cols);
      var bx = col === 0 ? W * 0.72 : W * 0.28;
      var by = startY + row * rowH;

      ctx.fillStyle = has ? "rgba(16, 185, 129, 0.22)" : "rgba(255, 255, 255, 0.06)";
      ctx.strokeStyle = has ? "#10b981" : "rgba(255, 255, 255, 0.15)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(bx - 210, by - 55, 420, 110, 22);
      else ctx.rect(bx - 210, by - 55, 420, 110);
      ctx.fill(); ctx.stroke();

      ctx.fillStyle = has ? "#fff" : "#94a3b8";
      ctx.font = "900 30px Cairo, Tahoma, sans-serif";
      ctx.fillText(b.ico + " " + b.title + (has ? " ✓" : ""), bx, by - 14);
      ctx.fillStyle = has ? "#a7f3d0" : "#64748b";
      ctx.font = "700 20px Cairo, Tahoma, sans-serif";
      ctx.fillText(b.desc, bx, by + 26);
    });

    ctx.fillStyle = "#cbd5e1"; ctx.font = "700 28px Cairo, Tahoma, sans-serif";
    ctx.fillText("منصة EduTech Mindset | عقلية التعليم والتكنولوجيا — " + unlocked.length + " من " + BADGES.length + " أوسمة", W / 2, H - 90);

    cv.toBlob(function (b) {
      var a = document.createElement("a");
      a.href = URL.createObjectURL(b);
      a.download = "أوسمتي-" + name + ".png";
      document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 700);
    }, "image/png");
  }

  function openModal() {
    if (typeof showModalContent !== "function") return;
    var st = load(), lv = levelOf(st.xp);
    var unlockedCount = Object.keys(st.badges).length;
    var name = localStorage.getItem("edu_student_name") || "";

    var html = '<div class="p-4 shrink-0 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-gradient-to-l from-amber-500/20 to-brand-500/10">' +
      '<h3 class="text-sm font-black">🏅 نقاطي وأوسمة التميّز (' + st.xp + ' XP)</h3>' +
      '<button type="button" class="p-2 text-slate-400" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button></div>' +
      '<div class="p-4 overflow-y-auto flex-1 min-h-0 space-y-4 text-right">' +
      '<div class="rounded-2xl p-4 bg-gradient-to-l from-slate-900 via-indigo-950 to-slate-900 text-white flex flex-wrap items-center justify-between gap-3">' +
      '<div><div class="text-xs text-amber-300 font-extrabold">المستوى ' + lv.level + ' • ' + e(lv.title) + '</div>' +
      '<div class="text-2xl font-black mt-0.5">' + st.xp + ' <span class="text-sm font-bold text-sky-300">نقطة خبرة (XP)</span></div>' +
      '<div class="text-[11px] text-slate-300 mt-1">الأوسمة المفتوحة: ' + unlockedCount + ' من ' + BADGES.length + '</div></div>' +
      '<div class="w-full sm:w-48"><div class="text-[10px] text-slate-300 mb-1 flex justify-between"><span>التقدم للمستوى ' + (lv.level + 1) + '</span><span>' + lv.curXp + '%</span></div>' +
      '<div class="w-full h-3 rounded-full bg-white/15 overflow-hidden"><div class="h-full bg-gradient-to-l from-amber-400 to-emerald-400" style="width:' + lv.curXp + '%"></div></div>' +
      '<button type="button" id="bdgShareBtn" class="mt-2.5 w-full py-1.5 px-3 rounded-xl bg-amber-500 text-slate-950 text-[11px] font-black">📤 تنزيل بطاقة أوسمتي (PNG)</button></div></div>' +
      '<div class="flex gap-2 items-center"><input id="bdgStudentName" value="' + e(name) + '" placeholder="اكتب اسمك ليظهر على بطاقة الأوسمة…" class="flex-1 text-xs font-bold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2">' +
      '<button type="button" id="bdgSaveName" class="px-3.5 py-2 rounded-xl bg-brand-600 text-white text-xs font-bold">حفظ الاسم</button></div>' +
      '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">' +
      BADGES.map(function (b) {
        var has = !!st.badges[b.id];
        return '<div class="p-3 rounded-2xl border flex items-start gap-3 ' + (has ? "border-emerald-400 bg-emerald-50/50 dark:bg-emerald-950/30" : "border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40 opacity-65") + '">' +
          '<div class="text-3xl shrink-0">' + b.ico + '</div>' +
          '<div class="min-w-0 flex-1"><div class="flex items-center justify-between"><span class="text-xs font-black">' + e(b.title) + '</span>' +
          '<span class="text-[10px] font-extrabold px-2 py-0.5 rounded-full ' + (has ? "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300" : "bg-slate-200 dark:bg-slate-700 text-slate-500") + '">' + (has ? "✔ مكتسب" : "+" + b.xp + " XP") + '</span></div>' +
          '<p class="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">' + e(b.desc) + '</p></div></div>';
      }).join("") + '</div></div>';

    showModalContent(html);
    var sn = document.getElementById("bdgSaveName");
    if (sn) sn.onclick = function () {
      var v = document.getElementById("bdgStudentName").value.trim();
      if (v) { try { localStorage.setItem("edu_student_name", v); } catch (x) {} toast("تم حفظ اسمك ✓"); }
    };
    var sb = document.getElementById("bdgShareBtn");
    if (sb) sb.onclick = function () {
      var v = document.getElementById("bdgStudentName").value.trim();
      if (v) { try { localStorage.setItem("edu_student_name", v); } catch (x) {} }
      exportBadgeCard();
    };
  }

  window.EduBadges = {
    award: award,
    open: openModal,
    summary: function () { var s = load(); return { xp: s.xp || 0, level: levelOf(s.xp || 0).level, count: Object.keys(s.badges || {}).length }; }
  };
})();

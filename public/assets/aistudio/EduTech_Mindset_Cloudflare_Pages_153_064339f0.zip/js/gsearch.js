/* البحث الشامل (Ctrl+K أو «/») — أدوات الموقع + مهامي وملاحظاتي + أقسام الصفحة — الإصدار 149 */
(function () {
  "use strict";
  var ID = "eduGS";
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  var CSS = "#" + ID + "{position:fixed;inset:0;z-index:2147482900;background:rgba(2,6,23,.6);backdrop-filter:blur(5px);display:flex;justify-content:center;align-items:flex-start;padding:9vh 12px 12px;font-family:Cairo,Tahoma,sans-serif;direction:rtl}" +
    "#" + ID + " .gs-box{width:100%;max-width:560px;background:#fff;color:#0f172a;border-radius:20px;box-shadow:0 24px 60px rgba(0,0,0,.4);overflow:hidden}html.dark #" + ID + " .gs-box{background:#0f172a;color:#f1f5f9;border:1px solid #334155}" +
    "#" + ID + " input{width:100%;box-sizing:border-box;border:0;border-bottom:1px solid #e2e8f0;padding:16px 18px;font:700 16px Cairo,sans-serif;background:transparent;color:inherit;outline:none}html.dark #" + ID + " input{border-color:#334155}" +
    "#" + ID + " .gs-list{max-height:60vh;overflow:auto;padding:6px}#" + ID + " .gs-h{font:900 11px Cairo,sans-serif;color:#64748b;padding:8px 10px 3px}" +
    "#" + ID + " .gs-i{display:flex;gap:10px;align-items:center;width:100%;border:0;background:transparent;color:inherit;text-align:right;padding:9px 10px;border-radius:12px;cursor:pointer;font:700 13px Cairo,sans-serif}" +
    "#" + ID + " .gs-i:hover,#" + ID + " .gs-i.on{background:#e0f2fe}html.dark #" + ID + " .gs-i:hover,html.dark #" + ID + " .gs-i.on{background:#1e293b}" +
    "#" + ID + " .gs-i small{display:block;font-weight:600;color:#64748b;font-size:11px;margin-top:1px}#" + ID + " .gs-e{padding:22px;text-align:center;color:#64748b;font:700 13px Cairo,sans-serif}" +
    ".gs-hdr{display:inline-flex;align-items:center;gap:4px;padding:6px 9px;border-radius:12px;border:1px solid #cbd5e1;background:#fff;color:#0f172a;font:800 11px Cairo,sans-serif;cursor:pointer}html.dark .gs-hdr{background:#1e293b;color:#fff;border-color:#475569}";
  var items = [], sel = 0;
  function norm(s) { var A = window.EduAssistant; return A && A.norm ? A.norm(s) : String(s || "").toLowerCase(); }
  function close() { var o = document.getElementById(ID); if (o) o.remove(); }
  function sections() {
    var out = [], seen = {};
    document.querySelectorAll("section[id]").forEach(function (sec) {
      var h = sec.querySelector("h1,h2,h3"); var t = h ? h.textContent.replace(/\s+/g, " ").trim() : "";
      if (t && t.length < 70 && !seen[sec.id]) { seen[sec.id] = 1; out.push({ id: sec.id, t: t }); }
    });
    return out;
  }
  function compute(q) {
    var A = window.EduAssistant, g = [], nq = norm(q);
    if (!nq) {
      var rec = (window.EduLauncher && window.EduLauncher.getRecent && window.EduLauncher.getRecent()) || [];
      if (rec.length) g.push({ h: "🕘 آخر ما استخدمته", r: rec.slice(0, 5).map(function (a) { return { ico: a.ico, t: a.title, d: a.desc, go: function () { window.EduLauncher.jump(a.id, true); } }; }) });
      return g;
    }
    var tools = (A && A.search ? A.search(q, 6) : []).map(function (x) { var a = x.a; return { ico: a.ico, t: a.title, d: a.desc, go: function () { window.EduLauncher.jump(a.id, true); } }; });
    if (tools.length) g.push({ h: "🧰 الأدوات", r: tools });
    var secs = sections().filter(function (s) { return norm(s.t).indexOf(nq) !== -1; }).slice(0, 4).map(function (s) { return { ico: "📍", t: s.t, d: "الانتقال إلى القسم", go: function () { var e = document.getElementById(s.id); if (e) e.scrollIntoView({ behavior: "smooth", block: "start" }); } }; });
    if (secs.length) g.push({ h: "📍 أقسام الصفحة", r: secs });
    if (A && A.data) {
      var d = A.data(), mine = [];
      (d.tasks || []).forEach(function (t) { if (norm(t.t).indexOf(nq) !== -1) mine.push({ ico: t.done ? "✅" : "☑️", t: t.t, d: "مهمة", go: function () { A.open("day"); } }); });
      (d.notes || []).forEach(function (n) { if (norm(n.t).indexOf(nq) !== -1) mine.push({ ico: "📝", t: String(n.t).slice(0, 80), d: "ملاحظة", go: function () { A.open("day"); } }); });
      if (mine.length) g.push({ h: "🗂️ مهامي وملاحظاتي", r: mine.slice(0, 6) });
    }
    if (A && A.ask) g.push({ h: "✨ اسأل المساعد", r: [{ ico: "🤖", t: "اسأل «مساعدي»: " + q, d: "إجابة ذكية", go: function () { A.ask(q); } }] });
    return g;
  }
  function paint(q) {
    var list = document.querySelector("#" + ID + " .gs-list"); if (!list) return;
    var groups = compute(q); items = []; sel = 0;
    if (!groups.length) { list.innerHTML = "<div class='gs-e'>اكتب للبحث في الأدوات والأقسام ومهامك وملاحظاتك</div>"; return; }
    var h = "";
    groups.forEach(function (g) { h += "<div class='gs-h'>" + g.h + "</div>"; g.r.forEach(function (r) { h += "<button type='button' class='gs-i' data-i='" + items.length + "'><span style='font-size:20px'>" + esc(r.ico) + "</span><span><b>" + esc(r.t) + "</b>" + (r.d ? "<small>" + esc(String(r.d).slice(0, 90)) + "</small>" : "") + "</span></button>"; items.push(r); }); });
    list.innerHTML = h; mark();
  }
  function mark() { document.querySelectorAll("#" + ID + " .gs-i").forEach(function (b, i) { b.classList.toggle("on", i === sel); if (i === sel) b.scrollIntoView({ block: "nearest" }); }); }
  function run(i) { var r = items[i]; if (!r) return; close(); setTimeout(function () { try { r.go(); } catch (e) {} }, 60); }
  function open() {
    if (document.getElementById(ID)) return close();
    if (!document.getElementById(ID + "Css")) { var st = document.createElement("style"); st.id = ID + "Css"; st.textContent = CSS; document.head.appendChild(st); }
    var o = document.createElement("div"); o.id = ID; o.setAttribute("role", "dialog"); o.setAttribute("aria-label", "بحث شامل");
    o.innerHTML = "<div class='gs-box'><input type='search' placeholder='ابحث: أداة، قسم، مهمة، ملاحظة…' autocomplete='off' aria-label='بحث'><div class='gs-list'></div></div>";
    o.addEventListener("click", function (e) { if (e.target === o) close(); var b = e.target.closest(".gs-i"); if (b) run(+b.getAttribute("data-i")); });
    document.body.appendChild(o);
    var inp = o.querySelector("input"); inp.addEventListener("input", function () { paint(inp.value); });
    inp.addEventListener("keydown", function (e) {
      if (e.key === "ArrowDown") { sel = Math.min(items.length - 1, sel + 1); mark(); e.preventDefault(); }
      else if (e.key === "ArrowUp") { sel = Math.max(0, sel - 1); mark(); e.preventDefault(); }
      else if (e.key === "Enter") { run(sel); e.preventDefault(); }
    });
    paint(""); setTimeout(function () { inp.focus(); }, 30);
  }
  document.addEventListener("keydown", function (e) {
    var t = e.target, typing = t && (/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || t.isContentEditable);
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); open(); }
    else if (e.key === "/" && !typing && !document.getElementById(ID)) { e.preventDefault(); open(); }
    else if (e.key === "Escape") close();
  });
  function hdr() {
    if (document.getElementById("gsHdrBtn")) return true;
    var g = document.getElementById("btnGoogleLoginHeader"); if (!g || !g.parentNode) return false;
    if (!document.getElementById(ID + "Css")) { var st = document.createElement("style"); st.id = ID + "Css"; st.textContent = CSS; document.head.appendChild(st); }
    var b = document.createElement("button"); b.type = "button"; b.id = "gsHdrBtn"; b.className = "gs-hdr"; b.title = "بحث شامل (Ctrl+K)"; b.setAttribute("aria-label", "بحث شامل");
    b.innerHTML = "<i class='fa-solid fa-magnifying-glass'></i><span>بحث</span>"; b.addEventListener("click", open);
    g.parentNode.insertBefore(b, g); return true;
  }
  var n = 0, iv = setInterval(function () { if (hdr() || ++n > 40) clearInterval(iv); }, 500);
  window.EduSearch = { open: open, close: close };
})();

/* وضع توفير البيانات + تنبيه الاتصال — الإصدار 149
 * يُفعَّل تلقائياً عند Save-Data أو اتصال بطيء (2g)، ويمكن للمستخدم تبديله: EduPerf.toggle() أو من «مساعدي ← ⋯». */
(function () {
  "use strict";
  var KEY = "edu_datasaver";
  function toast(m, t) { try { if (typeof showToast === "function") showToast(m, t || "info"); } catch (e) {} }
  function stored() { try { return localStorage.getItem(KEY); } catch (e) { return null; } }
  function auto() { var c = navigator.connection || {}; return !!(c.saveData || /(^|-)2g$/.test(c.effectiveType || "")); }
  function isOn() { var s = stored(); return s === "1" ? true : (s === "0" ? false : auto()); }
  var CSS = "html.edu-save *,html.edu-save *::before,html.edu-save *::after{animation-duration:.001s!important;animation-iteration-count:1!important;transition-duration:.001s!important;scroll-behavior:auto!important}" +
    "html.edu-save [class*='backdrop-blur']{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}" +
    "html.edu-save *{text-shadow:none!important}html.edu-save video[autoplay]{display:none!important}html.edu-save [class*='blur-3xl']{display:none!important}";
  var st = document.createElement("style"); st.textContent = CSS; document.head.appendChild(st);
  function lazyImgs(root) { (root || document).querySelectorAll("img:not([loading])").forEach(function (i) { i.loading = "lazy"; i.decoding = "async"; }); }
  var mo = null;
  function apply() {
    var on = isOn(); document.documentElement.classList.toggle("edu-save", on);
    if (on) { lazyImgs(); if (!mo) { mo = new MutationObserver(function (ms) { ms.forEach(function (m) { m.addedNodes.forEach(function (n) { if (n.nodeType === 1) { if (n.tagName === "IMG") { n.loading = "lazy"; } else lazyImgs(n); } }); }); }); mo.observe(document.documentElement, { childList: true, subtree: true }); } }
    else if (mo) { mo.disconnect(); mo = null; }
  }
  function toggle(force) {
    var next = typeof force === "boolean" ? force : !isOn();
    try { localStorage.setItem(KEY, next ? "1" : "0"); } catch (e) {}
    apply(); toast(next ? "وضع توفير البيانات مفعّل 📉" : "وضع توفير البيانات متوقف", "info"); return next;
  }
  apply();
  window.addEventListener("offline", function () { toast("أنت دون إنترنت — الأدوات الأساسية وبياناتك المحفوظة تعمل 📴", "warning"); });
  window.addEventListener("online", function () { toast("عاد الاتصال ✓", "success"); });
  if (navigator.connection && navigator.connection.addEventListener) navigator.connection.addEventListener("change", function () { if (stored() == null) apply(); });
  window.EduPerf = { toggle: toggle, isOn: isOn };
})();

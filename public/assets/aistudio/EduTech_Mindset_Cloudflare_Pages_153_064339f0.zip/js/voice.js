/*
 * voice.js: استوديو الشخصيات الصوتية العصبية (Neural Multi-Character TTS Studio) — EduTech Mindset (الإصدار 71)
 * المميزات الكبرى:
 * 1) 10 شخصيات عربية فصحى أصيلة ومميزة (ذكور، إناث، راوي قصص، معلم إملاء، طالب وأطفال) بأصوات Neural حقيقية.
 * 2) 8 شخصيات للغة الإنجليزية (US / UK / AU / أطفال) لتدريب النطق والاستماع.
 * 3) وضع الحوار الثنائي والبودكاست: يقرأ المعلم بصوت (الأستاذ حامد) والطالب/الطالبة بصوت (تيم أو سلمى) تلقائياً!
 * 4) شريط القارئ الصوتي العائم (Mini Voice Player Bar) أسفل الشاشة مع إمكانية الإيقاف المؤقت وتغيير الشخصية أثناء الاستماع.
 * 5) حفظ دائم في المتصفح ومزامنة مع السحابة، مع إمكانية تنزيل الملف الصوتي MP3 لأي نص تعليمي.
 */
(function () {
  "use strict";

  var KEY = "edu_voice_v72";
  var synth = ("speechSynthesis" in window) ? window.speechSynthesis : null;
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };

  // ---------- 1) قائمة الشخصيات العربية الفصحى الأصيلة (14 شخصية Neural تتصدرها أصوات الطلبة) ----------
  var AR_PRESETS = [
    {
      id: "ar_student_male",
      name: "👦 الطالب الذكي يزن (صوت طالب فصيح وواضح ومحبب للطلبة — الافتراضي)",
      shortName: "👦 الطالب يزن (فصيح)",
      gender: "male",
      badge: "صوت طالب فصيح ⭐",
      tl: "ar",
      lang: "ar-SA",
      rateMul: 1.02,
      pitchMul: 1.12,
      sample: "أَهْلاً بِكُمْ يَا أَصْدِقَائِي الطُّلَّاب! أَنَا زَمِيلُكُمْ يَزَن، هَيَّا نَتَعَلَّمُ وَنَتَفَوَّقُ مَعاً فِي دُرُوسِنَا اليَوْم."
    },
    {
      id: "ar_student_female",
      name: "👧 الطالبة المتفوقة ليان (صوت طالبة فصيح ومشرق وواضح)",
      shortName: "👧 الطالبة ليان (فصيحة)",
      gender: "female",
      badge: "صوت طالبة فصيحة ⭐",
      tl: "ar",
      lang: "ar-EG",
      rateMul: 1.02,
      pitchMul: 1.10,
      sample: "مَرْحَباً زَمِيلَاتِي وَزُمَلَائِي! مَا أَجْمَلَ أَنْ نَفْهَمَ الدَّرْسَ وَنُجِيبَ عَنِ الأَسْئِلَةِ بِثِقَةٍ وَإِبْدَاع."
    },
    {
      id: "ar_child_boy",
      name: "🧒 البرعم الصغير ريان (صوت طفل فصيح للصفوف الأساسية 1–6)",
      shortName: "🧒 البرعم ريان (طفل)",
      gender: "male",
      badge: "طفل فصيح",
      tl: "ar",
      lang: "ar-JO",
      rateMul: 0.96,
      pitchMul: 1.20,
      sample: "أَنَا أُحِبُّ مَدْرَسَتِي وَأُحِبُّ القِرَاءَةَ بِاللُّغَةِ العَرَبِيَّةِ الفُصْحَى الجَمِيلَة!"
    },
    {
      id: "ar_child_girl",
      name: "👶 البرعمة الصغيرة جنى (صوت طفلة فصيحة للتأسيس والقصص)",
      shortName: "👶 البرعمة جنى (طفلة)",
      gender: "female",
      badge: "طفلة فصيحة",
      tl: "ar",
      lang: "ar-SY",
      rateMul: 0.95,
      pitchMul: 1.18,
      sample: "هَيَّا نَقْرَأُ القِصَّةَ الجَدِيدَةَ وَنَتَعَرَّفُ عَلَى الحُرُوفِ وَالأَرْقَامِ مَعاً!"
    },
    {
      id: "ar_hamed",
      name: "🎙️ الأستاذ حامد (فصحى إذاعية أصيلة — رجل)",
      shortName: "الأستاذ حامد",
      gender: "male",
      badge: "فصحى معيارية أصيلة",
      tl: "ar",
      lang: "ar-SA",
      rateMul: 1.0,
      pitchMul: 1.0,
      sample: "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ، أَهْلاً بِكُمْ فِي مِنَصَّةِ عَقْلِيَّةِ التَّعْلِيمِ وَالتِّكْنُولُوجْيَا مِنْ غَزَّة."
    },
    {
      id: "ar_zariyah",
      name: "👩‍🏫 الأستاذة زارية (فصحى تربوية دافئة — سيدة)",
      shortName: "الأستاذة زارية",
      gender: "female",
      badge: "معلمة فصحى",
      tl: "ar",
      lang: "ar-SA",
      rateMul: 1.0,
      pitchMul: 1.0,
      sample: "مَرْحَباً بِكُمْ أَبْنَائِي الطَّلَبَة فِي دَرْسِنَا الجَدِيد، هَيَّا نَسْتَكْشِفُ مَعاً عَالَمَ المَعْرِفَةِ وَالإِبْدَاع."
    },
    {
      id: "ar_shakir",
      name: "👨‍🏫 الدكتور شاكر (فصحى أكاديمية رصينة — رجل)",
      shortName: "الدكتور شاكر",
      gender: "male",
      badge: "شرح علمي وتوجيهي",
      tl: "ar",
      lang: "ar-EG",
      rateMul: 0.96,
      pitchMul: 0.96,
      sample: "فِي هَذِهِ المُرَاجَعَةِ الشَّامِلَةِ، سَنُحَلِّلُ أَهَمَّ القَوَانِينِ وَالمَفَاهِيمِ العِلْمِيَّةِ بِدِقَّةٍ وَوُضُوح."
    },
    {
      id: "ar_salma",
      name: "🧕 الأستاذة سلمى (فصحى مشرقة وواضحة — سيدة)",
      shortName: "الأستاذة سلمى",
      gender: "female",
      badge: "سرد وشرح سلس",
      tl: "ar",
      lang: "ar-EG",
      rateMul: 1.0,
      pitchMul: 1.04,
      sample: "القِرَاءَةُ هِيَ مِفْتَاحُ العُقُولِ، وَبِالعِلْمِ وَالعَمَلِ نَبْنِي مُسْتَقْبَلاً مُشْرِقاً لِوَطَنِنَا."
    },
    {
      id: "ar_taim",
      name: "🎙️ الأستاذ تيم (فصحى شامية/فلسطينية واضحة — شاب)",
      shortName: "الأستاذ تيم",
      gender: "male",
      badge: "فصحى شامية",
      tl: "ar",
      lang: "ar-JO",
      rateMul: 1.0,
      pitchMul: 1.0,
      sample: "أَهْلاً بِكُمْ يَا أَبْطَال، سَنَخُوضُ اليَوْمَ تَحَدِّياً تَعْلِيمِيّاً مُمْتِعاً يَخْتَبِرُ ذَكَاءَكُمْ وَسُرْعَةَ بَدِيهَتِكُمْ."
    },
    {
      id: "ar_sana",
      name: "🌸 المعلّمة سناء (فصحى شامية هادئة — سيدة)",
      shortName: "المعلّمة سناء",
      gender: "female",
      badge: "فصحى شامية",
      tl: "ar",
      lang: "ar-JO",
      rateMul: 0.96,
      pitchMul: 1.05,
      sample: "أَحْسَنْتُمْ يَا صِغَارِي! لَقَدْ أَنْجَزْتُمْ مَهَمَّةَ اليَوْمِ بِتَفَوُّقٍ وَإِتْقَانٍ كَبِير."
    },
    {
      id: "ar_amjad",
      name: "📖 الحكواتي أمجد (راوي القصص التاريخية والأدبية — رجل)",
      shortName: "الحكواتي أمجد",
      gender: "male",
      badge: "حكواتي القصص",
      tl: "ar",
      lang: "ar-SY",
      rateMul: 0.90,
      pitchMul: 0.94,
      sample: "كَانَ يَا مَا كَانَ فِي قَدِيمِ الزَّمَانِ، مَدِينَةٌ عَرِيقَةٌ عَلَى شَاطِئِ البَحْرِ تَصْنَعُ الأَمَلَ بِالعِلْمِ وَالصُّمُود."
    },
    {
      id: "ar_amany",
      name: "🧸 رفيقة الأطفال أماني (صوت طفولي دافئ للتأسيس 1–4)",
      shortName: "أماني (للأطفال)",
      gender: "female",
      badge: "تأسيس وأطفال",
      tl: "ar",
      lang: "ar-SY",
      rateMul: 0.92,
      pitchMul: 1.12,
      sample: "هَيَّا نَقْرَأُ الحُرُوفَ الجَمِيلَةَ مَعاً: أَلِفٌ أَرْنَب، بَاءٌ بَطَّة، تَاءٌ تُفَّاحَة!"
    },
    {
      id: "ar_fahed",
      name: "✍️ معلّم الإملاء فهد (فصحى متأنية لمخارج الحروف — رجل)",
      shortName: "معلّم الإملاء",
      gender: "male",
      badge: "إملاء وتجويد لغة",
      tl: "ar",
      lang: "ar-KW",
      rateMul: 0.80,
      pitchMul: 0.98,
      sample: "اِسْتَمِعْ جَيِّداً ثُمَّ اكْتُبِ الجُمْلَةَ التَّالِيَةَ بِالتَّشْكِيلِ الصَّحِيح: العِلْمُ يَرْفَعُ بُيُوتاً لَا عِمَادَ لَهَا."
    },
    {
      id: "ar_fatima",
      name: "⚡ المدرّبة فاطمة (فصحى حيوية للملخصات والمسابقات — سيدة)",
      shortName: "المدرّبة فاطمة",
      gender: "female",
      badge: "مسابقات وملخصات",
      tl: "ar",
      lang: "ar-AE",
      rateMul: 1.08,
      pitchMul: 1.04,
      sample: "السُّؤَالُ الأَوَّلُ فِي التَّحَدِّي اليَوْمِي: فَكِّرْ بِسُرْعَةٍ وَاخْتَرِ الإِجَابَةَ الصَّحِيحَةَ قَبْلَ انْتِهَاءِ الوَقْت!"
    }
  ];

  // ---------- 2) قائمة الشخصيات الإنجليزية الدائمة (8 شخصيات Neural) ----------
  var EN_PRESETS = [
    {
      id: "en_andrew",
      name: "🇺🇸 Mr. Andrew (أستاذ أمريكي أكاديمي واضح — Male)",
      shortName: "Mr. Andrew (US)",
      gender: "male",
      badge: "American Male",
      tl: "en-US",
      lang: "en-US",
      rateMul: 1.0,
      pitchMul: 1.0,
      sample: "Welcome to EduTech Mindset. Let's practice clear American English pronunciation and vocabulary together."
    },
    {
      id: "en_aria",
      name: "🇺🇸 Ms. Aria (معلمة أمريكية تفاعلية — Female)",
      shortName: "Ms. Aria (US)",
      gender: "female",
      badge: "American Female",
      tl: "en-US",
      lang: "en-US",
      rateMul: 1.0,
      pitchMul: 1.0,
      sample: "Hello everyone! Today we will learn how to build great sentences and speak English with confidence."
    },
    {
      id: "en_ryan",
      name: "🇬🇧 Prof. Ryan (نطق بريطاني أوكسفورد فصيح — Male)",
      shortName: "Prof. Ryan (UK)",
      gender: "male",
      badge: "British Male",
      tl: "en-GB",
      lang: "en-GB",
      rateMul: 0.96,
      pitchMul: 1.0,
      sample: "Good morning class. Please open your textbooks and listen carefully to the British pronunciation."
    },
    {
      id: "en_sonia",
      name: "🇬🇧 Ms. Sonia (معلمة بريطانية واضحة للمنهاج — Female)",
      shortName: "Ms. Sonia (UK)",
      gender: "female",
      badge: "British Female",
      tl: "en-GB",
      lang: "en-GB",
      rateMul: 0.98,
      pitchMul: 1.02,
      sample: "Reading stories in English is a wonderful way to expand your vocabulary and grammar skills."
    },
    {
      id: "en_ana",
      name: "👧 Little Ana (صوت طفلة لتعليم الأطفال والحروف — Kid)",
      shortName: "Little Ana (Kids)",
      gender: "female",
      badge: "Kids & Phonics",
      tl: "en-US",
      lang: "en-US",
      rateMul: 0.92,
      pitchMul: 1.10,
      sample: "A is for Apple, B is for Book, C is for Cat! Let's sing and learn the alphabet together!"
    },
    {
      id: "en_guy",
      name: "📚 Narrator Guy (راوي القصص ونصوص الاستماع — Male)",
      shortName: "Narrator Guy",
      gender: "male",
      badge: "Story & Exam",
      tl: "en-US",
      lang: "en-US",
      rateMul: 0.90,
      pitchMul: 0.95,
      sample: "Listen carefully to the following passage, then answer the comprehension questions below."
    },
    {
      id: "en_natasha",
      name: "🇦🇺 Ms. Natasha (نطق دولي متأنٍ للإملاء — Female)",
      shortName: "Ms. Natasha",
      gender: "female",
      badge: "Dictation & Spelling",
      tl: "en-AU",
      lang: "en-AU",
      rateMul: 0.82,
      pitchMul: 1.0,
      sample: "Spell the following words carefully: Knowledge, Environment, Technology, Achievement."
    },
    {
      id: "en_william",
      name: "🇦🇺 Coach William (نطق دولي سريع للمحادثة — Male)",
      shortName: "Coach William",
      gender: "male",
      badge: "Fast Fluency",
      tl: "en-AU",
      lang: "en-AU",
      rateMul: 1.06,
      pitchMul: 1.0,
      sample: "Keep practicing every single day! Consistency is the secret to mastering any language."
    }
  ];

  // الحالة المحفوظة دائماً
  var S = {
    ar: "ar_student_male",
    en: "en_andrew",
    rate: 1.0,
    pitch: 1.0,
    preferCloud: true
  };

  // تحويل المعرفات القديمة تلقائياً إلى الشخصيات العصبية الجديدة
  var LEGACY_MAP = {
    "ar_fusha_news": "ar_hamed",
    "ar_fusha_teacher": "ar_shakir",
    "ar_fusha_ustadha": "ar_zariyah",
    "ar_fusha_story": "ar_amjad",
    "ar_fusha_dictation": "ar_fahed",
    "ar_fusha_fast": "ar_fatima",
    "en_us_clear": "en_andrew",
    "en_uk_oxford": "en_ryan",
    "en_us_slow_phonics": "en_ana",
    "en_uk_story": "en_sonia",
    "en_au_fluent": "en_william",
    "en_us_exam": "en_guy"
  };

  function loadSettings() {
    try {
      var raw = localStorage.getItem(KEY) || localStorage.getItem("edu_voice_v70") || localStorage.getItem("edu_voice_v1");
      if (raw) {
        var o = JSON.parse(raw);
        if (o && typeof o === "object") {
          if (o.ar) S.ar = LEGACY_MAP[o.ar] || o.ar;
          if (o.en) S.en = LEGACY_MAP[o.en] || o.en;
          if (typeof o.rate === "number" && !isNaN(o.rate)) S.rate = Math.max(0.5, Math.min(1.6, o.rate));
          if (typeof o.pitch === "number" && !isNaN(o.pitch)) S.pitch = Math.max(0.6, Math.min(1.5, o.pitch));
          if (typeof o.preferCloud === "boolean") S.preferCloud = o.preferCloud;
        }
      }
    } catch (e) {}
    if (!findPresetById("ar", S.ar) && !findDeviceVoice(S.ar)) S.ar = AR_PRESETS[0].id;
    if (!findPresetById("en", S.en) && !findDeviceVoice(S.en)) S.en = EN_PRESETS[0].id;
  }

  function saveSettings() {
    try {
      localStorage.setItem(KEY, JSON.stringify(S));
      localStorage.setItem("edu_voice_v70", JSON.stringify(S));
      localStorage.setItem("edu_voice_v1", JSON.stringify(S));
    } catch (e) {}
  }

  function getDeviceVoices() {
    if (!synth) return [];
    try { return synth.getVoices() || []; } catch (e) { return []; }
  }

  function findDeviceVoice(uri) {
    if (!uri || uri.indexOf("dev:") !== 0) return null;
    var target = uri.slice(4);
    var v = getDeviceVoices();
    for (var i = 0; i < v.length; i++) {
      if (v[i].voiceURI === target || v[i].name === target) return v[i];
    }
    return null;
  }

  function findPresetById(langGroup, id) {
    var list = langGroup === "en" ? EN_PRESETS : AR_PRESETS;
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === id) return list[i];
    }
    return null;
  }

  function getPreset(langGroup, id) {
    return findPresetById(langGroup, id) || (langGroup === "en" ? EN_PRESETS[0] : AR_PRESETS[0]);
  }

  function hasArabic(t) {
    return /[\u0600-\u06FF]/.test(String(t || ""));
  }

  function splitChunks(text, maxLen) {
    var limit = maxLen || 280;
    var t = String(text || "").replace(/\s+/g, " ").trim(), out = [];
    while (t.length) {
      if (t.length <= limit) { out.push(t); break; }
      var cut = Math.max(
        t.lastIndexOf("۔", limit),
        t.lastIndexOf(".", limit),
        t.lastIndexOf("!", limit),
        t.lastIndexOf("؟", limit),
        t.lastIndexOf("?", limit),
        t.lastIndexOf("،", limit),
        t.lastIndexOf(",", limit),
        t.lastIndexOf("؛", limit),
        t.lastIndexOf(" ", limit)
      );
      if (cut < 45) cut = limit;
      out.push(t.slice(0, cut).trim());
      t = t.slice(cut).trim();
    }
    return out.filter(Boolean);
  }

  // ---------- شريط القارئ الصوتي العائم (Floating Reader Bar) ----------
  var currentAudio = null;
  var playToken = 0;
  var lastSpokenText = "";
  var lastSpokenLang = "ar-SA";
  var origSpeak = synth ? synth.speak.bind(synth) : null;
  var origCancel = synth ? synth.cancel.bind(synth) : null;

  function showFloatingReaderBar(activePreset, textSnippet) {
    var bar = $("eduVoiceLiveBar");
    if (!bar) {
      bar = document.createElement("div");
      bar.id = "eduVoiceLiveBar";
      bar.className = "fixed bottom-20 right-3 z-50 max-w-[330px] rounded-2xl bg-slate-900/95 text-white border border-emerald-500/40 shadow-2xl px-3.5 py-2.5 backdrop-blur-md transition-all";
      document.body.appendChild(bar);
    }
    var pName = activePreset ? activePreset.shortName || activePreset.name : "القارئ الفصيح";
    bar.innerHTML =
      '<div class="flex items-center justify-between gap-2">' +
        '<div class="flex items-center gap-2 min-w-0">' +
          '<span class="flex h-2.5 w-2.5 rounded-full bg-emerald-400 animate-ping shrink-0"></span>' +
          '<div class="min-w-0 text-right">' +
            '<div class="text-[11px] font-black text-emerald-300 truncate">🔊 يقرأ الآن: ' + esc(pName) + '</div>' +
            '<div class="text-[10px] text-slate-300 truncate">' + esc(String(textSnippet || "").slice(0, 42)) + '…</div>' +
          '</div>' +
        '</div>' +
        '<div class="flex items-center gap-1 shrink-0">' +
          '<button type="button" id="evBarSwitch" class="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[10px] font-extrabold text-sky-300" title="تغيير الشخصية الصوتية">الشخصية</button>' +
          '<button type="button" id="evBarStop" class="px-2 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-[10px] font-extrabold text-white" title="إيقاف القراءة">⏹</button>' +
        '</div>' +
      '</div>';

    var bStop = $("evBarStop");
    if (bStop) bStop.onclick = stopAll;
    var bSw = $("evBarSwitch");
    if (bSw) bSw.onclick = function () { open(); };
  }

  function hideFloatingReaderBar() {
    var bar = $("eduVoiceLiveBar");
    if (bar) bar.remove();
  }

  function stopAll() {
    playToken++;
    if (currentAudio) {
      try {
        currentAudio.onended = null;
        currentAudio.onerror = null;
        currentAudio.pause();
        currentAudio.src = "";
      } catch (e) {}
      currentAudio = null;
    }
    if (origCancel) {
      try { origCancel(); } catch (e) {}
    }
    hideFloatingReaderBar();
  }

  function tryNativeFallback(text, lang, rate, pitch, onDone) {
    if (!origSpeak) { if (onDone) onDone(); return; }
    try {
      var u = new SpeechSynthesisUtterance(text);
      u.lang = lang || "ar-SA";
      u.rate = Math.max(0.5, Math.min(2.0, rate || 1.0));
      u.pitch = Math.max(0.5, Math.min(2.0, pitch || 1.0));
      var vs = getDeviceVoices();
      var prefix = String(u.lang).slice(0, 2).toLowerCase();
      for (var i = 0; i < vs.length; i++) {
        if (vs[i].lang && vs[i].lang.toLowerCase().indexOf(prefix) === 0) {
          u.voice = vs[i];
          break;
        }
      }
      u.onend = u.onerror = function () { if (onDone) onDone(); };
      origSpeak(u);
    } catch (e) {
      if (onDone) onDone();
    }
  }

  function speakViaCloudOrDevice(text, opts) {
    opts = opts || {};
    var cleanText = String(text || "").replace(/[*#_`~]/g, "").trim();
    if (!cleanText) {
      if (opts.onend) opts.onend();
      return;
    }

    lastSpokenText = cleanText;
    var isAr = opts.lang ? /^ar/i.test(opts.lang) : hasArabic(cleanText);
    lastSpokenLang = isAr ? "ar-SA" : "en-US";

    // دعم تعدد الشخصيات التلقائي في الحوار (مثل بودكاست المعلم الذكي حيث يختلف الـ pitch بين المعلم والطالب)
    var selectedId = opts.voiceId || (isAr ? S.ar : S.en);
    if (!opts.voiceId && isAr && opts.pitch) {
      // في البودكاست والحوار: الطالب يتحدث بصوت (الطالب يزن / الطالبة ليان) والمعلم بصوت (الأستاذ حامد)
      if (opts.pitch > 1.10) {
        selectedId = (S.ar === "ar_student_male") ? "ar_student_female" : "ar_student_male";
      } else if (opts.pitch < 0.95) {
        selectedId = "ar_hamed";
      }
    }

    var devVoice = findDeviceVoice(selectedId);
    if (devVoice && origSpeak) {
      var u = new SpeechSynthesisUtterance(cleanText);
      u.voice = devVoice;
      u.lang = devVoice.lang || (isAr ? "ar-SA" : "en-US");
      u.rate = Math.max(0.4, Math.min(2.0, (opts.rate || 1) * S.rate));
      u.pitch = Math.max(0.4, Math.min(2.0, (opts.pitch || 1) * S.pitch));
      if (opts.onend) u.onend = opts.onend;
      if (opts.onerror) u.onerror = opts.onerror;
      origSpeak(u);
      return;
    }

    var preset = getPreset(isAr ? "ar" : "en", selectedId);
    var finalRate = Math.max(0.5, Math.min(1.75, (opts.rate || 1.0) * S.rate * (preset.rateMul || 1.0)));
    var finalPitch = Math.max(0.5, Math.min(1.75, (opts.pitch || 1.0) * S.pitch * (preset.pitchMul || 1.0)));

    if (!navigator.onLine || !S.preferCloud) {
      var localMatch = getDeviceVoices().filter(function (v) {
        return v.lang && v.lang.toLowerCase().indexOf(isAr ? "ar" : "en") === 0;
      })[0];
      if (localMatch && origSpeak) {
        var u2 = new SpeechSynthesisUtterance(cleanText);
        u2.voice = localMatch;
        u2.lang = localMatch.lang;
        u2.rate = finalRate;
        u2.pitch = finalPitch;
        if (opts.onend) u2.onend = opts.onend;
        origSpeak(u2);
        return;
      }
    }

    var myToken = ++playToken;
    var parts = splitChunks(cleanText, 280);
    var idx = 0;
    showFloatingReaderBar(preset, cleanText);

    function playNextPart() {
      if (myToken !== playToken) return;
      if (idx >= parts.length) {
        hideFloatingReaderBar();
        if (opts.onend) opts.onend();
        return;
      }
      var part = parts[idx++];
      var tl = preset.tl || (isAr ? "ar" : "en-US");
      var url = "/api/tts?voice=" + encodeURIComponent(preset.id) +
        "&tl=" + encodeURIComponent(tl) +
        "&rate=" + encodeURIComponent(finalRate.toFixed(2)) +
        "&q=" + encodeURIComponent(part);

      var audio = new Audio(url);
      currentAudio = audio;

      audio.onended = function () {
        if (myToken !== playToken) return;
        playNextPart();
      };
      audio.onerror = function () {
        if (myToken !== playToken) return;
        tryNativeFallback(part, preset.lang, finalRate, finalPitch, playNextPart);
      };
      var playPromise = audio.play();
      if (playPromise && typeof playPromise.catch === "function") {
        playPromise.catch(function () {
          if (myToken !== playToken) return;
          tryNativeFallback(part, preset.lang, finalRate, finalPitch, playNextPart);
        });
      }
    }

    playNextPart();
  }

  if (synth && origSpeak) {
    synth.cancel = function () {
      stopAll();
    };
    synth.speak = function (u) {
      try {
        if (!u || !u.text) return;
        speakViaCloudOrDevice(u.text, {
          lang: u.lang,
          rate: u.rate || 1.0,
          pitch: u.pitch || 1.0,
          onend: u.onend,
          onerror: u.onerror
        });
      } catch (e) {
        origSpeak(u);
      }
    };
  }

  function read(text, lang, voiceOverride, onEnd) {
    stopAll();
    var opts = (typeof lang === "object" && lang !== null) ? lang : {
      lang: lang || (hasArabic(text) ? "ar-SA" : "en-US"),
      voiceId: voiceOverride,
      onend: typeof onEnd === "function" ? onEnd : undefined
    };
    speakViaCloudOrDevice(text, opts);
  }

  // ---------- 3) نافذة استوديو الشخصيات الصوتية والتبديل السريع ----------
  function buildSelectOptions(presets, devList, currentId) {
    var html = '<optgroup label="🌟 الشخصيات الصوتية العصبية المدمجة (تعمل على جميع الأجهزة)">';
    presets.forEach(function (p) {
      html += '<option value="' + esc(p.id) + '"' + (p.id === currentId ? " selected" : "") + '>' + esc(p.name) + '</option>';
    });
    html += '</optgroup>';
    if (devList && devList.length) {
      html += '<optgroup label="📱 أصوات إضافية مثبتة في جهازك">';
      devList.forEach(function (v) {
        var val = "dev:" + v.voiceURI;
        html += '<option value="' + esc(val) + '"' + (val === currentId ? " selected" : "") + '>' + esc(v.name) + ' (' + esc(v.lang) + ')</option>';
      });
      html += '</optgroup>';
    }
    return html;
  }

  function open() {
    if (typeof showModalContent !== "function") return;
    loadSettings();
    var allDev = getDeviceVoices();
    var devAr = allDev.filter(function (v) { return /^ar/i.test(v.lang); });
    var devEn = allDev.filter(function (v) { return /^en/i.test(v.lang); });

    var selCls = "w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-xs sm:text-sm font-extrabold text-slate-800 dark:text-slate-100 outline-none focus:border-brand-500";
    var curArPreset = getPreset("ar", S.ar);

    var html =
      '<div class="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-gradient-to-l from-emerald-900 via-slate-900 to-slate-950 text-white">' +
        '<div>' +
          '<div class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black mb-1">✨ أصوات عصبية طبيعية (Neural Multi-Character Voices)</div>' +
          '<h3 class="text-sm sm:text-base font-black flex items-center gap-2"><span>🎙️</span><span>استوديو الشخصيات الصوتية العربية الفصحى والإنجليزية</span></h3>' +
          '<p class="text-[11px] text-slate-300 mt-0.5">اختر شخصيتك الصوتية المفضلة (معلم، معلمة، حكواتي، طفل، أو مذيع فصيح) — تُحفظ دائماً وتعمل على كل الأجهزة</p>' +
        '</div>' +
        '<button type="button" onclick="closeModal()" class="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-sm font-bold" aria-label="إغلاق">✕</button>' +
      '</div>' +

      '<div class="p-4 sm:p-5 text-right space-y-4 overflow-y-auto max-h-[78dvh]">' +

        // قسم الشخصيات العربية الفصحى الأصيلة
        '<div class="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-2.5">' +
          '<div class="flex items-center justify-between gap-2">' +
            '<label class="text-xs sm:text-sm font-black text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5">' +
              '<span>🕌 شخصيات اللغة العربية الفصحى الأصيلة (ذكور وإناث وأطفال)</span>' +
            '</label>' +
            '<span class="px-2.5 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-extrabold">' + AR_PRESETS.length + ' شخصيات فصحى</span>' +
          '</div>' +
          '<select id="evAr" class="' + selCls + '">' + buildSelectOptions(AR_PRESETS, devAr, S.ar) + '</select>' +
          '<div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-1.5 pt-1" id="evArQuickGrid">' +
            AR_PRESETS.map(function (p) {
              var on = S.ar === p.id;
              return '<button type="button" data-pick-ar="' + esc(p.id) + '" class="p-2.5 rounded-xl border text-right transition flex flex-col justify-between ' +
                (on ? "bg-emerald-600 text-white border-emerald-600 shadow-md" : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-emerald-500") + '">' +
                '<div class="text-[11px] font-black leading-snug">' + esc(p.shortName) + '</div>' +
                '<div class="text-[9px] font-bold opacity-80 mt-0.5">' + esc(p.badge) + '</div>' +
                '<div class="mt-1.5 pt-1 border-t border-current/15 flex items-center justify-between text-[10px] font-black">' +
                  '<span>' + (p.gender === "female" ? "👩 أنثى" : "👨 ذكر") + '</span>' +
                  '<span>' + (on ? "✓ نشط" : "▶ استمع") + '</span>' +
                '</div>' +
              '</button>';
            }).join("") +
          '</div>' +
        '</div>' +

        // قسم الشخصيات الإنجليزية
        '<div class="p-3.5 rounded-2xl bg-sky-500/10 border border-sky-500/30 space-y-2.5">' +
          '<div class="flex items-center justify-between gap-2">' +
            '<label class="text-xs sm:text-sm font-black text-sky-800 dark:text-sky-300 flex items-center gap-1.5">' +
              '<span>🌐 شخصيات اللغة الإنجليزية (American / British / Kids)</span>' +
            '</label>' +
            '<span class="px-2.5 py-0.5 rounded-full bg-sky-600 text-white text-[10px] font-extrabold">' + EN_PRESETS.length + ' شخصيات إنجليزية</span>' +
          '</div>' +
          '<select id="evEn" class="' + selCls + '">' + buildSelectOptions(EN_PRESETS, devEn, S.en) + '</select>' +
          '<div class="grid grid-cols-2 sm:grid-cols-4 gap-1.5 pt-1" id="evEnQuickGrid">' +
            EN_PRESETS.map(function (p) {
              var on = S.en === p.id;
              return '<button type="button" data-pick-en="' + esc(p.id) + '" class="p-2.5 rounded-xl border text-right transition flex flex-col justify-between ' +
                (on ? "bg-sky-600 text-white border-sky-600 shadow-md" : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-sky-500") + '">' +
                '<div class="text-[11px] font-black leading-snug" dir="ltr">' + esc(p.shortName) + '</div>' +
                '<div class="text-[9px] font-bold opacity-80 mt-0.5">' + esc(p.badge) + '</div>' +
                '<div class="mt-1.5 pt-1 border-t border-current/15 flex items-center justify-between text-[10px] font-black">' +
                  '<span>' + (p.gender === "female" ? "👩 Female" : "👨 Male") + '</span>' +
                  '<span>' + (on ? "✓ نشط" : "▶ Play") + '</span>' +
                '</div>' +
              '</button>';
            }).join("") +
          '</div>' +
        '</div>' +

        // التحكم بالسرعة والنبرة
        '<div class="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">' +
          '<div>' +
            '<div class="flex justify-between text-xs font-black mb-1"><span>⚡ سرعة القراءة الإضافية:</span><span id="evRv" class="text-brand-600 dark:text-sky-400">' + S.rate.toFixed(2) + '×</span></div>' +
            '<input id="evRate" type="range" min="0.6" max="1.5" step="0.05" value="' + S.rate + '" class="w-full accent-brand-600">' +
          '</div>' +
          '<div>' +
            '<div class="flex justify-between text-xs font-black mb-1"><span>🎵 نبرة الصوت:</span><span id="evPv" class="text-brand-600 dark:text-sky-400">' + S.pitch.toFixed(2) + '</span></div>' +
            '<input id="evPitch" type="range" min="0.7" max="1.4" step="0.05" value="' + S.pitch + '" class="w-full accent-brand-600">' +
          '</div>' +
        '</div>' +

        // صندوق التجربة وتنزيل ملف الصوت MP3
        '<div class="space-y-2 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900/60">' +
          '<div class="flex flex-wrap items-center justify-between gap-2">' +
            '<label class="text-xs font-black">📝 استوديو القراءة الفورية وتوليد الملف الصوتي (MP3):</label>' +
            '<div class="flex gap-1.5">' +
              '<button type="button" id="evSampleAr" class="px-2.5 py-1 rounded-lg bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-[10px] font-extrabold">نص عربي مشكول</button>' +
              '<button type="button" id="evSampleEn" class="px-2.5 py-1 rounded-lg bg-sky-500/15 text-sky-700 dark:text-sky-300 text-[10px] font-extrabold">English Sample</button>' +
            '</div>' +
          '</div>' +
          '<textarea id="evTxt" rows="2" class="' + selCls + '" placeholder="اكتب أي نص عربي أو إنجليزي للاستماع إليه أو تنزيله كملف صوتي MP3...">' + esc(curArPreset.sample) + '</textarea>' +
          '<div class="flex flex-wrap gap-2 pt-1">' +
            '<button type="button" id="evTestAr" class="flex-1 px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-md transition">▶ استمع بالشخصية العربية</button>' +
            '<button type="button" id="evTestEn" class="flex-1 px-3.5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-black text-xs shadow-md transition">▶ استمع بالشخصية الإنجليزية</button>' +
            '<button type="button" id="evDownloadMp3" class="px-3.5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md transition" title="تنزيل القراءة كملف صوتي MP3 لاستخدامه في عروضك وفيديوهاتك">⬇ تنزيل MP3</button>' +
            '<button type="button" id="evStop" class="px-3.5 py-2.5 rounded-xl bg-rose-500/15 hover:bg-rose-600 text-rose-600 dark:text-rose-300 hover:text-white font-black text-xs transition">⏹ إيقاف</button>' +
          '</div>' +
        '</div>' +

      '</div>';

    showModalContent(html);

    function refreshQuickCards() {
      var arGrid = $("evArQuickGrid");
      if (arGrid) {
        arGrid.querySelectorAll("[data-pick-ar]").forEach(function (b) {
          var id = b.getAttribute("data-pick-ar");
          var on = S.ar === id;
          b.className = "p-2.5 rounded-xl border text-right transition flex flex-col justify-between " +
            (on ? "bg-emerald-600 text-white border-emerald-600 shadow-md" : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-emerald-500");
          var spans = b.querySelectorAll("span");
          if (spans.length) spans[spans.length - 1].textContent = on ? "✓ نشط" : "▶ استمع";
        });
      }
      var enGrid = $("evEnQuickGrid");
      if (enGrid) {
        enGrid.querySelectorAll("[data-pick-en]").forEach(function (b) {
          var id = b.getAttribute("data-pick-en");
          var on = S.en === id;
          b.className = "p-2.5 rounded-xl border text-right transition flex flex-col justify-between " +
            (on ? "bg-sky-600 text-white border-sky-600 shadow-md" : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-sky-500");
          var spans = b.querySelectorAll("span");
          if (spans.length) spans[spans.length - 1].textContent = on ? "✓ نشط" : "▶ Play";
        });
      }
    }

    $("evAr").onchange = function () {
      S.ar = this.value;
      saveSettings();
      refreshQuickCards();
      var p = getPreset("ar", S.ar);
      if (p && p.sample) $("evTxt").value = p.sample;
      toast("تم اختيار شخصية: " + (p ? p.shortName : S.ar) + " ✓");
    };

    $("evEn").onchange = function () {
      S.en = this.value;
      saveSettings();
      refreshQuickCards();
      var p = getPreset("en", S.en);
      if (p && p.sample) $("evTxt").value = p.sample;
      toast("Selected voice: " + (p ? p.shortName : S.en) + " ✓");
    };

    document.querySelectorAll("[data-pick-ar]").forEach(function (b) {
      b.onclick = function () {
        var id = b.getAttribute("data-pick-ar");
        S.ar = id;
        $("evAr").value = id;
        saveSettings();
        refreshQuickCards();
        var p = getPreset("ar", id);
        if (p && p.sample) $("evTxt").value = p.sample;
        read($("evTxt").value, "ar-SA", id);
      };
    });

    document.querySelectorAll("[data-pick-en]").forEach(function (b) {
      b.onclick = function () {
        var id = b.getAttribute("data-pick-en");
        S.en = id;
        $("evEn").value = id;
        saveSettings();
        refreshQuickCards();
        var p = getPreset("en", id);
        if (p && p.sample) $("evTxt").value = p.sample;
        read($("evTxt").value, "en-US", id);
      };
    });

    $("evRate").oninput = function () {
      S.rate = +this.value;
      $("evRv").textContent = S.rate.toFixed(2) + "×";
      saveSettings();
    };
    $("evPitch").oninput = function () {
      S.pitch = +this.value;
      $("evPv").textContent = S.pitch.toFixed(2);
      saveSettings();
    };

    $("evSampleAr").onclick = function () {
      var p = getPreset("ar", S.ar);
      $("evTxt").value = p.sample;
    };
    $("evSampleEn").onclick = function () {
      var p = getPreset("en", S.en);
      $("evTxt").value = p.sample;
    };

    $("evTestAr").onclick = function () {
      var t = $("evTxt").value.trim();
      if (!hasArabic(t)) {
        var p = getPreset("ar", S.ar);
        t = p.sample;
        $("evTxt").value = t;
      }
      read(t, "ar-SA", S.ar);
    };

    $("evTestEn").onclick = function () {
      var t = $("evTxt").value.trim();
      if (hasArabic(t)) {
        var p = getPreset("en", S.en);
        t = p.sample;
        $("evTxt").value = t;
      }
      read(t, "en-US", S.en);
    };

    $("evDownloadMp3").onclick = function () {
      var t = $("evTxt").value.trim();
      if (!t) { toast("اكتب نصاً أولاً لتنزيله كملف صوتي", "warning"); return; }
      var isAr = hasArabic(t);
      var voiceId = isAr ? S.ar : S.en;
      var preset = getPreset(isAr ? "ar" : "en", voiceId);
      var dlUrl = "/api/tts?voice=" + encodeURIComponent(preset.id) +
        "&tl=" + encodeURIComponent(preset.tl) +
        "&rate=" + encodeURIComponent(S.rate.toFixed(2)) +
        "&q=" + encodeURIComponent(t.slice(0, 350));
      var a = document.createElement("a");
      a.href = dlUrl;
      a.download = "edutech-voice-" + preset.id + ".mp3";
      document.body.appendChild(a);
      a.click();
      a.remove();
      toast("⬇ جارٍ تنزيل الملف الصوتي MP3 بصوت " + preset.shortName + " ✓");
    };

    $("evStop").onclick = stopAll;
  }

  /* زر «اقرأ المحدد» العائم */
  var btn;
  function selBtn() {
    if (btn) return btn;
    btn = document.createElement("button");
    btn.type = "button";
    btn.id = "evSelBtn";
    btn.innerHTML = "🔊 اقرأ المحدد";
    btn.style.cssText = "position:fixed;z-index:70;display:none;padding:8px 15px;border-radius:999px;background:linear-gradient(135deg,#059669,#0284c7);color:#fff;font-weight:900;font-size:12.5px;box-shadow:0 8px 22px rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.25)";
    btn.addEventListener("mousedown", function (e) { e.preventDefault(); });
    btn.addEventListener("click", function () {
      var t = String(window.getSelection()).trim();
      if (t) read(t);
      btn.style.display = "none";
    });
    document.body.appendChild(btn);
    return btn;
  }
  var tm;
  document.addEventListener("selectionchange", function () {
    clearTimeout(tm);
    tm = setTimeout(function () {
      var sel = window.getSelection(), t = sel ? String(sel).trim() : "";
      if (t.length < 3) { if (btn) btn.style.display = "none"; return; }
      try {
        var r = sel.getRangeAt(0).getBoundingClientRect(), b = selBtn();
        b.style.display = "block";
        b.style.top = Math.max(70, r.top - 46) + "px";
        b.style.left = Math.max(8, Math.min(window.innerWidth - 150, r.left)) + "px";
      } catch (e) {}
    }, 250);
  });

  loadSettings();
  try { if (synth) synth.onvoiceschanged = function () {}; } catch (e) {}

  window.EduVoice = {
    open: open,
    read: read,
    stop: stopAll,
    isSpeaking: function () { return !!(currentAudio || (synth && synth.speaking)); },
    arVoices: AR_PRESETS,
    enVoices: EN_PRESETS,
    setVoice: function (langGroup, id) {
      if (langGroup === "en") S.en = id;
      else S.ar = id;
      saveSettings();
    },
    settings: function () { return S; }
  };
})();

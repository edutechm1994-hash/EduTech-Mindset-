/*
 * إضافات المنصة المتقدمة ومركز الإدارة والتطوير الشامل:
 * إدارة الروابط والأيقونات، البطاقات السريعة، الأقسام المخصصة، المشرفون، المستخدمون وسجل الرقابة،
 * النسخ الاحتياطي السحابي والمحلي، المحركات الذكية، وتشخيص النظام المتقدم للمطور.
 * جميع أدوات الإدارة والتطوير مدمجة في أسفل الموقع (#adminDevFooterHub) ولا تظهر سوى للإدارة فقط.
 */
(function () {
  "use strict";

  var ICONS = [
    ["fa-brands fa-youtube", "يوتيوب"], ["fa-brands fa-instagram", "انستغرام"], ["fa-brands fa-telegram", "تيليجرام"],
    ["fa-brands fa-whatsapp", "واتساب"], ["fa-brands fa-tiktok", "تيك توك"], ["fa-brands fa-facebook", "فيسبوك"],
    ["fa-brands fa-x-twitter", "X (تويتر)"], ["fa-brands fa-linkedin", "لينكدإن"], ["fa-brands fa-github", "جيت هب"],
    ["fa-brands fa-snapchat", "سناب شات"], ["fa-brands fa-pinterest", "بنترست"], ["fa-brands fa-discord", "ديسكورد"],
    ["fa-brands fa-google-drive", "جوجل درايف"], ["fa-brands fa-google", "جوجل"], ["fa-brands fa-android", "أندرويد"],
    ["fa-solid fa-globe", "موقع إلكتروني"], ["fa-solid fa-envelope", "بريد إلكتروني"], ["fa-solid fa-phone", "هاتف"],
    ["fa-solid fa-link", "رابط عام"], ["fa-solid fa-book-open", "كتب ومناهج"], ["fa-solid fa-graduation-cap", "تعليم"],
    ["fa-solid fa-chalkboard-user", "معلم"], ["fa-solid fa-laptop-code", "برمجة"], ["fa-solid fa-robot", "ذكاء اصطناعي"],
    ["fa-solid fa-lightbulb", "فكرة"], ["fa-solid fa-star", "نجمة"], ["fa-solid fa-file-pdf", "ملف PDF"],
    ["fa-solid fa-video", "فيديو"], ["fa-solid fa-gamepad", "ألعاب تعليمية"], ["fa-solid fa-calendar-days", "جدول/فعالية"],
    ["fa-solid fa-trophy", "مسابقة"], ["fa-solid fa-users", "مجتمع"], ["fa-solid fa-location-dot", "موقع/عنوان"],
    ["fa-solid fa-heart", "قلب"], ["fa-solid fa-flask", "علوم"], ["fa-solid fa-calculator", "رياضيات"]
  ];
  var COLORS = [
    ["text-brand-500", "أزرق"], ["text-red-500", "أحمر"], ["text-pink-500", "وردي"], ["text-sky-500", "سماوي"],
    ["text-emerald-500", "أخضر"], ["text-amber-500", "ذهبي"], ["text-purple-500", "بنفسجي"], ["text-blue-600", "أزرق غامق"],
    ["text-slate-800 dark:text-white", "رمادي/أسود"]
  ];
  var POST_TYPES = [["video", "🎬 فيديو"], ["prompt", "💡 برومبت"], ["tool", "📎 أداة/قالب"], ["image", "🖼️ إنفوجرافيك"], ["article", "📝 مقال/فكرة"]];

  var DEFAULT_STAGES = ["الابتدائية (الصفوف 1 - 4)", "المتوسطة / الإعدادية (الصفوف 5 - 9)", "الثانوية (الصفوف 10 - 12)", "الجامعية والتعليم المستمر"];
  function getStages() { var s = (appState.stages || []).filter(function (x) { return String(x).trim(); }); return s.length ? s : DEFAULT_STAGES; }
  window.stagesOptions = function (sel) {
    var l = getStages(), found = l.indexOf(sel) !== -1;
    return (found || !sel ? l : l.concat([sel])).map(function (s) { return '<option value="' + esc(s) + '"' + (s === sel ? " selected" : "") + ">" + esc(s) + "</option>"; }).join("");
  };
  var DEFAULT_SUBJECTS = ["تكنولوجيا التعليم والذكاء الاصطناعي", "الرياضيات والمنطق", "العلوم العامة والفيزياء", "اللغة العربية وآدابها", "اللغة الإنجليزية", "الدراسات الاجتماعية والتاريخ", "البرمجة والروبوتيكس"];
  function getSubjects() { var s = (appState.subjects || []).filter(function (x) { return String(x).trim(); }); return s.length ? s : DEFAULT_SUBJECTS; }
  window.getSubjects = getSubjects;
  window.subjectsOptions = function (sel) {
    var l = getSubjects(), found = l.indexOf(sel) !== -1;
    return (found || !sel ? l : l.concat([sel])).map(function (s) { return '<option value="' + esc(s) + '"' + (s === sel ? " selected" : "") + ">" + esc(s) + "</option>"; }).join("");
  };
  function applySubjects() {
    var g = document.getElementById("genSubject");
    if (!g) return;
    var cur = g.value, l = getSubjects(), sig = l.join("|");
    if (g.dataset.sig === sig) return;
    g.dataset.sig = sig;
    g.innerHTML = l.map(function (s) { return '<option value="' + esc(s) + '">' + esc(s) + "</option>"; }).join("");
    g.value = l.indexOf(cur) !== -1 ? cur : l[0];
  }
  function applyStages() {
    var g = document.getElementById("genGrade");
    if (!g) return;
    var cur = g.value, l = getStages();
    var sig = l.join("|");
    if (g.dataset.sig === sig) return;
    g.dataset.sig = sig;
    g.innerHTML = l.map(function (s, i) { return '<option value="' + esc(s) + '">' + esc(s) + "</option>"; }).join("");
    g.value = l.indexOf(cur) !== -1 ? cur : (l[1] || l[0]);
  }

  var modPosts = [];
  var postsReady = false;

  function esc(s) { return escapeHtml(s); }
  function opts(list, sel) {
    var found = list.some(function (x) { return x[0] === sel; });
    var l = found || !sel ? list : list.concat([[sel, sel]]);
    return l.map(function (x) { return '<option value="' + esc(x[0]) + '"' + (x[0] === sel ? " selected" : "") + ">" + esc(x[1]) + "</option>"; }).join("");
  }
  function isAdminNow() { return typeof isSuperAdminUser === "function" && isSuperAdminUser(); }
  function cloudAdmin() { return !!(window.Cloud && window.Cloud.enabled && window.Cloud.isAdmin && isAdminNow()); }
  function canPost() { return !!(window.Cloud && window.Cloud.enabled && (window.Cloud.isMod || cloudAdmin())); }
  var inputCls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-brand-500";

  // ---------- النسخ الاحتياطي السحابي الشامل (للإدارة) ----------
  function downloadCloudBackup() {
    if (!isAdminNow()) { showToast("النسخ الاحتياطي للإدارة فقط 🔒", "warning"); return; }
    if (!window.Cloud || !window.Cloud.enabled || !window.Cloud.col) {
      showToast("النسخة السحابية تتطلب تفعيل الربط السحابي (يمكنك تصدير ملف JSON المحلي)", "warning");
      return;
    }
    var cols = ["site", "items", "ads", "books", "resources", "posts", "games", "classrooms"];
    var out = { app: "EduTech Mindset Cloud Backup", at: new Date().toISOString(), appState: appState, data: {} };
    showToast("⏳ جارٍ تجميع النسخة الاحتياطية السحابية الشاملة…", "info");
    Promise.all(cols.map(function (c) {
      return window.Cloud.col(c).get().then(function (s) {
        out.data[c] = {};
        s.docs.forEach(function (d) { out.data[c][d.id] = d.data(); });
      }, function () { out.data[c] = "تعذر القراءة"; });
    })).then(function () {
      var blob = new Blob([JSON.stringify(out, null, 2)], { type: "application/json" });
      var a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "edutech-cloud-backup-" + new Date().toISOString().slice(0, 10) + ".json";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
      showToast("✓ تم تنزيل النسخة الاحتياطية السحابية الشاملة بنجاح", "success");
    });
  }
  window.EduCloudBackup = downloadCloudBackup;

  // ---------- الأقسام الديناميكية ----------
  function ensureSections() {
    if (document.getElementById("quickLinksSection")) return;
    var lib = document.getElementById("library");
    var social = document.getElementById("social");
    if (!lib || !social) return;
    var q = document.createElement("section");
    q.id = "quickLinksSection";
    q.className = "py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 hidden";
    social.parentNode.insertBefore(q, social);
    var m = document.createElement("section");
    m.id = "modsSection";
    m.className = "py-14 bg-gradient-to-b from-amber-50/40 to-transparent dark:from-slate-900/40 border-t border-slate-200/80 dark:border-slate-800";
    lib.parentNode.insertBefore(m, lib.nextSibling);
    var nav = document.querySelector("header nav");
    if (nav && false) {
      var a = document.createElement("a");
      a.id = "navModsLink";
      a.href = "#modsSection";
      a.className = "px-3 py-2 rounded-lg hover:bg-brand-50 dark:hover:bg-slate-800 hover:text-brand-600 dark:hover:text-brand-400 transition-all flex items-center gap-1.5";
      a.innerHTML = '<i class="fa-solid fa-user-pen text-slate-400"></i>المشرفون';
      nav.insertBefore(a, nav.querySelector('a[href="#social"]'));
    }
    if (nav && false) {
      var ai = document.createElement("a");
      ai.id = "navAiLink"; ai.href = "#aiStudio";
      ai.className = "px-3 py-2 rounded-lg hover:bg-brand-50 dark:hover:bg-slate-800 hover:text-brand-600 dark:hover:text-brand-400 transition-all flex items-center gap-1.5";
      ai.innerHTML = '<i class="fa-solid fa-robot text-slate-400"></i>مساعد ذكي';
      nav.insertBefore(ai, nav.querySelector('a[href="#library"]'));
    }
  }

  function syncAdminButtons() {
    var admin = isAdminNow();
    if (document.body) {
      document.body.classList.toggle("is-super-admin", admin);
    }
  }

  function renderQuickLinks() {
    var sec = document.getElementById("quickLinksSection");
    if (!sec) return;
    var list = appState.quickLinks || [];
    var admin = isAdminNow();
    if (!list.length && !admin) { sec.classList.add("hidden"); return; }
    sec.classList.remove("hidden");
    var cards = list.map(function (c) {
      var has = c.url && c.url.trim();
      var tag = has ? "a" : "div";
      return "<" + tag + (has ? ' href="' + esc(safeUrl(c.url)) + '" target="_blank" rel="noopener"' : "") +
        ' class="group glass-card rounded-2xl p-5 border border-slate-200/90 dark:border-slate-800 hover:border-brand-500 hover:shadow-lg transition-all flex items-start gap-4">' +
        '<div class="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xl shrink-0 group-hover:scale-110 transition-transform ' + esc(c.color || "text-brand-500") + '"><i class="' + esc(c.icon || "fa-solid fa-link") + '"></i></div>' +
        '<div class="min-w-0"><h3 class="font-extrabold text-sm text-slate-900 dark:text-white mb-1">' + esc(c.title) + '</h3>' +
        '<p class="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">' + esc(c.desc || "") + '</p></div></' + tag + ">";
    }).join("");
    sec.innerHTML =
      '<div class="flex items-center justify-between gap-3 mb-6"><div><h2 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">وصول سريع وخدمات المنصة</h2>' +
      '<p class="text-xs text-slate-500 dark:text-slate-400 mt-1">روابط وأدوات مختارة من الإدارة</p></div>' +
      (admin ? '<button type="button" id="btnQuickEdit" class="admin-only-ui px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-extrabold flex items-center gap-1.5"><i class="fa-solid fa-plus"></i>إضافة/تعديل البطاقات</button>' : "") +
      '</div><div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">' +
      (cards || '<div class="col-span-full p-6 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 text-center text-xs text-slate-500">لا توجد بطاقات بعد — أضف أول بطاقة من مركز تطوير الموقع أسفل الصفحة.</div>') + "</div>";
    var be = document.getElementById("btnQuickEdit");
    if (be) be.addEventListener("click", function () { openSiteManager("quick"); });
  }

  // ---------- منصة المشرفين ----------
  function renderMods() {
    var sec = document.getElementById("modsSection");
    if (!sec) return;
    var cloud = !!(window.Cloud && window.Cloud.enabled);
    var me = (typeof getCurrentUser === "function") ? getCurrentUser() : null;
    var posts = modPosts.slice().sort(function (a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)); });
    if (!posts.length && !canPost() && !isAdminNow()) {
      sec.classList.add("hidden");
      sec.style.display = "none";
      return;
    }
    sec.classList.remove("hidden");
    var cards = posts.map(function (p) {
      var mine = me && p.authorEmail === me.email;
      var canEdit = cloudAdmin() || (mine && window.Cloud.isMod);
      var meta = { video: "🎬", prompt: "💡", tool: "📎", image: "🖼️", article: "📝" }[p.type] || "📎";
      var has = p.url && p.url.trim();
      return '<article class="glass-card rounded-2xl border border-slate-200/90 dark:border-slate-800 overflow-hidden flex flex-col">' +
        (p.thumb ? '<img src="' + esc(safeUrl(p.thumb)) + '" alt="" class="w-full h-36 object-cover" loading="lazy">' : "") +
        '<div class="p-4 flex flex-col gap-2 flex-grow"><div class="flex items-center justify-between text-[10px] font-bold text-slate-500"><span>' + meta + " منشور مشرف</span><span>" + esc(formatActTime(p.createdAt)) + "</span></div>" +
        '<h3 class="font-extrabold text-sm text-slate-900 dark:text-white">' + esc(p.title) + "</h3>" +
        '<p class="text-[11px] leading-relaxed text-slate-600 dark:text-slate-300 whitespace-pre-line">' + esc(p.desc || "") + "</p>" +
        '<div class="mt-auto pt-3 flex items-center justify-between gap-2 border-t border-slate-200/70 dark:border-slate-800"><span class="text-[11px] font-bold text-amber-600 dark:text-amber-400 truncate"><i class="fa-solid fa-user-pen ml-1"></i>' + esc(p.authorName || "مشرف") + "</span>" +
        '<div class="flex items-center gap-1.5 shrink-0">' +
        (has ? '<a href="' + esc(safeUrl(p.url)) + '" target="_blank" rel="noopener" class="px-2.5 py-1 rounded-lg bg-brand-600 text-white text-[11px] font-bold">فتح</a>' : "") +
        (canEdit ? '<button type="button" class="btn-mod-edit px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px] font-bold" data-id="' + esc(p.id) + '"><i class="fa-solid fa-pen"></i></button>' +
          '<button type="button" class="btn-mod-del px-2 py-1 rounded-lg bg-rose-500/10 text-rose-500 text-[11px] font-bold" data-id="' + esc(p.id) + '"><i class="fa-solid fa-trash-can"></i></button>' : "") +
        "</div></div></div></article>";
    }).join("");
    var action = "";
    if (canPost()) action = '<button type="button" id="btnModNew" class="px-4 py-2.5 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 text-slate-950 text-xs font-black shadow-md flex items-center gap-1.5"><i class="fa-solid fa-feather-pointed"></i>نشر جديد</button>';
    else if (!cloud) action = "";
    else if (me) action = '<span class="text-[11px] font-bold text-slate-500">النشر هنا للمشرفين المعتمدين من الإدارة</span>';
    else action = '<button type="button" id="btnModLogin" class="px-3.5 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-xs font-bold">دخول المشرفين</button>';
    sec.innerHTML = '<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="flex flex-wrap items-center justify-between gap-3 mb-6"><div><div class="inline-flex items-center gap-1.5 text-xs font-extrabold text-amber-600 dark:text-amber-400 mb-1"><i class="fa-solid fa-user-shield"></i>مساحة المشرفين</div>' +
      '<h2 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">منشورات المشرفين</h2>' +
      '<p class="text-xs text-slate-500 dark:text-slate-400 mt-1">محتوى ينشره مشرفون معتمدون، منفصل عن مكتبة الإدارة الرسمية.</p></div>' + action + "</div>" +
      '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">' +
      (cards || '<div class="col-span-full p-8 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 text-center text-xs text-slate-500">' + (cloud ? (postsReady ? "لا توجد منشورات بعد." : "جارٍ التحميل…") : "تتطلب هذه المساحة تفعيل الربط السحابي.") + "</div>") + "</div></div>";
    var bn = document.getElementById("btnModNew"); if (bn) bn.addEventListener("click", function () { openPostModal(null); });
    var bl = document.getElementById("btnModLogin"); if (bl) bl.addEventListener("click", startGoogleSignIn);
    sec.querySelectorAll(".btn-mod-edit").forEach(function (b) { b.addEventListener("click", function () { openPostModal(b.dataset.id); }); });
    sec.querySelectorAll(".btn-mod-del").forEach(function (b) { b.addEventListener("click", function () { deletePost(b.dataset.id); }); });
  }

  function deletePost(id) {
    if (!window.eduConfirm("حذف هذا المنشور نهائياً؟")) return;
    window.Cloud.deletePost(id).then(function () { showToast("تم حذف المنشور", "info"); })
      .catch(function () { showToast("لا تملك صلاحية حذف هذا المنشور 🔒", "warning"); });
  }

  function openPostModal(id) {
    if (!canPost()) { showToast("النشر هنا للمشرفين المعتمدين فقط 🔒", "warning"); return; }
    var p = id ? modPosts.find(function (x) { return x.id === id; }) : null;
    p = p || { type: "article", title: "", desc: "", url: "", thumb: "" };
    showModalContent(
      '<div class="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50"><h3 class="text-sm font-extrabold">' + (id ? "تعديل منشور" : "نشر جديد كمشرف") + '</h3>' +
      '<button type="button" class="p-2 text-slate-400" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button></div>' +
      '<form id="formPost" class="p-6 space-y-3 overflow-y-auto text-right">' +
      '<select id="pType" class="' + inputCls + '">' + opts(POST_TYPES, p.type) + "</select>" +
      '<input id="pTitle" required maxlength="140" class="' + inputCls + '" placeholder="العنوان *" value="' + esc(p.title) + '">' +
      '<textarea id="pDesc" required rows="4" maxlength="1500" class="' + inputCls + '" placeholder="المحتوى / الوصف *">' + esc(p.desc) + "</textarea>" +
      '<input id="pUrl" dir="ltr" class="' + inputCls + ' text-left" placeholder="رابط (اختياري) https://..." value="' + esc(p.url || "") + '">' +
      '<input type="hidden" id="pThumb" value="' + esc(p.thumb || "") + '">' +
      '<label class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px] font-bold cursor-pointer"><i class="fa-solid fa-image text-emerald-500"></i>صورة (اختياري)<input id="pThumbFile" type="file" accept="image/*" class="hidden"></label>' +
      '<span id="pThumbInfo" class="mr-2 text-[11px] font-bold text-emerald-600">' + (p.thumb ? "✓ توجد صورة" : "") + "</span>" +
      '<div class="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800"><button type="button" class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold" onclick="closeModal()">إلغاء</button>' +
      '<button type="submit" class="px-5 py-2 rounded-xl bg-amber-500 text-slate-950 text-xs font-black">' + (id ? "حفظ" : "نشر") + "</button></div></form>");
    document.getElementById("pThumbFile").addEventListener("change", function (e) {
      var f = e.target.files[0]; if (!f) return;
      compressImageFile(f, 640, 160000).then(function (d) {
        document.getElementById("pThumb").value = d; document.getElementById("pThumbInfo").textContent = "✓ تم رفع الصورة";
      }).catch(function () { showToast("تعذر معالجة الصورة", "warning"); });
    });
    document.getElementById("formPost").addEventListener("submit", function (e) {
      e.preventDefault();
      var u = getCurrentUser();
      var post = {
        id: id || "post-" + Date.now(),
        type: document.getElementById("pType").value,
        title: document.getElementById("pTitle").value.trim(),
        desc: document.getElementById("pDesc").value.trim(),
        url: document.getElementById("pUrl").value.trim(),
        thumb: document.getElementById("pThumb").value,
        authorEmail: p.authorEmail || (u ? u.email : ""),
        authorName: p.authorName || (u ? u.name : "مشرف"),
        createdAt: p.createdAt || new Date().toISOString()
      };
      window.Cloud.savePost(post).then(function () {
        closeModal(); showToast(id ? "تم حفظ التعديل ✓" : "تم النشر ✓", "success");
        if (typeof logActivity === "function") { logActivity((id ? "عدّلت منشوراً: " : "نشرت منشوراً: ") + post.title); saveState(); }
      }).catch(function () { showToast("تعذر النشر: لا تملك صلاحية مشرف 🔒", "warning"); });
    });
  }

  // ---------- الإعلانات والأقسام المخصصة ----------
  var adsList = [];
  var BLOCK_STYLES = [["brand", "أزرق متدرج"], ["amber", "ذهبي"], ["slate", "داكن"], ["light", "فاتح"]];
  var POSITIONS = [["top", "أعلى الصفحة (بعد الواجهة)"], ["mid", "وسط الصفحة (بعد المكتبة)"], ["bottom", "أسفل الصفحة (قبل من نحن)"]];
  var BLOCK_CLS = {
    brand: "bg-gradient-to-l from-brand-700 via-brand-600 to-sky-500 text-white",
    amber: "bg-gradient-to-l from-amber-500 to-orange-500 text-slate-950",
    slate: "bg-slate-900 text-white",
    light: "glass-card border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white"
  };

  function getAds() {
    return (window.Cloud && window.Cloud.enabled) ? adsList : (appState.ads || []);
  }
  function adActive(a) {
    if (a.active === false) return false;
    var today = new Date().toISOString().slice(0, 10);
    if (a.startDate && today < a.startDate) return false;
    if (a.endDate && today > a.endDate) return false;
    return true;
  }
  function ensureSlots() {
    if (document.getElementById("slot-top")) return;
    function mk(id, ref, after) {
      var d = document.createElement("div");
      d.id = id;
      d.className = "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4 empty:hidden";
      if (after) ref.parentNode.insertBefore(d, ref.nextSibling); else ref.parentNode.insertBefore(d, ref);
    }
    var hero = document.getElementById("hero"), lib = document.getElementById("library"), about = document.getElementById("about");
    if (hero) mk("slot-top", hero, true);
    if (lib) mk("slot-mid", lib, true);
    if (about) mk("slot-bottom", about, false);
  }
  function renderSlots() {
    ensureSlots();
    var ads = getAds().filter(adActive);
    var blocks = appState.blocks || [];
    POSITIONS.forEach(function (p) {
      var el = document.getElementById("slot-" + p[0]);
      if (!el) return;
      var html = blocks.filter(function (b) { return (b.position || "top") === p[0]; }).map(function (b) {
        var has = b.btnUrl && b.btnUrl.trim();
        return '<div class="rounded-3xl p-6 sm:p-8 shadow-lg ' + (BLOCK_CLS[b.style] || BLOCK_CLS.brand) + '"><div class="flex flex-col sm:flex-row sm:items-center gap-4">' +
          '<div class="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center text-2xl shrink-0"><i class="' + esc(b.icon || "fa-solid fa-star") + '"></i></div>' +
          '<div class="flex-grow min-w-0"><h3 class="text-lg sm:text-xl font-black mb-1">' + esc(b.title) + '</h3><p class="text-xs sm:text-sm leading-relaxed opacity-90 whitespace-pre-line">' + esc(b.body || "") + "</p></div>" +
          (has ? '<a href="' + esc(safeUrl(b.btnUrl)) + '" target="_blank" rel="noopener" class="shrink-0 px-5 py-2.5 rounded-xl bg-white text-slate-900 text-xs font-black shadow">' + esc(b.btnLabel || "المزيد") + "</a>" : "") +
          "</div></div>";
      }).join("");
      html += ads.filter(function (a) { return (a.placement || "mid") === p[0]; }).map(function (a) {
        var has = a.url && a.url.trim();
        return '<a ' + (has ? 'href="' + esc(safeUrl(a.url)) + '" target="_blank" rel="noopener sponsored"' : "") + ' class="group flex flex-col sm:flex-row items-stretch gap-0 rounded-2xl overflow-hidden glass-card border border-amber-400/40 hover:border-amber-500 shadow-sm hover:shadow-lg transition-all">' +
          (a.image ? '<img src="' + esc(safeUrl(a.image)) + '" alt="" class="w-full sm:w-56 h-36 sm:h-auto object-cover" loading="lazy">' : "") +
          '<div class="p-4 flex-grow min-w-0"><span class="inline-block text-[9px] font-black px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-600 dark:text-amber-400 mb-1.5">إعلان</span>' +
          '<h4 class="font-extrabold text-sm text-slate-900 dark:text-white mb-1">' + esc(a.title) + '</h4><p class="text-[11px] leading-relaxed text-slate-600 dark:text-slate-300">' + esc(a.desc || "") + "</p>" +
          (has ? '<span class="inline-block mt-2 text-[11px] font-extrabold text-brand-600 dark:text-brand-400">اعرف المزيد ←</span>' : "") + "</div></a>";
      }).join("");
      el.innerHTML = html;
      el.className = "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4 " + (html ? "py-6" : "");
    });
  }

  // ---------- مركز الإدارة والتطوير الكامل الموحّد ----------
  function openSiteManager(tab) {
    if (!isAdminNow()) {
      showToast("هذه اللوحة مخصصة للإدارة العليا فقط 🔒", "warning");
      openAdminPinModal(function () { openSiteManager(tab); });
      return;
    }
    var cloud = !!(window.Cloud && window.Cloud.enabled);
    var W = {
      links: JSON.parse(JSON.stringify(appState.links || [])),
      quick: JSON.parse(JSON.stringify(appState.quickLinks || [])),
      blocks: JSON.parse(JSON.stringify(appState.blocks || [])),
      ads: JSON.parse(JSON.stringify(getAds()))
    };
    var annDraft = Object.assign({
      enabled: true,
      badge: "📢 تعميم الإدارة",
      text: "",
      link: "#edtechLabSection",
      btnLabel: "استكشف المختبر"
    }, appState.announcement || {});
    var ai = JSON.parse(JSON.stringify(appState.aiConfig || {}));
    if (window.AIAdmin) ai = window.AIAdmin.clean(ai);
    var theme = JSON.parse(JSON.stringify(appState.themeConfig || (window.DEFAULT_THEME_CONFIG || {})));
    var wel = Object.assign({
      enabled: true,
      title: "أهلاً بك في عقلية التعليم والتكنولوجيا 👋",
      text: "منصة تعليمية من غزة تجمع لك موارد وأدوات ذكية للمعلم والطالب.\nابدأ من المكتبة، أو جرّب أدوات المعلم الذكية.",
      btn: "ابدأ الاستكشاف",
      link: "#library",
      everyVisit: false
    }, appState.welcome || {});
    var stg = getStages().slice(), sbj = getSubjects().slice();
    var current = tab || "links";

    var TABS = [
      ["links", "🔗 الروابط والتواصل"],
      ["quick", "⚡ البطاقات السريعة"],
      ["blocks", "🧩 أقسام مخصصة"],
      ["ads", "📢 إعلانات المكتبة"],
      ["theme", "🎨 المظهر والألوان"],
      ["stages", "🏫 المراحل الدراسية"],
      ["subjects", "📚 المواد الدراسية"],
      ["welcome", "👋 الترحيب"],
      ["mods", "🛡️ المشرفون"],
      ["users", "👥 المستخدمون والرقابة والتعميم"],
      ["ai", "🤖 المحركات الذكية"],
      ["backup", "💾 النسخ الاحتياطي والبيانات"],
      ["diag", "🩺 تشخيص النظام والمطور"]
    ];

    // اختصارات الانتقال السريع لتبويبات الهوية والواجهة في EduHome
    var HOME_JUMP = [
      ["identity", "🖼️ الهوية والصور"],
      ["sections", "📑 ترتيب الأقسام"],
      ["nav", "🧭 القوائم العلوية"],
      ["ads", "🖼️ السلايدر الإعلاني"],
      ["videos", "🎬 الفيديوهات"],
      ["ticker", "📰 الشريط العاجل"],
      ["courses", "🎓 الدورات"],
      ["poster", "🎨 الملصقات"],
      ["audio", "🔊 الصوت"]
    ];

    var LIST = { links: 1, quick: 1, blocks: 1, ads: 1 };
    var NEW = {
      links: function () { return { id: "l-" + Date.now(), i: "fa-solid fa-link", n: "رابط جديد", u: "", color: "text-brand-500", handle: "" }; },
      quick: function () { return { id: "q-" + Date.now(), icon: "fa-solid fa-star", title: "بطاقة جديدة", desc: "", url: "", color: "text-brand-500" }; },
      blocks: function () { return { id: "b-" + Date.now(), icon: "fa-solid fa-bullhorn", title: "عنوان القسم", body: "", btnLabel: "", btnUrl: "", style: "brand", position: "top" }; },
      ads: function () { return { id: "ad-" + Date.now(), title: "عنوان الإعلان", desc: "", url: "", image: "", placement: "mid", startDate: "", endDate: "", active: true }; }
    };
    var ADD_LABEL = { links: "إضافة رابط جديد", quick: "إضافة بطاقة جديدة", blocks: "إضافة قسم مخصص", ads: "إضافة إعلان" };

    function fld(f, v, ph, extra) { return '<input data-f="' + f + '" class="' + inputCls + '" placeholder="' + ph + '" value="' + esc(v || "") + '" ' + (extra || "") + ">"; }
    function ctrls(i, n) {
      return '<div class="flex items-center justify-end gap-1.5 text-[11px] font-bold"><button type="button" data-act="up" class="px-2 py-1 rounded-lg bg-slate-200 dark:bg-slate-700"' + (i === 0 ? " disabled" : "") + '>↑</button>' +
        '<button type="button" data-act="down" class="px-2 py-1 rounded-lg bg-slate-200 dark:bg-slate-700"' + (i === n - 1 ? " disabled" : "") + '>↓</button>' +
        '<button type="button" data-act="del" class="px-2.5 py-1 rounded-lg bg-rose-500/10 text-rose-500">حذف</button></div>';
    }
    function wrap(kind, i, inner) { return '<div class="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-2" data-kind="' + kind + '" data-idx="' + i + '">' + inner + "</div>"; }
    function iconRow(prev, fi, fiv, fc, fcv) {
      return '<div class="flex items-center gap-2"><span class="w-9 h-9 rounded-xl bg-white dark:bg-slate-900 flex items-center justify-center text-lg ' + esc(fcv || "") + '"><i class="' + esc(fiv) + '"></i></span>' +
        '<select data-f="' + fi + '" class="' + inputCls + '">' + opts(ICONS, fiv) + "</select>" + (fc ? '<select data-f="' + fc + '" class="' + inputCls + ' max-w-[120px]">' + opts(COLORS, fcv || "text-brand-500") + "</select>" : "") + "</div>";
    }
    function row(kind, c, i, n) {
      var h = "";
      if (kind === "links") h = iconRow(0, "i", c.i, "color", c.color) + fld("n", c.n, "الاسم") + fld("handle", c.handle, "النص الظاهر (مثال: @edutech)") + fld("u", c.u, "https://...", 'dir="ltr"');
      else if (kind === "quick") h = iconRow(0, "icon", c.icon, "color", c.color) + fld("title", c.title, "العنوان") + fld("desc", c.desc, "وصف قصير") + fld("url", c.url, "https://...", 'dir="ltr"');
      else if (kind === "blocks") h = iconRow(0, "icon", c.icon, null, "") + fld("title", c.title, "عنوان القسم") +
        '<textarea data-f="body" rows="3" class="' + inputCls + '" placeholder="النص">' + esc(c.body || "") + "</textarea>" + fld("btnLabel", c.btnLabel, "نص الزر (اختياري)") + fld("btnUrl", c.btnUrl, "رابط الزر https://...", 'dir="ltr"') +
        '<div class="flex gap-2"><select data-f="style" class="' + inputCls + '">' + opts(BLOCK_STYLES, c.style || "brand") + '</select><select data-f="position" class="' + inputCls + '">' + opts(POSITIONS, c.position || "top") + "</select></div>";
      else h = fld("title", c.title, "عنوان الإعلان") + '<textarea data-f="desc" rows="2" class="' + inputCls + '" placeholder="نص الإعلان">' + esc(c.desc || "") + "</textarea>" + fld("url", c.url, "رابط الإعلان https://...", 'dir="ltr"') +
        '<div class="flex gap-2 items-center"><select data-f="placement" class="' + inputCls + '">' + opts(POSITIONS, c.placement || "mid") + '</select><label class="flex items-center gap-1.5 text-[11px] font-bold shrink-0"><input type="checkbox" data-f="active" ' + (c.active !== false ? "checked" : "") + '>فعّال</label></div>' +
        '<div class="grid grid-cols-2 gap-2"><label class="text-[10px] font-bold">من تاريخ<input type="date" data-f="startDate" class="' + inputCls + '" value="' + esc(c.startDate || "") + '"></label><label class="text-[10px] font-bold">إلى تاريخ<input type="date" data-f="endDate" class="' + inputCls + '" value="' + esc(c.endDate || "") + '"></label></div>' +
        '<div class="flex items-center gap-2">' + (c.image ? '<img src="' + esc(c.image) + '" class="w-16 h-12 object-cover rounded-lg" alt="">' : "") + '<label class="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-[11px] font-bold cursor-pointer">رفع صورة<input type="file" accept="image/*" data-up="image" class="hidden"></label>' + (c.image ? '<button type="button" data-clear="image" class="text-[11px] text-rose-500 font-bold">إزالة الصورة</button>' : "") + "</div>";
      return wrap(kind, i, h + ctrls(i, n));
    }

    function bodyFor() {
      if (LIST[current]) {
        var l = W[current];
        return (current === "ads" ? '<p class="text-[11px] text-slate-500 mb-3">تظهر الإعلانات بوسم «إعلان» في المكان الذي تختاره، ويمكنك تحديد فترة العرض. ' + (cloud ? "" : "(الوضع المحلي: تُحفظ على هذا الجهاز فقط)") + "</p>" : "") +
          '<div class="space-y-3">' + l.map(function (c, i) { return row(current, c, i, l.length); }).join("") + '</div><button type="button" id="mgAdd" class="mt-3 px-4 py-2 rounded-xl bg-brand-600 text-white text-xs font-bold"><i class="fa-solid fa-plus ml-1"></i>' + ADD_LABEL[current] + "</button>";
      }
      if (current === "stages" || current === "subjects") return '<p class="text-[11px] text-slate-500 mb-3">' + (current === "stages" ? "تظهر هذه المراحل" : "تظهر هذه المواد") + ' في «مولّد البرومبت» والملف الشخصي والكتب. عدّل الاسم أو أضف أو احذف أو رتّب.</p><div class="space-y-2">' +
        (current === "stages" ? stg : sbj).map(function (s, i) { return '<div class="flex items-center gap-1.5" data-stg="' + i + '"><input class="' + inputCls + '" data-sv value="' + esc(s) + '"><button type="button" data-sa="up" class="px-2 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-[11px]">↑</button><button type="button" data-sa="down" class="px-2 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-[11px]">↓</button><button type="button" data-sa="del" class="px-2 py-1.5 rounded-lg bg-rose-500/10 text-rose-500 text-[11px] font-bold">حذف</button></div>'; }).join("") +
        '</div><button type="button" id="stgAdd" class="mt-3 px-4 py-2 rounded-xl bg-brand-600 text-white text-xs font-bold"><i class="fa-solid fa-plus ml-1"></i>' + (current === "stages" ? "إضافة مرحلة" : "إضافة مادة") + '</button><button type="button" id="stgReset" class="mt-3 mr-2 px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold">استعادة الافتراضي</button>';
      if (current === "welcome") return '<p class="text-[11px] text-slate-500 mb-3">رسالة ترحيب تظهر للزائر عند دخوله الموقع. استخدم {name} لاسم الزائر بعد تسجيل دخوله.</p>' +
        '<label class="flex items-center gap-2 text-xs font-bold mb-2"><input type="checkbox" id="wlOn" ' + (wel.enabled !== false ? "checked" : "") + '>تفعيل رسالة الترحيب</label>' +
        '<label class="flex items-center gap-2 text-xs font-bold mb-3"><input type="checkbox" id="wlEvery" ' + (wel.everyVisit ? "checked" : "") + '>إظهارها في كل زيارة (وإلا مرة واحدة لكل زائر)</label>' +
        '<input id="wlTitle" class="' + inputCls + ' mb-2" placeholder="العنوان" value="' + esc(wel.title) + '">' +
        '<textarea id="wlText" rows="5" class="' + inputCls + ' mb-2" placeholder="النص">' + esc(wel.text) + '</textarea>' +
        '<input id="wlBtn" class="' + inputCls + ' mb-2" placeholder="نص الزر" value="' + esc(wel.btn) + '">' +
        '<input id="wlLink" dir="ltr" class="' + inputCls + ' text-left" placeholder="رابط الزر (#library أو https://...)" value="' + esc(wel.link) + '">' +
        '<button type="button" id="wlPreview" class="mt-3 px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold">معاينة</button>';
      if (current === "theme") return window.ThemeAdmin ? window.ThemeAdmin.html(theme) : '<p class="text-xs text-rose-500">تعذر تحميل لوحة المظهر (js/theme.js)</p>';
      if (current === "ai") return window.AIAdmin ? window.AIAdmin.html(ai) : '<p class="text-xs text-rose-500">تعذر تحميل لوحة المحركات (js/ai-admin.js)</p>';

      if (current === "users") {
        var auditHtml = (appState.auditLog || []).slice(0, 15).map(function (lg) {
          return '<div class="flex items-center justify-between gap-2 text-[11px] py-1.5 border-b border-slate-200/60 dark:border-slate-800">' +
            '<span class="font-bold text-slate-700 dark:text-slate-200">' + esc(lg.action) + ' <em class="text-brand-500 not-italic">(' + esc(lg.actor) + ')</em></span>' +
            '<span class="text-[10px] text-slate-400 shrink-0">' + esc(lg.time) + '</span></div>';
        }).join("") || '<div class="text-xs text-slate-400 py-3 text-center">لا توجد عمليات مسجلة بعد.</div>';

        return '<div class="space-y-4">' +
          // شريط التعميم العلوي
          '<div class="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/25 space-y-2.5">' +
            '<div class="flex items-center justify-between">' +
              '<h4 class="text-xs font-black text-amber-700 dark:text-amber-300"><i class="fa-solid fa-bullhorn ml-1"></i>شريط تعميم الإدارة العلوي</h4>' +
              '<label class="flex items-center gap-1.5 text-xs font-bold cursor-pointer"><input id="mgAnnOn" type="checkbox" class="w-4 h-4 rounded" ' + (annDraft.enabled !== false ? "checked" : "") + '><span>إظهار الشريط</span></label>' +
            '</div>' +
            '<div class="grid grid-cols-1 sm:grid-cols-3 gap-2">' +
              '<input id="mgAnnBadge" class="' + inputCls + '" placeholder="عنوان الشارة" value="' + esc(annDraft.badge || "📢 تعميم الإدارة") + '">' +
              '<input id="mgAnnText" class="' + inputCls + ' sm:col-span-2" placeholder="نص التعميم أو الورشة التدريبية" value="' + esc(annDraft.text || "") + '">' +
            '</div>' +
            '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2">' +
              '<input id="mgAnnBtn" class="' + inputCls + '" placeholder="نص زر الانتقال" value="' + esc(annDraft.btnLabel || "استكشف المختبر") + '">' +
              '<input id="mgAnnLink" dir="ltr" class="' + inputCls + ' text-left" placeholder="#edtechLabSection أو https://..." value="' + esc(annDraft.link || "#edtechLabSection") + '">' +
            '</div>' +
          '</div>' +

          // المستخدمون المسجلون
          '<div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-2">' +
            '<h4 class="text-xs font-black text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5"><i class="fa-solid fa-users"></i><span>المستخدمون المسجّلون عبر Google (<span id="mgUsersCount">…</span>)</span></h4>' +
            '<p class="text-[11px] text-slate-500">يحتفظ كل مستخدم ببياناته الشخصية دون أي صلاحية لتعديل محتوى أو إعدادات الموقع.</p>' +
            '<div id="mgUsersList" class="space-y-2 max-h-52 overflow-y-auto pr-1"><div class="text-xs text-slate-500">جارٍ التحميل…</div></div>' +
          '</div>' +

          // سجل الرقابة الإدارية
          '<div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-2">' +
            '<div class="flex items-center justify-between"><h4 class="text-xs font-black text-slate-700 dark:text-slate-300"><i class="fa-solid fa-clipboard-list ml-1"></i>سجل الرقابة والعمليات الإدارية (Audit Log)</h4></div>' +
            '<div class="max-h-44 overflow-y-auto px-1">' + auditHtml + '</div>' +
          '</div>' +
        '</div>';
      }

      if (current === "backup") {
        return '<div class="space-y-4">' +
          '<div class="p-4 rounded-2xl bg-gradient-to-l from-brand-600/15 to-emerald-500/10 border border-brand-500/30 space-y-2">' +
            '<h4 class="text-xs font-black text-brand-700 dark:text-sky-300"><i class="fa-solid fa-cloud-arrow-down ml-1"></i>1. النسخة الاحتياطية السحابية الشاملة (Firestore + إعدادات الموقع)</h4>' +
            '<p class="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">يجمع كافة مجموعات قاعدة البيانات السحابية (الموارد، الكتب، الإعلانات، الدروس، الفصول، الألعاب، وإعدادات الهوية) في ملف JSON موحّد.</p>' +
            '<button type="button" id="mgCloudBackupBtn" class="px-4 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-black shadow"><i class="fa-solid fa-cloud-arrow-down ml-1.5"></i>تنزيل النسخة السحابية الكاملة الآن</button>' +
          '</div>' +

          '<div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-3">' +
            '<h4 class="text-xs font-black text-slate-800 dark:text-white"><i class="fa-solid fa-file-code ml-1"></i>2. تصدير واستيراد بيانات وإعدادات المنصة (JSON)</h4>' +
            '<div class="flex flex-wrap items-center gap-2">' +
              '<button type="button" id="mgExportLocalJson" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold shadow-xs"><i class="fa-solid fa-download"></i><span>تصدير بيانات الموقع (JSON)</span></button>' +
              '<label class="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-800 dark:text-slate-100 text-xs font-extrabold cursor-pointer"><i class="fa-solid fa-upload text-brand-500"></i><span>استيراد ملف بيانات (JSON)</span><input id="mgImportJsonInp" type="file" accept=".json" class="hidden"></label>' +
              '<button type="button" id="mgResetFactoryBtn" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500 hover:text-white text-rose-500 text-xs font-extrabold mr-auto transition"><i class="fa-solid fa-rotate-left"></i><span>استعادة البيانات الافتراضية</span></button>' +
            '</div>' +
          '</div>' +
        '</div>';
      }

      if (current === "diag") {
        var C = window.Cloud || {}, le = C.lastError;
        var diagRep = (window.EduDiag && window.EduDiag.report) ? window.EduDiag.report() : { errors: [], usage: {} };
        var perf = (window.EduDiag && window.EduDiag.perf) ? window.EduDiag.perf() : { domMs: 0, loadMs: 0, swActive: false, online: true };
        var topUsed = (window.EduDiag && window.EduDiag.topTools) ? window.EduDiag.topTools(8) : [];
        var maxCount = topUsed.length ? Math.max(1, topUsed[0].count) : 1;

        var rows = [
          ["الربط السحابي (Firebase)", C.enabled ? "مفعّل ومتصل ✓" : "غير مفعّل ✗ (وضع محلي)"],
          ["مكتبة Firebase", typeof firebase !== "undefined" ? "محمّلة ✓" : "غير محمّلة ✗"],
          ["النطاق الحالي", location.hostname || "محلي"],
          ["حساب الإدارة النشط", C.user ? C.user.email : "وضع محلي / غير مسجّل"],
          ["صلاحية الإدارة العليا", isAdminNow() ? "مفعّلة بالكامل 👑" : "غير مفعّلة"],
          ["حالة Service Worker (العمل بلا إنترنت)", perf.swActive ? "نشط ومفعّل ✓" : "قيد التجهيز"],
          ["سرعة تجهيز الواجهة (DOM Ready)", perf.domMs + " مللي ثانية"],
          ["عدد موارد المكتبة", String((appState.items || []).length) + " مورد"],
          ["آخر خطأ سحابي", le ? (le.code + " — " + le.message) : "لا يوجد ✓"]
        ];

        var topToolsHtml = topUsed.length ? topUsed.map(function (t) {
          var pct = Math.min(100, Math.round((t.count / maxCount) * 100));
          return '<div class="space-y-1"><div class="flex justify-between text-[11px] font-bold"><span>' + esc(t.id) + '</span><span class="text-brand-500">' + t.count + ' ضغطة</span></div>' +
            '<div class="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden"><div class="h-full bg-gradient-to-l from-brand-500 to-sky-400 rounded-full" style="width:' + pct + '%"></div></div></div>';
        }).join("") : '<div class="text-xs text-slate-400 py-2">لم تُسجّل نقرات كافية بعد.</div>';

        var errsHtml = (diagRep.errors || []).slice().reverse().slice(0, 12).map(function (er) {
          return '<div class="p-2 rounded-xl bg-rose-500/10 border border-rose-500/20 text-[11px] font-mono text-left" dir="ltr">' +
            '<div class="text-rose-500 font-bold truncate">' + esc(er.m) + '</div>' +
            '<div class="text-[10px] text-slate-400">' + esc(er.t) + (er.s ? ' • ' + esc(er.s) : '') + '</div></div>';
        }).join("") || '<div class="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-bold text-center">✓ سجل الأخطاء البرمجية نظيف تماماً (0 أخطاء)</div>';

        return '<div class="space-y-4">' +
          '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">' +
            rows.map(function (r) {
              return '<div class="flex justify-between items-center gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"><b>' + r[0] + '</b><span class="text-left font-bold text-brand-600 dark:text-sky-400" dir="auto">' + esc(r[1]) + "</span></div>";
            }).join("") +
          '</div>' +

          '<div class="flex flex-wrap items-center gap-2">' +
            '<button type="button" id="mgPing" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold"><i class="fa-solid fa-cloud-bolt ml-1"></i>اختبار حفظ فعلي في السحابة</button>' +
            '<button type="button" id="mgPurgeCache" class="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black"><i class="fa-solid fa-arrows-rotate ml-1"></i>تحديث الكاش و Service Worker فوراً</button>' +
            '<button type="button" id="mgDiagDownload" class="px-3.5 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-xs font-bold"><i class="fa-solid fa-file-arrow-down ml-1"></i>تنزيل تقرير التشخيص</button>' +
          '</div>' +
          '<div id="mgPingRes" class="text-xs font-bold"></div>' +

          '<div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-2">' +
            '<div class="flex items-center justify-between"><h4 class="text-xs font-black text-brand-600 dark:text-sky-400">📊 إحصاءات أكثر الأدوات والأقسام تفاعلاً (على هذا الجهاز)</h4>' +
            '<button type="button" id="mgClearUsage" class="text-[11px] text-slate-400 hover:text-rose-500 font-bold">تصفير العداد</button></div>' +
            '<div class="space-y-2">' + topToolsHtml + '</div>' +
          '</div>' +

          '<div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-2">' +
            '<div class="flex items-center justify-between"><h4 class="text-xs font-black text-rose-500">🐞 سجل فحص الأخطاء البرمجية التلقائي (' + (diagRep.errors || []).length + ')</h4>' +
            '<button type="button" id="mgClearErrs" class="text-[11px] text-rose-500 font-bold hover:underline">مسح السجل</button></div>' +
            '<div class="space-y-1.5 max-h-44 overflow-y-auto">' + errsHtml + '</div>' +
          '</div>' +
        '</div>';
      }

      return '<p class="text-[11px] text-slate-500 mb-3">المشرف يدخل بحساب Google (بدون رمز) ويستطيع <b>نشر الموارد وتحريرها</b> ونشر منشوراته في «منشورات المشرفين»، لكنه لا يحذف ولا يغيّر الإعدادات والإعلانات. أضف بريد Gmail الخاص به.</p>' +
        (cloud ? '<div class="flex flex-col sm:flex-row gap-2 mb-3"><input id="mgModName" class="' + inputCls + '" placeholder="اسم المشرف"><input id="mgModEmail" dir="ltr" class="' + inputCls + ' text-left" placeholder="moderator@gmail.com"><button id="mgModAdd" type="button" class="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-extrabold shrink-0">تعيين</button></div><div id="mgModList" class="space-y-2 text-xs">جارٍ التحميل…</div>'
          : '<div class="p-4 rounded-xl border border-dashed border-slate-300 text-xs text-slate-500">يتطلب تفعيل الربط السحابي (Firebase).</div>');
    }

    function draw() {
      showModalContent(
        '<div class="p-3.5 shrink-0 border-b border-slate-200 dark:border-slate-800 bg-gradient-to-l from-slate-900 via-indigo-950 to-slate-900 text-white">' +
          '<div class="flex items-center justify-between mb-2">' +
            '<h3 class="text-sm font-black flex items-center gap-2"><i class="fa-solid fa-screwdriver-wrench text-amber-400"></i><span>مركز تطوير وإدارة الموقع الشامل 👑</span></h3>' +
            '<button type="button" class="p-1.5 rounded-lg text-slate-300 hover:text-white" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button>' +
          '</div>' +
          '<div class="flex items-center gap-1 overflow-x-auto pb-1 no-scrollbar text-[10px]">' +
            '<span class="text-amber-300 font-extrabold shrink-0 ml-1">انتقال سريع للواجهة:</span>' +
            HOME_JUMP.map(function (hj) {
              return '<button type="button" data-homejump="' + hj[0] + '" class="shrink-0 px-2 py-1 rounded-lg bg-white/10 hover:bg-amber-500 hover:text-slate-950 font-bold transition">' + hj[1] + '</button>';
            }).join("") +
          '</div>' +
        '</div>' +
        '<div class="flex flex-wrap gap-1 px-3 pt-2 shrink-0 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50">' +
        TABS.map(function (t) { return '<button type="button" data-tab="' + t[0] + '" class="shrink-0 px-2.5 py-2 text-[11px] border-b-2 ' + (t[0] === current ? "border-brand-600 text-brand-600 dark:text-sky-400 font-extrabold" : "border-transparent text-slate-500 font-bold hover:text-slate-800 dark:hover:text-slate-200") + '">' + t[1] + "</button>"; }).join("") + "</div>" +
        '<div class="p-4 overflow-y-auto text-right flex-1 min-h-0" id="mgBody">' + bodyFor() + "</div>" +
        '<div class="p-3 shrink-0 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2 bg-slate-50 dark:bg-slate-800/50"><button type="button" class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold" onclick="closeModal()">إغلاق</button>' +
        '<button type="button" id="mgSave" class="px-5 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-black shadow">حفظ ونشر التعديلات للجميع ✓</button></div>');
      bind();
    }

    function readWel() { var o = document.getElementById("wlTitle"); if (!o) return; wel = { enabled: document.getElementById("wlOn").checked, everyVisit: document.getElementById("wlEvery").checked, title: o.value, text: document.getElementById("wlText").value, btn: document.getElementById("wlBtn").value, link: document.getElementById("wlLink").value }; }
    function readAnn() {
      var o = document.getElementById("mgAnnBadge");
      if (!o) return;
      annDraft = {
        enabled: document.getElementById("mgAnnOn").checked,
        badge: o.value.trim() || "📢 تعميم الإدارة",
        text: document.getElementById("mgAnnText").value.trim(),
        btnLabel: document.getElementById("mgAnnBtn").value.trim() || "استكشف المختبر",
        link: document.getElementById("mgAnnLink").value.trim() || "#edtechLabSection"
      };
    }
    function readStg() { var rows = document.querySelectorAll("[data-stg]"); if (rows.length || document.getElementById("stgAdd")) { var v = Array.prototype.map.call(rows, function (r) { return r.querySelector("[data-sv]").value; }); if (current === "subjects") sbj = v; else stg = v; } }
    function curList() { return current === "subjects" ? sbj : stg; }
    function readAI() {
      readWel();
      readAnn();
      readStg();
      if (window.AIAdmin) window.AIAdmin.read(ai);
      if (window.ThemeAdmin) window.ThemeAdmin.read(theme);
    }
    function bind() {
      document.querySelectorAll("[data-homejump]").forEach(function (b) {
        b.addEventListener("click", function () {
          var target = b.getAttribute("data-homejump");
          closeModal();
          setTimeout(function () {
            if (window.EduHome && window.EduHome.openAdmin) window.EduHome.openAdmin(target);
          }, 60);
        });
      });
      document.querySelectorAll("[data-tab]").forEach(function (b) { b.addEventListener("click", function () { readAI(); current = b.dataset.tab; draw(); }); });
      document.querySelectorAll("[data-kind]").forEach(function (box) {
        var i = +box.dataset.idx, arr = W[box.dataset.kind];
        box.querySelectorAll("[data-f]").forEach(function (inp) {
          var ev = (inp.tagName === "SELECT" || inp.type === "checkbox" || inp.type === "date") ? "change" : "input";
          inp.addEventListener(ev, function () { arr[i][inp.dataset.f] = inp.type === "checkbox" ? inp.checked : inp.value; if (inp.tagName === "SELECT") draw(); });
        });
        box.querySelectorAll("[data-up]").forEach(function (inp) {
          inp.addEventListener("change", function () {
            var f = inp.files[0]; if (!f) return;
            compressImageFile(f, 640, 120000).then(function (d) { arr[i][inp.dataset.up] = d; draw(); }).catch(function () { showToast("تعذر معالجة الصورة", "warning"); });
          });
        });
        box.querySelectorAll("[data-clear]").forEach(function (b) { b.addEventListener("click", function () { arr[i][b.dataset.clear] = ""; draw(); }); });
        box.querySelectorAll("[data-act]").forEach(function (b) {
          b.addEventListener("click", function () {
            var act = b.dataset.act;
            if (act === "del") arr.splice(i, 1);
            else if (act === "up" && i > 0) { var t = arr[i]; arr[i] = arr[i - 1]; arr[i - 1] = t; }
            else if (act === "down" && i < arr.length - 1) { var t2 = arr[i]; arr[i] = arr[i + 1]; arr[i + 1] = t2; }
            draw();
          });
        });
      });
      document.querySelectorAll("[data-stg]").forEach(function (r) {
        var i = +r.dataset.stg;
        r.querySelectorAll("[data-sa]").forEach(function (b) { b.addEventListener("click", function () {
          readStg(); var a = b.dataset.sa;
          var L = curList();
          if (a === "del") L.splice(i, 1);
          else if (a === "up" && i > 0) { var t = L[i]; L[i] = L[i - 1]; L[i - 1] = t; }
          else if (a === "down" && i < L.length - 1) { var t2 = L[i]; L[i] = L[i + 1]; L[i + 1] = t2; }
          draw();
        }); });
      });
      var sAdd = document.getElementById("stgAdd");
      if (sAdd) sAdd.addEventListener("click", function () { readStg(); curList().push(current === "subjects" ? "مادة جديدة" : "مرحلة جديدة"); draw(); });
      var sRes = document.getElementById("stgReset");
      if (sRes) sRes.addEventListener("click", function () { if (current === "subjects") sbj = DEFAULT_SUBJECTS.slice(); else stg = DEFAULT_STAGES.slice(); draw(); });
      if (window.AIAdmin) window.AIAdmin.bind(ai);
      if (window.ThemeAdmin && current === "theme") window.ThemeAdmin.bind(theme);
      var pv = document.getElementById("wlPreview");
      if (pv) pv.addEventListener("click", function () { readWel(); appState.welcome = wel; closeModal(); if (window.showWelcome) window.showWelcome(true); });
      var add = document.getElementById("mgAdd");
      if (add) add.addEventListener("click", function () { W[current].push(NEW[current]()); draw(); });

      // تبويب التشخيص والمطور
      var ping = document.getElementById("mgPing");
      if (ping) ping.addEventListener("click", function () {
        var out = document.getElementById("mgPingRes"); out.textContent = "⏳ جارٍ فحص الكتابة السحابية…";
        if (!window.Cloud || !window.Cloud.enabled) { out.textContent = "الربط السحابي غير مفعّل."; return; }
        var t0 = Date.now();
        window.Cloud.ping().then(function () {
          out.className = "mt-2 text-xs font-bold text-emerald-600";
          out.textContent = "✓ نجحت الكتابة في السحابة خلال " + (Date.now() - t0) + "ms — الحفظ السحابي يعمل بكفاءة.";
        }).catch(function (e) {
          out.className = "mt-2 text-xs font-bold text-rose-500";
          out.textContent = "✗ فشلت الكتابة: " + (e.code || e.message);
        });
      });
      var purgeBtn = document.getElementById("mgPurgeCache");
      if (purgeBtn) purgeBtn.addEventListener("click", function () {
        if (window.EduDiag && window.EduDiag.purgeCache) window.EduDiag.purgeCache();
      });
      var diagDl = document.getElementById("mgDiagDownload");
      if (diagDl) diagDl.addEventListener("click", function () {
        if (window.EduDiag && window.EduDiag.download) window.EduDiag.download();
      });
      var clrUsage = document.getElementById("mgClearUsage");
      if (clrUsage) clrUsage.addEventListener("click", function () {
        if (window.EduDiag && window.EduDiag.clearUsage) { window.EduDiag.clearUsage(); draw(); }
      });
      var clrErrs = document.getElementById("mgClearErrs");
      if (clrErrs) clrErrs.addEventListener("click", function () {
        if (window.EduDiag && window.EduDiag.clearErrors) { window.EduDiag.clearErrors(); draw(); }
      });

      // تبويب المستخدمين والرقابة
      if (current === "users") {
        var uBox = document.getElementById("mgUsersList");
        var uCnt = document.getElementById("mgUsersCount");
        if (!cloud) {
          if (uBox) uBox.innerHTML = '<div class="p-3 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-center text-xs text-slate-500">الربط السحابي غير مفعّل حالياً.</div>';
          if (uCnt) uCnt.textContent = "0";
        } else if (window.Cloud && window.Cloud.listUsers) {
          window.Cloud.listUsers().then(function (list) {
            list.sort(function (a, b) { return String(b.lastLoginAt || "").localeCompare(String(a.lastLoginAt || "")); });
            if (uCnt) uCnt.textContent = String(list.length);
            if (!list.length) {
              if (uBox) uBox.innerHTML = '<div class="p-3 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-center text-xs text-slate-500">لا يوجد مستخدمون مسجّلون بعد.</div>';
              return;
            }
            if (uBox) {
              uBox.innerHTML = list.map(function (u) {
                return '<div class="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">' +
                  '<div class="flex items-center justify-between gap-2"><span class="text-xs font-extrabold text-slate-900 dark:text-white truncate">' + esc(u.name || "مستخدم") + '</span><span class="text-[10px] text-slate-400 shrink-0">' + (u.lastLoginAt ? esc(formatActTime(u.lastLoginAt)) : "") + '</span></div>' +
                  '<div class="text-[10px] text-slate-500 font-mono truncate" dir="ltr">' + esc(u.email || "") + '</div>' +
                  '<div class="text-[10px] text-brand-600 dark:text-brand-400 font-bold mt-0.5">' + esc(u.role || "") + ' • ❤️ ' + (u.favorites || []).length + ' • ✓ ' + (u.completedItems || []).length + ' • 💡 ' + (u.savedPrompts || []).length + '</div></div>';
              }).join("");
            }
          }).catch(function () {
            if (uBox) uBox.innerHTML = '<div class="p-3 text-xs text-rose-500">تعذر تحميل قائمة المستخدمين.</div>';
            if (uCnt) uCnt.textContent = "؟";
          });
        }
      }

      // تبويب النسخ الاحتياطي والبيانات
      var cbBtn = document.getElementById("mgCloudBackupBtn");
      if (cbBtn) cbBtn.addEventListener("click", downloadCloudBackup);
      var expLocal = document.getElementById("mgExportLocalJson");
      if (expLocal) expLocal.addEventListener("click", function () {
        try {
          var backupPayload = { appState: appState, exportedAt: new Date().toISOString() };
          var dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupPayload, null, 2));
          var dl = document.createElement("a");
          dl.setAttribute("href", dataStr);
          dl.setAttribute("download", "edutech_mindset_backup_" + Date.now() + ".json");
          dl.click();
          showToast("✓ تم تصدير ملف النسخة الاحتياطية بنجاح", "success");
        } catch (e) { showToast("تعذر تصدير الملف", "warning"); }
      });
      var impInp = document.getElementById("mgImportJsonInp");
      if (impInp) impInp.addEventListener("change", function (e) {
        var file = e.target.files[0];
        if (!file) return;
        var reader = new FileReader();
        reader.onload = function (ev) {
          try {
            var imported = JSON.parse(ev.target.result);
            var targetState = (imported && imported.appState && Array.isArray(imported.appState.items)) ? imported.appState : (imported && Array.isArray(imported.items) ? imported : null);
            if (targetState) {
              appState = Object.assign(deepCopy(DEFAULT_DATA), targetState);
              delete appState.adminPin;
              addAuditLog("استيراد نسخة احتياطية للمحتوى");
              saveState();
              closeModal();
              fullRender();
              showToast("✓ تم استيراد البيانات وتحديث الموقع بنجاح", "success");
            } else {
              showToast("الملف لا يحتوي على بنية بيانات صالحة", "warning");
            }
          } catch (err) { showToast("فشل قراءة ملف JSON", "warning"); }
        };
        reader.readAsText(file);
      });
      var resetFactory = document.getElementById("mgResetFactoryBtn");
      if (resetFactory) resetFactory.addEventListener("click", function () {
        if (!window.eduConfirm("سيتم استعادة المحتوى والإعدادات الافتراضية للموقع. هل أنت متأكد؟")) return;
        appState = deepCopy(DEFAULT_DATA);
        addAuditLog("استعادة المحتوى الافتراضي");
        saveState();
        closeModal();
        fullRender();
        showToast("تمت استعادة البيانات الافتراضية بنجاح", "info");
      });

      document.getElementById("mgSave").addEventListener("click", function () {
        readAI();
        appState.links = W.links.filter(function (l) { return (l.n || "").trim(); });
        appState.quickLinks = W.quick.filter(function (c) { return (c.title || "").trim(); });
        appState.blocks = W.blocks.filter(function (b) { return (b.title || "").trim(); });
        appState.welcome = wel;
        appState.announcement = annDraft;
        appState.stages = stg.map(function (s) { return String(s).trim(); }).filter(Boolean);
        appState.subjects = sbj.map(function (s) { return String(s).trim(); }).filter(Boolean);
        appState.aiConfig = window.AIAdmin ? window.AIAdmin.clean(ai) : {};
        appState.themeConfig = theme;
        if (window.applySiteTheme) window.applySiteTheme(theme);
        var newAds = W.ads.filter(function (a) { return (a.title || "").trim(); });
        if (cloud) {
          var ops = [], keep = {};
          newAds.forEach(function (a) { keep[a.id] = 1; var d = JSON.parse(JSON.stringify(a)); delete d.id; delete d.updatedAt; delete d.updatedBy;
            var old = adsList.filter(function (x) { return x.id === a.id; })[0];
            var oc = old ? JSON.parse(JSON.stringify(old)) : null; if (oc) { delete oc.id; delete oc.updatedAt; delete oc.updatedBy; }
            if (!oc || stableJson(oc) !== stableJson(d)) ops.push({ col: "ads", id: a.id, data: d }); });
          adsList.forEach(function (x) { if (!keep[x.id]) ops.push({ col: "ads", id: x.id, remove: true }); });
          if (ops.length) window.Cloud.commit(ops).catch(function (e) { showToast("تعذر حفظ الإعلانات [" + (e.code || "؟") + "]", "warning"); });
        } else appState.ads = newAds;
        addAuditLog("تحديث إعدادات مركز الإدارة والتطوير الموحّد");
        saveState(); closeModal(); fullRender();
        showToast("تم الحفظ — يظهر الآن لجميع الزوار ✓", "success");
      });
      if (current === "mods" && cloud) {
        var list = document.getElementById("mgModList");
        var load = function () {
          window.Cloud.listMods().then(function (ms) {
            list.innerHTML = ms.length ? ms.map(function (m) {
              return '<div class="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"><div class="min-w-0"><div class="font-extrabold">' + esc(m.name || "") + '</div><div dir="ltr" class="text-[10px] text-slate-500 font-mono truncate">' + esc(m.email) + '</div></div><button type="button" data-rm="' + esc(m.email) + '" class="px-2.5 py-1 rounded-lg bg-rose-500/10 text-rose-500 font-bold">إزالة</button></div>';
            }).join("") : "لا يوجد مشرفون بعد.";
            list.querySelectorAll("[data-rm]").forEach(function (b) { b.addEventListener("click", function () {
              window.Cloud.removeMod(b.dataset.rm).then(function () { showToast("تمت إزالة المشرف", "info"); load(); });
            }); });
          }).catch(function () { list.textContent = "تعذر تحميل القائمة."; });
        };
        load();
        document.getElementById("mgModAdd").addEventListener("click", function () {
          var name = document.getElementById("mgModName").value.trim();
          var email = document.getElementById("mgModEmail").value.trim().toLowerCase();
          if (!name || !/^\S+@\S+\.\S+$/.test(email)) { showToast("أدخل اسماً وبريداً صحيحاً", "warning"); return; }
          window.Cloud.addMod(email, name).then(function () {
            showToast("تم تعيين " + name + " مشرفاً ✓ (يدخل بحساب Google ويحدّث الصفحة)", "success");
            document.getElementById("mgModName").value = ""; document.getElementById("mgModEmail").value = ""; load();
          }).catch(function (e) { showToast("تعذر التعيين [" + (e.code || "؟") + "]: تحقق من حساب الإدارة وقواعد الأمان", "warning"); });
        });
      }
    }
    draw();
  }

  // ---------- ربط ----------
  window.openSiteManager = openSiteManager;
  window.renderExtras = function () {
    ensureSections();
    renderQuickLinks();
    renderMods();
    renderSlots();
    applyStages();
    applySubjects();
    syncAdminButtons();
  };
  window.addEventListener("DOMContentLoaded", function () {
    setTimeout(function () {
      ensureSections();
      if (window.Cloud && window.Cloud.enabled) {
        window.Cloud.subscribePosts(function (list) { modPosts = list; postsReady = true; renderMods(); }, function () { postsReady = true; renderMods(); });
      }
      if (window.Cloud && window.Cloud.enabled) {
        window.Cloud.subscribeAds(function (l) { adsList = l; renderSlots(); }, function () {});
      }
      renderExtras();
    }, 0);
  });
})();

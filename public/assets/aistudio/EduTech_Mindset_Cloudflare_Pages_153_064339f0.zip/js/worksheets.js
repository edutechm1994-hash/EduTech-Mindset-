/*
 * مولّد أوراق العمل والاختبارات — EduTech Mindset
 * توليد بالذكاء الاصطناعي (موضوع / نص / صورة)، تعديل، نسختان أ وب، PDF للطالب وللمعلم (مع الإجابات)، حفظ في Firestore (worksheets).
 * أنواع الأسئلة: mcq / tf / fill / match / short / problem
 */
(function () {
  "use strict";
  var COL = "worksheets";
  var TYPES = { mcq: "اختيار من متعدد", tf: "صح وخطأ", fill: "أكمل الفراغ", match: "وصّل", short: "سؤال قصير", problem: "مسألة / تمرين" };
  var PTS = { mcq: 1, tf: 1, fill: 1, match: 2, short: 2, problem: 3 };
  var LEVELS = { easy: "سهل", mid: "متوسط", hard: "متقدم", mix: "متدرّج (من السهل للمتقدم)" };
  var GRADES = ["الأول الأساسي", "الثاني الأساسي", "الثالث الأساسي", "الرابع الأساسي", "الخامس الأساسي", "السادس الأساسي", "السابع", "الثامن", "التاسع", "العاشر", "الحادي عشر", "الثاني عشر"];
  var LET = ["أ", "ب", "ج", "د", "هـ"];
  var st = { id: "", title: "", kind: "worksheet", grade: GRADES[3], subject: "", level: "mix", topic: "", school: "", teacher: "", duration: "", sets: { A: [], B: [] }, set: "A", attach: [], dirty: false, prev: "" };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  function e(s) { return typeof escapeHtml === "function" ? escapeHtml(String(s == null ? "" : s)) : String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function $(id) { return document.getElementById(id); }
  function toast(m, t) { if (typeof showToast === "function") showToast(m, t || "success"); }
  function cloud() { return window.Cloud && window.Cloud.enabled; }
  function uid() { return window.Cloud && window.Cloud.getStudioUser ? window.Cloud.getStudioUser().uid : (window.Cloud && window.Cloud.user ? window.Cloud.user.uid : "local_workspace"); }
  function cur() { return st.sets[st.set]; }
  function total(arr) { return (arr || []).reduce(function (a, q) { return a + (+q.pts || 0); }, 0); }
  function lsGet() { try { return JSON.parse(localStorage.getItem("ws_hdr") || "{}"); } catch (x) { return {}; } }
  function lsSet() { try { localStorage.setItem("ws_hdr", JSON.stringify({ school: st.school, teacher: st.teacher, duration: st.duration })); } catch (x) {} }

  // ---------- تنظيف / توحيد الأسئلة ----------
  function str(v, n) { return String(v == null ? "" : v).trim().slice(0, n || 400); }
  function normQ(x) {
    if (!x || typeof x !== "object" || !TYPES[x.t]) return null;
    var q = { t: x.t, q: str(x.q, 500), pts: +x.pts > 0 ? Math.min(20, +x.pts) : PTS[x.t] };
    if (x.t === "mcq") {
      var o = (x.options || []).map(function (v) { return str(v, 150); }).filter(Boolean).slice(0, 4);
      while (o.length < 4) o.push("—");
      var a = parseInt(x.answer, 10); q.options = o; q.answer = a >= 0 && a < 4 ? a : 0;
    } else if (x.t === "tf") { q.answer = x.answer === true || x.answer === "true" || x.answer === "صح"; }
    else if (x.t === "match") {
      q.pairs = (x.pairs || []).map(function (p) { return { a: str(p && p.a, 120), b: str(p && p.b, 120) }; }).filter(function (p) { return p.a || p.b; }).slice(0, 5);
      while (q.pairs.length < 2) q.pairs.push({ a: "—", b: "—" });
    } else { q.answer = str(x.answer, 800); }
    return q;
  }
  function parseJson(txt) {
    var s = String(txt || "").replace(/```json|```/gi, ""), a = s.indexOf("{"), b = s.lastIndexOf("}");
    if (a < 0 || b <= a) throw new Error("لم يُرجع الذكاء الاصطناعي نتيجة مفهومة، أعد المحاولة");
    return JSON.parse(s.slice(a, b + 1));
  }
  var SCHEMA = '{"title":"عنوان الورقة","questions":[{"t":"mcq","q":"","options":["","","",""],"answer":0,"pts":1},{"t":"tf","q":"عبارة","answer":true,"pts":1},{"t":"fill","q":"جملة فيها ___ مكان الفراغ","answer":"الكلمة","pts":1},{"t":"match","q":"وصّل كل عنصر بما يناسبه","pairs":[{"a":"","b":""},{"a":"","b":""},{"a":"","b":""}],"pts":2},{"t":"short","q":"","answer":"إجابة نموذجية مختصرة","pts":2},{"t":"problem","q":"","answer":"خطوات الحل والناتج","pts":3}]}';

  // دفعات صغيرة (حتى 7 أسئلة) تُولَّد بالتوازي: أسرع وأضمن من طلب واحد كبير يتجاوز مهلة المحرك
  function sizes(n) { var k = Math.ceil(n / 7), out = [], left = n; for (var i = 0; i < k; i++) { var c = Math.ceil(left / (k - i)); out.push(c); left -= c; } return out; }
  function askRetry(prompt, files) {
    return window.AI.ask(prompt, files || [], "worksheet").catch(function () { return new Promise(function (r) { setTimeout(r, 1500); }).then(function () { return window.AI.ask(prompt, files || [], "worksheet"); }); });
  }
  function buildPrompt(n, part, parts) {
    var types = Object.keys(TYPES).filter(function (k) { return $("wsT_" + k) && $("wsT_" + k).checked; });
    return "أنت معلّم خبير في إعداد " + (st.kind === "exam" ? "اختبارات قصيرة" : "أوراق عمل تدريبية") + " للمنهاج الفلسطيني" + (st.topic ? " عن: «" + st.topic + "»" : " من المحتوى الموجود في الصور المرفقة") +
      ".\nالمرحلة: " + st.grade + (st.subject ? "\nالمادة: " + st.subject : "") + "\nعدد الأسئلة في هذا الطلب: " + n + (parts > 1 ? " (الجزء " + part + " من " + parts + " من أسئلة الورقة الكاملة؛ غطِّ جانباً مختلفاً من الموضوع ولا تكرر الأفكار الأساسية التي ستغطيها الأجزاء الأخرى" + (st.level === "mix" ? "، والمستوى المتدرّج يُطبَّق ضمن هذا الجزء" : "") + ")" : "") + "\nالمستوى: " + LEVELS[st.level] + "\nأنواع الأسئلة المسموحة فقط: " + types.map(function (k) { return k + " (" + TYPES[k] + ")"; }).join("، ") + " ووزّعها بشكل متوازن.\n" +
      "أعد JSON صالحاً فقط، بلا أي شرح وبلا علامات ```، بهذا الشكل (استخدم من الأنواع المسموحة فقط):\n" + SCHEMA + "\n" +
      "القواعد: لكل mcq أربعة خيارات وanswer هو رقم الخيار الصحيح (0 إلى 3) وبدون «كل ما سبق» إلا عند الضرورة. في fill ضع ___ مكان الفراغ وفراغ واحد فقط. في match من 3 إلى 5 أزواج {a,b} صحيحة 1:1. الدرجات pts مناسبة للصعوبة. اللغة العربية الفصحى المبسّطة المناسبة للمرحلة والأسئلة دقيقة علمياً وغير مكررة، وإجاباتها صحيحة 100%.";
  }
  function generate() {
    st.topic = $("wsTopic").value.trim(); st.grade = $("wsGrade").value; st.subject = $("wsSubject").value.trim(); st.level = $("wsLevel").value; st.kind = $("wsKind").value;
    if (!st.topic && !st.attach.length) { toast("اكتب الموضوع أو أضف صورة الدرس", "warning"); return; }
    if (!Object.keys(TYPES).some(function (k) { return $("wsT_" + k).checked; })) { toast("اختر نوع سؤال واحداً على الأقل", "warning"); return; }
    var btn = $("wsGo"), stat = $("wsStat"), wantB = $("wsB").checked;
    btn.disabled = true; btn.classList.add("opacity-60"); stat.textContent = "⏳ جارٍ إعداد الأسئلة… قد يستغرق حتى دقيقة";
    var A, sz = sizes(+$("wsCount").value), done = 0;
    function upd(msg) { stat.textContent = "⏳ " + msg; }
    upd("جارٍ إعداد الأسئلة… (" + sz.length + (sz.length > 1 ? " دفعات بالتوازي" : " دفعة") + ")");
    var files = st.attach.map(function (f) { return { mime: f.mime, data: f.data }; });
    Promise.all(sz.map(function (c, i) {
      return askRetry(buildPrompt(c, i + 1, sz.length), files).then(function (txt) { done++; upd("اكتملت " + done + " من " + sz.length + " دفعات…"); return parseJson(txt); });
    })).then(function (js) {
      A = [].concat.apply([], js.map(function (j) { return (j.questions || []).map(normQ).filter(Boolean); }));
      if (A.length < 2) throw new Error("عدد الأسئلة الناتج قليل، أعد المحاولة");
      st.title = String((js[0] && js[0].title) || st.topic || "ورقة عمل").slice(0, 120); st.id = "";
      st.sets = { A: A, B: [] }; st.set = "A"; st.dirty = true;
      if (!wantB) return null;
      upd("جارٍ إعداد النسخة (ب)…");
      return genBSet(A).then(function (B) { st.sets.B = B; }, function () { toast("تعذر إعداد النسخة (ب)، يمكنك المحاولة لاحقاً بزر «ولّد النسخة ب»", "warning"); });
    }).then(function () { stat.textContent = ""; renderEditor(); $("wsEditor").scrollIntoView({ behavior: "smooth", block: "start" }); },
      function (err) { stat.textContent = "⚠️ " + (err && err.message ? err.message : "تعذر التوليد"); })
      .then(function () { btn.disabled = false; btn.classList.remove("opacity-60"); });
  }
  function genBSet(A) {
    var sz = sizes(A.length), at = 0;
    return Promise.all(sz.map(function (c) {
      var chunk = A.slice(at, at + c); at += c;
      return askRetry(variantPrompt(chunk)).then(function (t) { return (parseJson(t).questions || []).map(normQ).filter(Boolean); });
    })).then(function (parts) {
      var B = [].concat.apply([], parts);
      if (B.length < 2) throw new Error("نتيجة غير صالحة");
      return B;
    });
  }
  function variantPrompt(A) {
    return "هذه ورقة (" + (st.kind === "exam" ? "اختبار" : "عمل") + ") للمرحلة " + st.grade + (st.subject ? " (" + st.subject + ")" : "") + " بعنوان «" + st.title + "»:\n" + JSON.stringify({ questions: A }) +
      "\nأنشئ النسخة (ب) المكافئة: نفس عدد الأسئلة ونفس الأنواع والترتيب والدرجات ونفس المستوى، لكن بأسئلة وأرقام وأمثلة مختلفة تماماً (غير منسوخة من النسخة أ)، وبترتيب مختلف لخيارات mcq. أعد JSON فقط بنفس الشكل {\"questions\":[...]} بلا أي شرح.";
  }
  function genB() {
    var stat = $("wsEdStat"); stat.textContent = "⏳ جارٍ إعداد النسخة (ب)…";
    genBSet(st.sets.A).then(function (B) { st.sets.B = B; st.set = "B"; st.dirty = true; stat.textContent = ""; renderEditor(); })
      .catch(function (err) { stat.textContent = "⚠️ " + (err.message || "تعذر"); });
  }
  function regenQ(i) {
    var q = cur()[i], stat = $("wsEdStat"); stat.textContent = "⏳ جارٍ إعادة توليد السؤال " + (i + 1) + "…";
    var p = "في " + (st.kind === "exam" ? "اختبار" : "ورقة عمل") + " بعنوان «" + st.title + "» للمرحلة " + st.grade + (st.subject ? " (" + st.subject + ")" : "") + "، أعد كتابة هذا السؤال بسؤال جديد مختلف عنه في نفس الموضوع والنوع والمستوى:\n" + JSON.stringify(q) + "\nأعد JSON فقط لسؤال واحد بنفس الحقول والنوع دون أي شرح.";
    window.AI.ask(p, [], "worksheet").then(function (t) {
      var n = normQ(parseJson(t)); if (!n) throw new Error("نتيجة غير صالحة"); n.t = q.t; if (!n.pts) n.pts = q.pts; cur()[i] = n; st.dirty = true; stat.textContent = ""; renderEditor();
    }).catch(function (err) { stat.textContent = "⚠️ " + (err.message || "تعذر"); });
  }

  // ---------- الورقة المطبوعة ----------
  var PAPER_CSS = ".wsp{direction:rtl;text-align:right;font-family:'Cairo',Tahoma,sans-serif;color:#111;background:#fff;font-size:13px;line-height:1.7;padding:6mm}.wsp *{box-sizing:border-box}" +
    ".wsp .hd{border:2px solid #111;border-radius:8px;padding:8px 12px;margin-bottom:10px}.wsp .hd .r1{display:flex;justify-content:space-between;gap:8px;font-weight:700;font-size:12px}.wsp .ttl{text-align:center;font-size:19px;font-weight:900;margin:4px 0}" +
    ".wsp .r2{display:flex;justify-content:space-between;gap:12px;font-size:12px;margin-top:6px}.wsp .r2 span{flex:1;border-bottom:1px dotted #555;min-height:20px}" +
    ".wsp .q{margin:0 0 11px;page-break-inside:avoid;break-inside:avoid}.wsp .qh{display:flex;gap:6px;font-weight:700}.wsp .qn{min-width:22px;height:22px;border-radius:50%;background:#111;color:#fff;text-align:center;font-size:12px;line-height:22px;flex:none}" +
    ".wsp .qp{margin-inline-start:auto;font-size:11px;font-weight:700;border:1px solid #555;border-radius:6px;padding:0 6px;white-space:nowrap;height:20px}.wsp .opts{display:grid;grid-template-columns:1fr 1fr;gap:2px 14px;margin:3px 28px 0}" +
    ".wsp .ln{display:inline-block;min-width:90px;border-bottom:1.5px solid #111;margin:0 3px}.wsp .box{border:1px dashed #888;border-radius:6px;min-height:64px;margin:4px 28px 0}.wsp .lines{margin:4px 28px 0}.wsp .lines i{display:block;border-bottom:1px solid #999;height:22px}" +
    ".wsp .m{display:flex;justify-content:space-between;gap:30px;margin:4px 28px 0}.wsp .m div{flex:1}.wsp .m p{margin:2px 0;padding:3px 8px;border:1px solid #bbb;border-radius:6px}" +
    ".wsp .ok{color:#047857;font-weight:800}.wsp .ans{margin:3px 28px 0;padding:2px 8px;border-inline-start:3px solid #059669;background:#ecfdf5;color:#065f46;font-weight:700;font-size:12px}" +
    ".wsp .key{margin-top:12px;border-top:2px dashed #555;padding-top:6px;font-size:12px}.wsp .tag{display:inline-block;background:#fde68a;border-radius:6px;padding:0 8px;font-size:11px;font-weight:800;margin-inline-start:6px}";
  function qHtml(q, i, teacher) {
    var h = '<div class="q"><div class="qh"><span class="qn">' + (i + 1) + "</span><span>" + e(q.q).replace(/_{3,}/g, '<span class="ln"></span>') + '</span><span class="qp">' + q.pts + " " + (q.pts > 2 ? "درجات" : q.pts === 2 ? "درجتان" : "درجة") + "</span></div>";
    if (q.t === "mcq") {
      h += '<div class="opts">' + q.options.map(function (o, k) { return "<div" + (teacher && k === q.answer ? ' class="ok"' : "") + ">" + LET[k] + ") " + e(o) + (teacher && k === q.answer ? " ✓" : "") + "</div>"; }).join("") + "</div>";
    } else if (q.t === "tf") {
      h += '<div style="margin:2px 28px 0">( &nbsp;&nbsp; ) صح &nbsp;&nbsp;&nbsp; ( &nbsp;&nbsp; ) خطأ' + (teacher ? ' <span class="ok">← ' + (q.answer ? "صح" : "خطأ") + "</span>" : "") + "</div>";
    } else if (q.t === "fill") {
      if (teacher) h += '<div class="ans">الإجابة: ' + e(q.answer) + "</div>";
    } else if (q.t === "match") {
      var n = q.pairs.length, perm = q.pairs.map(function (_, k) { return (k + 1) % n; });
      h += '<div class="m"><div>' + q.pairs.map(function (p, k) { return "<p>" + (k + 1) + ") " + e(p.a) + "</p>"; }).join("") + "</div><div>" + perm.map(function (pi, k) { return "<p>" + LET[k] + ") " + e(q.pairs[pi].b) + "</p>"; }).join("") + "</div></div>";
      if (teacher) h += '<div class="ans">الإجابة: ' + q.pairs.map(function (p, k) { return (k + 1) + " ← " + LET[perm.indexOf(k)]; }).join(" ، ") + "</div>";
    } else {
      h += q.t === "problem" ? '<div class="box"></div>' : '<div class="lines"><i></i><i></i></div>';
      if (teacher) h += '<div class="ans">' + (q.t === "problem" ? "الحل: " : "الإجابة النموذجية: ") + e(q.answer) + "</div>";
    }
    return h + "</div>";
  }
  function paperHtml(set, teacher) {
    var arr = st.sets[set] || [], t = total(arr), label = st.kind === "exam" ? "اختبار" : "ورقة عمل";
    var hd = '<div class="hd"><div class="r1"><span>' + e(st.school || "المدرسة: ................") + "</span><span>" + e(label) + (st.sets.B.length ? " — النسخة (" + (set === "A" ? "أ" : "ب") + ")" : "") + (teacher ? ' <span class="tag">نسخة المعلم</span>' : "") + "</span><span>" + e(st.teacher ? "المعلم: " + st.teacher : "المعلم: ............") + "</span></div>" +
      '<div class="ttl">' + e(st.title) + '</div><div class="r1" style="font-weight:600"><span>' + e(st.subject ? "المادة: " + st.subject : "") + "</span><span>الصف: " + e(st.grade) + "</span><span>" + (st.duration ? "الزمن: " + e(st.duration) + " دقيقة" : "") + "</span><span>الدرجة الكلية: " + t + "</span></div>" +
      '<div class="r2"><span>اسم الطالب:</span><span style="flex:.6">الشعبة:</span><span style="flex:.6">التاريخ:</span><span style="flex:.6">الدرجة: &nbsp;&nbsp;/ ' + t + "</span></div></div>";
    var qrBanner = (window.EduQR && window.EduQR.brandBanner) ? window.EduQR.brandBanner((st.title || label) + " — " + (st.subject || "") + " (" + st.grade + ")", location.origin + location.pathname + "?app=worksheetStudio") : "";
    return '<div class="wsp">' + qrBanner + hd + arr.map(function (q, i) { return qHtml(q, i, teacher); }).join("") + "</div>";
  }
  function ensureCss() { if ($("wsPaperCss")) return; var s = document.createElement("style"); s.id = "wsPaperCss"; s.textContent = PAPER_CSS; document.head.appendChild(s); }
  function preview(teacher) {
    ensureCss(); var p = $("wsPreview"); p.innerHTML = '<div class="rounded-2xl border border-slate-300 shadow-lg overflow-hidden bg-white" style="max-width:820px;margin:auto">' + paperHtml(st.set, teacher) + "</div>"; p.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }
  function exportPdf(teacher, both) {
    var sets = both ? ["A", "B"].filter(function (k) { return st.sets[k].length; }) : [st.set];
    var old = $("wsPrintFrame"); if (old) old.remove();
    var fr = document.createElement("iframe"); fr.id = "wsPrintFrame"; fr.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0"; document.body.appendChild(fr);
    var d = fr.contentDocument; d.open();
    d.write('<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>' + e(st.title) + '</title><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet"><style>@page{size:A4;margin:10mm}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}body{margin:0}.pgb{page-break-after:always;break-after:page}.pgb:last-child{page-break-after:auto;break-after:auto}' + PAPER_CSS + "</style></head><body>" +
      sets.map(function (k) { return '<div class="pgb">' + paperHtml(k, teacher) + "</div>"; }).join("") + "</body></html>");
    d.close();
    var done = false, go = function () { if (done) return; done = true; setTimeout(function () { try { fr.contentWindow.focus(); fr.contentWindow.print(); } catch (x) { toast("تعذر فتح نافذة الطباعة", "warning"); } }, 500); };
    fr.onload = go; setTimeout(go, 1500); toast("اختر «حفظ كملف PDF» من نافذة الطباعة");
  }

  // ---------- الحفظ ----------
  function needLogin() {
    if (!cloud()) { toast("الحفظ يحتاج ربط Firebase", "warning"); return true; }
    if (!uid()) { toast("سجّل الدخول بحساب Google لحفظ الورقة", "warning"); if (typeof openGoogleAuthModal === "function") openGoogleAuthModal(); return true; }
    return false;
  }
  function save() {
    if (!st.sets.A.length || needLogin()) return Promise.resolve();
    var u = (window.Cloud && window.Cloud.getStudioUser ? window.Cloud.getStudioUser() : window.Cloud.user), id = st.id || ("w" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6));
    var data = { ownerUid: u.uid, ownerEmail: u.email || "", title: st.title || "ورقة بدون عنوان", kind: st.kind, grade: st.grade, subject: st.subject, level: st.level, school: st.school, teacher: st.teacher, duration: st.duration, setA: st.sets.A, setB: st.sets.B, updatedAt: window.Cloud.stamp() };
    if (!st.id) data.createdAt = window.Cloud.stamp();
    return window.Cloud.col(COL).doc(id).set(data, { merge: true }).then(function () { st.id = id; st.dirty = false; toast("تم حفظ الورقة ✓"); renderEditor(); loadMine(); },
      function (err) { toast(err && err.code === "permission-denied" ? "لا صلاحية: انشر قواعد Firestore الجديدة" : "تعذر الحفظ", "warning"); });
  }
  function loadMine() {
    var box = $("wsMine"); if (!box) return;
    if (!cloud() || !uid()) { box.innerHTML = '<p class="text-[11px] text-slate-500">سجّل الدخول لترى أوراقك المحفوظة.</p>'; return; }
    window.Cloud.col(COL).where("ownerUid", "==", uid()).get().then(function (snap) {
      var list = snap.docs.map(function (d) { return Object.assign({ id: d.id }, d.data()); });
      list.sort(function (a, b) { return ((b.updatedAt && b.updatedAt.seconds) || 0) - ((a.updatedAt && a.updatedAt.seconds) || 0); });
      box.innerHTML = list.length ? list.map(function (p) {
        return '<div class="flex items-center gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700"><div class="flex-1 min-w-0"><div class="text-xs font-extrabold truncate">' + e(p.title) + '</div><div class="text-[10px] text-slate-500">' + (p.kind === "exam" ? "اختبار" : "ورقة عمل") + " · " + (p.setA || []).length + " سؤال · " + e(p.grade || "") + '</div></div><button type="button" data-open="' + p.id + '" class="px-3 py-1.5 rounded-lg bg-brand-600 text-white text-[11px] font-bold">فتح</button><button type="button" data-del="' + p.id + '" class="px-2.5 py-1.5 rounded-lg bg-rose-600 text-white text-[11px] font-bold">حذف</button></div>';
      }).join("") : '<p class="text-[11px] text-slate-500">لا أوراق محفوظة بعد.</p>';
      box._list = list;
    }, function () { box.innerHTML = '<p class="text-[11px] text-rose-600">تعذر التحميل (تحقق من نشر قواعد Firestore).</p>'; });
  }
  function openSaved(p) {
    st.id = p.id; st.title = p.title; st.kind = p.kind || "worksheet"; st.grade = p.grade || st.grade; st.subject = p.subject || ""; st.level = p.level || "mix"; st.school = p.school || st.school; st.teacher = p.teacher || st.teacher; st.duration = p.duration || "";
    st.sets = { A: (p.setA || []).map(normQ).filter(Boolean), B: (p.setB || []).map(normQ).filter(Boolean) }; st.set = "A"; st.dirty = false; renderEditor(); $("wsEditor").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  // ---------- المحرر ----------
  function qFields(q, i) {
    var f = '<textarea data-qi="' + i + '" data-f="q" rows="2" class="' + cls + '" placeholder="نص السؤال' + (q.t === "fill" ? " (استخدم ___ مكان الفراغ)" : "") + '">' + e(q.q) + "</textarea>";
    if (q.t === "mcq") f += q.options.map(function (o, k) { return '<div class="flex items-center gap-2 mt-1.5"><input type="radio" name="wsr' + i + '" data-qi="' + i + '" data-ans="' + k + '" ' + (q.answer === k ? "checked" : "") + ' title="الإجابة الصحيحة"><input data-qi="' + i + '" data-opt="' + k + '" value="' + e(o) + '" class="' + cls + '"></div>'; }).join("");
    else if (q.t === "tf") f += '<select data-qi="' + i + '" data-tf class="' + cls + ' mt-1.5"><option value="1"' + (q.answer ? " selected" : "") + '>الإجابة: صح</option><option value="0"' + (!q.answer ? " selected" : "") + ">الإجابة: خطأ</option></select>";
    else if (q.t === "match") f += '<textarea data-qi="' + i + '" data-pairs rows="4" class="' + cls + ' mt-1.5" placeholder="كل سطر: العنصر | ما يناسبه">' + e(q.pairs.map(function (p) { return p.a + " | " + p.b; }).join("\n")) + "</textarea>";
    else f += '<' + (q.t === "fill" ? 'input value="' + e(q.answer) + '"' : 'textarea rows="2"') + ' data-qi="' + i + '" data-f="answer" class="' + cls + ' mt-1.5" placeholder="' + (q.t === "fill" ? "الإجابة (الكلمة الناقصة)" : "الإجابة النموذجية / الحل") + '">' + (q.t === "fill" ? "" : e(q.answer) + "</textarea>");
    return f;
  }
  function renderEditor() {
    var box = $("wsEditor"); if (!box) return;
    if (!st.sets.A.length) { box.innerHTML = ""; return; }
    var arr = cur(), b = "px-3 py-2 rounded-xl text-[11px] font-extrabold ";
    var tabs = '<div class="flex gap-1.5 items-center text-[11px] font-bold"><span>النسخة:</span><button type="button" data-set="A" class="px-3 py-1 rounded-lg border-2 ' + (st.set === "A" ? "border-brand-500 bg-brand-50 dark:bg-slate-700" : "border-slate-300") + '">أ</button>' +
      (st.sets.B.length ? '<button type="button" data-set="B" class="px-3 py-1 rounded-lg border-2 ' + (st.set === "B" ? "border-brand-500 bg-brand-50 dark:bg-slate-700" : "border-slate-300") + '">ب</button>' : '<button type="button" id="wsGenB" class="px-3 py-1 rounded-lg bg-purple-600 text-white">+ ولّد النسخة (ب)</button>') + "</div>";
    box.innerHTML = '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700 p-4 sm:p-5 space-y-3 text-right">' +
      '<div class="flex flex-wrap gap-2 items-center"><input id="wsTitle" value="' + e(st.title) + '" class="' + cls + ' flex-1 min-w-[10rem] !text-sm !font-black" placeholder="عنوان الورقة">' +
      '<button type="button" id="wsSave" class="' + b + 'bg-emerald-600 text-white">💾 حفظ' + (st.dirty ? " •" : "") + "</button></div>" +
      '<div class="grid grid-cols-1 sm:grid-cols-3 gap-2"><input id="wsSchool" value="' + e(st.school) + '" class="' + cls + '" placeholder="اسم المدرسة"><input id="wsTeacher" value="' + e(st.teacher) + '" class="' + cls + '" placeholder="اسم المعلم"><input id="wsDur" value="' + e(st.duration) + '" inputmode="numeric" class="' + cls + '" placeholder="الزمن بالدقائق (اختياري)"></div>' +
      '<div class="flex flex-wrap gap-2 items-center justify-between">' + tabs + '<div class="text-xs font-extrabold">عدد الأسئلة: ' + arr.length + " · الدرجة الكلية: <span id=\"wsTot\">" + total(arr) + "</span></div></div>" +
      '<div class="flex flex-wrap gap-1.5"><button type="button" id="wsPvS" class="' + b + 'bg-sky-600 text-white">👁 معاينة الطالب</button><button type="button" id="wsPvT" class="' + b + 'bg-teal-600 text-white">👁 معاينة المعلم</button>' +
      '<button type="button" id="wsPdfS" class="' + b + 'bg-red-700 text-white">📄 PDF الطالب</button><button type="button" id="wsPdfT" class="' + b + 'bg-orange-600 text-white">📄 PDF المعلم (بالإجابات)</button>' + (st.sets.B.length ? '<button type="button" id="wsPdfAB" class="' + b + 'bg-slate-700 text-white">📄 PDF النسختين (أ+ب)</button>' : "") + '<button type="button" id="wsExamBtn" class="' + b + 'bg-indigo-600 text-white">🌐 اختبار إلكتروني للطلاب</button><button type="button" id="wsToGameBtn" class="' + b + 'bg-fuchsia-600 text-white">🎮 حوّل إلى لعبة تفاعلية</button><button type="button" id="wsToReviewBtn" class="' + b + 'bg-emerald-700 text-white">🧠 أرسل للمراجعة الذكية</button><button type="button" id="wsToPlannerBtn" class="' + b + 'bg-violet-700 text-white">🗓️ جدولة بالمخطط</button></div><div id="wsExam"></div>' +
      '<div id="wsPreview"></div><div id="wsQs" class="space-y-3">' +
      arr.map(function (q, i) {
        return '<div class="rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-900/40 p-3"><div class="flex items-center gap-2 mb-2 flex-wrap"><span class="w-6 h-6 rounded-full bg-slate-800 text-white text-[11px] font-black flex items-center justify-center">' + (i + 1) + '</span><span class="text-[11px] font-extrabold text-brand-600">' + TYPES[q.t] + '</span><label class="text-[10px] font-bold flex items-center gap-1 mr-auto">الدرجة <input data-qi="' + i + '" data-pts type="number" min="1" max="20" value="' + q.pts + '" class="w-14 text-xs font-bold border border-slate-300 rounded-lg px-1 py-1 bg-white dark:bg-slate-800"></label>' +
          '<button type="button" data-act="up" data-qi="' + i + '" class="px-2 py-1 rounded-lg bg-slate-200 dark:bg-slate-700 text-[11px]">⬆</button><button type="button" data-act="down" data-qi="' + i + '" class="px-2 py-1 rounded-lg bg-slate-200 dark:bg-slate-700 text-[11px]">⬇</button><button type="button" data-act="regen" data-qi="' + i + '" class="px-2 py-1 rounded-lg bg-purple-600 text-white text-[11px]">🔄</button><button type="button" data-act="del" data-qi="' + i + '" class="px-2 py-1 rounded-lg bg-rose-600 text-white text-[11px]">🗑</button></div>' + qFields(q, i) + "</div>";
      }).join("") + "</div>" +
      '<div class="flex flex-wrap gap-1.5 items-center"><select id="wsAddT" class="' + cls + ' !w-auto flex-1 min-w-[8rem]">' + Object.keys(TYPES).map(function (k) { return '<option value="' + k + '">' + TYPES[k] + "</option>"; }).join("") + '</select><button type="button" id="wsAdd" class="' + b + 'bg-sky-600 text-white whitespace-nowrap">➕ سؤال</button><button type="button" id="wsQBankBtn" class="' + b + 'bg-amber-500 text-slate-950 whitespace-nowrap">🏦 بنك أسئلتي</button><button type="button" id="wsExpJson" class="' + b + 'bg-slate-700 text-white whitespace-nowrap">⬇ تصدير ملف للمعلمين</button><label class="' + b + 'bg-slate-200 dark:bg-slate-700 cursor-pointer whitespace-nowrap">📂 استيراد ملف<input id="wsImpJson" type="file" accept=".json,application/json" class="hidden"></label></div><div id="wsQBankBox"></div><div id="wsEdStat" class="text-[11px] font-bold text-slate-500"></div></div>';

    function dirty() { st.dirty = true; var t = $("wsTot"); if (t) t.textContent = total(cur()); }
    $("wsTitle").oninput = function (ev) { st.title = ev.target.value; st.dirty = true; };
    [["wsSchool", "school"], ["wsTeacher", "teacher"], ["wsDur", "duration"]].forEach(function (p) { $(p[0]).oninput = function (ev) { st[p[1]] = ev.target.value; lsSet(); st.dirty = true; }; });
    $("wsSave").onclick = save;
    $("wsPvS").onclick = function () { preview(false); }; $("wsPvT").onclick = function () { preview(true); };
    $("wsPdfS").onclick = function () { exportPdf(false, false); }; $("wsPdfT").onclick = function () { exportPdf(true, false); };
    if ($("wsPdfAB")) $("wsPdfAB").onclick = function () { exportPdf(false, true); };
    if ($("wsGenB")) $("wsGenB").onclick = genB;
    $("wsExamBtn").onclick = function () { st.examOpen = !st.examOpen; renderExamPanel(); };
    if ($("wsToGameBtn")) $("wsToGameBtn").onclick = function () { if (window.EduGames && window.EduGames.fromWorksheet) window.EduGames.fromWorksheet(st); else toast("وحدة الألعاب قيد التحميل…", "warning"); };
    if ($("wsToReviewBtn")) $("wsToReviewBtn").onclick = function () { if (window.EduBridge && window.EduBridge.toReview) window.EduBridge.toReview(st.title || st.topic || "ورقة عمل", cur()); };
    if ($("wsToPlannerBtn")) $("wsToPlannerBtn").onclick = function () { if (window.EduBridge && window.EduBridge.toPlanner) window.EduBridge.toPlanner("تطبيق ورقة عمل: " + (st.title || st.topic || "درس"), "", "ورقة عمل: " + (st.title || st.subject || "")); };
    if (st.examOpen) renderExamPanel();
    box.querySelectorAll("[data-set]").forEach(function (x) { x.onclick = function () { st.set = x.dataset.set; renderEditor(); }; });
    var qs = $("wsQs");
    qs.addEventListener("input", function (ev) {
      var el = ev.target, i = +el.dataset.qi, q = cur()[i]; if (!q) return;
      if (el.dataset.f) q[el.dataset.f] = el.value;
      else if (el.dataset.opt !== undefined) q.options[+el.dataset.opt] = el.value;
      else if (el.dataset.pts !== undefined) { q.pts = Math.max(1, +el.value || 1); }
      else if (el.dataset.pairs !== undefined) { q.pairs = el.value.split("\n").map(function (l) { var s = l.split("|"); return { a: (s[0] || "").trim(), b: (s.slice(1).join("|") || "").trim() }; }).filter(function (p) { return p.a || p.b; }).slice(0, 5); }
      dirty();
    });
    qs.addEventListener("change", function (ev) {
      var el = ev.target, i = +el.dataset.qi, q = cur()[i]; if (!q) return;
      if (el.dataset.ans !== undefined) { q.answer = +el.dataset.ans; dirty(); }
      else if (el.dataset.tf !== undefined) { q.answer = el.value === "1"; dirty(); }
    });
    qs.addEventListener("click", function (ev) {
      var bt = ev.target.closest("[data-act]"); if (!bt) return; var i = +bt.dataset.qi, a = cur(), act = bt.dataset.act;
      if (act === "up" && i > 0) { var t = a[i]; a[i] = a[i - 1]; a[i - 1] = t; st.dirty = true; renderEditor(); }
      else if (act === "down" && i < a.length - 1) { var t2 = a[i]; a[i] = a[i + 1]; a[i + 1] = t2; st.dirty = true; renderEditor(); }
      else if (act === "del") { if (a.length > 1 && window.eduConfirm("حذف هذا السؤال؟")) { a.splice(i, 1); st.dirty = true; renderEditor(); } }
      else if (act === "regen") regenQ(i);
    });
    $("wsAdd").onclick = function () {
      var t = $("wsAddT").value, n = { t: t, q: "سؤال جديد", pts: PTS[t] };
      if (t === "mcq") { n.options = ["الخيار أ", "الخيار ب", "الخيار ج", "الخيار د"]; n.answer = 0; } else if (t === "tf") n.answer = true; else if (t === "match") n.pairs = [{ a: "عنصر 1", b: "يناسبه 1" }, { a: "عنصر 2", b: "يناسبه 2" }, { a: "عنصر 3", b: "يناسبه 3" }]; else n.answer = "";
      cur().push(n); st.dirty = true; renderEditor();
    };
    if ($("wsExpJson")) $("wsExpJson").onclick = function () {
      var payload = { app: "EduTechWorksheet", v: 44, title: st.title, kind: st.kind, grade: st.grade, subject: st.subject, sets: st.sets };
      var a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
      a.download = "ورقة-عمل-" + (st.title || "درس").slice(0, 35) + ".json";
      document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 600);
      toast("تم تنزيل ملف الورقة لمشاركته مع الزملاء ✓");
    };
    if ($("wsImpJson")) $("wsImpJson").onchange = function (ev) {
      var f = ev.target.files && ev.target.files[0]; if (!f) return;
      var rd = new FileReader();
      rd.onload = function () {
        try {
          var j = JSON.parse(rd.result);
          var setA = ((j.sets && j.sets.A) || j.setA || j.questions || []).map(normQ).filter(Boolean);
          if (!setA.length) throw new Error("ملف غير صالح");
          st.id = ""; st.title = j.title || "ورقة مستوردة"; st.grade = j.grade || st.grade; st.subject = j.subject || st.subject;
          st.sets = { A: setA, B: ((j.sets && j.sets.B) || j.setB || []).map(normQ).filter(Boolean) };
          st.set = "A"; st.dirty = true; renderEditor();
          toast("تم استيراد " + setA.length + " سؤال بنجاح ✓");
        } catch (x) { toast("ملف غير صالح للاستيراد", "warning"); }
      };
      rd.readAsText(f);
    };
    if ($("wsQBankBtn")) $("wsQBankBtn").onclick = function () {
      var qbox = $("wsQBankBox"); if (!qbox) return;
      if (qbox.innerHTML) { qbox.innerHTML = ""; return; }
      var savedList = ($("wsMine") && $("wsMine")._list) || [];
      var allQs = [];
      savedList.forEach(function (w) {
        (w.setA || []).forEach(function (q) {
          var nq = normQ(q);
          if (nq) allQs.push({ wTitle: w.title || "ورقة", grade: w.grade || "", q: nq });
        });
      });
      if (!allQs.length) {
        qbox.innerHTML = '<div class="p-3 rounded-xl bg-amber-50 dark:bg-slate-800 border border-amber-300 text-xs">لا توجد أسئلة في أوراقك المحفوظة بعد. احفظ ورقة عمل أولاً ليتكون بنك أسئلتك الخاص.</div>';
        return;
      }
      qbox.innerHTML = '<div class="p-3 rounded-2xl border-2 border-amber-400 bg-amber-50/60 dark:bg-slate-900/70 space-y-2"><div class="flex items-center justify-between"><span class="text-xs font-black">🏦 بنك أسئلتي المحفوظة (' + allQs.length + ' سؤال) — اضغط لإضافته للورقة الحالية</span><button type="button" id="wsQBClose" class="text-xs font-bold text-rose-600">✕ إغلاق</button></div><div class="max-h-60 overflow-y-auto space-y-1.5">' +
        allQs.map(function (item, idx) {
          return '<div class="flex items-center justify-between gap-2 p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs">' +
            '<div class="min-w-0 flex-1"><span class="font-extrabold text-brand-600">[' + e(TYPES[item.q.t]) + ']</span> ' + e(item.q.q) + ' <span class="text-[10px] text-slate-400">(' + e(item.wTitle) + ')</span></div>' +
            '<button type="button" data-qbadd="' + idx + '" class="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-[11px] font-bold shrink-0">+ أضف</button></div>';
        }).join("") + '</div></div>';
      $("wsQBClose").onclick = function () { qbox.innerHTML = ""; };
      qbox.querySelectorAll("[data-qbadd]").forEach(function (bt) {
        bt.onclick = function () {
          var picked = allQs[+bt.dataset.qbadd];
          if (picked && picked.q) {
            cur().push(JSON.parse(JSON.stringify(picked.q)));
            st.dirty = true;
            toast("أُضيف السؤال إلى الورقة ✓");
            renderEditor();
          }
        };
      });
    };
  }


  // ---------- الاختبار الإلكتروني للطلاب + النتائج ----------
  var ex = { id: "", published: false, open: true, duration: 0, showAnswers: "after", shuffle: "on", certPct: 60 };
  function examLink() { return location.origin + location.pathname.replace(/index\.html$/, "") + "?x=" + st.id; }
  function renderExamPanel() {
    var box = $("wsExam"); if (!box) return;
    if (!st.examOpen) { box.innerHTML = ""; return; }
    if (st.id && ex.id !== st.id && cloud()) {
      ex = { id: st.id, published: false, open: true, duration: 0, showAnswers: "after", shuffle: "on", certPct: 60 };
      window.Cloud.col("exams").doc(st.id).get().then(function (d) { if (d.exists) { var x = d.data(); ex.published = true; ex.open = x.open !== false; ex.duration = x.duration || 0; ex.showAnswers = x.showAnswers || "after"; ex.shuffle = x.shuffle || "on"; ex.certPct = x.certPct == null ? 60 : +x.certPct; } renderExamPanel(); }, function () {});
    }
    var b = "px-3 py-2 rounded-xl text-[11px] font-extrabold ";
    box.innerHTML = '<div class="rounded-2xl border border-indigo-300 dark:border-indigo-700 bg-indigo-50/60 dark:bg-slate-900/40 p-3 space-y-2"><div class="text-sm font-black">🌐 اختبار إلكتروني للطلاب</div>' +
      '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2"><select id="exDur" class="' + cls + '">' + [0, 10, 15, 20, 30, 45, 60].map(function (m) { return '<option value="' + m + '"' + (m === ex.duration ? " selected" : "") + ">" + (m ? "الزمن: " + m + " دقيقة" : "بدون مؤقت") + "</option>"; }).join("") + '</select>' +
      '<select id="exShuf" class="' + cls + '"><option value="on"' + (ex.shuffle !== "off" ? " selected" : "") + '>ترتيب الأسئلة والخيارات عشوائي لكل طالب (يقلل الغش)</option><option value="off"' + (ex.shuffle === "off" ? " selected" : "") + '>ترتيب ثابت للجميع</option></select><select id="exShow" class="' + cls + '"><option value="after"' + (ex.showAnswers !== "hidden" ? " selected" : "") + '>يرى الطالب الإجابات الصحيحة بعد التسليم</option><option value="hidden"' + (ex.showAnswers === "hidden" ? " selected" : "") + ">إخفاء الإجابات عن الطالب</option></select>" + '<select id="exCert" class="' + cls + '">' + [0, 50, 60, 70, 80, 90].map(function (m) { return '<option value="' + m + '"' + (m === (ex.certPct == null ? 60 : ex.certPct) ? " selected" : "") + ">" + (m ? "🏅 شهادة إنجاز للطالب عند " + m + "% فأكثر" : "بدون شهادة") + "</option>"; }).join("") + '</select></div>' +
      '<p class="text-[10px] text-slate-600 dark:text-slate-400 leading-relaxed">الطالب يحلّ أونلاين أو يطبع الورقة من الرابط نفسه. التصحيح التلقائي: اختيار من متعدد، صح وخطأ، أكمل الفراغ، وصّل. السؤال القصير والمسألة لا تدخل في الدرجة ويقرأ المعلم إجاباتها من لوحة النتائج. اسم الطالب ودرجته يُحفظان ويراهما صاحب الاختبار فقط. الإجابات الصحيحة موجودة في بيانات الاختبار، فهو مناسب للتدريب والتقويم الصفي لا للاختبارات الرسمية المغلقة.</p>' +
      '<div class="flex flex-wrap gap-1.5 items-center"><button type="button" id="exPub" class="' + b + 'bg-emerald-600 text-white">🚀 ' + (ex.published ? "حدّث الاختبار" : "انشر الاختبار") + "</button>" +
      (ex.published && st.id ? '<input id="exLink" readonly value="' + e(examLink()) + '" class="' + cls + ' !w-auto flex-1 min-w-[10rem]" dir="ltr"><button type="button" id="exCopy" class="' + b + 'bg-sky-600 text-white">نسخ الرابط</button><button type="button" id="exTog" class="' + b + (ex.open ? "bg-amber-600" : "bg-slate-600") + ' text-white">' + (ex.open ? "⏸ إغلاق الاختبار" : "▶ فتح الاختبار") + '</button><button type="button" id="exRes" class="' + b + 'bg-indigo-700 text-white">📊 النتائج</button>' : "") +
      (ex.published && st.id ? '<button type="button" id="exPin" class="' + b + 'bg-indigo-600 text-white">📌 انشر في مادة (ورقة أو اختبار)</button><button type="button" id="exClassPin" class="' + b + 'bg-sky-700 text-white">🏫 أضف إلى فصل دراسي</button>' : "") +
      '<button type="button" id="exOffHtml" class="' + b + 'bg-teal-700 text-white">📲 تصدير الاختبار بلا إنترنت (ملف HTML / رابط محمول)</button>' +
      '</div><div id="wsResults"></div></div>';
    $("exPub").onclick = publishExam;
    if ($("exCopy")) $("exCopy").onclick = function () { var l = examLink(); if (typeof copyTextToClipboard === "function") copyTextToClipboard(l, "تم نسخ رابط الاختبار 🔗"); else { try { navigator.clipboard.writeText(l); toast("تم نسخ رابط الاختبار 🔗"); } catch (x) { window.eduPrompt("انسخ الرابط", l); } } };
    if ($("exTog")) $("exTog").onclick = function () { var nv = !ex.open; window.Cloud.col("exams").doc(st.id).set({ open: nv }, { merge: true }).then(function () { ex.open = nv; toast(nv ? "تم فتح الاختبار" : "تم إغلاق الاختبار"); renderExamPanel(); }, function () { toast("تعذر التحديث", "warning"); }); };
    if ($("exRes")) $("exRes").onclick = loadResults;
    if ($("exPin")) $("exPin").onclick = function () { if (window.EduPublish) window.EduPublish.open({ kind: "exam", title: st.title, url: examLink() }); };
    if ($("exClassPin")) $("exClassPin").onclick = function () { if (window.EduClassrooms && window.EduClassrooms.assign) window.EduClassrooms.assign({ kind: "exam", title: st.title, url: examLink(), refId: st.id }); };
    if ($("exOffHtml")) $("exOffHtml").onclick = exportOfflineExamFile;
  }

  function exportOfflineExamFile() {
    var qsList = (st.sets && st.sets.A && st.sets.A.length) ? st.sets.A : [];
    if (!qsList.length) { toast("ولّد أسئلة الورقة أو الاختبار أولاً قبل التصدير", "warning"); return; }
    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
      '<title>اختبار تفاعلي بلا إنترنت — ' + e(st.title || "اختبار") + '</title>' +
      '<style>*{box-sizing:border-box}body{margin:0;font-family:Tahoma,Arial,sans-serif;background:#f1f5f9;color:#0f172a;padding:16px;line-height:1.8}.w{max-width:740px;margin:0 auto}.h{background:linear-gradient(135deg,#0f766e,#1e3a8a);color:#fff;padding:18px;border-radius:18px;margin-bottom:14px}.c{background:#fff;border:1px solid #cbd5e1;border-radius:16px;padding:14px;margin-bottom:12px}.o{display:block;padding:8px 12px;border:1.5px solid #e2e8f0;border-radius:10px;margin-top:6px;cursor:pointer}.btn{width:100%;padding:14px;border:0;border-radius:14px;background:#0f766e;color:#fff;font-weight:900;font-size:16px;cursor:pointer}</style></head><body><div class="w">' +
      '<div class="h"><h1 style="margin:0 0 4px;font-size:20px">' + e(st.title || "اختبار تفاعلي") + '</h1><p style="margin:0;font-size:12px">' + e([st.school, st.grade, st.subject, st.teacher].filter(Boolean).join(" • ")) + ' — يعمل بلا إنترنت (EduTech Mindset)</p></div>' +
      '<div class="c"><label style="font-weight:800;font-size:13px">اسم الطالب الكامل:</label><input id="stName" style="width:100%;padding:8px 12px;border-radius:10px;border:1.5px solid #cbd5e1;margin-top:4px" placeholder="اكتب اسمك هنا…"></div>' +
      qsList.map(function (q, i) {
        var optsHtml = "";
        if (q.t === "mcq" && Array.isArray(q.options)) {
          optsHtml = q.options.map(function (op) {
            return '<label class="o"><input type="radio" name="q' + i + '" value="' + e(op) + '"> ' + e(op) + '</label>';
          }).join("");
        } else if (q.t === "tf") {
          optsHtml = '<label class="o"><input type="radio" name="q' + i + '" value="صح"> صح</label><label class="o"><input type="radio" name="q' + i + '" value="خطأ"> خطأ</label>';
        } else {
          optsHtml = '<input type="text" name="q' + i + '" style="width:100%;padding:8px;border-radius:10px;border:1px solid #cbd5e1;margin-top:6px" placeholder="اكتب إجابتك هنا…">';
        }
        return '<div class="c qcard" data-ans="' + e(q.answer || "") + '" data-pts="' + (+q.pts || 1) + '"><div style="font-weight:800">(' + (i + 1) + ') ' + e(q.q) + ' <span style="float:left;font-size:11px;color:#64748b">' + (+q.pts || 1) + ' د</span></div>' + optsHtml + '<div class="ans-fb" style="display:none;margin-top:8px;padding:6px 10px;border-radius:8px;background:#ecfdf5;color:#065f46;font-size:12px;font-weight:800">الإجابة النموذجية: ' + e(q.answer || "") + '</div></div>';
      }).join("") +
      '<button type="button" class="btn" onclick="gradeMe()">✅ تسليم الإجابات وعرض النتيجة فوراً</button>' +
      '<div id="resBox" class="c" style="display:none;margin-top:14px;text-align:center;font-weight:900;font-size:18px;background:#ecfdf5;border-color:#10b981"></div>' +
      '</div><script>function gradeMe(){var cards=document.querySelectorAll(".qcard"),sc=0,mx=0;cards.forEach(function(c,i){var ans=(c.getAttribute("data-ans")||"").trim(),pts=+c.getAttribute("data-pts")||1;mx+=pts;var r=c.querySelector("input[type=radio]:checked")||c.querySelector("input[type=text]");var v=r?(r.value||"").trim():"";if(v&&ans&&v===ans){sc+=pts;c.style.borderColor="#10b981";}else{c.style.borderColor="#f43f5e";}var fb=c.querySelector(".ans-fb");if(fb)fb.style.display="block";});var b=document.getElementById("resBox"),nm=document.getElementById("stName").value||"طالب";b.style.display="block";b.innerHTML="🌟 الطالب/ـة: "+nm+"<br>الدرجة المستحقة: "+sc+" من "+mx+" ("+Math.round(sc*100/(mx||1))+"%)";window.scrollTo({top:document.body.scrollHeight,behavior:"smooth"});}</script></body></html>';
    var blob = new Blob([html], { type: "text/html;charset=utf-8" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "اختبار-محمول-بلا-إنترنت-" + (st.title || "اختبار").slice(0, 30) + ".html";
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 700);
    toast("تم تنزيل ملف الاختبار التفاعلي المستقل (.html) — يعمل على أي هاتف بلا إنترنت عبر البلوتوث أو واتساب ✓");
  }
  function publishExam() {
    if (needLogin()) return;
    var dur = +$("exDur").value, shw = $("exShow").value, shf = $("exShuf").value, cp = +$("exCert").value;
    ex.duration = dur; ex.showAnswers = shw;
    Promise.resolve(st.id && !st.dirty ? 0 : save()).then(function () {
      if (!st.id) return;
      var u = (window.Cloud && window.Cloud.getStudioUser ? window.Cloud.getStudioUser() : window.Cloud.user);
      function encAns(qList) {
        return (qList || []).map(function (q) {
          var copy = JSON.parse(JSON.stringify(q));
          try {
            var raw = JSON.stringify({ a: copy.answer, p: copy.pairs });
            var xored = "";
            for (var i = 0; i < raw.length; i++) xored += String.fromCharCode(raw.charCodeAt(i) ^ ((i * 7 + 42) & 0xff));
            copy._ak = btoa(unescape(encodeURIComponent(xored)));
          } catch (x) {}
          return copy;
        });
      }
      var data = { ownerUid: u.uid, ownerEmail: u.email || "", title: st.title, kind: st.kind, grade: st.grade, subject: st.subject, school: st.school, teacher: st.teacher, duration: dur, showAnswers: shw, shuffle: shf, certPct: cp, open: ex.open !== false, sets: { A: encAns(st.sets.A), B: encAns(st.sets.B) }, updatedAt: window.Cloud.stamp() };
      return window.Cloud.col("exams").doc(st.id).set(data, { merge: true }).then(function () { ex = { id: st.id, published: true, open: data.open, duration: dur, showAnswers: shw, shuffle: shf, certPct: cp }; toast("تم نشر الاختبار ✓ انسخ الرابط وأرسله للطلاب"); renderExamPanel(); },
        function (err) { toast(err && err.code === "permission-denied" ? "لا صلاحية: انشر قواعد Firestore الجديدة" : "تعذر النشر", "warning"); });
    });
  }
  function fmtT(sec) { return Math.floor(sec / 60) + ":" + ("0" + (sec % 60)).slice(-2); }
  function loadResults() {
    var box = $("wsResults"); if (!box) return; box.innerHTML = '<p class="text-[11px] font-bold">⏳ جارٍ تحميل النتائج…</p>';
    window.Cloud.col("examResults").where("ownerUid", "==", uid()).where("examId", "==", st.id).get().then(function (snap) {
      var rows = snap.docs.map(function (d) { return Object.assign({ id: d.id }, d.data()); });
      rows.sort(function (a, b) { return ((b.at && b.at.seconds) || 0) - ((a.at && a.at.seconds) || 0); });
      box._rows = rows; paintResults();
    }, function () { box.innerHTML = '<p class="text-[11px] text-rose-600">تعذر تحميل النتائج (تحقق من نشر قواعد Firestore).</p>'; });
  }
  // تحليل كل سؤال: نسبة الإجابات الصحيحة وعدد من أجابوه (الأسئلة المقالية/اليدوية تُستثنى)
  function qTable(rows, qn) {
    var A = rows.filter(function (r) { return r.set !== "B"; }), body = "", any = false;
    for (var i = 0; i < qn; i++) {
      var tot = 0, c = 0, wrong = 0; A.forEach(function (r) { var v = (r.correct || [])[i]; if (typeof v === "number" && v >= 0) { tot += v; c++; if (v < 0.5) wrong++; } });
      if (!c) continue; any = true; var pc = Math.round(tot / c * 100), col = pc >= 75 ? "#10b981" : pc >= 50 ? "#f59e0b" : "#ef4444";
      body += '<tr><td class="p-1.5 border text-center font-black">' + (i + 1) + '</td><td class="p-1.5 border">' + e(st.sets.A[i].q).slice(0, 70) + '</td><td class="p-1.5 border" style="min-width:90px"><div style="background:#e2e8f0;border-radius:6px;height:10px"><div style="width:' + pc + '%;background:' + col + ';height:10px;border-radius:6px"></div></div></td><td class="p-1.5 border text-center font-black">' + pc + '%</td><td class="p-1.5 border text-center">' + wrong + " / " + c + "</td></tr>";
    }
    var weak = rows.filter(function (r) { return (r.pct || 0) < 50; }).sort(function (a, b) { return a.pct - b.pct; }).slice(0, 12).map(function (r) { return e(r.name) + " (" + r.pct + "%)"; }), wk = weak.length ? '<p class="text-[11px] font-bold mt-2 text-rose-700">⚠️ طلاب يحتاجون دعماً (أقل من 50%): ' + weak.join("، ") + "</p>" : "";
    if (!any) return wk;
    return wk + '<details class="mt-2 rounded-xl border bg-white dark:bg-slate-800 p-2"><summary class="text-[11px] font-black cursor-pointer">📊 تحليل الأسئلة (نسبة الصواب لكل سؤال' + (rows.some(function (r) { return r.set === "B"; }) ? " — للنسخة أ فقط" : "") + ')</summary><div class="overflow-x-auto mt-2"><table class="w-full text-[11px] border-collapse"><thead><tr class="bg-slate-200 dark:bg-slate-700"><th class="p-1.5 border">#</th><th class="p-1.5 border">السؤال</th><th class="p-1.5 border"></th><th class="p-1.5 border">% صواب</th><th class="p-1.5 border">أخطأ</th></tr></thead><tbody>' + body + "</tbody></table></div></details>";
  }
  function paintResults() {
    var box = $("wsResults"), rows = box._rows || [];
    if (!rows.length) { box.innerHTML = '<p class="text-[11px] text-slate-600">لا نتائج بعد. أرسل الرابط للطلاب ثم اضغط «النتائج» للتحديث.</p>'; return; }
    var n = rows.length, avg = Math.round(rows.reduce(function (a, r) { return a + (r.pct || 0); }, 0) / n), best = Math.max.apply(null, rows.map(function (r) { return r.pct || 0; })), low = Math.min.apply(null, rows.map(function (r) { return r.pct || 0; }));
    var bk = [["0-49", 0, 49], ["50-59", 50, 59], ["60-69", 60, 69], ["70-79", 70, 79], ["80-89", 80, 89], ["90-100", 90, 100]].map(function (b) { return [b[0], rows.filter(function (r) { return (r.pct || 0) >= b[1] && (r.pct || 0) <= b[2]; }).length]; }), mx = Math.max.apply(null, bk.map(function (b) { return b[1]; })) || 1;
    var chart = '<div class="mt-2 rounded-xl bg-white dark:bg-slate-800 border p-2"><div class="text-[11px] font-black mb-1">توزيع الدرجات (عدد الطلاب)</div><div class="flex items-end gap-1.5 h-24">' + bk.map(function (b) { return '<div class="flex-1 flex flex-col items-center justify-end h-full min-w-0"><span class="text-[10px] font-bold">' + b[1] + '</span><div class="w-full rounded-t-md bg-emerald-500" style="height:' + Math.round(b[1] * 100 / mx * 0.7) + '%;min-height:' + (b[1] ? 3 : 0) + 'px"></div><span class="text-[9px] text-slate-500 mt-1">' + b[0] + "</span></div>"; }).join("") + "</div></div>";
    var qn = st.sets.A.length, hard = -1, hr = 2;
    for (var i = 0; i < qn; i++) { var tot = 0, c = 0; rows.forEach(function (r) { var v = (r.correct || [])[i]; if (typeof v === "number" && v >= 0) { tot += v; c++; } }); if (c && tot / c < hr) { hr = tot / c; hard = i; } }
    var h = '<div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-[11px] font-bold"><div class="rounded-xl bg-white dark:bg-slate-800 p-2 border">الطلاب<br><b class="text-base">' + n + '</b></div><div class="rounded-xl bg-white dark:bg-slate-800 p-2 border">المتوسط<br><b class="text-base">' + avg + '%</b></div><div class="rounded-xl bg-white dark:bg-slate-800 p-2 border">الأعلى<br><b class="text-base">' + best + '%</b></div><div class="rounded-xl bg-white dark:bg-slate-800 p-2 border">الأدنى<br><b class="text-base">' + low + "%</b></div></div>" +
      chart +
      (hard >= 0 ? '<p class="text-[11px] font-bold mt-2">أصعب سؤال: رقم ' + (hard + 1) + " (" + Math.round(hr * 100) + "% إجابات صحيحة) — " + e(st.sets.A[hard].q).slice(0, 80) + "</p>" : "") +
      qTable(rows, qn) +
      '<div class="flex flex-wrap gap-1.5 my-2"><button type="button" id="exAiGradeAll" class="px-3 py-2 rounded-xl text-[11px] font-extrabold bg-purple-600 text-white">🤖 تصحيح المقالي بالذكاء الاصطناعي</button><button type="button" id="exRem" class="px-3 py-2 rounded-xl text-[11px] font-extrabold bg-amber-500 text-slate-950">🩹 ورقة علاجية للأسئلة الصعبة</button><button type="button" id="exToPortfolioRem" class="px-3 py-2 rounded-xl text-[11px] font-extrabold bg-indigo-700 text-white">📁 خطة علاجية للضعاف (في ملف الإنجاز)</button><button type="button" id="exToIep" class="px-3 py-2 rounded-xl text-[11px] font-extrabold bg-teal-700 text-white">🧩 خطة فردية (IEP) للمتعثرين</button><button type="button" id="exBulkCerts" class="px-3 py-2 rounded-xl text-[11px] font-extrabold bg-amber-600 text-white">🏅 شهادات جماعية للمتفوقين</button><button type="button" id="exCsv" class="px-3 py-2 rounded-xl text-[11px] font-extrabold bg-emerald-700 text-white">⬇ تنزيل Excel/CSV</button><button type="button" id="exRef" class="px-3 py-2 rounded-xl text-[11px] font-extrabold bg-slate-600 text-white">تحديث</button></div>' +
      '<div class="overflow-x-auto"><table class="w-full text-[11px] font-semibold border-collapse"><thead><tr class="bg-slate-200 dark:bg-slate-700"><th class="p-1.5 border">الاسم</th><th class="p-1.5 border">النسخة</th><th class="p-1.5 border">الدرجة</th><th class="p-1.5 border">%</th><th class="p-1.5 border">الزمن</th><th class="p-1.5 border"></th></tr></thead><tbody>' +
      rows.map(function (r, k) { return '<tr><td class="p-1.5 border">' + e(r.name) + '</td><td class="p-1.5 border text-center">' + (r.set === "B" ? "ب" : "أ") + '</td><td class="p-1.5 border text-center">' + r.score + " / " + r.max + '</td><td class="p-1.5 border text-center">' + r.pct + '%</td><td class="p-1.5 border text-center">' + fmtT(r.secs || 0) + '</td><td class="p-1.5 border text-center whitespace-nowrap"><button type="button" data-rv="' + k + '" class="px-2 py-1 rounded-lg bg-sky-600 text-white">إجاباته</button> <button type="button" data-rd="' + k + '" class="px-2 py-1 rounded-lg bg-rose-600 text-white">🗑</button></td></tr>'; }).join("") + '</tbody></table></div><div id="exDetail" class="mt-2"></div>';
    box.innerHTML = h;
    $("exRef").onclick = loadResults;
    if ($("exToPortfolioRem")) $("exToPortfolioRem").onclick = function () {
      var lowStudents = rows.filter(function (r) { return (r.pct || 0) < 50; }).map(function (r) { return r.name + " (" + r.pct + "%)"; });
      var hardSkill = hard >= 0 && st.sets.A[hard] ? st.sets.A[hard].q.slice(0, 90) : (st.title || "المهارات الأساسية في الاختبار");
      var weakDesc = "معالجة الإخفاق في اختبار «" + (st.title || "") + "» — المهارة الأكثر صعوبة: (" + hardSkill + ")" +
        (lowStudents.length ? " — الطلاب المستهدفون (" + lowStudents.length + "): " + lowStudents.slice(0, 8).join("، ") : "");
      if (window.EduPortfolio && window.EduPortfolio.openWithRemedial) {
        window.EduPortfolio.openWithRemedial({
          kind: "remedial",
          subject: st.subject || "المادة",
          grade: st.grade || "السابع",
          weakness: weakDesc
        });
      }
    };
    if ($("exToIep")) $("exToIep").onclick = function () {
      var lowest = rows.slice().sort(function (a, b) { return (a.pct || 0) - (b.pct || 0); })[0];
      var stName = lowest ? (lowest.name + " (" + (st.grade || "") + " — حصل على " + (lowest.pct || 0) + "%)") : ("طالب في " + (st.grade || "الصف"));
      var hardSkill = hard >= 0 && st.sets.A[hard] ? st.sets.A[hard].q.slice(0, 90) : (st.title || "مهارات المادة");
      if (window.EduInclusive && window.EduInclusive.openWithIEP) {
        window.EduInclusive.openWithIEP({
          name: stName,
          need: "تعثر دراسي في اختبار «" + (st.title || "") + "» وحاجة لتسهيلات صفية وتجزئة المهارات في: " + hardSkill
        });
      }
    };
    if ($("exBulkCerts")) $("exBulkCerts").onclick = function () {
      var top = rows.filter(function (r) { return (r.pct || 0) >= 60; }).map(function (r) { return r.name + " | " + (r.pct || 0) + "%"; });
      if (!top.length) top = rows.map(function (r) { return r.name + " | " + (r.pct || 0) + "%"; });
      if (window.EduCertificates && window.EduCertificates.openWithNames) {
        window.EduCertificates.openWithNames(top, st.title || st.subject || "اختبار");
        toast("تم إرسال " + top.length + " طالب إلى مولّد الشهادات الجماعية ✓");
      }
    };
    $("exRem").onclick = function () {
      var A = rows.filter(function (r) { return r.set !== "B"; }), wk = [];
      for (var i = 0; i < qn; i++) { var tt = 0, cc = 0; A.forEach(function (r) { var v = (r.correct || [])[i]; if (typeof v === "number" && v >= 0) { tt += v; cc++; } }); if (cc && tt / cc < 0.6) wk.push({ i: i, r: tt / cc }); }
      wk.sort(function (x, y) { return x.r - y.r; }); wk = wk.slice(0, 4);
      if (!wk.length) { toast("لا أسئلة أخطأ فيها أغلب الطلاب (أقل من 60% صحيح) — لا حاجة لورقة علاجية 👏", "success"); return; }
      var tp = $("wsTopic"); if (!tp) return;
      tp.value = ("ورقة علاجية: أخطأ فيها كثير من الطلاب في اختبار «" + st.title + "». ولّد أسئلة تدريب جديدة مشابهة (ليست نسخاً حرفياً) تعالج نفس المهارات بتدرّج من السهل للأصعب:\n" + wk.map(function (x, k) { return (k + 1) + ") " + st.sets.A[x.i].q + "  (نسبة الصواب " + Math.round(x.r * 100) + "%)"; }).join("\n")).slice(0, 5900);
      var kd = $("wsKind"); if (kd) kd.value = "worksheet";
      tp.scrollIntoView({ behavior: "smooth", block: "center" });
      toast("جهّزنا موضوع الورقة العلاجية من أصعب " + wk.length + " أسئلة، اضغط ولّد", "success");
    };
    $("exCsv").onclick = function () {
      var head = ["الاسم", "النسخة", "الدرجة", "من", "النسبة %", "الزمن (ثانية)", "التاريخ"].concat(st.sets.A.map(function (x, i) { return "س" + (i + 1); })), q = function (v) { return '"' + String(v == null ? "" : v).replace(/"/g, '""') + '"'; };
      var csv = [head.map(q).join(",")].concat(rows.map(function (r) { return [r.name, r.set === "B" ? "ب" : "أ", r.score, r.max, r.pct, r.secs, r.at && r.at.seconds ? new Date(r.at.seconds * 1000).toLocaleString("ar") : ""].concat(st.sets.A.map(function (x, i) { var v = (r.correct || [])[i]; return typeof v !== "number" ? "" : v < 0 ? "يدوي" : Math.round(v * 100) / 100; })).map(q).join(","); })).join("\r\n");
      var a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["﻿", csv], { type: "text/csv;charset=utf-8" })); a.download = "نتائج-" + (st.title || "اختبار").slice(0, 40) + ".csv"; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    };
    function recalcAndSaveRow(r) {
      var qsx = st.sets[r.set] && st.sets[r.set].length ? st.sets[r.set] : st.sets.A;
      var sc = 0, mx = 0;
      qsx.forEach(function (qq, i) {
        var c = (r.correct || [])[i];
        if (typeof c === "number" && c >= 0) {
          var pts = +qq.pts || 1;
          mx += pts;
          sc += pts * c;
        }
      });
      r.score = Math.round(sc * 10) / 10;
      r.max = mx;
      r.pct = mx ? Math.round(r.score * 100 / mx) : 0;
      return window.Cloud.col("examResults").doc(r.id).set({
        correct: r.correct,
        score: r.score,
        max: r.max,
        pct: r.pct,
        aiFeedback: r.aiFeedback || {}
      }, { merge: true });
    }

    function gradeRowWithAI(r) {
      var qsx = st.sets[r.set] && st.sets[r.set].length ? st.sets[r.set] : st.sets.A;
      var items = [];
      qsx.forEach(function (qq, i) {
        if (qq.t === "short" || qq.t === "problem" || (r.correct || [])[i] < 0) {
          items.push({ idx: i, q: qq.q, modelAnswer: qq.answer || "", maxPts: +qq.pts || 1, studentAnswer: (r.answers || [])[i] || "" });
        }
      });
      if (!items.length) return Promise.resolve(false);
      var prompt = "أنت مصحح تربوي عادل ودقيق. قارن إجابة الطالب بالإجابة النموذجية لكل سؤال مقالي/مسألة، وأعطِ نسبة استحقاق الدرجة ratio من 0 إلى 1 (مثلاً 1 للإجابة الكاملة، 0.5 لنصف الدرجة، 0 للخطأ أو الفارغ) مع تعليق قصير ومشجع للطالب بالعربية (feedback).\n" +
        "الأسئلة وإجابات الطالب:\n" + JSON.stringify(items) + "\n" +
        "أعد JSON فقط بهذا الشكل بلا أي شرح:\n{\"grades\":[{\"idx\":0,\"ratio\":1,\"feedback\":\"إجابة ممتازة ودقيقة\"}]}";
      return window.AI.ask(prompt, [], "worksheet").then(function (txt) {
        var j = parseJson(txt);
        var grades = (j && j.grades) || [];
        if (!r.correct) r.correct = [];
        if (!r.aiFeedback) r.aiFeedback = {};
        grades.forEach(function (g) {
          var i = +g.idx;
          var ratio = Math.max(0, Math.min(1, parseFloat(g.ratio) || 0));
          r.correct[i] = Math.round(ratio * 100) / 100;
          if (g.feedback) r.aiFeedback["q" + i] = String(g.feedback).slice(0, 220);
        });
        return recalcAndSaveRow(r).then(function () { return true; });
      });
    }

    if ($("exAiGradeAll")) $("exAiGradeAll").onclick = function () {
      var hasManual = st.sets.A.some(function (q) { return q.t === "short" || q.t === "problem"; });
      if (!hasManual) { toast("هذا الاختبار لا يحتوي أسئلة قصيرة أو مسائل مقالية؛ جميع أسئلته مصححة تلقائياً ✓", "info"); return; }
      var btn = $("exAiGradeAll");
      btn.disabled = true; btn.textContent = "⏳ جارٍ تصحيح إجابات الطلاب بالذكاء الاصطناعي…";
      var queue = rows.slice();
      (function next() {
        var r = queue.shift();
        if (!r) {
          btn.disabled = false; btn.textContent = "🤖 تصحيح المقالي بالذكاء الاصطناعي";
          toast("تم تصحيح الأسئلة المقالية وتحديث درجات الطلاب بنجاح ✓");
          paintResults();
          return;
        }
        gradeRowWithAI(r).then(next, next);
      })();
    };

    box.querySelectorAll("[data-rv]").forEach(function (bt) { bt.onclick = function () {
      var rowIdx = +bt.dataset.rv, r = rows[rowIdx], qsx = st.sets[r.set] && st.sets[r.set].length ? st.sets[r.set] : st.sets.A;
      var fb = r.aiFeedback || {};
      $("exDetail").innerHTML = '<div class="rounded-xl border-2 border-sky-500/30 bg-white dark:bg-slate-800 p-3 text-[11px] space-y-2"><div class="flex flex-wrap items-center justify-between gap-2"><b class="text-sm">إجابات الطالب: ' + e(r.name) + ' (' + r.score + ' / ' + r.max + ')</b><div class="flex gap-1.5"><button type="button" id="exAiOneBtn" class="px-3 py-1 rounded-lg bg-purple-600 text-white font-extrabold">🤖 تصحيح المقالي بالـ AI</button><button type="button" id="exSaveManualBtn" class="px-3 py-1 rounded-lg bg-emerald-600 text-white font-extrabold">💾 حفظ تعديل الدرجات</button></div></div>' + qsx.map(function (qq, i) {
        var c = (r.correct || [])[i], pts = +qq.pts || 1, earned = c >= 0 ? Math.round(c * pts * 10) / 10 : "";
        var mark = c === 1 ? "✅" : c === 0 ? "❌" : c < 0 ? "✍️ (بانتظار التصحيح)" : "◐";
        return '<div class="p-2 rounded-lg bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700">' +
          '<div class="flex items-center justify-between gap-2"><div>' + mark + " <b>" + (i + 1) + ")</b> " + e(qq.q) + '</div>' +
          '<label class="shrink-0 flex items-center gap-1 font-bold">الدرجة: <input type="number" step="0.5" min="0" max="' + pts + '" data-mgrade="' + i + '" value="' + (c >= 0 ? earned : "") + '" placeholder="من ' + pts + '" class="w-16 px-1.5 py-0.5 rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-center"> / ' + pts + '</label></div>' +
          '<div class="mt-1 text-slate-600 dark:text-slate-300">إجابة الطالب: <b>' + (e((r.answers || [])[i]) || "—") + '</b></div>' +
          (qq.t === "short" || qq.t === "problem" || c < 0 ? '<div class="text-emerald-700 dark:text-emerald-400">الإجابة النموذجية: ' + e(qq.answer) + '</div>' : '') +
          (fb["q" + i] ? '<div class="mt-1 text-purple-700 dark:text-purple-300 font-bold">🤖 تعليق المصحح الذكي: ' + e(fb["q" + i]) + '</div>' : '') +
          '</div>';
      }).join("") + "</div>";
      if ($("exAiOneBtn")) $("exAiOneBtn").onclick = function () {
        var b1 = $("exAiOneBtn"); b1.disabled = true; b1.textContent = "⏳ جارٍ التصحيح…";
        gradeRowWithAI(r).then(function (ok) {
          toast(ok ? "تم تصحيح إجابات " + r.name + " بالذكاء الاصطناعي ✓" : "لا توجد أسئلة مقالية لهذا الطالب", ok ? "success" : "info");
          paintResults();
        }, function () { b1.disabled = false; b1.textContent = "🤖 تصحيح المقالي بالـ AI"; toast("تعذر التصحيح الذكي حالياً", "warning"); });
      };
      if ($("exSaveManualBtn")) $("exSaveManualBtn").onclick = function () {
        if (!r.correct) r.correct = [];
        $("exDetail").querySelectorAll("[data-mgrade]").forEach(function (inp) {
          var i = +inp.dataset.mgrade, v = inp.value.trim(), pts = +qsx[i].pts || 1;
          if (v !== "") {
            var num = Math.max(0, Math.min(pts, parseFloat(v) || 0));
            r.correct[i] = Math.round((num / pts) * 100) / 100;
          }
        });
        recalcAndSaveRow(r).then(function () {
          toast("تم حفظ درجات " + r.name + " المحدثة ✓");
          paintResults();
        }, function () { toast("تعذر حفظ التعديل — تأكد من نشر قواعد Firestore المحدثة", "warning"); });
      };
    }; });
    box.querySelectorAll("[data-rd]").forEach(function (bt) { bt.onclick = function () { var r = rows[+bt.dataset.rd]; if (!window.eduConfirm("حذف نتيجة " + r.name + "؟")) return; window.Cloud.col("examResults").doc(r.id).delete().then(function () { rows.splice(+bt.dataset.rd, 1); paintResults(); }, function () { toast("تعذر الحذف", "warning"); }); }; });
  }

  // ---------- الصور ----------
  function shrink(file) {
    return new Promise(function (res, rej) {
      var url = URL.createObjectURL(file), im = new Image();
      im.onload = function () { var m = 1500, k = Math.min(1, m / Math.max(im.width, im.height)), c = document.createElement("canvas"); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(url); res({ mime: "image/jpeg", data: c.toDataURL("image/jpeg", 0.78).split(",")[1] }); };
      im.onerror = function () { URL.revokeObjectURL(url); rej(new Error("img")); }; im.src = url;
    });
  }
  function addFiles(list) {
    Array.prototype.slice.call(list || []).reduce(function (p, f) {
      return p.then(function () {
        if (st.attach.length >= 10) { toast("الحد الأقصى 10 صور", "warning"); return; }
        if (!/^image\//.test(f.type)) {
          if (window.EduSourceCapture) {
            return window.EduSourceCapture.handleFiles([f], {
              onText: function (tx) { var tp = document.getElementById("wsTopic"); if (tp) tp.value = (tp.value ? tp.value + "\n\n" : "") + tx.slice(0, 5000); }
            });
          }
          return;
        }
        return shrink(f).then(function (x) { st.attach.push(x); }, function () { toast("تعذر قراءة الصورة", "warning"); });
      });
    }, Promise.resolve()).then(drawThumbs);
  }
  function drawThumbs() { $("wsThumbs").innerHTML = st.attach.map(function (a, i) { return '<span class="relative inline-block"><img src="data:image/jpeg;base64,' + a.data + '" class="w-14 h-14 object-cover rounded-lg border"><button type="button" data-rm="' + i + '" class="absolute -top-1.5 -left-1.5 w-5 h-5 rounded-full bg-rose-600 text-white text-[10px]">×</button></span>'; }).join(""); }

  // ---------- بناء القسم ----------
  function build() {
    if ($("worksheetStudio")) return true;
    var anchor = $("slidesStudio") || $("teacherTools") || $("aiStudio");
    if (!anchor) return false;
    var h = lsGet(); st.school = h.school || ""; st.teacher = h.teacher || ""; st.duration = h.duration || "";
    var s = document.createElement("section"); s.id = "worksheetStudio"; s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4"><div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-emerald-600 via-teal-700 to-slate-900 text-white"><div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1"><i class="fa-solid fa-file-pen"></i>مولّد أوراق العمل والاختبارات</div><h2 class="text-xl sm:text-2xl font-black">ورقة عمل أو اختبار جاهز للطباعة في دقيقة</h2><p class="text-xs text-white/80 mt-1">اكتب الموضوع أو صوّر صفحة الدرس، ثم عدّل الأسئلة ونزّل PDF للطالب ونسخة المعلم بمفتاح الإجابات.</p></div>' +
      '<div class="p-5 sm:p-6 space-y-3 text-right"><div><label class="block text-xs font-bold mb-1">موضوع الدرس أو النص</label><textarea id="wsTopic" rows="3" maxlength="6000" class="' + cls + '" placeholder="مثال: جمع الكسور العشرية — أو الصق نص الدرس هنا"></textarea></div>' +
      '<div><div class="flex flex-wrap gap-2"><label class="px-4 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-extrabold cursor-pointer flex items-center gap-2"><i class="fa-solid fa-camera"></i>تصوير صفحة<input id="wsCam" type="file" accept="image/*" capture="environment" class="hidden"></label><label class="px-4 py-2.5 rounded-xl bg-sky-600 text-white text-xs font-extrabold cursor-pointer flex items-center gap-2"><i class="fa-solid fa-image"></i>صور من الجوال<input id="wsPick" type="file" accept="image/*,application/pdf,.txt,.md" multiple class="hidden"></label><button type="button" id="wsPickPreset" class="px-3.5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-extrabold flex items-center gap-1.5"><i class="fa-solid fa-book-open"></i><span>درس من المنهاج</span></button></div><div id="wsThumbs" class="flex flex-wrap gap-2 mt-2"></div></div>' +
      '<div class="grid grid-cols-2 sm:grid-cols-3 gap-3"><div><label class="block text-xs font-bold mb-1">النوع</label><select id="wsKind" class="' + cls + '"><option value="worksheet">ورقة عمل (تدريب)</option><option value="exam">اختبار قصير</option></select></div>' +
      '<div><label class="block text-xs font-bold mb-1">المرحلة</label><select id="wsGrade" class="' + cls + '">' + GRADES.map(function (g) { return "<option" + (g === st.grade ? " selected" : "") + ">" + g + "</option>"; }).join("") + '</select></div>' +
      '<div><label class="block text-xs font-bold mb-1">المادة</label><input id="wsSubject" class="' + cls + '" placeholder="رياضيات…"></div>' +
      '<div><label class="block text-xs font-bold mb-1">عدد الأسئلة</label><select id="wsCount" class="' + cls + '"><option>6</option><option selected>10</option><option>15</option><option>20</option></select></div>' +
      '<div class="col-span-2 sm:col-span-2"><label class="block text-xs font-bold mb-1">المستوى</label><select id="wsLevel" class="' + cls + '">' + Object.keys(LEVELS).map(function (k) { return '<option value="' + k + '"' + (k === "mix" ? " selected" : "") + ">" + LEVELS[k] + "</option>"; }).join("") + "</select></div></div>" +
      '<div><div class="text-xs font-bold mb-1.5">أنواع الأسئلة</div><div class="flex flex-wrap gap-2">' + Object.keys(TYPES).map(function (k) { return '<label class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-600 text-[11px] font-bold cursor-pointer"><input id="wsT_' + k + '" type="checkbox"' + (k === "mcq" || k === "tf" || k === "fill" || k === "short" ? " checked" : "") + ">" + TYPES[k] + "</label>"; }).join("") + "</div></div>" +
      '<label class="flex items-center gap-2 text-xs font-bold cursor-pointer"><input id="wsB" type="checkbox"> ولّد نسختين (أ وب) لمنع الغش — يستغرق وقتاً أطول</label>' +
      '<div class="flex flex-wrap items-center gap-2"><button id="wsGo" type="button" class="px-6 py-3 rounded-xl bg-gradient-to-l from-emerald-600 to-teal-600 text-white text-xs font-black shadow-md flex items-center gap-2"><i class="fa-solid fa-wand-magic-sparkles"></i><span>ولّد الأسئلة</span></button><span id="wsStat" class="text-[11px] font-bold text-slate-500"></span></div></div></div>' +
      '<div id="wsEditor"></div><div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700 p-4 sm:p-5 text-right"><div class="flex items-center justify-between mb-2"><h3 class="text-sm font-black">📁 أوراقي المحفوظة</h3><button type="button" id="wsReload" class="text-[11px] font-bold text-brand-600">تحديث</button></div><div id="wsMine" class="space-y-2"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    $("wsGo").onclick = generate;
    if ($("wsPickPreset")) $("wsPickPreset").onclick = function () {
      if (window.EduSourceCapture) window.EduSourceCapture.openPresets(function (p) {
        if ($("wsTopic")) $("wsTopic").value = p.title + "\n\n" + (p.notes || "");
        if ($("wsSubject")) $("wsSubject").value = p.subject || "";
        if ($("wsGrade") && p.grade) $("wsGrade").value = p.grade;
      });
    };
    ["wsCam", "wsPick"].forEach(function (id) { $(id).addEventListener("change", function (ev) { addFiles(ev.target.files); ev.target.value = ""; }); });
    $("wsThumbs").addEventListener("click", function (ev) { var b = ev.target.closest("[data-rm]"); if (b) { st.attach.splice(+b.dataset.rm, 1); drawThumbs(); } });
    $("wsReload").onclick = loadMine;
    $("wsMine").addEventListener("click", function (ev) {
      var o = ev.target.closest("[data-open]"), d = ev.target.closest("[data-del]"), list = $("wsMine")._list || [];
      if (o) { var p = list.filter(function (x) { return x.id === o.dataset.open; })[0]; if (p) openSaved(p); }
      if (d && window.eduConfirm("حذف هذه الورقة نهائياً؟")) window.Cloud.col(COL).doc(d.dataset.del).delete().then(function () { if (st.id === d.dataset.del) st.id = ""; loadMine(); toast("تم الحذف"); }, function () { toast("تعذر الحذف", "warning"); });
    });
    loadMine();
    
    return true;
  }

  window.EduWorksheets = { state: st, paperHtml: paperHtml, openId: function (id) { return window.Cloud.col(COL).doc(id).get().then(function (d) { if (d.exists) openSaved(Object.assign({ id: id }, d.data())); }); }, openExam: function (id) { st.examOpen = true; return window.Cloud.col(COL).doc(id).get().then(function (d) { if (d.exists) { openSaved(Object.assign({ id: id }, d.data())); setTimeout(function () { if (document.getElementById("exRes")) document.getElementById("exRes").click(); }, 700); } }); } };
  function init() { if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();

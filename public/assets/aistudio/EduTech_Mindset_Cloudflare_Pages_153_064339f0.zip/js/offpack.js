/*
 * حقيبة المذاكرة التفاعلية المحمولة بلا إنترنت (Interactive Portable Offline Study Pack) — EduTech Mindset (الإصدار 52)
 * تجمع للطالب أو المعلم في ملف HTML تفاعلي واحد مستقل (Single-File Offline App):
 * 1) 📋 جميع الملخصات الذكية المنشورة ونصوص دروس الكتب المدرسية.
 * 2) ✅ اختبارات التقييم الذاتي التفاعلية (Self-Grading Interactive Quizzes) بلا إنترنت مع تصحيح فوري.
 * 3) 🃏 بطاقات الاستذكار القلّابة التفاعلية (Flashcards) للمراجعة السريعة.
 * 4) 📐 موسوعة القوانين الرياضية والفيزيائية والكيميائية المدمجة + ملاحظات الطالب الخاصة.
 */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var e = function (v) { return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var toast = function (m, t) { if (typeof showToast === "function") showToast(m, t || "success"); };
  var cls = "w-full text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100";

  var BUILTIN_QUIZ = [
    { q: "ما وحدة قياس القوة في النظام الدولي للوحدات (SI)؟", opts: ["الجول (J)", "النيوتن (N)", "الواط (W)", "الباسكال (Pa)"], ans: 1, exp: "النيوتن (N) هو وحدة قياس القوة وفق قانون نيوتن الثاني (ق = ك × ت)." },
    { q: "ما قيمة المميز (Δ) للمعادلة التربيعية: x² - 5x + 6 = 0 ؟", opts: ["Δ = 1", "Δ = 49", "Δ = -1", "Δ = 0"], ans: 0, exp: "Δ = b² - 4ac = (-5)² - 4(1)(6) = 25 - 24 = 1 > 0 (للمعادلة جذران حقيقيان: 2 و 3)." },
    { q: "أي من المدن الفلسطينية التالية تقع على ساحل البحر الأبيض المتوسط؟", opts: ["القدس", "غزة وعكا ويافا", "نابلس والخليل", "أريحا"], ans: 1, exp: "غزة وعكا ويافا وحيفا مدن ساحلية فلسطينية تطل على البحر المتوسط." },
    { q: "ما إعراب كلمة (العلمُ) في جملة: «العلمُ نورٌ يضيء الطريق»؟", opts: ["خبر مرفوع", "مبتدأ مرفوع وعلامة رفعه الضمة", "فاعل مرفوع", "مفعول به منصوب"], ans: 1, exp: "اسم في بداية الجملة الاسمية فهو مبتدأ مرفوع وعلامة رفعه الضمة الظاهرة." }
  ];

  var BUILTIN_CARDS = [
    { front: "قانون أوم الكهربائي", back: "الجهد (V) = شدة التيار (I) × المقاومة (R)" },
    { front: "القانون العام لحل المعادلة التربيعية", back: "x = (-b ± √(b² - 4ac)) / (2a)" },
    { front: "عدد المولات في الكيمياء", back: "عدد المولات (ن) = الكتلة بالغرام ÷ الكتلة المولية" },
    { front: "نظرية فيثاغورس", back: "مربع الوتر = مجموع مربعي الضلعين القائمين (c² = a² + b²)" }
  ];

  function collectPackData(filterGrade) {
    var learn = window.EduLearn && window.EduLearn.data ? window.EduLearn.data() : { tree: { stages: [] }, res: [], books: [] };
    var summaries = (learn.res || []).filter(function (r) { return r.sum || r.kind === "summary"; });
    var booksWithLessons = (learn.books || []).filter(function (b) {
      return (!filterGrade || b.grade === filterGrade) && Array.isArray(b.lessons) && b.lessons.length > 0;
    });
    var formulas = (window.EduSciCalc && window.EduSciCalc.formulas) ? window.EduSciCalc.formulas : [];
    var schedule = {};
    try { schedule = JSON.parse(localStorage.getItem("edu_weekly_schedule_v1") || "{}"); } catch (x) {}
    return {
      summaries: summaries,
      books: booksWithLessons,
      formulas: formulas,
      quiz: BUILTIN_QUIZ,
      cards: BUILTIN_CARDS,
      schedule: schedule
    };
  }

  function downloadOfflineHtmlPack() {
    var fGrade = $("opGrade") ? $("opGrade").value : "";
    var customNotes = $("opNotes") ? $("opNotes").value.trim() : "";
    var incFormulas = !$("opIncFormulas") || $("opIncFormulas").checked;
    var incQuiz = !$("opIncQuiz") || $("opIncQuiz").checked;
    var studentName = localStorage.getItem("edu_student_name") || "طالب EduTech Mindset";
    var data = collectPackData(fGrade);
    var dt = new Date().toLocaleDateString("ar-EG", { day: "numeric", month: "long", year: "numeric" });

    var summariesHtml = data.summaries.length ? data.summaries.map(function (s, i) {
      return '<div class="card searchable"><h3>📋 ' + (i + 1) + ') ' + e(s.title) + '</h3>' +
        (s.desc ? '<p class="meta">' + e(s.desc) + '</p>' : '') +
        '<div class="content">' + e(s.sum || s.desc || "") + '</div></div>';
    }).join("") : '<p class="meta">لا توجد ملخصات منشورة حالياً.</p>';

    var booksHtml = data.books.length ? data.books.map(function (b) {
      return '<div class="card searchable"><h3>📖 ' + e(b.title) + ' (' + e(b.grade || "") + ' — ' + e(b.subject || "") + ')</h3>' +
        (b.lessons || []).map(function (l, k) {
          return '<details style="margin-top:8px;border:1px solid #334155;border-radius:10px;padding:8px"><summary style="font-weight:800;cursor:pointer">الدرس ' + (k + 1) + ': ' + e(l.t) + '</summary>' +
            '<div class="content" style="margin-top:6px">' + e(l.x || "عنوان الدرس مسجل للمراجعة.") + '</div></details>';
        }).join("") + '</div>';
    }).join("") : '<p class="meta">لا توجد نصوص دروس مضافة في الكتب لهذا الاختيار.</p>';

    var formulasHtml = (incFormulas && data.formulas.length) ? '<h2 class="sec-title">📐 موسوعة القوانين العلمية والرياضية (' + data.formulas.length + ')</h2>' +
      data.formulas.map(function (f) {
        return '<div class="card searchable"><div class="meta">' + e(f.cat) + '</div><h3>' + e(f.title) + '</h3><div class="content" style="font-family:monospace;background:#0f172a;padding:8px 12px;border-radius:10px;color:#38bdf8">' + e(f.rule) + '</div></div>';
      }).join("") : "";

    var flashcardsHtml = '<h2 class="sec-title">🃏 بطاقات الاستذكار القلّابة (اضغط على البطاقة لقلبها)</h2>' +
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px">' +
      data.cards.map(function (c) {
        return '<div class="card searchable" style="cursor:pointer;border-color:#0284c7;text-align:center" onclick="toggleCardAns(this)">' +
          '<div style="font-weight:900;color:#fde047">❓ ' + e(c.front) + '</div>' +
          '<div class="ans" style="display:none;margin-top:8px;padding-top:8px;border-top:1px dashed #475569;color:#34d399;font-weight:800">💡 ' + e(c.back) + '</div></div>';
      }).join("") + '</div>';

    var quizHtml = incQuiz ? '<h2 class="sec-title">✅ اختبار التقييم الذاتي التفاعلي (يعمل بلا إنترنت)</h2>' +
      '<div id="quizBox">' +
      data.quiz.map(function (q, qi) {
        return '<div class="card searchable" data-ans="' + q.ans + '"><h3>س' + (qi + 1) + ': ' + e(q.q) + '</h3>' +
          q.opts.map(function (o, oi) {
            return '<label style="display:block;padding:6px 10px;margin:4px 0;border-radius:8px;background:#0f172a;cursor:pointer"><input type="radio" name="q' + qi + '" value="' + oi + '"> ' + e(o) + '</label>';
          }).join("") +
          '<div class="q-exp" style="display:none;margin-top:8px;font-size:13px;color:#34d399;background:#064e3b;padding:8px;border-radius:8px">💡 ' + e(q.exp) + '</div></div>';
      }).join("") +
      '<button type="button" onclick="gradeOfflineQuiz()" style="width:100%;padding:12px;border-radius:14px;border:0;background:#10b981;color:#052e16;font-weight:900;font-size:15px;cursor:pointer">🏆 صحّح إجاباتي الآن</button>' +
      '<div id="quizScore" style="margin-top:10px;text-align:center;font-weight:900;font-size:18px;color:#fde047"></div></div>' : "";

    var html = '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
      '<title>حقيبة المذاكرة التفاعلية بلا إنترنت — EduTech Mindset</title>' +
      '<style>*{box-sizing:border-box}body{margin:0;font-family:Tahoma,Arial,sans-serif;background:#0f172a;color:#f8fafc;line-height:1.8;padding:16px}' +
      '.wrap{max-width:860px;margin:0 auto}.hdr{background:linear-gradient(135deg,#0284c7,#1e3a8a);border-radius:22px;padding:22px;margin-bottom:18px;text-align:center}' +
      '.hdr h1{margin:0 0 6px;font-size:24px}.hdr p{margin:0;font-size:13px;opacity:0.9}' +
      '.search{width:100%;padding:12px 16px;border-radius:14px;border:2px solid #38bdf8;background:#1e293b;color:#fff;font-size:14px;margin-bottom:16px}' +
      '.sec-title{font-size:18px;color:#fde047;margin:18px 0 10px;border-bottom:1px solid #334155;padding-bottom:6px}' +
      '.card{background:#1e293b;border:1px solid #334155;border-radius:18px;padding:16px;margin-bottom:12px}' +
      '.card h3{margin:0 0 6px;color:#38bdf8;font-size:16px}.meta{font-size:12px;color:#94a3b8;margin:0 0 6px}' +
      '.content{white-space:pre-line;font-size:14px;color:#e2e8f0}</style></head><body><div class="wrap">' +
      '<div class="hdr"><h1>🎒 حقيبة المذاكرة التفاعلية بلا إنترنت (الإصدار 52)</h1><p>منصة EduTech Mindset | عقلية التعليم والتكنولوجيا — أُعدّت لـ: ' + e(studentName) + ' (' + dt + ')</p></div>' +
      '<input type="search" id="q" class="search" placeholder="🔍 ابحث في الملخصات والدروس والقوانين والأسئلة (يعمل بلا إنترنت)…" oninput="filterCards(this.value)">' +
      (customNotes ? '<h2 class="sec-title">📝 ملاحظاتي وملخصاتي الخاصة</h2><div class="card searchable"><div class="content">' + e(customNotes) + '</div></div>' : '') +
      flashcardsHtml +
      quizHtml +
      formulasHtml +
      '<h2 class="sec-title">📋 الملخصات الذكية المحفوظة (' + data.summaries.length + ')</h2><div id="sumList">' + summariesHtml + '</div>' +
      '<h2 class="sec-title">📚 نصوص ودروس الكتب المدرسية (' + data.books.length + ' كتب)</h2><div id="bkList">' + booksHtml + '</div>' +
      '</div><script>' +
      'function toggleCardAns(el){var b=el.querySelector(\".ans\");if(b)b.style.display=b.style.display===\"none\"?\"block\":\"none\";}function filterCards(q){q=q.trim().toLowerCase();document.querySelectorAll(".searchable").forEach(function(c){c.style.display=(!q||c.textContent.toLowerCase().indexOf(q)!==-1)?"":"none";});}' +
      'function gradeOfflineQuiz(){var cards=document.querySelectorAll("#quizBox .card"),ok=0;cards.forEach(function(c,i){var ans=+c.getAttribute("data-ans"),sel=c.querySelector("input[type=radio]:checked");var exp=c.querySelector(".q-exp");if(exp)exp.style.display="block";if(sel&&+sel.value===ans){ok++;c.style.borderColor="#10b981";}else{c.style.borderColor="#f43f5e";}});document.getElementById("quizScore").textContent="نتيجتك في المراجعة الذاتية: "+ok+" من "+cards.length+" 🌟";}' +
      '</script></body></html>';

    var blob = new Blob([html], { type: "text/html;charset=utf-8" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "حقيبة-المذاكرة-التفاعلية-بلا-إنترنت-" + (fGrade || "شاملة") + ".html";
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 800);
    toast("تم تنزيل حقيبة المذاكرة التفاعلية (.html) مع الاختبارات والقوانين والبطاقات ✓");
  }

  function paint() {
    var box = $("opBody"); if (!box) return;
    var d = collectPackData("");
    var GRADES = ["الأول الأساسي", "الثاني الأساسي", "الثالث الأساسي", "الرابع الأساسي", "الخامس الأساسي", "السادس الأساسي", "السابع", "الثامن", "التاسع", "العاشر", "الحادي عشر", "الثاني عشر"];

    box.innerHTML = '<div class="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">' +
      '<div class="lg:col-span-7 space-y-3">' +
      '<div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">' +
      '<div><label class="block text-xs font-bold mb-1">تصفية الحقيبة حسب الصف (اختياري)</label>' +
      '<select id="opGrade" class="' + cls + '"><option value="">كل الصفوف والمراحل</option>' + GRADES.map(function (g) { return '<option value="' + g + '">' + g + '</option>'; }).join("") + '</select></div>' +
      '<div class="p-3 rounded-2xl bg-sky-500/10 border border-sky-500/25 flex flex-col justify-center text-center">' +
      '<div class="text-xs font-black text-sky-600 dark:text-sky-300">المحتوى الجاهز للتضمين الآن:</div>' +
      '<div class="text-[11px] font-bold mt-0.5">' + d.summaries.length + ' ملخص • ' + d.books.length + ' كتب • ' + d.formulas.length + ' قانوناً واختباراً</div></div></div>' +
      '<div class="flex flex-wrap gap-3 p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800/80 text-xs font-bold">' +
      '<label class="flex items-center gap-1.5 cursor-pointer"><input type="checkbox" id="opIncFormulas" checked> 📐 تضمين موسوعة القوانين العلمية</label>' +
      '<label class="flex items-center gap-1.5 cursor-pointer"><input type="checkbox" id="opIncQuiz" checked> ✅ تضمين اختبارات التقييم الذاتي والبطاقات القلّابة</label>' +
      '</div>' +
      '<div><label class="block text-xs font-bold mb-1">أضف ملاحظاتك أو ملخصاتك الخاصة لتُحفظ داخل الحقيبة المحمولة (اختياري)</label>' +
      '<textarea id="opNotes" rows="3" class="' + cls + '" placeholder="اكتب أو الصق أي قوانين أو نقاط مهمة تريد الاحتفاظ بها داخل الملف المحمول…"></textarea></div>' +
      '<button type="button" id="opDlBtn" class="w-full py-3 rounded-xl bg-gradient-to-l from-cyan-600 to-blue-700 text-white text-xs font-black shadow-lg">📥 تنزيل «حقيبة المذاكرة التفاعلية بلا إنترنت» (ملف HTML مستقل شامل)</button>' +
      '</div>' +
      '<div class="lg:col-span-5 rounded-3xl border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-900/50 p-5 space-y-2.5 text-xs leading-relaxed">' +
      '<div class="font-black text-sm text-cyan-600 dark:text-cyan-400">💡 الجديد في الحقيبة المحمولة (الإصدار 52):</div>' +
      '<ul class="list-disc list-inside space-y-1.5 text-slate-600 dark:text-slate-300 font-semibold">' +
      '<li>تجمع <b>الملخصات + الدروس + البطاقات القلّابة + اختبارات التصحيح الذاتي + موسوعة القوانين</b> في ملف واحد خفيف.</li>' +
      '<li>يختبر الطالب نفسه ويصحح إجاباته فوراً داخل الملف دون الحاجة لأي اتصال بالشبكة.</li>' +
      '<li>قابل للإرسال الفوري للزملاء عبر <b>البلوتوث أو Quick Share أو واتساب</b>.</li>' +
      '</ul></div></div>';

    $("opDlBtn").onclick = downloadOfflineHtmlPack;
  }

  function build() {
    if ($("offPackStudio")) return true;
    var anchor = $("analyticsStudio") || $("classToolsStudio") || $("teacherDash");
    if (!anchor) return false;
    var s = document.createElement("section");
    s.id = "offPackStudio";
    s.className = "py-12 scroll-mt-20";
    s.innerHTML = '<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">' +
      '<div class="glass-card rounded-3xl border border-slate-200 dark:border-slate-700/90 shadow-xl overflow-hidden">' +
      '<div class="p-5 sm:p-6 bg-gradient-to-l from-cyan-700 via-blue-800 to-slate-900 text-white">' +
      '<div class="flex items-center gap-2 text-xs font-extrabold text-amber-300 mb-1">🎒 حقيبة المذاكرة التفاعلية المحمولة بلا إنترنت (Offline Study & Quiz Pack)</div>' +
      '<h2 class="text-xl sm:text-2xl font-black">احفظ ملخصاتك ودروسك واختباراتك الذاتية وقوانينك في ملف تفاعلي واحد يعمل بلا إنترنت</h2>' +
      '<p class="text-xs text-white/85 mt-1">ميزة مصممة خصيصاً لطلبتنا ومعلمينا في غزة للاحتفاظ بالمحتوى الدراسي والتدريب الذاتي وتبادله عبر البلوتوث.</p>' +
      '</div><div class="p-4 sm:p-6 text-right" id="opBody"></div></div></div>';
    anchor.parentNode.insertBefore(s, anchor.nextSibling);
    paint();
    setTimeout(paint, 2500);
    return true;
  }

  function init() {
    if (build()) return; var n = 0, iv = setInterval(function () { if (build() || ++n > 20) clearInterval(iv); }, 250);
  }
  window.EduOffPack = { open: function () { if (window.EduLauncher && window.EduLauncher.jump) window.EduLauncher.jump("offPackStudio", true); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
